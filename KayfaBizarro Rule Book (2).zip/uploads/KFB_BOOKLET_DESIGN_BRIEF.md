# KayfaBizarro — A5 Booklet Design Brief

**Goal**: Print-ready HTML booklet (20pp DIN A5, double-page = DIN A4) for *KayfaBizarro — The Anti-Rules*. Optimized for readability, fast rule comprehension, and visual consistency with the existing Game Board + Cheat Sheet at `kfb-board-cheatsheet.html`.

**Deliverable**: Single `kfb-rules-booklet.html` file with embedded CSS. Browser print → PDF → print shop. No JS required.

---

## 1. Design Tokens (from existing Cheat Sheet)

```css
:root {
  /* ── typography ── */
  --ff-d: 'Archivo Black', 'Impact', 'Arial Black', sans-serif;   /* display */
  --ff-b: 'Source Sans 3', system-ui, sans-serif;                  /* body */
  --ff-m: 'IBM Plex Mono', 'Courier New', monospace;               /* mono/meta */

  /* ── palette ── */
  --red:    #9E2A20;     /* maroon — headings, numbers, emphasis */
  --gold:   #7A5C18;     /* gold — labels, meta text */
  --ink:    #1C1814;     /* near-black — H2, strong text */
  --ink2:   #3D352C;     /* dark warm — body text */
  --paper:  #F5F0E8;     /* warm off-white — page background */
  --p2:     #ECE5D0;     /* cream — header bars, callout bg */
  --blt:    #BEB5A4;     /* light border — table frames */
  --rule:   #C8BFA8;     /* row separators */

  /* ── mode identity colors ── */
  --tragic:    #BEDAEE;   /* slate blue */
  --comic:     #B8EEC0;   /* bright mint */
  --absurd:    #B4EAEE;   /* aqua teal */
  --heroic:    #E8E4A4;   /* olive gold */
  --mystical:  #CCBEF0;   /* soft violet */
  --forbidden: #EEB8C8;   /* rose pink */

  /* ── orange arc gradient (sequential steps) ── */
  --arc-1: #FEF3E8;
  --arc-2: #FCEACC;
  --arc-3: #FAD8A8;
  --arc-4: #F8C488;
  --arc-5: #F4AE6C;
  --arc-6: #EE9554;
}
```

**Google Fonts** (load via `<link>`):
```
Archivo+Black
Source+Sans+3:ital,wght@0,400;0,600;0,700;1,400
IBM+Plex+Mono:wght@400;600;700
```

---

## 2. Page Format

```css
@page {
  size: A5 portrait;            /* 148mm × 210mm */
  margin: 13mm 16mm 16mm 16mm;  /* top shorter for running head */
}
@page :left  { margin-left: 20mm; margin-right: 14mm; }  /* gutter for binding */
@page :right { margin-left: 14mm; margin-right: 20mm; }
```

- **Content area**: ~118mm × 181mm
- **Footer**: page number right-aligned (odd) / left-aligned (even), `var(--ff-m)` 7pt `var(--gold)`
- **Running head** (optional): `KayfaBizarro` in `var(--ff-m)` 6pt gold, top-right of odd pages

---

## 3. Typography Scale

| Element | Font | Size | Weight | Color | Extras |
|---------|------|------|--------|-------|--------|
| H1 (section) | `--ff-d` | 28pt | — | `--red` | `margin-top: 0; margin-bottom: 3mm` |
| H2 (sub-section) | `--ff-d` | 16pt | — | `--ink` | `margin-top: 5mm; margin-bottom: 2mm` |
| Body | `--ff-b` | 9.5pt | 400 | `--ink2` | `line-height: 1.38` |
| Body bold | `--ff-b` | 9.5pt | 700 | `--ink2` | for inline emphasis |
| Body italic | `--ff-b` | 9.5pt | 400i | `--ink2` | for game-term definitions |
| Label (meta) | `--ff-m` | 8.5pt | 700 | `--gold` | `text-transform: uppercase; letter-spacing: .05em` |
| Number (step) | `--ff-m` | 9.5pt | 700 | `--red` | in colored cells |
| Callout label | `--ff-m` | 8.5pt | 700 | `--gold` | `text-transform: uppercase` |
| Footer | `--ff-m` | 7pt | 400 | `--gold` | page number |

---

## 4. Component Inventory

### 4a. Step Table (Setup, Beats, Quest Die, Solo Setup)

The core structural element. Numbered sequential steps with label + body.

```
┌──────────┬─────────────────────────────────────┐
│ 1 DRAW   │ Take 1 card from the shared deck.   │
│ (orange) │ You hold 4 for a moment.            │
├──────────┼─────────────────────────────────────┤
│ 2 ROLL   │ Roll the Story-Mode Die. Whatever   │
│ (orange) │ it shows is your tone. Commit.      │
└──────────┴─────────────────────────────────────┘
```

**CSS pattern:**
```css
.step-table {
  width: 100%;
  border-collapse: collapse;
  border: 0.5pt solid var(--blt);
  font-size: 9.5pt;
}
.step-table td {
  padding: 2mm 3mm;
  border: 0.5pt solid var(--blt);
  vertical-align: top;
}
.step-table .step-id {
  width: 26mm;
  font-family: var(--ff-m);
  vertical-align: middle;
}
.step-table .step-id .num {
  font-weight: 700;
  color: var(--red);
}
.step-table .step-id .lbl {
  font-weight: 700;
  color: var(--gold);
  text-transform: uppercase;
  letter-spacing: .04em;
  margin-left: 0.5em;
}
```

**Color rule**: each row's `.step-id` cell gets `background: var(--arc-N)` where N = row number (1–5 or 1–6). The body cell stays white.

**Header bar** (optional, for Beats): full-width merged cell, `background: var(--p2)`. Title left in `--ff-d` `--red`, subtitle right in `--ff-m` `--gold` muted.

### 4b. Inline Definition List (Intro Ritual, Social Calls, Finale cleanup, +/-1 modifiers)

For label-value pairs that aren't tabular. One paragraph per item.

```
MEMORY —  Quest card stays on the table as a shared record.
CLEAR  —  Stage cleared. All Scene cards go to discard.
```

**CSS pattern:**
```css
.def-item {
  margin: 1mm 0;
  line-height: 1.38;
}
.def-item .def-label {
  font-family: var(--ff-m);
  font-weight: 700;
  color: var(--gold);
  text-transform: uppercase;
  letter-spacing: .04em;
}
/* exception: brand calls keep mixed case */
.def-item .def-label.brand { text-transform: none; }
```

### 4c. Callout Box (NOTE, ALWAYS, TIMING, ANTI-JOURNALING)

Meta-commentary that's distinct from rules text.

```css
.callout {
  background: var(--p2);
  border-left: 3pt solid var(--red);
  padding: 2.5mm 3.5mm;
  margin: 3mm 0;
  font-size: 9pt;
  line-height: 1.35;
}
.callout .callout-label {
  font-family: var(--ff-m);
  font-weight: 700;
  color: var(--gold);
  text-transform: uppercase;
  letter-spacing: .05em;
  margin-right: 1.5em;
}
```

### 4d. Quote Block

Italicized pull-quotes from the game's voice.

```css
.pull-quote {
  border-left: 3pt solid var(--red);
  padding-left: 3.5mm;
  margin: 3mm 0;
  font-style: italic;
  color: var(--ink2);
}
```

### 4e. Mode Grid (Six Story Modes)

2×3 grid where each cell is a "mode card" with identity color.

```css
.mode-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 2mm;
}
.mode-card {
  border: 0.5pt solid var(--blt);
  padding: 2mm 3mm;
  font-size: 8.5pt;
}
.mode-card .mode-num {
  font-family: var(--ff-m); font-weight: 700; color: var(--red);
}
.mode-card .mode-name {
  font-family: var(--ff-m); font-weight: 700;
  text-transform: uppercase; letter-spacing: .04em;
  color: var(--gold);
  margin-left: 0.5em;
}
```

Each `.mode-card` gets its identity color as background.

### 4f. Glossary Table

2-column reference table: term (mono/gold) + definition (body).

```css
.glossary td:first-child {
  font-family: var(--ff-m);
  font-weight: 700;
  color: var(--gold);
  text-transform: uppercase;
  letter-spacing: .04em;
  width: 24mm;
  vertical-align: top;
}
```

---

## 5. The 3 Key Improvements (DOCX → HTML)

### Improvement 1: Reliable Fonts

The DOCX booklet's #1 problem was font substitution: Impact, Arial, Courier New aren't available on all renderers. LibreOffice on Linux substituted Impact → DejaVu Sans (looked serif-y), Arial → Liberation Sans, Courier → Liberation Mono.

**Fix**: Use Google Fonts (Archivo Black, Source Sans 3, IBM Plex Mono) — same as the cheat-sheet. Embedded in the HTML, rendered identically everywhere.

- Archivo Black replaces Impact: condensed display, very high x-height, unmistakable
- Source Sans 3 replaces Arial: professional, excellent readability at 9–10pt
- IBM Plex Mono replaces Courier New: modern mono, better readability for labels

### Improvement 2: CSS Tables with Proper Sizing

The DOCX table struggles were: cell widths too narrow (PURSUIT wrapping), inconsistent borders (dashed vs solid vs nil), different gradient treatments per table, font/color inconsistencies in label cells.

**Fix**: CSS tables with explicit column widths, consistent `border: 0.5pt solid var(--blt)`, and shared `.step-id` / `.step-body` classes. One definition, all tables inherit.

### Improvement 3: Print Pagination

DOCX pagination was manual (page-break-before). HTML can use:

```css
.section { page-break-before: always; }
h1 { page-break-after: avoid; }
.step-table, .callout { page-break-inside: avoid; }
```

This prevents orphaned headings and split tables.

---

## 6. Content Structure (20 pages)

| Page | Section | Key Components |
|------|---------|----------------|
| 1 | Cover | Title, tagline, FrizzleBob vignette |
| 2 | Contents + Start Here | TOC, "What you need" def-list |
| 3 | Start Here (cont.) | 60-second version callout |
| 4 | Setup | Step table (5 rows, 3-col) |
| 5 | The Intro Ritual | Def-list (3 items) + ALWAYS callout |
| 6 | Your Turn | Step table (5 beats) + King Kayfabian H2 |
| 7 | The Six Story Modes | Mode grid (2×3) + quote |
| 8 | The Stage | Def-list (2) + Actor Switch H2 |
| 9 | The Quest Die | Step table (6 phases) + King's Verdict H2 + def-list (+/-1) + NOTE |
| 10 | The Finale | Body + After the Finale H2 + def-list (4) + Optional Rules H2 |
| 11 | Social Calls | Def-list (4 brand calls) + TIMING callout |
| 12 | Powers & Cards | Body + DON'T SAY table |
| 13 | Solo Play + Solo Setup | Body + step table (5) + Solo Quest Die def-list |
| 14 | Solo Modes A–D | Mode descriptions |
| 15 | Session End + BLÖDSINN! Solo | Body |
| 16 | FAQ | Q&A body text |
| 17 | Glossary | Glossary table |
| 18 | Episode Log | Log table (header + empty rows) |
| 19 | Notes | Blank ruled page |
| 20 | Back Cover | Title, tagline, cheat-sheet reference |

---

## 7. Build Notes

**HTML structure**:
```html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>KayfaBizarro — The Anti-Rules</title>
  <link href="https://fonts.googleapis.com/css2?family=..." rel="stylesheet">
  <style>/* all CSS inline */</style>
</head>
<body>
  <section class="page cover">...</section>
  <section class="page">
    <h1>Setup</h1>
    <table class="step-table">...</table>
  </section>
  <!-- ... -->
</body>
</html>
```

**Print workflow**:
1. Open in Chrome
2. Cmd+P → Save as PDF
3. Settings: A5, no margins (margins are in CSS), background graphics ON
4. Result: 20-page A5 PDF, print-shop ready

**A4 double-page imposition** (for home printing):
- Use a PDF imposition tool (e.g., `pdfbook2`) to arrange A5 pages 2-up on A4 landscape
- Or: add a `@media print` variant with `@page { size: A4 landscape }` and CSS columns

---

## 8. Brand Voice Reminders

- **CamelCase**: KayfaBizarro, MedKayfab, KayfaBINGO!, KayfaBOGGLE?, KayfaBONGO!
- **BLÖDSINN!**: always all-caps
- **Card terms** stay English in both languages: Character→Actor, Scene, Quest, Power, Lore, Mode
- **Players** = "meat puppets" (EN) / "Gestalten" (DE)
- **Object Agency Rule**: actions belong to players, not game objects ("You move the die" not "The die tracks")
- **"Unfinished by Design"**: intentional brand stance

---

## 9. Source Files

- **Content source**: `KayfaBizarro_Anti-Rules_A5_booklet.docx` (v16, current)
- **Design reference**: `kfb-board-cheatsheet.html` (the canonical design system)
- **Landing page**: `https://kayfabizarro.pages.dev/`
- **Brand bible**: `KAYFABIZARRO_BRAND_BIBLE_v1.1.md`

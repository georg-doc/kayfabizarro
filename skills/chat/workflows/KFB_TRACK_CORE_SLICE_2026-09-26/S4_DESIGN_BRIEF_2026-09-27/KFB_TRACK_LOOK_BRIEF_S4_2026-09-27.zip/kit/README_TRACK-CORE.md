# TRACK-CORE · folder layout (Dropbox `KFB Racetrack Blender Kit/TRACK-CORE/`, mirrors GitHub PR #219)

GitHub: `georg-doc/kayfabizarro` branch `georg-doc-patch-2` → `skills/chat/workflows/KFB_TRACK_CORE_SLICE_2026-09-26/<slice>/`

| Folder | Contents |
|---|---|
| `W0_2026-09-27/` | Census, contract v0, RouteRecipe schema, RETURN; `track-core/` = JS core **v0.1** + tests + seed fixture |
| `S2_B1_2026-09-27/` | RETURN, screenshots; `track-core/` = core **v0.2** (split/merge, jumps, connector) + fixtures; `blender/` = B1 importer; `out/` = streams; `b1/` = Blender file, GLB, oracle report |
| `S3_2026-09-27/` | RETURN; `track-core/` = core **v0.3** (skins, bar taper, ramp/steps, anchors, headroom) + `layout/td03.mjs`; `blender/` = importer, Uni-Center scenery, clearance check; `out/` = streams + corridor; `b1/` = TD03 and seed Blender files, GLBs |
| `_to_delete/` | Superseded importer iterations, Dropbox duplicate PNGs, W0 copies that had been overwritten with v0.2. Nothing was deleted; Georg decides. |

The newest core is always in the newest slice folder. Blender files are new per slice; no foreign .blend is saved.

# Pixel check for `stream-to-three.mjs`

1. At the ZIP root: `python3 -m http.server 8765`
2. `CHROMIUM=/path/to/chromium node kit/check/shot.mjs` (needs `playwright`), or open `http://localhost:8765/kit/check/index.html` in a browser.

Tested 2026-09-27: headless Chromium (SwiftShader) with three.js 0.160.0 served locally. The Coworker sandbox blocks unpkg.com, so the
CDN line in `index.html` itself was not exercised there; it is the same three.js version H0 loads from unpkg.
Result: `shots/b14_three_loader_check.png`. Node geometry check: TD03 185,630 vertices, 99,526 triangles, 0 non-finite values.

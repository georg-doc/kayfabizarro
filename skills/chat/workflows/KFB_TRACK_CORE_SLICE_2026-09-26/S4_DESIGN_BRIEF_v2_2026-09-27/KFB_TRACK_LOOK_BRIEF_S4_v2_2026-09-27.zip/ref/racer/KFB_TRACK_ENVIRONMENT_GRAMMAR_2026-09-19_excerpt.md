# KFB Stunt World · Track + Environment Design Grammar v0.1

**Date:** 2026-09-19  
**Status:** PROPOSAL / DESIGN SPEC · NO RUNTIME CHANGE  
**Implementation SSOT:** `georg-doc/KFB-Stunt-Car-Race`  
**Integration lead:** existing WSA / Race owner  
**Stage target after implementation:** `https://kayfabizarro.pages.dev/kfb-hub/stage/stunt-world/`

## Preflight

- **GOAL:** define one reusable KFB track/environment grammar for broad, colourful, psychedelic stunt ribbons that can live inside the real OSM Hürth → Ehrenfeld world and later be seeded from KFB Card JSON.
- **EXISTING OWNER:** WSA / Race remains the integration owner; C0/Free Roam keeps position, contact, collision and recovery ownership.
- **EXACT SOURCES / REVISIONS:** Race main `041670711e6f4c5c4afcdded4652fff8aa3377f1`; accepted v0.8 recipe `2026-09-17.t1t2.a0.2`; current corridor PR #12 head `8108af52de5d54e64c539071ae6d0d28fec2008b` with tested runtime `d2529e634952f25d691d68873801b2651125ac0c`; Kayfabizarro current donor line recovered through `d6062351d69939cdd7015337b060b9c50b6b7a72`; SP13KTRA visual/behaviour reference in
- **PROTECTED BOUNDARIES:** no C0 physics retune; no replacement movement/camera/contact owner; no deformation of collision shells; OSM remains geographic truth; TinySkies/Travel remains presentation/world-language donor; Landmark Group Rig and audio remain non-owning consumers/donors; SP13KTRA code/assets are not reused.
- **DONE WHEN:** width grammar, route-frame grammar, surface/grid language, curve/ramp gesture library, topology rules, Rule-of-Three prop placement, biome seed contract and one bounded runtime POC definition are explicit enough for a separate tested implementation slice.

## 1 · North Star

**The track is the visual spine of the living toy world.**

The target is not “OSM city with a racetrack dropped on top” and not a copy of a futuristic racer. The KFB world should read as one coherent toy-biome in which:

- OSM provides the real geographic skeleton;
- TinySkies / Travel provides terrain, sky, weather, fog, light and broad building language;
- KFB Track supplies a bold, immediately readable drivable ribbon;
- curated landmarks override only their visual representation, never OSM geography;
- KayKit/KFB props appear in authored-looking asymmetric clusters rather than uniform scatter;
- later Card JSON seeds can recolour, redress and animate the same structural world deterministically.

The track surface is therefore a recurring KFB design motif: broad dark ribbon, route-space grid, pale/ink-like edge treatment, a small number of high-saturation gameplay accents and large readable silhouettes.

## 2 · Width ladder

The accepted v0.8 proof uses `baseWidth = 10.8` with local width multipliers. Georg now wants a larger default width.

### Proposed v0.1 width classes

| Class | Full width | Intended use |
|---|---:|---|
| **NARROW** | **10.8** | technical squeeze, service/pit, old v0.8 familiar width |
| **STANDARD** | **14.4** | new default KFB race ribbon |
| **WIDE** | **18.0** | sweepers, drift playground, approach to decision zones |
| **HERO** | **21.6** | start/finish, landmark plaza, large jump/ramp staging |

Design logic: the current accepted v0.8 base width becomes the new **NARROW** class rather than being discarded. The new STANDARD is exactly 4/3 of that width, so ordinary driving gains room without making the old feel proof irrelevant.

### Width rules

1. Width is a continuous route property, never a topology substitute.
2. Width transitions use smoothstep/cubic interpolation; no hard shoulders created by a numeric jump.
3. A typical width transition should occupy roughly **18–36 m** of route length depending on speed and context.
4. Splits may widen before the decision zone, but the split remains a real SPLIT connector.
5. Pit/service lanes may use NARROW while the mainline remains STANDARD/WIDE.
6. Bridge decks retain their own width; an overpass never becomes a split merely because the deck narrows.
7. Road top, edge/side mesh, rails, grid UV and Race contact limit must all consume the same local width value.

Suggested normalized profile for the first proof:

```text
STANDARD 14.4
→ WIDE 18.0 sweeper
→ STANDARD 14.4
→ NARROW 10.8 technical squeeze
→ HERO 21.6 ramp / landmark staging
→ STANDARD 14.4
```

## 3 · Route frame: one geometric language for curves, ramps and banking

A KFB ribbon should be sampled from one centreline and one transported frame. Per route sample:

```text
s
position
forward
right
up
width
elevation
pitch
bank
curvature
surfacePreset
cueTags[]
stuntTags[]
```

The rendered surface is generated from `position ± right * width/2`, while elevation and bank affect the local frame rather than being faked by rotating decorative pieces.

This gives one coherent mechanism for:

- flat streets;
- broad bends;
- hairpins;
- S-curves;
- banked bowls;
- crests/dips;
- ramps;
- bridges/overpasses;
- waves;
- jump take-offs and landing transitions.

### Important constraint

The v0.9 failure remains the guardrail:

```text
SPLIT / MERGE = route topology
OVERPASS = vertical relationship
WIDTH = route dimension
BANK = local frame
RAMP = elevation profile
```

These are separate fields/concepts even when several occur near one another.

## 4 · KFB track gesture library

Do not generate arbitrary noisy splines. Compose a small authored-looking vocabulary of gestures.

### Horizontal gestures

- **LONG STRAIGHT** — breathing space / acceleration / vista.
- **SWEEPER** — large-radius bend, usually WIDE.
- **DOUBLE APEX** — two related curves with a short relief between them.
- **S-CURVE** — clear left-right rhythm, no micro-wiggles.
- **HAIRPIN** — strong silhouette and landmark opportunity.
- **CHICANE** — short deliberate lateral rhythm, not random slalom.
- **BOWL** — sustained banked arc with skyline visible over the outside rail.
- **SKEW / LATERAL SHIFT** — Kenney-like lateral offset useful before splits/merges.

### Vertical gestures

- **CREST** — gentle rise and reveal.
- **DIP** — shallow compression with skyline disappearing then returning.
- **HILL** — climb, elevated run, descent.
- **RAMP** — explicit stunt take-off with readable landing zone.
- **OVERPASS** — climb → deck → independent lower route → descent.
- **WAVE** — two or three broad vertical oscillations, never noisy terrain-following bumps.
- **LAUNCH TABLE** — HERO-width staging plateau into a jump.
- **LANDING FAN** — wider descending receiver surface for forgiving stunt recovery.

### Composition rule

Every 20–60 seconds of normal driving should contain one dominant gesture, one supporting gesture and one visual punctuation. The world should not demand continuous stunt input.

## 5 · Surface language: KFB TOY GRID

The screenshots' strongest reusable idea is not their exact palette; it is the **route-following panel/grid surface** that makes speed, curvature and banking legible.

### Proposed default surface

**KFB TOY GRID**

- near-black / deep-biome road base;
- thin route-space grid;
- off-white or warm pale outer edge/rail;
- one biome accent colour for selected grid majors;
- gameplay pads/strips use a second high-saturation accent only when semantically active;
- surface remains readable in daylight, dusk and strange/fractal presets.

### Grid construction

Do not place a second coplanar grid mesh over the road. That invites the same z-fighting class already observed in city/terrain work.

Instead map the grid in the road material from route coordinates:

```text
u = lateral position / local width
v = route distance s
```

Recommended first visual rhythm:

- longitudinal construction lines: 4–6 subdivisions across STANDARD width;
- transverse minor lines: every ~4.5 m;
- transverse major lines: every ~18 m;
- major panel can receive a very small value/lightness shift for speed rhythm;
- line AA via `fwidth`/derivatives or equivalent low-cost anti-aliasing;
- grid amplitude fades slightly at extreme distance instead of shimmering.

The grid therefore bends, banks, widens and climbs with the same surface without additional geometry.

### Edge language

- low dark structural sidewall;
- pale/ink-like top rail or outer lip;
- rail can carry restrained biome/accent pulses later;
- rail collision remains Race-owned and can keep the accepted forgiving/rubber behaviour;
- edge visuals never change the collision shell silently.

## 6 · Colour + psychedelic biome grammar

The reference works because one circuit is a coherent colour world rather than a pile of unrelated colourful assets. KFB should keep that coherence but use TinySkies/Travel softness and KFB toy/material language.

Per biome seed:

```text
baseHue
secondaryHue
accentHue
roadValue
gridValue
skyTop / skyHorizon
fogHue / density
terrainPalette
buildingPalette
propFamilies[]
weatherPreset
sunPreset
landmarkResponsePreset
trackSurfacePreset
```

### Palette policy

Use a controlled 5-level ladder:

1. dark road / deep shadow;
2. terrain/body mid;
3. building mass;
4. light/sky;
5. one saturated accent.

A second saturated colour is reserved for gameplay state, Cards, boost/recharge or a specific hero landmark. This keeps the result psychedelic without becoming visual noise.

## 7 · OSM + stunt-ribbon relationship

OSM remains geographic truth.

Use three track modes rather than deforming all real roads into rollercoasters:

### A · OSM ROAD SKIN

Existing real street centreline and grade. KFB Track adds surface/material/edge/cue language while leaving the road geographically correct.

### B · AUTHORED STUNT SOCKET

At selected anchors the race ribbon can peel away from the real street into a ramp, bridge, bowl, rooftop-like deck or terrain shortcut, then reconnect through explicit connectors.

### C · FACILITY / FANTASY TRACK

In dedicated race areas, track topology may be fully authored while the surrounding OSM/TinySkies world remains the geographic context.

This preserves the Hürth → Ehrenfeld world while allowing spectacular geometry where it helps play rather than warping every street.

## 8 · Rule-of-Three prop mapping

Reuse the existing Travel composition principle rather than inventing another scatterer.


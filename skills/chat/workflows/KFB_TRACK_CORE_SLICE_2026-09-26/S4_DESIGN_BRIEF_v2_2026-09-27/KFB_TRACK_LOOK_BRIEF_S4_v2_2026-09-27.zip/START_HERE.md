# Start here · S4 v2 · track kit look (Claude Design)

1. Read `BRIEF_CLAUDE_DESIGN_TRACK_LOOK_S4_v2.md`: §0 (what changed) and §1A (priority) first.
2. Serve this folder (`python3 -m http.server 8765`), open `kit/check/index.html` (TD03) and `kit/check/tn02.html` (tunnels) to see the streams in three.js.
3. Deliver Phase A (§1A, §6) with a RETURN.md, defects first. Georg decides the look.

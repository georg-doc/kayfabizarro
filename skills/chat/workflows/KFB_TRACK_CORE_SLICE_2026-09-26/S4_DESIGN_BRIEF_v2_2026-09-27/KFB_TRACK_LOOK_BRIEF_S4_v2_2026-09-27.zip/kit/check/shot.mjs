// node kit/check/shot.mjs  (server on :8765 at the ZIP root; Playwright + Chromium installed)
import { chromium } from 'playwright';
const b = await chromium.launch({ executablePath: process.env.CHROMIUM, args: ['--use-gl=swiftshader', '--enable-webgl', '--ignore-gpu-blocklist'] });
const p = await b.newPage({ viewport: { width: 1200, height: 750 } });
p.on('pageerror', (e) => console.log('err', e.message));
await p.goto('http://localhost:8765/kit/check/' + (process.argv[2] ?? 'index.html')); await p.waitForFunction('window.DONE===true', { timeout: 60000 });
await p.screenshot({ path: process.argv[3] ?? 'three_check.png' }); await b.close(); console.log('ok');

/* WB2 consumer of Georg-approved Recovery r3. No renderer, clock, input or fallback owner. */
export const CURTAIN_SOURCE={commit:'7ca4a36bfeae16dfbc0e0ba99427a4da1b1c2d3e',blobSha:'87d44e2cafa85e92abc3bc6ed4ef554910d45693',issue:372,approval:'Georg PASS r3',material:'P',hardware:'pelmet'};
export async function createApprovedCurtain({renderer}){
 if(!renderer.isWebGPURenderer||typeof renderer.compute!=='function')throw Error('Approved Curtain r3 requires the existing host to support WebGPU compute. Legacy curtain and silent fallback are forbidden; receiving renderer integration remains pending.');
 const {createTheatreCurtain}=await import('./approved-curtain/kfb-curtain-core.js');
 const core=createTheatreCurtain({material:'P',hardware:'pelmet'});core.group.rotation.y=Math.PI;core.warmup(renderer,900);core.setHostFacts({loadingReady:false,selectedActorReady:false,revealAllowed:false});
 return{scene:core.group,source:CURTAIN_SOURCE,get open(){return core.openness},update(dt){core.update(renderer,dt)},setHostFacts:core.setHostFacts,setProgress:core.setFootlights,setState(state){if(state==='open')core.requestReveal();else core.cover()},snapshot(){return{source:CURTAIN_SOURCE,state:core.state,openness:core.openness}},dispose(){core.dispose();core.group.removeFromParent()}};
}

# R4 · Island Story Law und KFB-Town-Entwurfsgrundlage

Status: BINDING USER CORRECTION; räumliche Ausarbeitung unten ist WORKING DESIGN, kein neuer Town-Kanon und kein Visual PASS.
Owner: WB2 · PR #348 · chatgpt-web/wb2-convergence-golden-corridor-01-2026-10-04.
Erfasst: 2026-10-08. Technische Basis: e31005f5cca79d675d717709a38af63aaaf339e1; nachfolgende lokale Reparaturen sind noch nicht als Golden geprüft.

## Oberste Produktinvariante

Jede KFB-Insel ist ein kausal lesbares Living Diorama mit eigener Micro-Story. Ihre heutige Geografie, Siedlungsstruktur, Wege, Landmarken, Gebäude, Residents und Daily Activities müssen aus ihrer Geschichte und Funktion plausibel hervorgehen. Kein Element darf ausschließlich deshalb existieren, weil eine Acceptance-Zeile es verlangt.

Vor Szenenbau muss beantwortet sein: Warum ist diese Insel so? Wer lebt hier? Was tun sie täglich? Warum liegen Markt, Straßen, Gebäude, Landmark und Übergänge genau dort? Welche Geschichte liest der Spieler beim Durchqueren?

Ein technisch vollständiges Island ohne lesbare Micro-Story ist ein Produkt-FAIL. Ein erläuternder Text ersetzt den sichtbaren Beleg nicht. Die Verantwortung für die bisherige falsche Operationalisierung liegt beim Integrator, nicht bei Georgs Briefing.

Der eingefrorene Vertrag bleibt operationalVersion 5 mit 44 REQUIRED, 13 STRONGLY INCLUDE und 7 OPTIONAL PROOF. Dieses Gesetz streicht oder stuft keine Zeile ab und erzeugt keinen zusätzlichen Runtime-Owner. Es bindet die Zeilen zu einem Produkt. Die gefrorene Matrix bleibt unverändert.

## Quellen und Vorrang

Am 2026-10-08 aus der aktuellen GitHub-Version gelesen:
- skills/chat/town/LIVING_KFB_TOWN.md, Blob a1bb4ec94aaa5a6d0b694b4fcc4409e8f7573a61.
- skills/chat/meta/KFB_META_COMPENDIUM_v1.md, Blob a4713d2c1e2c5305d3e77e12c9272344f8d1b85b; Index, kein eigener Kanon.
- skills/chat/masterplan/KFB_META_TOWN_ADDENDUM_2026-09-14.md, Blob 1fb3e40b9cfa6da80effcb62d4644e19175777b3.

Town §12 präzisiert die älteren Abschnitte: Bewohner mit ihren packeigenen Requisiten und Tätigkeitsräumen zuerst, Architektur ergänzt die Ensembles; keine Houses-first-Pflicht, keine Hex-Assetteile für die nächste Stellprobe. Town §13 setzt die gemeinsame Bühne nahe dem Turm. Frühere Hex-Grundrissangaben legitimieren deshalb nicht die abgelehnte Medieval-Stellprobe.

Georgs aktuelle R4-Richtung ist bindend: sichtbares Joyride-Design; KFB-Town-Verteiler mit Track-Anschluss zu anderen Inseln; kompakte Dimensionierung erlaubt; Geografie muss Markt und Stadtleben ermöglichen; ausschließlich freigegebener Curtain. Die Quellenentscheidung ist am tatsächlichen isolierten Donor zu prüfen, nicht an einem geladenen URL.

## KFB Town: räumliche Arbeitshypothese vor weiterer Implementierung

Kanonischer Kern: Town ist eine gewachsene Stadt auf dem Spiel-/Basteltisch. King Kayfabian sitzt im orientierenden Turm; der Markt ist Ort für Tauschen, Schenken und Auftritte. Bewohner leben überwiegend im Freien. Die gemeinsame Showbühne liegt beim Turm. Werkzeuge haben einen Ort. Die Stadt bleibt auch ohne Spieler tätig.

R4-Ausarbeitung, ausdrücklich kein behaupteter historischer Kanon: Die Hauptstadt ist um ihren gemeinsamen Markt und den höher liegenden Turm gewachsen. Die heutigen Inselverbindungen bringen Ankommende und Weiterreisende an diesen bestehenden Ort. Die neuere Joyride-Verkehrserschließung führt am alten sozialen Zentrum vorbei. Das erklärt zwei nebeneinander lesbare Ordnungen: ein kurzer, fußläufiger Stadtweg zwischen Alltag und Bühne sowie ein befahrbarer Verteiler für Ankunft und Weiterreise.

Die Geografie muss dafür ein zusammenhängendes begehbares Stadtplateau tragen. Eine erhöhte Schulter gibt dem Turm Sicht über Markt und Bühne. Eine Randmulde führt das Wasser; die Brücke gehört an eine tatsächlich notwendige Querung. Der steilere oder unzugängliche Rand bleibt Naturraum. Hügel, Fluss und Küste werden nicht nachträglich als Dekoration in eine bereits fertige Fahrbahn gedrückt. Welche genaue Form dies erhält, ist durch Komposition und Surface-Truth-Kontakt zu belegen.

Der kompakte Verteiler liegt an der Ankunftsseite außerhalb des Aufenthaltskerns. Seine Fortsetzungen führen sichtbar zu Inselkanten und behalten echte, geprüfte Track-Sockets sowie freigehaltene Anschlusskorridore. Der Markt liegt neben dem Verteiler, nicht als unerreichbare Restfläche in seiner Mitte. Halteplatz und sichere kurze Fußverbindung machen den Übergang von Fahrt zu Stadtleben lesbar. Noch nicht verbundene Inselziele werden nicht als bereits erreichbar behauptet.

Der lokale Fahrweg verbindet Halteplatz, nutzbare Ortszugänge und Randquerung und kehrt zum Verteiler zurück. Der spielerische Joyride-Abschnitt gehört an den freien Rand; er darf den Markt nicht durchschneiden. Kein Loop wird allein durch Geschlossenheit zum sinnvollen Stadtweg.

## Bewohner als Ursachen der Anordnung

Diese Rollen und räumlichen Beziehungen werden vor Geometrie gesetzt; tatsächliche Besetzung, vorhandene Props und Clips sind anschließend quellengebunden zu prüfen:

- Der Driver empfängt Ankommende am Halteplatz, kehrt zum Fahrzeug zurück und nutzt den befahrbaren Anschluss. Darum liegt sein Tätigkeitsraum am Verteiler und am Fußweg zum Markt.
- Der Clown bereitet seinen Marktauftritt vor, tritt auf und räumt danach am selben Ort um. Sein Podium gehört an den Platzrand, wo Zuhörer stehen können und Durchgänge frei bleiben. Kein Dauerloop ohne Gegenstand oder Adressaten.
- Ein Bewohner bringt einen tatsächlich vorhandenen Gegenstand von seinem Arbeits-/Aufbewahrungsplatz zum Tauschort und wieder zurück. Quelle, Tragen, Ablage und Rückweg müssen zusammenpassen; die konkrete Figur und das Prop werden nicht als schon ausgewählt behauptet.
- Die gemeinsame Bühne beim Turm erklärt Zuschauerflächen und den Weg vom Markt. Ihr Gebrauch wechselt, statt für jede Aufführung ein weiteres Gebäude zu verlangen. King Kayfabian und Black Knight behalten ihre unterschiedlichen Rollen; keine ungeprüfte Modellbesetzung.
- Wohn-/Arbeitsfronten wenden sich zu diesen Wegen und Tätigkeiten. Joyride-Gebäude sind nicht allein durch ihren korrekten Paketnamen akzeptiert. Eingang, Maßstab, Nutzung, Freiraum und native sichtbare Material-/Formbehandlung müssen am Ensemble stimmen.

## Ohne Erklärung lesbarer Weg

Ankunft: Straßenfortsetzungen und Halteplatz erklären die Hauptstadt als Verbindungspunkt.
Zu Fuß: kurze Verbindung öffnet den Markt mit gegenstandsbezogenen Handlungen.
Im Zentrum: Bühne und sichtbarer Turm erklären öffentliche Aufführung und Autorität.
Am Rand: die Fahrroute folgt einem wirklichen Ziel und quert das Wasser an der notwendigen Stelle.
Rückkehr: Bewohner führen ihre Tätigkeit fort; der Ort wartet nicht eingefroren auf den Spieler.

Diese Beschreibung ist eine Bauhypothese. Erst die tatsächliche Welt kann sie bestätigen.

## Ausführbare Bau- und Kritikregeln

Vor Aufnahme eines Elements nennt der Integrator dessen Ursache, Gebrauch, räumliche Nachbarschaft, tatsächliche Quelle und sichtbaren Beleg. Fehlt eine dieser Beziehungen, bleibt das Element außerhalb der akzeptierten Komposition. Keine neue Runtime-Datenbank nur für diesen Nachweis.

Vor weiterem Szenenbau: diese Arbeitshypothese gegen die aktuellen Quellen und die bestehenden REQUIRED-Funktionen prüfen. Maße folgen erst aus Akteuren, realen Fahrzeugen, Gebäudeeingängen und den zusammenhängenden Aufenthaltsflächen.

F-R39-Kritik enthält zusätzlich eine unbeeinflusste Begehung ohne Story-Erklärtext. Der unabhängige Critic beschreibt aus eigener Beobachtung: Wozu dient der Ort? Wo kommen Menschen an? Was tun Bewohner? Warum führen Wege hier entlang? Was ist Zentrum, was Rand? Welche Vergangenheit oder Umnutzung ist sichtbar? Erst danach Vergleich mit der Entwurfshypothese. Nicht wiederholte Formulierungen, sondern beobachtete räumliche und zeitliche Zusammenhänge zählen.

Phase 3 beweist die räumliche Lesbarkeit und die für spätere Activities tatsächlich geeigneten Orte. Vorgesehene Handlungen zählen dort nicht als bereits laufende Residents. Nach Required Systems muss derselbe Zusammenhang durch echte Alltagsabläufe belegt sein. Der Whole-Product Critic darf technisch grüne Teilprüfungen bei fehlender Micro-Story nicht zum Produkt-PASS mitteln.

## Aktueller Befund und erhaltene Arbeit

Der bisherige Entwurf ist als gestalterische Grundlage zurückgenommen. Medieval-Hex-Häuser, dominanter Verkehrsloop und nachträglich gefüllte Freiflächen erfüllen das Gesetz nicht. Die Quellenkorrektur allein reicht ebenfalls nicht.

Erhalten bleiben technische Ergebnisse zu Dokumentidentität, Surface Truth, Ground/Drive/Flight, Track Core und belegten Donor-Adaptern, jeweils mit ihrem exakten Evidence-Head. Post-Critic-Reparaturen sind Zwischenarbeit, kein Golden. Der Approved-Curtain-Intake dokumentiert weiterhin eine offene Renderer-Kompatibilität; ein Adapter oder Import ist kein sichtbarer Curtain-PASS.

F-R39 bleibt nicht bestanden; keine Golden Baseline, keine Fortsetzung zu Phase 4. F-R07 bleibt UNKNOWN bis zum tatsächlichen Lauf auf GEORG_PRIMARY_ACCEPTANCE_MACHINE. Kein behaupteter endgültiger Outcome-Blocker und kein Neustart der erhaltenen technischen Arbeit.


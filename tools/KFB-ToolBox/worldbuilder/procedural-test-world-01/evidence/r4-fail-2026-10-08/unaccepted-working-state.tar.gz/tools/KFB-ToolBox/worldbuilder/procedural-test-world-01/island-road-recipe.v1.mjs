// Authored route intent for the bounded R4 island. All geometry compiles in Track Core.
export function islandRoadRecipe(TC){
 const graph={schema:'kfb.route-graph/0.1-draft',id:'island.r4.village-coast',defaults:{profile:{width:7.2},markings:'STREET',biome:'city',autoBank:{gain:0,limitDeg:0}},nodes:[{type:'ROUNDABOUT',id:'village.circle',center:[-35,.6,0],island:8.5,ringWidth:6.4,armWidth:8.4,fillet:6,splitter:0,armLength:9,arms:[{id:'outbound',at:90},{id:'south',at:0},{id:'north',at:180},{id:'village',at:270}]}],routes:[]};
 const sockets=TC.compileGraph(graph).sockets;
 // Native endpoint-derived adjacent-arm loop leaves south and west for island links.
 const pieces=[{id:'north.run',type:'STRAIGHT',length:12},{id:'north.bend',type:'CURVE_EASE',turn:-90,radius:22,width:7.2,bankDeg:0},{id:'coast.straight',type:'STRAIGHT',markings:'TRACK',skin:'track',length:30,width:9},{id:'east.bend',type:'CURVE_EASE',markings:'STREET',skin:'street',turn:-90,radius:22,width:7.2,bankDeg:0}];
 const probe=TC.compileGraph({...graph,routes:[{id:'coast.probe',start:{socket:'village.circle/north'},pieces}]}).routes['coast.probe'];
 const last=probe.samples.at(-1),bendProbe=TC.compileRecipe({start:{p:last.p,headingDeg:180},defaults:{profile:{width:7.2}},pieces:[{type:'CURVE_EASE',turn:-90,radius:22,width:8.4,bankDeg:0}]}),bendEnd=bendProbe.samples.at(-1);
 const southLength=bendEnd.p[2]-sockets['village.circle/village'].p[2];
 pieces.push({id:'south.run',type:'STRAIGHT',length:southLength},{id:'south.bend',type:'CURVE_EASE',turn:-90,radius:22,width:8.4,bankDeg:0},{id:'town.join',type:'CONNECT',to:'village.circle/village'});
 graph.routes.push({id:'coast.loop',start:{socket:'village.circle/north'},pieces});
 graph.extensions=[{id:'town.island-link.south',socket:'village.circle/south',state:'RESERVED',setback:2},{id:'town.island-link.west',socket:'village.circle/outbound',state:'RESERVED',setback:2}];
 graph.traversal={id:'island.r4.golden-loop',closed:true,laneOffset:2.1,parts:[{route:'village.circle.north'},{route:'coast.loop'},{route:'village.circle.village',reverse:true},{node:'village.circle',path:'village>north'}]};
 graph.islandLayout={lobes:[{xz:[-5,0],rad:66},{xz:[20,45],rad:61},{xz:[-15,55],rad:52},{xz:[0,-62],rad:52},{xz:[-35,0],rad:45}],pond:{x:10,z:35,r:4.5},waterProfile:'graded-v2',meshResolution:{angular:384,radial:160},depth:36,hills:[{x:46,z:35,r:23,h:4.5},{x:40,z:-40,r:23,h:5.5},{x:-54,z:55,r:15,h:2.7}],spawn:[-37.1,39],paletteZone:{id:'purple-grove',fromX:10,toX:34,grass:'#9a74cc',grass2:'#8a66bd',hill:'#8b66c2'},groves:[[43,35],[44,-37],[2,-86],[-62,-44],[-65,35],[2,70]],pads:[{x:5,z:-35,r:9,h:1.6},{x:-12,z:-20,r:6,h:.4},{x:-10,z:-49,r:6,h:.4},{x:15,z:-52,r:6,h:.4},{x:-16,z:-63,r:6,h:.4},{x:25,z:-22,r:6,h:.4},{x:-10,z:-34,r:3,h:.4}],plazas:[{kind:'big',x:-7,z:-34,r:9,h:.4},{kind:'small',x:-18,z:-32,r:3,h:.4}]};
 return graph;
}

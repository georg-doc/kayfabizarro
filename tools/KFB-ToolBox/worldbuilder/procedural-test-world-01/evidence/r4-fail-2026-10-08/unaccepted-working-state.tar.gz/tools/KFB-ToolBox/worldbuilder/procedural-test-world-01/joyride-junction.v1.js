/* Presentation-only bridge: Track Core owns plate, arms, kerb paths and sockets.
 * J14 owns the clay strand cross-section and curb stones. The same resulting
 * meshes are consumed by WB2 Surface Truth. No junction solver or fallback plate. */
import {createStrandProfile} from './joyride-profile.v1.mjs';
import {createJoyrideRoadMaterial} from './joyride-strand.v1.js';
import {buildJoyrideSidewalk} from './joyride-sidewalk.v1.js';
import {makeClayMaterial,seedGeometry,PROFILES} from '../../_inbox/KFB Knet-Strecke T3 v2/KFB_CLAYMATION_K2_KNET_WERKZEUGE_2026-09-28/lab-clay/clay-material.v10.js';
import {TOOLMIX} from '../../_inbox/KFB Knet-Strecke T3 v2/KFB_CLAYMATION_K2_KNET_WERKZEUGE_2026-09-28/lab-clay/clay-toolmix.v1.js';

export function buildJoyrideJunction(THREE,ST,node,paint,{U,palette}){
 const group=ST.buildNode(THREE,{...node,anchor:null},paint,new THREE.MeshStandardMaterial({vertexColors:true}));
 group.name='Track Core junction · Joyride J14 presentation';
 const clay=(color,key='road')=>makeClayMaterial(THREE,U,{src:new THREE.MeshStandardMaterial({color}),profile:{...PROFILES[key],scale:1.5,print:.3,dent:0,gouge:0,crack:0,stroke:1,facet:.9,crease:.5,legacy:0,tools:TOOLMIX.rock}});
 const road=createJoyrideRoadMaterial(THREE,U,palette);
 node.deck.zones.forEach((zone,i)=>{
  const mesh=group.children[i],geo=mesh.geometry,pos=geo.attributes.position;
  if(zone.kind==='hatch')return;
  seedGeometry(THREE,geo,37+i);
  if(zone.kind==='island'){mesh.visible=false;mesh.userData.contactExcluded=true;return;}
  const count=pos.count,su=new Float32Array(count*2);
  for(let k=0;k<count;k++){su[2*k]=pos.getX(k);su[2*k+1]=pos.getZ(k);}
  geo.setAttribute('aW',new THREE.Float32BufferAttribute(new Float32Array(count),1));
  geo.setAttribute('aBio',new THREE.Float32BufferAttribute(new Float32Array(count),1));
  geo.setAttribute('aSU',new THREE.Float32BufferAttribute(su,2));mesh.material=road;mesh.name='fahrbahn · '+zone.part;
 });
 // Replace only technical kerb presentation; native positions/normals remain authoritative.
 for(const old of group.children.slice(node.deck.zones.length,node.deck.zones.length+node.kerbs.length*2)){old.removeFromParent();old.traverse(o=>o.geometry?.dispose());}
 const lipMaterial=clay(palette.sand,'house');
 for(const kerb of node.kerbs){
  const samples=ST.kerbSamples(kerb,node.section,paint,node.biome),stream={samples};
  const nativeProfile=createStrandProfile(stream,{barrierT:()=>1,bio:()=>0});
  const positions=[],indices=[];let width=0;
  samples.forEach((q,i)=>{const section=nativeProfile.sideProfile(q,i,1);width=section.length;
   for(const [x,y] of section)positions.push(...nativeProfile.W3(q,x,y));
   if(i)for(let k=0;k<width-1;k++){const a=(i-1)*width+k,b=i*width+k;indices.push(a,a+1,b,a+1,b+1,b);}
  });
  const geometry=new THREE.BufferGeometry();geometry.setAttribute('position',new THREE.Float32BufferAttribute(positions,3));geometry.setIndex(indices);geometry.computeVertexNormals();seedGeometry(THREE,geometry,73);
  const lip=new THREE.Mesh(geometry,lipMaterial);lip.name='J14 clay kerb · '+kerb.id;group.add(lip);
  group.add(buildJoyrideSidewalk(stream,U,{sides:[1],rows:0}));
 }
 group.userData.sourceRecord={assetId:'Track Core junction / Joyride J14 kerb',packId:'KFB Joyride J14',source:{commit:'927a1b4bd2d1de6cf0479414e2e8ac1cb9d6509f',path:'tools/KFB-ToolBox/_inbox/KFB_JOYRIDE_J14_CLAUDE_DESIGN_SESSION_CUT_2026-09-30_r1/lab-track/track-look.v5.js'},construction:'Track Core v0.12 node deck / kerbs / sockets'};
 return group;
}

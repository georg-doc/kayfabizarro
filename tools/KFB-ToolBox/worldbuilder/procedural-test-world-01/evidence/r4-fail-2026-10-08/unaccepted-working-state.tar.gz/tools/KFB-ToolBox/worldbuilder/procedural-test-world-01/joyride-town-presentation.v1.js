/* Source-derived presentation consumer, not an asset loader or second world owner.
 * J14 joyride-drive.j09.js lines 77–94 + transition-atlas.v1.js geoOf:
 * H0 per source part, uniform 4.1 scale, K1 v8 house, source UV/palette preserved.
 * WB2 Registry supplies loaded source objects; WB2 owns placement and contacts. */
import * as THREE from 'three';
import {softenGeometry} from '../../_inbox/KFB_JOYRIDE_J14_CLAUDE_DESIGN_SESSION_CUT_2026-09-30_r1/lab-clay/clay-soften.v1.js';
import * as K1 from '../../_inbox/KFB_JOYRIDE_J14_CLAUDE_DESIGN_SESSION_CUT_2026-09-30_r1/lab-clay/clay-material.v8.js';
import {makeClayRelief} from '../../_inbox/KFB_JOYRIDE_J14_CLAUDE_DESIGN_SESSION_CUT_2026-09-30_r1/lab-clay/clay-relief.v2.js';
const BASE=new URL('../../_inbox/KFB_JOYRIDE_J14_CLAUDE_DESIGN_SESSION_CUT_2026-09-30_r1/',import.meta.url);
let context;
async function houseContext(loadRegistered,reference){
 if(!context)context=(async()=>{
  const [source,config]=await Promise.all([loadRegistered(reference),fetch(new URL('lab-drive/joyride.j06.json',BASE)).then(r=>{if(!r.ok)throw Error('Joyride facade contract missing');return r.json()})]);
  const nativeHeight=new THREE.Box3().setFromObject(source).getSize(new THREE.Vector3()).y,hk=nativeHeight*4.1/config.facade.k1.refHeight;
  const relief=makeClayRelief({size:1024,seed:11}),texture=new THREE.DataTexture(relief.data,relief.size,relief.size,THREE.RGBAFormat);texture.wrapS=texture.wrapT=THREE.RepeatWrapping;texture.magFilter=THREE.LinearFilter;texture.minFilter=THREE.LinearMipmapLinearFilter;texture.generateMipmaps=true;texture.needsUpdate=true;
  const U=K1.makeClayUniforms(THREE,texture);
  // Repository packet stores the unchanged PNG as three binary parts; no substitute texture.
  const parts=await Promise.all(['01','02','03'].map(n=>fetch(new URL('ref/clay-joebinns/Fingerprints01_3K.png.part'+n,BASE)).then(r=>{if(!r.ok)throw Error('Joyride fingerprint source part missing');return r.arrayBuffer()})));
  const url=URL.createObjectURL(new Blob(parts,{type:'image/png'}));try{U.uClayPrint.value=await K1.makePrintTexture(THREE,url,2048);U.uClayPrintOn.value=1;}finally{URL.revokeObjectURL(url)}
  U.uClayHand.value=.5*hk;U.uClayTile.value=1.6*hk;U.uClayPrintTile.value=4.5*hk;if(U.uClayFacetSize)U.uClayFacetSize.value=.65*hk;
  return{U,hk,options:config.facade.h0};
 })();return context;
}
export async function adaptJoyrideHouse(root,reference,loadRegistered,seed=4000){
 const {U,hk,options}=await houseContext(loadRegistered,reference),parts=[];root.updateMatrixWorld(true);
 root.traverse(o=>{if(!o.isMesh)return;let raw=o.geometry.clone();raw.applyMatrix4(o.matrixWorld);if(raw.index)raw=raw.toNonIndexed();
  const result=softenGeometry(THREE,raw,options),geometry=result.geometry;K1.seedGeometry(THREE,geometry,seed++);
  const src=Array.isArray(o.material)?o.material[0]:o.material,material=K1.makeClayMaterial(THREE,U,{src,profile:'house',scale:.5*hk}),mesh=new THREE.Mesh(geometry,material);mesh.name=o.name;mesh.castShadow=mesh.receiveShadow=true;parts.push(mesh);
 });
 root.clear();root.position.set(0,0,0);root.rotation.set(0,0,0);root.scale.setScalar(1);root.add(...parts);root.updateMatrixWorld(true);
 const box=new THREE.Box3().setFromObject(root),c=box.getCenter(new THREE.Vector3());for(const mesh of parts)mesh.geometry.translate(-c.x,-box.min.y,-c.z);
 root.userData.joyridePresentation={owner:'Joyride J14 K1/H0 facade',sourcePin:'927a1b4bd2d1de6cf0479414e2e8ac1cb9d6509f',houseK1:true,uniformSourceScale:4.1,material:'clay-material.v8 / house',h0:options,fingerprint:'native J14 PNG assembled from exact binary parts'};
 return root;
}

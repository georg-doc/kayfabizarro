import test from 'node:test';import assert from 'node:assert/strict';
import * as TC from '../../procedural-test-world-01/open-world/src/owners/track-core/track-core.mjs';
import {compileTraversal} from '../../procedural-test-world-01/open-world/src/owners/track-core/traversal.mjs';
import {islandRoadRecipe} from '../../procedural-test-world-01/island-road-recipe.v1.mjs';
import {makeIslandCore} from '../../procedural-test-world-01/r2d-island-core.v1.js';
import {islandRecipe,validateIslandRecipe} from '../island-document.v1.mjs';
test('native roundabout and connected coastal route pass Track Core geometry gates',()=>{const r=islandRoadRecipe(TC),g=TC.compileGraph(r),c=TC.runGraphChecks(g);assert.equal(c.pass,true,JSON.stringify(c));assert.equal(g.nodes.length,1);assert.equal(g.nodes[0].kind,'roundabout');assert.ok(c.results.find(r=>r.id.startsWith('node_clear')).pass);});
test('closed drive traversal preserves native graph seams and an upright orthonormal frame',()=>{const r=islandRoadRecipe(TC),g=TC.compileGraph(r),t=compileTraversal(g,r.traversal.parts,r.traversal);assert.deepEqual(t.samples[0].p,t.samples.at(-1).p);assert.ok(t.samples.at(-1).s>300);for(const q of t.samples){assert.ok(q.U[1]>.999);for(const a of [q.T,q.R,q.U])assert.ok(Math.abs(Math.hypot(...a)-1)<1e-6);assert.ok(Math.abs(q.T.reduce((s,x,i)=>s+x*q.R[i],0))<1e-6);}assert.throws(()=>compileTraversal(g,[{route:'coast.loop'},{node:'village.circle',path:'south>north'}],{closed:true}));});
test('fresh island replays complete graph, physical path and authored outline with stable segment identities',()=>{const route=islandRoadRecipe(TC),doc=islandRecipe({id:'road-proof',seed:3,shape:'frei',biome:'burg',route}),fresh=validateIslandRecipe(JSON.parse(JSON.stringify(doc))),a=makeIslandCore(3,TC,'frei',doc.route),b=makeIslandCore(3,TC,'frei',fresh.route);assert.deepEqual(a.plan.graph,b.plan.graph);assert.deepEqual(a.plan.stream,b.plan.stream);assert.deepEqual(a.plan.pads,b.plan.pads);for(const q of a.plan.stream.samples){assert.ok(a.plan.sdf(q.p[0],q.p[2])<-10);assert.equal(a.field.heightAt(q.p[0],q.p[2]),b.field.heightAt(q.p[0],q.p[2]));}});

test('authored river descends continuously through the crossing and stays above its carved bed',()=>{const core=makeIslandCore(3,TC,'frei',islandRoadRecipe(TC)),C=core.plan.creek;assert.ok(C?.cross);assert.equal(typeof C.waterAt,'function');let prior=Infinity;for(const p of C.pts.slice(0,C.lip.i+1)){const y=C.waterAt(...p);assert.ok(y<=prior+1e-8);assert.ok(core.field.heightAt(...p)<y-.2);prior=y;}assert.ok(C.waterAt(...C.cross)<core.plan.roadY-.5);});

test('Town distributor reserves two unobstructed native island-link sockets',()=>{
 const recipe=islandRoadRecipe(TC),core=makeIslandCore(3,TC,'frei',recipe),P=core.plan;
 assert.equal(P.reservedCorridors.length,2);
 for(const c of P.reservedCorridors){
  const socket=P.graph.sockets[c.socket];assert.ok(c.width>=socket.width+2*TC.SIDE_EXTENT+4);
  assert.ok(P.sdf(c.position[0]+c.direction[0]*c.length,c.position[2]+c.direction[2]*c.length)>=2);
  // The real Track Core can continue each socket; no placeholder connection metadata.
  const extended=TC.compileGraph({...recipe,routes:[...recipe.routes,{id:c.id,start:{socket:c.socket},pieces:[{type:'STRAIGHT',length:c.length}]}]});
  assert.deepEqual(extended.routes[c.id].samples[0].p,socket.p);
  assert.ok(TC.runGraphChecks(extended).pass);
 }
});

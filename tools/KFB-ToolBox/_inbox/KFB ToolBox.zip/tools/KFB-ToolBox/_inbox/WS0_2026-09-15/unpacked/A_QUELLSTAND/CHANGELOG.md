# Changelog · WS0_TOOLBOX_SOURCE_REFRESH
*additiv, neueste Zeile oben.*

2026-09-15 · **Paket erzeugt.** Ergebnis A: Identität der lokalen Baseline gegen Commit
`525288d67a9fdfd94caacf19e47b4ba333dc1ca2` per Git-Blob-Hash belegt (30/32 bytegleich, 2 = v3.1).
Delta ermittelt: **0** von 30 v3-Modulen seit dem Pin geändert, **52** Workspace-Dateien ohne
Gegenstück, **60** erreichbare Module, **0** fehlende Modul-Referenzen. 87 Dateien in
Originalstruktur nach `src/` (Paket gesamt 101 Dateien, 3,33 MB). Kaltstart aus `src/` gemessen: Rigging Lab und Animation Lab
**0 Ausfälle**, Studio **3** — dieselben drei wie in der Authoring-Quelle. R1 am Quelltext
verifiziert, nicht neu repariert. Georgs Sitzungsspeicher nachweislich unverändert.

2026-09-15 · **Nicht getan:** kein UI-Rework (Ergebnis B), keine Feldabdeckungstabelle, keine
Messung der vier Prüfgrößen, kein Repo-Schreibvorgang, keine Schriftdateien im Paket.

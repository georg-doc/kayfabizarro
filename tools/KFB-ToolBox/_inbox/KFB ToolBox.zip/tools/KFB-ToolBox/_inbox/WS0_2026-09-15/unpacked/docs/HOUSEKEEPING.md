# HOUSEKEEPING · Stand 15.09.2026

Status je Artefakt: AKTIV · FROZEN · SUPERSEDED · DEAD · ASSET

## Blätter
- `KFB ToolBox Pilot v1.dc.html` — **AKTIV** (neu 15.09.). Gemeinsame Hülle, Ergebnis B.
  Baut **nichts selbst**: `mountCarl` · `mountGraft` · `faceMods()`. Ersetzt kein Werkzeug.
- `KFB FrankenStein Studio v17.dc.html` — **AKTIV**, 15.09. geändert (LIBRARY-MISSING-Streifen).
  v16 → **SUPERSEDED** (Referenz bleibt liegen).
- `KFB Rigging Lab v1.dc.html` — **AKTIV**. ⚠ Zeigt Carl **sandfarben** aus der Werkbanksitzung
  `kfb.carl.rig.v6.3`. Das ist ein **lokaler Entwurf**, nicht der ausgelieferte Look (s. u.).
- `KFB Animation Lab v3.dc.html` — **AKTIV**. v2 → **SUPERSEDED**, v1 → **FROZEN** (Referenz).
- `KFB Recherchi Lab v1.dc.html`, `KFB Vergleich Graft vs Carl v1.dc.html` — **AKTIV** (Prüfmittel).
- `KFB FrizzleDummy Lab v1.dc.html`, `KFB Mech & Vehicle Rig v1/v2.dc.html` — **AKTIV**, diese
  Sitzung nicht geändert.
- `petstudio-v9/KFB FrankenStein Studio v15/v16.dc.html`, `KFB FrizzleBob Studio v14.dc.html` —
  **SUPERSEDED**, Referenzkopien.

## Entschieden 15.09. · eine Wahrheit für Carls Look
**Der Vertrag gewinnt.** `petstudio-v9/kfb-pet-capsule-carl.json` färbt »capsule (body)« auf
DocCheck-Rot `#c03`. Die Werkbanksitzung `kfb.carl.rig.v6.3` ist ein **Entwurf** und darf den
Vertrag im Authoring überstimmen, **nie in einem Consumer-Paket**. Georgs Sitzung wurde **nicht**
angeglichen — eine Entscheidung löscht keinen Entwurf.

## Geteilte Module (mehrfach importiert — NICHT als tot einstufen)
- `petstudio-v9/studio-v7/pet-session.v1.js` — Studio **und** Animation Lab.
- `lab-v4/carlrig.js` · `lab-v2/audit.js` — Rigging Lab **und** Studio (über `carlrig-mount.v1.js`)
  **und** `frizzlegraft-v1/recherchi-mount.v1.js`.
- `frizzlegraft-v1/{actor-wobble,actor-color}.v1.js` — Rigging Lab **und** Studio.
- `lab-v6/facegraft.v1.js` — Rigging Lab **und** Studio.
- `petstudio-v9/studio-v3/pet-mouth.v1.js` · `studio-v12/{pet-eye-rig.v6,brow-rig.v2,pet-nose.v2,pet-moustache.v1}.js`
  — Studio, Rigging Lab, Dummy Lab, beide Leser **und** der Pilot. Die am breitesten geteilten Dateien im Projekt.
- **Neu geteilt seit 15.09.:** `frizzlegraft-v1/graft-mount.v1.js` und `lab-v6/carlrig-mount.v1.js`
  werden jetzt auch vom **Piloten** importiert. Drei Verbraucher je Leser.

## Neu diese Sitzung
- **Deliverables:** `KFB ToolBox Pilot v1.dc.html` (AKTIV) ·
  `export/WS0_TOOLBOX_SOURCE_REFRESH_2026-09-15/qa/Start und Vergleich.dc.html` (AKTIV, Startseite A).
- **Docs:** `KRITIK_UX_CARL_WEG_v1.md` · `BERICHT_UI_PILOT_v1.md` · im A-Paket `RETURN.md` ·
  `DELTA.md` · `DELTA_FOLGE_01.md` · `CHANGELOG.md` · `qa/QA_2026-09-15.md` (alle AKTIV).
- **Integrität:** `MANIFEST.json` · `CHECKSUMS.sha256` (ASSET, zuletzt erzeugt).
- **Captures:** vier Kaltstart-Aufnahmen in `qa/` (ASSET, je unter 40 kB).
- **Keine Verträge geändert.** Kein Modul geändert. Ein Blatt geändert (Studio v17).

## Bekannte Lücken, nicht behoben — alle drei auch in der Quelle
1. `petstudio-v9/studio-v3/PET_EDITOR/pet-LIBRARY.json` fehlt → keine Emotes, kein Gesichts-Block.
   **Seit 15.09. nicht mehr stumm** (Streifen im Studio). Entscheidung (c): so lassen, sichtbar machen.
2. **18 `@font-face`-Regeln** auf ein `fonts/`-Verzeichnis, das es nicht gibt. **Absichtlich** nicht
   im Übergabepaket (Auftrag §4); `font-display:swap` trägt. Für WSA: Dateien nachreichen **oder**
   die Referenzen auf Web-Fonts umstellen — eine Entscheidung, kein Fehler.
3. `petstudio-v9/kfb-pinball-sfx.json` fehlt → Klangbank **ungeprüft** (lazy, erst beim Klick).

## Clean-Run-Checkliste
1. `src/` über **HTTP** ausliefern (`file://` trägt nicht — ES-Module).
2. **Ordnerstruktur nicht umsortieren.** Studio v17 setzt `__KFB_MODBASE = petstudio-v9/` und lädt
   `./studio-v7/…` **und** `../lab-v6/…`.
3. Konsole prüfen: Rigging Lab und Animation Lab müssen **0** HTTP-Ausfälle zeigen, Studio **3**
   (die drei oben). Mehr heißt: eine Datei fehlt im Export.
4. ⚠ **Vor jedem Standbild selbst rendern** — im verborgenen Vorschaufenster parkt die Bildschleife.
5. ⚠ **Eine Messung darf nichts speichern.** Alles mit `save`, `_touchPet`, `_ensureInLib` schreibt
   in Georgs Sitzung. Der Pilot hat einen **eigenen** Schlüssel `kfb-toolbox-pilot-v1` und ist
   deshalb für Messungen unbedenklich.
6. ⚠ Das GitHub-Baumwerkzeug **verbirgt `.glb` und `.gltf`** in diesem Repo. Direkt lesen entscheidet.

## Aufräum-Kandidaten (nur benannt, nichts ausgeführt — Freigabe nötig, jeder Schritt einzeln)
| Kandidat | Größe | Empfehlung |
|---|---|---|
| `export/KFB-session-2026-09-12/` · `export/KFB-v16/` · `export/WSA_2026-09-12/` · `export/WSA_2026-09-13/` | ältere Bündel | **raus** — durch `WS0_TOOLBOX_SOURCE_REFRESH_2026-09-15/` abgelöst |
| `petstudio-v9/KFB FrankenStein Studio v15/v16.dc.html` · `KFB FrizzleBob Studio v14.dc.html` | ~1,6 MB | **raus**, wenn die Wurzelkopien bleiben |
| `KFB Animation Lab v1/v2.dc.html` · `KFB FrankenStein Studio v15.dc.html` (Wurzel) | ~0,7 MB | v2 raus, **v1 behalten** (FROZEN, bewusst uncluttered) |
| `uploads/*` | viele Duplikate (`kfb-pet-graft-driver (1..4).json`) | **raus** — nie Quelle, nur Spiegel |
| `petstudio-v9/assets/models/FrizzleBob_Yellow.gltf` | 608 kB | **behalten**, bis der RAW-Weg steht: die Datei liegt am Pin `525288d6`, also **kann** sie per URL kommen |
| `LIVING_frizzlegraft.md` | 167 kB | **behalten** — additiv, neueste Zeile oben; das ist der Zweck |

## Pfad-Hygiene
Geprüft: alle Modell-, Clip- und Texturpfade laufen über
`raw.githubusercontent.com/georg-doc/kayfabizarro/…`. **Eine** lokale Ausnahme mit Absicht:
`frizzlegraft-v1/kfb-card-backside.png` (256 kB, kopiert statt verlinkt — ein Blatt, das aus dem Netz
nachlädt, ist beim nächsten Ausfall ein leeres Blatt) und das Spendermodell oben.
⚠ **Alle `@main`-Pfade sind beweglich.** Ein gepinnter Modulimport pinnt die Daten nicht mit.

# QA-Belege dieses Jobs · Verzeichnis und Pin
*15.09.2026 · WSA. Diese Datei pinnt die sieben Kaltstartbilder über sha256, damit die
Feldabdeckungsmatrix und `RETURN_WSA.md` auf identifizierbare Belege zeigen — auch dort, wo die
Bilddateien selbst (noch) nicht im Repo liegen.*

## Textbelege (im Repo gesichert)

| Datei | Bytes | sha256 |
|---|---|---|
| `checksums-wsa.json` | 250 | `4f46265d3e5d20770e8371f32d2ad2d6b6b84290e895a510b46a4276b7cc7e1e` |
| `closure-wsa.json` | 19 748 | `530c419a8bc143e4a58d9f68d589489f04ba6fde81c23786101ca25d9c905f2d` |
| `field-coverage-wsa.json` | 9 859 | `e7e13d98922e4bc0414e2317e738c0cdc596fd32b36564c52d8007a4e52dec2c` |
| `fields-wsa.json` | 1 063 | `29feb1e209213e9fd1c15ab5d3864c371f339d0670fea2bf9aa1a058b43f6620` |
| `identity-wsa.json` | 7 753 | `7729e836d7ee7129d7f6e8b937f9a718ee0a5704aca3ccdee1ca55c01c0c0662` |

## Kaltstartbilder · 15.09.2026 · Chromium über HTTP, 924×540

Alle sieben zeigen Oberfläche **und** 3D-Inhalt; Beurteilung in `RETURN_WSA.md` · TESTED RESULT.

| Datei | Blatt | Bytes | sha256 |
|---|---|---|---|
| `coldstart-studio-wsa.png` | FrankenStein Studio v17 | 40 272 | `8022cbb6248b8a55e420632ddc41c0706bdd6dfa5578aacd6321f44e881742c3` |
| `coldstart-rigging-wsa.png` | Rigging Lab v1 | 31 882 | `bfe404102b0534e282dfe3f0920d1e79a3c622bca169591d531b2caaab1af12e` |
| `coldstart-animlab-wsa.png` | Animation Lab v3 | 37 366 | `76a4912107fba498e7386931c152ef5fefdebac8f8a754d61f352bea5b58d92c` |
| `coldstart-recherchi-wsa.png` | Recherchi Lab v1 | 26 647 | `6800967739bef43d54a5361b3262331ab4aaf1be3b88cbe917dff02fc7d4b0ad` |
| `coldstart-vergleich-wsa.png` | Vergleich Graft vs Carl v1 | 30 154 | `64d166437f5679a71ed7e05d9019af1cd1a615b1f558ed9c268feb36efc80271` |
| `coldstart-frizzledummy-wsa.png` | FrizzleDummy Lab v1 | 36 504 | `05b6ca4a2ebc494ff0252cf718dd157c9cbc55cce2e0db4603204810c3d00470` |
| `coldstart-mechrig-wsa.png` | Mech and Vehicle Rig v2 | 34 420 | `f120df9981f5da166ef32fbb4430d789aec358ad24da5263338ff7f8f5b902db` |

**SOURCE FACT · Werkzeuggrenze.** Der Schreibweg dieser Arbeitsumgebung überträgt Dateien als Text.
Die sieben PNG sind Binärdateien und sind über diesen Weg **nicht** übertragbar — sie liegen im
lokalen Jobordner und sind hier über Bytes und sha256 gepinnt. Nachzuziehen mit einem gewöhnlichen
`git add tools/KFB-ToolBox/_inbox/WS0_2026-09-15/qa-wsa/*.png` aus dem lokalen Ordner. Keine
Plattform- oder Rechteaussage, nur diese Grenze.

## Was diese Belege **nicht** zeigen

Kein Laufzeitmitschnitt von `report.applied[]` / `report.rejected[]` aus einem echten
`mountCarl`-Aufruf (WS0s Prüfseite, offen) · kein Rundlauf Export/Import · keine Bedienung
(Mods, Talk, Blick) · keine der vier Prüfgrößen (gehört zu Ergebnis B) · kein Klang.
Die Zeilen `seat` und `cardRider` der Matrix stehen deshalb als `NOT_MEASURED` und sind nicht als
grün gezählt.

# Rückgabe WS0 · Ergebnis A · Quellstand, Delta, Kaltstart
*15.09.2026 · Antwort auf `AUFTRAG_WS0_DELTA_EXPORT.md` · Referenz `georg-doc/kayfabizarro@525288d67a9fdfd94caacf19e47b4ba333dc1ca2`,
Unterbaum `tools/KFB-ToolBox/kfb-rigs-embed-v3/`. Nur Ergebnis A. B ist nicht angefangen.*

## In einem Satz
**Kein einziges der 30 Module von Rig-Embed v3 ist seit dem gepinnten Commit angefaßt worden** —
der ganze Fortschritt der Werkstatt liegt in 52 Dateien und 7 Blättern, die v3 nie enthielt; das
Paket in `src/` startet aus dem leeren Ordner und zeigt dieselbe Figur wie die Authoring-Quelle.

## Was hier drin liegt
| Lieferung | Inhalt |
|---|---|
| `src/` | **87 Dateien** in der **Originalstruktur** (Pflicht, die Blätter lösen relativ auf) — 7 Einstiege, 60 erreichbare Module, 6 Verträge, 1 Spendermodell, Design-System-Bündel |
| `DELTA.md` | Datei- und Fähigkeitsvergleich gegen den Pin, je Datei mit Hash und Grund |
| `MANIFEST.json` | Einstiege, lokale Dateien mit sha256, externe Laufzeitdaten mit URL und Pin-Zustand |
| `qa/` | Startseite `Start und Vergleich.dc.html`, Kaltstartbericht, vier Aufnahmen, Rohdaten der Messungen |
| `CHANGELOG.md` · `CHECKSUMS.sha256` | additiv; Prüfsummen zuletzt erzeugt |

**Paketumfang:** 101 gezählte Dateien · 3,33 MB (`MANIFEST.json` und `CHECKSUMS.sha256` zählen sich selbst nicht mit).
Alle Zahlen dieses Berichts sind aus `MANIFEST.json` abgeleitet.

## Startweg
Entpacken, `src/` über **HTTP** ausliefern (kein `file://` — die Blätter laden ES-Module),
dann eines der Blätter öffnen. Kein Build, kein Paketmanager, keine Installation.

    src/KFB FrankenStein Studio v17.dc.html      vier Bewohner · Materialzonen · Anim-Reiter
    src/KFB Rigging Lab v1.dc.html               CapsuleCarl-Werkbank · 21 Zonen
    src/KFB Animation Lab v3.dc.html             Vertrag als Figurenquelle · Clips · Waffenanker
    src/KFB Recherchi Lab v1.dc.html             Würfel mit sechs bedienbaren Flächen
    src/KFB Vergleich Graft vs Carl v1.dc.html   Zwei-Figuren-Probe
    src/KFB FrizzleDummy Lab v1.dc.html          Messbank Wirtsfiguren
    src/KFB Mech & Vehicle Rig v2.dc.html        Sockel · Rover · Wanne

**Zwei Leser, eine Reihenfolge** — daran nichts vorbei bauen:
`frizzlegraft-v1/graft-mount.v1.js#mountGraft` · `lab-v6/carlrig-mount.v1.js#mountCarl`.

## Identität der Baseline — belegt, nicht angenommen
Verfahren: **Git-Blob-Hash** jeder lokalen Datei nachgerechnet (`sha1("blob "+len+"\0"+inhalt)`) und
gegen die Blob-Hashes des gepinnten Commits gestellt. Rohdaten: `qa/identity-raw.json`.

- **30 von 32** baumsichtbaren Dateien **bytegleich** mit dem Pin.
- **2 abweichend — genau die beiden angekündigten Austauschdateien (v3.1):**
  `EMBED_KFB_RIGS_v3.md` (Pin 12 516 B → lokal 17 791 B) ·
  `lab-v6/carlrig-mount.v1.js` (Pin 5 716 B → lokal 9 780 B, enthält den R1-Fix).
- `petstudio-v9/assets/models/FrizzleBob_Yellow.gltf` **liegt am Pin** (608 342 B, byte- und
  größengleich). ⚠ Das GitHub-Baumwerkzeug **verbirgt sie** — wer dem Baum glaubt, hält den
  Ordner für leer. Dieselbe Falle wie bei den `.glb` (steht in `github.md`).
- `kfb-rigs-embed-v3.manifest.json` und `REVIEW_ANTWORT_v3.1.md` liegen **nicht** am Pin —
  sie sind lokal entstanden und im Repo nachzuziehen.

**Befund, der einen Fehlschluß verhindert:** die Byte-Angaben *im* Manifest sind durchgehend
kleiner als Pin und lokale Datei (z. B. 12 315 statt 12 516 · 9 731 statt 9 780 · 30 142 statt
30 150). Das Manifest ist damit **kein Identitätsanker**; nur Blob- oder sha256-Hashes sind einer.

**Antwort auf die Vorgabe:** die lokale `export/`-Fassung ist als Baseline zulässig, aber nur als
*Pin plus zwei bekannte Austauschdateien*. Maßgeblich bleibt der Commit.

## Delta in einem Blick
| Gruppe | Zahl | Bedeutung |
|---|---|---|
| v3-Module, seit dem Pin **geändert** | **0** | keine stille Weiterentwicklung im Inneren von v3 |
| v3-Module, bytegleich zum Pin | 29 | |
| v3-Module gleich der v3.1-Kopie | 1 | `lab-v6/carlrig-mount.v1.js` |
| Workspace-Dateien **ohne Gegenstück in v3** | **52** | hier sitzt der ganze Zugewinn |
| erreichbare Module (transitiv, 7 Einstiege) | 60 | |
| **fehlende Modul-Referenzen** | **0** | der Baum ist geschlossen |

Die Fähigkeiten dahinter stehen in `DELTA.md` §2. Kurz: Recherchi als vierte Bewohnerklasse,
Animation-Lab-Linie (Vertrag · Karte · Prüfung), Carl-Farb- und Oberflächenzonen, Kartenreiter,
Sockel und Wanne, gepinnte Quellenliste.

## Kaltstart im leeren Ordner — gemessen
Drei Blätter **allein aus `src/`** geladen, ohne Nachbarn der Authoring-Quelle. Bericht `qa/QA_2026-09-15.md`.

| Blatt | HTTP ≥ 400 | Bild |
|---|---|---|
| Studio v17 | **3** (siehe unten) | Figur auf der Karte, Skydome, Gesicht, Waffe · Leinwand 1848 × 880 |
| Rigging Lab v1 | **0** | CapsuleCarl mit Georgs gespeicherter Kalibrierung, 66 Bedienelemente |
| Animation Lab v3 | **0** | Monstrosity spielt `Running_A`, Roster und Zeitleiste vollständig |

**Die drei Ausfälle sind keine Exportlücke.** Dieselben drei, mit denselben Pfaden, treten in der
**Authoring-Quelle** auf (`qa/` Gegenprobe). Der Export hat nichts verloren:
1. `petstudio-v9/studio-v3/PET_EDITOR/pet-LIBRARY.json` — existiert im Workspace **überhaupt nicht**.
   Folge: der Bibliotheks-Block (Emotes, Gesichtsvorgaben) ist leer. Die 25 Figuren kommen aus
   `lab-v2/sources.js` (Repo v1.2.8 + 1 Entwurf) und sind vollständig. ⚠ Der Ausfall ist **stumm** —
   kein Hinweis auf der Oberfläche. Das ist ein Punkt für B.
2. `fonts/Bangers-Regular.ttf` · `fonts/FonteysPRO-Heavy.otf` — **18 `@font-face`-Regeln** zeigen auf
   ein `fonts/`-Verzeichnis, das es nicht gibt. **Absichtlich nicht mitgeliefert** (Auftrag §4:
   keine Fontdateien in Übergabepakete). `font-display:swap` trägt, das Bild bleibt heil.
3. `kfb-pinball-sfx.json` — nicht vorhanden; wird erst beim ersten Klick geholt, deshalb im
   Kaltstart nicht aufgetaucht. **Ungeprüft**, nicht »in Ordnung«.

## Drei Belege, getrennt gehalten
**1 · Daten erhalten.** Verträge bytegleich im Paket, Blattfelder gezählt:
`kfb-pet-graft-driver.v4.json` **591** · `kfb-pet-graft-driver-default.json` **589** ·
`kfb-pet-capsule-carl.json` **166** · `kfb-pet-recherchi.json` **52** ·
`kfb-carl-rig-default.json` **99** (`kfb.carl.rig/6`) · `kfb-pets.json` **865** (24 Einträge).

**2 · Felder angewandt.** **Am Quelltext verifiziert, nicht neu reparieret** (Auftrag: bereits
behobene Stellen nur prüfen). `PartRig.set()` bricht beim **ersten** unbekannten Feld ab und gibt
`{status:'UNSUPPORTED', field, reason}` zurück; `DEFAULTS` sind genau die sechs erlaubten Felder
`enabled · scale · spread · lift · depth · tilt`. Der Aufrufer filtert **positiv**
(`only(src, PART_FIELDS)`), wertet den Rückgabestatus aus und führt `applied[]`/`rejected[]`.
Die Sichtbarkeit entscheidet der **Mode**, nicht `original.enabled`.
**Beobachtet:** im Kaltstart steht Carl mit Nicht-Standardwerten (Spacing 0,226 · Height 0,312 ·
Eye size 0,140 · Lid fit 0,92 · Lash length 0,45) — Georgs Kalibrierung kommt an.
⚠ **Noch nicht geliefert:** eine Abdeckungstabelle Feld → angewandt/nicht unterstützt über
*alle* Kanäle (Augenfarben, Schnurrbart, Mund-Set, Visemes, Materialzonen). Nächster Schritt
unten benannt.

**3 · Sichtbar gleich.** Studio v17 aus `src/` und aus der Authoring-Quelle nebeneinander
(`qa/coldstart-studio.png` · `qa/live-studio.png`): gleiches Bild, **gleicher Startbericht**
(`repo v1.2.8 → 25 pets · 1 Entwurf`), gleiche Meßzahlen (Maßstab 0,516 · Kopf 1500 Dreiecke ·
765/2293 Punkte), gleiche drei Ausfälle.

## Was die Messung nicht angefaßt hat
Vor dem Kaltstart wurde Georgs Sitzungsspeicher gesichert, danach geprüft:
`kfb-lab-v2:ui` · `kfb.carl.rig.v6.3` · `kfb-pet-studio-v5` **alle drei unverändert**, keine neuen
Schlüssel. Es wurde nichts gespeichert und nichts gelöscht.

## Bewußt nicht im Paket
Blätter älterer Fassungen (Studio v15, Animation Lab v1/v2, die drei `.dc.html`-Kopien in
`petstudio-v9/`), Mech Rig v1, Bilderhalden und frühere Abgabeordner. Schriftdateien (s. o.).
Nichts davon wird gelöscht — es bleibt beim WS0 und ist History.

## Drei nächste Schritte
1. **Feldabdeckung nachliefern:** eine Prüfseite in `qa/`, die `mountCarl` und `mountGraft` mit
   Georgs Verträgen aufruft und `applied[]`/`rejected[]` je Kanal ausschreibt. Das schließt Beleg 2.
2. **`pet-LIBRARY.json` entscheiden:** Datei beibringen oder den stummen Ausfall zu einer
   sichtbaren Meldung machen. Betrifft Emotes und den Gesichts-Block.
3. **Zwei Dateien im Repo nachziehen** (`kfb-rigs-embed-v3.manifest.json`,
   `REVIEW_ANTWORT_v3.1.md`) und die beiden v3.1-Austauschdateien einspielen.

## Eine Entscheidung liegt bei Georg
**Woher kommt `pet-LIBRARY.json`?** Drei Wege:
**(a)** Datei aus dem Repo nachladen (`media/3D_Assets/pet-LIBRARY.json` ist im Blatt als
`CANON_URL` schon benannt) — dann trägt das Paket eine Netzabhängigkeit mehr.
**(b)** Datei ins Paket legen — dann muß sie einmal erzeugt werden.
**(c) ⟵ Empfehlung:** so lassen, aber den stummen Ausfall sichtbar machen; die 25 Figuren kommen
ohnehin aus `sources.js`, gefehlt haben nur Emotes und Gesichtsvorgaben.

# Folge-Delta 01 · nach der Abnahme von A
*15.09.2026 · Eine Änderung, entstanden **nach** dem Snapshot. Der Inhalt von `src/` bleibt die
abgenommene Baseline und ist **nicht** angefaßt — so bleiben gesicherter Stand und spätere
Änderung unterscheidbar (Auftrag §2 und §6).*

## Die Änderung
**Georgs Entscheidung (c) zur offenen Frage aus `RETURN.md`:** `pet-LIBRARY.json` bleibt fehlend,
aber der stumme Ausfall bekommt eine Stimme.

| | |
|---|---|
| Datei | `KFB FrankenStein Studio v17.dc.html` (Authoring-Quelle im Workspace) |
| Stand in `src/` | unverändert — zeigt den abgenommenen Zustand **ohne** Hinweis |
| Art | Sichtbarkeit, keine neue Rig- oder Materialwahrheit |

## Warum der Ausfall stumm war — gemessen, nicht vermutet
Der `catch` setzte schon vorher `status`. **Nur rendert die Sechs-Tab-Chrome `status` nirgends** —
das steht als Kommentar im Blatt selbst bei `loadPet` (24.08.: »dieser Zweig war STUMM«). Die
einzige Anzeige war `loadErr` im Ladeschirm, und der verschwindet, sobald `ready` steht. Ergebnis:
ein Studio ohne Emotes und ohne Gesichts-Block, das aussah wie eines mit.

Zusätzlich überschrieben die nachfolgenden `setState` des Starts (Boot-Bericht, `v5boot`, `v8guard`)
den Statustext ohnehin. Ein eigener Zustand war deshalb nötig, kein zweiter Statustext.

## Was jetzt passiert
1. `this.setState({ libMissing: e.message })` — eigener Zustand, wird vom Start **nicht** überschrieben.
2. Ein `console.warn` mit Ursache und Folge, nicht nur mit der Fehlermeldung.
3. Ein Hinweisstreifen unter der Reiterzeile: **LIBRARY MISSING** · »pet-LIBRARY.json nicht geladen —
   keine Emotes, kein Gesichts-Block. Die Figuren kommen aus sources.js (Repo + Entwürfe).« plus die
   echte Ursache (`pet-LIBRARY.json HTTP 404`).
4. Ein `dismiss`-Knopf. Wegklickbar, nicht wegzuignorieren: der Streifen kommt beim nächsten Laden
   wieder, solange die Datei fehlt.

**Gemessen:** Streifen sichtbar, Text trägt die echte Ursache, Figur und Bühne unverändert,
keine neuen Konsolenfehler. Bei vorhandener Bibliothek steht `display:none` — kein Platzhalter.

## Betroffene Aufrufer
Keine. Der Streifen hängt an einem eigenen Zustandsfeld und einer eigenen Fläche; `lib`, `roster`,
die beiden Leser und alle Verträge bleiben unberührt.

## Wenn die ToolBox diese Änderung mitnehmen will
Drei Stellen im Blatt, alle drei im Quelltext datiert und begründet (`15.09.`):
der `catch` bei `LIB_URL`, drei Werte in `renderVals()` (`libWarnStyle` · `libWarnText` ·
`onLibWarnClose`), ein `div` in der Bühne direkt nach `canvas` und `input[type=file]`.

# Delta · laufender Stand gegen `kfb-rigs-embed-v3` am Commit `525288d6`
*15.09.2026 · Verfahren: Git-Blob-Hash je Datei gegen die Blob-Hashes des gepinnten Baums;
Modulbaum transitiv aus den Einstiegen aufgelöst (statische und dynamische Importe, `import.meta.url`).
Rohdaten: `qa/identity-raw.json` · `qa/delta-files.json` · `qa/closure.json`.*

## 1 · Dateivergleich

### 1a · v3-Module — unverändert seit dem Pin (29)
Alle bytegleich (Blob-Hash identisch). Grund: die Werkstatt hat **neben** v3 weitergebaut, nicht darin.

`frizzlegraft-v1/`: actor-wobble.v1 · donoreyes.v1 · ears.v2 · eyeoval.v1 · facehost.v1 · fx.v1 ·
graft-biped.v1 · graft-mount.v1 · headgraft.v1 · headzones.v1 · matzones.v1 · wordmark.v1
`lab-v2/audit.js` · `lab-v4/carlrig.js`
`lab-v6/`: carl-contract.v1 · facegraft.v1 · partrig.v1 · texclean.js · zonenames.v4
`petstudio-v9/`: kfb-ink-canon.js · studio-v12/{brow-rig.v2, frizzlebob.v4a, gun-look.v4a,
pet-eye-rig.v6, pet-moustache.v1, pet-nose.v2} · studio-v13/pose-rig.v1 · studio-v3/pet-mouth.v1
`contracts/kfb-pet-graft-driver.v4.json` (im Workspace als `fixtures/`)

### 1b · Geändert gegenüber dem Pin (2) — die angekündigte v3.1
| Datei | Pin | jetzt | Grund | Aufrufer |
|---|---|---|---|---|
| `lab-v6/carlrig-mount.v1.js` | 5 716 B · `52dfccb5ad19` | 9 780 B · `ff3262743ed9` | **R1-Fix**: positiver Feldfilter über die sechs `PartRig`-Felder, Rückgabestatus wird ausgewertet, `applied[]`/`rejected[]` | Studio v17 (`_CarlMod`) · Animation Lab v3 (`carlmount`) · Rigging Lab (mittelbar) |
| `EMBED_KFB_RIGS_v3.md` | 12 516 B · `5ac6d3ecb81c` | 17 791 B · `e8d42004af07` | Anleitung um den Fix und die Nichtpin-Warnung erweitert | — |

### 1c · Nur lokal, am Pin **nicht vorhanden** (2)
`kfb-rigs-embed-v3.manifest.json` · `REVIEW_ANTWORT_v3.1.md` → im Repo nachzuziehen.

### 1d · Am Pin vorhanden, vom Baumwerkzeug verborgen (1)
`petstudio-v9/assets/models/FrizzleBob_Yellow.gltf` · 608 342 B · am Pin und lokal identisch.
**Nicht als »fehlt« führen.** Das Werkzeug zeigt `.gltf`/`.glb` in diesem Repo nicht an.

### 1e · Eine Umbenennung im Paket
`KFB Mech & Vehicle Rig v2.dc.html` liegt als `KFB Mech and Vehicle Rig v2.dc.html` im Paket.
**Inhalt unverändert.** Das `&` im Dateinamen bricht Werkzeugketten und URL-Behandlung (hier
mehrfach aufgetreten). Empfehlung: in der Quelle ebenfalls umbenennen.

### 1f · Vorgänger unbekannt
Keiner. Jede Datei des Pakets hat am Pin ein Gegenstück oder ist nachweisbar neu (1c).
**Aus Versionsnummern wurde nichts abgeleitet** — nur aus Hashes.

## 2 · Fähigkeiten, die v3 nicht kannte (52 Dateien ohne Gegenstück)
| Fähigkeit | Dateien | Einstieg |
|---|---|---|
| **Recherchi** · Würfel, sechs Materialschächte mit echtem HTML je Fläche, **kein CSS3DRenderer** | `frizzlegraft-v1/recherchi-mount.v1.js` (46 740 B) · `fixtures/kfb-pet-recherchi.json` | Studio v17 (4. Bewohnerklasse) · Recherchi Lab v1 |
| **Animation-Linie** · Vertrag als Figurenquelle, Clip-Karte, Spurenprüfung | `anim-contract.v1` · `anim-map.v1` · `anim-audit.v1` | Animation Lab v3 · Studio-Reiter »Anim« |
| **Carls Farben und Oberflächen** je Insel | `lab-v6/brow.v3` · `stache.v3` · `inkform.v1` · `frizzlegraft-v1/actor-color.v1` | Rigging Lab v1 (21 Zonen) |
| **Kartenreiter** · Figur sitzt auf der KFB-Karte | `cardrider.v1.js` + `kfb-card-backside.png` (kopiert, nicht verlinkt) | Studio v17 |
| **Sockel und Wanne** | `torsobase.v1` · `seat-lab.v1` · `look.v1` | Mech & Vehicle Rig v2 |
| **Gepinnte Quellen** · 94 Pfade, Bewegung, Ablage | `lab/assets.js` · `locomotion.js` · `zipstore.js` · `lab-v2/sources.js` | Rigging Lab · Dummy Lab |
| **Studio-Unterbau** (v7–v13) · Sitzung, Messung, Boden, Pad, Blasen, Pose, Waffenaufsätze | 21 Dateien unter `petstudio-v9/studio-v*`, `podcast-v2/` | Studio v17 |
| **Verträge und Entwürfe** | `kfb-pet-capsule-carl.json` · `kfb-pet-graft-driver-default.json` · `kfb-pets.json` · `lab-v2/config/*` | alle |
| **Oberflächenrahmen** | `_ds/doccheck-…/_ds_bundle.js` · `colors_and_type.css` | Rigging Lab v1 |
| **Rückfallwege, bewußt behalten** | `frizzlegraft-v1/ears.v1.js` | eine Zeile im Blatt |
| **Ungenutzt im Paket** | `petstudio-v9/kfb-pinball-audio.js` (Bank fehlt, s. RETURN §Kaltstart) | Studio v17, erst beim Klick |

## 3 · Migrationsfolgen für die ToolBox
- **Die Ordnerstruktur ist Teil des Vertrags.** Studio v17 setzt `window.__KFB_MODBASE = petstudio-v9/`
  und lädt `./studio-v7/…` **und** `../lab-v6/…` — das Blatt liegt eine Ebene über `petstudio-v9/`,
  `lab-v6/` und `frizzlegraft-v1/` liegen daneben. Umsortieren bricht beides.
- **Zwei Ladewege, beide erhalten:** die Animation-Lab-Linie lädt über `loadModule(name, rel)` mit
  einem Umweg über eingebetteten Quelltext (`window.__KFB_LAB_SRC` / `…SRC64`) für Standalone-Pakete.
  Das Studio lädt direkt gegen den Modul-Anker. **Nicht zu einem Weg zusammenziehen.**
- **Fast alle Studio-Importe sind `try/catch`.** Fällt ein Modul aus, fehlt genau sein Beitrag und
  sonst nichts — gut für Robustheit, schlecht für die Fehlersuche: der Ausfall ist stumm.
- **Alle Modelldaten kommen zur Laufzeit aus dem Repo**, ganz überwiegend über `/main/`, also
  **beweglich**. Ein gepinnter Modulimport pinnt die Daten nicht mit. Genaue Liste: `MANIFEST.json`.

## 4 · Offen (blockiert die Abnahme von A nicht)
`pet-LIBRARY.json` fehlt (Emotes, Gesichts-Block leer, stummer Ausfall) ·
`kfb-pinball-sfx.json` fehlt (Klang ungeprüft) ·
`fonts/` fehlt absichtlich (18 Regeln, `swap` trägt) ·
Feldabdeckungstabelle noch nicht erzeugt ·
Prüfgrößen 1440×900 / 1024×768 / 768×1024 / 390×844 **noch nicht gemessen** — das ist B.

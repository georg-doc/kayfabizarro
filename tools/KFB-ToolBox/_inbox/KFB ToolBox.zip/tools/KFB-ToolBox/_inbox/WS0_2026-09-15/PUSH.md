# Git-Sicherung dieses Jobordners · Anleitung
*15.09.2026 · **Nicht ausgeführt. Grund ist jetzt gemessen, nicht vermutet.** Der Schreibweg ist in
dieser Umgebung vorhanden (Dateien pushen, Branch anlegen, Datei anlegen/ändern, PR öffnen), aber die
GitHub-App-Installation auf `georg-doc/kayfabizarro` lehnt jeden Schreibvorgang ab. Drei Endpunkte
geprüft, alle drei `403 Resource not accessible by integration`:*

| Versuch | Endpunkt | Ergebnis |
|---|---|---|
| Branch `toolbox/ws0-quellstand-2026-09-15` anlegen | `POST /git/refs` | **403** |
| Commit auf `main` (Tree bauen) | `POST /git/trees` | **403** |
| Einzeldatei auf `main` schreiben | `PUT /contents/…` | **403** |

**Einordnung:** die Installation hat Leserechte (Baum, Dateien, Codesuche, Commit-Vergleich) und
**kein** `Contents: Read and write`. Das ist eine Rechteaussage über diese Installation, keine
Plattformdiagnose und keine Aussage über Georgs eigene Rechte am Repo. Zwei Wege stehen offen:
**(A)** der Installation `Contents: Read and write` auf diesem Repo geben, dann läuft der Push von
hier; **(B)** der Push von Georgs Rechner mit den Befehlen unten. **B braucht nichts von hier** —
der Jobordner liegt vollständig lokal.

## Was zu sichern ist

    tools/KFB-ToolBox/_inbox/WS0_2026-09-15/
      START_HERE.md          Einstieg, Herkunft, Startweg, Verlauf
      DELTA_WSA.md           nachgerechnetes Delta gegen den Pin und gegen den T1-Stand
      RETURN_WSA.md          Rückgabe mit TESTED-RESULT-Tabelle
      FIELD_COVERAGE.md      positive Feldabdeckungsmatrix, 48 Zeilen
      SOURCE_MANIFEST.json   Archivhash + 113 Dateien mit Bytes und sha256
      PUSH.md                diese Datei
      qa-wsa/                QA_EVIDENCE.md + 5 JSON + 7 Kaltstartbilder
      unpacked/              vollständig entpacktes Paket (113 Dateien)
      original/              Archiv unverändert

    tools/KFB-ToolBox/_archive/site-v1_2026-09-14/    ersetzte Startseite
    tools/KFB-ToolBox/site/{KFB ToolBox.dc.html,index.html}   neue Startseite
    tools/KFB-ToolBox/{CHANGELOG.md,TOOLBOX_MANIFEST.json,docs/MISSING_MODULES.md}

## Zwei Entscheidungen, die vor dem Commit zu treffen sind

1. **`original/…zip` und `unpacked/` zusammen sind Dopplung** (~5 MB im Repo). Das Archiv liegt
   bereits unter `_inbox/KFB FrankenStein ToolBox (WS0).zip`. Vorschlag: nur `unpacked/` und die
   Dokumente committen, `original/` per `.gitignore` auslassen und die Herkunft über den sha256 im
   `SOURCE_MANIFEST.json` halten — der pinnt das Archiv genauso.
2. **Freigabeumfang.** Im Paket sind **keine** Schriftdateien, Tokens oder privaten Berichte
   (nachgeprüft: 17 `fonts/`-Referenzen ohne Dateien). Der Quelltext, die Verträge und die
   Kaltstartbilder sind für dieses öffentliche Repo freigegeben. `docs/LIVING_frizzlegraft.md`
   (171 kB Chronik) ist Teil des Pakets; wer sie nicht öffentlich will, läßt sie aus.

## Befehle

    git checkout -b toolbox/ws0-quellstand-2026-09-15
    git add "tools/KFB-ToolBox/_inbox/WS0_2026-09-15" \
            "tools/KFB-ToolBox/_archive/site-v1_2026-09-14" \
            "tools/KFB-ToolBox/site/KFB ToolBox.dc.html" \
            "tools/KFB-ToolBox/site/index.html" \
            "tools/KFB-ToolBox/CHANGELOG.md" \
            "tools/KFB-ToolBox/TOOLBOX_MANIFEST.json" \
            "tools/KFB-ToolBox/docs/MISSING_MODULES.md"
    git commit -m "ToolBox: WS0-Quellstand geprüft und übernommen, Startweg umgestellt

    - Archiv sha256 948d195017e2ab7dd26f3e9c5cb4f01d00fa614e0e6425431db04e43b2393c5b
    - 101/101 Paket-Prüfsummen PASS, Modulschluß 0 offene Referenzen, 7/7 Kaltstart
    - 30/31 Embed-Dateien bytegleich zum Pin (Abweichung: v3.1 carlrig-mount)
    - Feldabdeckung 48 Zeilen, kein neuer Source-/Contract-Blocker
    - Status T1_PARTIAL_BLOCKED_SOURCE_EXPORT -> T1_SOURCE_CLOSURE_DELIVERED"
    git push -u origin toolbox/ws0-quellstand-2026-09-15

Danach PR gegen `main`, Merge-Autorität aus dem aktuellen Projektauftrag. **Nichts löschen**: die
drei Bundles, die sechs Configs und der Eingang vom 13.09. bleiben unverändert liegen.

## Prüfbar nach dem Push · Git-Blob-Hashes der Jobdokumente

Nach dem Commit läßt sich jede Datei einzeln gegen diese Werte stellen
(`git hash-object <datei>`); stimmt der Hash, ist die Datei bytegleich zu dem Stand, der hier
geprüft wurde.

| Datei | Bytes | Git-Blob-SHA1 |
|---|---|---|
| `START_HERE.md` | 5 280 | `a5489352708f8b051d64dea4ecd72f2b1a34ddf3` |
| `DELTA_WSA.md` | 5 921 | `f45a2728b71a89d1f4b5f30fe52315a2401e993c` |
| `RETURN_WSA.md` | 11 669 | `a73f38c009da25189c4fd663ef539f82c6d62408` |
| `FIELD_COVERAGE.md` | 14 689 | `52519a1b46e24596462cb13f9c87078fedef4b10` |
| `SOURCE_MANIFEST.json` | 20 545 | `2495ef87d0b03f3d656808b2d9fbaae8ae2ee8c9` |
| `PUSH.md` | — | ändert sich mit dieser Fassung, deshalb nicht gepinnt |
| `qa-wsa/QA_EVIDENCE.md` | 2 897 | `fa74c46c025b275ebcdfcf11aa431fe39a2bd520` |
| `qa-wsa/checksums-wsa.json` | 250 | `728ea26dae4c7c998eda134b86be2b51ec238c98` |
| `qa-wsa/closure-wsa.json` | 19 748 | `797823627f60516636afb2a8af6e23294ec68611` |
| `qa-wsa/field-coverage-wsa.json` | 9 859 | `bd0fa131697e52522e27de1e6c6fb46822c62fd5` |
| `qa-wsa/fields-wsa.json` | 1 063 | `1367617983eeccf1b8ecb31f9200b5a4b97c4c24` |
| `qa-wsa/identity-wsa.json` | 7 753 | `9d41ebb9edc2cd471e393fa753e1f49820dbba97` |

Die sieben Kaltstartbilder sind in `qa-wsa/QA_EVIDENCE.md` über Bytes und sha256 gepinnt.

## Nachzutragen, sobald der Commit steht

`SOURCE_MANIFEST.json → archive.commit` (steht auf `UNRESOLVED`), `github.md → ## Last sync · commit:`,
und in `TOOLBOX_MANIFEST.json` `site.workBranch` auf den tatsächlichen Branchnamen.

# PUSH · Birthday-Consumer-Handoff · 15.09.2026

Schreibweg von hier weiterhin verweigert: `POST /git/refs` → `403 Resource not accessible by integration` (gemessen 06:52 UTC, wie am Vortag). Fehlendes Recht: **Contents: Read and write** auf der App-Installation. Zwei Wege:

**A · Recht nachziehen**, dann läuft der Push von hier (Branch `toolbox/birthday-casting-2026-09-15`, danach PR nach `main`).

**B · Von Georgs Rechner** — ZIP dieses Ordners entpacken, dann:

    cd kayfabizarro
    git checkout -b toolbox/birthday-casting-2026-09-15 main
    # Ordner aus dem ZIP nach tools/KFB-ToolBox/_handover/BIRTHDAY_STARTSCREEN_2026-09-15/ legen
    # tools/KFB-ToolBox/CHANGELOG.md aus dem ZIP übernehmen (additiv, Obermenge des Repo-Stands e61c28e3)
    git add tools/KFB-ToolBox/_handover/BIRTHDAY_STARTSCREEN_2026-09-15 tools/KFB-ToolBox/CHANGELOG.md
    git commit -m "ToolBox · Birthday-Consumer-Handoff: Casting FrizzleBob + GothGirl (Idle/Focus/Select/Rest), Dance P1, Hihi Slot"
    git push -u origin toolbox/birthday-casting-2026-09-15

## Dateien

| Pfad (unter `tools/KFB-ToolBox/`) | Bytes | Art |
|---|---|---|
| `_handover/BIRTHDAY_STARTSCREEN_2026-09-15/RETURN_BIRTHDAY_CONSUMER.md` | 9 453 | Return Contract |
| `_handover/BIRTHDAY_STARTSCREEN_2026-09-15/PUSH.md` | — | dieses Blatt |
| `_handover/BIRTHDAY_STARTSCREEN_2026-09-15/profiles/kfb-pet-graft-driver.georg-2026-09-15.json` | 30 337 | Georgs Upload, sha256 `554a4395…9a05` |
| `_handover/BIRTHDAY_STARTSCREEN_2026-09-15/qa/casting-probe.html` | 20 438 | Meßseite |
| `_handover/BIRTHDAY_STARTSCREEN_2026-09-15/qa/casting-probe.json` | 16 374 | Meßwerte |
| `_handover/BIRTHDAY_STARTSCREEN_2026-09-15/qa/QA_EVIDENCE.md` | 2 334 | sha256 der Bilder |
| `_handover/BIRTHDAY_STARTSCREEN_2026-09-15/qa/*.jpg` | 12 Dateien | Standbilder (Pins in QA_EVIDENCE) |
| `CHANGELOG.md` | 20 771 | additiv, enthält den Repo-Eintrag 14.09. unverändert plus 14.09.–15.09. |
| `site/KFB ToolBox.dc.html` · `site/index.html` | — | nur ein Nav-Link »Birthday-Casting« ergänzt (optional mitnehmen) |

`START_HERE.md` in diesem Ordner ist Georgs Auftrag vom Repo (`1139a94f…`) — nicht verändert, nicht mitschieben.

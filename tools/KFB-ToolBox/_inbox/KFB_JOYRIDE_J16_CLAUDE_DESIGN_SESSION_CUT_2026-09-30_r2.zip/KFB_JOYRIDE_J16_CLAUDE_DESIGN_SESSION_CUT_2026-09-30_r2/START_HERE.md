# START_HERE · KFB Joyride J16 · Parcours 1b Race-Tube · Session Cut 2026-09-30 r2

**Status:** DESIGN PROOF · CANDIDATE. Kein GitHub-Push, kein Cloudflare, keine Stage, keine Owner-Änderung.

## Sofort testen (ohne Server)
`KFB Joyride J16 · Standalone.html` liegt in 5 Teilen bei (sha256 db1d569bab21c4500f60927e1934be3a309d9763e635f5c4e7489b787ecba157) (ZIP-Grenze 2 MB):
```sh
cat "KFB Joyride J16 · Standalone.html.part0"* > "KFB Joyride J16 · Standalone.html"
```
Doppelklick genügt. Alle lokalen Dateien stecken darin (Stream, Module, Knet-Texturen); Aufbau 40–60 s.
Online nötig bleiben: three.js/React (unpkg), Google Fonts, KayKit-Figuren/Autos/Radio (jsDelivr/GitHub).

## Projekt-Fassung (Server)
- Entry: `KFB Joyride J16 · Parcours 1b Race-Tube.dc.html` (braucht `support.js`).
- Weitere Seiten: `KFB Joyride TC1 · Tunnel-Looks.dc.html` (4 Looks, Georg-Wahl = C Race-Tube) und `KFB Joyride P1 · Parcours-Plan.dc.html` (Inventar + Draufsicht).
- Stream zusammensetzen:
  `cat lab-track/data/p1b.v2.stream.json.part0* > lab-track/data/p1b.v2.stream.json`
  sha256 `2eec607913380419117a9ee56359cc9e478e8a80ce00ce08b2641c22fa7fb309`.
- Die Fingerabdruck-Textur `ref/clay-joebinns/Fingerprints01_3K.png` fehlt in diesem ZIP (Platzgrenze). Sie ist optional, der Code hat einen Rückfall; im Standalone und im r1-Cut ist sie enthalten.
- Starten: `npx serve .` oder `python3 -m http.server`.

## Bedienung
- **Auto:** W/S Gas/Bremse · A/D lenken · Q/E Drift · Shift Boost · Leertaste unter 0,5 m/s Aussteigen, darüber Hüpfen · R zurück · C Kamera
- **Burger-Menü:** Runde automatisch · Proben A/B/C · Figur · Physik K2B/K2 · Tunnel „Race-Tube (fest im Rezept)“

## Lesereihenfolge
- WSA: `HANDOVER_WSA.md`
- Blender MCP: `HANDOVER_BLENDER_MCP.md` + `blender/`
- Beide danach: `CURRENT_STATE.md` → `TEST_REPORT.md` → `RETURN.md` → `evidence/`
- Frischer Chat: `NEXT_CHAT.md`

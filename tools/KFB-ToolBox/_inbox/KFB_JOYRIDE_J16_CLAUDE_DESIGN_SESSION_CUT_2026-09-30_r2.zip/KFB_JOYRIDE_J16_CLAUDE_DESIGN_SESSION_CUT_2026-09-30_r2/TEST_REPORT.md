# TEST_REPORT · r2 · 2026-09-30

| # | Test | Ort | Ergebnis | Beleg |
|---|---|---|---|---|
| T1 | compileRecipe B (toy) + runChecks + Pads | headless | **PASS** · 0 Fehler, pad_level 0,0001, tunnel_clearance 0,3, portal_match 0, tunnel_shell PASS, 1 Ring | lab-track/data/p1b.v2.export.json |
| T2 | Rezept A unverändert | headless | **PASS** · Fingerprint 840a0a2e | – |
| T3 | Ring v2 = getesteter race_tube-Ring, Geometrie v2 = p1b | headless | **PASS** · je 0 m | p1b.v2.export.json |
| T4 | Runde 1b v2 (W+Shift, s 60, dt 1/60) | headless | **PASS** · K2B 91,60 · K2B@0,8 91,87 · K2 91,53 s · 7/7 · 0 Bande · 0 Rettung | evidence/j16-round-gate.p1b-v2.json |
| T5 | Kamera J16 Tunnel/Loop/Skydrive | Vorschau | **PASS** · 112/158/301 Proben, 0 verdeckt, 0 unter Fahrbahn, 0 Kipper, Ring min. 8,64 m | evidence/j16-cam-probe.json |
| T6 | Bildkontrolle Race-Tube (Portale, innen, Übersicht, Verfolger) | Vorschau | **PASS** | evidence/j16-race-tube.*.png |
| T7 | Standalone bootet | Vorschau | **PASS** · VFS 40 Dateien, 32 Module, 0 Zyklen, 0 Fehler, Stream d42aa57e, TC1 84.448 △, 19 fps | evidence/j16-standalone.check.png |
| T8 | Referenz-GLB exportiert (three GLTFExporter, mergeVertices) | Skript | **PASS** · 1,58 MB, 5 Meshes + Mittellinie | blender/tc1-race-tube.v1.glb |
| T9 | Clean-Run gegen das entpackte ZIP | Skript | siehe Rückgabe (cleanrun r2) | – |
| T10 | Standalone offline (ohne Netz) | – | **NOT_RUN** · braucht CDN (three/React/KayKit) | – |
| T11 | fps auf Georgs Gerät | – | **NOT_RUN** | – |
| T12 | GLB in Blender geöffnet | – | **NOT_RUN** | – |

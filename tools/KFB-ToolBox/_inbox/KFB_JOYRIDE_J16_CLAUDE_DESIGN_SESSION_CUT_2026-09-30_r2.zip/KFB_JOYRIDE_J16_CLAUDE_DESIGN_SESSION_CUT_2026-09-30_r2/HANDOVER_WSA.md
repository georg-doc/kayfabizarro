# HANDOVER an WSA · J16 Parcours 1b Race-Tube · 2026-09-30

## Entschieden (Georg)
Parcours **1b** · Tunnel **Race-Tube** (TC1 `race_tube` auf Core-Preset `toy`).

## Was steht
- **Rezept:** `p1-recipes.js` B = `tunnel(90, 'toy')`. `BLOCKS.tunnel` hat jetzt den optionalen Parameter `extra`. A bleibt unverändert (840a0a2e).
- **Stream** `p1b.v2.stream.json`:
  - Core-Fingerprint d42aa57e, 0 Fehler, pad_level 0,0001 m
  - Ein Ring: round Ø 24,93 m, Wand 0,6 m. tunnel_clearance 0,3, portal_match 0, tunnel_shell PASS
  - Gegenüber dem getesteten Look-Ring und gegenüber p1b: 0 m Abweichung
- **J16** = J15-Host + Stream v2, Look fest (`source.tunnelLook`). J15 mit allen 4 Looks liegt im r1-Cut.
- **TC1** `lab-track/tunnel-clay.tc1.js`: Look-Schicht, T4-Knetmaterialien. Race-Tube = 39 Module à 6 m, Band-Ringe innen und außen, Randwulst in 14 Streifen, Lampen-Gantry, 84k △, Einbaufreiheit 0,65 m.
- **Tests:**
  - Runde headless: K2B 91,60 s · K2B@0,8 91,87 s · K2 91,53 s · je 7/7 Sprünge, 0 Bande, 0 Rettungen
  - Kamera J16 (Vorschau), überall 0 Kipper: Tunnel 112 · Looping 158 · Skydrive 301 Proben, 0 verdeckt, 0× außerhalb des Rings (min. 8,64 m)
  - Standalone bootet in der Vorschau: VFS 40 Dateien, 32 Module, 0 Zyklen, 0 Fehler; Stream d42aa57e/8.786 Samples; TC1 race_tube 84.448 △
- **Blender-Paket** `blender/`: Spezifikation (Ring, Pflichtfläche, Mittellinie je Meter, Kit-Teile, Palette, Budget, Abgabeformat) + Referenz-GLB des aktuellen TC1-Stands.

## Was nicht steht
- Einbaufreiheit ist ein TC1-Check, kein Core-Check.
- Sichtstrahl nur gegen Tunnel + strang-Meshes.
- Im Tunnel liegt die Fahrbahn im Sonnenschatten; die Lampen sind nur emissive.
- Hero Jump nur mit Boost (32,05 > 27 m/s). TD03-Warnungen unverändert.
- fps auf Georgs Gerät nicht gemessen.

## Owner-Grenzen
- Strecke/Fläche/Ring = Track Core
- Tunnel-Aussehen = TC1. Ein Blender-Asset kommt nur **über TC1** herein (Teil-Tausch je Kit-Teil) und wird kein zweiter Tunnel-Owner.
- Auto = k2b/k2 · Kamera = J09 · Travel = travel-core.j14
- T4/M2/Atlas/Fassaden/Schatten unverändert

## WSA-Entscheide nötig
1. Blender-Tunnel: ersetzt er die TC1-Geometrie je Kit-Teil (Vorschlag), oder wird er ein eigenes Asset mit eigenem Owner?
2. `tunnel_cladding` (Einbaufreiheit) als Core-Check aufnehmen?
3. Nachtastung ds 0,5 im Export beibehalten oder s-Lookup in T4/K2?
4. Tunnel-Innenlicht: echte Lichter (einmalige Shader-Neukompilierung) oder gebackene Helligkeit in TC1?

## Next Gate
**Georg fährt J16 (Standalone) auf seinem Gerät → fps + Gefühl in Race-Tube, Looping, Skydrive zurück; parallel liefert Blender MCP die Race-Tube-Kit-Teile nach `HANDOVER_BLENDER_MCP.md`, und TC1 hängt sie ein, erst wenn WSA Entscheid 1 getroffen hat.**

# CURRENT_STATE · 2026-09-30 spät

| Bereich | Stand |
|---|---|
| Parcours | 1b v2, geschlossen, 4.392 m, Fingerprint d42aa57e, Tunnel Race-Tube fest im Rezept |
| Hosts | J16 (Race-Tube fest) · Standalone J16 · J15 (4 Looks, im r1-Cut) |
| Tunnel | TC1 race_tube, 39 Module, 84k △, Einbaufreiheit 0,65 m |
| Fahrphysik | K2B / K2 pur; FLOW/FEEL = Race v0.8 |
| Kamera | J09-Verfolger; Probe Tunnel/Loop/Skydrive ohne Verdeckung |
| Blender | Spezifikation + Referenz-GLB übergeben; Kit v2 offen |
| Offen | fps auf Georgs Gerät · Blender-Owner-Entscheid · Innenlicht · Einbaufreiheit als Core-Check |

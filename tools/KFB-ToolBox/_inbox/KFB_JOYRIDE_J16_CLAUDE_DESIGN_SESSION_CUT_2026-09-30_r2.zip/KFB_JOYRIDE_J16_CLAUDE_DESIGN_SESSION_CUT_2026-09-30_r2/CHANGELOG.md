# CHANGELOG · 2026-09-30

## r2 (J16 + Standalone + Blender-Paket)
- Rezept B: Tunnel = Core-Preset `toy` (Georg: Race-Tube). `BLOCKS.tunnel(turn, preset, extra)`.
- `lab-track/data/p1b.v2.stream.json`: ein Ring. Race-Tube-Wand jetzt 0,6 m (Core toy); in J15 waren es 1,2 m aus dem gotthard-Standard.
- `KFB Joyride J16 · Parcours 1b Race-Tube.dc.html`: Look fest, Tweak `tunnelLook` entfernt.
- `lab-track/j15-cam-probe.js`: Ringabstand fällt jetzt auf `tunnelRings` zurück.
- **Standalone** `KFB Joyride J16 · Standalone.html`: eingebettetes Dateisystem (gzip + base64). Module werden als blob:-Module neu verdrahtet, `import.meta.url` → vfs-Basis, fetch() und <img>.src lesen aus dem VFS. Quelle: `KFB Joyride J16 Standalone.src.html`.
- `blender/tc1-race-tube.spec.json` + `blender/tc1-race-tube.v1.glb` (Referenz, mergeVertices, 1,6 MB).

## r1 (J15)
Siehe r1-Cut: Stream 1b, TC1 mit 4 Looks, J15, Tunnel-Looks-Seite, Belege.

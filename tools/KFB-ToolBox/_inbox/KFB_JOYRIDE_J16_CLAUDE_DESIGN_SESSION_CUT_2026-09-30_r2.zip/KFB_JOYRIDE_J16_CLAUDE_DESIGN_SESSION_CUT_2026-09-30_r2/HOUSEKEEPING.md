# HOUSEKEEPING · r2

## Behalten
J16-DC, Standalone (.html + .src.html), `lab-track/data/p1b.v2.*`, `lab-track/tunnel-clay.tc1.js`, `blender/**`, `lab-track/evidence/j16-*`, `export/JOYRIDE_J15_2026-09-30/RETURN.md` (mit J16-Nachtrag).

## Kann weg (Workspace)
- `export/_stage_j15/**`, `export/_stage_j16/**` (Staging)
- `lab-track/data/p1b.stream.json` erst, wenn J15 nicht mehr als Vergleich gebraucht wird. Es ist dieselbe Route, aber mit 4 Ringen.

## Doppelte Wahrheiten vermeiden
- Kanonisch ist p1b.v2 (ein Ring). p1b (v1) ist nur der J15-Vergleich.
- Standalone = abgeleitete Datei. Nie direkt ändern; aus der .src.html neu bündeln.
- `blender/tc1-race-tube.v1.glb` ist Referenz, nicht Laufzeit.

## Nicht im r2-ZIP
- J15 + p1b v1 (im r1-Cut)
- `ref/clay-joebinns/Fingerprints01_3K.png` (optional; im r1-Cut und im Standalone)

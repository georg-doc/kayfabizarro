# HANDOVER an Blender MCP · TC1 Race-Tube · 2026-09-30

## Worum es geht
Der Joyride-Tunnel auf Parcours 1b ist eine **Race-Tube** im Knetstil. Lage, Kurve, Innenkontur und Wandstärke kommen aus dem Track Core und sind fest. Die Verkleidung (TC1) ist in three.js prozedural gebaut. Aus Blender brauchen wir **bessere Kit-Teile in derselben Geometrie-Hülle**, nicht einen neuen Tunnel.

## Dateien
- `blender/tc1-race-tube.spec.json`: alle Maße. Ring (48 Punkte), Pflichtfläche + Mindestabstand 0,3 m, Mittellinie je Meter (p/R/U/T), Kit-Teile, Palette, Budget, Abgabeformat.
- `blender/tc1-race-tube.v1.glb` (1,6 MB): der aktuelle TC1-Stand als Referenz. Meshes je Material (`tc1_race_tube_strang|cloud|pad|tower1|lamps`), Mittellinie als Linie `tc1_centerline_road`, Ursprung = Portal Einfahrt.
- Bilder: `evidence/j16-race-tube.sheet.png`, `evidence/j16-race-tube.chase.jpg`, `evidence/j16-standalone.check.png`.
- Live: `KFB Joyride J16 · Standalone.html`

## Feste Maße (nicht ändern)
- Ring round, Ø 24,93 m (innen), Wand 0,6 m. Tunnel 230,87 m mit 90°-Kurve (r 90 m), gerade Ein- und Ausfahrt.
- Unter −0,7 m (relativ zur Fahrbahn) liegt alles im Tisch; dort kein Detail nötig.
- Kein Teil näher als **0,3 m** an die Pflichtfläche (Barrieren, Bankett, Fahrbahn + 7,0 m Fahrzeughülle). TC1 misst das beim Einbau und meldet PASS/FAIL.

## Kit-Teile (Vorschlag, Maße aus TC1)
1. `module_6m`: Innenband + Außenschale, 6 m lang, gerade. TC1 biegt es entlang der Mittellinie; darum Querschnitt sauber und längs mit ausreichend Kanten.
2. `band_ring`: Stoß-Ring innen + außen, Rundprofil r ≈ 0,3 m (pad-Gelb).
3. `portal_rim`: Randwulst r ≈ 1,0 m um die Öffnung, 14 Streifen strang/cloud.
4. `gantry`: Brett 18 × 2,7 × 1,0 m über dem Portal, 5 Lampen, 2 Stützen (tower1).
5. `lamp`: Kugel r 0,28 m, emissive.

## Stil
- Knete: weiche, leicht unregelmäßige Kanten, keine harten Fasen, keine Bildtexturen. Das Knet-Relief (Daumen, Fingerabdruck, Korn) kommt aus dem T4-Shader.
- Palette: strang #ef5a22 · cloud #e2d0bc · pad #f2b632 · tower1 #e8743a · Lampe #fff2c8 / emissive #ffc15a. Materialnamen `kfb_<key>`; TC1 ersetzt sie durch die Knetmaterialien gleichen Schlüssels.
- Budget: ganze Röhre inklusive Portale ≤ 84k △ (heutiger Stand).

## Abgabe
- GLB, Y oben, Meter.
- Je Kit-Teil ein Node **im Kit-Rahmen**: X = rechts, Y = oben, −Z = Fahrtrichtung, Ursprung Fahrbahnmitte am Stoß bzw. Portal. **Nicht** entlang der Kurve backen.
- Name `tc1_race_tube_<teil>_<materialKey>`. Kein gebackenes Licht.
- Ablage: `blender/tc1-race-tube.kit.v2.glb` + kurze `blender/RETURN_BLENDER.md` mit Teile-Liste, △ je Teil und Hinweis, was sich gegenüber v1 ändert.

## Grenzen
- Nicht anfassen: Ring, Mittellinie, Fahrbahn, Barrieren, Tunnel-Länge/Kurve. Das gehört dem Track Core.
- Laufende Blender-Reparaturen an anderen Tunneln blockieren J16 nicht. Übernahme in J16 erst nach WSA-Entscheid (Owner: TC1 tauscht Teile, kein zweiter Tunnel-Owner).

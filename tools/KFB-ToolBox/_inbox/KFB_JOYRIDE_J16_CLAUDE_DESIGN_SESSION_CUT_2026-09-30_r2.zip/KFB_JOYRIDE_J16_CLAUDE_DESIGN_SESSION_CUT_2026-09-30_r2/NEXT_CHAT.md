# NEXT_CHAT · Onboarding für einen frischen Chat

## Paste-Prompt
> Weiter mit KFB Joyride J16 (Session Cut 2026-09-30 r2, Projekt „KFB World Design Setup“). Entry `KFB Joyride J16 · Parcours 1b Race-Tube.dc.html`, Test ohne Server: `KFB Joyride J16 · Standalone.html`. Status DESIGN PROOF · CANDIDATE. Lies START_HERE.md, HANDOVER_WSA.md, TEST_REPORT.md; wenn es um den Tunnel geht, auch HANDOVER_BLENDER_MCP.md. Setz zuerst die geteilten Dateien zusammen. Nichts erfinden: Werte aus Track Core v0.12 oder den Belegen. Auftrag: das Next Gate aus HANDOVER_WSA.md.

## Kontext
1. Joyride = Knet-Rennspiel (three.js, Claymation-Look T4). Strecken baut ausschließlich der **Track Core v0.12** (`lab-track/core/track-core.v012.mjs`, Rezepte `lab-track/parcours/p1-recipes.js`).
2. P1 = Baukasten-Parcours. Georg hat **1b** gewählt (Uni-Center → Stadt → Fahrschule → Skydrive → Tunnel → Hero Jump) und als Tunnel die **Race-Tube**.
3. Tunnel = TC1-Look-Schicht über dem Core-Ring (`lab-track/tunnel-clay.tc1.js`). Blender MCP liefert bessere Kit-Teile, TC1 bleibt Owner.
4. Eingefroren: Fahrphysik K2B/K2, Kamera J09, Reisemodi J14, T4, M2, Übergangsatlas, Fassaden, Schatten.
5. WSA = Architekt/Reviewer (Briefs, Owner-Entscheide, will Belege). Georg = Auftraggeber, entscheidet an Wahlpunkten.

## Arbeitsregeln
- Kein zweiter Owner (Track, Kamera, Physik, Travel, Tunnel-Look).
- Werte aus Quellen; Budget-Änderungen nur mit Vorher/Nachher.
- An menschlichen Wahlen anhalten und Varianten zeigen.
- Vor jeder Übergabe die Stelle im Bild prüfen. WebGL-Fotos über `lab-track/tc1-sheet.js` (`sheet()` / `chase()`), dann das Element sichern.
- Zwei Fehlversuche am selben Gate → einfrieren und Belege zeigen.
- Ausgaben versioniert benennen (.vN/.jN/?r=N). Nur ausgeführte Tests heißen PASS.

## Werkzeuge
- Runde headless: Physik-Datei im Skript laden, `makeFrame` → `createDriver(60)` → `stepDriver` mit W+Shift, dt 1/60 (Soll 1b: 91,60 s, 7/7, 0 Bande).
- Kamera-Probe: `(await import('./lab-track/j15-cam-probe.js')).run({ zones })` → `window.__camProbe`.
- TC1: `window.__tc1.info` (Module, Teile, △, Einbaufreiheit).
- Core-Export: `compileRecipe` → `runChecks` → `placePads` → erneut `compileRecipe` → Nachtastung ds 0,5 (round(s/ds)).
- Standalone neu bauen: `KFB Joyride J16 Standalone.src.html` erzeugen (VFS-Skript, siehe CHANGELOG r2) → super_inline_html.

## Offene Entscheide (nicht selbst treffen)
Blender-Owner · Einbaufreiheit als Core-Check · Nachtastung vs. s-Lookup · Tunnel-Innenlicht · Leistung auf Georgs Gerät.

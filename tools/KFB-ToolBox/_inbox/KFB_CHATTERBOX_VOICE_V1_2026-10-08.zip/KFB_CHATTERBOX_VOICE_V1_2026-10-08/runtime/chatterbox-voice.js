/* KFB ChatterBox Voice · browser runtime v0.1
 * ---------------------------------------------------------------
 * Turns one ChatterBox Triplet line into sound. No dependencies, no server, no GPU.
 *
 *   const voice = new ChatterboxVoice({ manifest, casting, basePath: 'build/' });
 *   await voice.play({ archetype: 'troll', emotion: 'annoyed',
 *                      triplet: ['This bridge', 'used to be free, until', 'somebody invented paperwork.'] });
 *
 * Resolution order per line (first hit wins):
 *   1. fragments  every segment exists as a pre-rendered fragment -> play seg 0, gap, seg 1, gap, seg 2 …
 *                 (Triplets have 3 segments; phrase templates like 'We have a file on' + {X} have 2 or 3)
 *   2. whole      a pre-rendered whole line exists for line.lineId
 *   3. live       options.liveTTS(text, preset, emotion) returns an audio URL/Blob (future Site endpoint, optional)
 *   4. browser    window.speechSynthesis with the archetype's fallback pitch/rate (always available, sounds worst)
 *
 * Events (all optional): onBeat(slotIndex, line)  -> reveal bubble text slot by slot
 *                        onSpeaking(bool, line)    -> drive a simple mouth flap / emanata
 *                        onRoute(mode, line)       -> debug: which path was used
 * Only one line plays at a time per instance; play() cancels the previous line.
 * The manifest key format MUST match tools/render_chatterbox_voice.py: archetype|emotion|slot|normalized text
 */
(function (root) {
  'use strict';

  function normText(t) {
    return String(t || '').toLowerCase().replace(/’/g, "'").trim()
      .replace(/[.!?,]+$/, '').split(/\s+/).filter(Boolean).join(' ');
  }
  function fragKey(archetype, emotion, slot, text) {
    return archetype + '|' + (emotion || 'calm') + '|' + slot + '|' + normText(text);
  }
  function wait(ms, token, self) {
    return new Promise(function (res) { var t = setTimeout(res, ms); self._timers.push(t); });
  }

  function ChatterboxVoice(opts) {
    opts = opts || {};
    this.manifest = opts.manifest || { fragments: {}, lines: {} };
    this.casting = opts.casting || { archetypes: {}, emotions: {}, gapsMsDefault: [240, 140] };
    this.basePath = opts.basePath || '';
    this.liveTTS = opts.liveTTS || null;
    this.onBeat = opts.onBeat || function () {};
    this.onSpeaking = opts.onSpeaking || function () {};
    this.onRoute = opts.onRoute || function () {};
    this.useBrowserFallback = opts.useBrowserFallback !== false;
    this._token = 0; this._audio = null; this._timers = [];
  }

  ChatterboxVoice.prototype.preset = function (archetype) {
    return this.casting.archetypes[archetype] || {};
  };
  ChatterboxVoice.prototype.emotion = function (name) {
    return (this.casting.emotions || {})[name || 'calm'] || {};
  };
  /** Pause after each segment except the last. Triplets use [after SHOW IT, after SPIN IT]; longer
   *  template lines ({X} frames) reuse the last value. */
  ChatterboxVoice.prototype.gaps = function (line, n) {
    var p = this.preset(line.archetype), e = this.emotion(line.emotion);
    var g = p.gapsMs || this.casting.gapsMsDefault || [240, 140];
    var m = e.gapMul || 1, out = [];
    for (var i = 0; i < (n || 3) - 1; i++) out.push(Math.round((g[i] != null ? g[i] : g[g.length - 1]) * m));
    return out;
  };

  /** Decide how a line will be voiced, without playing it. */
  ChatterboxVoice.prototype.resolve = function (line) {
    var self = this, trip = line.triplet || [];
    if (trip.length >= 2) {
      // try the requested emotion, then its fallback chain (casting.emotionFallback), then 'calm'
      var chain = [], e = line.emotion || 'calm', fb = this.casting.emotionFallback || {};
      while (e && chain.indexOf(e) < 0 && chain.length < 5) { chain.push(e); e = fb[e]; }
      if (chain.indexOf('calm') < 0) chain.push('calm');
      for (var c = 0; c < chain.length; c++) {
        var files = trip.map(function (part, i) {
          var f = self.manifest.fragments[fragKey(line.archetype, chain[c], i, part)];
          return f ? f.file : null;
        });
        if (files.every(Boolean)) return { mode: 'fragments', files: files, gaps: this.gaps(line, files.length), emotionUsed: chain[c] };
      }
    }
    var l = line.lineId && this.manifest.lines[line.lineId];
    if (l && l.whole) return { mode: 'whole', file: l.whole };
    if (this.liveTTS) return { mode: 'live' };
    return { mode: 'browser' };
  };

  ChatterboxVoice.prototype.text = function (line) {
    return line.text || (line.triplet || []).map(function (s) { return String(s).trim(); }).join(' ');
  };

  ChatterboxVoice.prototype.cancel = function () {
    this._token++;
    this._timers.forEach(clearTimeout); this._timers = [];
    if (this._audio) { try { this._audio.pause(); } catch (e) {} this._audio = null; }
    try { if (root.speechSynthesis) root.speechSynthesis.cancel(); } catch (e) {}
  };

  ChatterboxVoice.prototype._playUrl = function (url, token) {
    var self = this;
    return new Promise(function (res) {
      if (token !== self._token) return res('canceled');
      var a = new Audio(url); self._audio = a;
      var done = false, finish = function (r) { if (!done) { done = true; res(r); } };
      a.onended = function () { finish('end'); };
      a.onerror = function () { finish('error'); };
      // watchdog: never hang the dialogue if a media event goes missing
      var t = setTimeout(function () { finish('watchdog'); }, 15000); self._timers.push(t);
      var p = a.play(); if (p && p.catch) p.catch(function () { finish('blocked'); });
    });
  };

  ChatterboxVoice.prototype._browserSpeak = function (line, token) {
    var self = this, synth = root.speechSynthesis, U = root.SpeechSynthesisUtterance;
    if (!synth || !U || !this.useBrowserFallback) return Promise.resolve('no-tts');
    var p = this.preset(line.archetype), fb = p.browserFallback || {}, e = this.emotion(line.emotion);
    return new Promise(function (res) {
      if (token !== self._token) return res('canceled');
      var u = new U(self.text(line));
      u.lang = 'en-US'; u.pitch = fb.pitch != null ? fb.pitch : 1;
      u.rate = (fb.rate || 1) / (e.rateMul || 1);
      var done = false, finish = function (r) { if (!done) { done = true; res(r); } };
      u.onend = function () { finish('end'); }; u.onerror = function () { finish('error'); };
      var t = setTimeout(function () { finish('watchdog'); }, 4000 + self.text(line).length * 120); self._timers.push(t);
      synth.speak(u);
    });
  };

  /** Play one line. Resolves with the route used ('fragments' | 'whole' | 'live' | 'browser' | 'canceled'). */
  ChatterboxVoice.prototype.play = function (line) {
    var self = this;
    this.cancel();
    var token = this._token, r = this.resolve(line);
    this.onRoute(r.mode, line);
    this.onSpeaking(true, line);
    var run;
    if (r.mode === 'fragments') {
      run = r.files.reduce(function (chain, file, i) {
        return chain.then(function () {
          if (token !== self._token) return;
          self.onBeat(i, line);
          return self._playUrl(self.basePath + file, token).then(function () {
            if (i < r.files.length - 1 && token === self._token) return wait(r.gaps[i], token, self);
          });
        });
      }, Promise.resolve());
    } else if (r.mode === 'whole') {
      (line.triplet && line.triplet.length ? line.triplet : [0, 1, 2]).forEach(function (_, i) { self.onBeat(i, line); });
      run = this._playUrl(this.basePath + r.file, token);
    } else if (r.mode === 'live') {
      (line.triplet && line.triplet.length ? line.triplet : [0, 1, 2]).forEach(function (_, i) { self.onBeat(i, line); });
      run = Promise.resolve(this.liveTTS(this.text(line), this.preset(line.archetype), line.emotion)).then(function (src) {
        if (!src) return self._browserSpeak(line, token);
        var url = (typeof src === 'string') ? src : URL.createObjectURL(src);
        return self._playUrl(url, token);
      }).catch(function () { return self._browserSpeak(line, token); });
    } else {
      (line.triplet && line.triplet.length ? line.triplet : [0, 1, 2]).forEach(function (_, i) { self.onBeat(i, line); });
      run = this._browserSpeak(line, token);
    }
    return run.then(function () {
      var canceled = token !== self._token;
      self.onSpeaking(false, line);
      return canceled ? 'canceled' : r.mode;
    });
  };

  ChatterboxVoice.normText = normText;
  ChatterboxVoice.fragKey = fragKey;
  root.ChatterboxVoice = ChatterboxVoice;
  if (typeof module !== 'undefined' && module.exports) module.exports = ChatterboxVoice;
})(typeof window !== 'undefined' ? window : globalThis);

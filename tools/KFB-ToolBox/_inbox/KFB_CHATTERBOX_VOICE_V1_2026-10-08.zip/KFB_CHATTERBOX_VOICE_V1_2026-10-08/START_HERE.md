# KFB ChatterBox Voice v1 · START HERE

**Status:** READY FOR WSA REVIEW · proposal + working reference implementation · no runtime promotion
**Date:** 2026-10-08
**Executor:** ChatGPT Work / WSA
**Owner:** existing WSA / KFB integration lead (audio and voice output; ChatterBox content stays with its current owner)
**Repository:** `georg-doc/kayfabizarro`. Suggested home for this folder: `skills/chat/workflows/KFB_CHATTERBOX_VOICE_V1_2026-10-08/`
**Language:** English (KFB runtime language). Georg's summary in German is directly below.

---

## Klartext für Georg

**Was ist der Stand?**
Für die Sprachausgabe der ChatterBox-Dialoge gibt es jetzt einen fertigen Baukasten. Elf Fantasy-Typen haben je eine eigene Stimme: Troll, Ork, Roboter, Vampir, Skelett, Geist, Goblin, Dämonenfürst, Lorekeeper, Bauer, Hexe. Dazu kommen 24 englische Beispielzeilen als Hörprobe und ein kleines Abspielprogramm, das Triplets aus fertigen Bausteinen zusammensetzt. Alles läuft ohne Grafikkarte, ohne Server und ohne laufende Kosten.

**Wer macht jetzt was?**
WSA prüft das Paket gegen den echten ChatterBox-Phrasen-Pool und schlägt vor, wo es im bestehenden Audio-Site andockt.

**Was musst du tun?**
`demo.html` öffnen (Doppelklick reicht) und pro Typ „Assembled“ gegen „Whole“ und „Browser“ anhören. Danach entscheidest du: Welche Stimmen passen, und reicht das Zusammensetzen aus Bausteinen?

**Was passiert danach?**
Nach deinem Hörentscheid vertont WSA einen echten Ausschnitt des Pools für drei Residents und baut ihn in eine bestehende Fläche ein.

---

## ⚠ Naming correction · read before anything else

**ChatterBox = the KFB dialogue system.** Residents speak in semantic Triplets (SHOW IT → SPIN IT → SELL IT), resolved from weighted Card/deck refs, shown in speech bubbles. Canon: `DECK_WORLD_SEED_CARD_PIPELINE_2026-10-04.md` §15, `GOLDEN_JOURNEY_MVP_2026-10-04.md`, `overworld/overworld/chatter-phrases.js`.

**It is NOT "Chatterbox TTS" by Resemble AI** (an open-source GPU speech model that happens to share the name).

Consequences, binding for this slice:
- Do **not** plan, price or request GPU servers, Resemble AI accounts, hosted Chatterbox-TTS APIs or any other paid speech service for ChatterBox.
- Any existing cost estimate that assumed "Chatterbox = Resemble TTS" is void and must be marked as such in its own document.
- When a document needs to mention the Resemble model, write **"Resemble Chatterbox-TTS (unrelated)"**. When it means KFB, write **"ChatterBox (KFB dialogue)"**.
- Renaming ChatterBox is Georg's decision, not part of this slice.

---

## Outcome

ChatterBox lines can be spoken with distinct character voices instead of the default browser voice. The voices are offline, deterministic, free to run, and they work in every KFB surface (GPT Site, Cloudflare mirror, claude.ai artifact, local file).

## What is in this folder

| Path | What it is |
|---|---|
| `demo.html` | Voice bench. Open locally. Plays every example as **Assembled** (fragments + beat gaps), **Whole** (one render) and **Browser** (today's fallback). It also has a custom Triplet box that shows the fallback route. |
| `data/voice_casting.json` | 11 archetype voice presets, 15 emotion modifiers (same set as `RESIDENT_AFFECT_EMANATA_MAP_PREP`) and the emotion fallback chain |
| `data/triplet_examples_en.json` | 22 illustrative Triplets (2 per archetype, across utopia/dystopia/protopia) plus 2 `{X}` template lines that reuse real frames from `chatter-phrases.js`. **Not canon.** |
| `tools/render_chatterbox_voice.py` | Build tool: Triplets → position-aware fragments + whole lines + `voice_manifest.json`. Piper + ffmpeg (+ espeak-ng for Robot). CPU only. |
| `tools/test_runtime.cjs` | 10 resolution tests for the runtime (`node tools/test_runtime.cjs`) |
| `tools/render-chatterbox-voice.github-action.yml` | Optional CI recipe so rendering never depends on one person's laptop |
| `runtime/chatterbox-voice.js` | Browser runtime, no dependencies: fragments → whole → live hook → browser voice; beat events for bubble reveal |
| `build/` | Rendered output: 71 fragments, 24 lines (whole + assembled), manifest, script twins for `file://` |
| `VOICE_CONTRACT.md` | Technical contract: data shapes, keys, routes, FX, emotion handling, integration seams, sizing |
| `LICENSES_AND_COSTS.md` | Voice model licenses (some Piper voices are non-commercial) and the cost picture (zero runtime cost) |

## Read first (existing KFB sources)

1. `skills/chat/PLAIN_LANGUAGE_HANDOFF_STANDARD.md`
2. `skills/chat/workflows/KFB_PLAYABLE_MVP_CONSOLIDATION_V1_2026-09-21/DECK_WORLD_SEED_CARD_PIPELINE_2026-10-04.md` §14–17
3. `skills/chat/RESIDENT_LIFE_SEMANTIC_MODEL_PREP_2026-10-06.md` (`chatterProfileRef`, §14 LLM-free default)
4. `skills/chat/RESIDENT_AFFECT_EMANATA_MAP_PREP_2026-10-06.json` (15 emotions)
5. `overworld/overworld/chatter-phrases.js`, `chatter-2d.js`, `bubble-ts.js` (phrase frames, 44-char bubble cut, speech/thought/whisper registers)
6. `skills/chat/workflows/KFB_AUDIO_SOUNDSCAPE_BASELINE_V1_2026-09-24/START_HERE.md` (ducking, voice intelligibility, accepted mix)
7. `skills/chat/KFB_SITES_FIRST_DELIVERY_POLICY_2026-10-04.md` (update the existing Site, no parallel Site)
8. `skills/chat/KFB_ACTIVE_WORK_MAP_2026-10-04.md`: **Triplet/ChatterBox #362 is HOLD.** This voice slice prepares output only. It does not reopen #362 without Georg.

## Protected boundary

- ChatterBox keeps owning content, speaker, timing and presentation budget. The voice layer is **output only** ("Bubble/Emote/TTS is output", §15).
- No second dialogue grammar, no new LLM call, no change to Triplet selection or weights.
- Example lines are illustrative. Real lines must resolve from canonical Card/deck refs. No invented Card titles.
- Anti-slop rules apply to anything spoken: no corporate humor, no em dashes, conflict over consensus.
- Non-commercial voice models stay out of public builds (see `LICENSES_AND_COSTS.md`).
- No new productive Site. Voice output docks into the existing Audio Site or the existing ChatterBox consumer.

## Recommended path (WSA to confirm or reject)

1. **Hybrid voicing.** Pool Triplets and `{X}` frames are spoken from pre-rendered fragments. Free LLM text outside the pool uses a live voice if the Site offers one. The browser voice is the last fallback.
2. **Render offline, ship static files.** Piper runs on any CPU (GitHub Actions runner or Coworker). The Site only hosts small MP3 files and `voice_manifest.json`. Nothing heavy runs in the Site.
3. **Integrate through one seam.** Where ChatterBox currently hands text to a bubble, add `voice.play({archetype, emotion, triplet})`. `onBeat` reveals bubble segments in sync. `whisper` bubbles map to a whisper preset, `thought` bubbles stay silent by default.
4. **Ducking** follows the accepted Audio Baseline: voice on top, music ducked while `onSpeaking(true)`.

## Done when

1. WSA has checked this folder against the real phrase pool and Resident profiles and returned the open questions below with answers or proposals.
2. Three real Residents (one per deck) speak **pool-resolved** lines through `runtime/chatterbox-voice.js` in an existing surface, with bubble beats in sync.
3. The fallback route is shown working: an unrendered LLM line still speaks.
4. Georg has made **one human listening decision**: which archetype voices to keep, and whether Assembled is good enough versus Whole.
5. A `RETURN.md` lists exact sources used, fragment count, total MB, licenses of every shipped voice, and the next safe step.

## Open questions for WSA

1. Where does the real Triplet/phrase pool live today (beyond `chatter-phrases.js`), and is it enumerable for pre-rendering?
2. Does the GPT Site environment expose a built-in TTS voice that could serve the live route? If yes: cost, latency, license.
3. Which surface is the first consumer: Overworld/Town bubbles, Golden Journey Residents or the Audio Site bench?
4. Mapping from Resident profiles to archetype presets (`chatterProfileRef` → `voicePreset`), plus per-Resident overrides (pitch, rate).
5. Should `thought` bubbles get a voice at all? Default: no.

## Technischer Nachweis — nur für die ausführenden Chats

- Rendered and tested in Claude Cowork sandbox, 2026-10-08: Piper 1.x (`piper-tts`), ffmpeg 6.1.1, espeak-ng 1.51
- `node tools/test_runtime.cjs` → 10/10
- Headless Chromium bench check: Assembled route played 3 fragments in order; custom Triplet resolved `fragments`, changed text resolved `browser`; no script errors
- LibriTTS-R speaker ids chosen by measured median F0 (97–245 Hz), not by ear. Georg's listening decides.

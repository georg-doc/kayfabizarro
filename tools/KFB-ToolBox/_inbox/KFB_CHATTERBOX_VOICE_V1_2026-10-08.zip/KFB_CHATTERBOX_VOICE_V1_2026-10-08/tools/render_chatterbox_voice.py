#!/usr/bin/env python3
"""KFB ChatterBox voice renderer (reference build tool, v0.1).

Renders ChatterBox Triplet lines to audio, offline, without GPU:
  * fragments/  one file per Triplet slot (position-aware intonation) -> runtime assembly
  * lines/      whole-line renders (for comparison / fixed lines)
  * voice_manifest.json  lookup table the browser runtime reads

Usage:
  python3 tools/render_chatterbox_voice.py \
      --casting data/voice_casting.json --lines data/triplet_examples_en.json \
      --voices /path/to/piper-voices --out build/

Requires: piper-tts (pip install piper-tts), ffmpeg, optional espeak-ng (robot preset).
Voices:   python3 -m piper.download_voices en_US-libritts_r-medium en_GB-cori-high en_GB-northern_english_male-medium
"""
import argparse, hashlib, json, os, subprocess, sys, tempfile

SR = 22050


def sh(cmd, **kw):
    r = subprocess.run(cmd, shell=isinstance(cmd, str), capture_output=True, text=True, **kw)
    if r.returncode != 0:
        raise RuntimeError(f"command failed: {cmd}\n{r.stderr[-800:]}")
    return r


def key_of(*parts):
    return hashlib.sha1("|".join(str(p) for p in parts).encode()).hexdigest()[:16]


def synth_raw(preset, text, length_scale, voices_dir, out_wav):
    """Render plain speech (no FX) to a mono WAV."""
    if preset["provider"] == "espeak":
        speed = int(preset.get("espeakSpeed", 150) / max(0.5, length_scale))
        sh(["espeak-ng", "-v", preset["voice"], "-p", str(preset.get("espeakPitch", 50)),
            "-s", str(speed), "-w", out_wav, text])
    else:
        model = os.path.join(voices_dir, preset["voice"] + ".onnx")
        p = subprocess.run([sys.executable, "-m", "piper", "-m", model, "-s", str(preset.get("speaker", 0)),
                            "--length-scale", f"{length_scale:.3f}", "-f", out_wav],
                           input=text, capture_output=True, text=True)
        if p.returncode != 0:
            raise RuntimeError(p.stderr[-800:])


def norm_text(t):
    """Must match normText() in runtime/chatterbox-voice.js."""
    return " ".join(t.lower().replace("\u2019", "'").strip().rstrip(".!?,").split())


def frag_lookup_key(archetype, emotion, slot, text):
    """Readable manifest key, rebuilt by the browser runtime: archetype|emotion|slot|normalized text."""
    return f"{archetype}|{emotion}|{slot}|{norm_text(text)}"


def pitch_filter(semitones, mode):
    if abs(semitones) < 0.05:
        return []
    ratio = 2 ** (semitones / 12)
    if mode == "natural":
        return [f"rubberband=pitch={ratio:.4f}:formant=preserved"]
    # creature: shift pitch and formants together, keep duration
    return [f"asetrate={SR}*{ratio:.4f}", f"aresample={SR}", f"atempo={1/ratio:.4f}"]


def apply_fx(preset, emo, in_wav, out_wav, trim=True):
    fx = preset.get("fx", {})
    st = fx.get("pitchSt", 0) + emo.get("pitchSt", 0)
    chain = [f"aresample={SR}"]
    chain += pitch_filter(st, fx.get("pitchMode", "creature"))
    chain += fx.get("chain", [])
    if emo.get("volumeDb"):
        chain.append(f"volume={emo['volumeDb']}dB")
    if trim:  # strip leading/trailing silence so fragments butt together cleanly
        t = "silenceremove=start_periods=1:start_threshold=-45dB"
        chain += [t, "areverse", t, "areverse"]
    # consistent loudness across Residents (single-pass EBU R128), then back to the base rate
    norm = ["loudnorm=I=-18:TP=-1.5:LRA=11", f"aresample={SR}", "alimiter=limit=0.95"]
    layer = fx.get("layerOctaveDown")
    if layer:
        base = ",".join(chain)
        low = ",".join(pitch_filter(-12, "creature"))
        graph = f"[0]{base},asplit[a][b];[b]{low},volume={layer}[l];[a][l]amix=inputs=2:normalize=0,{','.join(norm)}[o]"
        sh(["ffmpeg", "-loglevel", "error", "-y", "-i", in_wav, "-filter_complex", graph, "-map", "[o]", "-ac", "1", out_wav])
    else:
        sh(["ffmpeg", "-loglevel", "error", "-y", "-i", in_wav, "-af", ",".join(chain + norm), "-ac", "1", out_wav])


def to_mp3(wav, mp3):
    sh(["ffmpeg", "-loglevel", "error", "-y", "-i", wav, "-ac", "1", "-b:a", "64k", mp3])


def duration_ms(path):
    r = sh(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", path])
    return int(float(r.stdout.strip()) * 1000)


def slot_text(i, n, text):
    """Position-aware prompt: a trailing ellipsis keeps the pitch 'open' for every segment but the last;
    only the last segment gets the closing punctuation. Works for Triplets (n=3) and {X} templates (n=2..3)."""
    t = text.strip().rstrip(".!?,")
    end = text.strip()[-1] if text.strip()[-1] in ".!?" else "."
    if n == 1:
        return f"{t}{end}"
    if i == 0:
        return f"{t} ..."
    if i < n - 1:
        return f"... {t} ..."
    return f"... {t}{end}"


def silence(ms, out_wav):
    sh(["ffmpeg", "-loglevel", "error", "-y", "-f", "lavfi", "-i", f"anullsrc=r={SR}:cl=mono", "-t", f"{ms/1000:.3f}", out_wav])


def concat(wavs, out_wav):
    ins = sum([["-i", w] for w in wavs], [])
    graph = "".join(f"[{i}]" for i in range(len(wavs))) + f"concat=n={len(wavs)}:v=0:a=1[o]"
    sh(["ffmpeg", "-loglevel", "error", "-y", *ins, "-filter_complex", graph, "-map", "[o]", "-ac", "1", out_wav])


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--casting", required=True)
    ap.add_argument("--lines", required=True)
    ap.add_argument("--voices", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--no-assembled", action="store_true", help="skip pre-assembled comparison files")
    a = ap.parse_args()
    cast = json.load(open(a.casting))
    lines = json.load(open(a.lines))["lines"]
    os.makedirs(os.path.join(a.out, "fragments"), exist_ok=True)
    os.makedirs(os.path.join(a.out, "lines"), exist_ok=True)
    manifest = {"schema": "kfb.chatterbox.voice-manifest.v0.1", "sampleRate": SR, "fragments": {}, "lines": {}}
    tmp = tempfile.mkdtemp()
    for ln in lines:
        preset = cast["archetypes"][ln["archetype"]]
        emo = cast["emotions"].get(ln.get("emotion", "calm"), {})
        ls = preset.get("lengthScale", 1.0) * emo.get("rateMul", 1.0)
        gaps = [int(g * emo.get("gapMul", 1.0)) for g in preset.get("gapsMs", cast["gapsMsDefault"])]
        frag_wavs = []
        for i, part in enumerate(ln["triplet"]):
            lookup = frag_lookup_key(ln["archetype"], ln.get("emotion", "calm"), i, part)
            k = key_of(lookup)
            raw, fxw = f"{tmp}/r.wav", f"{tmp}/f{i}.wav"
            synth_raw(preset, slot_text(i, len(ln["triplet"]), part), ls, a.voices, raw)
            apply_fx(preset, emo, raw, fxw)
            rel = f"fragments/{k}.mp3"
            to_mp3(fxw, os.path.join(a.out, rel))
            manifest["fragments"][lookup] = {"file": rel, "ms": duration_ms(os.path.join(a.out, rel)),
                                        "archetype": ln["archetype"], "emotion": ln.get("emotion"), "slot": i, "text": part}
            frag_wavs.append(fxw)
        whole = " ".join(p.strip() for p in ln["triplet"])
        raw = f"{tmp}/w.wav"
        synth_raw(preset, whole, ls, a.voices, raw)
        apply_fx(preset, emo, raw, f"{tmp}/wf.wav")
        rel_whole = f"lines/{ln['id']}_whole.mp3"
        to_mp3(f"{tmp}/wf.wav", os.path.join(a.out, rel_whole))
        entry = {"text": whole, "archetype": ln["archetype"], "emotion": ln.get("emotion"), "deck": ln.get("deck"),
                 "whole": rel_whole, "gapsMs": gaps}
        if not a.no_assembled:
            seq = []
            for i, fw in enumerate(frag_wavs):
                seq.append(fw)
                if i < len(frag_wavs) - 1:
                    g = gaps[i] if i < len(gaps) else gaps[-1]
                    silence(g, f"{tmp}/g{i}.wav"); seq.append(f"{tmp}/g{i}.wav")
            concat(seq, f"{tmp}/as.wav")
            rel_as = f"lines/{ln['id']}_assembled.mp3"
            to_mp3(f"{tmp}/as.wav", os.path.join(a.out, rel_as))
            entry["assembled"] = rel_as
        manifest["lines"][ln["id"]] = entry
        print(f"ok {ln['id']:<15} {whole}")
    json.dump(manifest, open(os.path.join(a.out, "voice_manifest.json"), "w"), indent=1, ensure_ascii=False)
    # script twins so demo.html also works from file:// (no fetch needed)
    with open(os.path.join(a.out, "voice_manifest.js"), "w") as f:
        f.write("window.KFB_VOICE_MANIFEST = " + json.dumps(manifest, ensure_ascii=False) + ";\n")
    with open(os.path.join(a.out, "voice_casting.js"), "w") as f:
        f.write("window.KFB_VOICE_CASTING = " + json.dumps(cast, ensure_ascii=False) + ";\n")
    with open(os.path.join(a.out, "triplet_lines.js"), "w") as f:
        f.write("window.KFB_TRIPLET_LINES = " + json.dumps(lines, ensure_ascii=False) + ";\n")
    print(f"\n{len(manifest['fragments'])} fragments, {len(manifest['lines'])} lines -> {a.out}")


if __name__ == "__main__":
    main()

# ChatterBox Voice · Technical Contract v0.1

Scope: how a ChatterBox line becomes audio. ChatterBox content selection is out of scope and unchanged.

## 1 · Pipeline

```
ChatterBox line (Triplet or {X} template, archetype, emotion, register)
  → resolve route        fragments | whole | live | browser
  → play segments        segment 0 → gap → segment 1 → gap → segment 2
  → events               onBeat(i) for bubble reveal · onSpeaking(bool) for mouth flap + music ducking
```

## 2 · Line shape (what ChatterBox hands to the voice layer)

```js
{
  archetype: "troll",            // voice preset id from voice_casting.json (via Resident chatterProfileRef/voicePreset)
  emotion:   "annoyed",          // one of the 15 RESIDENT_AFFECT emotions; default "calm"
  triplet:   ["This bridge", "used to be free, until", "somebody invented paperwork."],
                                 // 2..n segments. Triplet = 3 (SHOW IT, SPIN IT, SELL IT).
                                 // {X} template = frame parts + the X fragment, e.g. ["We have a file on", "the broken lamp."]
  lineId:    "troll_01",         // optional: a pre-rendered whole line exists
  text:      "...",              // optional: free LLM text (route live/browser)
  register:  "speech"            // speech | whisper | thought (bubble-ts.js registers)
}
```

## 3 · Fragment keys

Manifest key = `archetype|emotion|segmentIndex|normalizedText`.
`normalizedText` = lower case, `’` → `'`, trimmed, trailing `.!?,` removed, whitespace collapsed.
The same function exists in the Python build tool (`norm_text`) and the runtime (`normText`). Change both or neither.

Segment index matters. The same words render differently as segment 0 (open intonation) and as the last segment (closing intonation). This is what makes assembled lines sound like one utterance.

## 4 · Routes

| Route | Condition | Sound | Cost |
|---|---|---|---|
| `fragments` | every segment has a fragment for the emotion or its fallback chain | natural, slightly staged by design (beat gaps) | none at runtime |
| `whole` | `lineId` has a pre-rendered whole line | most fluent | none at runtime |
| `live` | `liveTTS(text, preset, emotion)` provided and returns URL/Blob | depends on provider | provider cost |
| `browser` | always | weakest, per-archetype pitch/rate only | none |

Emotion fallback: requested emotion → `emotionFallback` chain → `calm`. This lets a Resident ship only 2–3 emotions.

## 5 · Rendering (build time)

- Engine: Piper (neural, CPU, ~1 s per short sentence), espeak-ng for the Robot preset.
- Position-aware prompts: non-final segments are rendered as `"text ..."` / `"... text ..."`, the final one as `"... text."`, then silence-trimmed.
- FX per archetype (ffmpeg): pitch shift (`creature` = pitch + formants for body size, `natural` = rubberband with preserved formants), filters (reverb, tremolo, soft clip, spectral "robot"), optional octave-down layer (Demon Lord).
- Loudness normalized per file (EBU R128, −18 LUFS, −1.5 dBTP) so Residents sit at one level under the Audio Baseline mix.
- Output: mono MP3 64 kbit/s, 22.05 kHz. A fragment is typically 0.5–3 s and 4–24 KB (ghost and demon presets run longest because of reverb and slow rate).

## 6 · Sizing

`fragments ≈ pool segments × archetypes using them × emotions rendered`

Example: 300 pool segments, 6 archetypes each using a third of them, 3 emotions each comes to about 1,800 fragments × ~10 KB ≈ **18 MB**. Fine for a Site or a mirror, too big for a single claude.ai artifact (16 MB cap). In artifacts, ship only the active Resident subset.

## 7 · Integration seams (proposal)

| Existing piece | Seam |
|---|---|
| `chatter-2d.js` speak (44-char bubble) | call `voice.play(line)` where the bubble text is set; reveal segments on `onBeat` |
| `bubble-ts.js` registers | `whisper` → preset variant with whisper FX or browser fallback at low volume · `thought` → silent by default |
| Resident profile | `chatterProfileRef` / new `voicePreset` → archetype id + optional `{pitchSt, rateMul}` overrides |
| Audio Baseline | `onSpeaking(true)` → duck music per accepted AUDIO-CAL-01 settings |
| Mouth / emanata | Stage 1: `onSpeaking` + per-fragment random flap. Stage 2: amplitude via AnalyserNode on the playing element |

## 8 · Live route (only if WSA finds a suitable provider)

`liveTTS(text, preset, emotion) → Promise<url|Blob|null>`. Returning `null` falls back to browser voice. The provider must:
- accept a voice choice per archetype (or the archetype FX are applied client-side, not in scope v1)
- stay inside the existing Site / owner boundary
- never receive player personal data

## 9 · Tests

- `node tools/test_runtime.cjs`: 10 resolution tests (exact hit, normalization, emotion fallback, `{X}` templates, whole, live, browser, file existence)
- Bench: `demo.html`, three buttons per line, route chip shows the chosen path

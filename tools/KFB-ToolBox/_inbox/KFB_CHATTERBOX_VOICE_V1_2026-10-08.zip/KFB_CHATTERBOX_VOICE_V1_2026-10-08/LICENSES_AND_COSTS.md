# Licenses and Costs · ChatterBox Voice v1

## Costs

| Item | Cost |
|---|---|
| Rendering fragments (Piper, ffmpeg, espeak-ng on any CPU, e.g. a GitHub Actions runner on a public repo) | none |
| Hosting (static MP3 + JSON inside an existing Site or mirror) | within existing hosting |
| Runtime playback (browser audio) | none |
| GPU, Resemble AI, hosted "Chatterbox-TTS" | **not needed, not planned** (see naming correction in START_HERE) |
| Optional live voice for free LLM text | only if WSA finds a provider worth it; decided separately |

## Software

| Tool | License | Note |
|---|---|---|
| Piper (`piper-tts`, OHF-Voice/piper1-gpl) | GPL-3.0 | Used at **build time** only. Shipping the generated audio does not ship Piper. |
| espeak-ng | GPL-3.0 | Build time only (Robot preset). Same reasoning. |
| ffmpeg | LGPL/GPL depending on build | Build time only. |
| `runtime/chatterbox-voice.js` | KFB-owned | No third-party code. |

The GPL notes are a technical reading, not legal advice.

## Voice models (dataset licenses from each Piper MODEL_CARD)

| Voice | Used for | Dataset license | Public build? |
|---|---|---|---|
| `en_US-libritts_r-medium` (904 speakers) | Troll, Orc, Vampire, Skeleton, Goblin, Demon Lord, Farmer, Witch, Robot alt | CC BY 4.0 (LibriTTS-R) | yes, with attribution |
| `en_GB-cori-high` | Ghost | public domain (LibriVox) | yes |
| `en_GB-northern_english_male-medium` | Lorekeeper | CC BY-SA 4.0 | yes, with attribution; check share-alike reading |
| espeak-ng `en-us+klatt3` | Robot | GPL-3.0 (engine), rule-based voice | yes (audio output) |
| `en_GB-semaine-medium` (prudence, spike, obadiah, poppy) | **not used**: emotional speakers, tempting for Orc/Troll | CC BY-NC-SA 4.0 | **no**: prototype/private only |
| `en_US-ryan-high` | not used | CC BY-NC-SA 4.0 | **no** |
| `en_US-lessac-high` | not used | Blizzard 2013 license (research) | **no** without review |
| `en_GB-alan-medium` | not used | unclear ("see URL") | **no** without review |

Rule for WSA: every shipped voice gets a line in `RETURN.md` with its dataset license. Attribution text for CC BY voices goes into the Site credits.

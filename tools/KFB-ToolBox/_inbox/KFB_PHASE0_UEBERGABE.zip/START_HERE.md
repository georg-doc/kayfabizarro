# Phase 0 · Übergabe an den nächsten Chat

**Was das ist:** ein unabhängiger Vorbefund zu den zwei KFB-Briefing-Fehlschlägen vom 15.09.2026, erstellt von Claude Coworker.
**Status:** `PROPOSAL`. Kein DECISION, keine IMPLEMENTATION, keine Georg-Abnahme.
**Bestellt war:** ein Audit mit neun Dokumenten. **Geliefert ist eins**, mit Begründung warum.

---

## Das Ergebnis in einem Satz

> **Was in der Abnahmeliste stand, wurde gebaut. Was nicht drinstand, wurde weggelassen oder frei erfunden.**

Belegt an sechs Stellen im Wortlaut des ToolBox-Briefs. Einzelheiten in `PHASE0_BEFUND.md`.

**Damit trägt die Prämisse des Auditauftrags nicht.** Der Brief war nicht mehrdeutig, er war sogar detailliert. Die Frage ist nicht, warum er unklar war, sondern warum ein klarer Brief das Falsche erzeugt hat.

---

## Was fehlt und warum

Der **Birthday-Teil ist ungeprüft**. Das Auditpaket verweist auf `georg-doc/KFB-Travel-Globe` PR #8, gepinnt auf `bbf78434aea3ea25e3f6d2ee4e8ec673af1cf2b8`.

```
git cat-file -t bbf7843…   could not get object info
alle 13 Branches lokal     neuester Commit 13.09.
BIRTHDAY im Arbeitsbaum    0 Treffer
BIRTHDAY in der Historie   0 Treffer
```

Der Vorfall ist vom **15.09.**, die lokale Arbeitskopie endet am **13.09.** Die Birthday-Arbeit liegt nur auf der Gegenstelle.

**Das ist selbst ein Befund:** das Auditpaket verweist auf Belege an einem Ort, von dem aus sie nicht erreichbar sind. Wer der Leseordnung folgt, läuft an derselben Stelle auf.

---

## Der nächste Schritt, ohne Terminal

**In GitHub Desktop:**

1. `File → Add Local Repository`
2. Ordner wählen: `~/.codex/.chatgpt-projects/g-p-6977…/travel-globe`
3. Oben auf **`Fetch origin`** klicken

Danach liegen die Originalbriefs unter `_handover/BIRTHDAY_STARTSCREEN_ASTRA_2026-09-15/`, der Rückgabebericht unter `qa/BIRTHDAY/RETURN.md` und die sieben Bildschirmfotos lokal.

**Dann ist die Gegenprobe möglich:** bestätigt der Birthday-Fall dasselbe Muster, sind die restlichen acht Dokumente überflüssig. Widerlegt er es, war der Vorbefund zu schnell.

---

## Was ich vorschlage statt der acht restlichen Dokumente

Zwei Regeln, kein Regelwerk:

**Regel 1 · Was nicht in der Abnahme steht, existiert nicht.**
Jede identitätstragende Eigenschaft bekommt eine Zeile in der Abnahmeliste, oder sie wird ausdrücklich als *darf fehlen* markiert. Kein drittes Feld.

**Regel 2 · Ein Bild, bevor gebaut wird.**
Ein Standbild aus der echten Pipeline, vor dem Ausbau. Fällt die Entscheidung negativ aus, hat es Minuten gekostet statt zwölf Prozent eines Wochenbudgets.

---

## Für den empfangenden Chat

Dieser Befund ist **ohne** die ChatGPT-Postmortems entstanden, damit er unabhängig von ihnen ist. Wer ihn weiterverarbeitet, sollte dasselbe tun: erst die Originalbriefs, dann die Rettungsdokumente.

Und er ist angreifbar. Die Zählung in `PHASE0_BEFUND.md` §2 B6 (39 Oberflächenpflichten, 11 Abnahmetore) lässt sich am Originalbrief nachzählen. Wenn die Zahl nicht stimmt, fällt das Argument.

```
PHASE0_BEFUND.md    der Befund, sechs Stellen am Wortlaut belegt
START_HERE.md       diese Datei
```

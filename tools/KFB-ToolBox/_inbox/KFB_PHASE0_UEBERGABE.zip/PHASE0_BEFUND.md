# PHASE 0 · Befund

**Gegenstand:** die zwei Briefing-Fehlschläge vom 15.09.2026.
**Zweck dieser Phase:** entscheiden, ob die neun bestellten Dokumente überhaupt das richtige Thema haben.
**Gelesen:** `START_HERE.md` und `SOURCE_INDEX.md` des Auditpakets, und der gescheiterte ToolBox-Brief `tools/KFB-ToolBox/_handover/UI_CRITIQUE_REWORK_WS0_2026-09-15/START_HERE.md` im vollen Wortlaut.
**Ausdrücklich nicht gelesen:** die Postmortems, die Rettungsdokumente, die Birthday-Unterlagen. Die ersten beiden mit Absicht, das dritte weil unerreichbar (§4).

**Markierung nach §E des Auftrags:** `[Q]` quellengestützt, `[B]` beobachtet, `[G]` Georgs Ablehnung, `[F]` meine Folgerung, `[V]` mein Vorschlag.

---

## 1 · Die Prämisse des Auftrags trägt nicht

Der Auftrag heißt Briefing-Audit und unterstellt, die Briefs seien mehrdeutig gewesen.

**Der ToolBox-Brief ist nicht mehrdeutig.** `[Q]` Er hat 13 Abschnitte, benennt vier Prüfgrößen mit Pixelmaßen, trennt UI-, Rig- und Material-Eigentümerschaft ausdrücklich, führt ein Statusvokabular, verbietet generische Aussagen wie `make it cleaner`, und liefert einen Rückgabevertrag mit sechs Punkten. Nach üblichen Maßstäben ist das ein guter Brief.

**Trotzdem kam das Falsche heraus.** Also ist die Frage nicht, warum der Brief unklar war, sondern **warum ein klarer Brief das Falsche erzeugt hat.**

---

## 2 · Der literale Ausführer, sechs Befunde am Wortlaut

### B1 · Die visuelle Sprache steht nirgends im Brief

**Beobachtete Drift** `[Q]`: DocCheck-Rot und dunkel, obwohl Studio Papier und Licht ist.

**Wortlaut:** im ganzen Brief steht **kein einziges Wort** über Palette, Helligkeit, Tonalität oder den Studio-Look. `[B]` Farbe kommt nur zweimal vor, beide Male als Funktion im Werkzeug: `#RRGGBB` für Materialzonen und eine kuratierte Palette für den Actor. Nicht für die Anwendung selbst.

**Literale Lesart** `[F]`: der Ausführer wählt eine eigene Oberflächenfarbe. In einem Umfeld, in dem DocCheck vorkommt, ist Rot eine naheliegende Wahl.

**Das ist keine Mehrdeutigkeit, sondern eine Auslassung.** Die Reparatur ist nicht präziseres Formulieren, sondern ein fehlender Satz.

### B2 · Studio v17 kommt im Brief nicht vor

**Beobachtete Drift** `[Q]`: der Pilot wurde zum Produktmodell befördert, obwohl Studio v17 die funktionale Quelle ist.

**Wortlaut:** §1, der Auftrag in einem Satz, lautet *„Nimm den realen, bereits funktionalen KFB ToolBox Pilot v1 als Ausgangspunkt"*. `[Q]` Die Leseordnung in §2 nennt neun Dokumente. **Studio v17 ist keines davon.** Der Begriff kommt im gesamten Brief nicht vor. `[B]`

**Literale Lesart** `[F]`: der Ausführer weiß nicht, dass Studio v17 existiert, geschweige denn dass es die Produktwahrheit ist. Er tut genau das, was in Satz eins steht.

**Die Quellenhierarchie ist nicht falsch verstanden worden. Sie stand nicht im Brief.**

### B3 · Carl ist das erste Abnahmekriterium

**Beobachtete Drift** `[Q]`: Carl wurde als UI-Modell behandelt, obwohl er QA-Vorrichtung ist.

**Wortlaut:** §10, erste Zeile der Abnahme: *„kompletter Carl-Workflow ohne Toolwechsel"*. `[Q]`

**Literale Lesart** `[F]`: ein Ausführer richtet die Oberfläche auf das aus, woran sie gemessen wird. Carl zum UI-Modell zu machen ist unter diesem Brief **keine Drift, sondern Regelbefolgung.**

### B4 · Das Roster hat keinen Boden

**Beobachtete Drift** `[Q]`: Roster auf vier Sonderfiguren eingedampft.

**Wortlaut:** §5 verlangt *„eine Auswahlquelle für Actors"*, §7.4 *„Actor → Rig family → state slot"*. **Keine Zahl, keine Untergrenze, kein Wort darüber, dass das Roster identitätstragend ist.** `[B]`

**Literale Lesart** `[F]`: der Ausführer zeigt eine Handvoll. Vier erfüllt *„eine Auswahlquelle"* vollständig.

### B5 · Talk fällt weg, weil Talk kein Tor ist

**Beobachtete Drift** `[Q]`: Talk, Voice und Bubbles weggelassen.

**Wortlaut:** Talk steht im Namen eines Schritts, `Motion & Talk`, und als **ein Aufzählungspunkt unter dreizehn** in §6. In §10, der Abnahme, kommt Talk **gar nicht vor**. `[B]` Bubbles kommen im ganzen Brief nicht vor. `[B]`

**Literale Lesart** `[F]`: **nichts in der Abnahme fällt durch, wenn Talk fehlt.** Unter Zeit- oder Budgetdruck fällt zuerst das weg, was nicht gemessen wird.

### B6 · Die Unordnung ist die Summe des Briefs

**Beobachtete Drift** `[Q]`: gestapelte Kopfzeilen, Karten in Karten, zu viel Erklärtext, Bühne entwertet, progressive disclosure wurde zu Unordnung.

**Gezählt** `[B]`:

```
§5  Grundprinzipien          10 Verpflichtungen
§6  Prüfe mindestens         13
§7.1 Color/Material Zones    11
§7.5 Living authoring UI      5
                             ──
                             39 einzelne Oberflächenpflichten

§10 Abnahme                  11 Tore
```

Und mittendrin, in §5, steht *„progressive disclosure statt 100 Regler gleichzeitig"*.

**Literale Lesart** `[F]`: der Brief fordert Reduktion und zählt gleichzeitig 39 Dinge auf, die vorhanden sein müssen. Wer alle 39 sichtbar erfüllt, baut eine dichte Oberfläche. **Karten in Karten und gestapelte Kopfzeilen sind die bauliche Form von neununddreißig nachzuweisenden Pflichten.** Die Anweisung und die Liste ziehen gegeneinander, und die Liste gewinnt, weil die Liste geprüft wird.

Dazu passt der Befund zur Bühne: sie bekommt **einen** Satz, *„Die Bühne bleibt möglichst stabil"*, gegen 39 Pflichten an Panels, Inspektoren und Feldern. Dass sie entwertet wurde, ist proportional zum Brief. `[F]`

---

## 3 · Die Diagnose, und sie ist schärfer als beide Ausgangsthesen

Ich bin mit zwei Hypothesen hineingegangen: **Wortlautproblem** oder **Rückkopplungsproblem**. Beide sind zu grob.

> **Was in §10 stand, wurde gebaut. Was nicht in §10 stand, wurde weggelassen oder frei erfunden.**

Prüf es an allen sechs Befunden:

| Sache | in der Abnahme? | Ergebnis |
|---|---|---|
| Carl-Workflow | ja, Position 1 | gebaut, sogar zum Modell erhoben |
| Colorpicker, Hex, Esc | ja | gebaut |
| vier Prüfgrößen | ja | gebaut |
| Export-Roundtrip | ja | gebaut |
| visuelle Sprache | **nein** | frei erfunden, DocCheck-Rot |
| Studio v17 als Quelle | **nein** | nicht benutzt |
| Rostergröße | **nein** | auf vier eingedampft |
| Talk, Voice, Bubbles | **nein** | weggelassen |
| Bühne | **nein** | entwertet |

**Die Prosa des Briefs hat viel Richtiges gesagt. Die Abnahmeliste hat entschieden, was passiert ist.** `[F]`

Das erklärt auch den Birthday-Fall, so wie er im Auditpaket beschrieben wird: zehn Tests grün, saubere Konsole, Clip-Bindung und Audio geprüft, und trotzdem abgelehnt. `[Q]` Dieselbe Mechanik. Gemessen wurde, was messbar war, und das Ergebnis war nicht das Produkt.

---

## 4 · Was ich nicht prüfen konnte, und warum

Der Birthday-Teil fehlt vollständig. `[B]`

```
SOURCE_INDEX A1/A2 verweist auf   georg-doc/KFB-Travel-Globe, PR #8
gepinnter Stand                   bbf78434aea3ea25e3f6d2ee4e8ec673af1cf2b8
```

**In deiner lokalen Arbeitskopie existiert dieser Stand nicht.** `[B]` Geprüft in `~/.codex/.chatgpt-projects/…/travel-globe`:

```
git cat-file -t bbf7843…      could not get object info
Branches, alle 13              neuester Commit 2026-09-13
BIRTHDAY im Arbeitsbaum        0 Treffer
BIRTHDAY in der Historie       0 Treffer
git ls-remote origin           could not read Username
```

Der Vorfall ist vom **15.09.**, die Arbeitskopie endet am **13.09.** Die Birthday-Arbeit liegt nur auf der Gegenstelle und wurde hier nie geholt. Netz hat die Maschine, Zugangsdaten nicht.

**Das ist selbst ein Befund** `[F]`: das Auditpaket verweist auf Belege an einem Ort, von dem aus sie nicht erreichbar sind. Ein externer Prüfer, der der Leseordnung folgt, läuft an derselben Stelle auf.

**Ein Befehl behebt es:**

```bash
cd ~/.codex/.chatgpt-projects/g-p-6977ebcd1c148191bf212fdabaa38ffe/travel-globe
git fetch origin
```

Danach liegen Briefs, `qa/BIRTHDAY/RETURN.md` und die sieben Bildschirmfotos hier, und ich sehe sie mir an, ohne dass du etwas hochladen musst.

---

## 5 · Was daraus folgt für die restlichen acht Dokumente

**Die Autopsien lohnen sich, aber kürzer als bestellt.** Das Muster ist an sechs Stellen belegt und wiederholt sich. Eine zweite Autopsie am Birthday-Fall dient der Gegenprobe, nicht der Sammlung.

**Drei Vorlagen lohnen sich nicht.** Wenn die Abnahmeliste entscheidet, ändert eine bessere Briefvorlage nichts, solange die Liste unvollständig bleibt. `[V]`

**Was tatsächlich fehlt, sind zwei Regeln, nicht ein Regelwerk** `[V]`:

**Regel 1 · Was nicht in der Abnahme steht, existiert nicht.** Jede identitätstragende Eigenschaft bekommt eine Zeile in der Abnahme, oder sie wird ausdrücklich als *darf fehlen* markiert. Kein drittes Feld. Der ToolBox-Brief hätte damit gezwungenermaßen Farbwelt, Rostergröße, Talk und Bühne benannt, weil sie sonst als *darf fehlen* dagestanden hätten und du das gesehen hättest.

**Regel 2 · Ein Bild, bevor gebaut wird.** §11 verlangt Bildschirmfotos als Teil der **Rückgabe**, also nachdem alles gebaut ist. `[Q]` Es gibt im ganzen Ablauf keinen Punkt, an dem dir etwas gezeigt wird, bevor Aufwand entsteht. Ein Standbild aus der echten Pipeline, vor dem Ausbau. Sagst du nein, hat es Minuten gekostet statt zwölf Prozent eines Wochenbudgets.

**Und eine Beobachtung zum Auftrag selbst** `[F]`: er bestellt neun Dokumente, um einen Fehlschlag zu untersuchen, dessen Muster lautet *zu viele Pflichten, zu wenig gemessene Böden*. Neun weitere Dokumente sind mehr Pflichten. Die Reparatur ist eine kürzere Abnahmeliste mit vollständiger Abdeckung, nicht ein längeres Regelwerk.

---

*Gelesen wurde der ToolBox-Brief im vollen Wortlaut, das Auditpaket-Onboarding, und der Zustand der Travel-Globe-Arbeitskopie. Die Postmortems sind bewusst ungelesen, damit dieser Befund unabhängig von ihnen entstanden ist. Wenn eine der Zahlen oben falsch aussieht, ist der erste Verdächtige meine Zählung und nicht euer Text.*

# Antwort an den Custom GPT

Ja. Du sollst `skills/chat` und die projektbezogenen ToolBox-/ClayBound-Dateien als kanonische Routing- und Workflow-Quellen behandeln, aber nicht als statische ewige Wahrheit.

Ich gebe dir einen kuratierten Snapshot mit:
- den relevanten KFB-Routing- und Workflow-Regeln,
- dem aktuellen ClayBound-/Clay-Asset-Owner-Modell,
- den echten `produce-clay-assets`-Skillregeln,
- der 50er Asset-Queue,
- und den aktuellen Blender-MCP-Grenzen.

Wichtig:

1. **Live-GitHub-Stand hat immer Vorrang** vor dem Upload-Snapshot.
2. Wenn Owner, Branch, Stage-Route, Return oder Blender-Handoff nicht verifiziert sind, **nichts erfinden**.
3. In diesem Fall den Output als `UNVERIFIED` bzw. `GENERIC KFB-COMPATIBLE HANDOFF` kennzeichnen.
4. Für Clay Assets gilt:
   - genau **ein Asset pro Review-Turn**,
   - keine automatische Batch-Produktion,
   - echte Tile-/Alpha-/Data-Map-QA,
   - Human Gate vor dem nächsten Asset,
   - keine automatische Blender-, Asset-Librarian-, Stage- oder Live-Promotion.
5. ClayBound/KlayBound ist visueller Donor, kein neuer Runtime- oder Character-Owner.
6. Für Blender gilt derzeit: `CLAY-BLENDER-POC-01` bleibt HOLD, bis mindestens eine Core-Clay-Textur human-approved ist. Es gibt noch keinen universell validierten Clay-Blender-MCP-Handoff.

Aktueller Asset-1-Stand:
`ChatGPT-Bild 26. Sept. 2026, 17_38_23.png` existiert als Kandidat. Plugin-QA/Analyse läuft noch; Human Approval und Seamless-PASS stehen noch aus.

Wenn der Upload-Snapshot später älter als der GitHub-Stand ist, behandle ihn als Referenz und fordere für konkrete Produktionsclaims eine GitHub-Verifikation an.

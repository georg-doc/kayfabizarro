# Source Manifest

Repository: `georg-doc/kayfabizarro`

Curated source snapshot HEAD: `8ed9acd163581019006b2cc2b316ea51c211a027`

The uploaded context is a snapshot. Live GitHub state overrides it.

| Path / source | Git blob SHA |
|---|---|
| `skills/chat/START_HERE.md` | `d623fb0f43bce5711d53d43c1539ad196a96c3df` |
| `skills/chat/REGISTRY.json` | `323dfa35786a4aa77b75b2b1fccebb0ccc86672c` |
| `skills/chat/CHAT_GITHUB_KFB_STAGE_WORKFLOW.md` | `7fbc7102a8c7c6e0aa3875bf272678ef201c1dca` |
| `skills/chat/FRESH_CHAT_SLICE_PROTOCOL.md` | `b3a3141f9279f37a3539b2c7f408b54a5746fc09` |
| `skills/chat/GATE_PROPORTIONALITY_TOKEN_BUDGET_PROTOCOL.md` | `fb23165fc78d0c29df5c29af9516d1770be54f3d` |
| `skills/chat/ANTI_SLOP_VISUAL_BRIEF_GUARDRAILS.md` | `885584939e4c3be77eb08dc9828cee78a47db738` |
| `tools/KFB-ToolBox/START_HERE.md` | `15e736e36895b47b5cb9e1cae4ac3c0d0b12cfe1` |
| `.../CLAYBOUND_INPUT_INTAKE_2026-09-26.md` | `cb8a163bc40ca4b528e7b8b7a11def5dd6bfb8d4` |
| `.../RESEARCH_ROUND_01_REVIEW.md` | `93223c7362173555110b0001c1b1a698bd418e3c` |
| `.../CUSTOM_GPT_KFB_CONTEXT_2026-09-26.md` | `9e5c48189f71d34505378ec6bc3736c795c8fef0` |
| `plugin/plugin.json` | `080efe19b596f1ee0b0bad779806e1b141faf14f` |
| `plugin/SKILL.md` | `fb9059c59eea21e25dc48ede12cb939892a47a8c` |
| `plugin/asset-queue.md` | `a4f1b5756a4b3cbd29900f2a67fd9e66f6956c84` |

Current Asset 1 candidate: `ChatGPT-Bild 26. Sept. 2026, 17_38_23.png` · blob `58dca5d8177e113807776b370b9b0d03ae846bd8` · QA/Human gate pending.

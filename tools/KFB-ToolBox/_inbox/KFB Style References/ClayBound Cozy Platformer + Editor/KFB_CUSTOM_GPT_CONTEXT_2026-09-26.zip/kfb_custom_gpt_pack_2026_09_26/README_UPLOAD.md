# Upload recommendation

For the Custom GPT, upload at minimum:

1. `KFB_CUSTOM_GPT_CONTEXT_2026-09-26.md`
2. `plugin/SKILL.md`
3. `plugin/asset-queue.md`

Optional:
- `plugin/plugin.json`
- `SOURCE_MANIFEST.md`

`CUSTOM_GPT_REPLY_DE.md` is the ready-to-paste answer to the GPT.

The context is a snapshot. Live GitHub state always wins.

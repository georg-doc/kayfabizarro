# KNOWN_ISSUES

## 1 · SOURCE_GAP · Audio-Manifest fehlt
`src/petstudio-v9/kfb-pinball-audio.js` lädt `./kfb-pinball-sfx.json`. Die Datei liegt **nicht** im Baum. Im Repo vorhanden: `skills/KFB PetStudio/KFB Pet Studio v9-1/pet-studio-v9_2026-08-28_ws0-rehome/kfb-pinball-sfx.json` (18 058 B, Blob `5f7b52e2666a`). Folge: Audio-Pfad `BLOCKED`. **Nicht rekonstruiert** — eine aus der Dokumentation nachgebaute Klangliste wäre eine Erfindung.

## 2 · Schriften hängen an einem beweglichen Zweig
Die `@font-face`-URLs zeigen auf `…/main/…`. `main` bewegt sich. Für den Betrieb auf einen Commit pinnen oder — besser — same-origin unter `/fonts/` ausliefern und die URLs auf `./fonts/` kürzen (Rückweg steht als Kommentar über dem ersten `@font-face`).

## 3 · `FrizzleBob_Yellow.gltf` hat keine GitHub-Quelle
Gesucht über 8 647 Repo-Dateien, kein Treffer. Liegt deshalb im Paket und ist als `NEW_ASSET_REQUIRES_GITHUB_IMPORT` markiert. Bis zum Import ist der Spenderkopf (Schädel + Ohren) an eine Datei gebunden, die nur in diesem Paket existiert.

## 4 · Roster-Indizes sind nicht stabil
Im Projektbaum lag Klo-Rolli auf Platz 26, im Exportbaum auf 27 (GothGirl rutschte auf 26). Der Roster entsteht aus Vertrag + Profilen; wer nach Index adressiert, adressiert falsch. **Immer nach `id`**: `roster.findIndex(p => p.id === 'klo-rolli')`.

## 5 · `three` kommt aus dem Netz
Import-Map auf `unpkg.com/three@0.160.0`. Ohne Netz startet kein Blatt. Für den Betrieb: three same-origin ausliefern und die Import-Map umstellen.

## 6 · Was ungeprüft ist, ist ungeprüft
`FEATURE_PARITY.md` hat viele `NOT_TESTED`. Das ist kein Versehen: Pose, Motion, Voice, Szene-Roundtrip und der Resource Picker sind am Exportbaum nicht bedient worden. Der Code ist da; die Abnahme fehlt.

## 7 · Studio v18 ist Donor, nicht Ziel
`src/KFB FrankenStein Studio v18.dc.html` trägt Fixes, die im Stage-First-Blatt noch nicht alle stehen (u. a. Fein-Arbeit an Mund, Textur-Wäsche, Bodenhöhe). Wer Stage-First weiterbaut, holt sie **von dort** — und baut sie nicht neu.

# RETURN · KFB-COMBAT-ARENA_CLAUDE_DESIGN_SESSION_CUT_2026-09-30_r1 · Claude Design → WSA

Status: **DESIGN CANDIDATE**. Voller lauffähiger Workspace-Stand, keine Änderung gegenüber dem Workspace.
Entry Point: `KFB Combat Arena KayKit.dc.html` · Rückfall: `index.html`.
Tests: siehe TEST_REPORT.md (Export-Prüfungen PASS; Handtest, Münze, Gate 6, Licht/Tinte NOT_RUN).
Externe Abhängigkeiten: three.js 0.160.0 (unpkg, gepinnt), KayKit-GLBs + KFB_Coin_01.glb (kayfabizarro@main, UNPINNED), Nunito Sans (Google Fonts).
REPLAY_DEPENDENCY_MISSING: `media/kfb/KayfaBizarro_Card_Backside_01_lowrez.png` (Kartenrückseite, 404, schon im Workspace).
SOURCE_REQUIRED: FrizzleBob Driver v3/v5 (`frizzlebob-driver-adapter.v2.js`).
Next Gate: Georgs Handabnahme im sichtbaren Tab.

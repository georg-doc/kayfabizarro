repo: georg-doc/KFB-Combat-Arena
branch: main

## Last sync
date: 2026-09-30T01:24:59Z
commit: f6a59ad15b9ffcf3164b0ab013f223962b63f61f

### Updated in this project
- CD-COMBAT-CLAY-KAYKIT-01: KayKit-Arena-Kandidat (KFB Combat Arena KayKit.dc.html)
- Knet-Racer-HUD übernommen, Controls ins Pause-Overlay
- Reward-/FB-Assets aus main nachgezogen (Skull, Trank, Bomben, FrizzleBob_Yellow)

## Screen map
| Project screen | Repo files |
|---|---|
| index.html | index.html, combat-arena-v1..v4/*, modules/*, studio-v3/* (B0-Kopie) |
| KFB Combat Arena KayKit.dc.html | index.html, combat-arena-v4/fun.v4.js, combat-arena-v2/mobs.v2.js, combat-arena-v2/gunfight.v2.js, combat-arena-v4/rewards.v4a.js, assets/4a/*, assets/5a/*, assets/models/* |
| CD-COMBAT-CLAY-KAYKIT-01 Vorlauf.dc.html | _handover/C0_REENTRY/OWNER_MAP.md, WSA_START.md, docs/combat-arena-v5/LIVING_combat-arena-v5.md, combat-arena-v1/enemies.v1.js, modules/kfb-combat-def.js, combat-arena-v2/gunfight.v2.js, combat-arena-v3/runflow.v3.js |

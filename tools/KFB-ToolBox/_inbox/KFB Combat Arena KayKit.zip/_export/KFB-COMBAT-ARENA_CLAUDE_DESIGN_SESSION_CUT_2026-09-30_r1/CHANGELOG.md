# CHANGELOG

## r1 · 2026-09-30 · Session-Cut
- Erster Voll-Export des Workspace als lauffähiger Session-Cut. Keine Codeänderung in diesem Schritt.

## 30.09.2026 · CD-COMBAT-CLAY-KAYKIT-01 (Runde 3)
- Licht gedämpft (Belichtung ×0,85, Sheen ×0,45, envMapIntensity 0,3), `?light=`.
- Zensur-Tinte als beleuchtete Tusche-Knete, empfängt Schatten, `?ink=flat`.
- Gegnerwürfe aus Handhöhe (0,50 statt 0,72 Körperhöhe), vy kompensiert, Wurfcode abgesichert.

## 30.09.2026 · CD-COMBAT-CLAY-KAYKIT-01 (Runde 1–2)
- KayKit-Roster über `mb.R`/`mb.loader`.
- `fun.v6k.js` mit neuem HUD-DOM, Racer-HUD-Look.
- Settings → Pause/Hilfe-Overlay; Enemy size + Inspector entfernt.
- Erklärtexte, Wortmarke, Rüsten-Banner, Start-Hinweis, Controls-Leiste entfernt.
- K2-Knetmaterial auf Actors/Props/Munition, Clay-VFX-Pool (Normal/Low/Legacy).
- Reward-/FB-Assets aus main nachgezogen (Skull, Trank, Bomben, FrizzleBob_Yellow).

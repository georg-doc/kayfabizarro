# TEST_REPORT · Session-Cut r1 · 2026-09-30T04:22:59.094Z

Nur in dieser Export-Session ausgeführte Prüfungen heißen hier PASS. Gameplay-Nachweise stammen aus der Vorsession (Details: `_handover/CD-COMBAT-CLAY-KAYKIT-01/TEST_REPORT.md`).

| Prüfung | Ergebnis | Nachweis |
|---|---|---|
| Closure-Analyse ab Entry Point (statisch) | PASS | 92 lokale Dateien erreicht, alle im ZIP. Nicht auflösbare Treffer sind Kommentare oder remote-präfixierte Pfade (EXPORT_MANIFEST → closure_unresolved). |
| importmap-Ziele `vendor/addons/*` | PASS | GLTFLoader, RoomEnvironment, SkeletonUtils vorhanden |
| Secret-Scan (Tokens, PATs, Keys, signierte URLs) | PASS | nur base64-Buffer in glTF als Fehltreffer |
| Dateigröße ≤ 2 MB | PASS | größte Datei 676 KB (FrizzleBob_Yellow_Gun.gltf) |
| Checksums SHA-256 | PASS | CHECKSUMS.sha256 |
| Clean-Run gegen Staging-Ordner (= ZIP-Inhalt) | PASS mit 1 Befund | lädt ohne Konsolenfehler bis zum Countdown; 1 lokaler 404: `media/kfb/KayfaBizarro_Card_Backside_01_lowrez.png` (Kartenrückseite, arena-ring.v1.js), fehlt schon im Workspace. Gegen ein entpacktes ZIP: NOT_RUN |
| Runtime-Netzwerkmitschnitt | NOT_RUN | |
| 3× 60 s Bot-Lauf | PASS (Vorsession, Harness, verdeckter Tab) | 12 Kills, 1→5, 0 Fehler |
| Münzaufnahme | NOT_RUN | Bot: 0 aufgesammelt |
| Gate 6 Clipping Nahaufnahme | NOT_RUN | |
| Licht/Tinte visuell | NOT_RUN | |
| Menschlicher 60-s-Test | NOT_RUN | |

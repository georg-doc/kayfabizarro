# START_HERE · KFB-COMBAT-ARENA_CLAUDE_DESIGN_SESSION_CUT_2026-09-30_r1

Status: **DESIGN CANDIDATE**. Kein DESIGN PASS, kein READY_FOR_INTEGRATION. Kein Commit, kein Deploy.

## Öffnen
1. Ordner über einen lokalen HTTP-Server ausliefern (ES-Module + importmap, `file://` geht nicht): `python3 -m http.server 8000` im ZIP-Wurzelordner.
2. Entry Point: `KFB Combat Arena KayKit.dc.html` (URL-kodiert: `KFB%20Combat%20Arena%20KayKit.dc.html`).
3. Rückfall: `index.html` (5A/A1, unverändert).
4. Kontext: `CD-COMBAT-CLAY-KAYKIT-01 Vorlauf.dc.html`.

Netz nötig: three.js (unpkg, gepinnt 0.160.0), KayKit-GLBs + Münze (raw.githubusercontent, **main, ungepinnt**), Nunito Sans (Google Fonts). Siehe EXPORT_MANIFEST.json → remote.

## URL-Schalter
`?vfx=normal|low|legacy` · `?clay=0` · `?clayRes=1024` · `?light=0.7–1.0` · `?ink=flat`

## Lesereihenfolge
HANDOVER.md → CURRENT_STATE.md → TEST_REPORT.md → NEXT_CHAT.md. Slice-Details: `_handover/CD-COMBAT-CLAY-KAYKIT-01/`.

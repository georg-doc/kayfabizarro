# CURRENT_STATE · 2026-09-30T04:22:59.094Z

| Bereich | Stand |
|---|---|
| Status | DESIGN CANDIDATE |
| Entry Point | `KFB Combat Arena KayKit.dc.html` |
| Rückfall | `index.html` (unverändert) |
| Basis | georg-doc/KFB-Combat-Arena@f6a59ad15b9ffcf3164b0ab013f223962b63f61f |
| Gegner | KayKit Skeleton Minion/Mage/Warrior (remote, main) |
| Spieler | FrizzleBob Kenney-Fallback, Gelb-Tint |
| HUD | Knet-Racer-HUD, Schild ausgeblendet |
| Material | K2 clay-material v10, relief v4, toolmix v1 |
| Licht | ×0,85, Sheen ×0,45, envMapIntensity 0,3 (`?light=`) |
| Tinte | Tusche-Knete, schattenempfangend (`?ink=flat` = alt) |
| Gameplay-Tests | 3× 60 s Bot-Lauf (Vorsession): 12 Kills, Stockwerk 1→5, 0 Fehler |
| Menschlicher Test | NOT_RUN |

# RETURN · CD-COMBAT-CLAY-KAYKIT-01 · Claude Design → WSA · 30.09.2026

## Status

**DESIGN CANDIDATE.** DESIGN PASS erst nach Gate 6 und Georgs Abnahme. Nie READY_FOR_INTEGRATION ohne diese beiden. Kein Commit, kein Deploy.

## Decision

- Die KayKit-Gegnerfamilie kommt an zwei Nähten des bestehenden M3 herein: `mb.R` (Roster-Form wie `kfb-monster-roster`) und `mb.loader` (Proxy nur für mb). Es gibt keinen zweiten Mob-Controller.
- Warrior läuft heran und schadet nur über den bestehenden Biss-Takt, ohne Projektil (Georg 30.09.).
- Schild bleibt ausgeblendet, bis ein Owner einen Wert liefert (Georg 30.09.).
- HUD im Look des Knet-Racer-HUD (Joyride J13). Keine Brand-Fonts, stattdessen Nunito Sans. Keine Erklärtexte im Sichtfeld.
- Boden = Karte, bleibt Papier (A2). Der Knet-Tisch wurde verworfen.

## Implementation

- `fun.v6k.js` ersetzt `fun.v4.js` nur in der Kopie. Rewards, Slam, Chill, Pause, Pips und Bursts sind identisch verdrahtet.
- Das Settings-Paneel wurde zum Pause/Hilfe-Overlay (Modus, Steuerung, Loot, Effekte). Die Prüfwerkzeuge Enemy size und Inspector sind in der Kopie entfernt.
- Clay-VFX: ein InstancedMesh-Pool mit eigenem RNG für muzzle, trail, hit, land (Sprung, Slam, Skull), ko, reward und prop_break.

## Tested result

Siehe `TEST_REPORT.md`. Drei 60-s-Läufe mit je 12 Kills, 5 Stockwerken, 4 Wechseln und 0 Fehlern. Gemessen im verdeckten Tab über den Harness.

## Source verified / unresolved

- `docs/combat-arena-v5/LIVING_HANDOVER.md` gibt es nicht. Gelesen wurde `LIVING_combat-arena-v5.md`.
- `combat-arena-v2/frizzlebob-driver-adapter.v2.js` gibt es weder im Repo noch im Projekt. C1 ist nicht geliefert.
- K1-Handover per Namen nicht gefunden. Gelesen: H0 (27.09.) und K2 (28.09., ACCEPTED AS BASE).
- Die Blobs waren MonsterCuteCubes (`kfb-monster-roster`), keine Space-Kit-Gegner. Der Vorlauf ist korrigiert.

## Deferred

- Melee: LATER/CANDIDATE.
- Blender CHOREO-LAB: nur als Donor katalogisiert, nicht eingebaut.
- Andere Gegnerfamilien (MonsterCuteCubes, Space Kit, Mystery S6): als Skins vorbereitbar über denselben `mb.R`-Tausch.

## Open (Problem zuerst)

0. **Nachtrag 30.09. (Runde 3):** Licht gedämpft (Clay-Material envMapIntensity 0,3 wie der Wirt statt 1, Sheen ×0,45, Belichtung ×0,85, per `?light=` einstellbar). Zensur-Tinte ist jetzt beleuchtete Tusche-Knete, dunkles Graubraun, und nimmt Figurenschatten an (`?ink=flat` = alt). Gegnerwürfe starten aus Handhöhe (0,50 statt 0,72 der Körperhöhe, leicht rechts; vy gleicht die Höhe aus). Einmal ist `Cannot read properties of undefined (reading 'x')` aufgetreten, Quelle nicht eindeutig. Die Wurf-Anpassung ist jetzt abgesichert. **Georgs Blick auf Licht und Tinte steht aus.**
0b. **Driver-Graft-FB (v3) und später v5 NICHT eingebaut:** Die Quelle fehlt, `frizzlebob-driver-adapter.v2.js` gibt es weder im Repo noch im Projekt. Georg nennt das Projekt oder die Datei, danach wird der Tausch an der C1-Naht (`index.html` Actor-Adapter) ein eigener Slice.

1. Clipping, Schatten und Texturflimmern in Nahaufnahme sind ungeprüft (Gate 6).
2. Münzaufnahme im Bot-Lauf nicht erreicht. Muss von Hand geprüft werden.
3. Clay-Material wird erst 1–6 s nach dem Spielstart umgestellt (Reliefberechnung). Sichtbarer Wechsel mitten im Spiel. Abhilfe wäre, die Karten offline vorzubacken.
4. Zensur-Tinte deckt zu Rundenbeginn große Kartenflächen ab (A2-Owner, nicht angefasst).
5. Warrior steht bei Aggro alle ~1,6 s für 0,42 s still, weil `gunfight` das Windup auch ohne Schuss setzt. Das liest sich als Ansage. Ein eigener Kontakt-Zweig wäre Combat-Core, nicht dieser Pass.
6. Fingerabdruck-Aufnahme `ref/clay-joebinns` fehlt im Arena-Export. Die Abdrücke im Material sind deshalb aus.

## Rollback

`index.html` und alle v1–v4-Owner sind unverändert. Die Kopie und `combat-arena-v6/` lassen sich löschen.

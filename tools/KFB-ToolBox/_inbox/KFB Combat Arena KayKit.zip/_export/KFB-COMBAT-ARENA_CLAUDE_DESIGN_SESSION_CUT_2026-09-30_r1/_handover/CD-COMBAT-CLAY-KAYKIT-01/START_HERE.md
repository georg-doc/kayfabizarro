# START_HERE · CD-COMBAT-CLAY-KAYKIT-01

**Status: DESIGN CANDIDATE.** Das ist noch kein DESIGN PASS. Offen sind Gate 6 (Clipping-Nahprüfung), die Münzaufnahme und Georgs Hand-/Augenabnahme im sichtbaren Tab. Kein Commit, kein Deploy, keine Live-Promotion.

## Öffnen

1. `KFB Combat Arena KayKit.dc.html` ist der spielbare Kandidat.
2. `CD-COMBAT-CLAY-KAYKIT-01 Vorlauf.dc.html` zeigt Source-Owner, die isolierten KayKit-Actors, den Fehlstand und den HUD-Plan.
3. `index.html` ist unverändert und bleibt der Rückfall (5A/A1).

URL-Schalter:
- `?vfx=normal|low|legacy` erzwingt die Effektstufe.
- `?clay=0` zeigt das Bild ohne Knet-Material (A/B-Vergleich).
- `?clayRes=1024` nutzt die volle K2-Kartengröße.

## Steuerung

Standardmäßig ist nichts im Bild. Die Steuerung steht im Pause-Overlay, das der Knopf oben rechts oder Esc öffnet.

- WASD: laufen und drehen
- Q/E: seitwärts
- Shift: rennen
- Space: springen
- F: Slam
- Klick: zielen und schießen

## Neue Dateien

- `combat-arena-v6/kaykit-enemies.v6.js`: KayKit-Roster und Loader-Proxy an den Nähten `mb.R` und `mb.loader`, dazu die Schuss- und Treffer-Clips.
- `combat-arena-v6/fun.v6k.js`: Fork von `fun.v4.js` mit derselben Spiel-Verdrahtung und einem neuen HUD-DOM.
- `combat-arena-v6/clay-hud.v6.js`: Look des Knet-Racer-HUD (aus Joyride J13, lab-hud).
- `combat-arena-v6/clay-world.v6.js`: K2-Material auf Actors, Props und Munition, dazu der Clay-VFX-Pool.
- `lab-clay/*`: K2-Module, unverändert kopiert.
- `lab-hud/fingerprints-512.png`: Textur für die Fingerabdrücke im HUD.
- `_handover/CD-COMBAT-CLAY-KAYKIT-01/`: diese Dokumente, `test-harness.js`, `kaykit-actor-view.js` und die Screenshots.

Nachgezogene Assets (Rewards.load brach vorher ab, auch in B0):
- `assets/4a/Skull.gltf`
- `assets/5a/{healing-potion,water-bomb,smoke-bomb}/model.gltf` (Buffer eingebettet)
- `assets/models/FrizzleBob_Yellow*.gltf`
- `Coin.glb` lässt sich im Design-Export nicht speichern und wird beim Laden auf `kayfabizarro/media/3D_Assets/KFB_Coin_01.glb` umgeleitet.

Weiter: `RETURN.md` → `TEST_REPORT.md` → `SOURCE_MANIFEST.json`.

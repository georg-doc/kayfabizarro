/* kaykit-actor-view — Isolationsbühne für einen Source-Actor (CD-COMBAT-CLAY-KAYKIT-01, Schritt b).
   Lädt exakt die Pfade aus combat-arena-v1/enemies.v1.js (ROSTER) bzw. modules/kfb-combat-def.js,
   filtert Rig_Medium-Clips nach Knotennamen wie enemies.v1.js spawn(), wählt Clips mit CLIP_RE (verbatim)
   und spielt sie der Reihe nach. Kein Ersatzmodell: schlägt jeder Pfad fehl, bleibt die Bühne leer + FAIL. */
(function () {
  if (customElements.get('kaykit-actor-view')) return;
  const RAW = 'https://raw.githubusercontent.com/georg-doc/kayfabizarro/main/media/3D_Assets/';
  const enc = (p) => p.split('/').map(encodeURIComponent).join('/');
  const url = (p) => /^https?:|^\.\.?\//.test(p) ? new URL(p, document.baseURI).href : RAW + enc(p);
  const CLIP_RE = {
    idle: /^Idle(_|$)|Idle_A|idle/i, walk: /^Walk|Walking_A|Walking/i, run: /^Run|Running_A/i,
    attack: /Melee_Attack|Attack|Punch|Slice|Chop|Stab/i, shoot: /Ranged|Shoot|Spellcast|Throw/i,
    hit: /^Hit|HitReact|Hit_A/i, death: /^Death|Death_A|Die/i, block: /Block/i,
  };
  const ANIM = 'KayKit_Character_Animations_1.1/Animations/gltf/Rig_Medium/Rig_Medium_';
  let libP = null;
  const lib = () => libP || (libP = Promise.all([
    import('https://esm.sh/three@0.160.0'),
    import('https://esm.sh/three@0.160.0/examples/jsm/loaders/GLTFLoader.js'),
    import('https://esm.sh/three@0.160.0/examples/jsm/utils/SkeletonUtils.js'),
    import('https://esm.sh/three@0.160.0/examples/jsm/environments/RoomEnvironment.js'),
  ]).then(([T, G, S, R]) => ({ T, loader: new G.GLTFLoader(), SU: S, Room: R.RoomEnvironment })));
  const gltfCache = new Map();
  const load = (L, u) => { if (!gltfCache.has(u)) gltfCache.set(u, L.loader.loadAsync(u)); return gltfCache.get(u); };
  window.__KAYKIT_ISO = window.__KAYKIT_ISO || {};

  class View extends HTMLElement {
    connectedCallback() {
      if (this._on) return; this._on = true;
      Object.assign(this.style, { display: 'block', position: 'relative', overflow: 'hidden', cursor: 'pointer', width: '100%', height: '100%', minHeight: '300px' });
      this.innerHTML = '';
      this._cv = document.createElement('canvas'); Object.assign(this._cv.style, { position: 'absolute', inset: '0', width: '100%', height: '100%', display: 'block' });
      this._top = this._tag('top'); this._bot = this._tag('bot');
      this.append(this._cv, this._top, this._bot);
      this._status('lädt …');
      this.addEventListener('click', () => this._next(true));
      this._io = new IntersectionObserver((e) => { this._vis = e[0].isIntersecting; }); this._io.observe(this);
      this._boot().catch((e) => { this._fail(e); });
    }
    disconnectedCallback() { this._dead = true; this._io && this._io.disconnect(); this._r && this._r.dispose(); }
    _tag(pos) {
      const d = document.createElement('div');
      Object.assign(d.style, { position: 'absolute', left: '10px', right: '10px', [pos === 'top' ? 'top' : 'bottom']: '8px',
        font: '12px/1.35 "Space Grotesk", ui-monospace, monospace', color: '#1f1a14', pointerEvents: 'none', textWrap: 'pretty' });
      return d;
    }
    _status(s) { this._top.textContent = s; }
    _fail(e) {
      this._status('FAIL · ' + (e && e.message ? e.message : e)); this._top.style.color = '#b8361f';
      window.__KAYKIT_ISO[this.id] = Object.assign(window.__KAYKIT_ISO[this.id] || {}, { ok: false, error: String(e && e.message || e) });
    }
    async _boot() {
      const L = await lib(); const T = L.T;
      const srcs = (this.getAttribute('src') || '').split('|').map((s) => s.trim()).filter(Boolean);
      const tried = []; let gltf = null, used = null;
      for (const s of srcs) { try { gltf = await load(L, url(s)); used = s; break; } catch (e) { tried.push(s.split('/').pop() + ' ✕'); } }
      if (!gltf) throw new Error('kein Pfad lädt: ' + srcs.join(' · '));
      const t0 = performance.now();
      const root = L.SU.clone(gltf.scene);
      root.updateMatrixWorld(true);
      const raw = new T.Box3().setFromObject(root), h0 = raw.max.y - raw.min.y;
      const H = parseFloat(this.getAttribute('height') || '1.7'), k = h0 > 0.01 ? H / h0 : 1;
      root.scale.setScalar(k); root.updateMatrixWorld(true);
      const box = new T.Box3().setFromObject(root); root.position.y -= box.min.y;
      const names = new Set(); let bones = 0;
      const tint = this.getAttribute('tint');
      root.traverse((n) => {
        if (n.name) names.add(n.name); if (n.isBone) bones++;
        if (n.isMesh) { n.castShadow = true; n.frustumCulled = false;
          for (const m of [].concat(n.material)) { if ('metalness' in m) m.metalness = 0; if (tint && /main/i.test(m.name || '')) m.color.set(tint); } }
      });
      const own = (gltf.animations || []).map((c) => ({ name: c.name, clip: c, source: 'own' }));
      const libc = [], compat = {};
      const cats = (this.getAttribute('cats') || '').split(',').map((s) => s.trim()).filter(Boolean);
      for (const cat of cats) {
        try {
          const g = await load(L, url(ANIM + cat + '.glb')); const allN = new Set(), okN = new Set();
          (g.animations || []).forEach((c) => {
            const keep = c.tracks.filter((tr) => { const n = T.PropertyBinding.parseTrackName(tr.name).nodeName; allN.add(n); const ok = names.has(n); if (ok) okN.add(n); return ok; });
            if (keep.length) libc.push({ name: c.name, clip: keep.length === c.tracks.length ? c : new T.AnimationClip(c.name, c.duration, keep), source: cat });
          });
          compat[cat] = allN.size ? Math.round(100 * okN.size / allN.size) : 0;
        } catch (e) { compat[cat] = 'FAIL'; }
      }
      const clips = own.concat(libc);
      const seq = (this.getAttribute('seq') || 'idle,walk,shoot,hit,death').split(',').map((s) => s.trim());
      /* Viewer: exakte Namen zuerst (PREFER), CLIP_RE aus enemies.v1.js nur als Rückfall.
         Befund: source CLIP_RE.idle trifft 'Jump_Idle' vor 'Idle_A', CLIP_RE.shoot trifft 'Ranged_1H_Aiming' (Ziel-Loop). */
      const PREFER = { idle: ['Idle_A', 'Idle'], walk: ['Walking_A', 'Walk'], run: ['Running_A', 'Run'], shoot: ['Ranged_1H_Shoot', 'Ranged_Magic_Shoot', 'Ranged_Magic_Spellcasting', 'Throw', 'Shoot'], hit: ['Hit_A', 'HitReact', 'Hit'], death: ['Death_A', 'Death'] };
      const srcPick = (key) => clips.find((c) => CLIP_RE[key] && CLIP_RE[key].test(c.name)) || null;
      this._set = seq.map((key) => {
        const pref = (PREFER[key] || []).map((n) => clips.find((c) => c.name === n)).find(Boolean) || null;
        const src = srcPick(key);
        return { key, e: pref || src, src };
      });
      // Stage
      const r = this._r = new T.WebGLRenderer({ canvas: this._cv, antialias: true, alpha: true, preserveDrawingBuffer: true });
      r.setPixelRatio(Math.min(2, devicePixelRatio)); r.outputColorSpace = T.SRGBColorSpace; r.toneMapping = T.ACESFilmicToneMapping; r.toneMappingExposure = 1.0;
      r.shadowMap.enabled = true; r.shadowMap.type = T.PCFSoftShadowMap;
      const sc = this._sc = new T.Scene();
      const pm = new T.PMREMGenerator(r); sc.environment = pm.fromScene(new L.Room(), 0.04).texture; sc.environmentIntensity = 0.55;
      const key = new T.DirectionalLight(0xfff3dc, 2.1); key.position.set(2.2, 4.5, 3); key.castShadow = true;
      key.shadow.mapSize.set(1024, 1024); Object.assign(key.shadow.camera, { left: -2, right: 2, top: 2, bottom: -2, near: 0.5, far: 12 }); key.shadow.bias = -0.0004; key.shadow.normalBias = 0.02;
      sc.add(key, new T.HemisphereLight(0xf6efd9, 0x8a7a5a, 0.7));
      const floor = new T.Mesh(new T.CircleGeometry(1.3, 48), new T.MeshStandardMaterial({ color: 0xe3d5af, roughness: 1 }));
      floor.rotation.x = -Math.PI / 2; floor.receiveShadow = true; sc.add(floor);
      const hold = new T.Group(); hold.add(root); hold.rotation.y = parseFloat(this.getAttribute('yaw') || '0.45'); sc.add(hold);
      const cam = this._cam = new T.PerspectiveCamera(30, 1, 0.05, 50);
      cam.position.set(0, H * 0.62, H * 2.55); cam.lookAt(0, H * 0.5, 0);
      this._mixer = new T.AnimationMixer(root); this._T = T; this._idx = -1; this._clock = new T.Clock();
      const ms = Math.round(performance.now() - t0);
      const rep = { ok: true, file: used, triedFirst: tried, bones, ownClips: own.length, libClips: libc.length, compat, scale: +k.toFixed(3), height: H,
        map: Object.fromEntries(this._set.map((s) => [s.key, s.e ? s.e.name + ' (' + s.e.source + ')' : null])),
        sourceClipRe: Object.fromEntries(this._set.map((s) => [s.key, s.src ? s.src.name : null])),
        clipNames: clips.map((c) => c.name) };
      window.__KAYKIT_ISO[this.id] = rep;
      this._status((tried.length ? tried.join(' · ') + ' → ' : '') + used.split('/').pop() + ' · ' + bones + ' Bones · ' + (own.length + libc.length) + ' Clips');
      this._next(false);
      const loop = () => {
        if (this._dead) return; requestAnimationFrame(loop);
        const dt = Math.min(0.05, this._clock.getDelta());
        if (!this._vis) return;
        const w = this.clientWidth, h = this.clientHeight;
        if (w && h && (w !== this._w || h !== this._h)) { this._w = w; this._h = h; r.setSize(w, h, false); cam.aspect = w / h; cam.updateProjectionMatrix(); }
        this._mixer.update(dt); this._t += dt;
        if (!this._manual && this._t > this._dur) this._next(false);
        r.render(sc, cam);
      };
      loop();
    }
    _next(manual) {
      if (!this._set) return; if (manual) this._manual = true;
      const T = this._T;
      for (let n = 0; n < this._set.length; n++) {
        this._idx = (this._idx + 1) % this._set.length; const s = this._set[this._idx];
        if (!s.e) continue;
        const a = this._mixer.clipAction(s.e.clip); const once = s.key === 'death' || s.key === 'hit' || s.key === 'shoot';
        a.setLoop(once ? T.LoopOnce : T.LoopRepeat, Infinity); a.clampWhenFinished = once;
        if (this._a && this._a !== a) this._a.fadeOut(0.15);
        a.reset().fadeIn(0.12).play(); this._a = a; this._t = 0;
        this._dur = once ? s.e.clip.duration + 0.9 : Math.max(2.4, s.e.clip.duration * 2);
        const diff = s.src && s.src !== s.e ? '<br><span style="color:#b8361f">Source-CLIP_RE wählt: ' + s.src.name + '</span>' : '';
        this._bot.innerHTML = '<b style="font-weight:700">' + s.key + '</b> → ' + s.e.name + ' <span style="color:#6f6450">· ' + s.e.source + ' · ' + s.e.clip.duration.toFixed(2) + ' s</span>' + diff
          + (this._manual ? ' <span style="color:#6f6450">· Klick = nächster</span>' : '');
        return;
      }
      this._bot.textContent = 'keine Clips aus ' + this._set.map((s) => s.key).join('/') + ' gefunden';
    }
  }
  customElements.define('kaykit-actor-view', View);
})();

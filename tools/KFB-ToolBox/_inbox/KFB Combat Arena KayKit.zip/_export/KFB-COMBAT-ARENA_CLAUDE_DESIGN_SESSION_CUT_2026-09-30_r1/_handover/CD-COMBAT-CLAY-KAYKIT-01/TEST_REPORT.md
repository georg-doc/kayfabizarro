# TEST_REPORT · CD-COMBAT-CLAY-KAYKIT-01 · 30.09.2026

Kandidat: `KFB Combat Arena KayKit.dc.html`. Basis: `georg-doc/KFB-Combat-Arena@f6a59ad` (B0-Kopie, `index.html` bleibt unverändert als Rückfall).

## Wie getestet (ehrlich)

Der Design-Preview läuft **verdeckt** (`document.hidden = true`). In diesem Zustand feuert `requestAnimationFrame` nie, Timer werden gedrosselt, und die Arena pausiert absichtlich. Deshalb lief jeder Test mit `test-harness.js`:

- Die Seite wird als sichtbar gemeldet.
- rAF und Timer laufen über einen MessageChannel-Takt (~60 Hz).
- Ein Bot spielt über dieselben Wege wie ein Mensch: `gf.aimAt()` wie ein Zielklick, `KeyboardEvent` für WASD/QE, Klick auf „Next card“.

Der Harness ändert keine Spielregel. Eine Hand- und Augenabnahme durch Georg in einem sichtbaren Tab steht noch aus.

## Gate 1 · 60 s ohne Neustart

| Lauf | Dauer | Zielklicks | Schüsse | Treffer | Kills | Pop | Stockwerke | „Next card“ | Fehler |
|---|---|---|---|---|---|---|---|---|---|
| A · Normal | 64 s | 46 | 44 | 39 | 12 | 12 | 1→5 | 4× | 0 |
| B · Normal/Low/Legacy gewechselt | 64 s | 47 | 46 | 36 | 12 | 12 | 1→5 | 4× | 0 |
| C · Final (Racer-HUD, Ammo-Cache) | 62 s | 43 | 42 | 36 | 12 | 12 | 1→5 | 4× | 0 |

- Phasen je Lauf: `play → cleared → ruesten → play`, viermal.
- Rewards je Lauf: 12 Skulls, 36 Aufpraller, 23–27 Münzen gedroppt.
- **Münzen aufgesammelt: 0.** Die Bot-Lenkung zur Münze (Panzersteuerung) hat nicht gegriffen. Der Aufnahmeweg über `rewards.collect` ist damit **nicht belegt** und muss von Hand geprüft werden.
- **Status: PASS für Move, Aim, Shoot, Hit, Kill, Pop-Reward und nächste Begegnung. OFFEN für die Münzaufnahme.**

## Gate 2 · KayKit isoliert und integriert

- Isoliert: Vorlauf (b), `shots/I_kaykit_isoliert.jpg`. Integriert: `shots/B_nachher_play_start.jpg`, `shots/G_run60_ende_stock5.jpg`.
- Alle drei Modelle laden über `KayKit_Skeletons/Skeleton_{Minion,Mage,Warrior}.glb`. Je Modell: 23 Bones, 65 Rig_Medium-Clips, 100 % kompatibel mit MovementBasic, CombatMelee, CombatRanged und General.
- Verwendete Clips (exakte Namen):
  - idle `Idle_A`
  - walk `Walking_A`
  - Biss/Kontakt `Melee_1H_Attack_Chop`
  - Treffer `Hit_A`
  - Schuss: Minion `Ranged_1H_Shoot`, Mage `Ranged_Magic_Shoot`, Warrior keiner (nur Kontakt)
- Welthöhen: Warrior 1,46 · Minion 1,30 · Mage 1,39 (FB 1,2 u).
- Befund im Source: `CLIP_RE` aus `enemies.v1.js` hätte `Jump_Idle` und `Ranged_1H_Aiming` gewählt.
- Tod: Der bestehende Lifecycle bleibt unverändert (Stauchen und Kippen, nach 0,2 s Skull). `Death_A` wird nicht gespielt.
- **Status: PASS.**

## Gate 3 · Vorher/Nachher, gleiche Kamera

- Vorher: `shots/A_vorher_5A1_current-ui.jpg`. Nachher: `shots/B_nachher_play_start.jpg` und `shots/F_run60_start_zensurtinte.jpg`.
- Kamera: Standard `schulter`, Neigung 37°, Abstand 7,6.
- Einschränkung: Die Karte unterscheidet sich, weil der Stapel je Sitzung an einer zufälligen Stelle beginnt (Owner: Ring). Der Seed für ein identisches Motiv ist nicht fixiert.
- **Status: PASS mit dieser Einschränkung.**

## Gate 4 · Normal/Low/Legacy ohne Gameplay-Unterschied

- Schalter im Pause-Overlay, gespeichert in `localStorage kfb-v6k-vfx`, per URL erzwingbar mit `?vfx=`.
- Pool: Normal 220 · Low 72 · Legacy 0. Spitzenwert im Lauf 56–67, 0 verworfen.
- Der Pool hat einen eigenen RNG. Er zieht nicht aus `host.rng` und ändert weder HP, Takt noch Treffer. Die bestehenden Papier-, Comic- und Rauch-VFX laufen in allen drei Stufen unverändert.
- Lauf B wechselte die Stufe mitten im Spiel. Kills und Stockwerke blieben gleich; Treffer schwanken zwischen den Läufen ohnehin durch die Zufallsbewegung des Bots.
- Ein deterministischer A/B-Lauf mit festem Seed wurde **nicht** gemacht.
- **Status: PASS im Code-Nachweis, der Lauf-Nachweis ist nicht deterministisch.**

## Gate 5 · Keine Palette und keine Erklärtexte im Sichtfeld, HUD vollständig

- Entfernt:
  - Controls-Leiste und Loadout-Slots
  - „Trank & Bomben …“
  - Wortmarke
  - Rüsten-Banner
  - Start-Hinweis (Georg 30.09.)
  - Erklär-Toasts beim Aufsammeln und bei Zielfehlern
  - Kicker „Card cleared“
  - Enemy-size- und Inspector-Tools
- Geblieben: die Comic-Laute „PLOPP!“ und „PAP!“, der Countdown und das Ergebnis-Paneel mit Knöpfen (Run-State).
- HUD:
  - Leben (Zahl und 10 Segmente)
  - Stockwerk und Gegnerstatus
  - Pop und Münzen
  - Waffe mit Nachladebogen
  - Slam mit Cooldown
  - Pause/Menü
  - Gegner-Pips
- Schild ist ausgeblendet, weil kein Owner einen Wert liefert (Georg 30.09.).
- Look: Knet-Racer-HUD aus *KFB Joyride J13 · Parcours 1a* (lab-hud). Paneel, Mulde, Peach-Knopf, Fingerabdrücke und SVG-Knetfilter sind 1:1 übernommen. Schrift ist Nunito Sans statt Bangers/Irish Grover (keine Brand-Fonts).
- **Status: PASS.**

## Gate 6 · Clay- und Shadow-Clipping

- K2-Material (v10, relief v4, toolmix v1) liegt auf FB, den KayKit-Actors, den Props (Skull, Münze, Trank, Bomben) und der Würfelmunition.
- Messwerte: 246 Netze umgestellt, 26 übersprungen (Gesicht, transparente Hosts, MeshBasic). 34 Materialien im Cache (vorher 145, Munition jetzt je Farbe). Relief und Werkzeuge in 512² brauchen 0,2–1,7 s plus 0,6–4,3 s.
- Die gedruckte Karte bleibt Papier (A2-Owner). Der Knet-Tisch wurde entfernt (Georg: „Bug/Missverständnis“).
- **Keine Nahaufnahme-Prüfung auf Clipping, Textur-Flimmern oder Schattenakne gemacht. Kein PASS.**

## Sonst gemessen

- Konsole: nur die bekannte PMREM-Warnung `sigmaRadians`.
- Zensur-Tinte bedeckt zu Rundenbeginn große Teile der Karte (`shots/F_run60_start_zensurtinte.jpg`). Das ist bestehendes Gameplay (spuck/zensur, A2), nicht Teil dieses Passes. Georg sollte es sich trotzdem ansehen.

## Screenshots

A Vorher · B Nachher Spielstart · C Kill (PLOPP, Clay-Splat) · D Pause/Hilfe · E Nächste Begegnung (Stockwerk 2) · F Rundenstart mit Zensur-Tinte · G Ende 60-s-Lauf (Stockwerk 5) · H Messwerte · I KayKit isoliert.

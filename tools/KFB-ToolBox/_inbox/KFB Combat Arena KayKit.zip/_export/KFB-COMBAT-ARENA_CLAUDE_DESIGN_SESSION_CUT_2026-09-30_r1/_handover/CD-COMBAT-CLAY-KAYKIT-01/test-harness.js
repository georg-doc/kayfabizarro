/* test-harness.js — CD-COMBAT-CLAY-KAYKIT-01 · NUR für die Abnahme im verdeckten Preview-Tab.
 * Grund (gemessen 30.09.): Der Design-Preview läuft mit document.hidden=true; requestAnimationFrame feuert dort nie,
 * und fun.v6k pausiert bei hidden (so gewollt). Der Harness
 *   1. meldet die Seite als sichtbar,
 *   2. ersetzt rAF durch einen MessageChannel-Takt (~60 Hz) und stößt den Wirt-Loop neu an,
 *   3. optional: ein Bot, der wie ein Spieler zielt/klickt und läuft (gf.aimAt = derselbe Weg wie ein Zielklick),
 *      Tasten per KeyboardEvent (derselbe Weg wie die Tastatur), und „Weiter“ nach Clear per Klick auf den Knopf.
 * Er ändert keine Spielregel und keinen Owner. Log: window.__BOT. */
(function () {
  if (window.__HARNESS) return; window.__HARNESS = true;
  try { Object.defineProperty(document, 'hidden', { configurable: true, get: () => false });
        Object.defineProperty(document, 'visibilityState', { configurable: true, get: () => 'visible' }); } catch (e) {}
  let q = [], id = 0, last = 0; const mc = new MessageChannel();
  /* Timer ebenfalls über den Takt: verdeckte Frames drosseln setTimeout bis auf 1/min (Chrome intensive throttling). */
  let timers = [], tid = 1e6;
  const runTimers = (now) => { if (!timers.length) return; const due = timers.filter((t) => t.at <= now); if (!due.length) return; timers = timers.filter((t) => t.at > now);
    for (const t of due) { if (t.every) { t.at = now + t.every; timers.push(t); } try { t.f(...t.a); } catch (e) { console.error(e); } } };
  window.setTimeout = (f, ms, ...a) => { if (typeof f !== 'function') return 0; const t = { id: ++tid, at: performance.now() + (+ms || 0), f, a }; timers.push(t); return t.id; };
  window.clearTimeout = (i) => { timers = timers.filter((t) => t.id !== i); };
  window.setInterval = (f, ms, ...a) => { const t = { id: ++tid, at: performance.now() + Math.max(4, +ms || 0), every: Math.max(4, +ms || 0), f, a }; timers.push(t); return t.id; };
  window.clearInterval = window.clearTimeout;
  mc.port1.onmessage = () => { const now = performance.now(); runTimers(now); if (now - last >= 15.5) { last = now; const cbs = q; q = []; for (const [, f] of cbs) { try { f(now); } catch (e) { console.error(e); } } } mc.port2.postMessage(0); };
  window.requestAnimationFrame = (f) => { q.push([++id, f]); return id; };
  window.cancelAnimationFrame = (i) => { q = q.filter((x) => x[0] !== i); };
  mc.port2.postMessage(0);
  const kick = () => { const A = window.__CA2; if (A && A.host) { const loop = (now) => { A.host.frameTick(now); requestAnimationFrame(loop); }; requestAnimationFrame(loop); } else setTimeout(kick, 200); };
  kick();
  window.dispatchEvent(new Event('visibilitychange')); document.dispatchEvent(new Event('visibilitychange'));

  const BOT = window.__BOT = { on: false, t0: 0, log: [], shots: 0, clears: 0, kills0: 0, events: [] };
  const key = (code, down) => window.dispatchEvent(new KeyboardEvent(down ? 'keydown' : 'keyup', { code, key: code, bubbles: true }));
  let held = null, nextAim = 0, nextMove = 0;
  BOT.start = (secs = 60) => {
    const C = window.__CA2.comp; BOT.on = true; BOT.t0 = performance.now(); BOT.until = BOT.t0 + secs * 1000;
    BOT.kills0 = C.gf.zaehler.kills; BOT.coins0 = C.gf.coins || 0; BOT.phases = []; BOT.levels = [C.rf.level];
    const tick = () => {
      if (!BOT.on) return; const now = performance.now(), c = window.__CA2.comp, gf = c.gf, ph = c.rf.phase;
      if (BOT.phases[BOT.phases.length - 1] !== ph) BOT.phases.push(ph);
      if (!BOT.levels.includes(c.rf.level)) BOT.levels.push(c.rf.level);
      if (now > BOT.until) { BOT.on = false; if (held) key(held, false); BOT.result = BOT.summary(); return; }
      if (ph === 'play') {
        BOT._clearAt = 0;
        const alive = c.mb.lebende();
        if (alive.length && now > nextAim) {
          let best = null, bd = 1e9; for (const m of alive) { const d = Math.hypot(m.pos.x - c.pc.pos.x, m.pos.z - c.pc.pos.z); if (d < bd) { bd = d; best = m; } }
          gf.aimAt(best); BOT.shots++; nextAim = now + 420;
        }
        if (now > nextMove) { if (held) key(held, false); held = ['KeyW', 'KeyQ', 'KeyE', 'KeyS', null][Math.floor(((now - BOT.t0) / 1300) % 5)]; if (held) key(held, true); nextMove = now + 1300; }
        // Loot nach Clear: siehe unten (Lenken zur nächsten Beute).
      } else if (ph !== 'cleared' && ph !== 'verloren' && held) { key(held, false); held = null; }
      if (ph === 'cleared' || ph === 'verloren') {
        /* Loot: zur nächsten Münze/Beute lenken (Panzersteuerung: drehen bis ausgerichtet, dann vor). */
        const pk = (gf.pickups || []).filter((p) => p.grp && p.grp.parent);
        if (!BOT._clearAt) BOT._clearAt = now;
        if (pk.length && now - BOT._clearAt < 9000) {
          let best = null, bd = 1e9; for (const p of pk) { const d = Math.hypot(p.grp.position.x - c.pc.pos.x, p.grp.position.z - c.pc.pos.z); if (d < bd) { bd = d; best = p; } }
          const want = Math.atan2(best.grp.position.x - c.pc.pos.x, best.grp.position.z - c.pc.pos.z);
          let diff = want - (c.pc._blick || 0); diff = Math.atan2(Math.sin(diff), Math.cos(diff));
          let k = Math.abs(diff) > 0.3 ? (BOT._turnKey || 'KeyA') : 'KeyW';
          if (k !== 'KeyW') { if (BOT._lastDiff != null && Math.abs(diff) > BOT._lastDiff + 0.02 && BOT._held === k) { BOT._turnKey = k === 'KeyA' ? 'KeyD' : 'KeyA'; k = BOT._turnKey; } BOT._lastDiff = Math.abs(diff); }
          if (held !== k) { if (held) key(held, false); held = k; key(k, true); BOT._held = k; }
        } else {
          if (held) { key(held, false); held = null; }
          const btn = [...document.querySelectorAll('div,button,span')].find((d) => /^(Next card|Play again|Try again|Nochmal|Weiter)$/i.test((d.textContent || '').trim()));
          if (btn && !BOT._clicked) { BOT._clicked = now; btn.click(); BOT.clears++; BOT.events.push({ t: Math.round((now - BOT.t0) / 100) / 10, ev: 'weiter:' + btn.textContent.trim() }); }
        }
      } else if (ph !== 'play') { BOT._clicked = 0; BOT._clearAt = 0; }
      requestAnimationFrame(tick);
    };
    tick();
  };
  BOT.summary = () => { const c = window.__CA2.comp, gf = c.gf;
    return { secs: Math.round((performance.now() - BOT.t0) / 1000), aimClicks: BOT.shots, shots: gf.zaehler.schuesse, hits: gf.zaehler.treffer,
      kills: gf.zaehler.kills - BOT.kills0, coins: (gf.coins || 0) - BOT.coins0, pop: c.state.pop, phases: BOT.phases, levels: BOT.levels, hp: Math.round(gf.hp),
      rewards: gf.rewards && gf.rewards.stats, vfx: c.clay ? { mode: c.clay.mode, rep: c.clay.rep.vfx } : null, fehler: c.fehler, events: BOT.events }; };
})();

# Return · KFB Combat Arena v6+ · Claude Design · Slice B0

## 0 · Identity

- Design project: KFB Combat Arena v6+ (this project)
- Slice: B0 — Baseline Clone / Parity (current-main clone, per Georg's correction — NOT the v5b donor)
- Date: 2026-09-13
- Combat repo HEAD read: `georg-doc/KFB-Combat-Arena@main` `f6a59ad15b9f...`
- Published build identity inspected: `kfb-combat-arena.pages.dev/build/` → source `f6a59ad15b9ffcf3164b0ab013f223962b63f61f`, tag "5A/A1 · Props & Play"
- Historical donor/export used: none (B0 redefined mid-slice to clone current main, not the v5b donor — see chat correction)

## 1 · Status summary

**DECISION:** B0 = 1:1 clone of the *current* `main`/published-site 5A/A1 state (old FrizzleBob, current controls/HUD/Settings), not the v5b donor. A2/v5b/Driver stay deferred to B1+.

**IMPLEMENTATION:** Copied the actual runtime tree verbatim from repo `main`: `index.html`, `support-v4.js`, `support.js`, `bundle/`, `cardbuilder/`, `combat-arena-v1..v4/`, `modules/`, `podcast-v1/`, `studio-v3/`, `site/`, `themes/`, `vendor/addons/`, `assets/` — the exact set `tools/build.py` assembles into `dist/`.

**TESTED RESULT:** Loads cleanly in the Design preview: title curtain → asset loading ("Shuffling the deck…" → "Dealing the card…") → live Arena with card surface, old FrizzleBob (yellow), one enemy, HUD (KayfaBizarro wordmark, Pop counter, countdown, loadout bar, full control legend). Only console output is a benign PMREM `sigmaRadians` warning from three's `RoomEnvironment`, present in the original code path too.

**UNRESOLVED:** No old-project export beyond what's already staged in-repo was located (see prior BOOTSTRAP REPORT); not needed for this corrected B0 scope.

**DEFERRED:** A2 card merge, v5b delta, Driver/C1, all Studio v17 assumptions — per Georg's instruction, none touched in B0.

## 2 · Donor treatment

| Donor / subsystem | Source repo/path/revision | Treatment | Reason |
|---|---|---|---|
| Current 5A/A1 runtime tree | `georg-doc/KFB-Combat-Arena@main` (f6a59ad15b9f) | REUSE UNCHANGED | B0 goal is exact current-state clone |
| `vendor/three.module.js`, `vendor/babel.min.js` | not committed to repo (fetched at build time by `tools/vendor.py` from `unpkg three@0.160.0` / `@babel/standalone@7.29.0`) | ADAPT | Design project can't run the Python vendor step; pointed at the identical pinned CDN sources instead |
| `assets/models/FrizzleBob_Yellow*.gltf` | also vendor.py-fetched, not committed | REUSE UNCHANGED (existing fallback) | Code already falls back to Kenney RAW + runtime tint on 404 — this is the app's own documented behavior, not a Design-side patch |
| `combat-arena-v4/targeting.v4a.js` | one line only | ADAPT | Its `import {Sphere} from '../vendor/three.module.js'` bypassed the importmap that every other module in this same codebase already uses; changed to the same bare `'three'` specifier used everywhere else |

## 3 · What changed

- `index.html` — importmap: `"three"` now resolves to `https://unpkg.com/three@0.160.0/build/three.module.js` (was `./vendor/three.module.js`, a file never committed to the repo). `three/addons/` still local, unchanged, already matches r160.
- `support-v4.js` — `BABEL_URL` now the pinned `unpkg @babel/standalone@7.29.0` CDN URL (was `./vendor/babel.min.js`, also never committed). SRI hash in the file was left untouched and still verifies, since it's the same published artifact.
- `combat-arena-v4/targeting.v4a.js` — one import line, relative vendor path → bare `three` specifier (see table above).
- No gameplay file's logic was otherwise touched. Rollback: revert these three edits to restore the exact repo-as-committed strings (they'll just 404 on the two genuinely-uncommitted vendor files).

## 4 · What was tested

- Source/static: file tree cross-checked against `tools/build.py`'s copy list.
- Design/browser runtime: loaded in the Claude Design preview; watched full boot sequence; checked `performance.getEntriesByType('resource')` to confirm every remote asset (character model, mouth textures, KayKit animation clips) fetched successfully; checked console for errors after boot.
- Visual: screenshot taken post-boot — HUD, wordmark, Pop/combo, countdown, loadout bar, full control legend all present and matching the README/site's documented controls.
- Not tested: audio/hearing acceptance, GPU/frame-time, actual play (kill/coin/slam interactions), settings panel interaction, multi-floor/card-change, tab-hidden lifecycle. No Georg freeplay acceptance yet.

## 5 · Baseline deviations

- Two files are legitimately absent from the repo by design (build-time vendor fetch): `vendor/three.module.js`, `vendor/babel.min.js`. Substituted with identical-version CDN loads (see §2/§3). No visible/behavioral difference expected since they're byte-identical published packages.
- One relative import path in `targeting.v4a.js` repaired to match the app's own importmap convention (see §2/§3) — required for it to run at all in this container; not a behavior change.
- Everything else is the committed repo content, unmodified.

## 6 · Open / blocked

- Gameplay/interaction parity (kill loop, slam, pickups, card-change, settings) not yet exercised — next step if useful before declaring full B0 acceptance.
- No audio/hearing check performed yet.

## 7 · Export / handoff

- Files live at the project root, mirroring the repo layout 1:1 (`index.html`, `support-v4.js`, `bundle/`, `cardbuilder/`, `combat-arena-v1..v4/`, `modules/`, `podcast-v1/`, `studio-v3/`, `site/`, `themes/`, `vendor/addons/`, `assets/`).
- Source revision: `georg-doc/KFB-Combat-Arena@main` `f6a59ad15b9f...`.
- Intended receiving slice: none — this stays the Design-side baseline; WSA/repo `main` remains SSOT.

## 8 · STOP

B0 stops here: current-main visual/control/HUD clone only. No A2 card merge, no v5b delta, no Driver/C1, no cleanup or refactor beyond the three path-adapts listed above. Awaiting Georg's visual acceptance before B1 (historical v5b delta) begins.

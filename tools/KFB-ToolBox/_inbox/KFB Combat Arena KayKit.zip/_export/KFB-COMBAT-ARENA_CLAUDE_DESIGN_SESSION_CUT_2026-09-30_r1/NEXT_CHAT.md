# NEXT_CHAT · Paste-Prompt

Kontext: KFB Combat Arena, Slice CD-COMBAT-CLAY-KAYKIT-01, Status DESIGN CANDIDATE. Session-Cut `KFB-COMBAT-ARENA_CLAUDE_DESIGN_SESSION_CUT_2026-09-30_r1`. Entry Point `KFB Combat Arena KayKit.dc.html`, Rückfall `index.html`. Lies START_HERE.md, HANDOVER.md, TEST_REPORT.md.

Aufgabe: Nach Georgs Handtest (60 s sichtbarer Tab) seine Befunde zu Münzaufnahme, Gate-6-Clipping, Licht und Tinte einarbeiten. Nichts an v1–v4-Ownern oder `index.html` ändern. Kein Commit, kein Deploy.

Wenn Georg die Quelle für FrizzleBob Driver v3 liefert: eigener Slice, Tausch an der C1-Naht (Actor-Adapter), switchbar gegen den Kenney-Fallback.

Next Gate: Georgs Handabnahme im sichtbaren Tab.

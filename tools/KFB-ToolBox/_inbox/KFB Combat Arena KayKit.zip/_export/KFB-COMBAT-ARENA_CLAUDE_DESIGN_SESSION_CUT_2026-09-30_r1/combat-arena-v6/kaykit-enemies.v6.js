/* kaykit-enemies.v6.js — CD-COMBAT-CLAY-KAYKIT-01 · KayKit-Gegnerfamilie für den bestehenden Enemy-Lifecycle.
 *
 * KEIN zweiter Mob-Controller. mobs.v2.js (M3) bleibt Owner von Spawn, Bewegung, Abstand, Clip-Rolle idle/walk.
 * Dieses Modul tauscht an ZWEI dokumentierten Nähten:
 *   1. mb.R        — der Roster (sonst modules/kfb-monster-roster.js, MonsterCuteCubes). Gleiche Form:
 *                    MONSTERS[], roleClip(e, rolle). Einträge = KayKit Skeletons Minion/Mage/Warrior.
 *   2. mb.loader   — ein Proxy NUR für mb. Für KayKit-Pfade lädt er das Modell, holt die Rig_Medium-Clips
 *                    (MovementBasic, CombatMelee, CombatRanged, General — wie enemies.v1.js spawn()),
 *                    filtert Spuren nach Knotennamen und setzt die Höhe über einen inneren Knoten.
 * Clipnamen: EXAKT zuerst (Befund Vorlauf b: CLIP_RE aus enemies.v1.js wählt Jump_Idle bzw. Ranged_1H_Aiming).
 * Gameplay unverändert: HP (3 Würfeltreffer), Takt, Schaden, Biss-Weite, Rewards gehören gunfight/rewards.
 * Präsentation (bindCombat): Schuss- und Treffer-Clip einmal abspielen, wie der bestehende Biss-Clip.
 * Warrior (Georg 30.09.): läuft heran, nur Kontaktschaden über den bestehenden Biss-Takt — kein Projektil. */

const ANIM = 'KayKit_Character_Animations_1.1/Animations/gltf/Rig_Medium/Rig_Medium_';
const CATS = ['MovementBasic', 'CombatMelee', 'CombatRanged', 'General'];
const BASE = 'media/3D_Assets/KayKit_Skeletons/';

const PREF = {
  idle: ['Idle_A', 'Idle_B', 'Idle'],
  walk: ['Walking_A', 'Walking_B', 'Walking_C', 'Walk'],
  hit: ['Hit_A', 'Hit_B'],
  death: ['Death_A', 'Death_B'],
  attack: ['Melee_1H_Attack_Chop', 'Melee_Unarmed_Attack_Punch_A', 'Melee_1H_Attack_Slice_Horizontal', 'Melee_2H_Attack_Chop'],
};
/* hRel = Welthöhe relativ zu FB. Setzung, nicht Messung (FB 1,2 u; Skelette sollen lesbar größer sein). */
export const MONSTERS = [
  { id: 'kk_minion', name: 'Skeleton Minion', file: BASE + 'Skeleton_Minion.glb', hRel: 1.08, ranged: true,
    shoot: ['Ranged_1H_Shoot', 'Throw', 'Ranged_1H_Shooting'], bolt: 0x9ad63f },
  { id: 'kk_mage', name: 'Skeleton Mage', file: BASE + 'Skeleton_Mage.glb', hRel: 1.16, ranged: true,
    shoot: ['Ranged_Magic_Shoot', 'Ranged_Magic_Spellcasting', 'Ranged_1H_Shoot'], bolt: 0xc78fff },
  { id: 'kk_warrior', name: 'Skeleton Warrior', file: BASE + 'Skeleton_Warrior.glb', hRel: 1.22, ranged: false, contactOnly: true,
    shoot: [], bolt: 0xe8e0cc,
    attack: ['Melee_1H_Attack_Chop', 'Melee_1H_Attack_Slice_Diagonal', 'Melee_Unarmed_Attack_Punch_A'] },
].map((e) => Object.assign({ air: false, ready: true, clipSet: 'kaykit', surface: 'bone', forwardZ: 1,
  quelle: 'KayKit Skeletons (CC0) · Rig_Medium · Pfad wie kfb-combat-def.js', clip: {} }, e));

export function roleClip(e, rolle) { return (e && e.clip && e.clip[rolle]) || null; }
export const FLYERS = [];
export const CLIPSETS = { kaykit: PREF };
export function zeile() { return 'kaykit-roster · ' + MONSTERS.length + ' Skelette · Clips aus Rig_Medium (' + CATS.join(', ') + ')'; }

export function installKayKit(c, host) {
  const mb = c.mb, T = c.THREE || host.THREE, orig = mb.loader;
  const assets = mb.assets;
  const log = (s) => (c.log ? c.log('[kaykit] ' + s) : console.info('[kaykit] ' + s));
  const byUrl = new Map(MONSTERS.map((e) => [mb._url(e), e]));
  const packs = new Map();
  const pack = (cat) => { if (!packs.has(cat)) packs.set(cat, orig.loadAsync(assets.RAW + assets.enc(ANIM + cat + '.glb')).then((g) => g.animations || []).catch((err) => { log(cat + ' FAIL ' + err.message); return []; })); return packs.get(cat); };
  const filtered = new Map();
  const report = { models: {}, packsMs: 0, H: 1.2, global: 0.49 };
  const kk = { report, MONSTERS, H: 1.2 };

  async function clipsFor(e, names) {
    if (filtered.has(e.id)) return filtered.get(e.id);
    const t0 = performance.now(), out = [], compat = {};
    for (const cat of CATS) {
      const anims = await pack(cat); const allN = new Set(), okN = new Set();
      for (const c0 of anims) {
        const keep = c0.tracks.filter((tr) => {
          const n = T.PropertyBinding.parseTrackName(tr.name).nodeName; allN.add(n);
          const ok = names.has(n); if (ok) okN.add(n);
          /* Wie HOWTO §8: Skalenspuren raus, Positionsspuren nur an root/hips. */
          if (ok && /\.scale$/.test(tr.name)) return false;
          if (ok && /\.position$/.test(tr.name) && !/^(root|hips|pelvis)$/i.test(n)) return false;
          return ok;
        });
        if (keep.length && !out.find((x) => x.name === c0.name)) out.push(new T.AnimationClip(c0.name, c0.duration, keep));
      }
      compat[cat] = allN.size ? Math.round(100 * okN.size / allN.size) : 0;
    }
    const pick = (list) => (list || []).find((n) => out.some((x) => x.name === n)) || null;
    e.clip = { idle: pick(PREF.idle), walk: pick(PREF.walk), hit: pick(PREF.hit), death: pick(PREF.death),
      attack: pick(e.attack || PREF.attack), shoot: pick(e.shoot) };
    report.packsMs = Math.round(performance.now() - t0);
    report.models[e.id] = { clips: out.length, compat, used: Object.assign({}, e.clip) };
    filtered.set(e.id, out);
    return out;
  }

  mb.R = { MONSTERS, FLYERS, CLIPSETS, roleClip, zeile, stance: () => ({ y: 0, rolle: 'walk', clip: null, echt: false, ersatz: null }) };
  mb.L = null;   // Look-Schicht der Cube-Atlanten gilt nicht für KayKit (eigene Textur, MeshStandard)
  mb.loader = {
    loadAsync: async (url) => {
      const e = byUrl.get(url);
      const g = await orig.loadAsync(url);
      if (!e) return g;
      const names = new Set(); g.scene.traverse((n) => { if (n.name) names.add(n.name); });
      const clips = await clipsFor(e, names);
      /* Höhe über einen inneren Knoten: mobs.v2 setzt wurzel.scale = global·H/1,2 (EIN Faktor für alle).
         Innen steht der Rest, damit die Welthöhe hRel·H wird. */
      g.scene.updateMatrixWorld(true);
      const bb = new T.Box3().setFromObject(g.scene), raw = Math.max(0.01, bb.max.y - bb.min.y);
      const s = report.global * (kk.H / 1.2), k = (e.hRel * kk.H) / (raw * s);
      const outer = new T.Group(); outer.name = 'kaykit:' + e.id; g.scene.scale.setScalar(k); outer.add(g.scene);
      g.scene.traverse((o) => { if (o.isMesh) { o.frustumCulled = false; for (const m of [].concat(o.material)) if (m && 'metalness' in m) m.metalness = 0; } });
      report.models[e.id].raw = +raw.toFixed(3); report.models[e.id].inner = +k.toFixed(4);
      return { scene: outer, animations: clips, userData: { kaykit: e.id } };
    }
  };
  const origSpawn = mb.spawn.bind(mb);
  mb.spawn = async (n, fbH, bes) => { kk.H = fbH || 1.2; report.H = kk.H; const b = await origSpawn(n, fbH, bes); kk.onSpawn && kk.onSpawn(b); return b; };
  import(new URL('./combat-arena-v2/mobs.v2.js?v=5a-props-20260909', document.baseURI).href).then((M) => { if (M.SPEC && M.SPEC.hoehe) report.global = M.SPEC.hoehe.global; }).catch(() => {});

  const once = (m, name) => {
    const clip = name && m.clips[name]; if (!clip) return null;
    const a = m.mixer.clipAction(clip); a.setLoop(T.LoopOnce, 1); a.clampWhenFinished = false; a.reset().play(); return a;
  };
  kk.bindCombat = (gf) => {
    const fire = gf._mobFeuern.bind(gf);
    gf._mobFeuern = (m) => {
      if (m && m.e && m.e.contactOnly) return null;       // Warrior: kein Projektil
      const n0 = gf.schuesse.length, r = fire(m);
      if (r !== null && m && m.e && m.e.clipSet === 'kaykit') {
        once(m, m.e.clip.shoot);
        /* Wurf aus der Hand statt aus dem Gesicht (Georg 30.09.: »sieht aus wie Spucken«): Abgang von 0,72 auf
           0,50 der Körperhöhe und etwas zur rechten Hand. vy gleicht die tiefere Höhe aus → gleiche Ankunftshöhe. */
        const p = gf.schuesse.length > n0 ? gf.schuesse[gf.schuesse.length - 1] : null;
        if (p && p.von === 'mob' && p.quelle === m && p.grp && p.dir && gf.pc && gf.pc.pos) try {
          const dy = (m.hoehe || 1.3) * 0.22, side = (m.hoehe || 1.3) * 0.16;
          const d = Math.hypot(gf.pc.pos.x - p.grp.position.x, gf.pc.pos.z - p.grp.position.z), flug = Math.max(0.15, d / Math.max(0.001, p.tempo));
          p.grp.position.y -= dy; p.vy += dy / flug;
          p.grp.position.x += -p.dir.z * side; p.grp.position.z += p.dir.x * side;
        } catch (e) { console.warn('[kaykit] Wurf-Anpassung', e); }
      }
      return r;
    };
    const dmg = gf.damageMob.bind(gf);
    gf.damageMob = (m, d, at) => { const r = dmg(m, d, at); if (r !== false && m && m.e && m.e.clipSet === 'kaykit' && !m.tot) once(m, m.e.clip.hit); return r; };
    log('Kampf gebunden · Warrior nur Biss · Schuss/Treffer-Clip je Treffer einmal');
  };
  log(zeile());
  window.__KAYKIT_ARENA = report;
  return (c.kaykit = kk);
}

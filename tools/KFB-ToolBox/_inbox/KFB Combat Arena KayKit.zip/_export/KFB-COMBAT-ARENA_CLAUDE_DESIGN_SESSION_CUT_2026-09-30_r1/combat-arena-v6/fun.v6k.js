// v6k presentation layer (CD-COMBAT-CLAY-KAYKIT-01). Fork of combat-arena-v4/fun.v4.js — SAME gameplay wiring
// (slam, dispatch, rewards, chill, pause, bursts, pips). Changed: the DOM is a game HUD instead of the
// controls palette; controls live in the pause overlay (Esc). HUD look = Knet-Racer HUD (clay-hud.v6.js). Plus KayKit + Clay installs.
import {Rewards} from '../combat-arena-v4/rewards.v4a.js';
import {SlamAction} from '../combat-arena-v4/slam.v4a.js';
import {actionForCode,isTextEntry,canAct,createActionDispatcher} from '../combat-arena-v4/actions.v5a.js';
import {installClayWorld} from './clay-world.v6.js?v=6k-7';
import {hudMarkup,clayFilters,applyLook,loadFont,setGauge} from './clay-hud.v6.js?v=6k-5';
export async function installFun(c) {
  const T=c.THREE, host=c.host, gf=c.gf, ze=c.ze;
  const stats={slams:0,cleans:0,fragments:0,hits:0,pops:0,bounces:0};
  let chill=true, elapsed=0, lastCard=c.ring.current, paused=false;
  const reduced=matchMedia('(prefers-reduced-motion: reduce)').matches;
  const group=new T.Group();group.name='v4-paper-feedback';host.scene.add(group);
  const geometry=new T.PlaneGeometry(.11,.19);
  const materials=[0xe9c14a,0xf3ead3,0x45b4ad,0xb8361f].map(color=>new T.MeshBasicMaterial({color,side:T.DoubleSide,toneMapped:false}));
  const bits=[], labels=new Map();
  const SEG=10;
  const ui=document.createElement('div');ui.className='v4-ui v6-hud';
  loadFont();clayFilters();applyLook(document.documentElement,true);
  ui.innerHTML=hudMarkup(SEG);
  (c._root || document.body).appendChild(ui);
  const $=s=>ui.querySelector(s);
  const slamButton=$('[data-slam]'), toastEl=$('.v4-toast');
  const segs=[...ui.querySelectorAll('.kc-seg i')], lifeEl=$('.v6-life'), foesEl=$('.kc-foes');
  let toastTime=0, nextProbe=0, hintSeen=false; try{hintSeen=localStorage.getItem('kfb-v6k-hint')==='1';}catch(e){}
  function toast(text){toastEl.textContent=text;toastEl.style.opacity=1;toastTime=1.15;}
  function burst(pos,n=14){
    if(reduced)n=Math.min(n,5);
    for(let i=0;i<n && bits.length<160;i++){
      const mesh=new T.Mesh(geometry,materials[i%materials.length]);mesh.position.copy(pos);mesh.position.y+=.12;
      const a=host.rng()*Math.PI*2,v=1.4+host.rng()*2.2;
      const bit={mesh,vx:Math.cos(a)*v,vz:Math.sin(a)*v,vy:2+host.rng()*3,t:0,life:.7+host.rng()*.5};
      group.add(mesh);bits.push(bit);stats.fragments++;
    }
  }
  function clean(pos,radius){const n=ze?.radieren?.(pos.x,pos.z,radius) || 0;stats.cleans+=n;return n;}
  function slam(){return slamAction.request();}
  function impact(){
    const pos=c.pc.pos.clone();pos.y=host.field.floorY();stats.slams++;
    burst(pos,34);clean(pos,3.2);
    for(const m of c.mb.lebende()){
      const dx=m.pos.x-pos.x,dz=m.pos.z-pos.z,d=Math.hypot(dx,dz);
      if(d<3.2+m.radius)gf.damageMob(m,{x:dx/(d||1),z:dz/(d||1)},m.pos.clone());
    }
    if(!gf.aggro){gf.aggro=true;c.mb.friedlich=false;}
    host.fx.cue('abzug',{sfx:'cartoon.slam',at:pos});
    host.fx.emit('burst',pos,{size:1.7,life:.28,color:0xe9c14a});toast('PAP!');
    c.clay?.emit('land',{x:pos.x,y:pos.y+.03,z:pos.z},{n:22,color:[0x3aa596,0x1f1a14,0xe9c14a],speed:4.4,up:2.4,size:.08,life:1});
  }
  const slamAction=c.pc.slamAction=new SlamAction(c.pc,{allowed:()=>['play','cleared'].includes(c.rf?.phase) && !c.state.settingsOn && !document.hidden,impact});
  const dispatch=createActionDispatcher(c,{slam});
  slamButton.onclick=()=>dispatch('slam');
  $('[data-pause]').onclick=()=>dispatch('pause');
  ui.addEventListener('pointerdown',e=>{if(e.target.closest('button,[data-pause]')){e.stopPropagation();host.input.state.fire=false;host.input.state.firePressed=false;}});
  ui.addEventListener('contextmenu',e=>e.preventDefault());
  const setChill=v=>{chill=!!v;c.setState({v6Chill:chill});};
  const onKey=e=>{
    if(e.repeat || isTextEntry(e.target))return;
    const action=actionForCode(e.code);
    if(action?.id==='slam' || action?.id==='pause'){e.preventDefault();dispatch(action.id);}
  };
  addEventListener('keydown',onKey);
  const originalBlack=ze.schwarz.bind(ze);ze.schwarz=()=>chill?false:originalBlack();
  gf.onHit=(m,pos)=>{stats.hits++;burst(pos,7);};
  gf.onPop=m=>{stats.pops++;toast('PLOPP!');};
  gf.onSkullBounce=(pos,index)=>burst(pos,[12,7,4][index]);
  gf.onReveal=(pos,r)=>{clean(pos,r*.82);for(let i=0;i<6;i++){const a=i*Math.PI/3;clean({x:pos.x+Math.cos(a)*r*.68,z:pos.z+Math.sin(a)*r*.68},r*(.29+.035*(i%2)));}};
  gf.onBounce=p=>{stats.bounces++;if(p.bounces===1 && p.von==='spieler'){clean(p.grp.position,.4);burst(p.grp.position,3);}};
  gf.onPickup=(p,result)=>{burst(p.grp.position,p.kind==='waterbomb'?24:p.kind==='smokebomb'?12:5);};
  gf.onAimFailure=()=>{};
  gf.isChill=()=>chill;
  /* Coin.glb ist im Design-Export nicht speicherbar (Binärformat). Nur für diesen Ladevorgang auf die in
     docs/ASSET-SOURCES-4A.json dokumentierte Quelle umleiten; danach ist der Loader wieder unverändert. */
  { const L=gf.loader, la=L.loadAsync.bind(L);
    L.loadAsync=(u,...a)=>la(/\/assets\/4a\/Coin\.glb$/.test(u)?'https://raw.githubusercontent.com/georg-doc/kayfabizarro/main/media/3D_Assets/KFB_Coin_01.glb':u,...a);
    try{gf.rewards=await Rewards.load(gf,{chill:()=>chill,reduced});}finally{L.loadAsync=la;} }
  const oldRoundUpdate=c.rf.update.bind(c.rf);
  c.rf.update=dt=>{
    if(c.state.settingsOn || document.hidden)return c.rf.phase;
    if(chill && ['play','cleared'].includes(c.rf.phase))gf.hp=Math.max(35,gf.hp);
    return oldRoundUpdate(dt);
  };
  const oldPhase=c.rf.onPhase;
  c.rf.onPhase=phase=>{
    if(phase!=='cleared'){host.input.reset();gf.cancelShot();}
    if(phase==='ruesten' || phase==='countdown'){
      gf.rewards.clear();
      for(const p of gf.schuesse)gf.gruppe.remove(p.grp);gf.schuesse.length=0;
      for(const p of gf.pickups)gf.gruppe.remove(p.grp);gf.pickups.length=0;
      slamAction.cancel(true);
    }
    oldPhase(phase);
  };
  const aimRing=new T.Mesh(new T.RingGeometry(.16,.19,32),new T.MeshBasicMaterial({color:0xe9c14a,transparent:true,opacity:.85,side:T.DoubleSide,depthWrite:false,toneMapped:false}));
  aimRing.rotation.x=-Math.PI/2;aimRing.visible=false;group.add(aimRing);
  const starShape=new T.Shape();for(let i=0;i<10;i++){const a=i*Math.PI/5,r=i%2?.045:.1;i?starShape.lineTo(Math.cos(a)*r,Math.sin(a)*r):starShape.moveTo(Math.cos(a)*r,Math.sin(a)*r);}starShape.closePath();
  const stars=Array.from({length:3},()=>{const m=new T.Mesh(new T.ShapeGeometry(starShape),new T.MeshBasicMaterial({color:0xe9c14a,side:T.DoubleSide,toneMapped:false}));m.visible=false;group.add(m);return m;});
  const halo=new T.Mesh(new T.RingGeometry(.30,.36,40),new T.MeshBasicMaterial({color:0x5fbf3a,transparent:true,opacity:0,side:T.DoubleSide,depthWrite:false,toneMapped:false}));halo.rotation.x=-Math.PI/2;group.add(halo);

  // KayKit presentation hooks + Clay world (material + VFX pool). Both are presentation; gameplay owners unchanged.
  c.kaykit?.bindCombat?.(gf);
  installClayWorld(c).then(()=>c.forceUpdate?.()).catch(e=>{console.warn('[v6k] Clay-Welt AUSFALL',e);c.log?.('[clay] AUSFALL '+(e&&e.message||e));});
  let shotsSeen=gf.zaehler?.schuesse||0, lastFoeTotal=0;

  // Pause/Help values for the existing Settings panel (renderVals merges c.v6Vals()).
  c.v6Vals=()=>{
    const mode=c.clay?.mode||'normal';
    const chip=(on)=>({fg:on?'#3A2416':'#E4DCF2',bg:on?'radial-gradient(110% 110% at 35% 28%,var(--ui-a-hi) 0%,var(--ui-a) 50%,var(--ui-a-lo) 100%)':'radial-gradient(120% 120% at 40% 30%,var(--ui-well-b) 0%,var(--ui-well-a) 100%)',bd:'transparent'});
    return {
      vfxChips:[['normal','Normal'],['low','Low'],['legacy','Legacy']].map(([id,name])=>({name,...chip(mode===id),pick:()=>c.clay?.setMode(id)})),
      modeChips:[[true,'Chill ☀'],[false,'Action ⚡']].map(([v,name])=>({name,...chip(chill===v),pick:()=>setChill(v)})),
      v6Controls:[['W/S · ↑/↓','Laufen'],['A/D','Drehen'],['Q/E','Seitwärts'],['Shift','Rennen'],['Space','Springen'],['F','Tinten-Slam'],['Klick','Zielen & schießen'],['Halten','Weiterfeuern'],['Rechts ziehen','Kamera'],['Esc','Pause']].map(([k,l])=>({k,l})),
      v6Loot:[['Grüner Trank','+20 Leben'],['Wasserfarb-Bombe','Tinte weg, Treffer im Umkreis'],['Rauchbombe','Gegner 2,5 s benommen'],['Goldmünze','+1 Pop']].map(([k,l])=>({k,l}))
    };
  };
  c.forceUpdate?.();

  const oldStep=c.schritt.bind(c);
  c.schritt=now=>{
    if(c.state.settingsOn || document.hidden){
      c._lastF=now;c._lastB=now;paused=true;host.time.state.phase='paused';host.input.reset();gf.cancelShot();
      ui.dataset.probe=JSON.stringify({paused:true,phase:c.rf.phase,roundTime:c.rf.t,ink:ze.deckung,gun:gf.probe(),input:{x:0,z:0,fire:false},errors:c.fehler});
      ui.style.visibility='hidden';
      return 0;
    }
    ui.style.visibility='visible';
    const dt=oldStep(now);elapsed+=dt;
    const wantPause=!!c.state.settingsOn || document.hidden;
    if(wantPause!==paused){paused=wantPause;host.input.reset();}
    if(paused){host.time.state.phase='paused';ui.dataset.probe=JSON.stringify({paused:true,phase:c.rf.phase,roundTime:c.rf.t,gun:gf.probe(),input:{x:host.input.state.x,z:host.input.state.z,fire:host.input.state.fire},errors:c.fehler});return dt;}
    if(host.time.state.phase==='paused')host.time.state.phase=['play','cleared'].includes(c.rf?.phase)?'play':'countdown';
    if(chill && ['play','cleared'].includes(c.rf?.phase))gf.hp=Math.max(35,gf.hp);
    const playing=['play','cleared'].includes(c.rf?.phase);
    const target=gf.aimTarget,tracking=!!target && (gf.aimLife>0 || gf._offen) && !target.tot && !target.weg;
    aimRing.visible=tracking && playing;
    if(tracking){aimRing.position.set(target.pos.x,host.field.floorY()+.05,target.pos.z);aimRing.scale.setScalar(1+Math.sin(elapsed*8)*.08);}
    const rig=c.fb?.rig;
    if(rig){
      if(tracking && rig.rig){const pt=target.pos.clone();if(!target.point)pt.y+=target.hoehe*.5;
        rig.rig.updateWorldMatrix(true,false);rig.rig.worldToLocal(pt);
        rig.setGazeFollow(true);rig.pointTo(Math.atan2(pt.x,Math.max(.2,pt.z))/.75,Math.atan2(pt.y,Math.max(.2,Math.hypot(pt.x,pt.z)))/.65);
      }else if(rig._follow)rig.setGazeFollow(false);
    }
    const stunned=(c.pc.stunRemaining||0)>0;
    stars.forEach((m,i)=>{m.visible=stunned;if(stunned){const a=elapsed*5+i*Math.PI*2/3;m.position.set(c.pc.pos.x+Math.cos(a)*.38,c.pc.pos.y+c.pc.hoehe+.1+Math.sin(a*2)*.06,c.pc.pos.z+Math.sin(a)*.38);m.quaternion.copy(host.camera.quaternion);}});
    const feedback=gf.rewards.feedback.at(-1);halo.visible=!!feedback;
    if(feedback){halo.position.set(c.pc.pos.x,host.field.floorY()+.055,c.pc.pos.z);halo.scale.setScalar(1+feedback.t*1.5);halo.material.opacity=(1-feedback.t/.75)*.7;halo.material.color.setHex(feedback.kind==='heal'?0x5fbf3a:feedback.kind==='waterbomb'?0x45b4ad:feedback.kind==='smokebomb'?0xac82dc:feedback.kind==='damage'?0xe84b3c:0xe9c14a);}

    // ── HUD (reads owners only) ──
    const hp=Math.max(0,Math.min(100,gf.hp)), on=Math.ceil(hp/100*SEG);
    segs.forEach((s,i)=>s.classList.toggle('off',i>=on));
    $('[data-hp]').textContent=Math.round(hp);lifeEl.setAttribute('aria-valuenow',Math.round(hp));lifeEl.classList.toggle('low',hp<=30);
    $('[data-stun]').textContent=stunned?'★ '+c.pc.stunRemaining.toFixed(1):'';
    $('[data-floor]').textContent=c.rf?.level||c.state.level||1;
    const alive=c.mb.lebende().length, total=Math.max(alive,c.mb.spawnBericht?.gesetzt||c.mb.mobs.length||0);
    if(total!==lastFoeTotal){lastFoeTotal=total;foesEl.innerHTML=Array.from({length:total},()=>'<i></i>').join('');}
    [...foesEl.children].forEach((f,i)=>f.classList.toggle('down',i>=alive));
    $('[data-foes]').textContent=alive+'/'+total;
    $('[data-pop]').textContent=c.state.pop||0;$('[data-combo]').textContent=c.state.combo||'';
    $('[data-coins]').textContent=gf.coins||0;
    const kalt=Math.max(0,gf._kalt||0), takt=.38, ready=kalt<=0 && !stunned && playing;
    const frac=1-Math.min(1,kalt/takt);
    setGauge(ui,playing?frac:0,stunned);

    if(!playing)slamAction.cancel();
    if(lastCard!==c.ring.current){lastCard=c.ring.current;slamAction.cancel(true);host.input.reset();for(const b of bits)group.remove(b.mesh);bits.length=0;}
    const cooldown=slamAction.cooldown;
    slamButton.disabled=!playing || cooldown>0 || stunned;
    $('[data-slamlabel]').textContent=cooldown>0?cooldown.toFixed(1):'F';
    toastTime-=dt;if(toastTime<=0)toastEl.style.opacity=0;
    for(let i=bits.length-1;i>=0;i--){const b=bits[i];b.t+=dt;b.vy-=12*dt;b.mesh.position.x+=b.vx*dt;b.mesh.position.z+=b.vz*dt;b.mesh.position.y+=b.vy*dt;b.mesh.rotation.x+=dt*8;b.mesh.rotation.z+=dt*5;
      const floor=host.field.floorY()+.025;
      if(b.mesh.position.y<floor && host.field.inside(b.mesh.position.x,b.mesh.position.z)){b.mesh.position.y=floor;b.vy=Math.abs(b.vy)*.25;b.vx*=.9;b.vz*=.9;}
      b.mesh.scale.setScalar(Math.max(0,1-b.t/b.life));
      if(b.t>b.life){group.remove(b.mesh);bits.splice(i,1);}
    }
    c.clay?.frame(dt);
    const rect=c._canvas.getBoundingClientRect(),aliveSet=new Set(c.mb.lebende());
    for(const [m,el] of labels)if(!aliveSet.has(m)){el.remove();labels.delete(m);}
    for(const m of aliveSet){
      gf._leben(m);let el=labels.get(m);
      if(!el){el=document.createElement('div');el.className='v4-pips';el.innerHTML='<i></i><i></i><i></i>';ui.appendChild(el);labels.set(m,el);}
      const p=new T.Vector3(m.pos.x,m.pos.y+m.hoehe+.23,m.pos.z).project(host.camera);
      el.hidden=p.z>1 || p.z< -1 || Math.abs(p.x)>1 || Math.abs(p.y)>1 || c.state.settingsOn;
      el.style.left=(p.x*.5+.5)*rect.width+'px';el.style.top=(-p.y*.5+.5)*rect.height+'px';
      el.classList.toggle('target',gf.zielMob===m);el.classList.toggle('windup',m._windup>0);el.classList.toggle('power-stun',m.powerStun>0);[...el.children].forEach((pip,i)=>pip.classList.toggle('empty',i>=m.hp));
    }
    if(elapsed>=nextProbe){nextProbe=elapsed+.25;ui.dataset.probe=JSON.stringify({...stats,phase:c.rf.phase,input:{x:host.input.state.x,z:host.input.state.z,fire:host.input.state.fire},hp:gf.hp,ink:ze.deckung,fx:host.fx.stats(),gun:gf.probe(),rewards:gf.rewards.stats,shot:gf.lastShot,aim:gf._offen?.stage,player:{pos:c.pc.pos.toArray(),stun:c.pc.stunRemaining,clip:c.pc.clipName},errors:c.fehler,vfx:c.clay?{mode:c.clay.mode,particles:c.clay.particles()}:null,alive:c.mb.lebende().map(m=>({id:m.e.id,hp:m.hp,position:[m.pos.x,m.pos.y,m.pos.z]}))});}
    return dt;
  };
  c.fun={slam,dispatch,stats,setChill,probe:()=>({...stats,chill,cooldown:slamAction.cooldown,slam:slamAction.stage,particles:bits.length,health:gf.hp,alive:c.mb.lebende().map(m=>({id:m.e.id,hp:m.hp}))})};
  return c.fun;
}

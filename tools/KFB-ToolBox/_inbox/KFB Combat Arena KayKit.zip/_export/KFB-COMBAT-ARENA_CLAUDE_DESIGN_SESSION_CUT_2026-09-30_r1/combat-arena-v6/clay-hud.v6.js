/* clay-hud.v6.js — Arena-HUD im Look des Knet-Racer-HUD (KFB Joyride J13 · Parcours 1a, lab-hud/).
 * Übernommen 1:1: Knet-Paneel (Radialverlauf hi/p/lo + Innen-/Unterschatten), Fingerabdruck-Overlay
 * (lab-hud/fingerprints-512.png, soft-light), dunkle Mulde (well), Peach-Knopf, SVG-Knetfilter kfb-clay-a/b/c,
 * Farbrechnung tones() (uiPrimary #6E5C9E · uiAccent #F08A5D), unregelmäßige Radien, leichte Drehung.
 * Abweichung: keine Brand-Fonts (Bangers/Irish Grover sind Legacy, Georg 30.09.) → Nunito Sans 800/900 (Racer-UI-Font).
 * Das Modul kennt keinen Spielwert; fun.v6k schreibt Zahlen hinein. */
const FP = './lab-hud/fingerprints-512.png';
const rgb = (h) => { const v = parseInt(String(h).replace('#', '').slice(0, 6), 16); return [(v >> 16) & 255, (v >> 8) & 255, v & 255]; };
const mix = (a, b, k) => { const x = rgb(a), y = rgb(b); return '#' + [0, 1, 2].map((i) => Math.round(x[i] + (y[i] - x[i]) * k).toString(16).padStart(2, '0')).join(''); };
export function tones(p = '#6E5C9E', a = '#F08A5D') {
  return { p, a, deep: mix(p, '#140F22', .58), hi: mix(p, '#FFF4E6', .38), lo: mix(p, '#140F22', .22), wellA: mix(p, '#140F22', .84), wellB: mix(p, '#140F22', .64),
    aHi: mix(a, '#FFF4E6', .32), aLo: mix(a, '#3A1A0A', .28), hot: mix(a, '#fb3233', .55) };
}
export function applyLook(el = document.documentElement, clay = true) {
  const t = tones(), set = (k, v) => el.style.setProperty(k, v);
  set('--ui-p', t.p); set('--ui-hi', t.hi); set('--ui-lo', t.lo); set('--ui-p-deep', t.deep); set('--ui-well-a', t.wellA); set('--ui-well-b', t.wellB);
  set('--ui-a', t.a); set('--ui-a-hi', t.aHi); set('--ui-a-lo', t.aLo); set('--ui-hot', t.hot);
  const sh = 'drop-shadow(0 3px 3px rgba(20,12,36,.3))', shc = 'drop-shadow(0 2px 2px rgba(20,12,36,.28))';
  set('--clay-a', clay ? 'url(#kfb-clay-a) ' + sh : sh); set('--clay-b', clay ? 'url(#kfb-clay-b)' : 'none'); set('--clay-c', clay ? 'url(#kfb-clay-c) ' + shc : shc); set('--clay-prints', clay ? '.55' : '0');
  return t;
}
export function clayFilters() {
  if (document.getElementById('kfb-clay-defs')) return; const NS = 'http://www.w3.org/2000/svg', svg = document.createElementNS(NS, 'svg');
  svg.id = 'kfb-clay-defs'; svg.setAttribute('width', '0'); svg.setAttribute('height', '0'); svg.style.cssText = 'position:absolute;width:0;height:0;overflow:hidden';
  const mk = (id, warpF, warp, dentF, dentS, grainS, seed) => `<filter id="${id}" x="-20%" y="-25%" width="140%" height="150%" color-interpolation-filters="sRGB">
    <feTurbulence type="fractalNoise" baseFrequency="${warpF}" numOctaves="2" seed="${seed}" result="w"/>
    <feDisplacementMap in="SourceGraphic" in2="w" scale="${warp}" xChannelSelector="R" yChannelSelector="G" result="shape"/>
    <feTurbulence type="fractalNoise" baseFrequency="${dentF}" numOctaves="3" seed="${seed + 11}" result="d"/>
    <feDiffuseLighting in="d" surfaceScale="${dentS}" diffuseConstant="1" lighting-color="#ffffff" result="dl"><feDistantLight azimuth="225" elevation="58"/></feDiffuseLighting>
    <feTurbulence type="fractalNoise" baseFrequency=".85" numOctaves="2" seed="${seed + 23}" result="g"/>
    <feDiffuseLighting in="g" surfaceScale="${grainS}" diffuseConstant="1" lighting-color="#ffffff" result="gl"><feDistantLight azimuth="225" elevation="62"/></feDiffuseLighting>
    <feBlend in="dl" in2="gl" mode="multiply" result="lit"/>
    <feComponentTransfer in="lit" result="lit2"><feFuncR type="linear" slope=".62" intercept=".5"/><feFuncG type="linear" slope=".62" intercept=".5"/><feFuncB type="linear" slope=".62" intercept=".5"/></feComponentTransfer>
    <feBlend in="shape" in2="lit2" mode="multiply" result="mix"/>
    <feComposite in="mix" in2="shape" operator="in"/></filter>`;
  svg.innerHTML = mk('kfb-clay-a', .018, 7, .045, 2.6, .9, 3) + mk('kfb-clay-b', .03, 4, .06, 1.8, .7, 17) + mk('kfb-clay-c', .045, 3.5, .08, 1.6, .8, 29);
  document.body.appendChild(svg);
}
export function loadFont() {
  if (document.getElementById('kfb-hud-font')) return;
  const l = document.createElement('link'); l.id = 'kfb-hud-font'; l.rel = 'stylesheet';
  l.href = 'https://fonts.googleapis.com/css2?family=Nunito+Sans:ital,wght@0,700;0,800;0,900;1,900&display=swap'; document.head.appendChild(l);
}
/* Bausteine — Markup wie im Racer (Paneel · Abdrücke · Mulde). */
const PANEL = 'background:radial-gradient(130% 110% at 30% 18%,var(--ui-hi) 0%,var(--ui-p) 52%,var(--ui-lo) 100%);box-shadow:inset 5px 7px 9px -3px rgba(255,255,255,.45),inset -6px -8px 12px -3px rgba(24,12,48,.5),0 5px 0 -1px var(--ui-p-deep);filter:var(--clay-a,none)';
const WELL = 'background:radial-gradient(120% 120% at 62% 78%,var(--ui-well-b) 0%,var(--ui-well-a) 100%);box-shadow:inset 3px 5px 8px rgba(6,3,14,.8),inset -2px -3px 5px rgba(255,255,255,.14),0 1.5px 0 rgba(255,255,255,.3);filter:var(--clay-b,none)';
export const PEACH = 'background:radial-gradient(110% 110% at 35% 28%,var(--ui-a-hi) 0%,var(--ui-a) 50%,var(--ui-a-lo) 100%);box-shadow:inset 3px 4px 6px -1px rgba(255,255,255,.55),inset -4px -5px 7px -2px rgba(80,34,12,.5),0 4px 0 -1px var(--ui-a-lo);filter:var(--clay-c,none)';
const shell = (r, fp, rot, inner, style = '') => `<div class="kc-shell" style="transform:rotate(${rot}deg);${style}">
  <div class="kc-abs" style="border-radius:${r};${PANEL}"></div>
  <div class="kc-abs" style="border-radius:${r};background:url(${FP}) ${fp} / 160px 160px;mix-blend-mode:soft-light;opacity:var(--clay-prints,.55);filter:var(--clay-a,none)"></div>${inner}</div>`;
const well = (r, inner, style = '') => `<div class="kc-well" style="${style}"><div class="kc-abs" style="border-radius:${r};${WELL}"></div>${inner}</div>`;
const R1 = '18px 23px 17px 21px / 21px 17px 23px 18px', R2 = '13px 10px 14px 11px / 11px 14px 10px 13px', RB = '47% 53% 50% 50% / 52% 47% 53% 48%', RB2 = '52% 48% 49% 51% / 48% 53% 47% 52%';

export function hudMarkup(SEG) {
  return `<style>
  .v6-hud{position:absolute;inset:0;pointer-events:none;z-index:11;font-family:'Nunito Sans',ui-sans-serif,system-ui,sans-serif;color:#FBF3E4}
  .kc-shell{position:relative;height:52px;padding:8px;box-sizing:border-box}
  .kc-abs{position:absolute;inset:0}
  .kc-well{position:relative;height:36px;display:flex;align-items:center;gap:10px;padding:0 13px}
  .kc-big{position:relative;font:900 24px/1 'Nunito Sans',sans-serif;letter-spacing:.01em;color:#FBF3E4;font-variant-numeric:tabular-nums;text-shadow:0 2px 0 rgba(6,3,14,.55),0 -1px 0 rgba(255,255,255,.12)}
  .kc-mono{position:relative;font:800 10px/1 ui-monospace,monospace;letter-spacing:.1em;color:var(--ui-a);font-variant-numeric:tabular-nums;white-space:nowrap}
  .kc-row{position:absolute;top:14px;display:flex;align-items:center;gap:10px}
  .kc-seg{position:relative;display:flex;gap:3px}
  .kc-seg i{display:block;width:10px;height:12px;border-radius:4px 3px 4px 3px;background:var(--ui-a);box-shadow:inset 1px 2px 2px rgba(255,255,255,.45),inset -1px -2px 2px rgba(80,34,12,.45)}
  .kc-seg i.off{background:rgba(6,3,14,.55);box-shadow:inset 1px 2px 3px rgba(0,0,0,.6)}
  .v6-life.low .kc-seg i:not(.off){background:var(--ui-hot);animation:kcpulse .6s ease-in-out infinite alternate}
  @keyframes kcpulse{to{opacity:.55}}
  .kc-foes{position:relative;display:flex;gap:3px}
  .kc-foes i{display:block;width:9px;height:12px;border-radius:3px 4px 3px 4px;background:#FBF3E4;box-shadow:inset -1px -2px 2px rgba(60,40,90,.4)}
  .kc-foes i.down{background:rgba(6,3,14,.5);box-shadow:inset 1px 2px 3px rgba(0,0,0,.6)}
  .kc-btn{position:relative;width:36px;height:36px;border:0;padding:0;background:transparent;cursor:pointer;pointer-events:auto;display:flex;align-items:center;justify-content:center;color:#3A2416;font:900 14px/1 'Nunito Sans',sans-serif;transition:transform .08s}
  .kc-btn:hover{transform:translateY(-1px) scale(1.05)} .kc-btn:active{transform:translateY(2px) scale(.94)}
  .kc-btn[disabled]{cursor:default;filter:saturate(.35) brightness(.8)}
  .kc-btn:focus-visible{outline:2px solid #FBF3E4;outline-offset:3px;border-radius:50%}
  .kc-gauge{position:absolute;left:16px;bottom:16px;width:118px;height:118px;transform:rotate(-2deg)}
  .kc-slam{position:absolute;left:140px;bottom:22px;width:52px;height:52px;padding:8px;box-sizing:border-box;transform:rotate(3deg)}
  .v4-pips{position:absolute;display:flex;gap:3px;transform:translate(-50%,-100%);padding:4px 5px;border-radius:9px 7px 10px 8px;${WELL.replace('filter:var(--clay-b,none)', '')}}
  .v4-pips i{width:9px;height:6px;display:block;border-radius:3px;background:var(--ui-a)}
  .v4-pips i.empty{background:rgba(255,255,255,.14)}
  .v4-pips.power-stun::before{content:"★";color:#FBF3E4;font-size:14px;line-height:7px}
  .v4-pips.target{outline:2px solid #FBF3E4;outline-offset:2px}
  .v4-pips.windup i:not(.empty){background:var(--ui-hot)}
  .v4-toast{position:absolute;left:50%;top:19%;transform:translateX(-50%) rotate(-2deg);font:italic 900 30px/1 'Nunito Sans',sans-serif;letter-spacing:.02em;color:var(--ui-a-hi);text-shadow:0 3px 0 var(--ui-p-deep),0 0 1px #140F22;opacity:0;transition:opacity .15s;white-space:nowrap}
  @media(max-width:640px){.kc-seg i{width:7px}.kc-big{font-size:20px}.kc-row.kc-tr{top:auto;bottom:16px}.kc-gauge{width:96px;height:96px}.kc-slam{left:118px}}
  </style>
  <div class="kc-row" style="left:16px">
    ${shell(RB, '13px 7px', -3, `<div style="position:relative;width:36px;height:36px;display:flex;align-items:center;justify-content:center"><div class="kc-abs" style="border-radius:${RB2};${WELL}"></div>
      <svg width="20" height="20" viewBox="0 0 24 24" style="position:relative"><path d="M12 20.5 C 5 15.5 2.5 12.2 2.5 8.6 A 4.6 4.6 0 0 1 12 6.3 A 4.6 4.6 0 0 1 21.5 8.6 C 21.5 12.2 19 15.5 12 20.5 Z" fill="var(--ui-a)" stroke="var(--ui-a-lo)" stroke-width="1.6"/></svg></div>`, 'width:52px')}
    <div class="v6-life" role="meter" aria-label="Leben" aria-valuemin="0" aria-valuemax="100">
    ${shell(R1, '40px 22px', 1, well(R2, `<span class="kc-big" data-hp style="width:44px">100</span><span class="kc-seg">${Array.from({ length: SEG }, () => '<i></i>').join('')}</span>`))}
    </div>
    <span class="kc-mono" data-stun style="color:#FBF3E4;text-shadow:0 1px 0 #140F22"></span>
  </div>
  <div class="kc-row kc-tr" style="right:16px">
    ${shell('21px 17px 20px 18px / 18px 21px 17px 20px', '90px 60px', -1.4, well(R2, `<span class="kc-big" data-floor>1</span><span class="kc-mono" style="color:#E4DCF2">STOCK</span><span class="kc-foes"></span><span class="kc-mono" data-foes>0/0</span>`))}
    ${shell('20px 17px 22px 18px / 17px 21px 18px 22px', '20px 90px', -.8, well(R2, `<span class="kc-big" data-pop>0</span><span class="kc-mono">POP</span><span class="kc-mono" data-combo style="color:var(--ui-a-hi);width:22px"></span>
      <svg width="16" height="16" viewBox="0 0 20 20" style="position:relative"><circle cx="10" cy="10" r="8" fill="#F2C230" stroke="#8a6a16" stroke-width="2"/></svg><span class="kc-big" data-coins style="font-size:18px">0</span>`))}
    ${shell(RB2, '70px 30px', 3, `<button type="button" class="kc-btn" data-pause aria-label="Pause und Hilfe (Esc)" title="Pause · Hilfe (Esc)"><span class="kc-abs" style="border-radius:49% 51% 53% 47% / 52% 48% 50% 50%;${PEACH}"></span>
      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3.2" stroke-linecap="round" style="position:relative"><path d="M5 7.4h14M5.6 12.2h13M5 17h14"></path></svg></button>`, 'width:52px')}
  </div>
  <div class="kc-gauge" aria-label="Würfel-Gun">
    <div class="kc-abs" style="border-radius:49% 51% 48% 52% / 52% 48% 51% 49%;${PANEL.replace('inset 5px 7px 9px -3px', 'inset 7px 9px 12px -3px').replace('inset -6px -8px 12px -3px', 'inset -8px -10px 15px -3px').replace('0 5px 0 -1px', '0 6px 0 -1px')}"></div>
    <div class="kc-abs" style="border-radius:49% 51% 48% 52% / 52% 48% 51% 49%;background:url(${FP}) 30px 140px / 190px 190px;mix-blend-mode:soft-light;opacity:var(--clay-prints,.55);filter:var(--clay-a,none)"></div>
    <div class="kc-abs" style="inset:9px;border-radius:51% 49% 50% 50% / 49% 51% 50% 50%;${WELL.replace('inset 3px 5px 8px', 'inset 4px 6px 10px')}"></div>
    <svg viewBox="0 0 168 168" style="position:absolute;inset:0;width:100%;height:100%;overflow:visible">
      <path d="M 30.31 115 A 62 62 0 1 1 137.69 115" fill="none" stroke="rgba(6,3,14,.55)" stroke-width="15" stroke-linecap="round"></path>
      <path data-arc d="M 30.31 115 A 62 62 0 1 1 137.69 115" fill="none" stroke="var(--ui-a)" stroke-width="13" stroke-linecap="round" stroke-dasharray="259.7" stroke-dashoffset="0"></path>
      <circle data-knob cx="137.69" cy="115" r="10.5" fill="#FBF3E4" stroke="#3D3359" stroke-width="3.5"></circle>
    </svg>
    <div class="kc-abs" style="display:flex;flex-direction:column;align-items:center;justify-content:center;gap:4px;padding-top:4px">
      <svg width="34" height="34" viewBox="0 0 34 34" style="transform:rotate(-8deg)"><rect x="3" y="3" width="28" height="28" rx="7" fill="#FBF3E4" stroke="#3D3359" stroke-width="2.5"/><circle cx="11" cy="11" r="2.8" fill="#3A2416"/><circle cx="23" cy="11" r="2.8" fill="#3A2416"/><circle cx="17" cy="17" r="2.8" fill="#3A2416"/><circle cx="11" cy="23" r="2.8" fill="#3A2416"/><circle cx="23" cy="23" r="2.8" fill="#3A2416"/></svg>
      <div style="font:800 8px/1 ui-monospace,monospace;letter-spacing:.14em;color:#E4DCF2">WÜRFEL</div>
    </div>
  </div>
  <div class="kc-slam">
    <div class="kc-abs" style="border-radius:${RB};${PANEL}"></div>
    <div class="kc-abs" style="border-radius:${RB};background:url(${FP}) 50px 10px / 150px 150px;mix-blend-mode:soft-light;opacity:var(--clay-prints,.55);filter:var(--clay-a,none)"></div>
    <button type="button" class="kc-btn" data-slam aria-label="Tinten-Slam (F)" title="Tinten-Slam (F)"><span class="kc-abs" style="border-radius:52% 48% 51% 49% / 48% 52% 49% 51%;${PEACH}"></span><span style="position:relative" data-slamlabel>F</span></button>
  </div>
  <div class="v4-toast" aria-live="polite"></div>`;
}
/* Readiness 0..1 → Bogen + Knopf (gleiche Geometrie wie der Racer-Tacho: 150° + 240°·n). */
export function setGauge(root, n, hot) {
  const arc = root.querySelector('[data-arc]'), knob = root.querySelector('[data-knob]'); n = Math.max(0, Math.min(1, n));
  arc.setAttribute('stroke-dashoffset', (259.7 * (1 - n)).toFixed(1)); arc.setAttribute('stroke', hot ? 'var(--ui-hot)' : n >= 1 ? 'var(--ui-a)' : '#E4DCF2');
  const th = (150 + 240 * n) * Math.PI / 180; knob.setAttribute('cx', (84 + 62 * Math.cos(th)).toFixed(1)); knob.setAttribute('cy', (84 + 62 * Math.sin(th)).toFixed(1));
}

/* clay-world.v6.js — CD-COMBAT-CLAY-KAYKIT-01 · Clay-Look + Clay-VFX-Pool als Präsentationsschicht.
 *
 * Material: K2 (clay-material.v10 + clay-relief.v4 + clay-toolmix.v1), unverändert kopiert aus
 *   kayfabizarro · tools/KFB-ToolBox/_inbox/KFB Knet-Strecke T3 v2/KFB_CLAYMATION_K2_KNET_WERKZEUGE_2026-09-28/lab-clay/.
 *   Maßstab passt ohne Umrechnung (HOWTO §3/§11: Figur ≈ 1,2 u = FB).
 * Form: K1/H0-Regel „Figuren mit Skin nie Vorstufe“ — keine neue Verformung. Bestehender Deformer bleibt Owner.
 * Grenze: Die gedruckte Karte (A2-Owner, MeshBasic/unbeleuchtet) bleibt Papier. Kein Knet-Tisch (verworfen 30.09.).
 * Gesicht: EyeRig/Mouth/transparente Hosts werden nie umgestellt (Lesbarkeit).
 * VFX: EIN InstancedMesh-Pool (Knetkugeln), feste Kapazität je Stufe, eigener RNG (keine Gameplay-RNG-Züge).
 *   Normal 220 · Low 72 · Legacy 0 (nur bestehende Arena-VFX). Bestehende Papier-/Comic-/Rauch-VFX bleiben additiv. */
import * as CM from '../lab-clay/clay-material.v10.js';
import { makeClayRelief } from '../lab-clay/clay-relief.v2.js';
import { makeToolReliefs } from '../lab-clay/clay-relief.v4.js';
import { TOOLMIX } from '../lab-clay/clay-toolmix.v1.js';

export const VFX_MODES = { normal: { cap: 220, rate: 1 }, low: { cap: 72, rate: 0.35 }, legacy: { cap: 0, rate: 0 } };
const FIG_TOOLS = { thumb: { k: 0.45, s: 0.22, c: 0.5 }, dent: { k: 0.3, s: 0.28, c: 0.4 } };   // Setzung (wie K2 vehicle, kleiner)
const FACE_RE = /(eye|lid|pupil|iris|mouth|brow|face|lash|emanata|host)/i;

export async function installClayWorld(c, opt = {}) {
  const T = c.THREE, host = c.host, gf = c.gf;
  const params = new URLSearchParams(location.search);
  const clayOn = params.get('clay') !== '0';
  const rep = { clayOn, reliefMs: 0, toolMs: 0, converted: 0, skipped: 0, cache: 0, vfx: { spawned: 0, dropped: 0, peak: 0 } };
  let mode = (params.get('vfx') || localStorage.getItem('kfb-v6k-vfx') || 'normal'); if (!VFX_MODES[mode]) mode = 'normal';

  /* Licht: ?light= (Standard 0,85) skaliert Belichtung und Umgebung, ohne Spielwert. */
  const LIGHT = +(params.get('light') || 0.85);
  if (host.renderer) { rep.exposure0 = host.renderer.toneMappingExposure; host.renderer.toneMappingExposure = rep.exposure0 * LIGHT; }
  /* ── Material ─────────────────────────────────────────────────────────────── */
  let U = null; const cache = new Map();
  const tex = (d, N) => { const t = new T.DataTexture(d, N, N, T.RGBAFormat); t.wrapS = t.wrapT = T.RepeatWrapping; t.magFilter = T.LinearFilter; t.minFilter = T.LinearMipmapLinearFilter; t.generateMipmaps = true; t.anisotropy = 4; t.needsUpdate = true; return t; };
  if (clayOn) {
    /* 512² statt K2-1024²: gleiche Weltmaße (Kachel/Handmaß unverändert), ¼ Rechenzeit beim Start. Abweichung, dokumentiert. */
    const RN = +(params.get('clayRes') || 512);
    await new Promise((r) => setTimeout(r, 0));
    const rel = makeClayRelief({ size: RN, seed: 31 }); rep.reliefMs = Math.round(rel.ms || 0);
    const relT = tex(rel.data, RN);
    const tools = await makeToolReliefs({ size: RN, seed: 41 }); rep.toolMs = Math.round(tools.ms || 0); rep.res = RN;
    U = CM.makeClayUniforms(T, relT);
    [U.uClayToolA.value, U.uClayToolB.value, U.uClayToolC.value] = tools.maps.map((d) => tex(d, RN));
    U.uClayToolOn.value = 1; U.uClayLegacyStroke.value = 0; U.uClayMottle.value = 0.04;
    U.uClayPrint.value = relT; U.uClayPrintOn.value = 0;   // Fingerabdruck-Aufnahme (ref/clay-joebinns) nicht im Arena-Export
  }
  const profileFor = (kind) => {
    const P = CM.PROFILES;
    if (kind === 'figure') return { ...P.figure, tools: FIG_TOOLS, legacy: 0 };
    if (kind === 'prop') return { ...P.prop, tools: TOOLMIX.rock, legacy: 0, scale: 0.35 };
    if (kind === 'ammo') return { ...P.prop, tools: FIG_TOOLS, legacy: 0, scale: 0.25, gouge: 0, crack: 0 };
    if (kind === 'terrain') return { ...P.terrainFg, tools: TOOLMIX.terrain, legacy: 0 };
    return { ...P.prop, legacy: 0 };
  };
  const convertible = (m) => m && !m.userData?.clay && (m.isMeshStandardMaterial || m.isMeshPhysicalMaterial || m.isMeshLambertMaterial || m.isMeshPhongMaterial || m.isMeshToonMaterial)
    && !m.transparent && !(m.opacity < 1);
  const clayMat = (src, kind) => {
    const key = kind === 'ammo' && src.color ? 'ammo:' + src.color.getHexString() + ':' + (src.map ? src.map.uuid : '-') : src.uuid + ':' + kind;   // Munition: je Farbe EIN Clay-Material (sonst wächst der Cache je Schuss)
    if (!cache.has(key)) { const cm = CM.makeClayMaterial(T, U, { src, profile: profileFor(kind) });
      /* Licht (Georg 30.09.: »zu hell, überstrahlt«): Clay-Physical kam mit envMapIntensity 1 + Sheen — der Wirt ist auf 0,3 kalibriert (host.v1 Z. 140). */
      cm.envMapIntensity = 0.3 * LIGHT; cm.sheen *= 0.45; cache.set(key, cm); rep.cache = cache.size; }
    return cache.get(key);
  };
  let seedN = 1;
  const clayify = (root, kind) => {
    if (!U || !root) return 0; let n = 0;
    root.traverse((o) => {
      if (!o.isMesh) return;
      let p = o, face = false; while (p) { if (FACE_RE.test(p.name || '')) { face = true; break; } p = p.parent; if (p === root.parent) break; }
      const mats = [].concat(o.material);
      if (face || !mats.every(convertible)) { rep.skipped++; return; }
      if (!o.geometry.attributes.claySeed) { o.geometry = o.geometry.clone(); CM.seedGeometry(T, o.geometry, 7919 * (seedN++)); }
      const next = mats.map((m) => clayMat(m, kind));
      o.material = Array.isArray(o.material) ? next : next[0];
      o.castShadow = true; o.receiveShadow = true; n++; rep.converted++;
    });
    return n;
  };

  /* Kein Knet-Tisch (Georg 30.09.: »die blaue Platte scheint ein Bug/Missverständnis«). Boden = Karte (A2-Owner), bleibt Papier. */
  if (U) {
    clayify(c.fb && (c.fb.figure || c.fb.root), 'figure');
    for (const m of c.mb.mobs) clayify(m.root, 'figure');
    const R = gf.rewards; if (R) { clayify(R.skull, 'prop'); clayify(R.coin, 'prop'); for (const k in R.props) clayify(R.props[k], 'prop'); }
    if (c.kaykit) { const prev = c.kaykit.onSpawn; c.kaykit.onSpawn = (b) => { prev && prev(b); for (const m of c.mb.mobs) clayify(m.root, 'figure'); }; }
    else { const sp = c.mb.spawn.bind(c.mb); c.mb.spawn = async (...a) => { const b = await sp(...a); for (const m of c.mb.mobs) clayify(m.root, 'figure'); return b; }; }
    const w0 = gf._wuerfel.bind(gf); gf._wuerfel = (...a) => { const g = w0(...a); clayify(g, 'ammo'); return g; };
  }

  /* Tusche-Knete (Georg 30.09.): Zensur-Schicht nicht flach schwarz, sondern beleuchtete, glänzende Knete,
     die Schatten der Figuren annimmt. Die Karte baut die Schicht je Karte neu → alle 0,5 s nachsehen. */
  const inkDone = new WeakSet();
  const inkify = () => {
    if (!U || !c.ring || !c.ring.current) return;
    c.ring.current.traverse((o) => {
      if (!o.isMesh || o.name !== 'zensur-schicht' || inkDone.has(o)) return;
      const old = o.material; inkDone.add(o);
      if (!o.geometry.attributes.claySeed) { o.geometry = o.geometry.clone(); CM.seedGeometry(T, o.geometry, 1313); }
      const m = CM.makeClayMaterial(T, U, { src: old, profile: { ...CM.PROFILES.water, legacy: 0, tools: TOOLMIX.cloud, scale: 0.6 } });
      m.color.setRGB(5.2, 4.8, 4.5);   // Karte trägt Tusche #1f1a14 (linear ~0,012) → ×5 = dunkles Knet-Graubraun statt Schwarz m.transparent = true; m.depthWrite = false; m.toneMapped = true;
      m.polygonOffset = true; m.polygonOffsetFactor = old.polygonOffsetFactor ?? -4; m.polygonOffsetUnits = old.polygonOffsetUnits ?? -4;
      m.envMapIntensity = 0.35 * LIGHT; m.roughness = 0.5;
      o.material = m; o.receiveShadow = true; rep.ink = (rep.ink || 0) + 1;
    });
  };
  if (U && params.get('ink') !== 'flat') { inkify(); setInterval(inkify, 500); }

  /* ── Clay-VFX-Pool ────────────────────────────────────────────────────────── */
  const MAX = VFX_MODES.normal.cap;
  const geo = new T.IcosahedronGeometry(1, 2); if (U) CM.seedGeometry(T, geo, 99);
  const mat = U ? CM.makeClayMaterial(T, U, { src: new T.MeshStandardMaterial({ color: 0xffffff }), profile: { ...CM.PROFILES.cloud, legacy: 0, scale: 0.2 } })
    : new T.MeshStandardMaterial({ color: 0xffffff, roughness: 0.9 });
  const pool = new T.InstancedMesh(geo, mat, MAX); pool.name = 'v6k-clay-vfx'; pool.frustumCulled = false;
  pool.instanceMatrix.setUsage(T.DynamicDrawUsage); pool.castShadow = false; pool.receiveShadow = false;
  pool.setColorAt(0, new T.Color(1, 1, 1)); pool.count = 0; host.scene.add(pool);
  const P = []; let seed = 0x9e3779b9;
  const rnd = () => { seed |= 0; seed = (seed + 0x6D2B79F5) | 0; let t = Math.imul(seed ^ (seed >>> 15), 1 | seed); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
  const col = new T.Color(), mtx = new T.Matrix4(), q = new T.Quaternion(), sc = new T.Vector3(), pv = new T.Vector3(), up = new T.Vector3(0, 1, 0), dir = new T.Vector3();
  const floor = () => host.field.floorY();
  function emit(kind, at, o = {}) {
    const M = VFX_MODES[mode]; if (!M.cap || !at) return 0;
    const want = Math.max(1, Math.round((o.n || 6) * M.rate));
    let made = 0;
    for (let i = 0; i < want; i++) {
      if (P.length >= M.cap) { rep.vfx.dropped++; break; }
      const a = rnd() * Math.PI * 2, sp = (o.speed || 2.2) * (0.5 + rnd() * 0.7), upv = (o.up ?? 2.4) * (0.6 + rnd() * 0.6);
      const r = (o.size || 0.07) * (0.6 + rnd() * 0.7);
      const cc = Array.isArray(o.color) ? o.color[i % o.color.length] : (o.color ?? 0xe9c14a);
      P.push({ kind, x: at.x + (o.spread || 0) * (rnd() - 0.5), y: at.y, z: at.z + (o.spread || 0) * (rnd() - 0.5),
        vx: Math.cos(a) * sp + (o.vx || 0), vy: upv, vz: Math.sin(a) * sp + (o.vz || 0), r, t: 0, life: (o.life || 0.9) * (0.75 + rnd() * 0.5),
        stuck: false, sq: 0, col: cc, grav: o.grav ?? 11, drag: o.drag ?? 0.6 });
      made++;
    }
    rep.vfx.spawned += made; rep.vfx.peak = Math.max(rep.vfx.peak, P.length);
    return made;
  }
  function step(dt) {
    const fy = floor();
    for (let i = P.length - 1; i >= 0; i--) {
      const p = P[i]; p.t += dt;
      if (p.t >= p.life) { P.splice(i, 1); continue; }
      if (!p.stuck) {
        p.vy -= p.grav * dt; const k = Math.exp(-p.drag * dt); p.vx *= k; p.vz *= k;
        p.x += p.vx * dt; p.y += p.vy * dt; p.z += p.vz * dt;
        if (p.y - p.r * 0.35 <= fy + 0.012 && host.field.inside(p.x, p.z)) { p.y = fy + 0.012 + p.r * 0.35; p.stuck = true; p.sq = 1; }
      }
    }
    const n = Math.min(P.length, MAX);
    for (let i = 0; i < n; i++) {
      const p = P[i], fade = Math.min(1, (p.life - p.t) / 0.28), s = p.r * Math.max(0.001, fade);
      if (p.stuck) { q.identity(); sc.set(s * 1.45, s * 0.38, s * 1.45); }   // Klecks: plattgedrückt, bleibt kurz liegen
      else {
        const v = Math.hypot(p.vx, p.vy, p.vz), st = Math.min(0.45, v * 0.05);
        dir.set(p.vx, p.vy, p.vz).normalize(); q.setFromUnitVectors(up, v > 0.01 ? dir : up);
        sc.set(s * (1 - st * 0.5), s * (1 + st), s * (1 - st * 0.5));      // Streckung entlang der Flugbahn, volumenähnlich
      }
      pv.set(p.x, p.y, p.z); mtx.compose(pv, q, sc); pool.setMatrixAt(i, mtx); pool.setColorAt(i, col.setHex(p.col));
    }
    pool.count = n; pool.instanceMatrix.needsUpdate = true; if (pool.instanceColor) pool.instanceColor.needsUpdate = true;
  }

  /* Ereignisse: alle an vorhandene Callbacks gekettet — der alte Aufrufer läuft zuerst. */
  const chainSafe = true;
  const chain = (obj, key, fn) => { const prev = obj[key]; obj[key] = function (...a) { const r = prev ? prev.apply(this, a) : undefined; try { fn(...a); } catch (e) { console.warn('[clay-vfx] ' + key, e); } return r; }; };
  chain(gf, 'onShot', (von) => emit('muzzle', von, { n: 5, color: [0xe9c14a, 0xf3ead3], speed: 1.4, up: 1.2, size: 0.045, life: 0.35, grav: 4 }));
  chain(gf, 'onHit', (m, pos) => pos && emit('hit', pos, { n: 8, color: [0xe8e0cc, 0xe9c14a, 0xb8361f], speed: 2.4, up: 2.2, size: 0.06, life: 0.9 }));
  const kill0 = gf._kill.bind(gf);
  gf._kill = (m, ...a) => { const wasDead = m && m.tot; const r = kill0(m, ...a); if (m && !wasDead && m.tot) { const at = { x: m.pos.x, y: m.pos.y + (m.hoehe || 1) * 0.5, z: m.pos.z }; emit('ko', at, { n: 18, color: [0xe8e0cc, 0xd8cfb8, (m.e && m.e.bolt) || 0x9ad63f, 0x1f1a14], speed: 3, up: 3.4, size: 0.085, life: 1.3, spread: 0.3 }); } return r; };
  chain(gf, 'onSkullBounce', (pos, i) => emit('land', { x: pos.x, y: floor() + 0.05, z: pos.z }, { n: [7, 4, 2][i] || 2, color: [0xe8e0cc, 0xd8cfb8], speed: 1.8, up: 1.2, size: 0.05, life: 0.8 }));
  chain(gf, 'onPickup', (p, result) => {
    const at = p && p.grp ? p.grp.position : null; if (!at) return;
    const k = p.kind;
    if (k === 'waterbomb' || k === 'smokebomb') emit('prop_break', at, { n: 26, color: k === 'waterbomb' ? [0x45b4ad, 0x2f7a72, 0xf3ead3] : [0xac82dc, 0x78559f, 0xe8e0cc], speed: 4.2, up: 3.2, size: 0.09, life: 1.2, spread: 0.2 });
    else emit('reward', at, { n: 7, color: k === 'coin' ? [0xe9c14a, 0xf2c230] : k === 'heal' ? [0x5fbf3a, 0x9ad63f] : [0xe9c14a], speed: 1.6, up: 2.8, size: 0.05, life: 0.8, grav: 8 });
  });
  const trail = new WeakMap();
  let air = false, lastY = 0, acc = 0;
  const frame = (dt) => {
    if (!dt || dt > 0.25) dt = 0.016;
    const M = VFX_MODES[mode];
    if (M.cap) {
      acc += dt;
      if (acc >= 0.04 / Math.max(0.2, M.rate)) {
        acc = 0;
        for (const s of gf.schuesse) {
          if (!s.grp || (s.leben != null && s.leben < 0.2)) continue;
          const n = (trail.get(s) || 0) + 1; trail.set(s, n); if (n > 40) continue;
          const pz = s.grp.position;
          emit('trail', pz, { n: 1, color: s.von === 'spieler' ? 0xe9c14a : 0xe8e0cc, speed: 0.15, up: 0.2, size: 0.032, life: 0.32, grav: 2, drag: 3 });
        }
      }
      const pc = c.pc; if (pc && pc.pos) {
        const fy = floor(), h = pc.pos.y - fy;
        if (h > 0.08) air = true;
        else if (air && h <= 0.02 && lastY > pc.pos.y) { air = false; emit('land', { x: pc.pos.x, y: fy + 0.03, z: pc.pos.z }, { n: 9, color: [0x3aa596, 0x2f8f83, 0xe8e0cc], speed: 2.2, up: 1.1, size: 0.05, life: 0.7 }); }
        lastY = pc.pos.y;
      }
    }
    step(dt);
  };
  const setMode = (m) => { if (!VFX_MODES[m]) return; mode = m; try { localStorage.setItem('kfb-v6k-vfx', m); } catch (e) {} if (!VFX_MODES[m].cap) { P.length = 0; pool.count = 0; } c.setState && c.setState({ vfxMode: m }); };
  const api = { rep, emit, frame, setMode, get mode() { return mode; }, clayify, pool, particles: () => P.length, uniforms: U };
  window.__CLAY_V6 = api;
  c.clay = api;
  return api;
}

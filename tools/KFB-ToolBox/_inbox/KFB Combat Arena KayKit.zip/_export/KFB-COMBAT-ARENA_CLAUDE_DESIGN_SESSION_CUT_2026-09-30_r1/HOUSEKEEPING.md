# HOUSEKEEPING · 2026-09-30

## Im ZIP, aber nicht vom Entry Point geladen (Kontext/Rückfall)
- `index.html` (Rückfall 5A/A1), `CD-COMBAT-CLAY-KAYKIT-01 Vorlauf.dc.html`, `support.js` (Runtime für Vorlauf), `site/portal.css`, `lab-clay/clay-tools.v1.js`, `_handover/B0_RETURN.md`.
- `assets/4a/smoke/*`, `assets/5a/{chest,knife,pencil_*}` Texturen: aus B0 übernommen, Nutzung durch Owner nicht einzeln geprüft.

## Nicht exportiert (LOCAL_NOT_EXPORTED)
- `uploads/` (2 Bildschirmfotos von Georg, eines 4,0 MB > 2-MB-Grenze).
- `.thumbnail`, temporäre Export-Hilfsdateien.
- Angehängter lokaler Ordner „KFB Joyride 01_2026_9_29-15_8_46“: anderes Projekt, nicht Teil dieses Cuts.

## Aufräumkandidaten (nicht ausgeführt)
- `combat-arena-v3/gutter.v3.js` + `gutter.v5.js` beide vorhanden; klären, welcher aktiv ist.
- `lab-clay/clay-relief.v2.js` neben v4.
- Duplikat `tools_bits_texture.png` (5×) und `dungeon_texture.png` (2×) in `assets/5a/`.

# HANDOVER · Claude Design → WSA · 2026-09-30

## Was das ist
Spielbarer KayKit-Kandidat der KFB Combat Arena (Slice CD-COMBAT-CLAY-KAYKIT-01) auf Basis `georg-doc/KFB-Combat-Arena@f6a59ad` (B0-Kopie). Ersatz für die kaputte veröffentlichte Fassung, sobald abgenommen.

## Entscheidungen (Georg, 30.09.)
- Warrior: läuft heran, Schaden nur über den bestehenden Biss-Takt. Kein Melee-System.
- Schild-Slot ausgeblendet, bis ein Owner Daten liefert.
- Keine Erklärtexte, Paletten, Debug-Elemente im Sichtfeld. Steuerung nur im Pause-Overlay.
- HUD im Knet-Racer-Look (Joyride J13): Leben, Stockwerk/Gegner, Munition/Cooldown, Rewards, Menüknopf.
- Licht ~85 %, halber Glanz. Zensur-Tinte = dunkle Tusche-Knete, nimmt Figurenschatten an.
- Gegnerwürfe aus Handhöhe, Flugbahn unverändert.
- Boden bleibt Papier (A2). Knet-Tisch verworfen.

## Architektur
- KayKit-Gegner (Minion/Mage/Warrior) über zwei Nähte im bestehenden M3: `mb.R` und `mb.loader` (`combat-arena-v6/kaykit-enemies.v6.js`). Kein zweiter Mob-Controller.
- `combat-arena-v6/fun.v6k.js` ersetzt `fun.v4.js` nur in der Kopie.
- `combat-arena-v6/clay-world.v6.js`: K2-Knetmaterial + Clay-VFX-Pool (eigener RNG).
- `combat-arena-v6/clay-hud.v6.js`: HUD-Look.
- FrizzleBob: Kenney-Fallback mit Gelb-Tint (`assets/models/FrizzleBob_Yellow*.gltf`).

## Offen (Problem zuerst)
1. Georgs Hand-/Augenabnahme im sichtbaren Tab fehlt (alle Läufe waren Bot + Harness im verdeckten Tab).
2. Gate 6 (Clipping, Schattenakne, Texturflimmern in Nahaufnahme) ungeprüft.
3. Münzaufnahme nie belegt (Bot hat 0 Münzen aufgesammelt).
4. Licht und Tinte nicht visuell verifiziert.
5. Einmaliger Fehler `Cannot read properties of undefined (reading 'x')`, Quelle unklar.
6. Clay-Material schaltet 1–6 s nach Start um (sichtbarer Wechsel).
7. FrizzleBob Driver v3 / v5 fehlt: **SOURCE_REQUIRED** (`frizzlebob-driver-adapter.v2.js` weder im Repo noch im Projekt).
8. Warrior-Standpause bei Aggro (0,42 s alle ~1,6 s), Combat-Core-Owner.
9. Kartenrückseite `media/kfb/KayfaBizarro_Card_Backside_01_lowrez.png` fehlt (404, `combat-arena-v1/arena-ring.v1.js` erwartet sie lokal). Schon im Workspace so, im Export nicht ersetzt. REPLAY_DEPENDENCY_MISSING.
10. Fingerabdruck-Aufnahme `ref/clay-joebinns` fehlt, Abdrücke im Material aus.

## Nicht angefasst
`index.html`, alle v1–v4-Owner. Rollback = `combat-arena-v6/` und die Kopie löschen.

## Next Gate
**Georg spielt `KFB Combat Arena KayKit.dc.html` 60 s im sichtbaren Tab und nimmt Münzaufnahme, Nahaufnahme-Clipping (Gate 6), Licht und Tinte ab.** Erst danach DESIGN PASS.

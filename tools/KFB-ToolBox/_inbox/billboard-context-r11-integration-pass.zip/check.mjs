import fs from 'node:fs';
import { chromium } from 'playwright';

const root = 'http://127.0.0.1:4173/tools/KFB-ToolBox/_handover/BILLBOARD_CONTEXT_R11_2026-10-02/';
const url = root + 'index.html?state=idle&packId=forget_utopia&card=7';
const report = { url, checks: [], pageErrors: [], consoleErrors: [], requestFailures: [], httpErrors: [], boot: {}, shots: [] };
const check = (name, pass, detail=null) => {
  report.checks.push({ name, pass: !!pass, detail });
  if (!pass) process.exitCode = 1;
};
const browser = await chromium.launch({
  headless: true,
  args: ['--use-angle=swiftshader', '--enable-unsafe-swiftshader']
});
const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });
page.on('pageerror', e => report.pageErrors.push(String(e)));
page.on('console', m => {
  if (m.type() === 'error') report.consoleErrors.push(m.text());
});
page.on('requestfailed', req => report.requestFailures.push({
  url: req.url(),
  error: req.failure()?.errorText || 'unknown'
}));
page.on('response', res => {
  if (res.status() >= 400) report.httpErrors.push({ url: res.url(), status: res.status() });
});

async function snap(state, file) {
  await page.evaluate(s => window.__r11.setState(s), state);
  await page.waitForFunction(s => {
    const r = window.__r11?.snapshot();
    return r?.ready && r?.context?.state === s;
  }, state, { timeout: 90000 });
  await page.waitForTimeout(1200);
  const s = await page.evaluate(() => window.__r11.snapshot());
  await page.screenshot({ path: 'artifacts/billboard-context-r11-integration/' + file, fullPage: true });
  report.shots.push({ state, file, snapshot: s });
  return s;
}

try {
  const response = await page.goto(url, { waitUntil: 'domcontentloaded', timeout: 90000 });
  check('candidate HTTP', !!response && response.ok(), response?.status());

  try {
    await page.waitForFunction(() => !!window.__r11, {}, { timeout: 20000 });
    report.boot.module = 'PASS';
  } catch (e) {
    report.boot.module = 'FAIL';
    report.boot.scripts = await page.evaluate(() =>
      [...document.scripts].map(s => ({ src: s.src, type: s.type }))
    );
    throw new Error('R11_MODULE_BOOT_TIMEOUT');
  }

  try {
    await page.waitForFunction(() => {
      const r = window.__r11?.snapshot?.();
      return !!r?.sourceFace;
    }, {}, { timeout: 60000 });
    report.boot.hero = 'PASS';
  } catch (e) {
    report.boot.hero = 'FAIL';
    report.boot.snapshot = await page.evaluate(() => window.__r11?.snapshot?.() || null);
    throw new Error('R11_HERO_MOUNT_TIMEOUT');
  }

  try {
    await page.waitForFunction(() => window.__r11?.snapshot?.()?.ready, {}, { timeout: 90000 });
    report.boot.initialReady = 'PASS';
  } catch (e) {
    report.boot.initialReady = 'FAIL';
    report.boot.snapshot = await page.evaluate(() => window.__r11?.snapshot?.() || null);
    throw new Error('R11_INITIAL_READY_TIMEOUT');
  }

  const idle = await snap('idle', '01-idle-h13.png');
  check('idle uses real H13', idle.mode === 'hyper' && idle.h13?.ready, idle);
  check('context pack bound', idle.context?.packId === 'forget_utopia', idle.context);
  check('no invented island/resident binding', idle.context?.islandId == null && idle.context?.residentId == null, idle.context);
  check('H13 face is 1024x512', idle.h13?.face?.width === 1024 && idle.h13?.face?.height === 512, idle.h13);
  check('H13 prop seam retained', idle.h13?.propSeam === '__dcSetProps', idle.h13);

  const approach = await snap('approach', '02-approach-cover.png');
  check('approach uses real cover', approach.mode === 'cover' && /cover page 1/i.test(approach.content || ''), approach.content);

  const focus = await snap('focus', '03-focus-card.png');
  check('focus uses selected card', focus.mode === 'quarter' && /#7/.test(focus.content || ''), focus.content);

  const interact = await snap('interact', '04-interact-card.png');
  check('interact holds selected card', interact.mode === 'quarter' && interact.ready, interact.content);

  const mediaFront = await snap('media', '05-media-front.png');
  check('media uses B2a CSS3D iframe', mediaFront.mode === 'video' && mediaFront.dom?.iframeSrc?.includes('youtube-nocookie.com'), mediaFront.dom);
  check('media front visible', mediaFront.css3d?.frontFacing === true && mediaFront.dom?.objectVisible === true, mediaFront.css3d);
  check('no modal', mediaFront.dom?.modalElementExists === false, mediaFront.dom);

  await page.evaluate(() => window.__r11.setView('BACK'));
  await page.waitForTimeout(800);
  const mediaBack = await page.evaluate(() => window.__r11.snapshot());
  await page.screenshot({ path: 'artifacts/billboard-context-r11-integration/06-media-back.png', fullPage: true });
  check('B2a rear cull retained', mediaBack.css3d?.frontFacing === false && mediaBack.dom?.objectVisible === false, mediaBack.css3d);

  await page.evaluate(() => window.__r11.setView('FRONT'));
  const returned = await snap('idle', '07-return-idle.png');
  check('return restores ambient H13', returned.mode === 'hyper' && returned.h13?.ready, returned);
  check('no page errors', report.pageErrors.length === 0, report.pageErrors);
} catch (e) {
  report.pageErrors.push(String(e?.stack || e));
  process.exitCode = 1;
} finally {
  report.status = process.exitCode ? 'FAIL' : 'PASS';
  report.passed = report.checks.filter(x => x.pass).length;
  report.total = report.checks.length;
  fs.writeFileSync(
    'artifacts/billboard-context-r11-integration/report.json',
    JSON.stringify(report, null, 2) + '\n'
  );
  console.log(JSON.stringify({
    status: report.status,
    checks: report.passed + '/' + report.total,
    pageErrors: report.pageErrors.length
  }, null, 2));
  await browser.close();
}

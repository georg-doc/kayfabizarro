import { openPage } from './_page.mjs'
import { TESTFAHRT_HASH } from '../src/siteHash.js'
const { browser, page } = await openPage(TESTFAHRT_HASH + ',debug,mute,clean,drivepanel=0,hour=12,tlapse=0')
await page.waitForFunction(() => window.__kfbM1?.clock?.steps > 200 && !window.__kfbM1.player()?.frozen?.(), null, { timeout: 240000 })
console.log(JSON.stringify(await page.evaluate(() => { const c = window.__kfbM1.camera3; const t = typeof c === 'function' ? c() : c; return { typ: typeof c, keys: t ? Object.keys(t).slice(0, 30) : null, isCam: !!t?.isCamera, orbit: Object.keys(window.__kfbStageOrbit || {}), zoom: Object.keys(window.__kfbStageZoom || {}), camRoll: typeof window.__kfbCamRoll, player: Object.keys(window.__kfbM1.player() || {}).slice(0, 30) } })))
await browser.close()

# Slot-Plaketten im Skin (Georg q533, 05.11.): die neutralen R7-Leisten des HUD-Chats (KFB_HUD_Slot_Bases_R7_288, neutral/bar_1..8.png) mit hudskin.recolor einfärben,
# Rand = Skin-Rand (hud-skins.r2.json) auf die Helligkeit des dunklen Bezugs (REF rim, die alte dunkelbraune Plakette) gesetzt: dunkel und satt in jedem Skin, Form und Alpha unverändert.
# Aufruf: python3 scripts/hud-kit/r7-plaques.py <R7-Ordner mit neutral/> <hudkit-Ordner>   Ausgabe: sk_<skin>_ui_bar_<n>.webp (verlustfrei)
import sys, os, json
import numpy as np
from PIL import Image
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
from hudskin import recolor, REF
R7, HUD = sys.argv[1], sys.argv[2]
SK = json.load(open(os.path.join(HERE, '..', '..', 'src', 'data', 'hud', 'hud-skins.r2.json')))['skins']
TARGET = float(np.mean(REF['rim']))   # Helligkeit der alten Plakette (93, 77, 65)
for sid, c in SK.items():
  rim = np.array(c['rim'], float); rim = np.clip(rim * TARGET / rim.mean(), 0, 255)
  for n in range(1, 9):
    A = np.array(Image.open(os.path.join(R7, 'neutral', f'bar_{n}.png')).convert('RGBA')); B = recolor(A, {'rim': tuple(rim), 'fill': tuple(c['fill'])})
    assert np.array_equal(B[..., 3], A[..., 3]); Image.fromarray(B).save(os.path.join(HUD, f'sk_{sid}_ui_bar_{n}.webp'), 'WEBP', lossless=True)
  print(sid, 'Rand', [round(v) for v in rim])

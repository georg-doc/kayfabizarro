// Arena R1 · Beleg Hocke in Deckung (WS0 11.11.): Soldat hinter Deckung geduckt (idle_crouching), im Anschlag (idle_crouching_aiming), dann aufgestanden und feuernd
// (firing_rifle_standing); Seitenblick figur_seite auf der Sonnenseite, Stadt-Instanzen auf der Sichtlinie nur fürs Bild auf Größe 0 (Deckung im Umkreis 2,5 m bleibt stehen).
// Dazu ein erhöhtes Spielbild: FB und die zwei nächsten Soldaten im Kader, nah genug, dass die Figuren lesbar sind. Szene wie _arena-taktik ORT=markt.
// Aufruf: PW_GPU=1 node test/_arena-hocke.mjs → test/out/arena-hocke/
import fs from 'fs'
import { startServer, openAudioPage } from './_audioServer.mjs'
import { TESTFAHRT_HASH } from '../src/siteHash.js'
import { belegVorbereiten, belegKamera, belegFoto, belegFreigeben } from './lib/beleg.mjs'
const OUT = 'test/out/arena-hocke' + (process.env.TAG ? '-' + process.env.TAG : ''); fs.mkdirSync(OUT, { recursive: true })
const log = (k, v) => console.log(k, JSON.stringify(v))
const srv = await startServer()
try {
  const A = await openAudioPage(srv.url, TESTFAHRT_HASH + ',debug,mute,tod=13' + (process.env.EXTRA || ''), { viewport: { width: 1280, height: 820 } }), p = A.page
  await p.waitForFunction(() => window.__kfbM1?.clock?.steps > 200 && window.__kfbM1.mods.player.status?.()?.actor?.status === 'OK', null, { timeout: 300000 })
  await p.evaluate(() => setInterval(() => { if (window.__kfbCardHero?.state?.().phase === 'shown') document.querySelector('[data-ui=card-hero-ok]')?.click() }, 300))
  await p.waitForFunction(() => window.__kfbArena?.gegner?.status?.().status === 'OK', null, { timeout: 240000 })
  await p.waitForTimeout(6000)
  log('ORT', await p.evaluate(() => { const A = window.__kfbArena, M = window.__kfbM1, t = A.stadt.tor(), m = A.stadt.markt(), L = Math.hypot(m[0] - t[0], m[2] - t[2]), ux = (m[0] - t[0]) / L, uz = (m[2] - t[2]) / L
    for (const d of [L * 0.55, L * 0.5, L * 0.6, L * 0.45]) { const x = t[0] + ux * d, z = t[2] + uz * d; if (A.stadt.frei(x, z, 1.2)) { M.player().teleport([x, M.terrainH(x, z) + 0.4, z], Math.atan2(ux, uz)); return [x, z] } } return null }))
  await p.evaluate(() => { window.__kfbArena.godMode(true) }); await p.waitForTimeout(1500)
  log('ALARM', await p.evaluate(() => window.__kfbArena.gegner.hoereSchuss()))
  await belegVorbereiten(p, { kanon: false })
  const freieSicht = (id) => p.evaluate((id) => { const M = window.__kfbM1, T = M.three(), c = window.__kfbBelegCam, cam = new T.Vector3(...c.pos), f = window.__kfbArena.gegner.figur(id).getWorldPosition(new T.Vector3()), weg = window.__kfbSichtWeg = [], m = new T.Matrix4(), b = new T.Box3(), hit = new T.Vector3(), mitte = new T.Vector3()
    for (const h of [0.5, 1.0, 1.5]) { const z = f.clone(); z.y += h; const ray = new T.Ray(cam, z.clone().sub(cam).normalize()), L = cam.distanceTo(z)
      window.__kfbArena.stadt.object3d.traverse((im) => { if (!im.isInstancedMesh) return; im.geometry.computeBoundingBox(); for (let i = 0; i < im.count; i++) { im.getMatrixAt(i, m); b.copy(im.geometry.boundingBox).applyMatrix4(m); b.getCenter(mitte)
        if (Math.hypot(mitte.x - f.x, mitte.z - f.z) < 2.5) continue; if (ray.intersectBox(b, hit) && hit.distanceTo(cam) < L - 0.5) { weg.push([im, i, m.clone()]); im.setMatrixAt(i, new T.Matrix4().makeScale(0, 0, 0)); im.instanceMatrix.needsUpdate = true } } }) }
    return weg.length }, id)
  const sichtZurueck = () => p.evaluate(() => { for (const [im, i, m] of window.__kfbSichtWeg || []) { im.setMatrixAt(i, m); im.instanceMatrix.needsUpdate = true } window.__kfbSichtWeg = [] })
  const box = (id) => p.evaluate((id) => { const T = window.__kfbM1.three(), f = window.__kfbArena.gegner.figur(id); f.updateMatrixWorld(true); const q = f.getWorldPosition(new T.Vector3()), v = new T.Vector3(0, 0, 1).applyQuaternion(f.getWorldQuaternion(new T.Quaternion())); return { min: [q.x - 0.5, q.y, q.z - 0.5], max: [q.x + 0.5, q.y + 1.8, q.z + 0.5], vorn: [v.x, v.z] } }, id)
  const foto = async (id, name) => { const k = await belegKamera(p, 'figur_seite', { objekt: await box(id), rahmen: 2.2 }); if (k?.gegenlicht) return { gegenlicht: k.fehler }
    const n = await freieSicht(id); await p.evaluate(() => new Promise((r) => requestAnimationFrame(() => requestAnimationFrame(r))))
    const st = await p.evaluate((id) => window.__kfbArena.gegner.status().gegner.find((g) => g.id === id), id)
    let r; try { r = await belegFoto(p, `${OUT}/${name}.png`) } catch (e) { r = { fehler: e.message.slice(0, 140) } } await sichtZurueck(); await belegFreigeben(p); return { ...r, weg: n, clip: st.clip, haltung: st.haltung, phase: st.phase } }
  const inReichweite = (g) => p.evaluate((g) => { const M = window.__kfbM1, T = M.three(), q = M.mods.player.object3d.getWorldPosition(new T.Vector3()), R = { gewehr: 30, streu: 16, schnell: 24, scharf: 45 }[g.art]; return Math.hypot(g.x - q.x, g.z - q.z) < R * 0.9 }, g)
  const st = () => p.evaluate(() => window.__kfbArena.gegner.status().gegner.filter((g) => g.hp > 0))
  // 1/2 Kandidaten: geduckte Soldaten in Reichweite seitlich fotografieren; wer danach innerhalb 20 s aufsteht und feuert, wird Beleg (Hocke = Bild 1, Feuer = Bild 2)
  const kand = new Map(); let fertig = null; const tStart = Date.now()
  while (!fertig && Date.now() - tStart < 120000) {
    for (const g of await st()) {
      const k = kand.get(g.id)
      if (k && g.clip === 'firing_rifle_standing' && Date.now() - k.t < 20000) { const r = await foto(g.id, '2_auf_und_feuer'); log('FEUER', { id: g.id, ...r }); if (r.clip === 'firing_rifle_standing' && !r.fehler && !r.gegenlicht) { fs.copyFileSync(k.datei, `${OUT}/1_hocke_in_deckung.png`); log('HOCKE', k); fertig = g.id; break } }
      if ((!k || Date.now() - k.t > 20000) && g.zustand === 'schiessen' && /^idle_crouching/.test(g.clip) && (await inReichweite(g))) { const datei = `${OUT}/kand_${g.id}.png`, r = await foto(g.id, `kand_${g.id}`); if (!r.gegenlicht && !r.fehler && /^idle_crouching/.test(r.clip)) kand.set(g.id, { t: Date.now(), datei, ...r }) } }
    await p.waitForTimeout(60) }
  for (const f of fs.readdirSync(OUT)) if (f.startsWith('kand_')) fs.renameSync(`${OUT}/${f}`, `${OUT}/_${f}`)
  if (!fertig) log('VERPASST', [...kand.keys()])
  // 4 erhöhtes Spielbild: FB und die zwei nächsten Soldaten im Kader, Sonnenseite, Uhr kurz angehalten, Ansicht auf Kamerakopie
  const r4 = await p.evaluate(async () => { const M = window.__kfbM1, T = M.three(), C = M.clock, q = M.mods.player.object3d.getWorldPosition(new T.Vector3()), W = window.__kfbArena.gegner.status().gegner.filter((g) => g.hp > 0 && g.rolle).sort((a, b) => Math.hypot(a.x - q.x, a.z - q.z) - Math.hypot(b.x - q.x, b.z - q.z)).slice(0, 2)
    const xs = [q.x, ...W.map((g) => g.x)], zs = [q.z, ...W.map((g) => g.z)], cx = (Math.min(...xs) + Math.max(...xs)) / 2, cz = (Math.min(...zs) + Math.max(...zs)) / 2, ext = Math.max(Math.max(...xs) - Math.min(...xs), Math.max(...zs) - Math.min(...zs))
    const s = M.mods.light.lights.sun, sd = s.position.clone().sub(s.target.position); sd.y = 0; sd.normalize(); const D = ext * 0.7 + 5, y = M.terrainH(cx, cz)
    const ts = C.timeScale; C.timeScale = 0; const R = M.renderer(), orig = R.render, kam = M.camera3().clone(), pos = new T.Vector3(cx + sd.x * D, y + D * 0.5, cz + sd.z * D), ziel = new T.Vector3(cx, y + 0.8, cz)
    R.render = function (sc, ca) { if (!ca.isPerspectiveCamera || R.getRenderTarget()) return orig.call(this, sc, ca); kam.fov = ca.fov; kam.aspect = ca.aspect; kam.near = 0.3; kam.far = ca.far; kam.updateProjectionMatrix(); kam.position.copy(pos); kam.lookAt(ziel); kam.updateMatrixWorld(); return orig.call(this, sc, kam) }
    window.__kfbBelegKopie = { kam, aus() { R.render = orig; window.__kfbBelegKopie = null; C.timeScale = ts } }; window.__kfbBelegCam = { pos: pos.toArray(), rect: [0.25, 0.3, 0.75, 0.8] }
    await new Promise((r) => requestAnimationFrame(() => requestAnimationFrame(r))); return { D: +D.toFixed(1), soldaten: W.map((g) => [g.id, g.clip, +Math.hypot(g.x - q.x, g.z - q.z).toFixed(1)]) } })
  log('KAM4', r4); try { log('FOTO4', await belegFoto(p, `${OUT}/4_erhoeht.png`)) } catch (e) { log('FOTO4', e.message.slice(0, 140)) } await belegFreigeben(p)
  await A.browser.close()
} finally { srv.stop() }
process.exit(0)

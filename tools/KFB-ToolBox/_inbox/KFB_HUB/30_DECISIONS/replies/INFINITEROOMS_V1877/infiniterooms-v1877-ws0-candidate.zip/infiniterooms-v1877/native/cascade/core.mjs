import { closeLaserPanel } from './r4/laser-panel.mjs';
import { LASER_CUT, validLaserPath } from './r4/laser-cut.mjs';
import {weaponImpact,opensBreach,fistOpens,saltOf,wallSize,MAX_IMPACTS} from './r4/impact-mask.mjs';
export const REPAIR_TICKS=150;
// Theme-free, deterministic sole owner. Commands and presentation events are idempotent.
export function route(field, from, to, blocked=new Set(), switches={},walls={}) {
 const next=new Map(field.nodes.map(n=>[n.id,[]]));
 for(const e of field.edges){if(e.wall&&walls[e.wall]!==false)continue;if(e.enabled===false||blocked.has(e.a)||blocked.has(e.b))continue;if(e.switch&&switches[e.switch]===false)continue;next.get(e.a)?.push(e.b);next.get(e.b)?.push(e.a);}
 const q=[from],prev=new Map([[from,null]]);for(let i=0;i<q.length;i++){const id=q[i];if(id===to){const p=[];for(let n=id;n!==null;n=prev.get(n))p.unshift(n);return p;}for(const n of next.get(id)||[])if(!prev.has(n)){prev.set(n,id);q.push(n);}}
 return null;
}
export function createCore(field,{goal=30}={}) {
 if(!field.nodes.length||!route(field,field.source,field.target))throw Error('Unreachable field');
 const initial=()=>({tick:0,mode:'rescue',credits:4,delivered:0,stars:0,done:false,cells:Object.fromEntries(field.nodes.map(n=>[n.id,{goo:n.goo||0,built:!n.broken,guard:false,...(n.vault?{shellHits:0,breached:false,everBreached:false,repaired:false,impacts:[],repairing:false,repairTicks:0}:{} )}])),walls:Object.fromEntries((field.walls||[]).map(w=>[w.id,true])),wallHits:{},switches:{...field.switches},units:[],nextUnit:0,seq:0,events:[],seen:[],collected:0,reroutes:0});
 let state=initial(), seen=new Set(),listeners=new Set();const emit=(type,data={})=>{const e={id:++state.seq,tick:state.tick,type,...data};state.events.push(e);if(state.events.length>200)state.events.shift();for(const f of listeners)f(e);return e;};
 const blocked=()=>new Set(Object.entries(state.cells).filter(([,c])=>c.goo>0||!c.built).map(([id])=>id));
 const path=(from=field.source)=>route(field,from,field.target,blocked(),state.switches,state.walls);
 const preview=id=>{const out=[],q=[id],seen=new Set();while(q.length){const n=q.shift();if(seen.has(n))continue;seen.add(n);out.push(n);for(const c of field.nodes)if((c.support||[]).includes(n))q.push(c.id);}return out;};
 function command(c){if(!c?.id||seen.has(c.id))return false;const cell=state.cells[c.cell];
  if (c.weapon === 'laser' && c.type === 'shellHit' && (!cell?.impacts || cell.repairing || cell.impacts.length >= MAX_IMPACTS || cell.impacts.filter(h => h.weapon === 'laser').length >= LASER_CUT.maxCuts)) return false;
  seen.add(c.id);state.seen.push(c.id);if(state.seen.length>4096)throw Error('command budget');
  if(c.type==='collect'){const i=state.units.findIndex(u=>u.id===c.unit);if(i<0)return false;state.units.splice(i,1);state.credits++;state.collected++;emit('collect',{unit:c.unit});return true;}
  if (c.type === 'shellHit' && c.weapon === 'laser') {
    if (!validLaserPath(c.path)) return false;
    const path = c.path.map(point => point.slice());
    const [x,y] = path.at(-1), wall = c.wall;
    if (![0,1,2,3].includes(wall)) return false;
    const impact = { weapon:'laser', wall, x, y, path, radius:LASER_CUT.radius, order:cell.impacts.length+1 };
    const first = !cell.breached;
    const vault = c.stroke && field.vaults?.find(v => v.id === c.cell);
    if (vault && !vault.kit && typeof c.stroke === 'string' && c.stroke.length <= 48) impact.stroke = c.stroke;
    cell.impacts.push(impact);
    if (impact.stroke) {
      const panel = closeLaserPanel(cell.impacts, impact.stroke, wall, wallSize(vault,wall).w, vault.h);
      if (panel) { impact.panel = panel; cell.everOpenedPanel = true; }
    }
    if (first) { cell.shellHits++; cell.breached = cell.everBreached = true; }
    emit('shell-hit',{cell:c.cell,impact});
    if (first) emit('shell-breach',{cell:c.cell,impact});
    if (impact.panel) emit('shell-panel-drop',{cell:c.cell,impact});
    return true;
  }
  if(c.type==='shellHit'){if(!cell||cell.shellHits===undefined||cell.repairing||(cell.impacts?.length||0)>=MAX_IMPACTS)return false;if(c.point&&(!Array.isArray(c.point)||c.point.length!==2||!c.point.every(Number.isFinite)))return false;const weapon=c.weapon==='rocket'||c.weapon==='ram'?'rocket':'gatling',wall=[0,1,2,3].includes(c.wall)?c.wall:0,impact=weaponImpact(weapon,c.point,(cell.impacts?.length||0)+1,c.direction||[0,0],{wall,salt:saltOf(c.cell)});if(c.weapon==='scrape')Object.assign(impact,{weapon:'scrape',dent:true,energy:Math.min(.7,Math.max(.05,Number.isFinite(c.energy)?c.energy:.25)),length:Math.min(4,Math.max(0,Number.isFinite(c.length)?c.length:0)),strength:.2});if(c.weapon==='ram')Object.assign(impact,{weapon:'ram',energy:Math.min(1.2,Math.max(.4,Number.isFinite(c.energy)?c.energy:.8)),strength:1});if(c.weapon==='fist')Object.assign(impact,{weapon:'fist',dent:true,strength:.6});if(c.weapon==='blaster'){const e=Math.min(1,Math.max(0,Number.isFinite(c.energy)?c.energy:.5));Object.assign(impact,{radius:impact.radius*(1.4+.8*e),strength:.6,blaster:true});};cell.impacts??=[];cell.impacts.push(impact);cell.shellHits+=weapon==='rocket'||c.weapon==='ram'?3:c.weapon==='scrape'?0:1;   /* V-1289 scrape: Wagen schrammt die Wand, nur Schramme, zählt nicht zur Bresche; ram: Anprall mit Tempo bricht die Wand auf wie eine Rakete (Bresche, Kaskade) */const wandTreffer=cell.impacts.filter(h=>(h.wall||0)===wall),oeffnet=impact.weapon==='fist'?fistOpens(wandTreffer,impact):opensBreach(wandTreffer,impact);if(oeffnet&&impact.weapon==='fist')impact.offen=true;emit('shell-hit',{cell:c.cell,impact});if(oeffnet){const first=!cell.breached;cell.breached=true;cell.everBreached=true;emit(first?'shell-breach':'shell-enlarge',{cell:c.cell,impact});}return true;}
  if(c.type==='fluffClean'){if(!cell||!cell.breached||cell.goo<=0||state.credits<1)return false;state.credits--;cell.goo=0;emit('clean',{cell:c.cell});emit('route-changed');return true;}
  if(c.type==='repairShell'){if(!cell||!cell.breached||cell.repairing||cell.goo>0||state.credits<2)return false;state.credits-=2;cell.repairing=true;cell.repairTicks=0;emit('repair-start',{cell:c.cell});return true;}
  if(c.type==='mode'){if(!['rescue','build'].includes(c.mode))return false;state.mode=c.mode;emit('mode',{mode:c.mode});return true;}
  if(c.type==='hitWall'){const w=field.walls?.find(w=>w.id===c.wall&&w.kind==='inner');if(!w||state.walls[w.id]===false)return false;state.wallHits[w.id]=(state.wallHits[w.id]||0)+1;if(state.wallHits[w.id]>=3){state.walls[w.id]=false;emit('wall-open',{wall:w.id});emit('route-changed');}return true;}
  if(!cell)return false;
  if(c.type==='hit'){if(cell.goo<=0)return false;cell.goo=Math.max(0,cell.goo-(c.power||1));emit('hit',{cell:c.cell});if(cell.goo===0){state.credits++;emit('clean',{cell:c.cell});if(field.nodes.find(n=>n.id===c.cell)?.breakOnClean){cell.built=false;emit('collapse',{cell:c.cell});}emit('route-changed');}return true;}
  if(c.type==='build'){if(cell.built||state.credits<2)return false;state.credits-=2;cell.built=true;emit('build',{cell:c.cell});emit('route-changed');return true;}
  if(c.type==='guard'){if(!cell.built||cell.goo||cell.guard||state.credits<3)return false;state.credits-=3;cell.guard=true;emit('guard',{cell:c.cell});return true;}
  if(c.type==='switch'){state.switches[c.cell]=state.switches[c.cell]===false;state.reroutes++;emit('switch',{cell:c.cell,on:state.switches[c.cell]});emit('route-changed');return true;}
  if(c.type==='destroy'){for(const id of preview(c.cell)){if(state.cells[id].built){state.cells[id].built=false;state.cells[id].guard=false;emit('collapse',{cell:id});}}emit('route-changed');return true;}
  return false;
 }
 function step(){if(state.done&&state.mode!=='build')return;state.tick++;
  for(const [id,c] of Object.entries(state.cells))if(c.repairing){c.repairTicks++;if(c.repairTicks>=REPAIR_TICKS){c.repairing=false;c.breached=false;c.shellHits=0;c.impacts=[];c.repaired=true;emit('build',{cell:id});}}
  if(!field.golden&&state.mode==='rescue'&&state.tick%1200===0){const candidates=field.nodes.filter(n=>n.id!==field.source&&n.id!==field.target&&n.infectable!==false&&state.cells[n.id].built&&!state.cells[n.id].guard);if(candidates.length){const n=candidates[(state.tick/1200-1)%candidates.length];state.cells[n.id].goo=Math.min(3,state.cells[n.id].goo+1);emit('infect',{cell:n.id});}}
  if(state.tick%90===0)for(const [id,c]of Object.entries(state.cells))if(c.guard){const neighbors=field.edges.filter(e=>e.a===id||e.b===id).map(e=>e.a===id?e.b:e.a);const target=neighbors.find(n=>state.cells[n].goo>0);if(target)command({id:'guard:'+state.tick+':'+id,type:'hit',cell:target});}
  if(state.tick%240===0&&state.units.length<30){state.units.push({id:++state.nextUnit,node:field.source,progress:0});emit('spawn',{unit:state.nextUnit});}
  if(!field.gather)for(const u of [...state.units]){u.progress++;if(u.progress<60)continue;u.progress=0;const p=path(u.node);if(!p){emit('wait',{unit:u.id,cell:u.node});continue;}if(p.length===1){state.units.splice(state.units.indexOf(u),1);state.delivered++;state.credits++;emit('arrive',{unit:u.id,cell:field.target});}else{const from=u.node;u.node=p[1];emit('flow',{unit:u.id,from,cell:u.node});}}
  if((field.golden?(state.collected>0&&Object.values(state.cells).some(c=>c.repaired)):state.delivered>=goal)&&!state.done){state.done=true;const left=Object.values(state.cells).filter(c=>c.goo>0).length;state.stars=1+(left===0?1:0)+(state.tick<=14400?1:0);emit('complete',{stars:state.stars});}
 }
 return {command,step,preview,path,subscribe(fn){listeners.add(fn);return()=>listeners.delete(fn);},snapshot:()=>structuredClone(state),reset(){state=initial();seen=new Set();emit('reset');},restore(s){if(!s||Object.keys(s.cells).join('|')!==Object.keys(state.cells).join('|'))throw Error('incompatible save');state=structuredClone(s);seen=new Set(state.seen);emit('restored');},get state(){return state;}};
}

// V-1289 · Zielhaken für den Kampf (Go WS0 03.11.): weitere Ziele neben dem Obstgarten über options.targets() in combatPlayer.r2, ein Zielsystem.
// Der Obstgarten (Bäume, addTarget-Ziele, 2D-Gegner) bleibt unverändert; seine Treffer und die der Quellen hier werden nach dem Anteil u auf der Strecke verglichen.
// Funken, Rauch, Splitter und Explosion zeichnet weiter nur combatPlayer.r2; eine Quelle bekommt nur die Meldung und baut ihre eigene Folge (Loch, Bruch).
// Quelle = { name, boxes?() → [{ id, min:[x,y,z], max:[x,y,z], material? }], sweep?(a, b, rad) → { id, u, at, normal?, material? } | null, hit(info), blast?(info) }
//   hit(info)   info = { kind: 'shot' | 'blast', id, at:[x,y,z], normal:[x,y,z], dir:[x,y,z], energy 0…1, weapon, radius?, shot? }
//   blast(info) ohne boxes: die Quelle prüft selbst, was im Radius liegt (info = { at, radius, energy, weapon, dir }); mit boxes ruft der Haken hit je Kasten
// Reine Logik, ohne three.js.
// Anmeldung im Spiel: addCombatTarget(quelle) → Abmeldung; M1World gibt die Liste als options.targets() an den Kampf (Kartenviertel, später weitere)
export const COMBAT_TARGETS = new Set()
export function addCombatTarget(src) { if (!src || typeof src.name !== 'string' || !(src.boxes || src.sweep || src.blast)) throw new Error('COMBAT_TARGET_INVALID'); COMBAT_TARGETS.add(src); return () => COMBAT_TARGETS.delete(src) }
export const combatTargets = () => [...COMBAT_TARGETS]
const sub = (a, b) => [a[0] - b[0], a[1] - b[1], a[2] - b[2]], len = (v) => Math.hypot(v[0], v[1], v[2])
const unit = (v, f = [0, 1, 0]) => { const l = len(v); return l > 1e-9 ? [v[0] / l, v[1] / l, v[2] / l] : f.slice() }

// Strecke a→b gegen einen achsparallelen Kasten (um rad vergrößert): erster Eintritt mit Anteil u und Flächennormale, sonst null
export function segBox(a, b, box, rad = 0) {
  let t0 = 0, t1 = 1, axis = -1, sign = 0
  for (let i = 0; i < 3; i++) { const d = b[i] - a[i], lo = box.min[i] - rad, hi = box.max[i] + rad
    if (Math.abs(d) < 1e-12) { if (a[i] < lo || a[i] > hi) return null; continue }
    let ta = (lo - a[i]) / d, tb = (hi - a[i]) / d, s = -1; if (ta > tb) { const t = ta; ta = tb; tb = t; s = 1 }
    if (ta > t0) { t0 = ta; axis = i; sign = s } t1 = Math.min(t1, tb); if (t0 > t1) return null }
  if (axis < 0) return null // Start im Kasten: kein Eintritt, kein Treffer
  const normal = [0, 0, 0]; normal[axis] = sign
  return { u: t0, at: [a[0] + (b[0] - a[0]) * t0, a[1] + (b[1] - a[1]) * t0, a[2] + (b[2] - a[2]) * t0], normal }
}
// nächster Punkt eines Kastens zu p
export const boxClosest = (p, box) => [0, 1, 2].map((i) => Math.min(box.max[i], Math.max(box.min[i], p[i])))

// erster Treffer aller Quellen auf a→b: { kind: 'ext', src, id, u, at, normal?, material? } | null
export function sweepTargets(sources, a, b, rad = 0, options) {
  let best = null
  for (const src of sources || []) {
    if (src.sweep) { const h = src.sweep(a, b, rad, options); if (h && (!best || h.u < best.u)) best = { ...h, kind: 'ext', src } }
    for (const bx of src.boxes?.() || []) { const h = segBox(a, b, bx, rad); if (h && (!best || h.u < best.u)) best = { kind: 'ext', src, id: bx.id, u: h.u, at: h.at, normal: h.normal, material: bx.material, ziel: Math.min(bx.max[0] - bx.min[0], bx.max[2] - bx.min[2]) / 2 } } }
  return best
}
// Treffer an die Quelle melden; fehlt die Normale, zeigt sie gegen die Schussrichtung
// Treffer-Kontext (Lieferung 4, Nachglühen in der Waffenfarbe): Welche Waffe gerade ein Ziel meldet. Zielbesitzer, deren eigene Ereignisse die Waffe nicht tragen (Kartenviertel: rocket bzw. gatling), lesen ihn im selben Aufruf.
let kontext = null, farbeVon = null, letzter = null
export const trefferKontext = () => kontext
// Für Empfänger, die erst über den Spiel-Bus hören (der liefert beim nächsten Tick aus): der jüngste Kontext, wenn er höchstens maxMs alt ist
export const letzterTrefferKontext = (maxMs = 400) => kontext || (letzter && performance.now() - letzter.zeit <= maxMs ? letzter : null)
export function setzeWaffenFarbe(fn) { farbeVon = typeof fn === 'function' ? fn : null }
const mitKontext = (weapon, fn) => { const alt = kontext; kontext = { waffe: weapon, farbe: farbeVon?.(weapon) ?? null }; letzter = { ...kontext, zeit: performance.now() }; try { return fn() } finally { kontext = alt } }
export function deliverHit(h, { dir, energy = 0.7, weapon = 'pistol', shot = null, damage = null, pellets = null, cutPath = null, cutStroke = null } = {}) {   // damage (#52) und pellets[] (#62: Einzelkontakte, eine gebündelte Zielreaktion)
  const d = unit(dir || [0, 0, 1]), info = { kind: 'shot', id: h.id, at: h.at.slice(), normal: h.normal ? unit(h.normal) : [-d[0], -d[1], -d[2]], dir: d, energy, weapon, shot }
  if (damage != null) info.damage = damage
  if (pellets) info.pellets = pellets
  if (cutPath) info.cutPath = cutPath
  if (cutStroke) info.cutStroke = cutStroke
  mitKontext(weapon, () => h.src.hit?.(info)); return info
}
// Explosion mit Radius: je Kasten im Radius ein Treffer, Energie fällt linear zum Rand, Normale vom Zentrum weg zum nächsten Punkt. Rückgabe = gemeldete Treffer
export function blastTargets(sources, at, radius, { energy = 1, weapon = 'bomb', damage = null } = {}) {
  const out = []; if (!(radius > 0)) return out
  for (const src of sources || []) {
    if (!src.boxes) { if (src.blast) { const info = { kind: 'blast', at: at.slice(), radius, energy, weapon, dir: [0, 1, 0] }; if (damage != null) info.damage = damage; mitKontext(weapon, () => src.blast(info)); out.push({ src: src.name, info }) } continue }
    for (const bx of src.boxes()) { const q = boxClosest(at, bx), v = sub(q, at), d = len(v); if (d > radius) continue
      const info = { kind: 'blast', id: bx.id, at: q, normal: unit(v), dir: unit(v), energy: energy * (1 - d / radius), weapon, radius }; if (damage != null) info.damage = damage * (1 - d / radius); mitKontext(weapon, () => src.hit?.(info)); out.push({ src: src.name, info }) } }
  return out
}

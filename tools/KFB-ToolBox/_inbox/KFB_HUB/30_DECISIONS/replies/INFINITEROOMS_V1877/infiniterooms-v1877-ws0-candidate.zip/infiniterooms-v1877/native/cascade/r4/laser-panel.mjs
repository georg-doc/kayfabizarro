// A continuous, bounded stroke on one wall produces one simple polygon.
export const PANEL_SNAP = .24
const MIN_EDGE = .04, MAX_VERTICES = 60
const distance = (a, b) => Math.hypot(a[0] - b[0], a[1] - b[1])
const cross = (a, b, p) => (b[0] - a[0]) * (p[1] - a[1]) - (b[1] - a[1]) * (p[0] - a[0])
export function polygonBounds(points) {
  const x = points.map(p => p[0]), y = points.map(p => p[1])
  return { left: Math.min(...x), right: Math.max(...x), low: Math.min(...y), high: Math.max(...y) }
}

function intersects(a, b, c, d) {
  if (Math.max(a[0], b[0]) < Math.min(c[0], d[0]) || Math.max(c[0], d[0]) < Math.min(a[0], b[0])
    || Math.max(a[1], b[1]) < Math.min(c[1], d[1]) || Math.max(c[1], d[1]) < Math.min(a[1], b[1])) return false
  return cross(a, b, c) * cross(a, b, d) <= 0 && cross(c, d, a) * cross(c, d, b) <= 0
}

function segmentDistance(p,a,b) {
  const dx=b[0]-a[0], dy=b[1]-a[1]
  const t=Math.max(0,Math.min(1,((p[0]-a[0])*dx+(p[1]-a[1])*dy)/(dx*dx+dy*dy||1)))
  return distance(p,[a[0]+t*dx,a[1]+t*dy])
}

function simplify(points) {
  let index=0, far=.088
  for(let i=1;i<points.length-1;i++){
    const d=segmentDistance(points[i],points[0],points.at(-1))
    if(d>far){far=d;index=i}
  }
  return index
    ? simplify(points.slice(0,index+1)).slice(0,-1).concat(simplify(points.slice(index)))
    : [points[0],points.at(-1)]
}

export function closeLaserPanel(impacts, stroke, wall, width, height) {
  if (impacts.some(h => h.wall === wall && h.panel)) return null
  const points = []
  for (const impact of impacts) {
    if (impact.stroke !== stroke || impact.wall !== wall) continue
    if (points.length && distance(points.at(-1), impact.path[0]) > .36) points.length = 0
    for (const p of impact.path) if (!points.length || distance(points.at(-1), p) >= MIN_EDGE) points.push(p)
  }
  if (points.length < 4 || distance(points[0], points.at(-1)) > PANEL_SNAP) return null
  const loop = simplify([...points,points[0]]).slice(0,-1)
  if (loop.length < 3 || loop.length > MAX_VERTICES) return null
  const box = polygonBounds(loop)
  if (box.left < -width / 2 + .23 || box.right > width / 2 - .23 || box.low < .035 || box.high > height - .23
    || box.right - box.left > 4.2 || box.high - box.low > 3.6) return null

  let area = 0
  for (let i = 0; i < loop.length; i++) {
    const a = loop[i], b = loop[(i + 1) % loop.length]
    area += cross([0, 0], a, b)
    for (let j = i + 2; j < loop.length; j++) {
      if (i === 0 && j === loop.length - 1) continue
      if (intersects(a, b, loop[j], loop[(j + 1) % loop.length])) return null
    }
  }
  if (Math.abs(area) < .38) return null
  const polygon = loop.map(p => p.slice())
  // A single low, roughly horizontal edge can release the remaining thin sill.
  // The same floor notch then drives the mask, panel and player collision.
  for (let i=0;i<polygon.length;i++) {
    const a=polygon[i], b=polygon[(i+1)%polygon.length], y=Math.max(a[1],b[1]);
    if(y<=.45&&Math.abs(a[1]-b[1])<=.16&&Math.abs(a[0]-b[0])>=.55
      && polygon.every(p=>p===a||p===b||p[1]>y+.06)){
      a[1]=b[1]=0;
      break;
    }
  }
  return polygon
}

// A beam can see through its own kerf. Keep tracking the original face while the
// same continuous stroke is active, until that face has a detached panel.
export function tracksLaserStroke(impacts, stroke, wall, point) {
  if (!stroke || impacts.some(h => h.wall === wall && h.stroke === stroke && h.panel)) return false
  for (const h of impacts) {
    if (h.wall !== wall || h.stroke !== stroke) continue
    for (let i = 0; i < h.path.length; i++) {
      const a = h.path[Math.max(0,i-1)], b = h.path[i]
      if (segmentDistance(point,a,b) <= .108) return true
    }
  }
  return false
}

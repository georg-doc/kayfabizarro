# RETURN · WSA Patch → WS0 · V-1877

**Lokaler Vertragskandidat, noch kein Game-PASS.** Neuester abgefragter Stamm bei Beginn: game/integration-r2 @ f66f65374b1ec5be94bec60568ec927cde4a8010. Vor Einbau erneut gegen den dann neuesten Stand vergleichen. Kein Stamm-Eingriff, kein Merge, keine veröffentlichte Änderung.

Lieferung: eine native Combat-Quelle, elf JSON-Waffenprofile, ein Kaskaden-Rezeptentwurf und ein Prototyp zur räumlichen Nutzung des vorhandenen planaren Viertel-Bruchfelds für die sechs Innenflächen. 20/20 Vertragstests, Rohbeleg evidence/unit-tests.txt. Kein eigener Strahl, Schadensbesitzer, Input, Takt, Renderer, Physik- oder Audiobesitzer. Kein AVBD/WebGPU.

## Offene Spielanschlüsse vor Georgs PASS

1. Den echten Collider-/Sweep-Besitzer des Kartenraums an die eine registrierte Quelle hängen. `hit`/`blast` verarbeiten ausschließlich bestätigte Host-Meldungen. Die neue Vertragsquelle ist noch nicht mit dem bisherigen Site-`createDestructibleRoom` verdrahtet; dessen eigene Prüfstrahlen dürfen nicht in den Game-Adapter gelangen.
2. `commitFracture` durch den vorhandenen Viertel-Geometrie-, Kollisions- und Fragmentbesitzer ausführen. Dies ist derzeit eine erforderliche Host-Funktion, kein fertiger Game-Export. Lochmaske/Bruchschollen müssen dieselbe Quelle für Darstellung und Kollisionsöffnung bleiben. Eingang/Baseline und sichere Rückwege erhalten.
3. Kaskadenrezept in den vorhandenen Choreografie-Besitzer aufnehmen, einmalige Eltern-ID und Waffenfarbe übernehmen. Die Markenzeiten beschreiben die Geometrieantwort und dürfen dieselbe Wirkung nicht nochmals auslösen. Funken/Rauch/Splitter/Explosion/Ton allein über combatPlayer und dessen bestehende Besitzer. Waffenfarbe bei späteren Busmeldungen aus dem gespeicherten Kontext lesen; fehlt sie, bleibt der Sichtnachweis offen.
4. Native Rückkehr-/Resetfreiheit für Spieler und später Fahrzeuge liefern. Keine Rekonstruktion über einer Figur. Definieren, wann wartende Kaskaden bei Reset/Entladen beendet werden. Der Registrierungsadapter meldet sich ab; er besitzt die fremden Kaskaden nicht.
5. HeroMan-Blaster mit originalem Modell, festen Ankern und bestehendem combatPlayer zeigen: Seite, Dreiviertel, Totale, Kontakt; dazu FPS/TPS. Nahe Wand blockiert den echten Welt-Schuss, Darstellung/Mündung/Ziel passen; FX/Ton/Treffer einmal. Die Ego-Waffendarstellung selbst ist hier nicht gebaut und kein neues Modell wurde hergestellt.
6. Kalter Start und gleiche Vordergrund-Bildzeiten im echten Game messen. Besonders die mehrflächige Explosion kann im vorhandenen synchronen Graph-/Feldweg aufwendig sein. Erst danach Gatling-Dauerlast und Nahkontakt; Materialhärte/ungestützte Bereiche nur als Erweiterung des vorhandenen Bruchbesitzers.

## Noch keine Freigabe

Keine neuen Filme, Screenshots, FPS-/TPS-Nachweise oder Spiel-Performancewerte. Die Live-Site bleibt unverändert bei ihrem bereits gelieferten Raum-Prüfstand. Die dortigen 277 Tests sind kein Beleg für diese noch offene Game-Verbindung. Registrierung, Feldprojektion und Rezept sind technisch geprüft; vollständige Game-, Kollisions-, Fragment-, Look- und Video-Abnahme steht aus.

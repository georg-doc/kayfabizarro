# InfiniteRooms · V-1877 · privater Anschlusskandidat

Stand 17.11.2026 (Europe/Berlin). Gegen den neuesten bei Arbeitsbeginn per GitHub aufgelösten `game/integration-r2`-Commit `f66f65374b1ec5be94bec60568ec927cde4a8010` geprüft. **Kein Einbau in den Stamm, kein Merge, kein Deployment, keine FPS-/Look-Freigabe.** Die bereits veröffentlichte `/room-lab/`-Site bleibt ihr eigener älterer Prüfaufbau und verwendet diesen Adapter noch nicht.

## Was ausführbar ist

- `combat-source.mjs`: genau eine `addCombatTarget({name:'infiniterooms', sweep, hit, blast})`-Quelle. Sweep wird an den vorhandenen Kollider-/Trefferbesitzer weitergereicht; bestätigte Meldungen gelangen ohne erneute Strahlenprüfung nach `level.impact(info, profile)`. Kein `boxes`-Eintrag: der unveränderte `blastTargets` ruft so die Raumquelle einmal statt einmal je Voxel-Kasten auf.
- `fracture-surfaces.mjs`: sechs räumliche Orientierungen desselben **unveränderten** Kartenviertel-Kerns (`cascade/core.mjs`) und seiner `impact-mask.mjs`/`fracture.mjs`-Felder. Kein neuer Rissalgorithmus, keine Kugel-/Bohrer-Carve-Logik, kein AVBD und keine neue Physikwelt. Die mitgelieferten Originaldateien unter `native/` dienen der reproduzierbaren Vertragsprüfung. Ihre Herkunft und Prüfsummen stehen in SOURCE_LOCK.json.
- Elf JSON-Profile: `blaster`, `gatling`, `grenade`, `bomb`, `rocket`, `clownbomb`, `boxing`, `faust`, `bow`, `ram`, `scrape`. Öffentlicher Waffenname bleibt unverändert. `nativeCommandWeapon` verwendet nur die vorhandenen internen Viertel-Zuordnungen (`rocket`/`gatling`/`fist` usw.); dies benennt keine Spielwaffe um. Der Radius entscheidet bei Explosionen, welche Flächen im Bereich reagieren; schwache Randkontakte verwenden die vorhandene Viertel-Schwelle. Schussrate, Schaden, Munition, Projektilflug und Balance bleiben beim Kampfbesitzer.
- Waffenfarbe wird synchron aus `trefferKontext()` eingefangen, bevor eine Kaskade später verarbeitet wird. Es gibt keine neu erfundene Farbtabelle. Fehlt ein Farbkontext, ist die Farbe `null`: dies darf im visuellen Blaster-Nachweis nicht als bestanden gelten; WS0 muss die bestehende Waffenpalette liefern.
- `data/choreo/infiniterooms.impact.v1.json`: Rezeptkandidat im bestehenden `core/rezept.js`-Format. Der unveränderte Runner spielt Kontakt → Bruch → Trümmer → Staub/Ton in der Vertragsprüfung einmal durch. Das Rezept wird noch **nicht** im Game registriert. Die Geometrie reagiert unmittelbar; die Rezeptmarken sind keine zweite Schadens- oder Geometrieausführung.

## Besitzer und Anschluss

`createInfiniteRoomsCombatSource` benötigt die echten Host-Funktionen `addCombatTarget`, `sweepWorld`, `readWeaponContext` und `onCascade`; dazu den Level mit `impact`/`reset`, die geladenen Profildaten und das Rezept. `readWeaponContext` kann die vorhandene Funktion `trefferKontext` sein. `sweepWorld` und `onCascade` sind absichtlich injizierte Host-Anschlüsse, **keine Behauptung neuer bereits vorhandener Game-APIs**.

`createFractureRoomResponse` benötigt den bestehenden Level-Koordinatenrahmen (`toLocal`, `localDirection`), `commitFracture` und `canReset`. `commitFracture({surface,field,impacts,receipt})` ist der vorzubereitende Übergang zum vorhandenen Geometrie-/Kollisions-/Fragmentbesitzer. Er bekommt das originale Bruchfeld, dessen Schollen und Lochmaske und muss daraus dieselbe Darstellung und Kollision ableiten. Der Kandidat erzeugt selbst weder Netze noch Kollider, Trümmerkörper, Funken, Rauch oder Ton. `canReset` muss die reale Spieler-/Fahrzeugfreiheit prüfen; der Kandidat ersetzt diesen Schutz nicht.

`aufprallSchaden.js` ist im geprüften Stamm die Weiterleitung für Fahrzeugkontakte. Der eigentliche gemeinsame Bruchkern liegt in `cascade/core.mjs` und `cascade/r4/impact-mask.mjs`/`fracture.mjs`; diese werden hier direkt wiederverwendet.

## Reproduktion

`npm test` benötigt keine Installation und führt 20 Node-Vertragstests mit den eingefrorenen nativen Besitzern aus. Die Node-Hilfe `profiles.mjs` lädt ausschließlich die JSON-Daten für diese Prüfung; der Game-Host lädt sie mit seinem vorhandenen Build-System.

Die Tests prüfen: native Zielwahl einschließlich eines abschirmenden Gegners; keine erneute Abfrage bei hit/blast; alle sechs Bruchflächen; ein Explosions-Elternereignis bei sechs betroffenen Flächen; zwei legitime Bomben am selben Ort; explizite Schuss-ID-Entdoppelung; Reset und gesperrten Reset; synchron gespeicherte Waffenfarbe; vorhandenes Zwei-Kontakt-Faustverhalten; unverändert gebündelte Pellets; alle elf erlaubten Waffen; Ablehnung unbekannter Namen/ungültiger Meldungen; drei An-/Abmeldungen; und das Rezept mit dem unveränderten Game-Runner.

Das sind **keine** neuen Rapier-/Raster-/FPS-/TPS-/Blaster- oder Filmbelege. Die 277 bestandenen Site-Tests gehören zum separat veröffentlichten Voxel-Raum, nicht zu einer bereits abgeschlossenen Integration dieses Graph-Adapters.

## Bewusste Grenzen

Die Graph-Erweiterung adressiert zunächst die sechs **inneren** ebenen Raumflächen im lokalen 6,5-m-Prüfraum. Eingangsöffnung/Vorbereich sind Baseline-Geometrie des Raum-Besitzers und müssen beim Ableiten der Kollisionsmaske erhalten bleiben. Neue Öffnungen dürfen keine unabhängige Loch-Wahrheit neben dem Bruchfeld erzeugen. Außenflächen, beliebig gebogene Wände, Übergänge und tragende Verbindungen zwischen verschiedenen Ebenen benötigen weitere Anpassung genau im vorhandenen Viertel-Besitzer.

Die sechs Flächen nutzen dieselbe planare Bruchlogik; das ist noch kein dreidimensionaler Tragwerksgraph. Das Ablösen ungestützter Geschosse/Decken und Materialhärte sind noch nicht ergänzt. Große Schollen und physische Trümmer müssen vom bestehenden Fragmentbesitzer übernommen werden; dieser Commit-/Kollideranschluss ist offen. Vollständige Explosionen können mehrere native Felder synchron bearbeiten; ihre Bildzeit und das vorhandene Host-Budget sind vor Game-Aktivierung zu prüfen. Node-Testlaufzeiten sind keine Bildzeiten.

Hammer, Bohrer, Fernzünder und 8-Ball sind ausdrücklich keine neuen Game-Profile und es wurden keine Modelle/Clips gebaut. Die bisherigen Site-Prüfknöpfe sind keine freigegebene Game-Tastenbelegung. Die native `hostKeys`-Map bleibt unverändert.

// A short wall-local polyline, shared by the building command and wall mask.
export const LASER_CUT = Object.freeze({ radius: .075, soot: .13, maxPoints: 8, maxStep: 1.2, maxCuts: 32 })

export function validLaserPath(points) {
  if (!Array.isArray(points) || points.length < 1 || points.length > LASER_CUT.maxPoints) return false
  return points.every((p, i) => Array.isArray(p) && p.length === 2 && p.every(Number.isFinite)
    && (!i || Math.hypot(p[0] - points[i - 1][0], p[1] - points[i - 1][1]) <= LASER_CUT.maxStep))
}

export function rasterLaserCut(f, points) {
  const { radius, soot } = LASER_CUT
  const dx = f.sx / f.cols, dy = f.sy / f.rows
  for (let n = 0; n < points.length; n++) {
    const [ax, ay] = points[Math.max(0, n - 1)], [bx, by] = points[n]
    const vx = bx - ax, vy = by - ay, length2 = vx * vx + vy * vy || 1
    const i0 = Math.max(0, Math.floor((Math.min(ax, bx) - soot - f.x0) / dx))
    const i1 = Math.min(f.cols - 1, Math.ceil((Math.max(ax, bx) + soot - f.x0) / dx))
    const j0 = Math.max(0, Math.floor((Math.min(ay, by) - soot) / dy))
    const j1 = Math.min(f.rows - 1, Math.ceil((Math.max(ay, by) + soot) / dy))
    for (let j = j0; j <= j1; j++) {
      const y = (j + .5) * dy
      for (let i = i0; i <= i1; i++) {
        const x = f.x0 + (i + .5) * dx
        const t = Math.max(0, Math.min(1, ((x - ax) * vx + (y - ay) * vy) / length2))
        const distance = Math.hypot(x - ax - t * vx, y - ay - t * vy)
        if (distance > soot) continue
        const k = j * f.cols + i, o = k * 4, signed = radius - distance
        f.d[k] = f.data[o] = Math.max(f.d[k], signed)
        f.soot[k] = f.data[o + 2] = Math.max(f.soot[k], Math.min(1, (soot - distance) / (soot - radius)))
        f.maxD = Math.max(f.maxD, signed)
      }
      const row = f.dirtyRows.get(j)
      f.dirtyRows.set(j, row ? [Math.min(row[0], i0), Math.max(row[1], i1)] : [i0, i1])
    }
  }
}

// Fill the interior on the same field as the kerf. The negative tear marker
// also clips the decorative card behind the shell, only at the new opening.
export function rasterLaserPanel(f, polygon) {
  const dx = f.sx / f.cols, dy = f.sy / f.rows
  const us = polygon.map(p => p[0]), ys = polygon.map(p => p[1])
  const i0 = Math.max(0, Math.floor((Math.min(...us) - f.x0) / dx))
  const i1 = Math.min(f.cols - 1, Math.ceil((Math.max(...us) - f.x0) / dx))
  const j0 = Math.max(0, Math.floor(Math.min(...ys) / dy))
  const j1 = Math.min(f.rows - 1, Math.ceil(Math.max(...ys) / dy))
  for (let j = j0; j <= j1; j++) {
    const y = (j + .5) * dy
    for (let i = i0; i <= i1; i++) {
      const x = f.x0 + (i + .5) * dx
      let inside = false, distance = Infinity
      for (let n = 0; n < polygon.length; n++) {
        const [ax, ay] = polygon[n], [bx, by] = polygon[(n + 1) % polygon.length]
        const vx = bx - ax, vy = by - ay
        if ((ay > y) !== (by > y) && x < ax + vx * (y - ay) / vy) inside = !inside
        const t = Math.max(0, Math.min(1, ((x - ax) * vx + (y - ay) * vy) / (vx * vx + vy * vy)))
        distance = Math.min(distance, Math.hypot(x - ax - vx * t, y - ay - vy * t))
      }
      if (!inside) continue
      const k = j * f.cols + i, o = k * 4
      f.d[k] = f.data[o] = Math.max(f.d[k], Math.min(.4, distance))
      f.tear[k] = f.data[o + 3] = -1
      f.maxD = Math.max(f.maxD, f.d[k])
    }
    const row = f.dirtyRows.get(j)
    f.dirtyRows.set(j, row ? [Math.min(row[0], i0), Math.max(row[1], i1)] : [i0, i1])
  }
}

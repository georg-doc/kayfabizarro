# G4 R3 · bounded failure evidence (2026-10-11)

This is a factual negative example, not a construction pattern or style Golden.

Repo georg-doc/kayfabizarro; branch wsa/kfb-g4-stairs-form-design-r3-2026-10-11; immutable evidence head e6f2aa1e1f0efb130975b1af498fcdba635f3ad0. Existing plugin identity plugins_6acaa1b6b0688191b66448db92767870 is preserved.

[Failure Recovery](https://github.com/georg-doc/kayfabizarro/blob/e6f2aa1e1f0efb130975b1af498fcdba635f3ad0/tools/KFB-ToolBox/_inbox/MVP1_RETURNS/WSA_modelling_test/FORM_R3/FAILURE_RECOVERY_R3.md) · [independent Tester](https://github.com/georg-doc/kayfabizarro/blob/e6f2aa1e1f0efb130975b1af498fcdba635f3ad0/tools/KFB-ToolBox/_inbox/MVP1_RETURNS/WSA_modelling_test/FORM_R3/tests/TEST_REPORT_R3_INDEPENDENT.md) · [independent Critic](https://github.com/georg-doc/kayfabizarro/blob/e6f2aa1e1f0efb130975b1af498fcdba635f3ad0/tools/KFB-ToolBox/_inbox/MVP1_RETURNS/WSA_modelling_test/FORM_R3/critic/final/REPORT_FINAL_R3.md) · [Guard](https://github.com/georg-doc/kayfabizarro/blob/e6f2aa1e1f0efb130975b1af498fcdba635f3ad0/tools/KFB-ToolBox/_inbox/MVP1_RETURNS/WSA_modelling_test/FORM_R3/guard/GUARD_FINAL_R3.md).

Verified: actual source isolation; eight treads/3H sampled width,45meshes in5roles,13036triangles/max380; exact neutral/styled geometry parity. Neutral G0 subset PASS8.0; full independent seven scores8/8/9/8/6/7/8 => mean7.7143 FORM_FAIL. Actual terrain exit drops0.26941–0.55830 vs0.0728limit; foot embedding incomplete despite96/96 affine donor-position identity. Independent visible review found hard planar-bank seams and regular bevel bands (styleScore7).

Observed failure/routing rules: source proof != contact proof; partial neutral preflight PASS != full construction PASS; independent mean threshold must be enforced; do not hide failed attachment with styling or teach affine donor placement as success. Preserve only the failing context seam, keep the independently proven isolated architecture and human design gate separate.

[Real neutral candidate](https://github.com/georg-doc/kayfabizarro/blob/e6f2aa1e1f0efb130975b1af498fcdba635f3ad0/tools/KFB-ToolBox/_inbox/MVP1_RETURNS/WSA_modelling_test/FORM_R3/renders/form_gray/three_quarter.jpg) · [source isolation](https://github.com/georg-doc/kayfabizarro/blob/e6f2aa1e1f0efb130975b1af498fcdba635f3ad0/tools/KFB-ToolBox/_inbox/MVP1_RETURNS/WSA_modelling_test/FORM_R3/renders/source/source_isolated_contact_sheet.jpg) · [styled probe](https://github.com/georg-doc/kayfabizarro/blob/e6f2aa1e1f0efb130975b1af498fcdba635f3ad0/tools/KFB-ToolBox/_inbox/MVP1_RETURNS/WSA_modelling_test/FORM_R3/renders/kfb_clay/three_quarter.jpg) · [failed actual context](https://github.com/georg-doc/kayfabizarro/blob/e6f2aa1e1f0efb130975b1af498fcdba635f3ad0/tools/KFB-ToolBox/_inbox/MVP1_RETURNS/WSA_modelling_test/FORM_R3/renders/kfb_clay/hill_connection.jpg).

The architectural pillars themselves scored9 and are not evidence for blob_pillar_not_column. K2/Golden parity, runtime swept locomotion and human Golden were not demonstrated. Do not generalize this failure into a ban on KayKit, Kenney, individual masonry meshes, or architectural pillars.


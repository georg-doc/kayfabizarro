# Source-led job and output contracts · v0.1

`kfb.asset-scene-image-job/1` is a **plugin job/input**, NOT a Registry rewrite or WorldBuilder implementation recipe. Draft from existing assets and preserve owner state.

```json
{
  "schema": "kfb.asset-scene-image-job/1",
  "jobId": "stable id or generated UUID",
  "mode": "asset_plate | scene_context | material_study | mood_explore",
  "source": {
    "repo": "georg-doc/kayfabizarro",
    "assetIds": ["the exact Asset Librarian assetId(s)"],
    "sourcePaths": ["the exact source path(s)"],
    "blobShas": ["verified SHA or null"],
    "sourceRenderViews": [{"view": "34", "path": "verified image path", "sha256": null, "pixelsAvailableToGenerator": false}],
    "licenseStatus": "VERIFIED|UNKNOWN|RESTRICTED",
    "nativeBbox": null,
    "K2KitFactor": null,
    "geometryLock": "strict|loose|none"
  },
  "context": {
    "scenePurpose": "why/how the objects relate",
    "selectedScenePacket": null,
    "environmentAssetIds": [], "characterAssetIds": [], "propAssetIds": [],
    "camera": "3/4 studio|gameplay|...", "viewLabelsAllowed": true
  },
  "style": {
    "bindingSSOT": ["skills/chat/KFB_OPEN_WORLD_CLAY_SURFACE_CANON_2026-10-07.md"],
    "benchmarkRefs": [], "paletteRoles": [], "materialMixAllowed": true,
    "partsBudgetMax": 6
  },
  "generation": {
    "sourcePixelsActuallySupplied": false,
    "provider": null,
    "providerRequestId": null,
    "renderPrompt": null,
    "status": "DRAFT|BLOCKED_SOURCE|READY|RUNNING|COMPLETE|FAILED"
  },
  "approval": {"classification": "UNREVIEWED", "georgPicked": false, "goldenRef": false}
}
```

Output: `kfb.asset-scene-image-result/1` with `jobId`, `sourceJobHash`, provider/host run receipt, exact output files `{path,sha256,bytes,width,height}`, `actualRefImagesUsed`, `qualityGateResults` ({source silhouette, KFB look, composition/purpose, parts budget}), provenance, user feedback and `approvedByGeorg` only if explicit, `git` actual repo/branch/head/blob when verified. Keep fail exports separate from accepted gallery. Never call preview image itself a verified 3D model.

## One-click UI / MCP action contracts for later Work

These names are **proposals for implementation**, not existing tools:

1. `prepare_image_job({assetId, scenePacket?, mode?, styleProfileId?})` → factual source preview image identities, `jobId`, ready/blocked.
2. `render_source_sheet({jobId, angles?})` → cached isolated source-view PNG bytes/secure file refs, source model sha and geometry proof (no screenshot substitute).
3. `generate_kfb_image({jobId, selectedRefImageIds, targetView?})` → generation provider receipt + image bytes/secure refs; rejects absent source reference when `geometryLock=strict`.
4. `evaluate_image({jobId,resultId})` → actual quality results; distinguishes style quality and source fidelity.
5. `store_image_result({jobId,resultId,decision?})` → original output hashes, durable image ref/ZIP, optional GitHub import through separately permissioned action; never auto Golden.
6. `get_job({jobId})` → state, receipts, blockers and links for resume.

The plugin should connect the existing Asset Librarian Site's asset detail/Town Scene Plan via 
`kfb.asset-scene-image-job/1`, not build a parallel file index. An App/MCP extension can expose **Create KFB image** in the Librarian inspector and a compact render/QA view, with an optional browser `assetId` deep link. Follow the current Sites-first policy; never invent its installed app ID or a new public URL.

## Acceptance criteria
- One existing Quaternius organic asset: assetId → identical source isolated 4 views → source image pixels confirmed in image provider request → output still recognizable as same donor; palette material role changes only, quality record.
- One Kenney flattened rock negative regression: 0.256 source height/footprint is retained in strict mode; never transform into a tall stacked mountain.
- One G4 buildable bridge ref: neutral view-label sheet is allowed; no branding, no fake drivable clearance claims, real donor identified; `PARTS.md` ≤6 large roles.
- One real `kfb.town-scene-candidate.v1` scene context, showing exactly selected assets and relations (not generic environment props); no new asset identities.
- Source misses, preview unavailable, commercial/private asset license unresolved → **BLOCKED_SOURCE**, no claim of fidelity; `mood_explore` only on explicit mode.
- Original PNG SHA256, job state, provider receipt and readback of any GitHub upload, actual test counts, portable ZIP; no auto-merge/GOLDEN.

## Architectural preflight evidence (additive, not a new runtime schema)

When the receiving asset class is architectural construction, attach an `architecturalFormPreflight` record to the existing job/result:
- `formBeforeMaterials`: actual neutral proof paths/hashes and chronological gate result;
- `formGrammar`: repeatable design roles/counts, separately `meshCount`; family budget never implies mesh-count budget;
- `constructionContacts`: intended connections plus actual independent height/gap/support and visible context proof, including full landing width/foot datum where relevant;
- `geometryScore` with exactly scored scope, `styleScore`, complete independent scorecard/result, and explicit human Golden state.

The source model -> neutral form proof -> styled result sequence does not grant success merely because all files exist. Source identity, neutral preflight, full contacts and seven-axis outcome are separate facts. Carry FORM_FAIL visibly into the archive and future handoff; a failed candidate is not a normative construction recipe. Use the receiving brief's thresholds, not universal numbers invented here.

Negative regression: source isolation/affine geometry equality PASS plus neutral subset PASS must still retain complete FORM_FAIL when the measured exit/foot contact or independent full quality threshold fails. G4 R3 evidence is in `g4-r3-failure-evidence.md`; no R3 Golden was granted.


## Required architectural anatomy/contact fields for bounded new kits

Extend the existing architecture preflight record with `formGrammar` (<=6 repeatable roles where required by the receiving brief, not meshCount<=6), `formAnatomy`, `constructionContacts`, `formBeforeMaterials`, and class-specific `architecturalTermination`.

Each constructionContact has actual candidate/source identity, source adaptation status, support/soil/exit role, measured gap/embedding/full-width continuity, tolerance, visible image proof, independent tester identity/method and limitations. Keep all unsupported/not-tested fields explicit. A frozen source byte hash and geometrical equivalence of a combined reexport are separate receipts; exported seam vertex/index changes must not be mistaken for shape edits if actual triangle-position equivalence is independently established.

For pillar class only, record foot/shaft/cap bearing anatomy. Record `geometryScore` with criterion scope, separate `styleScore`, full independent `formScore` and human Golden status. True source -> neutral -> styled comparison remains mandatory for construction; an output image itself is not a playable model. The proven R3 attachment reference is a bounded evidence example, not a universal physics or terrain contract.


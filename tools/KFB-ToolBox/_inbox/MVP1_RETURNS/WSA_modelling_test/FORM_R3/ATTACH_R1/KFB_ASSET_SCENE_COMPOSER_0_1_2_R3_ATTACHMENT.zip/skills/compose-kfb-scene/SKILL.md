---
name: compose-kfb-scene
description: Produce a KFB claymation/diorama visual reference or scene image when a user selects a source-backed 3D asset from the KFB Asset Librarian, passes a KFB scene packet, or requests a source-faithful KFB asset image. Use existing connected Github/Asset-Librarian tools, actual source images, the KFB style SSOT, and output provenance; this is not a model/runtime owner.
---

# KFB Asset Scene Composer · private chat workflow v0.1

## Identity and scope
This skills-only plugin provides a reusable **chat authoring workflow**. It does **not** install a one-click button into the Librarian, expose an MCP image-generation tool, host a Site, grant new GitHub privileges, or magically condition a generator on source image pixels from a URL. The **canonical product/data owner** remains `tools/asset_registry/librarian/` in `georg-doc/kayfabizarro` and the productive Site `https://kfb-asset-librarian.frizzlebob.chatgpt.site/`. KFB Clay Asset Studio owns texture/material-map queue items, not this source-led composition workflow. Treat the source item as `candidate-only`.

At each new KFB task, read current GitHub `skills/chat/START_HERE.md`, `skills/chat/CHAT_GITHUB_KFB_STAGE_WORKFLOW.md`, `skills/chat/FRESH_CHAT_SLICE_PROTOCOL.md`, the receiving project SSOT/Return/Recovery, and the updated G1 source-brief where applicable. GitHub current branch facts take precedence over remembered source names or asset packs. Check the exact current branch head before any writing and after each write. Do not merge or promote Live.

## Start from existing sources, not descriptions
Accept (A) `assetId`/`packId` and immutable source/ref, (B) an existing `kfb.asset-handoff.v1` or `kfb.town-scene-candidate.v1` packet, or (C) a specified asset from the user plus a verified file path. Fetch via **existing** Librarian search/get and Registry when available; do not create a duplicate index. Require one real source GLB/GLTF/FBX, an allowed preview license, exact source status, and actual visual/mesh proof. Metadata, a filename, a downloaded asset URL, a pseudo-3D screenshot, or a prompt alone is not evidence that the target mesh is actually shown.

For each candidate obtain a stable **source capture**: full asset isolated, 3/4, front, side, top, below where relevant; same lighting, no props, source proportions and material-part regions; `bbox` in native units, triangle count, expected role and unknown K2 kit factor. Prefer reuse of Librarian's existing `preview3d.js`/`framing3d.js`, its actual GLTFLoader and linked source URL; keep proprietary assets private. If the capture's *actual image pixels* are not available to the image generator in the current session, **do not claim source-faithful generation**. Instead offer to produce a labeled `MOOD_ONLY` concept, or request/prepare the real source render in the original owner. A screen/image URL being accessible does not prove generator conditioning.

## Decide mode and context
Choose with the user or infer from explicit request:
- `asset_plate`: **one selected asset** on an off-white studio/background board, with optional hero 3/4, front/side/top/below detail views and a few named variations (current §7a).
- `scene_context`: a bounded placement/interaction **concept illustration** grounded in selected environment + character/prop asset IDs and a scene purpose (what connects, supports, or motivates each object). Distinguish the illustration from a buildable scene recipe; preserve all source-owner IDs.
- `material_study`: exact mesh geometry retained; only palette/material/light treatment varies. This is a deterministic 3D visual proof when possible, NOT an AI redesign or Golden.
- `mood_explore`: creative visual proposals permitted with clear `MOOD_ONLY` label; never assert source fidelity.

Pack preference follows the receiving biome, geometry roles and current user decisions. Quaternius Nature is a useful first-pass donor for organic scenes when appropriate; the validated repository pack `ultimate-nature-pack-by-quaternius-1` is a source candidate, not a universal new canon. Kenney/KayKit/StreakByte are not categorically forbidden; rank by verified morphology and use. Exclude AI-generated **source packs** when the user asks for human-modeled game geometry, but user-approved generated **concept images** are still allowed as downstream mood/reference evidence.

## Image job contract
Create the canonical `kfb.asset-scene-image-job/1` JSON with actual `assetRefs`, `sourceProof` status, source front/side/3/4 image references **and an explicit boolean of actual pixel availability**; one `context` purpose or selection packet, `mode`, material/style authorities, camera plan, `viewLabelsAllowed`, constraints and `partsBudgetMax=6`. It must include `sourceAssetBlobSha` when available, `sourceModelTriCount`, K2 scale known/unknown, `imageModel` or execution system and the exact prompt, `imageConditioningReceipt` if verifiable, and `provenance`. See `references/job-contract.md`.

KFB art is **hand-built claymation diorama with selective useful material mix**: visually thick readable volumes, intentional cartoon details, large soft facets, KFB role palette, tactile but not photorealistic, no fake CAD-perfect crispness or grid repetition. Maximum **5–6 major buildable shape families** *when proposing a new build kit*; preserve existing donor polygon topology for `material_study`. Context-specific materials (wood, cork, felt, grass, asphalt, glass, emissive, particles) retain their own material grammar; do not translate every surface into watercolor or clay. Read `skills/chat/KFB_OPEN_WORLD_CLAY_SURFACE_CANON_2026-10-07.md` and `skills/chat/KFB_STYLE_REFERENCE_ROUTER_2026-10-07.md` for binding versus benchmark distinction.

Current design-brief §7a: a **single asset multi-view board** can show large 3/4, small front/side/top/below, details, form variants and **neutral panel labels**. No fake KFB title/logos, marketing slogans, unrelated props, figures, vehicles or boats on *isolated asset boards*. In `scene_context` mode, include only characters/vehicles explicitly listed by the receiving scene packet (not blanket banned there). Do not mistake rejected bridge marketing posters for successful donor proofs. For G4 drivable bridges, the construction gate requires flat/deck ≤6% slope, vehicle plus two pedestrian paths and real abutment supports; drawing these is not proof the geometry satisfies them.

## Production protocol
1. **Source card**: show the actual donor alone, measurements and positive/unknown license facts before first artistic image. Mark `SOURCE_ISOLATED`, `UNVERIFIED_SOURCE`, or `BLOCKED` truthfully.
2. **Prepare composition**: choose 1 asset or bounded context, KFB benchmark subset (not whole style pool), camera/light/material role and at most 5–6 large build families for new kit proposal. Generate and save `PARTS.md` before concept acceptance, H dimensions provisional when unmeasured.
3. **Render**: use an image generator only if one is *actually available*, and feed it **real attached source image data**, not source paths alone. This plugin cannot invoke image generation autonomously in every host; if unavailable, package a source-conditioned prompt and host/Work handoff, don't fabricate output. For highest geometric fidelity, prefer a render of the original GLB with material-only conversion in the existing owner, then optional image edit guided by that render.
4. **Critique** against source silhouette, distinctive proportions, components/color regions and intended scene relations; independently inspect true generated pixels. Two non-improving repairs on same failing seam => freeze/export exact failures, switch rendering strategy; do not reword endlessly.
5. **Review classification**: `MOOD_ONLY`, `STYLE_DIRECTION_ONLY`, `CANDIDATE_FOR_REVIEW`, `SOURCE_LOCKED_MATERIAL_STUDY`, `GOLDEN_REF` (only explicit Georg selection), `FAILED_QUARANTINED`. Positive 'super' ≠ donor Golden.
6. **Archive immediately**: original full PNG(s) with SHA256/bytes/dimensions, source render(s), prompt and `PARTS.md`, manifest, QA and relevant source refs in an additive ZIP; provide a real link only when verified. Do not mark an untransferred sandbox/ZIP as committed to GitHub. Reuse source-locked URLs, distinguish private packs. Later WSA Work can upload PNGs after hashes validate; GitHub readback/Return only after actual commits.
7. **Hand-off**: named repo/branch/head, exact files, actual test/quality counts, image output status, no inferred Site or Stage. Let the existing Librarian/WB owner integrate.

## WSA Work handoff for a genuine button
To make an actual one-click asset-to-image capability, **extend the existing Librarian Site and its future plugin/MCP backend** with an asset-identity-preserving `Create KFB image` action, rather than making this skills plugin a second registry or UI owner. It must capture/render source pixel bytes server-side (GLB/GLTF/FBX handling), call a configured image generation provider or existing image-generation host with an authenticated API under owner control, store job IDs and full PNGs durably, and return the exact file/hash/status. Build/export this only in a named Site-capable Work slice after the source preview and provider contract are demonstrated. See `references/job-contract.md`.

## Archive / source anchors
- Existing G1: `tools/KFB-ToolBox/_inbox/MVP1_RETURNS/G_asset_candidates/RECOVERY_G1.md` and `G1_R9_KENNEY_ROCK_MESH_COMPARISON.md`, branch `planning/kfb-mvp1-asset-candidates-2026-10-10` (historical working state, may now be superseded).
- Actual Quaternius source: `media/3D_Assets/QUATERNIUS_ULTIMATE_NATURE_SOURCE_2026-10-08.json` and `registry/assets/v1/packs/ultimate-nature-pack-by-quaternius-1.json`; verify source match and license on exact revision.
- Current Librarian: `tools/asset_registry/librarian/README.md`, `preview3d.js`, `town-workbench.js`, `framing3d.js`, canonical Site `https://kfb-asset-librarian.frizzlebob.chatgpt.site/`.
- Previous high-res art receipts: separately branched `assets/kfb-mvp1-concept-originals-2026-10-10` and its `ORIGINALS_UPLOAD_R1.md`; do not duplicate pixels or mark them merged without GitHub evidence.

## Architectural form preflight · R3 independently evidenced failure learning

For architectural construction classes, require an actual neutral, untextured source-to-candidate comparison **before** Clay styling. Capture source isolation, candidate 3/4/front/side, and bearing/termination contacts. Neutral form evidence is a preflight, not full construction acceptance. A partial neutral PASS must remain separate from the full criterion roster and human Golden.

Source isolation proves the donor was actually inspected; it does not prove that its placement has a continuous landing exit, correct foot datum, or credible embedding. Record intended `constructionContacts` separately from actual full-width height/gap/support measurements and independent visible context. Affine source-vertex equality and successful GLB import must never substitute for those contact checks.

For a new kit, `formGrammar` records repeatable design roles (the receiving brief may bound them to six); `meshCount` records the actual export separately. Do not infer a six-mesh limit or monolithic construction from a family budget. Preserve the strict geometry lock in material_study mode.

Record `geometryScore`, its scored scope, `styleScore`, complete independent criteria and explicit `FORM_PASS / FORM_FAIL / UNDECIDED`. If source or independent evaluation is missing, retain UNDECIDED. Failed terrain/contact placement stays a quarantined seam and cannot become a successful construction recipe. Do not replace a geometric contact failure with palette, bevel, bump, or an attractive picture.

Bounded negative evidence: [G4 R3 failure recovery](https://github.com/georg-doc/kayfabizarro/blob/e6f2aa1e1f0efb130975b1af498fcdba635f3ad0/tools/KFB-ToolBox/_inbox/MVP1_RETURNS/WSA_modelling_test/FORM_R3/FAILURE_RECOVERY_R3.md), [independent final scorecard](https://github.com/georg-doc/kayfabizarro/blob/e6f2aa1e1f0efb130975b1af498fcdba635f3ad0/tools/KFB-ToolBox/_inbox/MVP1_RETURNS/WSA_modelling_test/FORM_R3/critic/final/SCORECARD_FINAL_R3.json), and [actual Q1–Q9](https://github.com/georg-doc/kayfabizarro/blob/e6f2aa1e1f0efb130975b1af498fcdba635f3ad0/tools/KFB-ToolBox/_inbox/MVP1_RETURNS/WSA_modelling_test/FORM_R3/qcheck_r3.json). R3 neutral G0 scored8.0, while complete R3 scored7.7143 and failed its required mean>=8; terrain exit drops0.26941–0.55830Lab exceeded0.0728. The newly modeled pillars were genuinely foot/shaft/cap (score9); **do not** mislabel them blob_pillar_not_column or teach this failed context as a build recipe. See [bounded failure reference](references/g4-r3-failure-evidence.md).


## Proven architectural construction contract · R3 ATTACH_R1 bounded evidence

For new architectural build-kit proposals in a receiving brief with the six-role budget, the job must include `formGrammar` (<=6 repeatable design roles) **separately from** actual `meshCount`, and `formAnatomy` with each role's visible construction purpose. A role may have multiple meshes. Material-study mode retains its original geometry lock; this evidence does not authorize donor redesign.

Architectural classes must carry `constructionContacts`: actual bearing/support, soil footing and full-width connection measurements with visible proof, named tolerance, candidate hash, independent method and limits. Preserve source identity while explicitly classifying a reshaped donor as ADAPTED_HILL (or the applicable adapted class); source isolation is not unchanged-geometry evidence. No overlapping terrain copies or cosmetic fill can stand in for verified contact.

`architecturalTermination` is class-specific. For a pillar/column termination use actual foot/shaft/cap anatomy and bearing relations when the brief asks for that class. Do not impose three-zone columns on all props or all architecture. Distinguish foot-to-soil anchoring from shaft support through the foot; not every zone must touch soil directly.

`formBeforeMaterials` must preserve chronological source_model -> neutral-form proof -> styled-result. Compare true same-camera views and retain separate geometry/contact score, styleScore, complete independent formScore, and explicit human Golden status. A numerical form PASS may coexist with STYLE_TUNE and runtime NOT_RUN; it does not grant Golden or runtime certification.

Bounded proven example: [retained R3 + repaired attachment](references/g4-r3-attachment-proven-evidence.md). Seven independent scores8/8/9/8/8/7/8 mean8.0/min7 meet that brief's FORM criterion; style7 stays TUNE. Only the actual anatomy/contact/preflight distinctions are learned here, not a universal terrain recipe, camera, scale, capsule dimensions, or K2 material parity. Preserve the earlier failure evidence as history; never rewrite its FAIL into PASS.


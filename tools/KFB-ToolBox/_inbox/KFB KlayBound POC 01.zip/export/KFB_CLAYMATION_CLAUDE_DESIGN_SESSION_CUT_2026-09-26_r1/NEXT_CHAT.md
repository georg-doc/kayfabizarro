# NEXT_CHAT · paste-ready

1. `START_HERE.md` lesen.
2. `HANDOVER.md` lesen.
3. `SOURCE.json` lesen.
4. `CHANGELOG.md` (oberster Eintrag 2026-09-26) lesen, dann `docs/LIVING_CLAY.md`.
5. GitHub-/Owner-Wahrheit (georg-doc/kayfabizarro, Projekt `github.md`) schlägt diesen Export, falls neuer.
6. D1 zuerst reproduzieren (`KFB Knet-Probe D1.dc.html`), Totale und Ziegel gegen `evidence/` vergleichen.
7. Kein neuer Owner, kein Redesign vor Parity. Neue Modulfassung heißt `.vN.js` (Browser-Cache).
8. Nur das Gate bearbeiten: **D2 · Startgerade Cologne Option C mit clay-material.v3 + Vorstufe, Bildrate bei Renntempo.**

# CURRENT_STATE

- Sichtbar: D1 Totale, Palette Claybound, Licht Tag, alle Schichten an.
- Defaults (im Code): stroke 0,55 · grain 0,16 · macro 0,5 · tile 1,6 · facet 0,14 · crease 0,6 · facetSize 0,65 ·
  print 0,35 · oil 0,22 · pStri 1 · pSmear 1 · pLine 1 · procK 300 · Relief-Saat 11 · Kartengröße 1024.
- `RUNTIME_STATE_NOT_SERIALIZED`: Reglerstände liegen nur im React-State der DC; kein localStorage.
- Georgs eigener Reglerstand beim »top!«: unbekannt (`missing`).

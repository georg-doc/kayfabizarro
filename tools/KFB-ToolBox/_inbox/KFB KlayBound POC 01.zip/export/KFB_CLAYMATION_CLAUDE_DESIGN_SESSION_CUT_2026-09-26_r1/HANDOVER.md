# HANDOVER · KFB Claymation · 2026-09-26 r1

## A · User intent
Georg will für KFB (Race Track, Welt, Kid-Figuren) den Claymation-Look aus Claybound: runde, weiche
Spielzeug-Knetwelt, Haptik durch Licht und Relief, keine schlampige Bastelei. Später: alles verhält sich
wie Gummi und Knete, auch bei Kollisionen (»KlayfaBizarro«).

## B · Current result
- `KFB Knet-Probe D1.dc.html`: Three.js-Szene mit Plateau aus Kissenziegeln, zwei KayKit-Häusern, Kenney-Fahrbahn
  und -Rennwagen, CapsuleCarl, Knetwolke, violetter knetbarer Masse, Tafelbergen. Jede Look-Schicht schaltbar.
- `KFB Knetwelt Look-Konzept.dc.html`: Recherche und Konzept im DocCheck-Stil.

## C · What changed this session
Alles neu: `lab-clay/` (probe v1→v3, material v1→v3, relief v1→v2, soften v1), beide DCs, `ref/claybound/`,
`ref/clay-joebinns/`, `LIVING_CLAY.md`, Einträge in CHANGELOG/HOUSEKEEPING/github.md.

## D · Source / owners / donors
| Quelle | Rolle | Pin | Status |
|---|---|---|---|
| dermosef91/claybound | Look-Vorbild, Technik aus README/PR-Texten im Suchindex | Repo 404 über unseren Zugang | DONOR_ONLY (kein Code gelesen) |
| kayfabizarro `tools/KFB-ToolBox/_inbox/KFB Style References/ClayBound Cozy Platformer + Editor/` | 14 Referenzbilder | main @6e41ca0b4a52 | USED |
| joebinns/clay (MIT, Unity) | Verfahren Druckfacetten + Fingerabdruck-Dellen/Glanz | e8d2a792cc45 | DONOR_ONLY (kein Code) |
| cgbookcase Fingerprints 01 via joebinns/clay | Fingerabdruck-Aufnahme | `Assets/Textures/Fingerprints01_3K.png` @e8d2a792cc45 | USED (LOCAL_NOT_EXPORTED) |
| Perplexity-Demo `…/KFB ClayBound-Perplexity v1/` | Saat je Objekt | main @0f6012932fc7 | DONOR_ONLY (Idee) |
| KayKit City Builder building_A/E, Mystery S6 CapsuleCarl, Kenney Racing roadStraight/raceCarOrange | Testmodelle | kayfabizarro @2ff8b350 | USED (PINNED_REMOTE) |
| `lab-v9/option-c-style.v1.js` | gemessene Option-C-Farben | Projekt | USED (Werte übernommen) |

## E · Protected boundaries
Keine Race-Physik, Kamera, OSM-Geografie, Augen-/Mund-Rigs, Motion Library, World-Light-Rig neu bauen.
D1 ist Probe, kein Runtime-Owner. `lab-v2/vendor/` unberührt (CLAUDE.md).

## F · Current controls / workflow
Panel links: Relief an/aus · Vorstufe an/aus · Palette Claybound/Option C/Original · Licht Tag/Golden Hour/Höhle ·
AO an/aus · Kamera Totale/Nah/Ziegel · Referenz 05 zeigen. Regler: Flächen · Schlieren/Druckwellen/Grate,
Modelle · Handspuren, Feinkorn, Druckstellen, Kachelgröße, Druckfacetten, Falten, Facettengröße, Fingerabdrücke,
Hautfett. Orbit per Maus. Konsole: `window.__clayProbe.set(key, value)`, `.info`.

## G · Working / tested
Nur in der Claude-Preview beobachtet: Szene lädt ohne Konsolenfehler, alle Modelle laden, Schalter wirken,
Pixelaufnahmen in `evidence/`. Georg hat den Stand gesehen und als POC angenommen.

## H · Open / tune / blocked
- TUNE: Dichte/Stärke der Flächen-Züge, Default aus Georgs Reglerstand
- TUNE: Palette-Zuordnung (Kenney-Auto gelb statt orange)
- OPEN: Tafelberge sind Kästen · Kid ohne KFB-Augen-Rig
- DEFERRED: KlayfaBizarro-Kollisionen (Gummi federt zurück, Knete bleibt verformt)
- DEFERRED: Stop-Motion (Georg: vorerst nicht)
- SOURCE_REQUIRED: CC0-Plastilin-Texturen (Kandidaten im Konzept, Archive nicht im Repo)
- OPEN: Lizenz cgbookcase vor Veröffentlichung prüfen

## I · Rejected / superseded directions
- Stempel-Relief (Fächer, Spachtel) auf großen Flächen: repetitiv (Georg)
- Voronoi-Falten auf großen Flächen: lesen als Netz
- Höhenlinien cos(φ·K): Holzmaserung · gleichmäßig dichte Züge: Cord
- Farbtextur mit Flecken als Knet-Ersatz: gemessen trägt Farbe die Haptik nicht (Streuung 2–9/255)

## J · Next gate
D2 · Startgerade Cologne Option C mit `clay-material.v3` + Vorstufe, Bildrate bei Renntempo messen.

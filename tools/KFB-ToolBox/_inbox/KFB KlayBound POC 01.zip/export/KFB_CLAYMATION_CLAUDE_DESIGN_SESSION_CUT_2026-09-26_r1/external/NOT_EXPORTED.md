# NOT_EXPORTED

| Originalpfad | Größe | Rolle | Status |
|---|---|---|---|
| `ref/clay-joebinns/Fingerprints01_3K.png` | 4 699 482 B | Fingerabdruck-Lage im Knet-Material | LOCAL_NOT_EXPORTED |

Wiederherstellen: `https://raw.githubusercontent.com/joebinns/clay/e8d2a792cc45/Assets/Textures/Fingerprints01_3K.png`
nach `ref/clay-joebinns/Fingerprints01_3K.png` legen. Ohne die Datei startet D1 trotzdem; `makePrintTexture`
schlägt fehl, der Fehler steht in `info.errors`, die Fingerabdruck-Lage fällt aus. Replay ist damit
eingeschränkt, nicht blockiert.

Ebenfalls nicht exportiert (SUPERSEDED, kein Importer): `lab-clay/clay-probe.v1/v2`, `clay-material.v1/v2`,
`clay-relief.v1`; Originale `ref/claybound/cb-*.png` (je 2–4 MB).

## Link-Ziele im Konzept (RELATIVE_PATH_RISK)

`KFB Knetwelt Look-Konzept.dc.html` verlinkt beim Klick auf eine Referenz das Original `ref/claybound/cb-NN.png`
(12 Links, je 2–4 MB). Die angezeigten Bilder (`ref/claybound/web/*.jpg`) liegen im ZIP; nur der Klick ins
Original führt im Export ins Leere. Originale: kayfabizarro @6e41ca0b4a52
`tools/KFB-ToolBox/_inbox/KFB Style References/ClayBound Cozy Platformer + Editor/Bildschirmfoto 2026-09-26 um 05.*.png`.

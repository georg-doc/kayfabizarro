# ASSET_REFS

| Pfad | Klasse |
|---|---|
| https://unpkg.com/three@0.160.0/build/three.module.js + examples/jsm/* | CDN_EXTERNAL (versioniert) |
| raw.githubusercontent.com/georg-doc/kayfabizarro/2ff8b350…/media/3D_Assets/KayKit_City_Builder_Bits_1.0_FREE/Assets/gltf/building_A.gltf, building_E.gltf (+ .bin, citybits_texture.png) | PINNED_REMOTE |
| …/media/3D_Assets/KayKit_Mystery_Series6/CapsuleCarl/gltf/player.gltf (+ .bin, capsule_texture.png) | PINNED_REMOTE |
| …/media/3D_Assets/kenney_racing-kit/Models/GLTF format/roadStraight.glb, raceCarOrange.glb | PINNED_REMOTE |
| `ref/clay-joebinns/Fingerprints01_3K.png` | LOCAL_NOT_EXPORTED, Quelle joebinns/clay@e8d2a792cc45 |
| `ref/claybound/web/*.jpg` | LOCAL_INCLUDED |
| `_ds/…/colors_and_type.css`, `_ds_bundle.js`, `fonts/*` | LOCAL_INCLUDED |
| `ref/claybound/cb-*.png` (Link-Ziele im Konzept) | RELATIVE_PATH_RISK, siehe NOT_EXPORTED.md |

# TEST_REPORT

## Static / source
- Importpfade der Closure geprüft (38 Referenzen): alle Laufzeit-Imports vorhanden. Nicht im Export: Fingerabdruck-PNG (LOCAL_NOT_EXPORTED) und 12 Original-Links im Konzept (RELATIVE_PATH_RISK)
- JSON SOURCE.json / EXPORT_MANIFEST.json parsen: PASS (Skript)
- Datei > 2 MB im Export: keine (Skript)

## Runtime / browser
- Claude-Preview: D1 lädt, keine Konsolenfehler, Modelle 200: PASS (beobachtet 26.09.)
- Clean Run aus dem entpackten ZIP: `CLEAN_RUN_NOT_EXECUTED` (keine Laufzeit außerhalb des Projekts)
- Bildrate: gemessen nur in der Preview, kein Zielgerät: `NOT_RUN`

## Visual / human
- Georg: v2 »Texturen viel zu unnatürlich und repetitiv … für Carl & Modelle passt es«
- Georg: v3 »top! guter erster POC — wir müssen das später noch finetunen«

## Not tested
- Mobile, Zielgerät, Integration in Cologne Option C, Kollisionen, Tonemapping-Varianten, CC0-Texturen
- `zipcheck.py`: `ZIPCHECK_NOT_RUN` (kein Python in der Umgebung); dieselben Prüfungen manuell per Skript

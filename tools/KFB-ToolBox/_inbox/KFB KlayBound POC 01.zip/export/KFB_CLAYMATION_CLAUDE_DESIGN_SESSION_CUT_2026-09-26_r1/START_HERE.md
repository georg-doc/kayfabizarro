# START_HERE · KFB Claymation · Session Cut 2026-09-26 r1

1. **Projekt / Slice / Datum:** KFB Animation Lab · Knetwelt-Linie (Claymation-Look), D1 Knet-Probe · 2026-09-26
2. **Status:** `CANDIDATE` · Georg: »top! guter erster POC — wir müssen das später noch finetunen«
3. **Entry Point:** `KFB Knet-Probe D1.dc.html` (Szene) · `KFB Knetwelt Look-Konzept.dc.html` (Konzept)
4. **Start:** Ordner über einen statischen Server ausliefern (`python3 -m http.server`), Entry Point öffnen.
   Braucht Netz: three@0.160.0 von unpkg, Modelle von raw.githubusercontent.com @2ff8b350.
   Die Fingerabdruck-Karte ist nicht im ZIP (4,7 MB), siehe `external/NOT_EXPORTED.md`; ohne sie läuft die
   Szene, die Fingerabdruck-Lage fällt aus.
5. **Zuerst lesen:** `HANDOVER.md` → `docs/LIVING_CLAY.md` → `SOURCE.json` → `CHANGELOG.md` (oberster Eintrag)
6. **Owner:** Claude Design Projekt »KFB Animation Lab« · Receiving Owner: nächster Chat dieser Linie
7. **Besitzt NICHT:** Race-Physik (Race v0.8), Kamera der Option C, OSM-Geografie, Augen-/Gesichts-Rigs,
   Motion Library, World-Light-Rig (Travel-Owner laut WORLD_COLOR_LIGHTING_COHESION). D1 ist eine Probe.
8. **Next Gate:** D2 · Startgerade Cologne Option C mit `clay-material.v3` + Vorstufe, Bildrate bei Renntempo messen.

# LIVING_CLAY · Knetwelt-Linie (Claymation-Look)

Stand 2026-09-26 · ein Stand-Dokument für diese Linie. Ein frischer Chat liest zuerst dieses, dann `CLAUDE.md`.

## Wo die Linie steht

**D1 Knet-Probe ist ein erster Proof of Concept (Georg: »top! guter erster POC — wir müssen das
später noch finetunen«).** Arbeitstitel der Richtung: **»KlayfaBizarro«** — alles ist Gummi und
Knete, auch bei Kollisionen.

- Einstieg: `KFB Knet-Probe D1.dc.html` → `lab-clay/clay-probe.v3.js`
- Konzept und Recherche: `KFB Knetwelt Look-Konzept.dc.html`
- Referenzen: `ref/claybound/` (14 Bilder, Originale + `web/`-Fassungen, 4 Nahaufnahmen)

## Module

| Datei | Rolle |
|---|---|
| `lab-clay/clay-probe.v3.js` | Szene D1: Plateau aus Kissenziegeln, KayKit building_A/E, Kenney roadStraight ×5 + raceCarOrange, CapsuleCarl, Wolke, knetbare Masse, Tafelberge. Schalter Relief, Vorstufe, Palette, Licht, AO, Kamera. |
| `lab-clay/clay-material.v3.js` | Knet-Material (MeshPhysical + onBeforeCompile). Zwei Relief-Wege: **Modelle** (Quellmaterial vorhanden) über die Stempelkarte + Druckfacetten + Fingerabdrücke; **Flächen** (kein Quellmaterial, `CLAY_PROC`) vollprozedural: Druckwellen, einzelne Fingerzüge, abreißende Grate. Palette per Nächster-Farbe in OKLab. Saat je Objekt. |
| `lab-clay/clay-relief.v2.js` | CPU-Generator der kachelbaren Gradientkarte (Handspuren RG, Feinkorn BA). |
| `lab-clay/clay-soften.v1.js` | Geometrie-Vorstufe: unterteilen, nach Lage verschweißen, Taubin, Beulen, weiche Normalen. |

## Befunde, die die Bauweise bestimmt haben

1. **Relief als Gradient, nicht als Normal-Map.** Pro Projektionsachse eindeutig, die Vorzeichenfalle
   (Claybound PR #62, GLTFLoader-Y-Flip) kann nicht auftreten.
2. **Wiederholung kam aus dem Objektraum.** Alle Ziegel gleicher Größe trugen dasselbe Muster.
   Lösung: Attribut `claySeed` je Instanz (geteilte Geometrie wird geklont).
3. **Stempel und Voronoi lesen auf großen Flächen als Muster** (Georg: »viel zu unnatürlich und
   repetitiv … für Carl & Modelle passt es«). Darum zwei Wege, getrennt nach Quellmaterial.
4. **Verworfen auf dem Weg zu v3:** Höhenlinien eines Rauschfeldes (lasen als Holzmaserung),
   gleichmäßig dichte Züge (Cord). Aktiv: dünn besetzte, einzelne Fingerzüge.
5. **Die Häuser sind nicht modelliert.** Unveränderte KayKit-Modelle; schiefe Fenster und weiche
   Kanten kommen aus der Vorstufe. Georg lobte genau das → Verfahren für OSM-Blöcke vormerken.

## Entscheidungen Georg (26.09.)

- Relief zuerst prozedural, sauber. CC0 als zweiter Weg.
- Palette Claybound, Option C als Schalter.
- Kein Stop-Motion vorerst.
- Knet-Baukasten (OSM-Blöcke, Landmarken, Blender MCP, Blockfiguren mit KFB-Augen) als Option.
- KlayfaBizarro: Gummi federt zurück, Knete bleibt verformt (DEFERRED, noch nicht gebaut).

## Offen

- TUNE: Dichte/Stärke der Flächen-Züge; Default-Werte aus Georgs Reglerstand übernehmen.
- TUNE: Palette-Zuordnung (Kenney-Auto wird gelb statt orange).
- OPEN: Tafelberge sind noch Kästen.
- OPEN: Kid ohne KFB-Augen-Rig.
- DEFERRED: Kollisionsverhalten Gummi/Knete im Deformer.

## Nächstes Gate

D2 · Startgerade Cologne Option C mit `clay-material.v3` + Vorstufe, Bildrate bei Renntempo messen.

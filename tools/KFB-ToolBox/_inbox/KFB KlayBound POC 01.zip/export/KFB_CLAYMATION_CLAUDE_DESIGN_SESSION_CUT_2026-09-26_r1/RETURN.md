# RETURN · 2026-09-26

**Auftrag:** Claymation-Look nach Claybound recherchieren, Konzept, dann Demos an unseren Modellen.

**Geliefert:**
- Konzept `KFB Knetwelt Look-Konzept.dc.html` (Quelle, Referenzen, gemessene Palette, Kernfrage, Technik, Übertragung, Demos, Entscheidungen, KlayfaBizarro, weitere Quellen, CC0)
- D1 `KFB Knet-Probe D1.dc.html` mit vier Modulen unter `lab-clay/`
- Stand-Dokument `docs/LIVING_CLAY.md`

**Georgs Urteil:** Modelle und Carl passen (v2), Flächen waren zu repetitiv → v3 prozedural → »top! guter erster POC«.

**Nicht erledigt:** Feinabstimmung, KlayfaBizarro-Kollisionen, D2, D3, Augen-Rig am Kid, Tafelberge.

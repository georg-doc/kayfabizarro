# User Journey · from LEGO pieces to drawn KFB roads

| Phase | User action | System action | Proof required | Status |
|---|---|---|---|---|
| T0 | Modultyp wählen, Länge/Radius/Breite/Spuren/Steigung ändern | parametrische 2D-Absicht append | reacts instantly / round-trip | **in prototype** |
| T0 | Socket auswählen, Abzweig legen | graph grows from historical anchor | unique IDs / branch degree | **in prototype** |
| T0 | Freihandlinie zeichnen | RDP + Chaikin samples + soft endpoint snap | stroke retained and editable via JSON | **in prototype; not true route fit** |
| T0 | Zwei Sockets verbinden | provisional Hermite sample | hard label UNCOMPILED | **in prototype; geometry uncertified** |
| T1 | Module and lanes live adjust | core-based recompile + undo | exact sealed socket & profile checks | **future** |
| T1 | Real T/Y/X split and merges | resolve graph into tested Track Core junctions | no overlap plates, test junction radius, lanes, contact, save/reload | **future** |
| T1 | Stroke through landmarks | constrain to POI anchors, forbidden polygons | 2-3 geometry candidates + reject reason | **future** |
| T1 | Place 3D preview | render actual TrackStream with existing approved source objects | source isolation / gap / contact screenshot | **future** |
| T2 | Adapt roads to coastline/canyon | call Surface Truth contribution, no duplicated terrain | cut/fill + bridge seams + support grounding | **future** |
| T2 | Insert looping, corkscrew, jump, bank | supported core module selection; check bypass + envelope | real stunt and physics ownership tests | **future** |
| T2 | Link islands via destinations | route branch with meaningful POI and realm transition | grounded world model, no random dead end | **future** |
| T3 | Drag handles/freehand painting like Road Constructor | incremental re-solve, snapped sockets, ghost preview, cost field | edit/reload stability; independent browser critique | **future** |

## UI principles

- A user gesture always manipulates one **semantic graph**, not final mesh vertices.
- Show **GREEN = solved**, **AMBER = tentative**, **RED = rejected**, no decorative acceptance labels.
- Prioritize selecting existing source-backed built parts. Keep missing candidates explicitly missing.
- A side branch has a reason: alternate lap / destination / scenic POI / bypass; not arbitrary free space-filling.
- The world should be readable at top-down, sectional elevation and 3D review levels; these are three views of the **same authored graph**.
- Road Constructor (Unity) is a UX comparison, not dependency/license or authorization to port proprietary code.

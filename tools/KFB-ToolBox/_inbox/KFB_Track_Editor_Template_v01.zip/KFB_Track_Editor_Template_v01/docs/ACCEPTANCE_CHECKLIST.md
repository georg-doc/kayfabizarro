# Acceptance Matrix · local demonstrator vs production

## Local reference demonstrator (this ZIP)

- [x] Editor controls exist for length, radius, grade, road width, total lanes, profile hint.
- [x] Append straight, left/right arc, S turn, ramp, bridge, tunnel and symbolic looping.
- [x] Select existing socket, append route as branch, show topology counts.
- [x] Draw freehand stroke, simplify/smooth preview and snap near endpoints.
- [x] Connect two sockets using tentative Hermite preview.
- [x] Export/import input model and SVG schematic.
- [x] Audit warnings explicitly label uncompiled stunt and heuristic geometry.
- [x] Node tests (actual count in Test Report / handover reply).
- [ ] Proven production Track Core compilation (not attempted).
- [ ] Accepted RKit module visuals isolated from real 3D sources (not attempted in local UI template).
- [ ] Exact K2 production scale match (not attempted).
- [ ] Terrain-fit, islands, collision/contact or lap drive proof (not attempted).
- [ ] Formal Stage/Site verification (not required for this offline handover).

## Production acceptance (future only)

- Existing Track Core produces all frames and socket contracts from the graph.
- Real RouteRecipe compiles; `runChecks` / `runGraphChecks` and latest v0.14 owner tests pass.
- Curvature continuity, lane consistency, Bank/Grade continuity, no fold, no overlap plate, no illegal width taper.
- Real T/Y/X, exit/entry, split/merge and roundabout only when solver supports them; rejected variants shown as rejected.
- Looping requires real three-dimensional closure, headroom, plausible vehicle envelope, bypass and actual contact/physics ownership proof.
- Surface Truth provides grounded terrain cut/fill and legal support/bridge/tunnel constraints.
- Existing Joyride/KFB source family isolated and visually verified before integrated use.
- World save/fresh reload retains stable route/module identities.
- Independent Critic and Georg gate only at the correct project milestone; no auto-merge/Live.

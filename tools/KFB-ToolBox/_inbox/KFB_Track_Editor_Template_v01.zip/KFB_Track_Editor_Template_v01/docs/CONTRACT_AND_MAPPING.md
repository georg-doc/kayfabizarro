# Contract · Track Intent → existierender Track Core → RKit / Blender

**Status: Mapping-Vorschlag, nicht laufender Connector.**

## 1. Gemessene Source-Anker, keine erfundenen Owners

- `georg-doc/kayfabizarro`, aktuelle RKit-R3-Produktion auf Branch `blender/rkit-r3-p1-junction-profiles-2026-10-08` (am 2026-10-09 per GitHub Connector lesbar):
  `tools/KFB-ToolBox/_handover/RKIT_R3_BLENDER_MCP_CONSTRUCTION_2026-10-08/production_gate1b/docs/RETURN_GATE1B.md`.
  R3 Gate1b: Track Core v0.14, realer Blender-Assembly-Probe, Exit/Entry, Diverge/Converge und K2-Maßstab; **Zur Abnahme, nicht akzeptiert.** Einzelheiten in dortigem Return und `KFB_PROFILE_FAMILIES_v014_K2.md`.
- RKit-R3-Leitbrief: `tools/KFB-ToolBox/_handover/RKIT_R3_BLENDER_MCP_CONSTRUCTION_2026-10-08/BLENDER_MCP_FULL_BRIEF.md` auf dem entsprechenden Planning-/Build-Branch. Explizit: gezeichnete Straßen-Editor-Funktion ist ZUKÜNFTIG und muss im bestehenden Track-Core-Owner realisiert werden.
- Produkt-/Ownership-Kanon: `skills/chat/KFB_OPEN_WORLD_ROAD_TRACK_CORE_CANON_2026-10-07.md` im öffentlichen `georg-doc/kayfabizarro`.
- Historische **gepinnt-public Referenz**, nicht als neueste Private Owner-Version zu behaupten: `tools/KFB-ToolBox/_inbox/KFB_JOYRIDE_J14_CLAUDE_DESIGN_SESSION_CUT_2026-09-30_r1/lab-track/core/track-core.v012.mjs`. Enthält `compileRecipe`, `compileGraph`, `expandNodes`, `profileSlots`, `attachRings`, `runChecks`, `runGraphChecks`, `slotWorld`, `fingerprint`, Breiten 10.8/14.4/18/21.6/28.8 und 14 Querschnitt-Slots.
- Historische private RKIT-01…11 Kandidaten: `georg-doc/KFB-Stunt-Car-Race` Draft-PRs #34–#42. Relevanter Quellenvergleich sollte von einem Race-Owner-Leser erfolgen, nicht mit eingefrorenen POC-Annahmen.

## 2. Ein Produkt, eine Baupipeline

```text
Human editor gesture
  - click module / draw polyline / select socket / branch / connect
  -> TrackIntent [neutral transport DTO, this template]
  -> IntentAdapter [LATER, receiving Track Core owner]
       maps semantic edge kinds to approved RouteRecipe / graph ops
       fetches canonical profile definitions, constraints and socket frames
  -> EXISTING Track Core
       compileRecipe / compileGraph / runChecks / runGraphChecks
       authoritatively solves curvature, grade, bank, width transitions,
       intersections, profile slots, stable identities, contact frames
  -> TrackStream + socket/module placement metadata
  -> Blender RKit source-verified isolated donor modules / exporter
  -> GLB and editable .blend (accepted only after QA)
  -> EXISTING WorldBuilder Surface Truth terrain contribution/contact
  -> EXISTING Joyride/KFB Clay presentation and Race physics consumers
```

This zip creates **only the first DTO + visualization**. The path after `IntentAdapter` is a design contract, NOT invoked by the prototype.

## 3. DTO ownership and fields

`TrackIntent`:

- `format`: literal `kfb.track-intent.template/0.1` (**not** a canonical Track Core recipe schema).
- `coordinateConvention`: `x,z` horizontal map position, `y` elevation, positive heading clockwise from +X, **different heading convention from pinned Track Core v0.12**; adapter must convert to Track Core's +Z heading and handedness.
- `nodes[]`: `{id,x,z,y,heading,kind}` = position and desired outgoing orientation (an *editing anchor*, not a physically accepted Track Core socket).
- `edges[]`: `{id,from,to,kind,params,samples,semantic,status}`.
- `samples`: approximate editor preview line; never feed as production mesh/contact truth without Track Core compilation. `sourceStroke` (sketches) preserves user gesture separately.
- `activeSocketId`, `seq` are local UI editing state.

### Intended operation mapping (exact production API must be checked)

| Template kind | Candidate Track Core meaning | Status |
|---|---|---|
| straight | STRAIGHT / recipe node | API lookup required |
| left/right | ARC / clothoid transition recipe | current demo is circular only |
| s | two arcs with necessary transitions | requires admissible curvature solve |
| ramp | RAMP/CREST/DIP with smooth vertical transitions | preview currently linear elevation |
| bridge | elevated route plus cross-section/support metadata | surface/structure authority required |
| tunnel | TUNNEL/clearance/terrain opening | Surface Truth owner required |
| loop | LOOP / 3D track and stunt envelope, bypass | symbolic only |
| connector | CONNECT / stable socket transform | Hermite preview only |
| sketch | stroke-to-route fit with constraints and editable handles | stroke samples saved |
| branch / merge | core graph topology + validated junction | UI can branch, junction proof is missing |

No new spline-mesh owner. No automatic GLB creation from approximate editor polyline.

## 4. K2/Scale pinning

RKit R3 v0.14 Gate1b reports **MC = 6.4** and reference character height **H = 3.64** in the Island Lab. World road profile examples: TOWN 1+1 = 19.2 (3 MC), TOWN 2+2 = 32.0 (5 MC), DRIVING_SCHOOL 1+1 = 12.8 (2 MC). Reference Race widths from older public Track Core are different. Do not silently use this template's 14.4 m as K2's Town road.

`RACE_W` (race scaled for 6.0 world vehicle / 4.1 race vehicle ~1.463) appears in the R3 Gate1b docs **as a proposal awaiting Georg's approval**, not an accepted profile. Adapter must obtain receiving owner's accepted values before using it.

## 5. Socket contract to upgrade

The current anchor `position + heading` must become a resolved socket containing:

```
nodeId, portId, sourcePieceId, surfaceProfileFamily, materialRoleFamily,
frame = {position3, T, U, R}, width, laneCount, lanesDirection,
grade, bank, stableIdentity, clearanceEnvelope, permittedConnections,
terrainSupportRequirements, status, coreVersion, sourceHash
```

Generate socket transforms from **Track Core's own frames**, not from this demo's screen-plane atan2.

Snap constraints: exact endpoint position, tangent/curvature compatibility, grade continuity, bank transition, lane match, profile and materials, barrier/kerb/deck seams, terrain clearance, 3D collisions, legal branch class and world-object identity. Auto-insert an existing compatible connector only if ALL needed constraints pass. Otherwise show a truthful `CONNECT_REQUIRES_REPAIR` diagnostic and do not paint an overlap plate as proof.

## 6. World-aware route planner / painting (future)

Work with route design intents and authoritatively provided geometry:

1. Receive exclusion polygons, buildable/occupancy masks, road corridors, shoreline/portal constraints and POI anchors **from current WorldBuilder/Surface Truth**, not from a duplicate editor terrain model.
2. Stroke samples → simplified guided graph with endpoints/waypoints and goal constraints.
3. Run corridor/clearance suggestions with optional human handles and multiple candidates; use A* or constrained path planning to avoid obstacles, not blindly deform meshes.
4. Pass routes to the existing Track Core fit solver; if feasibility fails, return why (radius, width, vertical clearance, no valid connector, poor support); never auto-present unsupported paths as drivable.
5. WorldBuilder reconciles cut/fill, bridges, tunnel mouths, supports, shoreline boundaries, terrain edits and persisted world IDs.
6. Remain reversible/editable: raw stroke + semantic route + compiled hash; recompile only affected segments.

Cross-island extra laps, coastline attractions and clouds hiding secret destinations belong as **user-authored POI and scene/world-access semantics** — not as automatically invented new KFB lore or simulated secret islands.

## 7. Stop gates and reuse logic

- Source-visible isolated module before assembly; GLB loaded alone is not donor proof.
- No R4 Island runtime rebuild or silent geometry write: R4 stays STOPPED/NO MVP.
- Current RKit Gate1b is `ZUR ABNAHME`, not canonical PASS.
- Only named productive owner may integrate after Georg approves a bounded editor-intent step.
- Bundle is a local handover and reference implementation; GitHub/Stage/Site/Live remain untouched.

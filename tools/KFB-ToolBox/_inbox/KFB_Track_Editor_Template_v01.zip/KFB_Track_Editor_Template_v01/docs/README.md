# KFB Track Intent Workbench · Template 0.1

**2026-10-09 · Offline Handover für Coworker · SOURCE/CONCEPT PROTOTYPE · KEIN implementierter KFB Editor.**

## Direkt ausprobieren

1. ZIP entpacken.
2. Im entpackten Ordner auf macOS/Linux ein Terminal öffnen und `python3 -m http.server 8765` ausführen (oder einen anderen lokalen HTTP-Server verwenden). Der Browser muss ES-Module per HTTP laden; `file://` ist nicht verlässlich.
3. `http://localhost:8765/` öffnen. **Nur lokale Entwicklungsansicht, keine KFB Stage/Site-Abnahme.**
4. Links Parameter einstellen und auf **Gerade / Kurve / S-Kurve / Rampe / Brücke / Tunnel / Looping** klicken. Der Abschnitt wächst ab dem aktiven Socket.
5. Für einen Nebenweg einen früheren Kreis/Socket anklicken und weitere Module hinzufügen. Für gezogene Strecken **Zeichnen** wählen. Für die Verbindung zweier bestehender Sockets **Verbinden** wählen und den Ziel-Socket anklicken.
6. **Export JSON** für das neutrale `TrackIntent`-Dokument. **Import JSON** lädt die Entwurfsdatei zurück. **Plan als SVG** exportiert die schematische Draufsicht.

Die Startansicht ist eine **frei erfundene geometrische Demo**, kein KFB-Kanon und keine reale Insel-/OSM-Geometrie. Alle UI-Farben sind ein neutrales technisches Planungsdesign, **kein KFB Clay / Joyride Golden**.

## Was jetzt echt funktioniert

- Parametrisches Aneinanderhängen gerader, kreisförmiger und S-förmiger 2D-Mittellinien, plus Höhenwerte.
- Relative Sockets (Position, Tangentenrichtung, Höhe), Auswahl alter Sockets und daraus grafische Abzweige.
- Beim Modulbau Endpunkt-Snap innerhalb 10 Einheiten bei maximal 0,55 rad Richtungstoleranz.
- Zeichnen per Pointer; Ramer–Douglas–Peucker-Vereinfachung + Chaikin-Smoothing, Endpunkt-Snap bis 16 Einheiten; Stroke-Rohdaten im Export.
- Socket-zu-Socket-Verbindung mit Hermite-**Preview** (nicht Track-Core-zertifiziert).
- Live-Auswertung: Knoten, Abschnitte, Verzweigungen, freie Enden, einfache Warnungen, Höhenprofil-Werte im JSON.
- Undo, Beispieldatei, leeres Dokument, JSON-Export/Import, SVG-Draufsicht.
- Kernfunktionen ohne externe JS-Abhängigkeiten (`core.mjs`) und Node-Testscript.

## Was ausdrücklich **nicht** funktioniert

- Kein echter Track-Core-Aufruf (kein `compileRecipe`, `compileGraph`, `runGraphChecks`), kein RouteRecipe-konformer Export.
- Keine Clothoiden/Fahrdynamik; keine nachgewiesenen C1/C2-Tangenten-/Krümmungs-/Bank-/Höhenübergänge.
- Kein fertiger kreuzungsfähiger Mesh-Join, kein echtes T/Y/X, kein Pit-System, kein Looping-/Spiral-/Wallride-Solver. Brücke, Tunnel, Looping sind als 2D-Markierung und semantischer **REQUEST** gespeichert.
- Kein Gelände-Fit, Cut/Fill, Inselkontakt, WorldObject-Zuordnung, kein freiflächenbewusster Autolayout-/Avoidance-Solver.
- Keine verbindliche Spur-Richtungslogik; `lanes` ist nur ein Wunschwert. Keine Fahrphysik, Snap-Norm nach RKIT-Realdefinition, Kollisionsprüfung, GLB/Blender-Ausgabe, Speicherung im KFB Owner, GPT Site, Stage oder Live.
- Die Breite ist ein Editier-Demo-Regler und passt nicht automatisch in K2; das optionale **RACE_W** ist bisher eine nicht autorisierte Richtungsentscheidung und wird nicht von diesem Template implementiert.

## Paketinhalt

| Pfad | Verwendung |
|---|---|
| `index.html`, `styles.css`, `app.mjs` | editierbare reine Browser-Oberfläche mit SVG-Canvas |
| `core.mjs` | reine Intent-Geometrie, Socket-Graph, heuristischer Audit, JSON-Validator |
| `data/example-intent.json` | austauschbare Beispieldatei zum Importieren |
| `docs/COWORKER_HANDOVER.md` | ausführbarer Folgeauftrag und Abnahmegrenzen |
| `docs/CONTRACT_AND_MAPPING.md` | Mapping zu Track Core/RKit R3 und Datenfluss |
| `docs/UX_ROADMAP.md` | Prioritäten für „Strecke zeichnen“ und intelligente Terrain-Planung |
| `docs/MODULE_CATALOG.json` | design-only Modul- und Socket-Fähigkeitsmatrix |
| `docs/ACCEPTANCE_CHECKLIST.md` | echte Prototyp-Akzeptanz versus Produktionsgates |
| `tests/core.test.mjs` | Node `node tests/core.test.mjs` |
| `evidence/preview.png` | Screenshot aus isolierter Browser-Injection-Prüfung (kein normaler localhost-Seitenaufruf) |
| `evidence/TEST_REPORT.md` | genaue Testzahlen und Grenzen der Laufzeitprüfung |

## Sicherheits- und Integrationsgrenze

Dies ist absichtlich ein **übertragbarer Vorschlag/Template**, keine neue Produktionsautorität, kein zweiter Runtime-Owner. Coworker soll den Code als Referenz **nicht blind integrieren**. Vor produktiver Arbeit current GitHub branches, private Race Track Core Owner, K2 Scale und die realen RKit-R3-Assembly-Artefakte lesen.

**Kein GitHub-Write in diesem Chat.** Die ZIP darf zunächst lokal durch Coworker analysiert werden. Eine spätere technische Integration benötigt eine eigenständige Freigabe innerhalb des richtigen Owners und der aktuell geltenden Stop-/Gate-Regeln.

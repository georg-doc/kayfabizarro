# Coworker Handover · KFB Track Editor Template

**Use this as an independent local ZIP/research donor. No GitHub write is requested by the ZIP delivery.**

## Proposed bounded downstream outcome

**Outcome:** Reuse this browser TrackIntent workbench as an interaction proof and convert its small `TrackIntent` DTO into a typed, source-pinned **adapter specification** for the EXISTING KFB Track Core, without touching/duplicating the existing runtime. A new editor owner is NOT created.

**Current receiving architecture:**
- `georg-doc/kayfabizarro` public RKit R3 Blender construction lane for visuals/asset family verification (branch `blender/rkit-r3-p1-junction-profiles-2026-10-08`; Gate1b Return in package sources).
- `georg-doc/KFB-Stunt-Car-Race` private Race Track Core canonical owner, with historical RKIT-01…11 candidates.
- KFB WorldBuilder/Surface Truth is terrain owner; Joyride/KFB production look is visual owner.
- Island MVP R4 explicitly STOPPED / NO MVP, independent of this ZIP.

## Coworker read-first

1. ZIP `docs/README.md` + start `index.html` via local HTTP server, test click/draw/export/import.
2. ZIP `docs/CONTRACT_AND_MAPPING.md`, `docs/UX_ROADMAP.md`, `docs/ACCEPTANCE_CHECKLIST.md`.
3. Current repo `skills/chat/START_HERE.md`, `skills/chat/CHAT_GITHUB_KFB_STAGE_WORKFLOW.md`, `skills/chat/FRESH_CHAT_SLICE_PROTOCOL.md`.
4. Current `skills/chat/KFB_OPEN_WORLD_ROAD_TRACK_CORE_CANON_2026-10-07.md` and RKit R3 `BLENDER_MCP_FULL_BRIEF.md`.
5. Current branch `production_gate1b/docs/RETURN_GATE1B.md`, `KFB_PROFILE_FAMILIES_v014_K2.md`, RKit isolated donor evidence and script contracts.
6. Exact current receiving Race branch/ref and Track Core exports — not only pinned public `track-core.v012.mjs`.

## Do first, do not fan out

A. **Verify current owner & capability census**, including current RKit R3 status. Avoid silently upgrading from v0.12 assumptions to v0.14 and avoid declaring Gate1b production PASS.

B. **Preserve a working pure-editor reference**. Keep the ZIP runnable. Exercise its graph and JSON tests. No generic new engine, no new 3D geometry renderer, no branding replacement.

C. **Specify the narrow adapter** mapping a single saved intent fixture to real Track Core graph/RouteRecipe operations, using the actual current exports and profile/scale classes. Any missing operation returns a typed `UNSUPPORTED_BY_CORE` result. If the private Race source is unavailable, return a concrete source/access blocker; do not pretend an accepted connector exists.

D. **One meaningful gate**: a round-trip of a straight→curve→branch fixture through the existing Track Core with true resolved frames and explicitly reported unsupported junctions, or an honest executable adapter test specification if access is unavailable. No fake green labels, no geometry-fallback plates.

## Non-negotiable separation

This template is `UI INTENT`; the current Track Core is `GEOMETRY + SOCKET TRUTH`; Blender RKit is `SOURCE-BACKED PHYSICAL MODULES`; Joyride is visual style; Surface Truth owns terrain; Race owns dynamics.

Looping/ramp/fork in the template are requests. No rollout for alternative islands/worlds, bridge geometry, new AI locations or Cloudflare URL is authorized by this ZIP.

## Deliverables of a separately authorized Coworker slice

- `ADAPTER_CENSUS.md`: exact current owner/branch/head, exports, supported/unsupported mappings, K2 scale findings.
- `TRACK_INTENT_MAPPING.json` or typed adapter code under **existing owning repository**, only after explicit branch authorization.
- one real fixture and test evidence; source-isolated module design if a visual physical asset is adopted.
- `RETURN.md`: actual tests counts, unresolved, one gate; no auto-merge, no Stage unless later explicitly demanded.

### Pasteable Coworker task

> Read the ZIP `docs/COWORKER_HANDOVER.md` and `docs/CONTRACT_AND_MAPPING.md`, then the current GitHub router/workflow and existing RKIT R3 Gate1b/Track Core source. Run the enclosed browser editor and core tests. Treat it as a **read-only, local authoring interaction donor**. Make a source-verified mapping from `kfb.track-intent.template/0.1` to the **existing** Track Core recipe/graph API, noting K2/width/profile mismatches, unimplemented T-junctions, unsupported loop/bridge/terrain, and unknown private-owner differences. Do not write to GitHub, duplicate Road/Track core, design new source assets, merge, or promote Stage/Live without a separate go-ahead. Return one compact practical integration plan and evidence of the inspected current source, ending with one next gate.

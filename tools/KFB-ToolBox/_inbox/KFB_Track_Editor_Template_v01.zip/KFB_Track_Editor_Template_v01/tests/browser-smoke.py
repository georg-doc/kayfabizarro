"""Playwright QA: same HTML/CSS/JS in about:blank, because environment blocks localhost/file URL navigation.
This is NOT an acceptance test of external deployment or URL loading.
"""
from pathlib import Path
from playwright.sync_api import sync_playwright
import re

root=Path(__file__).resolve().parents[1]
html=(root/'index.html').read_text()
html=re.sub(r'<link rel="stylesheet" href="styles.css">','',html)
html=re.sub(r'<script type="module" src="app.mjs"></script>','',html)
css=(root/'styles.css').read_text()
core=(root/'core.mjs').read_text().replace('export const ','const ').replace('export function ','function ')
app=(root/'app.mjs').read_text()
app=re.sub(r'^import \{[^}]+\} from [^;]+;','',app,count=1)
assert 'from \'./core.mjs\'' not in app

with sync_playwright() as p:
    browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium', args=['--no-sandbox','--disable-gpu'])
    page=browser.new_page(viewport={'width':1640,'height':1000},device_scale_factor=1)
    errors=[]
    page.on('pageerror',lambda e:errors.append(str(e)))
    page.set_content(html,wait_until='domcontentloaded')
    page.add_style_tag(content=css)
    page.add_script_tag(type='module',content=core+'\n'+app)
    page.wait_for_function("document.querySelector('#edgeCount').textContent !== '0'",timeout=8000)
    assert page.locator('#edgeCount').inner_text()=='6'
    assert page.locator('#branchCount').inner_text()=='1'
    print('PASS browser demo initial 6 segments / 1 branch',flush=True)
    page.screenshot(path=str(root/'evidence'/'preview.png'),full_page=True)
    page.locator('[data-module="straight"]').click()
    assert page.locator('#edgeCount').inner_text()=='7'
    print('PASS module append 6 -> 7',flush=True)
    page.locator('#undo').click()
    assert page.locator('#edgeCount').inner_text()=='6'
    print('PASS undo 7 -> 6',flush=True)
    page.locator('[data-mode="select"]').click()
    node=page.locator('#nodes .sock').first
    initial_socket=page.locator('#socketId').inner_text()
    node.evaluate("e=>e.dispatchEvent(new MouseEvent('click',{bubbles:true}))")
    assert page.locator('#socketId').inner_text() != initial_socket
    print('PASS socket selection changed active socket',flush=True)
    page.locator('[data-mode="connect"]').click()
    page.locator('#nodes .sock').last.evaluate("e=>e.dispatchEvent(new MouseEvent('click',{bubbles:true}))")
    assert page.locator('#edgeCount').inner_text()=='7'
    page.locator('#undo').click()
    assert page.locator('#edgeCount').inner_text()=='6'
    print('PASS tentative socket connection and undo',flush=True)
    page.locator('[data-mode="sketch"]').click()
    box=page.locator('#scene').bounding_box()
    origin={'x':box['x']+200,'y':box['y']+200}
    page.mouse.move(origin['x'],origin['y']);page.mouse.down()
    for i in range(1,10):page.mouse.move(origin['x']+i*12,origin['y']+i*4,steps=2)
    page.mouse.up()
    assert page.locator('#edgeCount').inner_text()=='7'
    print('PASS hand-drawn gesture creates segment',flush=True)
    # Auto-confirm needs to be registered before click in Playwright.
    page.on('dialog',lambda d:d.accept())
    page.locator('#reset').click()
    assert page.locator('#edgeCount').inner_text()=='0'
    page.locator('#scene').click(position={'x':150,'y':130})
    assert page.locator('#nodeCount').inner_text()=='1'
    print('PASS reset and new placement',flush=True)
    page.locator('#fileInput').set_input_files(str(root/'data'/'example-intent.json'))
    assert page.locator('#edgeCount').inner_text()=='6'
    print('PASS JSON file import restores 6 edges',flush=True)
    with page.expect_download(timeout=4000) as d:
        page.locator('#save').click()
    assert d.value.suggested_filename=='kfb-track-intent.json'
    print('PASS JSON download starts with correct file name',flush=True)
    assert not errors, f'JavaScript exceptions: {errors}'
    print('PASS browser JS error count 0',flush=True)
    browser.close()

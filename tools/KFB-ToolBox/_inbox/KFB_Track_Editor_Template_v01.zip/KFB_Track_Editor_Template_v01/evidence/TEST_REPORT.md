# KFB Track Intent Editor Template v0.1 · Test Report

Date: 2026-10-09. Mode: local read-only ZIP creation. GitHub writes: 0. Stage/Site deployments: 0.

## Pure core · 18/18 PASS

Command: `node tests/core.test.mjs` (Node v22.16.0). Confirmed tests cover new document, initial socket, straight, right/left arcs, S heading, grade height, branch graph, connector, drawn-stroke provenance, stroke socket snap, preset demo, JSON roundtrip, invalid socket refs, malicious node IDs, small-radius warning, duplicate connection rejection and repeat-start rejection.

## Browser / UI · 10/10 steps PASS; 0 JS errors

Command: `python tests/browser-smoke.py` (Playwright + local Chromium 144). The runner loads the **exact** HTML/CSS/JavaScript file contents by injecting the module scripts into an `about:blank` page. It does so because this environment's browser navigation to `localhost` and `file://` returned `ERR_BLOCKED_BY_ADMINISTRATOR`. The JS module `export` and `import` statements are replaced with equivalent inlined declarations only within the browser test harness. This is not a proof of normal web server module routing or publication.

Observed checks:

1. Initial example shows six segments and one branch.
2. Append module: six → seven.
3. Undo: seven → six.
4. Socket selection changes active socket.
5. Tentative socket connection creates a segment and Undo removes it.
6. Pointer drawing creates one edge.
7. Clear and place new start socket succeeds.
8. Import JSON fixture restores six edges.
9. Export JSON starts a download with expected filename.
10. No uncaught JavaScript errors.

Screenshot: `preview.png`, captured from the injected-browser harness before edits. This is **UI evidence for the local prototype only**, not URL/public-acceptance evidence.

## Not tested / not claimed

- Normal `http://localhost` navigation in this host: blocked by environment policy. Coworker should verify ordinary local HTTP module loading.
- Three.js/Blender/RKit GLB data paths: none used.
- Track Core compilation/geometry/physics/terrain tests: 0.
- Production source visuals / KFB look acceptance: 0.
- Real Scene/World graph and K2 profile scale: not integrated.
- Public Stage/Site: 0.

**One next gate**: Coworker run local HTTP smoke test of the ZIP and read verified current Track Core for a narrow IntentAdapter mapping, without integration writes until separately authorized.

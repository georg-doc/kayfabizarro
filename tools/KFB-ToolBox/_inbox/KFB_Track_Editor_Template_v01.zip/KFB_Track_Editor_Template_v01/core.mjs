/** KFB Track Intent editor prototype. Planning geometry only; NOT Track Core / mesh / physics. */
export const FORMAT = 'kfb.track-intent.template/0.1';
export const MODULES = Object.freeze({
  straight: {label:'Gerade', note:'Geradliniger Abschnitt; socket-to-socket intent'},
  left: {label:'Kurve links', note:'Kreisbogen in der Draufsicht, nicht Clothoid'},
  right: {label:'Kurve rechts', note:'Kreisbogen in der Draufsicht, nicht Clothoid'},
  s: {label:'S-Kurve', note:'Gegenläufige Bögen; Übergangs-Check fehlt'},
  ramp: {label:'Rampe', note:'Linearisiertes Höhen-Intent; Crest/Dip erforderlich'},
  bridge: {label:'Brücke', note:'Brückenanfrage; keine Widerlager/Supports'},
  tunnel: {label:'Tunnel', note:'Tunnelanfrage; kein Gelände/Aushub'},
  loop: {label:'Looping', note:'Symbolischer Stunt-Marker; kein 3D Loop erzeugt'},
  connector: {label:'Verbindung', note:'Hermite-Ziellinie; braucht Track-Core CONNECT-Solve'},
  sketch: {label:'Gezeichnet', note:'Geglättete Stroke-Absicht; kein verbindlicher Fit'},
});
const RAD=Math.PI/180;
const round=n=>Math.round(n*1000)/1000;
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
export const distance=(a,b)=>Math.hypot(a.x-b.x,a.z-b.z);
export const normalizeAngle=a=>Math.atan2(Math.sin(a),Math.cos(a));
export function emptyIntent(){return {format:FORMAT,mode:'DRAFT_INTENT_ONLY',coordinateConvention:'plan-xz; elevation-y; +x east; +z south; heading radians clockwise from +x',nodes:[],edges:[],activeSocketId:null,seq:1};}
function id(state,kind){return `${kind}${state.seq++}`}
export function addStart(state,x=140,z=330,heading=0,y=0){
  if(state.nodes.length) throw Error('A start already exists; select a node to branch.');
  const n={id:id(state,'n'),x:round(x),z:round(z),y:round(y),heading:round(heading),kind:'anchor'};
  state.nodes.push(n);state.activeSocketId=n.id;return n;
}
export function nodeById(state,nid){return state.nodes.find(n=>n.id===nid)}
export function segmentSamples(from,kind,{length=85,radius=55,angle=65,grade=0}={}){
  if(!Number.isFinite(length)||length<10||length>500)throw Error('Segment length must be between 10 and 500.');
  if(!Number.isFinite(radius)||radius<5) throw Error('Radius must be at least 5.');
  if(!Number.isFinite(grade)||Math.abs(grade)>35) throw Error('Grade outside demonstration limits.');
  const points=[];let h=from.heading,px=from.x,pz=from.z,py=from.y;
  const step=(len,curvature)=>{const steps=Math.max(4,Math.ceil(len/3));const dl=len/steps;for(let i=0;i<steps;i++){
    const mid=h+curvature*dl/2;
    px+=Math.cos(mid)*dl;pz+=Math.sin(mid)*dl;py+=grade/100*dl;h+=curvature*dl;
    points.push({x:round(px),z:round(pz),y:round(py)});
  }};
  points.push({x:round(px),z:round(pz),y:round(py)});
  const a=clamp(angle,15,145)*RAD;
  if(kind==='left'||kind==='right')step(radius*a,(kind==='left'?-1:1)/radius);
  else if(kind==='s'){step(radius*a*.72,1/radius);step(radius*a*.72,-1/radius)}
  else step(length,0);
  return {points,heading:round(normalizeAngle(h))};
}
function nearCompatibleEnd(state,end,heading,sourceId,tolerance=10){
  return state.nodes.find(n=>n.id!==sourceId&&distance(n,end)<=tolerance&&Math.abs(normalizeAngle(n.heading-heading))<=0.55)||null;
}
export function addModule(state,kind,opt={}){
  if(!MODULES[kind]||kind==='sketch'||kind==='connector')throw Error('Unknown module');
  const from=nodeById(state,state.activeSocketId);if(!from)throw Error('Choose a socket or add a start first.');
  const params={length:clamp(Number(opt.length)||80,10,500),radius:clamp(Number(opt.radius)||55,5,400),angle:clamp(Number(opt.angle)||65,15,145),grade:Number(opt.grade)||0,width:Number(opt.width)||14.4,lanes:Math.round(Number(opt.lanes)||2),profile:opt.profile||'TRACK'};
  if(params.width<=0||params.lanes<1||params.lanes>8)throw Error('Invalid width/lanes');
  const result=segmentSamples(from,kind,params),last=result.points.at(-1);
  const snap=nearCompatibleEnd(state,last,result.heading,from.id);
  const end=snap||{id:id(state,'n'),...last,heading:result.heading,kind:'socket'};
  if(!snap)state.nodes.push(end);else result.points[result.points.length-1]={x:end.x,z:end.z,y:end.y};
  const edge={id:id(state,'e'),from:from.id,to:end.id,kind,params,samples:result.points,semantic:kind==='loop'?'STUNT_LOOP_REQUEST':kind==='bridge'?'BRIDGE_REQUEST':kind==='tunnel'?'TUNNEL_REQUEST':kind==='ramp'?'GRADE_REQUEST':'ROAD_SEGMENT_INTENT',status:'UNCOMPILED'};
  state.edges.push(edge);state.activeSocketId=end.id;return edge;
}
function hermite(a,b){
  const d=distance(a,b);const len=clamp(d*0.6,15,160);
  const m0={x:Math.cos(a.heading)*len,z:Math.sin(a.heading)*len};const m1={x:Math.cos(b.heading)*len,z:Math.sin(b.heading)*len};
  const result=[];for(let i=0;i<=Math.max(12,Math.ceil(d/3));i++){
    const t=i/Math.max(12,Math.ceil(d/3)),t2=t*t,t3=t2*t;
    const h0=2*t3-3*t2+1,h1=t3-2*t2+t,h2=-2*t3+3*t2,h3=t3-t2;
    result.push({x:round(h0*a.x+h1*m0.x+h2*b.x+h3*m1.x),z:round(h0*a.z+h1*m0.z+h2*b.z+h3*m1.z),y:round(a.y+(b.y-a.y)*t)});
  }return result;
}
export function connectSockets(state,toId,{width=14.4,lanes=2,profile='TRACK'}={}){
  const from=nodeById(state,state.activeSocketId),to=nodeById(state,toId);
  if(!from||!to||from.id===to.id)throw Error('Choose two different existing sockets');
  if(state.edges.some(e=>e.from===from.id&&e.to===to.id))throw Error('Connection already exists');
  const samples=hermite(from,to),d=distance(from,to),grade=d>0?100*(to.y-from.y)/d:0;
  const edge={id:id(state,'e'),from:from.id,to:to.id,kind:'connector',params:{length:round(d),radius:null,grade:round(grade),width:Number(width),lanes:Number(lanes),profile},samples,semantic:'CONNECT_REQUEST',status:'UNCOMPILED'};
  state.edges.push(edge);state.activeSocketId=to.id;return edge;
}
function perpendicularDistance(p,a,b){const dx=b.x-a.x,dz=b.z-a.z,t=clamp(((p.x-a.x)*dx+(p.z-a.z)*dz)/(dx*dx+dz*dz||1),0,1);return Math.hypot(p.x-a.x-t*dx,p.z-a.z-t*dz)}
export function simplify(points,epsilon=3){if(points.length<3)return [...points];let max=0,index=0;for(let i=1;i<points.length-1;i++){let d=perpendicularDistance(points[i],points[0],points.at(-1));if(d>max){max=d;index=i;}}if(max<=epsilon)return [points[0],points.at(-1)];return [...simplify(points.slice(0,index+1),epsilon).slice(0,-1),...simplify(points.slice(index),epsilon)]}
function chaikin(points){const result=[points[0]];for(let i=0;i<points.length-1;i++){const a=points[i],b=points[i+1];result.push({x:0.75*a.x+0.25*b.x,z:0.75*a.z+0.25*b.z},{x:0.25*a.x+0.75*b.x,z:0.25*a.z+0.75*b.z})}result.push(points.at(-1));return result}
function heading(a,b){return Math.atan2(b.z-a.z,b.x-a.x)}
export function addSketch(state,raw,{width=14.4,lanes=2,profile='TRACK',snapDistance=16}={}){
  if(!Array.isArray(raw)||raw.length<2||raw.some(p=>!Number.isFinite(p.x)||!Number.isFinite(p.z)))throw Error('Draw at least 2 finite points');
  const simplified=simplify(raw,3);const points=chaikin(chaikin(simplified));
  const start=points[0],end=points.at(-1);
  let a=state.nodes.filter(n=>distance(n,start)<=snapDistance).sort((x,y)=>distance(x,start)-distance(y,start))[0];
  if(!a){a={id:id(state,'n'),x:round(start.x),z:round(start.z),y:0,heading:round(heading(points[0],points[1])),kind:'sketchAnchor'};state.nodes.push(a)}
  let b=state.nodes.filter(n=>n.id!==a.id&&distance(n,end)<=snapDistance).sort((x,y)=>distance(x,end)-distance(y,end))[0];
  if(!b){b={id:id(state,'n'),x:round(end.x),z:round(end.z),y:a.y,heading:round(heading(points.at(-2),points.at(-1))),kind:'sketchAnchor'};state.nodes.push(b)}
  points[0]={x:a.x,z:a.z,y:a.y};points[points.length-1]={x:b.x,z:b.z,y:b.y};
  const p=points.map((v,i)=>({x:round(v.x),z:round(v.z),y:round(a.y+(b.y-a.y)*i/(points.length-1))}));
  const edge={id:id(state,'e'),from:a.id,to:b.id,kind:'sketch',params:{width:Number(width),lanes:Number(lanes),profile,grade:0},samples:p,semantic:'SKETCH_FIT_REQUEST',status:'UNCOMPILED',sourceStroke:raw.map(v=>({x:round(v.x),z:round(v.z)}))};
  state.edges.push(edge);state.activeSocketId=b.id;return edge;
}
function segIntersection(a,b,c,d){const cross=(u,v)=>u.x*v.z-u.z*v.x;const r={x:b.x-a.x,z:b.z-a.z},s={x:d.x-c.x,z:d.z-c.z};const den=cross(r,s);if(Math.abs(den)<1e-9)return false;const qp={x:c.x-a.x,z:c.z-a.z};const t=cross(qp,s)/den,u=cross(qp,r)/den;return t>0.02&&t<0.98&&u>0.02&&u<0.98;}
export function auditIntent(state){
  const warnings=[];
  for(const e of state.edges){
    if(!nodeById(state,e.from)||!nodeById(state,e.to))warnings.push(`${e.id}: Socket-Referenz ungültig`);
    if((e.params.grade||0)>10||(e.params.grade||0)<-10)warnings.push(`${e.id}: Steigung >10 %; Fahrbarkeit unbewiesen`);
    if(['left','right','s'].includes(e.kind)&&e.params.radius<e.params.width/2+4.32)warnings.push(`${e.id}: Innenprofil könnte falten (Radius < Breite/2 + 4,32)`);
    if(['loop','bridge','tunnel'].includes(e.kind))warnings.push(`${e.id}: ${e.kind} nur symbolisch; 3D/Contact/Surface Truth ungeprüft`);
    if(e.kind==='sketch'||e.kind==='connector')warnings.push(`${e.id}: Kurven-Fit durch Track Core erforderlich`);
  }
  let crossings=0;
  for(let i=0;i<state.edges.length;i++)for(let j=i+1;j<state.edges.length;j++){
    const A=state.edges[i],B=state.edges[j]; if(A.from===B.from||A.from===B.to||A.to===B.from||A.to===B.to)continue;
    let hit=false;for(let k=1;k<A.samples.length&&!hit;k++)for(let m=1;m<B.samples.length;m++){
      if(segIntersection(A.samples[k-1],A.samples[k],B.samples[m-1],B.samples[m])){const y1=(A.samples[k-1].y+A.samples[k].y)/2,y2=(B.samples[m-1].y+B.samples[m].y)/2;if(Math.abs(y1-y2)<7)hit=true;break;}
    }if(hit)crossings++;
  }
  if(crossings)warnings.push(`${crossings} potenzielle niveaugleiche Kreuzung(en) ohne Knoten (Nähe/Geometrie approximiert)`);
  const degree=new Map(state.nodes.map(n=>[n.id,0]));for(const e of state.edges){degree.set(e.from,(degree.get(e.from)||0)+1);degree.set(e.to,(degree.get(e.to)||0)+1)}
  const branches=[...degree.values()].filter(n=>n>=3).length,ends=[...degree.values()].filter(n=>n===1).length;
  return {nodes:state.nodes.length,segments:state.edges.length,branches,openEnds:ends,warnings,validForExport:state.edges.length>0};
}
export function importIntent(data){
  if(!data||data.format!==FORMAT||!Array.isArray(data.nodes)||!Array.isArray(data.edges)||data.nodes.length>10000||data.edges.length>10000)throw Error('Unsupported track-intent format');
  const copy=JSON.parse(JSON.stringify(data));const ids=new Set();
  for(const n of copy.nodes){if(typeof n.id!=='string'||!(/^[A-Za-z][A-Za-z0-9_-]{0,63}$/).test(n.id)||ids.has(n.id)||![n.x,n.z,n.y,n.heading].every(Number.isFinite))throw Error('Invalid node');ids.add(n.id)}
  for(const e of copy.edges){if(!ids.has(e.from)||!ids.has(e.to)||typeof e.id!=='string'||!(/^[A-Za-z][A-Za-z0-9_-]{0,63}$/).test(e.id)||!MODULES[e.kind]||!Array.isArray(e.samples)||e.samples.length<2||e.samples.length>15000||e.samples.some(p=>![p.x,p.z,p.y].every(Number.isFinite)))throw Error('Invalid edge');}
  if(copy.activeSocketId!==null&&!ids.has(copy.activeSocketId))throw Error('Invalid active socket');
  if(!Number.isSafeInteger(copy.seq)||copy.seq<1)throw Error('Invalid sequence');
  return copy;
}
export function makeDemo(){
  const s=emptyIntent();addStart(s,100,435,-0.15);
  const common={width:14.4,lanes:2,profile:'TRACK'};
  addModule(s,'straight',{...common,length:120});
  addModule(s,'right',{...common,radius:78,angle:60});
  const junction=s.activeSocketId;
  addModule(s,'straight',{...common,length:120});
  addModule(s,'loop',{...common,length:90});
  s.activeSocketId=junction;
  addModule(s,'left',{...common,radius:80,angle:60});
  addModule(s,'bridge',{...common,length:155,grade:4});
  return s;
}

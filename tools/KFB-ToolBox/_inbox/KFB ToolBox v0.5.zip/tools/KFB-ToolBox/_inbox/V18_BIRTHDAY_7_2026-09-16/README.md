# Intake · V18_BIRTHDAY_7_2026-09-16

Status: RECEIVED → REVIEWED → **ACCEPTED as PROMOTION DONOR** (nicht als ToolBox-SSOT).

- Original: `original/KFB FrankenStein Studio -7-.zip` (Klammern im Ablagenamen bereinigt) · 4 994 864 B · sha256 `06bc8afed3d5d1f1731d466d1241d64e0c5933c8beb38d888fe69dbe34c9a117` · Quelle Repo-Rohpfad `tools/KFB-ToolBox/_inbox/KFB FrankenStein Studio (7).zip` @ `79c5799afd185693f245755f19de2abb44d42452`.
- `INVENTORY.json`: 101 Einträge mit sha256; 95 Textdateien nach `unpacked/`, 6 PNG (5 Belegbilder + Kartenrückseite) nicht entpackt.
- `DIFF_WS0_vs_V18.json`: 80 gleich · 3 nur v18 · 1 geändert (v17-Blatt) · 6 nur WS0.
- Verwendet in: `../../stage-first/` (Return dort).

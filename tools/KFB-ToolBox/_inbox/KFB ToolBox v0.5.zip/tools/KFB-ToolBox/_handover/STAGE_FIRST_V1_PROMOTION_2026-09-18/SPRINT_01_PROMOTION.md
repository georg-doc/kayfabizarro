# Sprint 01 · Promotion + Browser Gate · ab 2026-09-18

**Ziel des Sprints:** ein Browser-Candidate, den Georg ohne Terminal öffnen kann, plus **ein** zusammenhängender Workflow-Durchlauf — nicht vierzehn einzeln abgehakte Häkchen.

**Nicht im Sprint:** Redesign · neue Features · Birthday · Travel-Szene · Registry · Rig-Umbau.

---

## Slice A · Asset- und Portabilitätsschluss
**Status: ZU 80 % ERLEDIGT** (siehe `ONBOARDING_FRESH_CHAT.md` §3 und `PROMOTION_MANIFEST.json`).

| Aufgabe | Status |
|---|---|
| Schriften auf festen Commit pinnen | **DONE** (34 URLs) |
| Audio-Manifest auf vorhandene GitHub-Quelle | **DONE** (nicht rekonstruiert) |
| `FrizzleBob_Yellow.gltf` auf belegte Repo-Quelle | **DONE** (Paketkopie nicht mehr geladen) |
| Restliche `main`-Laufzeit-URLs pinnen | **OFFEN** — 12 Pfade in `pet-library.v6.js`, `lab/assets.js`, `_loadBiped`, `KloRolli.js`, `recherchi-mount.v1.js`, `graft-mount.v1.js`; Liste in `PROMOTION_MANIFEST.json#openPins` |
| Ordnerstruktur + `__KFB_MODBASE` erhalten | **DONE** (nichts verschoben) |
| `three@0.160.0` unverändert | **DONE** |
| 35er Roster | **DONE** (gemessen: `roster.length === 35`) |
| `localStorage`-Keys erhalten | **DONE** (kein `clear()` im Baum) |
| Lokale `FrizzleBob_Yellow.gltf` löschen | **BRAUCHT FREIGABE** — liegt noch da, wird nicht geladen |

**Definition of Done für A:** kein `main` mehr in einer Laufzeit-URL · jede Ausnahme im Promotion-Manifest begründet · Boot im Browser ohne Konsolenfehler.

---

## Slice B · Promotion in den Owner
**Status: OFFEN** — der Schreibweg aus Claude Design nach GitHub existiert nicht (nur Lesen). Der Web Lead schiebt.

1. Zielpfad `tools/KFB-ToolBox/stage-first/` **additiv** anlegen (existiert auf `main` noch nicht).
2. Original-ZIP bleibt Paket-Provenienz; der Stunt-Race-Baum bleibt Mirror ohne Ownership.
3. `PROMOTION_MANIFEST.json` mitschieben — sie listet **jede** bewusste Abweichung vom Export.
4. Nicht überschreiben: WS0 · `kfb-rigs-embed-v3` · Studio-v18-History · Resident Atlas · World Atlas · Contracts.
5. Prüfsummen gegen `CHECKSUMS.sha256` verifizieren, **bevor** irgendetwas verändert wird.

**Definition of Done für B:** der Owner-Pfad enthält den Baum, die Prüfsummen stimmen, kein bestehender Pfad wurde angefasst.

---

## Slice C · Browser-Candidate
**Status: OFFEN**

Route-Vorschlag `/toolbox/stage-first/`. Einstieg ist `src/KFB ToolBox Stage-First v1.dc.html` — kein Build, aber **ES-Module brauchen HTTP** (`file://` scheitert an CORS). MIME-Tabelle und die restlichen Deploy-Pflichten stehen in `docs/DEPLOYMENT.md` des Exports.

**Definition of Done für C:** Georg öffnet eine URL und sieht die Bühne. Dateien-liegen-da ist kein PASS.

---

## Slice D · Functional Gate
**Status: OFFEN** — und das ist der eigentliche Blocker des Projekts.

**Ein** Durchlauf, nicht vierzehn Einzelprüfungen:
```
Boot → Actor → Face → Pose → Motion → Voice/Talk/Bubble → Stage → Save/Export → Reload → Import/Restore
```

| # | Prüfung | Stand heute |
|---|---|---|
| 1 | ein Cube Pet | NOT_TESTED (nur Boot-Figur geladen) |
| 2 | GothGirl oder anderer Rig_Medium-Zweibeiner | Laden **PASS**, Workflow NOT_TESTED |
| 3 | FrizzleBob / Graft | Laden **PASS** (18 Clips), Workflow NOT_TESTED |
| 4 | CapsuleCarl oder andere Sonderklasse | Laden **PASS**, Workflow NOT_TESTED |
| 5 | Actor-Wechsel ohne doppelte Eye-/Mixer-Owner | **PASS für Augen** (`assertSingleHostEyeSource` hält in vier Ladewegen, `eyePolicy.ok`); **Mixer-Eigentum NOT_TESTED** |
| 6 | Face-Regler mit sichtbarer Wirkung | NOT_TESTED |
| 7 | Pose speichern und wiederherstellen | NOT_TESTED |
| 8 | Motion Play/Stop/Rest mit echter Binding-Prüfung | NOT_TESTED · Verfahren existiert (`bindingCoverage`, `anim-audit.v1`) |
| 9 | Voice/Talk-Pfad inkl. wiedergewonnenem Audio-Manifest | NOT_TESTED · Ton in Claude nicht abnehmbar → braucht Georg oder den Web Lead |
| 10 | Resource Picker Preview → Accept → Revert | NOT_TESTED |
| 11 | Prop platzieren → transformieren → speichern → reload | NOT_TESTED |
| 12 | Profil Export → Import → sichtbar gleicher Actorzustand | NOT_TESTED |
| 13 | Desktop | **PASS** |
| 14 | ~832 px Split-Screen | NOT_TESTED |

**Reihenfolge-Vorschlag** (jede Stufe erzeugt einen Beleg, bevor die nächste beginnt): 5 → 12 → 6 → 7 → 8 → 10 → 11 → 9 → 14 → 1.
Begründung: **Zustand zuerst.** Wenn der Roundtrip (12) nicht hält, sind Pose (7) und Prop (11) nicht messbar — ein gespeicherter Zustand, der beim Laden abweicht, macht jeden späteren PASS wertlos. Das Augen-/Mixer-Eigentum (5) steht davor, weil ein doppelter Owner jede sichtbare Wirkung (6) verfälscht.

**Definition of Done für D:** jede Zeile trägt PASS mit Messwert oder `NOT_TESTED` mit Grund. Kein Häkchen aus Codeanwesenheit.

---

## Fallen in diesem Sprint
- **Roster-Indizes wandern.** Nach `id` adressieren.
- **Ton ist hier nicht abnehmbar.** #9 wird ohne Georg/Web Lead nicht PASS.
- **Vor jedem Löschen messen** (`inkform.v1` war die Lehre).
- **Belege kommen aus dem Studio**, nicht aus einem Prüfstand, der Wirte neu zusammensetzt.
- **Die 24 Cube-Pets sind nicht »der einfache Fall«** — sie haben die meisten Augenquellen.

## Return-Format
```
SOURCE | DECISION | IMPLEMENTATION | TESTED RESULT | PUBLIC DEPLOYMENT | GEORG ACCEPTANCE | OPEN | ARCHIVED HISTORY
```

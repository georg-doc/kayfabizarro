# Onboarding · KFB ToolBox Stage-First v1 · Promotion + Browser Gate
**Für einen frischen Chat. Stand 2026-09-18.** GitHub-Zustand schlägt Chat-Erinnerung.

## 1 · Wo du bist, in sechs Zeilen
- **Produkt:** Stage-First, ein Authoring-Werkzeug. Domänen `Actor · Face · Pose · Motion · Voice · Stage`.
- **Implementation Owner / SSOT:** `georg-doc/kayfabizarro/tools/KFB-ToolBox/`.
- **Der Export ist fertig und angekommen** (132 Dateien, 4,32 MB, kein Buildschritt). Er ist bewusst `EXPORT_PARTIAL` — vollständiger Source, ehrliche Testlücken.
- **Blocker ist nicht fehlender Code.** Blocker ist die **funktionale Browser-Abnahme** des Authoring-Workflows.
- **Birthday 2026 ist FAIL / OUTDATED / ARCHIVED HISTORY.** Nicht weiterbauen, nur als Provenienz lesen.
- **Kein Redesign.** Vorhandene Module übernehmen, nicht aus Dokumentation nachbauen.

## 2 · Lesereihenfolge (nicht abkürzen)
1. `tools/KFB-ToolBox/_handover/STAGE_FIRST_V1_INTAKE_2026-09-18/START_HERE.md` — der Intake-Brief, er entscheidet.
2. Im Export: `START_HERE.md` → `EXPORT_MANIFEST.json` → `FEATURE_PARITY.md` → `docs/TEST_REPORT.md` → `docs/KNOWN_ISSUES.md` → `docs/RECOVERY.md` → `docs/MODULE_MAP.md` → `docs/ASSET_MANIFEST.json`.
3. Dieses Blatt und `SPRINT_01_PROMOTION.md` daneben.

**Paket:** `tools/KFB-ToolBox/_inbox/KFB ToolBox v1-1.zip` (Blob `5943ee108609a7916bf231fec59848ef4c58f965`, Upload-Commit `eabc87255ee3da6283f9d438390454d70e9d2e55`).
**Lesbarer Mirror:** `georg-doc/KFB-Stunt-Car-Race/_inbox/KFB ToolBox v1/…` — **nur Transport, keine Ownership.**

## 3 · Was seit dem Export schon erledigt ist (nicht zweimal machen)
Im Claude-Design-Projekt »KFB ToolBox«, Baum `tools/KFB-ToolBox/stage-first/`, am 18.09. geschlossen und im Browser geprüft:

| Erledigt | Wie | Beleg |
|---|---|---|
| Schriften gepinnt | 34 `@font-face`-URLs (2 Blätter) von `main` auf Commit `eabc87255ee3da6283f9d438390454d70e9d2e55` | `document.fonts.load("16px 'Fonteys PRO'")` → 1 geladen |
| Audio-Manifest aufgelöst | `manifestUrl` zeigt auf die vorhandene GitHub-Datei (Blob `5f7b52e2666a…`), **nicht** rekonstruiert | Code gepinnt; Ton bleibt `NOT_TESTED` |
| `FrizzleBob_Yellow.gltf` korrigiert | `FB_URL` in `headgraft.v1.js` und `ears.v2.js` auf die belegte Repo-Quelle (Blob `e0a757ec…`) | Boot Graft-Driver + FrizzleBob laden fehlerfrei (18 Clips) |
| Augenquellen-Regel | Set-Vorgabe ohne googly, Wächter im Quellbaum, Halt in allen vier Ladewegen | `state.eyePolicy.ok === true` |

**Offen geblieben (mit Absicht):** die lokale Kopie `src/petstudio-v9/assets/models/FrizzleBob_Yellow.gltf` liegt noch im Baum, wird aber nicht mehr geladen. Löschkandidat — **braucht Georgs Freigabe**, nicht deine Entscheidung.

## 4 · Die zwölf Regeln, an denen dieser Bau hängt
1. **Ein Asset, das auf GitHub liegt, wird von GitHub geladen.** Keine zweite Library, keine Blob-URL, keine Kopie als neue Quelle.
2. **Laufzeit-URLs werden gepinnt**, nicht auf `main` gelassen.
3. **Der Ordnerbaum ist Teil der Abhängigkeit** (`window.__KFB_MODBASE = petstudio-v9/`). Nicht umbenennen, nicht neu ordnen, auch nicht »weil es sauberer aussieht«.
4. **Additiv promoten.** Nicht überschreiben: WS0-Baseline · `kfb-rigs-embed-v3` · Studio-v18-Donor-History · Resident Atlas · World Atlas · bestehende Contracts.
5. **35er Roster bleibt.** Kein Demo-Mini-Roster.
6. `three@0.160.0` **bleibt** in diesem Durchgang.
7. **`localStorage.clear()` ist verboten.** Keys erhalten.
8. **Owner nicht verschieben:** `kfb.pets/1` · Shared Pet Library · Registry/Librarian · Rigging/Animation · Travel/Combat/Stunt.
9. **Kein Bash-/Terminal-Auftrag an Georg.** Was gebaut werden muss, baust du.
10. **Code vorhanden ≠ PASS.** Nicht ausgeführt = `NOT_TESTED`.
11. **Progressive Disclosure statt Funktionsverlust** · eine Navigationsebene · Bühne dominant · kein Dashboard im Normalbetrieb · keine Textwände.
12. **Return immer getrennt:** `SOURCE | DECISION | IMPLEMENTATION | TESTED RESULT | PUBLIC DEPLOYMENT | GEORG ACCEPTANCE | OPEN | ARCHIVED HISTORY`.

## 5 · Die Fehler, die dieser Bau schon bezahlt hat
Lies das, bevor du etwas »aufräumst«.

- **Eine Augenquelle je Figur.** Ein Cube-Pet kann vier haben (Kenney-Schalen · `MODS.googly` · EyeRig · Originalaugen eines KayKit-Wirts). Sie mischen sich still. `SETS.animals.mods` stand seit SPRINT 10 auf `['googly','emotes']` — jeder Aufrufer ohne `mods: []` bekam ein zweites Augenpaar. Heute: Vorgabe leer, `loadOpts(face)` als einzige Aufrufform, `assertSingleHostEyeSource` nach jedem Bau. Volle Regel: `_handover/BIRTHDAY_STARTSCREEN_2026-09-15/EYE_SOURCE_RULE.md` (ARCHIVED-HISTORY-Ordner, aber **diese Regel gilt**).
- **Ein Prüfstand, der den Wirt neu zusammensetzt, ist eine zweite Wahrheit.** Ein freistehender Prüfstand baute die vier Bewohner nackt und lieferte kaputte Figuren als »Belege« — ohne Mund, ohne Textur-Wäsche, ohne Bodenhöhe, ohne Würfelflächen. **Belegt wird im Studio**, wo die Fixes liegen.
- **Vor dem Löschen messen.** `inkform.v1.js` sah aus wie ein Vorgänger und wird von `brow.v3.js` und `stache.v3.js` importiert.
- **Am richtigen Feld greifen.** Carl und Recherchi bauen ihr Gesicht selbst; das Rig heißt `handle.face.eyeRig`, nicht `handle.face.eye`. Ein Prüfstand am falschen Feld misst nichts, er behauptet.
- **Roster-Indizes sind nicht stabil.** Immer `roster.findIndex(p => p.id === '…')`.
- **Eine Zahl, ein Eigentümer.** Bühnengröße, Bodenhöhe, Augenanker werden nach dem Laden an genau einer Stelle festgeschrieben. Die Kommentare im Code nennen die Fehler, die dazu geführt haben (gecachtes GLB doppelt skaliert, Waffe verfälscht die Fußmessung, Blatt fällt unter die Platte).
- **Studio v18 ist der Donor.** Fixes, die Stage-First fehlen, kommen von dort — nicht neu gebaut.

## 6 · Die vier Bewohner-Klassen (und wo ihr Gesicht herkommt)
| Klasse | Beispiel · Roster-ID | Bauweg | Gesicht |
|---|---|---|---|
| `cube-pet` | `cat`, `bunny`, `hihi` | `pet-library.v6.js#Character.load` | Studio baut: `_buildEyeRig` + `_mountMouth` |
| `biped` | `gothgirl`, `frizzlebob`, `graft-driver` | `goth-biped.v1` / `frizzlebob.v4a` / `graft-biped.v1` | Studio baut über `faceCtx()` |
| `hanging` | `klo-rolli` | `studio-v10/KloRolli.js` | Studio baut über `eyeCtx()`/`mouthCtx()` |
| `capsule` / `htmlcube` | `capsule-carl` / `recherchi` | `carlrig-mount.v1` / `recherchi-mount.v1` | **Modul baut selbst**, Rig liegt in `handle.face.eyeRig` |

## 7 · Was du nicht tust
Kein Birthday-Rebuild · keine Travel-Szene · kein neues Pet-Schema · keine neue Registry · kein umgeschriebenes Rig-System · keine geratene Animations-Kompatibilität · kein Modul-Umbenennen · kein `localStorage.clear()` · keine doppelten GitHub-Assets · kein Source aus Screenshots, wo echter Source existiert · keine stille Beförderung von Kandidaten-Contracts zu Kanon.

# RETURN · ToolBox T1

Status: T1_PARTIAL_BLOCKED_SOURCE_EXPORT · 2026-09-14 · Fassung 2 (nach Review, siehe review_intake_2026-09-14/)
Produktionschat: Claude Design (Browser-Vorschau, kein Git-Zugriff). Git/PR/Push: über `CLAUDE_CODE_HANDOFF.md` an Claude Code delegiert.

## Identität

- sourceRepository / sourceCommit / sourceTree: `georg-doc/kayfabizarro` @ `f4171ad205f423bf7eec00def72db784fe171246`, Export-Tree `e9fbe4f2cef4d72d51b69fc7f211a735c2340ca2`; Onboarding-Stand `6ea5d439382ff1f4fce2c56161c523dbcf2a4e2c` (HEAD zum Zeitpunkt der Lektüre, 2026-09-13T22:29Z).
- workBranch / workCommit / PR: **noch nicht angelegt** — Vorschlag `toolbox/t1-site-2026-09-14`, siehe Handoff.
- aktive Authoring-Pfade je Tool: **nicht geliefert** (siehe UNRESOLVED 1). Bekannt: Studio-v16-Baum `skills/KFB PetStudio/KFB FrankenStein Studio 16/KFB-v16/`; lokaler Workspace `CLAUDE/KFB FrankenStein Lab + Models/KFB Rigging Lab v1/` (Stand vor 13.09. spät).
- Build-/Exportkommando: keines vorhanden. Die Bundles sind Claude-Design-Standalone-Exporte („Bundled Page“, Manifest mit gzip-JS + woff2). Site-Einstieg ist eine DC-Datei (`KFB ToolBox.dc.html` + `support.js`), `index.html` ist ihre Kopie.
- Vorschau-URL / Build-ID: **nicht veröffentlicht.** Zielpfad `tools/KFB-ToolBox/site/` auf dem bestehenden Kayfabizarro-Pages-Weg (Repo-Root wird serviert, vgl. Asset Librarian). Erwartete URL nach Merge: `https://<pages-host>/tools/KFB-ToolBox/site/`.
- enthält uncommittierte Arbeit: JA — alles in diesem ZIP.

## IMPLEMENTATION

**Unverändert (byte-identisch zu den Pins geprüft, Git-Blob-SHA1 nachgerechnet):**
- `site/KFB FrankenStein Studio v17 -standalone-.html` 1.853.971 B, blob 7da185ab, sha256 179a334f…
- `site/KFB Rigging Lab v1 -standalone-.html` 803.019 B, blob 720bafd3, sha256 b7b4a7ba…
- `site/KFB Animation Lab v2 -standalone-.html` 482.477 B, blob be880ee0, sha256 7b56cea9…
- `site/configs/*.json` — die sechs WIP-JSONs, unverändert aus dem Export kopiert.

**Neu:**
- `site/KFB ToolBox.dc.html` + `site/index.html` (Kopie) + `site/support.js`: Einstieg mit drei Werkzeugkacheln (Version, Autor-/WIP-Status, Boot-Befund, Bundle-Pin, Öffnen / Docs-LLM / Quelle), Config-Katalog (Schema, Rolle, Status, Bytes, Blob, Download), Platzhalterzeile für Podcast / Cartoon Creator / Card Viewer (ausdrücklich nicht T1), Build-Identität im Fuß. UI: Roboto 400/500/700 via Google Fonts + System-Fallback, 14–16 px, tabulare Zahlen, sichtbarer Fokus.
- `docs/MISSING_MODULES.md`, `docs/BUNDLE_RELATIVE_REFS.json`: exakte Modul-/Fontreferenzen der drei Bundles.
- `docs/FONT_INVENTORY.json`: 17 Fontdateien jetzt einzeln aus dem Studio-Bundle enumeriert; UI-Fundstellen im v17-Quelltext benannt.
- `TOOLBOX_MANIFEST.json`: `browserQA` je App auf `FAIL_MODULES_MISSING`, `currentReturn`, `site`-Block.
- `CHANGELOG.md`: additive Einträge.
- `_handover/TOOLBOX_V1_2026-09-14/CLAUDE_CODE_HANDOFF.md`: Auftrag für Branch/Commit/PR.

**Nicht gemacht, absichtlich:** kein Font-Pass in den Bundles (handgepatchte Bundles laut DELIVERABLES unzulässig; Georg-Entscheidung 14.09.: Font-Pass als Folgeauftrag). Keine Änderung an Travel/Combat/Stunt/Wissens-Pilli. Keine Registry-Promotion.

## TESTED RESULT

| Gate | PASS / FAIL / NOT_TESTED | Umgebung / Revision | Beobachtung | Beleg |
|---|---|---|---|---|
| Boot Studio v17 | **FAIL** | Chromium-Vorschau Claude Design, 2026-09-14, Bundle blob 7da185ab, served aus `site/` | Shell (Tabs Body/Face/Motion/Voice/Messen, Anim-Leiste) rendert; Canvas bleibt leer; `Unhandled rejection: Failed to fetch dynamically imported module …/petstudio-v9/studio-v7/pet-session.v1.js` | `evidence/boot_frankenstein-studio-v17_2026-09-14.jpg` |
| Boot Rigging v1 | **FAIL** | ebd., blob 720bafd3 | Kopfzeile, Regler (Eyes …), Kamerabuttons rendern; Fehlerbox `Failed to resolve module specifier './lab-v2/sources.js'`; Button-Label zeigt `Load\u2026` (unescaped Escape im Bundle, kosmetisch) | `evidence/boot_rigging-lab-v1_2026-09-14.jpg` |
| Boot Animation v2 | **FAIL** | ebd., blob be880ee0 | Shell rendert; `lab/assets.js failed: Failed to fetch dynamically imported module`; Warnungen `[anim-contract] fehlt`, `[pet-session] fehlt` | `evidence/boot_animation-lab-v2_2026-09-14.jpg` |
| Bundle-Identität | **PASS** | sha1/sha256 im Sandbox-Skript | drei Bundles byte-identisch zu den Manifest-Pins (Länge + Git-Blob-SHA) | dieses Dokument, Abschnitt IMPLEMENTATION |
| Graft / Carl / Mods / Talk / Clips | NOT_TESTED | — | nicht erreichbar, Module fehlen | — |
| Roundtrip / Fremdpets / Session | NOT_TESTED | — | ebd. | — |
| UI / Fontnetzwerk aus / Zoom (Einstiegsseite) | NOT_TESTED | — | Einstieg bei Vorschaubreite gesichtet; 200 %-Zoom und blockiertes Fontnetz nicht geprüft | — |
| Focus / Reload / Ressourcen | NOT_TESTED | — | — | — |
| Publikation / Build-Identität | NOT_TESTED | — | nicht deployt | — |

Historisch (nicht heute ausgeführt): Autoren-HOUSEKEEPING 13.09. meldet v17/Rigging v1 aktiv, Lab v2 aktiv; Gate V2.1 GRAFT PASS aus Lab-Workspace 12.09. Beides bezieht sich auf den Workspace mit Modulbaum, nicht auf die Standalones.

## GEORG ACCEPTANCE

Ausstehend. Entscheidungen 14.09. (Formular): Rückgabe als ZIP + Claude-Code-Handoff; Basis = unveränderte Bundles; Art-Fläche nur Wortmarke Kayfa·Bizarro; Zielpfad `tools/KFB-ToolBox/site/`; Startseite mit Config-Katalog; Erweiterungskacheln Podcast / Cartoon Creator / Card Viewer als out-of-scope-Platzhalter.

## UNRESOLVED / DEFERRED

0. **Review-Korrekturen eingearbeitet (Fassung 2):** Prüfsummen-FAIL der ersten Rückgabe (RETURN.md nach dem Hashen geändert) — jetzt letzter Schritt; Fonteys-Zählung 7 statt 8; Rigging-Fehler als Specifier-Auflösung eingeordnet, „danebenlegen genügt“ zurückgenommen; Animation-Konsolenmitschrift in evidence/console_2026-09-14.md; MASTERPLAN um Review-Eintrag ergänzt; Status übernommen.

1. **Modulbaum 13.09. fehlt (Stop-Grenze „fehlende entscheidende Originalquellen“).** Auswirkung: alle drei Tools starten nicht durch. Owner: Authoring-Workspace „KFB Rigging Lab v1“ (Claude Design). Nächster Test: Ordner gemäß `docs/MISSING_MODULES.md` neben die Bundles legen, Kaltstart wiederholen. Neun Dateien sind in keiner erreichbaren Quelle vorhanden (Liste dort).
2. **Font-Pass** (Roboto in Controls) — DEFERRED auf Folgeauftrag nach Modulbaum; muss in der editierbaren Quelle geschehen. Fundstellen: FONT_INVENTORY.json `uiUsesInV17Source`.
3. **Lab-Graft-Default** — NOT_TESTED, Bundle nicht lauffähig.
4. **Kosmetik Rigging-Bundle**: Label `Load\u2026` — Escape im Export; nur in der Quelle beheben.
5. **Pages-URL** — nach Merge durch Claude Code prüfen (HTTP 200 plus sichtbarer Inhalt, nicht Thumbnail-Fallback).

## Recovery

Letzter funktionierender Stand: Einstiegsseite `tools/KFB-ToolBox/site/KFB ToolBox.dc.html` (lokal lauffähig, Links auf Bundles/Configs/Docs). Startweg: Ordner `site/` statisch servieren, `index.html` öffnen. Nächste konkrete Handlung: (a) Authoring-Workspace liefert den Source-Export nach `review_intake_2026-09-14/TO_AUTHORING_WORKSPACE.md` (isoliert startgeprüft); (b) Claude Code sichert diesen Stand als Branch/PR gemäß `CLAUDE_CODE_HANDOFF.md`, ohne Merge und ohne die drei Tools als benutzbar zu bezeichnen; (c) Produktionschat fährt Kaltstart → Font-Pass → Gates. ZIP: `KFB_TOOLBOX_V1_RETURN_2026-09-14.zip` mit `CHECKSUMS.sha256` (alle Dateien SHA-256; die fünf Configs mit Klammern über inhaltsgleiche Kopien gehasht, Mapping in der Liste; erzeugt als letzter Schritt); keine Font-Binaries, keine Secrets. Ziel-Consumer: keiner freigegeben.

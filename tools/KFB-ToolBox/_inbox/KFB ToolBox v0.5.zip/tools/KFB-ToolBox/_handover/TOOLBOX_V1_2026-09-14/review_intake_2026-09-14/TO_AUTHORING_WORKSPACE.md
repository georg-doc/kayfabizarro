# Auftrag · ToolBox-Quellen vollständig exportieren

**An den ursprünglichen Claude-Design-Workspace, in dem Studio v17, Rigging Lab v1 und Animation Lab v2 zuletzt tatsächlich liefen. Nicht an einen alten gleichnamigen lokalen Rigging-Ordner.**

Der ToolBox-Publisher hat den Export geprüft. Die drei gelieferten Standalone-HTMLs enthalten ihre UI, aber nicht die vollständigen KFB-Modulbäume. Sie starten außerhalb des Authoring-Workspaces nicht durch. Bitte **nur diese Exportlücke schließen**, keine neuen Funktionen und keine Rekonstruktion der Module aus Beschreibungen.

## Auftrag

1. Sichere den tatsächlich funktionierenden gemeinsamen Workspace-Stand. Nenne dessen Projekt-/Seitenidentität und die drei editierbaren `.dc.html`-Einstiege. Nicht auf ältere Repo-Kopien zurückfallen, ohne den Unterschied ausdrücklich zu dokumentieren.
2. Liefere ein einziges geordnetes Source-ZIP mit den drei Einstiegen, ihren **vollständigen lokalen Laufzeitabhängigkeiten** und den Configs. Dazu gehören insbesondere `lab/`, `lab-v2/`, `lab-v4/`, `lab-v6/`, `frizzlegraft-v1/` und `petstudio-v9/`; diese Liste ist kein Ersatz für die transitive Import-/Fetch-/Asset-Prüfung. GLTF-Begleitdateien, Texturen, JSON, Audio und die tatsächlich verwendete DC-Runtime mit berücksichtigen. Bei externen Assets exakten Pfad, Revision und Abrufstatus dokumentieren.
3. Prüfe ausdrücklich die bislang fehlenden Dateien:

```text
lab-v6/carl-contract.v1.js
lab-v6/facegraft.v1.js
lab-v6/carlrig-mount.v1.js
lab-v6/browgraft.v1.js
frizzlegraft-v1/anim-contract.v1.js
frizzlegraft-v1/actor-color.v1.js
frizzlegraft-v1/actor-wobble.v1.js
petstudio-v9/kfb-pet-graft-driver-default.json
petstudio-v9/kfb-pet-capsule-carl.json
```

Wenn eine davon im funktionierenden Stand anders heißt oder nicht mehr benutzt wird, den tatsächlichen Importpfad belegen. Nicht eine fehlende Datei aus Erinnerung nachbauen. Ein bloß umbenannter WIP-Anhang ist kein automatisch freigegebenes Defaultprofil.

4. **Importauflösung prüfen:** Rigging meldet `Failed to resolve module specifier './lab-v2/sources.js'`. Nicht nur Dateien neben das Bundle legen. Sicherstellen, dass der exportierte DC-/Modul-Kontext die Pfade tatsächlich vom vorgesehenen Asset-/Modul-Root auflöst. Ein nötiger Pfadfix gehört in die editierbare Quelle und ins Changelog, nicht in einen unprotokollierten Bundle-Patch.
5. Den Export in einen **neuen, leeren Ordner** entpacken und über einen normalen lokalen Webserver starten, mit frischem Browserprofil und ohne Dateien aus dem ursprünglichen Workspace. Keine alten Drafts oder Service-Worker als versteckte Voraussetzungen. Im kleinen Exporttest alle drei Tools bis zum tatsächlichen Inhalt öffnen und zentrale Ladewege wie Actorwahl, eine vorhandene Clipwahl und Configimport prüfen; spätere vollständige ToolBox-QA bleibt beim Publisher.
6. Pro Tool Boot-Ergebnis, Screenshot und Konsolen-/Netzwerkfehler protokollieren. Studio: echter zusammengesetzter FB-Graft. Rigging: Carl sichtbar. Animation: tatsächlich geladene Figur und funktionierendes vorhandenes Playback; offen sagen, ob der FB-Graft-Default noch WIP ist. Kein Thumbnail-/UI-only-PASS.

## Lieferpaket

Ein ZIP mit `START_HERE.md`, den editierbaren Quellen, den benötigten Assetdateien bzw. verifizierten externen Assetreferenzen, unverändertem Configvertrag `kfb.pets/1`, Dateimanifest, Export-/Startanleitung, additivem Changelog und `EXPORT_SMOKE_TEST.md`.

**Prüfsummen ganz zuletzt erzeugen, nach dem finalen Return; danach nichts mehr im Paket ändern.** Auch Dateien mit Leerzeichen/Klammern hashen. Abschließend den fertigen ZIP noch einmal entpacken und anhand des Manifests prüfen.

Keine 17 Gestaltungsschriften bei Georg nachfordern. Für UI gilt weiterhin Roboto/System-Sans-Fallback; Brand-Art bleibt getrennt. Fehlende optionale Art-Fonts ausdrücklich ausweisen. Keine Font-Binaries, Secrets oder persönlichen Sitzungsdaten in diese Übergabe aufnehmen. Ein modularer Source-Export ist ausreichend; kein Single-File-Neubau nötig.

**Nicht im Auftrag:** neue Features, neues Rig, neues Schema, weitere Legacy-Suche, neue ToolBox-Oberfläche, Produktionsänderungen an Travel/Combat/Podcast/Wissens-Pilli. Das jetzige Paket wird nur vervollständigt und seine Exportierbarkeit bewiesen.

Rückgabe: ein ZIP, knapper Quellen-/Bootstatus und verbleibende konkrete Lücken. Keine neue Entscheidungsrunde zu bereits freigegebenen ToolBox-Grundlagen.

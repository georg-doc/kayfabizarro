# KFB ToolBox T1 · Review der Fable-Teilrückgabe

Datum: 2026-09-14  
Status: **REVIEW / T1 PARTIAL · SOURCE EXPORT BLOCKED**  
Basis: angehängtes „Fünf Entscheidungen ausstehend.zip“ und der zuvor gelieferte ToolBox-Onboarding-ZIP. Keine GitHub-Änderung, kein Merge, kein Deployment. Originaldateien unverändert.

## Ergebnis für Georg

**Als Diagnose brauchbar; als fertige ToolBox noch nicht geliefert.** Der Quellenblocker ist substanziell: Die drei HTML-Bundles enthalten nicht die benötigten KFB-Modulbäume. Die Oberfläche kann erscheinen, während Actor-/Rig-/Animationslogik nicht geladen wird. Eine erneute Tool-Implementation aus Beschreibungen wäre der falsche Weg.

Die neue Startseite, der Config-Katalog, das Font-Inventar und die dokumentierten Bootfehler sind erhaltenswerte Vorarbeit. Sie ersetzen aber weder drei benutzbare Werkzeuge noch Graft-/Talk-/Roundtrip-Abnahme. Ohne Kosten-/Verbrauchsdaten ist kein belastbarer Preisvergleich Fable gegen Astra möglich.

## 1 · Was unabhängig an den gelieferten Bytes geprüft wurde

- **3/3 HTML-Bundles und 6/6 Configs** entsprechen nach neu berechnetem Git-Blob-SHA und Größe den im Paket angegebenen Source-Pins. Das bestätigt Erhalt, nicht Funktionsfähigkeit. Es erfolgte kein neuer Download der GitHub-Basis.
- Die eingebetteten Ressourcenmanifeste und Textressourcen wurden gelesen: Studio hat 3 JavaScript-Ressourcen und 35 WOFF2-Ressourcen; Animation 3 und 16; Rigging 4 und 25. Die JavaScript-Ressourcen sind DC-Support/React/ReactDOM, beim Rigging zusätzlich ein Design-System-Bundle. Die App-Logik steckt im Template; die benötigten externen KFB-Moduldateien fehlen als vollständiger gelieferter Modulbaum.
- Studio importiert unter anderem `petstudio-v9/studio-v7/pet-session.v1.js`. Animation lädt `lab/assets.js`, `lab/locomotion.js`, `lab/zipstore.js`, `frizzlegraft-v1/anim-contract.v1.js` und `pet-session.v1.js` extern, wenn keine eingebettete Modulquelle vorhanden ist. Rigging enthält direkte relative Imports auf seine KFB-Module.
- **17 lokale Schriftreferenzen** im Studio-Template bestätigt; darunter sieben, nicht acht Fonteys-PRO-Dateien. Fables Einzeldateiliste stimmt in der Anzahl; die Zusammenfassung im Changelog zählt Fonteys falsch. Das ist eine kleine Dokumentationskorrektur, kein Bootblocker.
- Fables `CHANGELOG.md` erhält den gesamten alten Inhalt und hängt den neuen Teil an.

Details und alle Hashes: `VALIDATION.json`.

## 2 · Konkreter Paketfehler: Prüfsumme des Returns stimmt nicht

Die mitgelieferte `CHECKSUMS.sha256` enthält 18 Prüfeinträge: **17 PASS, 1 FAIL**.

Betroffen:

`tools/KFB-ToolBox/_handover/TOOLBOX_V1_2026-09-14/RETURN.md`

Erwartet laut Paket:

`642abb3f1dc4f2b631f5d15135adc07d0d2737d21736bdfd4879ab5186ff1af3`

Tatsächlich geliefert:

`a4c6191cd625d296978c631861dd4a23d24984d37e0c423e3fb65561ffb903b1`

Der eigene Claude-Code-Handoff würde deshalb in Schritt 2 korrekt stoppen. Die Ursache ist aus dem ZIP nicht beweisbar; eine spätere Änderung des Returns wäre eine mögliche Erklärung, aber kein festgestellter Sachverhalt.

Fünf Config-Dateien fehlen in der SHA-256-Liste; Fable erklärt dies mit einer Einschränkung seiner Umgebung bei Klammerpfaden. Das ist keine allgemeine Grenze solcher Dateinamen. Hier ließen sich alle sechs Configs problemlos hashen und gegen die angegebenen Git-Blobs prüfen.

**Ergänzung:** `ORIGINAL_ZIP_COMPLETE.sha256` enthält Prüfsummen für alle 24 Originaldateien, einschließlich der unverändert erhaltenen alten Prüfsummenliste. Diese neue Liste beschreibt den tatsächlich empfangenen ZIP. Sie macht den alten fehlerhaften Check nicht rückwirkend gültig.

## 3 · Beim Rigging steckt möglicherweise mehr als eine fehlende Datei dahinter

Fables Screenshot zeigt:

`Failed to resolve module specifier './lab-v2/sources.js'`

Das ist nicht dieselbe Meldung wie ein fehlgeschlagener HTTP-Dateiabruf. Im entpackten Rigging-Template steht ein direktes `import('./lab-v2/sources.js')` in der DC-Logik. Studio verwendet dagegen einen expliziten URL-Anker, Animation ebenfalls eine URL-Auflösung.

**INFERENCE:** Zusätzlich zum fehlenden Modulbaum könnte die Ausführung aus dem DC-/Bundle-Kontext die relativen Modulpfade falsch auflösen. Deshalb nicht versprechen: „Ordner danebenlegen und alle drei laufen.“ Erst Source-Closure liefern, dann Import-Basis im exportierten Startweg testen und nötigenfalls an der bestehenden Source-Naht korrigieren. Keine Neubau-Architektur.

## 4 · Grenzen der vorhandenen Belege

Die drei beigefügten Browserbilder wurden angesehen. Studio zeigt eine leere Bühne; Rigging zeigt den Specifier-Fehler; Animation zeigt konkret einen Fehler für `lab/locomotion.js`. Der Return nennt für Animation zusätzlich `lab/assets.js` und Warnungen. Das kann zusammenpassen, ist aber ohne Console-Log nicht als identische erste Fehlermeldung belegbar.

Ein unabhängiger Browserlauf wurde hier versucht, die lokale HTTP-Navigation aber mit `ERR_BLOCKED_BY_ADMINISTRATOR` abgewiesen. Es wurde keine Umgehung versucht. **Keine eigene Browser-Reproduktion und kein eigener App-Browser-PASS aus dieser Prüfung.** Die unabhängigen Resultate sind Datei-/Hash-/Bundle-Analysen; Browserbefunde bleiben Fables dokumentierte Befunde.

„Nirgends vorhanden“ ist auf Fables berichtete Suchumgebung zu begrenzen. Das ZIP enthält keine vollständigen Scanlogs mit allen geprüften lokalen Quellen und Revisionen. Belastbar ist: **Im gelieferten Paket fehlen diese Quellen.** Daraus folgt nicht, dass sie im ursprünglichen laufenden Authoring-Workspace verloren sind.

## 5 · Bewertung gegen den T1-Auftrag

| Teil | Bewertung |
|---|---|
| Quellen-/Exportprüfung | Wertvoll; tatsächliche Portabilitätslücke entdeckt und benannt |
| Originale/Configs bewahren | 9/9 Pins hier bestätigt |
| Einstieg und Config-Katalog | Implementierte Vorarbeit; tatsächliches Deployment und vollständige UI-QA offen |
| Drei benutzbare Tools | Nicht erreicht; 3 Boot-FAIL im Fremdreport |
| Graft/Carl/Talk/Mods/Clips/Roundtrip | Nicht getestet, nicht geliefert als Consumer-Nachweis |
| UI-Fonts | Inventar erweitert; Font-Pass nur auf Startseite, nicht in den Tools |
| Reproduzierbarer Paketabschluss | Noch fehlerhaft wegen Return-Prüfsumme; Zusatzliste erstellt |

Der Stop am fehlenden Originalcode war richtig. Die externe Suche und das Erstellen einer aufwendigen Startseite sind allerdings kein Ersatz für den zuerst erforderlichen vollständigen Source-Export. Das Source-Risiko war bereits im Onboarding `docs/SOURCE_AUDIT.md` ausdrücklich benannt.

Die Startseite benutzt erneut `x-dc`/DCLogic plus `support.js` und dupliziert ihren HTML-Inhalt in `index.html` und `KFB ToolBox.dc.html`. Das funktioniert möglicherweise innerhalb des vorgesehenen DC-Wegs; für reine Navigation wäre normales HTML weniger abhängig. **Jetzt kein weiterer Neubauauftrag dafür.** Falls die Seite erhalten bleibt, eine editierbare Quelle und einen erklärten Kopier-/Buildweg pflegen.

## 6 · Der nächste Auftrag bleibt eng

Im ursprünglichen, zuletzt laufenden Design-Workspace **nur den vollständigen Source-Export herstellen und testen**. Der Workspace ist anhand der tatsächlich dort laufenden drei Tools zu identifizieren, nicht allein anhand des möglicherweise mehrfach vorhandenen Namens „KFB Rigging Lab v1“.

Der Export braucht die drei editierbaren Einstiege, vollständige lokale Modul-/Asset-Abhängigkeiten, exakte Configs, dokumentierte externe Quellen und einen Startweg, der ohne alte Workspace-Dateien startet. Ein modulbasiertes Webpaket reicht; eine neue perfekte Single-HTML-Datei ist keine Voraussetzung.

Danach setzt derselbe ToolBox-Produktionschat T1 fort: Cold Boot → Font-Pass → Graft/Carl/Talk/Mods/Clips/Roundtrip → Vorschau → Georg-Abnahme. Kein neuer Router, kein zweiter Actor-Stack, keine weitere Projektsuche vor dieser konkreten Exportkorrektur.

## 7 · GitHub-/Masterplan-Einordnung

Empfohlener Status: `T1_PARTIAL_BLOCKED_SOURCE_EXPORT`.

Das Fable-Paket als unveränderten Eingang plus diesen Review sichern, nicht als fertigen ToolBox-Release. Die fehlerhafte Original-Prüfsumme dokumentieren; ergänzende Prüfsummen getrennt verwenden. Kein Blind-Overlay auf einen inzwischen veränderten `main` und keine Veröffentlichung der drei toten Tools als benutzbare Suite.

Dieser Review ändert keine GitHub-Dateien. `MASTERPLAN_DELTA.md` ist eine vorbereitete, noch nicht eingetragene Ergänzung. Runtime- und Tool-Quellen bleiben unverändert.

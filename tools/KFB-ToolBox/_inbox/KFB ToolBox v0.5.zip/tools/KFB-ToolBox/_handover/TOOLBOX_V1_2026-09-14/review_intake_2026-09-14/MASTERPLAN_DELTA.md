# Vorgeschlagener additiver Masterplan-Eintrag · 2026-09-14

Status dieses Dokuments: **PROPOSAL / bereit zur Übernahme, nicht auf GitHub eingetragen.**

## ToolBox T1 · Exportblocker statt neuer Architektur

**REPORTED TESTED RESULT:** Fable dokumentiert bei allen drei gelieferten Export-HTMLs einen UI-Start ohne funktionierende Tool-Inhalte und mit Modul-/Importfehlern. Graft/Carl/Talk/Clips/Roundtrip wurden nicht abgenommen.

**INDEPENDENT STATIC RESULT:** Der Review des angehängten Pakets bestätigt die neun ursprünglichen Bundle-/Config-Pins, nicht die Ausführbarkeit. Die für die App-Logik benötigten KFB-Module sind nicht als vollständige Runtime-Closure geliefert. 17 lokale Fontreferenzen sind im Studio-Template nachweisbar.

**INTEGRITY CORRECTION:** Die ursprüngliche SHA-256-Liste hat 17 bestandene und eine fehlgeschlagene Prüfung (RETURN.md); fünf Configs waren dort nicht per SHA-256 erfasst. Vollständige zusätzliche Hashliste für den empfangenen Stand liegt im Review-Paket. Originale bleiben unverändert.

**REVIEW:** Der Rigging-Specifier-Fehler ist zusätzlich auf die Modul-URL-Basis im exportierten DC-Kontext zu prüfen. Die Aussage „Dateien danebenlegen genügt“ ist noch nicht bewiesen. Nicht behaupten, fehlender Export bedeute verlorener Authoring-Workspace.

**NEXT PROPOSED ACTION:** Der ursprüngliche laufende Authoring-Workspace liefert einen vollständigen, editierbaren, isoliert startgeprüften Source-Export. Danach setzt der vorhandene ToolBox-Produktionschat T1 fort. Keine neue Architektur, kein automatischer Actor-/Schemawechsel und keine erneute breite Legacy-Suche.

**UNCHANGED:** Einheitlicher FB Driver Graft als Ziel für alle FB-Consumer; Carl eigenes Profil; bestehendes `kfb.pets/1`; UI-Webfont/System-Fallback; unveränderte Spiel-SSOTs; v17-Export-Boot ist noch keine Consumer-Promotion.

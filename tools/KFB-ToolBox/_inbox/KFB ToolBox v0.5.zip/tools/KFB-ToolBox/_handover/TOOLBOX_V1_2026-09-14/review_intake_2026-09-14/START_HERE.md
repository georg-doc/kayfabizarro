# KFB ToolBox T1 · Fable Review

1. `REVIEW.md`: Urteil, unabhängige Befunde, Grenzen und nächster Schritt.
2. `TO_AUTHORING_WORKSPACE.md`: Weitergabe an den ursprünglichen laufenden Design-Workspace.
3. `VALIDATION.json`: exakte Prüfergebnisse und Source-Pins.
4. `ORIGINAL_ZIP_COMPLETE.sha256`: vollständige ergänzende Hashliste des unverändert empfangenen Fable-Pakets. Prüfung aus dessen entpacktem Root, nicht aus dem ToolBox-Unterordner. Diese Liste enthält keine Runtime-Dateien.
5. `MASTERPLAN_DELTA.md`: vorgeschlagene Ergänzung, noch nicht in GitHub.
6. `CHANGELOG.md`: additive Geschichte dieser Prüfung.

Das Paket enthält keine Tool-HTML-Bundles, keine Schriftdateien und keine neue Runtime. Es ist ein Review-/Recovery-Handoff. Fables ursprünglicher ZIP bleibt die separate Quellenabgabe.

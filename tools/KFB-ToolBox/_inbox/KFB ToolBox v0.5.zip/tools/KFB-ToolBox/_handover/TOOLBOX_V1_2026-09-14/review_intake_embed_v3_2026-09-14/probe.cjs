/* Read-only call-shape probe, not a renderer or a patched production module.
 * Source: georg-doc/kayfabizarro@f6e1a57d2580e2d35bd842c042d4673671a1b7c4
 * tools/KFB-ToolBox/kfb-rigs-embed-v3/lab-v6/partrig.v1.js
 * Git blob: 27c6533f1512ee1edb96220dccc49d0f725ecc2e
 * DEFAULTS and set() below are transcribed from that source. apply() is a stub.
 * Calls reproduce the shapes in carlrig-mount.v1.js. No geometry is loaded.
 */
'use strict';
const assert = require('node:assert/strict');
const DEFAULTS = Object.freeze({ enabled: false, scale: 1, spread: 0, lift: 0, depth: 0, tilt: 0 });
function fixture() {
  return {
    params: { ...DEFAULTS }, calls: 0,
    apply() { this.calls++; },
    set(patch) {
      for (const [k, v] of Object.entries(patch || {})) {
        if (!(k in DEFAULTS)) return { status: 'UNSUPPORTED', field: k, reason: 'unknown' };
        if (k !== 'enabled' && !Number.isFinite(v)) return { status: 'UNSUPPORTED', field: k, reason: 'not a number' };
      }
      Object.assign(this.params, patch);
      this.apply();
      return { status: 'OK' };
    }
  };
}
// Exact relevant values from contracts/kfb-carl-rig-v6.json, through toPets1().
const nose = {mod:'original',original:{islands:[{island:6}],enabled:false,scale:1.34,spread:0,lift:-0.02,depth:-0.066,tilt:0}};
const brow = {mod:'block',original:{islands:[{island:7},{island:8}],enabled:false,scale:1,spread:0,lift:0,depth:0,tilt:0}};
const results = [];
for (const [id, patch] of [
  ['actual-nose-call', {...nose, enabled:nose.mod === 'original'}],
  ['actual-brow-call', {...brow, enabled:brow.mod === 'block'}],
  // Merely spreading original is also insufficient: it still contains islands.
  ['naive-unpack-control', {...nose.original, enabled:true}],
  // Illustrative compatible call, not an applied production fix or visibility decision.
  ['allowed-keys-control', {enabled:true,scale:1.34,spread:0,lift:-0.02,depth:-0.066,tilt:0}],
]) {
  const rig = fixture();
  const returned = rig.set(patch);
  results.push({id,returned,params:rig.params,applyCalls:rig.calls});
}
assert.deepEqual(results[0].returned,{status:'UNSUPPORTED',field:'mod',reason:'unknown'});
assert.deepEqual(results[1].returned,{status:'UNSUPPORTED',field:'mod',reason:'unknown'});
assert.equal(results[0].params.scale,1);
assert.equal(results[0].params.lift,0);
assert.equal(results[0].applyCalls,0);
assert.equal(results[1].applyCalls,0);
assert.deepEqual(results[2].returned,{status:'UNSUPPORTED',field:'islands',reason:'unknown'});
assert.deepEqual(results[3].returned,{status:'OK'});
assert.equal(results[3].params.scale,1.34);
assert.equal(results[3].params.depth,-0.066);
assert.equal(results[3].applyCalls,1);
console.log(JSON.stringify({
  sourceRevision:'f6e1a57d2580e2d35bd842c042d4673671a1b7c4',node:process.version,
  scope:'Extracted method and actual caller argument shapes; apply stubbed; no complete modules, assets, browser or consumer loaded.',
  result:'CALL_CONTRACT_MISMATCH_REPRODUCED',results,
  notTested:['full mountCarl','asset loading','appearance','WebGL','roundtrip','consumer integration','deployment']
},null,2));

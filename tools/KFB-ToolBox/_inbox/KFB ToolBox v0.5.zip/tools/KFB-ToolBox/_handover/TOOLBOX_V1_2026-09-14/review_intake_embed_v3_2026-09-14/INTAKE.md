# Eingang · Review »KFB Rig Embed v3« · 2026-09-14

Herkunft: Review-Paket `KFB_RIG_EMBED_V3_REVIEW_2026-09-14` (2. Eingang des Tages, anderer Gegenstand als `review_intake_2026-09-14/`).
Gegenstand des Reviews: `tools/KFB-ToolBox/kfb-rigs-embed-v3/` @ `f6e1a57d2580e2d35bd842c042d4673671a1b7c4`.
Dateien unverändert gesichert: REVIEW.md, PROBE_RESULTS.json, SOURCE_PINS.json, CHANGELOG.md, CHECKSUMS.sha256, probe.cjs.

Dieser Eingang betrifft einen **Donor-Paketbaum**, nicht die drei Standalone-Bundles. Er ist kein Abnahmedokument der ToolBox und ändert keinen Owner: WS0 bleibt liefernder Owner des Embeds.

## 1 · Was ich nachgeprüft habe

Gelesen am angegebenen Commit über den GitHub-Connector: vollständiger Tree `tools/KFB-ToolBox/` (66 Dateien) sowie `lab-v6/partrig.v1.js`, `lab-v6/carlrig-mount.v1.js`, `lab-v6/carl-contract.v1.js` im Volltext.

| Behauptung des Reviews | Prüfergebnis |
|---|---|
| R1 · `PartRig.set()` akzeptiert nur `enabled, scale, spread, lift, depth, tilt`; jeder andere Schlüssel liefert `UNSUPPORTED` vor `Object.assign` | **BESTÄTIGT** · `set()` iteriert `Object.entries(patch)` und kehrt beim ersten Schlüssel zurück, der nicht in `DEFAULTS` steht |
| R1 · Der Carl-Reader übergibt `{ ...brow, enabled: … }` und `{ ...nose, enabled: … }` ohne Statusprüfung | **BESTÄTIGT** · beide Zeilen in `carlrig-mount.v1.js`, Rückgabewert wird verworfen |
| R1 · `toPets1()` legt die Werte unter `pet.nose.original` ab | **BESTÄTIGT** · `nose: { mod, original }`, `brow: { mod, ...browFlat, original, graft }` |
| §5 · `kfb-rigs-embed-v3.manifest.json` ist im Paketbaum nicht vorhanden | **BESTÄTIGT** · Paketwurzel enthält nur `EMBED_KFB_RIGS_v3.md`; auch keine Testseite, keine Screenshots |
| §5 · `pet-session.v1.js`, `lab-v2/sources.js`, `lab/assets.js` fehlen im Paket | **BESTÄTIGT** |
| SOURCE_PINS · 9 Git-Blobs | **BESTÄTIGT** · alle 9 stimmen mit dem Tree am genannten Commit überein |

Nicht nachgeprüft: der Probe-Lauf selbst (Node-Ausführung), Browserstart, Asset-Render, Aussehen, Roundtrip. Die Probe ist ein Methodentest mit gestubbtem `apply()`, kein Beleg über eine gerenderte Figur — so beschreibt sie sich auch selbst.

## 2 · Zwei Ergänzungen zu R1

**(a) Die Naht der Braue trägt mehr fremde Schlüssel als `mod`.** Der Rückgabetext (§8) nennt `mod` und `original`. `toPets1()` legt in `pet.brow` zusätzlich `graft` und die **flachen BrowRig-Regler** aus `brow.drawn` ab (`browFlat`, alle Schlüssel außer `points`/`enabled`). Der Spread `{ ...brow }` schickt sie alle in ein `PartRig`. Ein Fix, der nur `mod` entfernt, trifft die Stelle nicht — die Übertragung muss auf die zulässigen sechs Felder **positiv gefiltert** werden, nicht per Ausschlussliste. Bei `pet.nose` genügt `{ mod, original }`.

**(b) Was genau verloren geht, ist die gespeicherte Abweichung — nicht die Sichtbarkeit.** `PartRig.DEFAULTS` ist ausdrücklich der *gemessene Originalzustand* (`reset()`-Kommentar), also `scale 1 / spread 0 / lift 0 / depth 0 / tilt 0`. Nach dem abgewiesenen `set()` steht das Part-Rig auf genau diesem Zustand. Für die Braue kann das deckungsgleich mit der Absicht sein; für die Nase nicht, weil der beigelegte Vertrag `scale 1.34`, `lift -0.02`, `depth -0.066` trägt. Zusätzlich bleibt `enabled` auf `false`, weil der frühe Rückgabepfad auch das mitgegebene `enabled` nicht mehr zuweist — die Sichtbarkeit entscheidet danach aber der Zonen-Durchlauf (`setZoneStyle` über alle Inseln). Die Zurückhaltung des Reviews (»nicht: die Nase ist zwingend unsichtbar«) ist damit belegt richtig. Der prüfbare Satz lautet: **die kalibrierten Abweichungen erreichen das Part-Rig nicht; die Sichtbarkeit hängt am Zonenvertrag.**

Konkreter visueller Test dafür: Carl mit `nose.mod = 'original'` montieren und die Nase gegen `scale 1.34 / depth -0.066` vergleichen. Abweichung sichtbar = Befund bestätigt.

## 3 · Was dieser Eingang für die ToolBox ändert

Das Review sagt in §5 ausdrücklich, der ToolBox-Exportblocker sei nicht aufgehoben. Das gilt weiter. Der Paketbaum enthält aber **Module, die `docs/MISSING_MODULES.md` bisher als nicht auffindbar geführt hat.** Das ist die ToolBox-seitige Gegenleistung zu diesem Review; das Review selbst wertet die Abdeckung nicht aus.

Vier der neun am 13.09. neu angelegten, bis dahin nirgends gefundenen Dateien liegen jetzt an einer gepinnten Adresse: `lab-v6/carl-contract.v1.js`, `lab-v6/facegraft.v1.js`, `lab-v6/carlrig-mount.v1.js`, `frizzlegraft-v1/actor-wobble.v1.js`.

Abdeckung je Bundle (Namensgleichheit, maschinenlesbar in `docs/EMBED_V3_COVERAGE.json`):

| Bundle | benötigt | im Embed v3 | fehlt weiter |
|---|---|---|---|
| Rigging Lab v1 | 15 | 10 | 5 |
| Animation Lab v2 | 5 | 0 | 5 |
| FrankenStein Studio v17 (benannte Direkt- + Transitivrefs) | 17 | 8 | 9 |

**Kein Bundle wird dadurch startfähig.** Für das Rigging Lab fehlen weiter `lab-v2/sources.js` (genau der erste beobachtete Fehler), `lab-v6/brow.v3.js`, `lab-v6/stache.v3.js`, `frizzlegraft-v1/actor-color.v1.js` und `petstudio-v9/kfb-pet-capsule-carl.json`; für das Animation Lab fehlt der komplette `lab/`-Ordner samt `anim-contract` und `pet-session`.

**Und: die Bytegleichheit dieser 10 Dateien mit dem 13.09.-Workspace-Stand ist nicht belegt.** Der Embed ist ein später kuratierter Donor, kein Workspace-Export. Die Regel von `MISSING_MODULES.md` bleibt darum in Kraft — **kein handgemischter Modulbaum aus zwei Ständen.** Der Auftrag an den Authoring-Owner (`../review_intake_2026-09-14/TO_AUTHORING_WORKSPACE.md`) ist unverändert gültig und wird durch dieses Paket nicht kleiner, nur besser umrissen.

Zwei belegbare Identitäten in die andere Richtung: `contracts/kfb-carl-rig-v6.json` (`b57d125ce047`) und `contracts/kfb-pet-graft-driver.v4.json` (`f202a1c2f167`) sind **byte-identisch** zu zwei Configs, die der Site-Katalog schon listet (`kfb-carl-rig-v6(1).json`, `kfb-pet-graft-driver (4).json`). Der Embed und der ToolBox-Eingang teilen an dieser Stelle dieselbe Quelle.

## 4 · Nicht übernommen

- Kein Fix am Embed. R1 gehört dem Owner (WS0); die ToolBox macht `PartRig` nicht permissiv, damit ein falscher Aufruf grün wird.
- Keine Übernahme der Module nach `site/`. Ohne belegten Stand wäre das der verbotene Mischbaum.
- Kein Statuswechsel. `TOOLBOX_MANIFEST.status` bleibt `T1_PARTIAL_BLOCKED_SOURCE_EXPORT`.
- Keine GitHub-Schreiboperation.

## 5 · Rückgabesatz an WS0

> Review angenommen, R1 am Commit unabhängig nachgelesen und bestätigt. Zwei Ergänzungen: erstens trägt `pet.brow` neben `mod` und `original` auch `graft` und die flachen BrowRig-Regler aus `brow.drawn` — der Fix muss positiv auf die sechs `PartRig`-Felder filtern, nicht `mod` ausschließen. Zweitens ist der Verlust genau die gespeicherte Abweichung (`PartRig`-Defaults sind der gemessene Originalzustand), während die Sichtbarkeit am nachfolgenden Zonen-Durchlauf hängt; die Zurückhaltung im Review ist damit belegt richtig. Für die ToolBox: das Paket deckt 10 von 15 Rigging-Lab-Modulen und 4 der neun am 13.09. neu angelegten Dateien ab, macht aber kein Bundle startfähig und ersetzt den Workspace-Export nicht, weil die Bytegleichheit zum 13.09.-Stand unbelegt ist. Manifest und Zwei-Figuren-Probe bleiben offen.

# KFB Rig Embed v3 · Review für WS0 und die spätere ToolBox-Übernahme

Stand: 14.09.2026
Quelle: `georg-doc/kayfabizarro@f6e1a57d2580e2d35bd842c042d4673671a1b7c4`
Paket: `tools/KFB-ToolBox/kfb-rigs-embed-v3/`
Paket-Tree: `dbcf82ac76097167d7a8a7016d87d77f3aaf99aa`

**Status:** Source-Review plus isolierte Probe eines Methodenvertrags. Kein vollständiger Modulimport, Browserstart, Asset-Render, Audio-Test oder Consumer-PASS. Keine GitHub- oder Runtime-Änderung. WS0 bleibt für diesen Eingang der liefernde Owner; die ToolBox-Übernahme ist noch keine vollzogene Migration.

## 1 · Urteil

Der Embed trifft den richtigen Bedarf: Ein Consumer erhält eine Figur über den bestehenden Bauweg, statt Augen, Mund, Kopfaufteilung und Materialien neu zu bauen. Das ist eine wiederverwendbare Laufzeitschicht, nicht eine weitere Autorenoberfläche.

Die zwei vorgesehenen Eingänge sind `mountGraft()` für die dokumentierten Graft-Zweibeiner und `mountCarl()` für CapsuleCarl. Cube-Pets bleiben laut §0 des Embed-Dokuments beim bisherigen v2.2-Vertrag. Der Titel »jede KFB-Figur« ist deshalb nicht als Beleg für universelle Kompatibilität mit jedem Actor, Vehicle oder beliebigen KayKit-Rig zu lesen.

**Empfehlung:** als konkreten WS0-Embed-Donor verwenden, den unten benannten Carl-Fehler am Owner beheben und erst nach einem sichtbaren Vergleich übernehmen. Keine neue Architektur und kein paralleler Proxy-Actor nötig.

## 2 · Quellbelegte Stärken

- Die beiden Mount-Funktionen erhalten `THREE` und Loader vom Wirt. Renderer, Szene und Welt werden nicht durch eine neue App ersetzt. Ob die vollständige Host-Importmap tatsächlich nur einen Three-Build lädt, ist anschließend am Host zu prüfen.
- `mountGraft()` liest Look, Materialzonen, Spenderaugen, Gesichtsmodule, Mund, Pose und optional die Waffe in einer dokumentierten Reihenfolge. Die Eingabe wird geklont, Overrides betreffen die Kopie. »Vom Studio abgeleitet« ist die Herkunftsaussage des Modulkopfs; ein byteweiser Abgleich gegen den vollständigen Studio-v17-Quellbaum wurde hier nicht ausgeführt.
- `animation:'host'` und `animation:'own'` machen den Mixer-Owner ausdrücklich. Die dokumentierte Reihenfolge lautet Mixer, Gesicht/Pose-Update, optionale FX, Render. Das ist passend für Travel und Arena, ohne ihnen einen zweiten Movement-Core zu geben.
- `poseOverClip` adressiert eine reale Fehlerklasse: eine statische Standpose darf nicht laufend die Beine eines Walk-Clips überschreiben. Die genaue Codebedingung ist `preset !== 'stand'` bei `auto`, nicht eine explizite Whitelist aller Sitzposen. Neue Presets daher nicht ungeprüft als sitzend behandeln.
- Das vorhandene `PetMouth` liefert Talk an/aus, TalkBurst und die abstrakten Viseme. Das Embed-Dokument bezeichnet den Shuffle ausdrücklich nicht als Lip-Sync. Für ChatterBox ist das der Darstellungsanschluss, nicht ein neuer Text-, Sprecherwahl- oder TTS-Owner.
- Die Carl-Übersetzung hält das bestehende `kfb.pets/1` bei und ergänzt benannte Inselangaben. Ein neuer Actor/Role/Fit-Großumbau ist dadurch nicht nötig.

## 3 · R1 · Konkreter Carl-Aufruffehler

**SOURCE FACT:** `carlrig-mount.v1.js` übergibt:

```js
origBrow.set({ ...brow, enabled: brow.mod === 'block' });
origNose.set({ ...nose, enabled: nose.mod === 'original' });
```

**SOURCE FACT:** `partrig.v1.js` akzeptiert in `set()` nur die Schlüssel aus `DEFAULTS`: `enabled`, `scale`, `spread`, `lift`, `depth`, `tilt`. Bereits `mod` führt zu `UNSUPPORTED`; die Methode kehrt vor `Object.assign` und `apply` zurück. Der Reader wertet diesen Rückgabestatus nicht aus.

**SOURCE FACT:** Der beigelegte Carl-Contract enthält `nose.original.scale = 1.34`, `lift = -0.02` und `depth = -0.066`. `toPets1()` bewahrt die Werte unter `pet.nose.original`. Der Reader entpackt diese Werte an der betreffenden Aufrufstelle nicht.

**TESTED RESULT, eng begrenzt:** `probe.cjs` führt die aus dem Source übernommene `set()`-Methode mit den tatsächlichen Argumentformen aus. Die Darstellung ist durch einen `apply()`-Zähler ersetzt. Beide Reader-Aufrufe werden mit `UNSUPPORTED / mod` abgewiesen, Parameter bleiben auf Defaults. Auch bloßes Entpacken von `original` reicht nicht: das enthaltene `islands` wird ebenfalls abgelehnt. Eine Kontrollprobe mit ausschließlich zulässigen Feldern wird angenommen.

Die Probe ist kein vollständiger Import von `mountCarl()` und kein visueller Beleg. Später im Reader gesetzte Zonen können Teile wieder sichtbar machen. Deshalb lautet der Befund **gespeicherte Part-Kalibrierung wird an dieser Naht nicht angewandt**, nicht »die Nase ist zwingend unsichtbar«.

**Vorschlag für WS0:** nur zulässige numerische Part-Parameter aus `original` übertragen, Sichtbarkeit entsprechend dem bestehenden Mode-/Zonen-Vertrag explizit bestimmen und Status prüfen. `PartRig` nicht permissiv machen, nur damit ein falscher Aufruf grün wird. Das Zusammenspiel von `original.enabled`, Mode und Zonen ist anhand des Authoring-Standes zu bewahren, nicht im Consumer neu festzulegen.

## 4 · R2 · Noch keine belegte vollständige JSON-Rehydration

Der Carl-Konverter exportiert `eye.colors`. `mountCarl()` reicht an `buildFace()` jedoch nur die dort aufgeführten Anker-, Lid-, Pupillen-, Glanz- und Wimpernwerte weiter; `pet.eye.colors` wird im gelesenen Reader nicht verwendet. Ebenso werden bei gezeichneten Brauen, gezeichneter Nase und Schnurrbart an der betreffenden Stelle nur Aktivierungszustände gesetzt, nicht alle übertragenen Einstellwerte.

Das ist nicht automatisch ein sichtbarer Fehler bei jedem Profil. Beispielsweise kann ein Profil mit unveränderten Farbdefaults gleich aussehen. Es ist aber ein konkreter Grund, **nicht pauschal »jeder JSON-Regler kommt vollständig an«** zu behaupten.

**Vorschlag:** eine kurze Feldliste am vorhandenen Vertrag führen: gespeichert, angewandt, bewusst ignoriert, noch nicht unterstützt. Mit zwei gezielten Abweichungen testen, etwa markant geänderter Pupillenfarbe und Nasentiefe. Kein neues Schema und kein neuer Importer.

Der dokumentierte geschlossene Ruhe-Mund (`neutral → m`) sollte im tatsächlich verwendeten Profil und bei der Mount-Initialisierung nachweisbar sein. Die reine API-Anleitung garantiert das nicht: `mountGraft()` setzt zunächst `mouth.rest = 'neutral'; mouth.setTex('neutral')`. Ob ein explizites Profil beim ersten Bild und nach Talk-Stopp gewinnt, gehört in den visuellen Vergleich. Keine pauschale Änderung aller Figurenmünder aus diesem Review ableiten.

## 5 · Verpackung und Abnahme

Der angegebene Paketbaum enthält echte Quellmodule und zwei Configs. Das ist wesentlich besser übernehmbar als eine HTML-Shell mit unbekannten lokalen Imports.

Die in §1 erwähnte `kfb-rigs-embed-v3.manifest.json` ist im geprüften Paketbaum und im direkten ToolBox-Wurzelverzeichnis nicht gelistet. Eine ausführbare kleine Embed-Testseite, Screenshot-Belege oder ein separater QA-Return liegen in diesem Paketbaum ebenfalls nicht. Das beweist nicht, dass WS0 andernorts keine Tests besitzt; diese Belege sind hier nur noch nicht mitgeliefert.

**Nachlieferungsvorschlag:** Manifest einschließlich externer Datenabhängigkeiten, Paket-/Quellenpin und eine kleine Zwei-Figuren-Probe mit Front/Seite, Walk plus Talk, Emote, Talk-Stopp und erneuter Montage. Numerische Reports ergänzen Bilder, ersetzen sie nicht.

Die Beispiele und mehrere Runtime-Datenpfade nutzen `@main` beziehungsweise `/main/`. Ein gepinnter Embed-Import allein pinnt damit noch nicht alle Modelle und Texturen. Für einen freigegebenen Consumer müssen verwendete Quellen revisionsfest dokumentiert oder bewusst als beweglich ausgewiesen sein. Das ist eine Reproduzierbarkeitsfrage, kein Zwang zum Kopieren aller Assets.

**Keine Aufhebung des früheren ToolBox-Exportblockers:** Dieses Paket liefert gezielt die Rig-Mount-Wege. Es liefert nicht automatisch die kompletten Studio-, Rigging- und Animation-Authoring-Oberflächen. Die damals vermissten Einstiegsmodule wie `pet-session.v1.js`, `lab-v2/sources.js` und `lab/assets.js` sind in diesem Paketbaum nicht enthalten. Was zur ToolBox-Veröffentlichung noch fehlt, muss der dortige Owner gesondert abgleichen.

## 6 · Combat-FX sind Vorschau, kein Treffervertrag

`fx.v1.js` zeichnet einen Trefferpunkt im Abstand `L * 3.2` vor dem Mündungsanker. Das ist eine feste Vorschauentfernung, keine aus der Spielwelt ermittelte Kollision. `fireTimes()` schätzt mögliche Auslösemomente aus Rotationsspitzen und besitzt einen 150-ms-Fallback. Das Modul kann im Lab hilfreich sein, darf aber nicht unbemerkt Projectiles, Treffer, Schussrate oder Damage des Combat-Consumers ersetzen.

Auch die Bestimmung der Mündung über längste Modellachse und entfernteres Ende ist eine Berechnung mit einer Formannahme. Für bekannte Waffen prüfen, nicht zur universellen semantischen Waffenmessung erklären. Die Dokumentation benennt Axt-/Bogenachsen ohnehin noch als offen.

## 7 · Schlanker weiterer Ablauf

WS0 behebt den bestehenden Carl-Aufruf und gleicht die tatsächlich exportierten Gesichtsparameter mit den Lesern ab. Danach liefert WS0 einen sichtbaren Zwei-Figuren-Vergleich und die fehlende Paketnachweisdatei. Die ToolBox übernimmt diesen geprüften Stand als gemeinsamen Bauweg oder als gepinnten Donor und dokumentiert den Pflegeübergang.

Travel, Combat, Podcast, Town und Wissens-Pilli bleiben Consumer. Ihr Verhalten, ihre Beleuchtung, Kameras und Inhalte werden nicht aus der Demo übernommen. Ein Legacy-Cube-Pet-Presenter ist kein Anlass, für Podcast einen zweiten FB zu bauen. Umgekehrt ersetzt der gemeinsame FB-Graft nicht CapsuleCarls eigene Geometrie und Messwerte.

Weitere gezielte Übernahmeprüfung, kein aktueller Blocker für die Source-Bewertung: `mountCarl().dispose()` entfernt derzeit nur die Gruppe. Ressourcenfreigabe und wiederholte Montage sind vor einer Oberfläche mit häufigem Actor-Wechsel gegen den vorgesehenen Cache-/Ownership-Vertrag zu prüfen.

## 8 · Kompakter Rückgabetext für WS0

> Embed v3 ist der richtige gemeinsame Bauweg. Bitte kein neues Rig bauen. Vor der ToolBox-Übernahme den Carl-Aufruf korrigieren: `PartRig.set()` lehnt die mitgegebenen Schlüssel `mod` und `original` ab; die gespeicherten `nose.original`-Werte erreichen den Part-Rig deshalb nicht. Nur zulässige Felder übertragen und den Rückgabestatus prüfen. Außerdem die exportierten Augenfarben und Gesichtsmodifier gegen die tatsächlich angewandten Felder abgleichen. Danach eine kleine Vergleichsseite für Graft und Carl inklusive Walk/Talk/Emote/Ruhe sowie das erwähnte Manifest mitliefern. FX bleiben Lab-Präsentation, keine neuen Combat-Treffer. Owner bleibt bis zum dokumentierten Pflegeübergang WS0.

# ⛔ ARCHIVED HISTORY · nicht weiterbauen

**Georgs Entscheidung, 2026-09-18:** `BIRTHDAY SLICE = FAIL / OUTDATED / ARCHIVED HISTORY`.

Betroffen ist die ganze Birthday-Spur: Birthday Character Select als P0 · ToolBox Birthday Consumer · Astra/Travel Birthday Slice · Birthday-Szenen-QA · Birthday-Juice als Priorität · Birthday-Ziel-Hierarchie.

Dieser Ordner bleibt im Git, weil er **Provenienz** und **einzelne wiederverwendbare Mechanismen** enthält — nicht, weil er Scope wäre. Er darf in keinem aktuellen Board als Arbeit auftauchen.

## Was hier weiterlebt (unabhängig vom Birthday-Scope)
| Datei | Was daran gilt |
|---|---|
| `EYE_SOURCE_RULE.md` | **Die Augenquellen-Regel gilt weiter** und ist im Quellbaum umgesetzt (`studio-v3/eye-source-guard.v1.js`). Sie ist der einzige Teil dieses Ordners, der aktiv ist. |
| `qa/eyesource-probe.json` · `qa/casting-probe.json` | gemessene Actor-Daten (Knochen, Clips, Bindungen, Augenzählung) — als Messwerte brauchbar |
| `qa/19–22-studio-*.jpg` | Belege, dass die vier Bewohner-Klassen im Studio laden |
| `profiles/kfb-pet-graft-driver.georg-2026-09-17.json` | Georgs Actor-Profil (kfb.pets/1 v1.2.9) |
| `qa/*-probe.html` | Prüfstände. **Warnung im Kopf beachten:** sie zählen, sie stellen nicht dar. |

## Was hier tot ist
Der Consumer-Auftrag (`RETURN_BIRTHDAY_CONSUMER.md`), das Casting als Produktziel, die Dance-/Rest-Zustandsleiste als Lieferung, der Hihi-Slot als Startscreen-Figur, `PUSH.md` als offener Branch-Auftrag.

Vor jeder Wiederverwendung: **Eigentümer und Zweck prüfen.** Einen Mechanismus übernehmen heißt nicht, die gescheiterte Spur um ihn herum wiederzubeleben.

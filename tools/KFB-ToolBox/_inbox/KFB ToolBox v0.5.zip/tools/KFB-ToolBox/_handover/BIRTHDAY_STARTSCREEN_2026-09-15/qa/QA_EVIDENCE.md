# QA-Evidenz · Birthday-Consumer-Handoff · 15.09.2026

Bilder aus `qa/casting-probe.html` (Chromium-Vorschau, 924×540, three r160, Quellstand über HTTP). Der Schreibweg nach GitHub überträgt nur Text — die JPGs sind hier über sha256 gepinnt, Maschinenwerte in `casting-probe.json`.

| Datei | sha256 | zeigt |
|---|---|---|
| `01-casting.jpg` | `8e2c6d9ae67a87cd4b622597c2a455d9be84dbabc740e226670bd9e204ddcaf9` | GothGirl · Idle_A (General) · loop |
| `02-casting.jpg` | `f71a8ec2f7b3262a8671d316bc2e67a3728f08720a85f80c9cc840725acae19c` | GothGirl · Waving (Simulation) · ~1,0 s im Clip |
| `03-casting.jpg` | `ac8742fed653a15bbb01213ec96bbc01681d321d6729628627864d403692c59d` | GothGirl · Cheering (Simulation) · ~0,9 s im Clip |
| `04-casting.jpg` | `c69567a9a474de885151042194099b8100a61ecc60cd3754cf2026c8d7eda103` | GothGirl · Rest → Idle_A |
| `05-casting.jpg` | `fc656dfe9f3f8a1ad6b8fec352012b939391a050c03ffe34ed681e70ff61c4f4` | FrizzleBob · Idle_A nach mountGraft (animation:host) |
| `06-casting.jpg` | `e99a9aa60650cef16d8b322cb1c67eed777d27ceef99fe298c5744eecaafe059` | FrizzleBob · Waving |
| `07-casting.jpg` | `34d7499d7618a279b9fb3868d71e0f8ce3c5071674fe17101878fbe614a9b5b8` | FrizzleBob · Cheering (Bild 3 der Reihe zeigt den Jubel mit Waffe aus dem Fixture-Vertrag) |
| `08-casting.jpg` | `baa077850760ef3aad826c3e9fc1f442b645a8059485dbea6a7f0d4b2a8b9923` | FrizzleBob · Rest → Idle_A |
| `01-dance-p1-candidate.jpg` | `99930520966442878ab79b846fd23ef622fb7c5b9fcda6981ae89607f033c5c6` | Dance-Zustand: FEHLT — kein Tanzclip im Spender (fail closed, Figur bleibt in Idle_A) |
| `02-dance-p1-candidate.jpg` | `bb895c02ac63a7b1f645a2a4ff018a1d51dcaf3f02f3be979c057ca5d472a306` | P1-Kandidat Skeletons_Taunt_Longer geladen (Bindung 69/69), nicht als Groove gesichtet |
| `01-layout.jpg` | `e11db8b1ece72fce93fd183547dcb14b213d4f7d207c7d52e06d4971521df503` | Probe nach Layoutkorrektur (Protokoll eingeklappt) · FrizzleBob · Cheering |
| `02-layout.jpg` | `af2c0877e638f831000b980d9b5e4a272b6ad16676c63dd041a6d098fa19f259` | Georgs Profil 15.09. über mountGraft gemountet: brow carl-original · nose carl-original · Waffe aus · anim-Block FEHLT |

## Nachtrag 17.09.2026 · Rest und Dance

Georgs Befund: beide Knöpfe »nicht funktional« (GothGirl). Gemessen war Rest als Treffer protokolliert — auf denselben Clip wie Idle; Dance als MISSING mit benanntem, aber nicht verdrahtetem Kandidaten. Beides in `casting-probe.html` behoben, `anim-map.v1.js` unverändert. Bilder mit Handtakt (`window.__probe.step`), weil die Vorschau der Seite keinen Bildtakt gibt.

| Datei | sha256 | zeigt |
|---|---|---|
| `09-rest-floor.jpg` | `ffa593d34d73564ed4a769bec7dd3e23b5c6390bdd61f76f72f62b2a83ba2455` | GothGirl · Rest · Sit_Floor_Idle (Simulation) 51/51 · sitzt am Boden |
| `10-rest-floor-transition.jpg` | `4ba32d9be9dfe8ac68941d90fa0aab14741b6a75cde90ea6ea20df628f2e0036` | GothGirl · Rest · Übergang aus Sit_Floor_Down in die Halteschleife |
| `11-dance-substitute.jpg` | `b42396f5a0aff27330bb1115b286fae6d5edca57aa10fd17c8743ecf37bfdc50` | GothGirl · Dance · ERSATZ Skeletons_Taunt_Longer (Special) 69/69 · ×1,15 · HUD nennt den Ersatz |

Die Bilder `01…08-casting.jpg` und `01/02-dance-p1-candidate.jpg` bleiben als historischer Stand vom 15.09.

Profil-Upload Georg 15.09.: `profiles/kfb-pet-graft-driver.georg-2026-09-15.json` · 30337 B · sha256 `554a439558d1f8193c681faf630c1c48d7a5513eeb0d2a86b9322b93292c9a05`.

## Nachtrag 17.09.2026 · Cube-Pet-Gesicht und der richtige FB

Georgs Befund: »cube pet hat weder eye rig noch mund« und »falscher FB«. Beides zutreffend. Der Slot lud das GLB roh — Kenneys Augen blieben aufgebacken, ein Mund war nie da; der FB hing an der alten Fixture (petVersion 4). Der Prüfstand benutzt jetzt den Bauweg des Studios (v17/v18 `_buildEyeRig` + `_mountMouth`, Inventar §1.2) und Georgs Vertrag vom 17.09. als Vorgabe.

| Datei | sha256 | zeigt |
|---|---|---|
| `12-cube-eyerig.jpg` | `6088ac727a1cc9f6ba1d801a4fff590d78e0121f30c951dc8f56f28eadf2a609` | Hihi · Kenney-Augenschalen 1+2 gelöscht · EyeRig v6 (glossy-googly, Lider aus der Colormap abgetastet) · Mund in Ruhe |
| `13-cube-mouth-talk.jpg` | `d4c0b03e5f47433f7540e089b520b3bcbbaefa983716c0eb18eb2c0c874b54f5` | Hihi · PetMouth v1 im Talk-Burst (Decal sichtbar, Set male) |

Profil-Upload Georg 17.09.: `profiles/kfb-pet-graft-driver.georg-2026-09-17.json` · 30764 B · sha256 `166d6cc8508ecda9e7ae8f4aec1d562a0cc60292bb9579ced5b95a9eb760fadc` · kfb.pets/1 v1.2.9 · meta.contract 1.3.0 · petVersions.graft-driver 9. Ab jetzt die Vorgabe der Probe; `?contract=georg15` und `?contract=fixture` bleiben erreichbar.

Offen und bewußt nicht erfunden: die Augen- und Mundmaße stammen aus den globalen Blöcken (am Hasen getunt) — auf der Katze sitzen die Augen groß und der Mund tief. Ein `pets[]`-Eintrag für `cat` existiert nicht; er gehört ins Studio, nicht in den Prüfstand.

## Nachtrag 17.09.2026 (19:04) · doppeltes Augen-Rig

Georgs Befund am Bild: das Kätzchen trug zwei Augen-Rigs. Ursache war der Ladeaufruf, nicht ein Modul: `SETS.animals.mods = ['googly','emotes']` ist die Set-Vorgabe, also steckt sich `MODS.googly` bei `Character.load` ohne `mods: []` von selbst an — zusätzlich zu EyeRig v6. Jetzt erzwingt `qa/eye-source-guard.v1.js` die Aufrufform und zählt nach dem Aufbau nach; bei gemischten Quellen wird die Figur nicht gezeigt.

| Datei | sha256 | zeigt |
|---|---|---|
| `14-cube-single-eyesource.jpg` | `d44c459e7ee6435df6c8fa535a49bd0883dab77f9380a1b40eaccdc4eb414c19` | Hihi mit GENAU EINER Augenquelle · Protokoll: `{"ok":true,"sources":["eyerig"],"googly":false,"mods":[],"kenney":false,"geoReplaced":true,"eyes":2}` |

Regel, Erkennung und die offene Embed-Pflicht: `EYE_SOURCE_RULE.md`. Wächter: `qa/eye-source-guard.v1.js` · 5983 B · sha256 `b3edc2e88cf2e2717bf7a97e807d1ac2c81c103831a31603d06f9fe35be9bdb3`.

## Nachtrag 17.09.2026 · Augenquellen aller vier Bewohner (§4, Halt statt Meldung)

Gemessen wurde zweimal, und der erste Lauf war der falsche Ort.

**Zurückgezogen: 15–18** (`qa/eyesource-probe.html`). Der Prüfstand baut jeden Wirt nackt — Modul
plus Augen-Rig, ohne Mund, ohne Textur-Wäsche, ohne Bodenhöhe, ohne Recherchis Würfelflächen, ohne
Rollis Klorollen-Logik. Georg am Bild: »die sind alle buggy · das sind sachen, die in frankenstein
studio schon größtenteils gefixt waren«. Richtig. Die Augenzählung der Seite bleibt gültig (sie hängt
nur an den Augenmodulen), ihre Bilder sind kein Beleg für ein Aussehen. Dateien 15–18 gelöscht, damit
niemand sie als Zustand liest.

**Gültig: 19–22** — dieselbe Prüfung, aber IM Studio (`stage-first/src/KFB ToolBox Stage-First v1.dc.html`),
wo alle Fixes liegen. Der Wächter läuft dort in allen vier Ladewegen; keiner hat gehalten, also wirkt
überall genau eine Augenquelle.

| Bild | Bewohner (Rosterplatz) | im Bild zu sehen | Wächter |
|---|---|---|---|
| `19-studio-rolli.jpg` | Klo-Rolli (26, hanging) | Rolle, Halter, Augen-Rig, Mund | kein Halt |
| `20-studio-carl.jpg` | CapsuleCarl (25, capsule) | Augen-Rig + **aufgemalter Mund** + Schulterplatten | kein Halt |
| `21-studio-gothgirl.jpg` | GothGirl (32, biped) | vollständige Figur, 17 Materialzonen gemessen | kein Halt |
| `22-studio-recherchi.jpg` | Recherchi (34, htmlcube) | Augen, Nasenknopf, Mund, Würfelfläche »Frag Recherchi« | kein Halt |

Zusätzlich gemessen beim Studiostart: `state.eyePolicy.ok = true` — kein Character-Set führt eine
Augenquelle als Vorgabe (`checked: ['animals']`).

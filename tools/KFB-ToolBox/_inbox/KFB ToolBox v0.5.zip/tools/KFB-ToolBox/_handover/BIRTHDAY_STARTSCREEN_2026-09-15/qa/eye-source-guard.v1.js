/* kfb.eye-source-guard/1 — EINE Augenquelle pro Figur, nachweisbar.
 *
 * WARUM DAS EXISTIERT (Georg, 17.09.2026, am Bild gemessen: »kitten hat doppeltes augen-rig«):
 * Ein Cube-Pet kann sein Gesicht aus DREI unabhängigen Quellen bekommen. Sie sehen einzeln richtig
 * aus, zusammen ergeben sie doppelte Augen — und sie mischen sich still, ohne Fehlermeldung:
 *
 *   1 · `kenney`  — Kenneys aufgebackene Augen-Schalen IM body-Mesh (Geometrie, keine Textur).
 *                   Verschwinden nur, wenn `Character.load({face})` sie löscht (face.stripEyes).
 *   2 · `googly`  — der Mod `MODS.googly` aus `studio-v3/pet-library.v6.js` (flache Cel-Scheiben,
 *                   eigener Anker, eigenes Blinzeln). Er hängt sich SELBST an, weil
 *                   `SETS.animals.mods = ['googly','emotes']` die Vorgabe des Sets ist: wer
 *                   `load()` ohne `mods: []` aufruft, bekommt ihn, ohne ihn zu bestellen.
 *   3 · `eyerig`  — `studio-v12/pet-eye-rig.v6.js#EyeRig`: unsere Kugelaugen mit Lidern, Blinzeln,
 *                   Wimpern, Emotes. Das ist der Default der ToolBox.
 *
 * Der Vertrag sagt es bereits (kfb-pets.json `embed.verbote`): »Keine Zone schreibt eine eigene
 * Augen-Implementierung. Wer googly braucht, setzt face.pupil.form = "googly".« Diese Datei macht
 * daraus eine PRÜFUNG statt einer Bitte: `loadOpts()` liefert die einzige erlaubte Aufrufform,
 * `auditEyeSources()` zählt nach, was tatsächlich am Kopf hängt, `assertSingleEyeSource()` bricht
 * ab, bevor ein gemischtes Gesicht auf die Bühne kommt.
 *
 * Der Prüfstand nutzt das Modul; der Embed, den wir herausgeben, MUSS es ebenso nutzen (genau eine
 * Zeile nach dem Aufbau des Gesichts). Ohne Prüfung ist die Regel eine Fußnote, und die Fußnote
 * war der Dauerfehler.
 */

export const SCHEMA = 'kfb.eye-source-guard/1';

export const SOURCES = {
  kenney: 'Kenneys aufgebackene Augen-Schalen im body-Mesh (nicht gelöscht)',
  googly: 'MODS.googly aus pet-library.v6.js (Set-Vorgabe SETS.animals.mods)',
  eyerig: 'EyeRig v6 (studio-v12/pet-eye-rig.v6.js) — Default der ToolBox',
};

/** Die EINZIGE erlaubte Aufrufform von `Character.load` in der ToolBox.
 *  `mods: []` ist der Punkt: sonst zieht das Set seinen googly-Mod mit.
 *  (Dieselbe Form benutzt Studio v17/v18 in `loadPet`.) */
export function loadOpts(face, extra = {}) {
  return { recolor: null, ...extra, face: face || {}, mods: [] };   // mods zuletzt: nicht überschreibbar
}

/** Zählt die tatsächlich wirksamen Augenquellen an einem Cube-Pet-Host.
 *  ch  = studio-v3/pet-library.v6.js#Character (geladen)
 *  rig = EyeRig-Instanz oder null
 *  Rückgabe: { schema, ok, sources[], detail{} } — `ok` heißt: GENAU EINE Quelle. */
export function auditEyeSources(ch, opts = {}) {
  const rig = opts.rig || null;
  const sources = [];
  const detail = {};

  const body = (ch && ch._body) || null;
  const orig = body && body.userData && body.userData._faceOrigGeo;
  const strippedGeo = !!(body && orig && body.geometry !== orig);
  const kenney = !!body && !strippedGeo;
  detail.kenney = {
    active: kenney,
    bodyMesh: body ? (body.name || '(unbenannt)') : null,
    faceApplied: !!orig,
    geometryReplaced: strippedGeo,
    why: !body ? 'kein body-Mesh gefunden'
      : strippedGeo ? 'Augen-Schalen gelöscht (Character.load({face}) hat die Geometrie ersetzt)'
      : orig ? 'face-Block lief, hat aber nichts gelöscht (stripEyes aus, oder kein gespiegeltes Schalenpaar gefunden)'
      : 'kein face-Block übergeben — das GLB liegt roh auf der Bühne',
  };
  if (kenney) sources.push('kenney');

  const mods = (ch && ch._mods) || [];
  const googly = mods.indexOf('googly') >= 0 || !!(ch && (ch._eyes || ch._eyeRig));
  detail.googly = {
    active: googly, mods: mods.slice(),
    modRig: !!(ch && ch._eyeRig), modEyes: !!(ch && ch._eyes),
    why: googly ? 'Mod hängt am body-Mesh — load() wurde ohne mods: [] aufgerufen (oder googly ausdrücklich bestellt)' : 'nicht angesteckt',
  };
  if (googly) sources.push('googly');

  const eyerig = !!(rig && rig.eyes && rig.eyes.length);
  detail.eyerig = { active: eyerig, eyes: eyerig ? rig.eyes.length : 0, gen: (rig && rig.gen) || null, pupilStyle: (rig && rig.pupilStyle) || null };
  if (eyerig) sources.push('eyerig');

  return { schema: SCHEMA, ok: sources.length === 1, sources, expected: opts.expected || 'eyerig', detail };
}

/** Wie `auditEyeSources`, bricht aber ab, wenn nicht genau eine Quelle wirkt (oder die falsche).
 *  Aufrufen, BEVOR die Figur gezeigt wird. */
export function assertSingleEyeSource(ch, opts = {}) {
  const a = auditEyeSources(ch, opts);
  const want = a.expected;
  if (!a.ok || (want && a.sources[0] !== want)) {
    const e = new Error(
      `[eye-source-guard] ${a.sources.length} Augenquelle(n) aktiv: ${a.sources.join(' + ') || 'keine'} — erwartet: ${want}. `
      + Object.keys(SOURCES).filter((k) => a.detail[k] && a.detail[k].active).map((k) => `${k}: ${a.detail[k].why || SOURCES[k]}`).join(' | ')
      + ` Abhilfe: Character.load(set, id, loadOpts(lib.face)) — mods: [] erzwingen, face-Block mitgeben, EyeRig danach bauen.`);
    e.audit = a;
    throw e;
  }
  return a;
}

/** Graft-Pfad (FrizzleBob auf KayKit): der Spenderkopf bringt eigene Augen mit.
 *  `graft-mount.v1.js` entfernt sie über `donoreyes.v1.js` — hier wird nachgezählt, nicht vertraut. */
export function auditGraftEyes(handle) {
  const donorStripped = !!(handle && handle.donorEyes && handle.donorEyes.status === 'OK');
  const eyerig = !!(handle && handle.rig && handle.rig.eyes && handle.rig.eyes.length);
  const sources = [];
  if (!donorStripped) sources.push('donor');
  if (eyerig) sources.push('eyerig');
  return {
    schema: SCHEMA, ok: sources.length === 1 && sources[0] === 'eyerig', sources,
    detail: { donorStripped, donorReport: (handle && handle.donorEyes) ? (handle.donorEyes.status || null) : null, eyes: eyerig ? handle.rig.eyes.length : 0 },
  };
}

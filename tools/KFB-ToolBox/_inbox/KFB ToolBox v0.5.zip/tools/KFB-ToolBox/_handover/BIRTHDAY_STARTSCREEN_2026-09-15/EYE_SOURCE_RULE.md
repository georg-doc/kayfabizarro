# Augenquellen · eine pro Figur · Regel + Prüfung

**Anlaß:** Georg, 17.09.2026, am Bild gemessen — »kitten hat doppeltes augen-rig« und »cube pet hat 3 augen-optionen (original, googly eye und unser default eye-rig → das darf niemals vermischt werden)«. Der Fehler war kein Zufall, sondern eine Vorgabe im Quellcode, auf die niemand geprüft hat.

## 1 · Die drei Quellen (SOURCE FACT, gelesen in `studio-v3/pet-library.v6.js`)

| Quelle | Wo sie herkommt | Wie sie verschwindet |
|---|---|---|
| `kenney` | Kenneys Augen sind **Geometrie im body-Mesh** (getrennte Schalen, kein gemaltes Gesicht — die colormap ist nur ein Farbstreifen-Atlas). | Nur durch `Character.load(set, id, { face })`: `face.stripEyes` + `face.eyeShell` löschen das gespiegelte Schalenpaar (zPlane 0,635 · minTris 25 · bei allen 24 Pets genau 2 Schalen). |
| `googly` | `MODS.googly` — flache Cel-Scheiben (Ink-Ring · Sclera · Pupille), eigener Anker, eigenes Blinzeln, eigenes Gaze-Wandern. Hing sich **selbst** an, weil `SETS.animals.mods = ['googly','emotes']` die **Set-Vorgabe** war. **Seit §4 nicht mehr voreingestellt** (`mods: ['emotes']`); er kommt nur auf Bestellung. | Nicht bestellen. `mods: []` beim Laden bleibt die vorgeschriebene Form (`loadOpts`), damit auch ein späterer Vorgaben-Rückfall nichts anstecken kann. |
| `eyerig` | `studio-v12/pet-eye-rig.v6.js#EyeRig` — Kugelaugen mit Lidern, Blinzeln, Wimpern, Emotes, Splay, Konvergenz. **Default der ToolBox**, derselbe Bauweg wie im Studio v17/v18 (`_buildEyeRig`). | `rig.dispose()`. |

Warum es still schiefgeht: `MODS.googly` schreibt `ch._eyeRig` / `ch._eyes`, `EyeRig` hält seine Augen in `rig.eyes` und fragt den Host nie. Beide bauen an dasselbe body-Mesh, keiner merkt den anderen. Kenneys Schalen bleiben zusätzlich stehen, wenn kein `face`-Block mitkommt. Drei Quellen, kein Widerspruch, ein Gesicht mit doppelten Augen.

## 2 · Die Regel

1. **Genau eine Quelle pro Figur.** In der ToolBox ist das `eyerig`.
2. **`Character.load` wird nie ohne `mods: []` und ohne `face` aufgerufen.** Dafür gibt es eine Aufrufform: `loadOpts(lib.face)`.
3. **Nach dem Aufbau wird gezählt, nicht vertraut** — `assertSingleEyeSource(ch, { rig, expected: 'eyerig' })` bricht ab, bevor eine gemischte Figur gezeigt wird.
4. Der Vertrag sagt es schon (`kfb-pets.json` → `embed.verbote`): »Keine Zone schreibt eine eigene Augen-Implementierung. Wer googly braucht, setzt `face.pupil.form = "googly"`.« Diese Regel macht daraus eine Prüfung.
5. **Der Graft-Pfad hat dieselbe Pflicht:** der KayKit-Spenderkopf bringt eigene Augen mit; `graft-mount.v1.js` entfernt sie über `donoreyes.v1.js`. `auditGraftEyes(handle)` zählt nach (`donorEyes.status === 'OK'` + genau ein Rig).

## 3 · Die Prüfung

`qa/eye-source-guard.v1.js` (`kfb.eye-source-guard/1`, 5983 B, sha256 `b3edc2e88cf2e2717bf7a97e807d1ac2c81c103831a31603d06f9fe35be9bdb3`) — der Prüfstands-Beleg, bleibt unverändert liegen. **Die Wahrheit ist seit §4 der Quellbaum:** `stage-first/src/petstudio-v9/studio-v3/eye-source-guard.v1.js` (dieselben vier Funktionen plus `auditEmbedEyePolicy` / `assertEmbedEyePolicy` / `EYE_SOURCE_MODS`).

```js
import { loadOpts, assertSingleEyeSource } from './eye-source-guard.v1.js';
await ch.load('animals', petId, loadOpts(lib.face));   // mods: [] ist nicht überschreibbar
const rig = new EyeRig(ch, { /* Werte aus lib.eyeRig / lib.face.eye */ }); rig.build();
assertSingleEyeSource(ch, { rig, expected: 'eyerig' }); // wirft, statt ein Doppel-Rig zu zeigen
```

Erkennung ohne Ratespiel: `kenney` = `body.geometry === body.userData._faceOrigGeo` (Geometrie nicht ersetzt) · `googly` = `ch._mods` enthält `googly` oder `ch._eyes`/`ch._eyeRig` existieren · `eyerig` = `rig.eyes.length`.

## 4 · Pflicht für den Embed (AUSGEFÜHRT 17.09.2026, 20:4x · im Quellbaum)

Georgs Auftrag: »auch beim embed, das wir rausgeben, muss dieser Dauer-Fehler 100% bullet proof verhindert werden.« Die drei Schritte sind jetzt im Quellbaum (`stage-first/src/`), nicht mehr nur im Prüfstand:

1. **Wächter im Quellbaum** — `petstudio-v9/studio-v3/eye-source-guard.v1.js` (PROMOTED, 8 520 B). Das Studio lädt ihn beim Start (`this._EyeGuard`); fällt der Import aus, sagt es die Konsole und die Regel bleibt trotzdem geschrieben.
2. **Die Vorgabe ist umgedreht** — `SETS.animals.mods = ['emotes']` (vorher `['googly','emotes']`). `emotes` sind Comic-Pips, keine Augen. googly ist nicht weg, nur nicht mehr voreingestellt: `face.pupil.form = 'googly'` oder ausdrücklich `opts.mods: ['googly']`. Die Auflösung steht in **einer** exportierten Funktion, `resolveMods(set, opts)` — ein ausdrücklich übergebenes `opts.mods` gilt vollständig und allein, sonst Set-Vorgabe plus Bestellung aus dem face-Block.
3. **Zwei Prüfungen, zwei Zeitpunkte:**
   · `assertEmbedEyePolicy(SETS)` prüft die **Vorgabe** — kein Set darf eine Augenquelle führen. Das ist die Abnahmebedingung des Bundles (Fehlschlag = kein Build) und läuft zusätzlich beim Start jeder Zone. Sie fängt den Fehler, bevor jemand ihn machen kann.
   · `assertSingleEyeSource(ch, { rig, expected: 'eyerig' })` prüft das **Ergebnis** am gebauten Gesicht. Im Cube-Pet-Pfad (`loadPet`) wirft sie: die Figur wird unsichtbar gestellt und der Ladefehler steht in der Oberfläche (`loadErr`) — ein gemischtes Gesicht kommt nicht auf die Bühne.

**Gemessen und nachgezogen (17.09.2026, 21:12 UTC).** Der Halt galt zuerst nur für Cube-Pets; für die anderen Klassen stand eine Meldung, weil die Zählung an ihnen nicht gemessen war. Georgs Vorgabe: »erst messen, dann halten«. Prüfstand `qa/eyesource-probe.html` baut jeden Wirt mit SEINEM Modul und zählt zweimal (vor und nach dem Schnitt des Studios) — Messwerte in `qa/eyesource-probe.json`. **Die Bilder dazu sind zurückgezogen** — der Prüfstand baut die Wirte nackt (kein Mund, keine Textur-Wäsche, keine Bodenhöhe, keine Würfelflächen, keine Klorollen-Logik), seine Figuren waren kaputt und taugten nicht als Beleg. Gültige Belege 19–22 kommen aus dem Studio, wo die Fixes liegen (`qa/QA_EVIDENCE.md`). Die Augenzählung selbst gilt in beiden Läufen:

| Wirt | Modul | nachher | Urteil |
|---|---|---|---|
| Rolli | `studio-v10/KloRolli.js` | eyerig · 2 Augen | HALT MÖGLICH |
| GothGirl | `frizzlegraft-v1/goth-biped.v1.js` | eyerig · 2 Augen | HALT MÖGLICH |
| Carl | `lab-v6/carlrig-mount.v1.js` | eyerig · 2 Augen | HALT MÖGLICH |
| Recherchi | `frizzlegraft-v1/recherchi-mount.v1.js` | eyerig · 2 Augen | HALT MÖGLICH |

Alle vier Stellen halten jetzt (`assertSingleHostEyeSource`, Gruppe unsichtbar + Fehler geworfen): `_loadBiped` · `_loadHanging` · `_loadCapsule` (mountCarl) · `_loadHtmlCube` (mountRecherchi). Der Graft-Pfad behält zusätzlich `auditGraftEyes(handle)`.

**Vierte Quelle, neu im Wächter:** ein KayKit-Wirt bringt Originalaugen auf zwei Wege mit — als eigene NETZE am Kopfknoten (Materialien `EyeColor`/`White`/`Black`, gemessen an FrizzleBob: 60/20/112 Dreiecke) oder als GEOMETRIE-INSELN im Kopfnetz (GothGirl: Inseln 6+7). `auditDonorMeshes` misst die Netze selbst; die Inseln zählt das jeweilige Modul, weil nur dort geprüft ist, welche Insel ein Auge ist. Ein Wächter, der auf einem fremden Kopf nach Inseln rät, ist kein Wächter.

**Drei Fehler dieser Runde, alle notiert statt geglättet:**
1. `SETS.animals.mods` stand seit SPRINT 10 auf `['googly','emotes']`, ohne dass ein Aufrufer es bestellt hätte — der Dauerfehler selbst.
2. Der erste Prüfstandslauf meldete für Carl und Recherchi »0 Quellen« — er griff auf `handle.face.eye`, das Feld heißt `handle.face.eyeRig`.
3. **Der Prüfstand war der falsche Ort für Bilder.** Er setzt den Wirt selbst zusammen und lässt dabei alles weg, was das Studio zusätzlich tut — Mund, Textur-Wäsche, Bodenhöhe, Recherchis Würfelflächen, Rollis Klorollen-Logik. Ergebnis: vier kaputte Figuren als »Belege«. Ein Prüfstand, der den Wirt neu baut, ist eine zweite Wahrheit. **Regel daraus: Augenquellen werden IM Studio belegt; die Probe darf zählen, nicht darstellen.**

Es bleibt dabei: **jede neue Zone, die ein Pet-Gesicht baut, importiert den Wächter.** Ohne Prüfung ist die Regel eine Fußnote — und die Fußnote war der Fehler.

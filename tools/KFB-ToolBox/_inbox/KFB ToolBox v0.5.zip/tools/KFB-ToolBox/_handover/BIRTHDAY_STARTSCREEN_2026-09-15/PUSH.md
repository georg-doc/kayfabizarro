# PUSH · Birthday-Consumer-Handoff · 15.09.2026

Schreibweg von hier weiterhin verweigert: `POST /git/refs` → `403 Resource not accessible by integration` (gemessen 06:52 UTC, wie am Vortag). Fehlendes Recht: **Contents: Read and write** auf der App-Installation. Zwei Wege:

**A · Recht nachziehen**, dann läuft der Push von hier (Branch `toolbox/birthday-casting-2026-09-15`, danach PR nach `main`).

**B · Von Georgs Rechner** — ZIP dieses Ordners entpacken, dann:

    cd kayfabizarro
    git checkout -b toolbox/birthday-casting-2026-09-15 main
    # Ordner aus dem ZIP nach tools/KFB-ToolBox/_handover/BIRTHDAY_STARTSCREEN_2026-09-15/ legen
    # tools/KFB-ToolBox/CHANGELOG.md aus dem ZIP übernehmen (additiv, Obermenge des Repo-Stands e61c28e3)
    git add tools/KFB-ToolBox/_handover/BIRTHDAY_STARTSCREEN_2026-09-15 tools/KFB-ToolBox/CHANGELOG.md
    git commit -m "ToolBox · Birthday-Consumer-Handoff: Casting FrizzleBob + GothGirl (Idle/Focus/Select/Rest), Dance P1, Hihi Slot"
    git push -u origin toolbox/birthday-casting-2026-09-15

## Dateien

| Pfad (unter `tools/KFB-ToolBox/`) | Bytes | Art |
|---|---|---|
| `_handover/BIRTHDAY_STARTSCREEN_2026-09-15/RETURN_BIRTHDAY_CONSUMER.md` | 9 453 | Return Contract |
| `_handover/BIRTHDAY_STARTSCREEN_2026-09-15/PUSH.md` | — | dieses Blatt |
| `_handover/BIRTHDAY_STARTSCREEN_2026-09-15/profiles/kfb-pet-graft-driver.georg-2026-09-15.json` | 30 337 | Georgs Upload, sha256 `554a4395…9a05` |
| `_handover/BIRTHDAY_STARTSCREEN_2026-09-15/qa/casting-probe.html` | 20 438 | Meßseite |
| `_handover/BIRTHDAY_STARTSCREEN_2026-09-15/qa/casting-probe.json` | 16 374 | Meßwerte |
| `_handover/BIRTHDAY_STARTSCREEN_2026-09-15/qa/QA_EVIDENCE.md` | 2 334 | sha256 der Bilder |
| `_handover/BIRTHDAY_STARTSCREEN_2026-09-15/qa/*.jpg` | 12 Dateien | Standbilder (Pins in QA_EVIDENCE) |
| `CHANGELOG.md` | 20 771 | additiv, enthält den Repo-Eintrag 14.09. unverändert plus 14.09.–15.09. |
| `site/KFB ToolBox.dc.html` · `site/index.html` | — | nur ein Nav-Link »Birthday-Casting« ergänzt (optional mitnehmen) |

`START_HERE.md` in diesem Ordner ist Georgs Auftrag vom Repo (`1139a94f…`) — nicht verändert, nicht mitschieben.

---

## Nachtrag 17.09.2026 · Augenquellen-Regel §4 (Quellbaum)

Schreibweg von hier unverändert verweigert (`403 Resource not accessible by integration`) — der Push geht über Georgs Rechner. Drei Dateien, ein Commit:

    cd kayfabizarro
    git checkout -b toolbox/eye-source-guard-2026-09-17 main
    # aus dem ZIP übernehmen:
    #   tools/KFB-ToolBox/stage-first/src/petstudio-v9/studio-v3/eye-source-guard.v1.js   (NEU)
    #   tools/KFB-ToolBox/stage-first/src/petstudio-v9/studio-v3/pet-library.v6.js        (geändert)
    #   tools/KFB-ToolBox/stage-first/src/KFB ToolBox Stage-First v1.dc.html              (geändert)
    #   tools/KFB-ToolBox/_handover/BIRTHDAY_STARTSCREEN_2026-09-15/EYE_SOURCE_RULE.md    (geändert)
    #   tools/KFB-ToolBox/_handover/BIRTHDAY_STARTSCREEN_2026-09-15/CHANGELOG.toolbox.md  (geändert)
    git add tools/KFB-ToolBox/stage-first/src tools/KFB-ToolBox/_handover/BIRTHDAY_STARTSCREEN_2026-09-15
    git commit -m "ToolBox · Augenquellen: eine Quelle pro Figur, geprueft statt gebeten (SETS.animals.mods ohne googly, eye-source-guard im Quellbaum)"
    git push -u origin toolbox/eye-source-guard-2026-09-17

**Ein Blick vor dem Merge** (das ist die Zeile, auf die es ankommt):

    grep -n "mods: \['emotes'\]" tools/KFB-ToolBox/stage-first/src/petstudio-v9/studio-v3/pet-library.v6.js

**Wenn der Push von hier laufen soll**, fehlt der App-Installation genau ein Recht: **Contents: Read and write**. Lesen (Baum, Dateien, Vergleich zweier Commits) geht schon.

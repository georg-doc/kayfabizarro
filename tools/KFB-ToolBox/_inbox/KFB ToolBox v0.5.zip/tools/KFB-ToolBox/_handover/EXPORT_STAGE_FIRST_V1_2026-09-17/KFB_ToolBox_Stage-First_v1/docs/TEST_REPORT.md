# TEST_REPORT · Exportrevision 2026-09-17

**Getestet wurde der Exportbaum**, nicht der Projektbaum: Einstieg `KFB_ToolBox_Stage-First_v1/src/KFB ToolBox Stage-First v1.dc.html`, geöffnet in der Claude-Design-Vorschau (Chromium), `three@0.160.0` über Import-Map.

**Was dieser Bericht NICHT ist:** ein Kaltstart aus einem entpackten ZIP auf einem fremden Rechner. Das kann ich von hier nicht ausführen. Der Lauf unten ist ein Kaltstart aus einem **neuen Pfad** mit **gepatchten Schriften** — er beweist Modulschluss und Assetauflösung, nicht das Verhalten hinter `file://`.

| Test | Ergebnis | Messwert |
|---|---|---|
| Boot | **PASS** | `window.__TOOLBOX` vorhanden, `ready: true`, `loadErr: null` |
| Bühne sichtbar | **PASS** | Figur gerendert, Status `✓ Graft · Driver · Driver.glb · raw · 23 bones · ×0,42` |
| Kritische Module | **PASS** | keine »Modul fehlt«-Warnung für Pflichtmodule; `_EyeGuard` geladen |
| Augenquellen-Vorgabe | **PASS** | `state.eyePolicy.ok === true`, `checked: ['animals']`, `offenders: []` |
| Schriften über RAW | **PASS** | `document.fonts.load("16px 'Fonteys PRO'")` → 1 geladen; `'Georg Comic'` → 1 geladen |
| Roster | **PASS** | 35 Einträge (kein reduzierter Demo-Roster) |
| Actor · Klo-Rolli (hanging) | **PASS** | `✓ Klo-Rolli · GLB Repo (raw) · Rolle ×4,13 · Modell-Blatt weg (10/62)` · kein `loadErr` |
| Actor · CapsuleCarl (capsule) | **PASS** | `✓ CapsuleCarl` · kein `loadErr` |
| Actor · GothGirl (biped) | **PASS** | `✓ GothGirl · GothGirl.glb · raw · 23 bones · ×0,46` · kein `loadErr` |
| Actor · Recherchi (htmlcube) | **PASS** | `✓ Recherchi · sechs Flächen · 6/6 gültig · foreignObject → CanvasTexture` |
| Augenquellen-Halt greift nicht fälschlich | **PASS** | vier Ladewege ohne Abbruch; vorher am Studio gemessen: je 2 Augen, eine Quelle |
| Assetladen (Soll/Ist) | **TEILWEISE** | die geladenen Figuren holten ihre GLBs aus dem Repo (`raw` in den Statusmeldungen). Eine vollständige Soll/Ist-Zählung über alle 31 Assets ist **NOT_RUN**. |
| Konsole / Netzwerk | **TEILWEISE** | keine Fehler im geprüften Ablauf; ein vollständiges Netzwerkprotokoll über alle Reiter ist **NOT_RUN** |
| Navigation Actor→Face→Pose→Motion→Voice→Stage | **NOT_TESTED** | Reiter nicht einzeln durchgeklickt |
| Zustands-Roundtrip (Profil exportieren → neu laden → importieren) | **NOT_TESTED** | — |
| Resource Picker Preview/Accept/Revert | **NOT_TESTED** | — |
| Pose speichern/neu laden | **NOT_TESTED** | — |
| Motion-Wiedergabe (Idle + Locomotion + dritter Clip) | **NOT_TESTED** | — |
| Voice / Talk / Audio | **NOT_TESTED** | Ton ist in dieser Umgebung nicht abnehmbar; Audio-Manifest fehlt (SOURCE_GAP-2) |
| Bühne: platzieren → transformieren → speichern → neu laden | **NOT_TESTED** | — |
| Desktop-Breite | **PASS** | Vorschau-Breite Desktop |
| ~832 px Splitscreen | **NOT_TESTED** | nicht gemessen |

## Vorgelagerte Messung (nicht dieser Export, aber derselbe Code)
Am Projektbaum, 17.09. 21:2x UTC: alle vier Bewohner im Studio geladen, Augenquellen-Wächter hält nicht, `eyePolicy.ok = true`. Bildbelege liegen im Claude-Projekt (nicht im Paket, auf Ansage »große Files weglassen«):
`tools/KFB-ToolBox/_handover/BIRTHDAY_STARTSCREEN_2026-09-15/qa/19-studio-rolli.jpg` · `20-studio-carl.jpg` · `21-studio-gothgirl.jpg` · `22-studio-recherchi.jpg`; Messwerte in `docs/handover/BIRTHDAY_STARTSCREEN_2026-09-15/qa/eyesource-probe.json`.
Der QA-Lauf vom 16.09. (13 PASS / 0 FAIL) steht in `SOURCE_MAP.json`; seine Bilder ebenfalls nur im Projekt.

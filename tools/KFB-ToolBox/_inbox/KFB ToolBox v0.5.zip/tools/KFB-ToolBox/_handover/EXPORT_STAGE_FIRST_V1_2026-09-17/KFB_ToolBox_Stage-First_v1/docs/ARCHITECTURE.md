# ARCHITECTURE · aus dem Code abgeleitet

Kein Framework-Diagramm, sondern wer was besitzt. Alles unten ist im Quellcode nachlesbar; wo ich es nicht belegen konnte, steht es so.

| Rolle | Eigentümer | Datei |
|---|---|---|
| Bühne (Renderer, Szene, Kamera, Licht, RoomEnvironment) | die Blatt-Klasse selbst | `src/KFB ToolBox Stage-First v1.dc.html` (`componentDidMount` → `_boot`) |
| Modul-Anker | `window.__KFB_MODBASE = petstudio-v9/` | ebd., `<helmet>` Z. 11 |
| Boden / Maßfläche | `ground-plane.v2` (Zone) + `pet-metrics` (Pet-Maß) | `petstudio-v9/studio-v12/ground-plane.v2.js`, `studio-v7/pet-metrics.v1.js` |
| Actor · Cube-Pets | `pet-library.v6.js#Character` (Laden, Clips, Mods, Recolor, Face-Chirurgie) | `petstudio-v9/studio-v3/pet-library.v6.js` |
| Actor · Zweibeiner | `frizzlebob.v4a` · `graft-biped.v1` · `goth-biped.v1` (erbt von Graft) | `petstudio-v9/studio-v12/`, `frizzlegraft-v1/` |
| Actor · Requisiten | `KloRolli.js` (hängend) · `carlrig-mount.v1` (Kapsel) · `recherchi-mount.v1` (HTML-Würfel) | `studio-v10/`, `lab-v6/`, `frizzlegraft-v1/` |
| Gesicht · Augen | `pet-eye-rig.v6.js#EyeRig` — **einziger** Augen-Eigentümer der ToolBox | `petstudio-v9/studio-v12/pet-eye-rig.v6.js` |
| Gesicht · Wächter | `eye-source-guard.v1.js` — zählt Augenquellen, hält bei Mischung | `petstudio-v9/studio-v3/eye-source-guard.v1.js` |
| Gesicht · Mund/Braue/Nase/Bart | `pet-mouth.v1` · `browfit.v1`/`brow-rig.v2` · `pet-nose.v2` · `pet-moustache.v1` | `studio-v3/`, `lab-v6/`, `studio-v12/` |
| Pose | `pose-rig.v1.js` (Gelenkwinkel, Zweiknochen-Löser, Sitzkontakt) | `petstudio-v9/studio-v13/pose-rig.v1.js` |
| Motion / Mixer | `THREE.AnimationMixer` in `Character` bzw. im Zweibeiner-Modul; Clip-Herkunft + Bindungsbericht in `anim-audit.v1`/`anim-map.v1`/`anim-contract.v1` | `frizzlegraft-v1/`, `lab-v2/sources.js` |
| Voice / Blasen | `bubble-shaper.v3` + `edge-treatment.v1` + `bubble-kiss.v1` + `bubble-tail.v1`; Mundbewegung über `pet-mouth` (Viseme) | `studio-v7/`, `studio-v9/`, `podcast-v2/` |
| Audio | `kfb-pinball-audio.js` — **Manifest `kfb-pinball-sfx.json` fehlt im Baum** (SOURCE_GAP) | `petstudio-v9/kfb-pinball-audio.js` |
| Zustand / Sitzung | `pet-session.v1` (Sitzung) + `contract-guard.v1` (wer überstimmt wen) + `pad-contract`/`ground-contract` | `studio-v7/`, `studio-v8/`, `studio-v9/` |
| Serializer (Import/Export) | `pet-session.v1` + die `toPets1`-Wege im Blatt (kfb.pets/1) | ebd. |
| Resource Picker / Library Drawer | im Blatt selbst (`_sfPick`, `_sfRoster`, `sfPreview`/`sfPin` — Browse → Preview → Accept/Revert) | `src/KFB ToolBox Stage-First v1.dc.html` |
| Asset-Auflösung | `RAW`-Konstanten je Modul + `assets: { raw(path) }` in den Zweibeiner-Modulen | `pet-library.v6.js`, `lab/assets.js`, `_loadBiped` |
| Build / Deploy-Einstieg | keiner — das `.dc.html` **ist** der Einstieg | — |

## Zwei Hausregeln, die man am Code sieht
**Eine Zahl, ein Eigentümer.** Bühnengröße, Bodenhöhe, Augenanker: jede Größe wird nach dem Laden an genau einer Stelle festgeschrieben. Die Kommentare nennen die Fehler, die dazu geführt haben (gecachtes GLB doppelt skaliert, Waffe verfälscht die Fußmessung, Blatt fällt unter die Platte).
**Gezählt, nicht vertraut.** Wo etwas still schiefgehen kann, steht eine Prüfung statt einer Bitte: `eye-source-guard`, `contract-guard`, `anim-audit` (Track-Bindung), `assertSingleHostEyeSource`.

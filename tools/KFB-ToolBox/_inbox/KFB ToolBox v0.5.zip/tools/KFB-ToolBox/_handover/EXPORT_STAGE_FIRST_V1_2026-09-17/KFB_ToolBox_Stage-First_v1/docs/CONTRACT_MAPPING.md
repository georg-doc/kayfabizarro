# CONTRACT_MAPPING

**Nichts umgeschrieben.** Dieses Blatt bildet die vorhandenen Formate ab, wie Briefing §9 es erlaubt.

## Verträge im Paket
| Vertrag | Datei | Eigentümer | Rolle in Stage-First |
|---|---|---|---|
| `kfb.pets/1` | `src/petstudio-v9/studio-v3/kfb-pets.json` (+ Profile in `profiles/`) | bestehend, **nicht** verschoben | Actor/Profile: Roster, Gesichtsblock, Augen-/Mund-/Brauen-Werte, Graft-Naht, Pose |
| Shared Pet Library | `media/3D_Assets/pet-LIBRARY.json` (Repo, Blob `7005d713c9e8`) | Repo | Emotes + Gesichtsblock; wird **gelesen**, nie mit WIP-Feldern überschrieben |
| `kfb.motion-library/1` | `media/3D_Assets/motion-LIBRARY.json` (Repo, `c1ce785ed443`) | Repo | Clipvertrag der Cube-Pets |
| `kfb.pose/0.1` | `src/petstudio-v9/studio-v13/pose-rig.v1.js#SCHEMA` | ToolBox | Gelenkwinkel + Presets |
| `kfb.eye-source-guard/1` | `src/petstudio-v9/studio-v3/eye-source-guard.v1.js` | ToolBox (neu 17.09.) | eine Augenquelle je Figur, als Prüfung |
| `kfb.carlrig-mount/1` · `kfb.headgraft/0.1` · `kfb.ears/0.2` · `kfb.gothbiped/1` | `lab-v6/`, `frizzlegraft-v1/` | ToolBox | Graft- und Requisiten-Bauwege |
| Ground/Pad-Verträge | `studio-v8/ground-contract.v1.js`, `studio-v9/pad-contract.v1.js` | ToolBox | Bodenhöhe und Anker als Vertragsblock |

## Abbildung auf den A0-Assembly-Contract
Nur Abbildung — die internen Formate bleiben, wie sie sind.

| A0 | Entspricht in Stage-First | Fundstelle |
|---|---|---|
| `AssetRef` | `SETS[*].urlPattern` + `pets[].modelId`/`glb` + die `RAW`-Konstanten | `pet-library.v6.js`, `ASSET_MANIFEST.json` |
| `TransformSlot` | `pets[].eye.anchor` · `pad`-Anker · `graft.neck`/`size` · Wurzelskalierung je Klasse | `kfb-pets.json`, `pad-contract.v1.js` |
| `Surface` | `face.stripEyes`/`stripSnout`/`facet` · Materialzonen (`matzones`, `headzones`) · `reskin: 'colormap'` | `pet-library.v6.js`, `frizzlegraft-v1/` |
| `Connector` | `faceCtx()`/`eyeCtx()`/`mouthCtx()` — der Wirt gibt eine Gruppe mit einem Netz `body`, das Gesicht hängt sich daran | `KloRolli.js`, `goth-biped.v1.js`, `recherchi-mount.v1.js` |
| `RecipeEnvelope` | ein `pets[]`-Eintrag samt `eye`/`mouth`/`brow`/`nose`/`pose`/`graft` = das Rezept einer Figur | `kfb-pets.json`, `profiles/*.json` |

## Grenzen, die dieser Export nicht überschreitet
Registry/Librarian **entdeckt** Kandidaten; ob ein Kandidat zu einem Rig paßt, entscheidet das empfangende Modul (`anim-audit.v1` zählt Track-Bindungen, `carl-contract.v1` prüft Teile). Stage-First trifft diese Entscheidung nicht vorweg — und baut keine zweite Registry.

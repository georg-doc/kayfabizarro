> **BERICHTIGT 2026-09-18** durch den Intake (`_handover/STAGE_FIRST_V1_INTAKE_2026-09-18/START_HERE.md`) und die Asset-Schließung im Quellbaum. Punkte 1–3 unten sind **erledigt**; sie bleiben stehen, damit der Weg nachlesbar ist. Aktueller Stand: `_handover/STAGE_FIRST_V1_PROMOTION_2026-09-18/PROMOTION_MANIFEST.json`.
>
> - **#1 Audio-Manifest:** Quelle belegt (Blob `5f7b52e2666a…`), `manifestUrl` zeigt darauf. **Nicht** rekonstruiert. Ton bleibt `NOT_TESTED`.
> - **#2 Schriften:** auf Commit `eabc87255ee3da6283f9d438390454d70e9d2e55` gepinnt, 34 URLs.
> - **#3 FrizzleBob_Yellow:** existiert im Repo (`tools/KFB-ToolBox/kfb-rigs-embed-v3/…`, Blob `e0a757ec…`). Meine Aussage »kein Treffer über 8 647 Dateien« war falsch — die Suche lief über einen Filter, der den Treffer verdeckte. Code lädt jetzt die Repo-Quelle.
> - **NEU #8:** das Audio-Manifest trägt intern selbst eine `baseUrl` auf `main` — beim Deployment mitpinnen.
> - **NEU #9:** die Birthday-Unterlagen unter `docs/handover/BIRTHDAY_STARTSCREEN_2026-09-15/` sind **ARCHIVED HISTORY** (Georg, 18.09.). Nur die Augenquellen-Regel und die gemessenen Actor-Daten gelten weiter.

# KNOWN_ISSUES

## 1 · SOURCE_GAP · Audio-Manifest fehlt
`src/petstudio-v9/kfb-pinball-audio.js` lädt `./kfb-pinball-sfx.json`. Die Datei liegt **nicht** im Baum. Im Repo vorhanden: `skills/KFB PetStudio/KFB Pet Studio v9-1/pet-studio-v9_2026-08-28_ws0-rehome/kfb-pinball-sfx.json` (18 058 B, Blob `5f7b52e2666a`). Folge: Audio-Pfad `BLOCKED`. **Nicht rekonstruiert** — eine aus der Dokumentation nachgebaute Klangliste wäre eine Erfindung.

## 2 · Schriften hängen an einem beweglichen Zweig
Die `@font-face`-URLs zeigen auf `…/main/…`. `main` bewegt sich. Für den Betrieb auf einen Commit pinnen oder — besser — same-origin unter `/fonts/` ausliefern und die URLs auf `./fonts/` kürzen (Rückweg steht als Kommentar über dem ersten `@font-face`).

## 3 · `FrizzleBob_Yellow.gltf` hat keine GitHub-Quelle
Gesucht über 8 647 Repo-Dateien, kein Treffer. Liegt deshalb im Paket und ist als `NEW_ASSET_REQUIRES_GITHUB_IMPORT` markiert. Bis zum Import ist der Spenderkopf (Schädel + Ohren) an eine Datei gebunden, die nur in diesem Paket existiert.

## 4 · Roster-Indizes sind nicht stabil
Im Projektbaum lag Klo-Rolli auf Platz 26, im Exportbaum auf 27 (GothGirl rutschte auf 26). Der Roster entsteht aus Vertrag + Profilen; wer nach Index adressiert, adressiert falsch. **Immer nach `id`**: `roster.findIndex(p => p.id === 'klo-rolli')`.

## 5 · `three` kommt aus dem Netz
Import-Map auf `unpkg.com/three@0.160.0`. Ohne Netz startet kein Blatt. Für den Betrieb: three same-origin ausliefern und die Import-Map umstellen.

## 6 · Was ungeprüft ist, ist ungeprüft
`FEATURE_PARITY.md` hat viele `NOT_TESTED`. Das ist kein Versehen: Pose, Motion, Voice, Szene-Roundtrip und der Resource Picker sind am Exportbaum nicht bedient worden. Der Code ist da; die Abnahme fehlt.

## 7 · Studio v18 ist Donor, nicht Ziel
`src/KFB FrankenStein Studio v18.dc.html` trägt Fixes, die im Stage-First-Blatt noch nicht alle stehen (u. a. Fein-Arbeit an Mund, Textur-Wäsche, Bodenhöhe). Wer Stage-First weiterbaut, holt sie **von dort** — und baut sie nicht neu.

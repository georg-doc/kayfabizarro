# DEPLOYMENT · für den Web Lead

Kein Buildschritt. Kein npm. Kein Bundler. Der Browser-Einstieg ist eine Datei.

## Einstieg und Wurzel
| | |
|---|---|
| Browser-Einstieg | `src/KFB ToolBox Stage-First v1.dc.html` |
| Build-Wurzel | identisch mit der Quellwurzel (`KFB_ToolBox_Stage-First_v1/`) — Source **ist** Build |
| Base-Pfad | beliebig, aber **der Ordnerbaum muss erhalten bleiben**: der Einstieg setzt `window.__KFB_MODBASE = new URL('petstudio-v9/', location.href)` und löst alle Studio-Module dagegen auf |
| Laufzeit neben jedem Blatt | `support.js` (dreimal im Paket, identischer Hash — das ist Absicht) |

## Pflichten
1. **ES-Module über HTTP ausliefern.** `file://` scheitert an CORS für `import()`. Ein statischer Host genügt.
2. **MIME:** `.js` → `text/javascript` · `.gltf`/`.json` → `application/json` · `.glb` → `model/gltf-binary` · `.otf` → `font/otf` · `.ttf` → `font/ttf` · `.webp` → `image/webp`.
3. **three.js** kommt derzeit aus der Import-Map (`unpkg.com/three@0.160.0` + `examples/jsm/`). Für den Betrieb same-origin spiegeln und die Import-Map im `<head>` der Blätter umstellen. Version **nicht** anheben, ohne die Rigs neu abzunehmen.
4. **Assets:** 31 Runtime-Assets kommen aus `georg-doc/kayfabizarro` (Liste mit Pfad, Revision und Blob-Sha in `ASSET_MANIFEST.json`). Sobald sie same-origin liegen, die `RAW`-Konstanten in `pet-library.v6.js`, `lab/assets.js` und den Zweibeiner-Modulen auf den Site-Pfad umstellen — **eine** Konstante je Modul, kein Suchen-und-Ersetzen über den Baum.
5. **Schriften:** aktuell GitHub-RAW auf `main`. Ziel: `/fonts/` same-origin; dann die `@font-face`-URLs auf `./fonts/` kürzen (Rückweg steht als Kommentar im Code). `Cross-Origin` braucht `Access-Control-Allow-Origin` — bei RAW gegeben, beim eigenen Host selbst setzen.
6. **CORS für GLB/GLTF:** die Loader holen Binärdaten. Same-origin ist der ruhige Weg; bei fremder Domain `ACAO` setzen.
7. **Keine Redirects auf Modulpfade.** Ein 301 auf einen `import()`-Pfad bricht den Modulschluss in manchen Browsern.

## Was NICHT nötig ist
Kein `package.json`, kein Lockfile, kein Transpilieren, kein Service Worker, keine Umgebungsvariablen. Was aussieht wie ein fehlender Build, ist keiner.

## Intake-Ziel (Briefing §14)
`tools/KFB-ToolBox/_inbox/KFB_TOOLBOX_STAGE_FIRST_V1/<export-revision>/` — Original zuerst unverändert ablegen, dann Hashes prüfen (`CHECKSUMS.sha256`), gegen die WS0-Baseline vergleichen, Parität prüfen, browsertesten, erst dann gezielt in die ToolBox promoten. Der geprüfte WS0-Stand bleibt bis dahin der Vergleichspunkt.

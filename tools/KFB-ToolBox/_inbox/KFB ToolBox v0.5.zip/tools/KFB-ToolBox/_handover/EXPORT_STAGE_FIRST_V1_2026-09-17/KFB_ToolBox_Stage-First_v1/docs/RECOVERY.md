# RECOVERY · für den nächsten Chat oder Entwickler

**Welches Paket ist die Originalübergabe?**
`KFB_ToolBox_Stage-First_v1_EXPORT_2026-09-17.zip`, erzeugt am 17.09.2026 aus dem Claude-Design-Projekt »KFB ToolBox«, Quellpfad `tools/KFB-ToolBox/stage-first`. Prüfsummen in `CHECKSUMS.sha256` (echt berechnet, SHA-256 über die Bytes).

**Was zuerst lesen?** `START_HERE.md`. Dann `docs/KNOWN_ISSUES.md` — dort stehen die sieben Dinge, die sonst Zeit kosten.

**Welche Revision ist geprüft?** Genau dieses Paket, Kaltstart aus neuem Pfad: Boot, Bühne, Augenquellen-Vorgabe, Schriften über RAW, vier Bewohner-Klassen (Rolli · Carl · GothGirl · Recherchi) ohne `loadErr`. Details und die vielen `NOT_TESTED` in `docs/TEST_REPORT.md`.

**Was funktioniert?** Bühne, Roster (35 Einträge), die vier Bewohner-Klassen, das Augen-Rig mit seinem Wächter, die Maß- und Bodenwege.

**Was ist offen?** Pose · Motion · Voice · Szene-Roundtrip · Resource-Picker-Abnahme · Splitscreen. Audio ist `BLOCKED` (fehlendes Manifest). Siehe `FEATURE_PARITY.md`.

**Welche Owner bleiben unverändert?**
`kfb.pets/1` (Actor/Profile-Vertrag) · `media/3D_Assets/pet-LIBRARY.json` (Shared Pet Library) · Registry/Librarian (Discovery, keine Eignungsentscheidung) · Rigging/Animation (echte Bindungsprüfung) · Travel/Combat/Stunt (Gameplay-Runtime). Dieser Export liefert Authoring-Daten und Kandidaten — nichts davon macht Stage-First zum Runtime-Owner.

**Wie rollt man auf den unveränderten Export zurück?**
Das ZIP erneut entpacken. Es enthält keine Zustände außerhalb von Dateien: keine Datenbank, kein Server, kein Cache. `localStorage` des Blattes ist Sitzungskomfort, keine Wahrheit — und wurde nie geleert (`localStorage.clear()` ist verboten und kommt im Code nicht vor).

**Wenn etwas nicht startet — drei Verdächtige, in dieser Reihenfolge:**
1. Ordnerbaum umsortiert → `__KFB_MODBASE` findet `petstudio-v9/` nicht.
2. Über `file://` geöffnet → `import()` scheitert an CORS. Statisch über HTTP ausliefern.
3. Kein Netz → `three` (unpkg) und die Repo-Assets fehlen.

**Vorgeschichte, die man kennen sollte:**
Der Augenquellen-Dauerfehler (`docs/handover/BIRTHDAY_STARTSCREEN_2026-09-15/EYE_SOURCE_RULE.md`) — drei bis vier Augenquellen, die sich still mischen. Die Regel ist jetzt eine Prüfung, kein Hinweis. Wer eine neue Bewohner-Klasse baut, importiert den Wächter und ruft `assertSingleHostEyeSource`. Ohne Prüfung ist die Regel eine Fußnote, und die Fußnote war der Fehler.

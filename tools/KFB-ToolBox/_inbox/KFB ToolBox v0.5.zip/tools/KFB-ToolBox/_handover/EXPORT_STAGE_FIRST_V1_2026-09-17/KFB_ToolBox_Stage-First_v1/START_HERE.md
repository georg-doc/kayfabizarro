# START_HERE · KFB ToolBox Stage-First v1 · Export 2026-09-17

**Was das ist:** der vollständige editierbare Stand des Stage-First-Authoring-Werkzeugs, aus Claude Design herausgelöst. Kein `dist`, kein Neuaufbau, keine Rekonstruktion aus Screenshots.

**Fünf Zeilen, dann weißt du Bescheid:**

1. **Einstieg:** `src/KFB ToolBox Stage-First v1.dc.html` — direkt im Browser öffnen. Kein Buildschritt, kein npm, kein Server nötig (ES-Module + Import-Map).
2. **Der Ordnerbaum IST die Abhängigkeit.** Der Einstieg setzt `window.__KFB_MODBASE = petstudio-v9/` und löst alles dagegen auf. Beim Intake nicht umsortieren, sonst laden die Module nicht (`docs/MODULE_MAP.md`).
3. **Assets liegen auf GitHub, nicht hier.** 31 Runtime-Assets werden über gepinnte `raw.githubusercontent`-Pfade geladen (`docs/ASSET_MANIFEST.json`). Zwei Dateien liegen bewusst im Paket, beide begründet.
4. **Was geprüft ist, steht in `docs/TEST_REPORT.md`** — mit `NOT_TESTED` dort, wo ich nicht geprüft habe. Ein Feature im Code ist kein PASS.
5. **Was der Web Lead braucht:** `docs/DEPLOYMENT.md`. Was ein neuer Chat braucht: `docs/RECOVERY.md`.

**Der eine Satz, der am meisten Zeit spart:** die Schrift-`@font-face`-Blöcke zeigen auf GitHub-RAW, weil es in diesem Baum keinen `fonts/`-Ordner gibt (nie gegeben hat). Sobald die Schriften same-origin unter `/fonts/` liegen, die URLs auf `./fonts/` kürzen — Rückweg steht als Kommentar direkt über dem ersten `@font-face`.

**Status dieses Pakets:** `IMPLEMENTATION` + `TESTED RESULT` für den Kaltstart am Exportbaum. **Keine** öffentliche Veröffentlichung, **kein** GitHub-Push (aus Claude Design nicht möglich — der Web Lead integriert).

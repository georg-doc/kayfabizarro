# SOURCE_SNAPSHOT

| | |
|---|---|
| Projekt | KFB ToolBox Stage-First v1 |
| Exportzeitpunkt | 2026-09-17, 22:0x UTC |
| Quelle | Claude-Design-Projekt »KFB ToolBox«, Pfad `tools/KFB-ToolBox/stage-first` |
| Einstieg | `src/KFB ToolBox Stage-First v1.dc.html` (653 KB) |
| Umfang | 106 Dateien im Paket (116 im Quellbaum, 10 Abnahmebilder ausgelassen) · 4,5 MB |
| Build | **keiner** — kein `package.json`, kein Lockfile, keine Bundler-Konfiguration im Baum. ES-Module plus Import-Map. `SOURCE REVISION → BUILD` ist damit `identity`: Source = Build. |
| WS0-Baseline | `tools/KFB-ToolBox/_inbox/WS0_2026-09-15/` — **nicht** in diesem Paket, bleibt unangetasteter Vergleichspunkt (Briefing §1) |
| Promotion-Donor | `src/KFB FrankenStein Studio v18.dc.html` liegt im Paket; v17 wurde auf Georgs Freigabe entfernt |

## Sichtbare Funktionen zum Exportzeitpunkt
Authoring-Domänen `Actor · Face · Pose · Motion · Voice · Stage` in **einer** persistenten Navigationszeile, Bühne visuell dominant. Roster mit 35 Einträgen: 24 Cube-Pets, 6 Zweibeiner (Graft-Driver, FrizzleBob, FrizzleBob+Gun, Graft-Medium/-Orc/-Clown, GothGirl), CapsuleCarl, Klo-Rolli, Hihi, Recherchi.

## Aktiver Zustand beim Export
`petIdx` = Graft-Driver (Boot-Vorgabe) · `eyePolicy.ok = true` · Augenquellen-Wächter geladen · keine `loadErr`.
Actor-Profile im Paket: `profiles/kfb-pet-gothgirl.json`, `profiles/kfb-pet-hihi.json` (+ Repo-Spiegel unter `profiles/repo-inbox/`), `docs/handover/BIRTHDAY_STARTSCREEN_2026-09-15/profiles/kfb-pet-graft-driver.georg-2026-09-17.json` (kfb.pets/1 v1.2.9 · meta 1.3.0 · petVersion 9).

## Änderungen AM Export (nicht im Projekt gewachsen)
1. **`@font-face` → GitHub-RAW** in `KFB ToolBox Stage-First v1.dc.html` und `KFB FrankenStein Studio v18.dc.html`, je 17 Verweise. Grund und Rückweg als Kommentar im Code. Status `REPAIRED_FOR_PORTABILITY`.
2. **Entfernt auf Freigabe:** `KFB FrankenStein Studio v17.dc.html`, `frizzlegraft-v1/ears.v1.js`, `DOC_RECONCILIATION_PROPOSAL.md` — auch im Projekt gelöscht, nicht nur im Paket.
3. **NICHT entfernt, obwohl als Vorgänger vorgeschlagen:** `lab-v6/inkform.v1.js`. Messung vor dem Löschen: `brow.v3.js` und `stache.v3.js` **importieren** die Datei. Der Vorgänger-Stempel war falsch.
4. **Ausgelassen:** `qa/evidence/*.jpg` (10 Bilder) und die Bilder aus `_handover` — auf Georgs Ansage »große Files kommentiert weglassen, Fokus auf Code & Module«. Sie bleiben im Claude-Projekt; `docs/TEST_REPORT.md` nennt sie mit Pfad.

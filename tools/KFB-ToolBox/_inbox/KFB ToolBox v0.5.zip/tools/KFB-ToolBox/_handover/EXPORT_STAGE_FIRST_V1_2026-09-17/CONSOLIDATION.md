# Stage-First v1 · Konsolidierung VOR dem Export

**Stand:** 2026-09-17, 21:40 UTC · **Status:** `PROPOSAL` — nichts gezippt, nichts gelöscht.
**Auftrag:** WSA-Exportbriefing (`_handover/KFB_TOOLBOX_STAGE_FIRST_V1_EXPORT_2026-09-17.md`, gelesen im Repo @`33491afbf99d`) plus Georgs Zusatz: »vorher konsolidieren und entsprechend dokumentieren«.

Dieses Blatt ist das **Veto-Fenster**. Es sagt, was der Export enthält, was er nicht enthält, was fehlt und was ich aufräumen *würde*. Freigabe je Punkt, dann baue ich das ZIP.

---

## 1 · Der Ist-Stand, gemessen (nicht geschätzt)

`tools/KFB-ToolBox/stage-first` · **116 Dateien · 5,06 MB · größte Datei 653 KB.** Prüfsummen echt berechnet (SHA-256 über die Bytes), Liste in `CHECKSUMS.sha256`, Rollen in `EXPORT_MANIFEST.json`.

| Rolle | Dateien | Was das ist |
|---|---|---|
| `MODULE` | 68 | die editierbaren Quellmodule (Three.js-Rigs, Loader, Contracts, Pose, Mund, Augen, Bühne) |
| `DATA` | 15 | Contracts, Fixtures, Actor-Profile |
| `EVIDENCE` | 10 | Abnahme-Captures des QA-Laufs 16.09. |
| `ENTRY` | 8 | Authoring-Blätter (`.dc.html`), Einstieg ist `src/KFB ToolBox Stage-First v1.dc.html` |
| `DOC` | 6 | README, CHANGELOG, Onboarding, PUSH, Return, Doc-Reconciliation |
| `RUNTIME` | 5 | 3× `support.js` (identisch, sha `8fe7df74…`) + DocCheck-Design-System-Bundle |
| `REFERENCE` | 2 | Frankenstein Studio v17 + v18 — Promotion-Donor, nicht der Export-Einstieg |
| `ASSET` | 2 | `FrizzleBob_Yellow.gltf` (594 KB, Spenderkopf) + `kfb-card-backside.png` (256 KB) |

**Größen-Budget des Exports ist erfüllt, ohne dass etwas weggelassen werden muss:** keine Datei über 2 MB, keine 3D-Bibliothek im Paket. Die schweren Sachen (KayKit-GLBs, Animationen, Skydomes) liegen bereits im Repo und werden zur Laufzeit über gepinnte RAW-URLs geladen — genau wie Briefing §5 es verlangt (`includedInExport: false`).

### Drei identische `support.js` sind kein Müll
Jedes `.dc.html` braucht die Laufzeit **neben sich**. `qa/`, `src/` und `src/petstudio-v9/` haben deshalb dieselbe Datei (gleicher Hash). Wer eine davon löscht, nimmt einem Blatt den Start. Im Manifest als geteilt markiert.

---

## 2 · SOURCE_GAPS · zwei echte Lücken, beide auflösbar

Nicht rekonstruiert, nicht erfunden — benannt und auf ihre GitHub-Quelle gezeigt (Briefing §3/§5).

### GAP-1 · `fonts/` fehlt im Quellbaum (19 `@font-face`-Verweise)
`src/KFB ToolBox Stage-First v1.dc.html` und `…Studio v18.dc.html` laden **13 Schriften** über `url('./fonts/…')`. Ein `fonts/`-Ordner existiert im Stage-First-Baum **nicht**. Im Chat-Vorschau-Kontext fällt das nicht auf (Fallback-Familien greifen), im Export wäre es der stille Killer aus der Pfad-Hygiene-Regel.

Gefunden im Repo, 17 Dateien mit Blob-Sha:
`skills/KFB PetStudio/KFB Pet Studio v9-1/pet-studio-v9_2026-08-28_ws0-rehome/fonts/`
(u. a. `FonteysPRO-Regular.otf` @`0641514242e8`, `GeorgComic-RegularPRO.otf` @`d17d87e3b9aa`, `Bangers-Regular.ttf` @`df3fa730747c`, `pottymouthbb_reg.otf` @`920eef38a9b5`).

**Vorschlag:** Schrift-Binaries **nicht** ins ZIP (Briefing §5 verbietet Font-Binaries aus Branding-Gründen). Statt dessen ein Patch der `@font-face`-Blöcke auf die gepinnte RAW-Quelle plus Eintrag im `ASSET_MANIFEST.json`. Das ist eine **Code-Änderung am Export** — Status `REPAIRED_FOR_PORTABILITY`, nicht `PRESERVED`. **Braucht deine Freigabe**, weil es die Quelle anfasst.
Alternative ohne Codeänderung: `fonts/` unangetastet lassen und im `DEPLOYMENT.md` als Pflicht für den Web Lead ausweisen (same-origin `/fonts/`). Dann bleibt der Export `EXPORT_PARTIAL` an dieser Stelle.

### GAP-2 · `kfb-pinball-sfx.json` fehlt
`src/petstudio-v9/kfb-pinball-audio.js` lädt `./kfb-pinball-sfx.json` (Audio-Manifest). Datei nicht im Baum. Im Repo vorhanden: `skills/KFB PetStudio/…/kfb-pinball-sfx.json` (18 058 B) @`5f7b52e2666a`.
**Vorschlag:** als `SOURCE_GAP` ausweisen, RAW-Pin ins `ASSET_MANIFEST.json`, Audio-Feature auf `NOT_TESTED` (in Claude ist Ton ohnehin nicht abnehmbar).

---

## 3 · Doppelungen und Vorgänger im Baum (Housekeeping, nichts gelöscht)

| Artefakt | Status | Begründung |
|---|---|---|
| `src/KFB ToolBox Stage-First v1.dc.html` | `AKTIV` | Export-Einstieg |
| `src/KFB FrankenStein Studio v18.dc.html` | `AKTIV` (Donor) | Promotion-Donor; **hier liegen die Fixes**, die Stage-First noch nicht alle hat |
| `src/KFB FrankenStein Studio v17.dc.html` | `SUPERSEDED` | von v18 überholt, bleibt als Rückweg |
| `src/frizzlegraft-v1/ears.v1.js` | `SUPERSEDED` | `ears.v2.js` ist aktiv |
| `src/lab-v6/inkform.v1.js` | `SUPERSEDED` | `inkform.v2.js` ist aktiv |
| `profiles/repo-inbox/*.json` | `ASSET` (Spiegel) | Spiegel der Repo-Fassung, **keine zweite Wahrheit** — Ladereihenfolge canonical → lokal |
| `src/support.js` · `src/petstudio-v9/support.js` · `qa/support.js` | `AKTIV` (geteilt ×3) | DC-Laufzeit muss neben jedem Blatt liegen |
| `src/_ds/doccheck-…/_ds_bundle.js` | `AKTIV` (fremd) | DocCheck-Design-System, nicht KFB-Quelle — im Manifest als Fremdbestand |
| `DOC_RECONCILIATION_PROPOSAL.md` | `FROZEN` | Vorschlagsblatt vom 16.09., durch dieses Blatt teilweise erledigt |

**Vorgänger bleiben im Export.** Briefing §0: »Bestehende Funktionen, Module, Zustände, Presets, Szenen und WIP-Teile erhalten« — ein Vorgänger ist der Rückweg, kein Ballast. Löschen nur auf ausdrückliche Freigabe, jeder Schritt einzeln.

---

## 4 · Was NICHT in den Export geht (und warum)

| Draußen | Grund |
|---|---|
| `_inbox/WS0_2026-09-15/` · `_inbox/V18_BIRTHDAY_7_2026-09-16/` | geprüfte **Baselines / Donor-Pakete**, nicht Stage-First-Quelle. Briefing §1: der WS0-Pin bleibt unangetasteter Vergleichspunkt. Das ZIP nennt sie als Referenz, kopiert sie nicht. |
| `site/…-standalone-.html` | erzeugte Bündel, kein editierbarer Source (Briefing §3: kein reiner `dist`-Export — umgekehrt aber auch kein `dist` statt Source) |
| `_archive/` | Historie |
| KayKit-/Cube-Pet-GLBs, Animationen | liegen im Repo, Source of Truth bleibt GitHub (§5) |
| Schrift-Binaries | §5 ausdrücklich unzulässig |

---

## 5 · Dokumenten-Konsolidierung · alt → gefordert

Der Baum hat schon Docs. Ich schreibe **keine** Parallelwelt, sondern ziehe sie auf die geforderten Namen zusammen:

| Gefordert | Quelle im Ist-Stand | Vorgehen |
|---|---|---|
| `README.md` | `stage-first/README.md` | übernehmen, Exportkopf ergänzen |
| `START_HERE.md` | `FRESH_CHAT_ONBOARDING.md` | daraus ableiten (Onboarding bleibt zusätzlich) |
| `SOURCE_SNAPSHOT.md` | `SOURCE_MAP.json` + dieses Blatt | neu, aus gemessenen Zahlen |
| `CHANGELOG.md` | `CHANGELOG.stage-first.md` | übernehmen, additiv |
| `DECISIONS.md` | `RETURN_STAGE_FIRST_P0_2026-09-16.md` + `EYE_SOURCE_RULE.md` §4 | neu, Entscheidungen mit Datum |
| `FEATURE_PARITY.md` | — | neu; Status je Funktion, ehrlich, mit `NOT_TESTED` wo ich nicht geprüft habe |
| `docs/MODULE_MAP.md` | aus den `import`-Zeilen gelesen | neu, nur echte Kanten |
| `docs/ASSET_MANIFEST.json` | RAW-Verweise im Code + GitHub-Blobs | neu, mit `sourceRevision`/`sourceBlobSha` |
| `docs/CONTRACT_MAPPING.md` | `kfb-pets.json`, `pet-LIBRARY.json`, A0-Contract | neu, nur Abbildung — kein Format umschreiben |
| `docs/RECOVERY.md` · `DEPLOYMENT.md` · `TEST_REPORT.md` · `KNOWN_ISSUES.md` · `ARCHITECTURE.md` | teils aus `PUSH.md` | neu |
| `EXPORT_MANIFEST.json` · `CHECKSUMS.sha256` | **liegen schon hier, echt berechnet** | fertig |

---

## 6 · Was ich bis hierher NICHT behaupte

- **Kein Browser-Testlauf des Exportpakets.** Getestet ist der Stand *im Projekt* (Studio startet, vier Bewohner laden, Augenquellen-Wächter hält nicht, `eyePolicy.ok = true`, 17.09. 21:2x). Ein Kaltstart aus dem entpackten ZIP ist noch nicht gelaufen → im `TEST_REPORT.md` `NOT_TESTED`, niemals PASS.
- **Kein Build.** Das Projekt hat keinen Buildschritt (keine `package.json`, keine Bundler-Konfiguration im Baum) — es sind ES-Module plus `.dc.html`. Damit ist `<deployable build>` **entfallen, nicht versäumt**; das gehört so in `DEPLOYMENT.md`.
- **Kein Push, keine Veröffentlichung.** `GITHUB PUSH: NOT PERFORMED` · `PUBLIC DEPLOYMENT: NOT PERFORMED`.
- **Preview-Link:** im Projekt geöffnet; eine dauerhafte öffentliche URL kann ich nicht erzeugen → `NOT AVAILABLE` als Dauer-URL.

---

## 7 · Deine drei Freigaben (das ist das Veto-Fenster)

1. **GAP-1 Schriften:** `@font-face` auf gepinnte RAW-URLs patchen (Export lauffähig, aber Quelle angefasst) — **oder** unverändert lassen und als Web-Lead-Pflicht dokumentieren (`EXPORT_PARTIAL`)?
2. **Reichweite:** nur `stage-first/` ins ZIP (mein Vorschlag) — oder zusätzlich die Augenquellen-Unterlagen aus `_handover/BIRTHDAY_STARTSCREEN_2026-09-15/` (Regel, Probe, Belege 19–22)?
3. **Aufräum-Kandidaten** (nur benannt, nichts ausgeführt): `Studio v17` · `ears.v1` · `inkform.v1` · `DOC_RECONCILIATION_PROPOSAL.md`. Mein Vorschlag: **alle behalten**, Status im `HOUSEKEEPING.md` führen.

Nach deinem Okay: ZIP bauen, Dokumente schreiben, Kaltstart-Test soweit möglich, Abschlussantwort im Format des Briefings.

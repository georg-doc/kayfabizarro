# KFB ToolBox Stage-First v1 · Export 2026-09-17

Vollständiger editierbarer Stand, aus Claude Design herausgelöst. **Zuerst `START_HERE.md` lesen.**

| Datei | Wofür |
|---|---|
| `START_HERE.md` | fünf Zeilen Orientierung |
| `SOURCE_SNAPSHOT.md` | was genau exportiert wurde, inkl. der drei Änderungen am Export |
| `FEATURE_PARITY.md` | Status je Funktion, mit `NOT_TESTED` wo ungeprüft |
| `DECISIONS.md` | Entscheidungen mit Datum und Grund |
| `CHANGELOG.md` · `CHANGELOG.stage-first.md` | Verlauf |
| `EXPORT_MANIFEST.json` · `CHECKSUMS.sha256` | Inventar + echte SHA-256 |
| `docs/ARCHITECTURE.md` | wer was besitzt |
| `docs/MODULE_MAP.md` | echte Importkanten |
| `docs/ASSET_MANIFEST.json` | 33 Assets mit Repo, Pfad, Revision, Blob-Sha |
| `docs/CONTRACT_MAPPING.md` | Verträge + A0-Abbildung |
| `docs/DEPLOYMENT.md` | für den Web Lead |
| `docs/TEST_REPORT.md` | was wirklich gelaufen ist |
| `docs/KNOWN_ISSUES.md` | sieben Dinge, die sonst Zeit kosten |
| `docs/RECOVERY.md` | für den nächsten Chat |
| `docs/handover/` | die Unterlagen aus `_handover` (Augenquellen-Regel, Studio-Inventar, Kritik, Konzept) |

**Status:** `IMPLEMENTATION` + `TESTED RESULT` (Kaltstart am Exportbaum) · `GITHUB PUSH: NOT PERFORMED` · `PUBLIC DEPLOYMENT: NOT PERFORMED`.

---

# KFB ToolBox · Stage-First working line

**Stand 2026-09-16 · Status: P0 slice tested · GEORG ACCEPTANCE PENDING**

| Was | Wo |
|---|---|
| Start (Actor · Face · Pose · Motion · Voice · Stage) | `src/KFB ToolBox Stage-First v1.dc.html` |
| Prüfstand (13 Checks, Roundtrips im Speicher, Sitzung gesichert/wiederhergestellt/nachgemessen) | `qa/Stage-First QA.dc.html` → »Run 13 checks« |
| Return mit Source Map, Promotion-Matrix, Delta-Matrix, Tested Result | `RETURN_STAGE_FIRST_P0_2026-09-16.md` |
| Hashes | `SOURCE_MAP.json` |
| Donor unverändert (Vergleich) | `src/KFB FrankenStein Studio v18.dc.html` |
| Profile (v18-Export, byte-gleich) | `profiles/kfb-pet-gothgirl.json` · `profiles/kfb-pet-hihi.json` |

`src/` = WS0 `A_QUELLSTAND/src` (87 Dateien, getestet) + drei v18-Module (`goth-biped.v1`, `browfit.v1`, `inkform.v2`) + v18-Blatt + Stage-First-Blatt. Kein Modul wurde nachgebaut oder verändert. Die sieben WS0-Blätter starten hier weiterhin.

Regeln: `../AGENTS.md`. Entwürfe leben in `localStorage` (`kfb-pet-library-v9`, `kfb-pet-studio-v5`). Die Bedien-Handler schreiben sie auch während eines Prüflaufs (v18 F10) — der Prüfstand sichert den Stand vorher, stellt ihn nachher wieder her und mißt das in Prüfung 13.


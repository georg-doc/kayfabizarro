# Abdeckungsmatrix · Studio v17 → ToolBox Shell

**15.09.2026 · Vorlage zur Freigabe. Keine Implementierung, bis diese Matrix steht.**
Grundlage: `STUDIO_V17_INVENTORY.md` (39 Abschnitte, fünf Reiter, Fußstreifen, File-Menü).

---

## A · Die Regel, nach der umgeräumt wird

1. **Das Reitermodell bleibt primär.** Body · Face · Motion · Voice · Messen sind weiterhin die
   Struktur. Sie sind gemessen, benannt und eingespielt; ein Workflow-Band ersetzt sie nicht.
2. **Das Band ist Zweitnavigation.** `Select → Shape & Look → Attach & Fit → Motion & Talk → Export`
   liegt **über** der Reiterleiste und **wählt einen Reiter plus eine Abschnittsgruppe vor**. Es
   blendet nie einen Reiter aus. Wer das Band ignoriert, verliert nichts.
3. **Progressive Disclosure heißt umgruppieren, nicht entfernen.** Innerhalb eines Reiters gibt es
   zwei Läufe: **Basis** (offen, wie im Studio — `V2OPEN0`, »zugeklappt = unsichtbar«) und
   **Expert** (zu, ein Klick entfernt). Der vorhandene Schalter *Erklärtexte* bleibt die
   Dichteregelung. Kein Abschnitt verschwindet, keiner wandert in ein zweites Werkzeug.
4. **Visuelle Sprache = Studio.** `V2SURF.paper` als Vorgabe, `lab` als Zweitstand über denselben
   Theme-Knopf. Space Grotesk. Ein Akzent (`--accent-fill`), Textakzent über `--tcol`. Kein rotes
   Chrome, kein dunkler Start.
5. **Split-Screen ist Hauptfall.** Roster und Panel sind **Paletten** mit Umschaltern, keine
   schrumpfenden Spalten. Der Fußstreifen bleibt in jeder Breite (»ohne Klick da«).
6. **Carl ist ein QA-Szenario, kein Modell.** Pflichtszenarien: Cube-Pet · CapsuleCarl ·
   FrizzleBob/Graft · Motion-Casting · Talk/Voice/Bubbles.

---

## B · Neue Anordnung

```
┌ Kopf 48 · Wortmarke · Roster-Auswahl · Entwurfsstand · Theme · File ────────┐
├ Band  36 · Select › Shape & Look › Attach & Fit › Motion & Talk › Export ───┤   ← Zweitnavigation
├ Reiter 44 · Body · Face · Motion · Voice · Messen ──────────────────────────┤   ← primär, immer alle fünf
│ ┌ Palette A ┐ ┌────────── Bühne ──────────┐ ┌ Palette B ────────────────┐   │
│ │ Roster    │ │  Blase liegt über der     │ │ Abschnitte des Reiters    │   │
│ │ Herkunft  │ │  Bühne, nicht im Panel    │ │ Basis offen · Expert zu   │   │
│ └───────────┘ └───────────────────────────┘ └───────────────────────────┘   │
├ Fußstreifen 52 · Emotes · Viseme · Anim (CLIP8) ────────────────────────────┤
└─────────────────────────────────────────────────────────────────────────────┘
```

**Breitenverhalten** — die Breite bestimmt die *Vorgabe*, der Benutzer den *Stand*:

| Breite | Palette A | Palette B | Fußstreifen | Band |
|---|---|---|---|---|
| ≥ 1180 | angedockt 228 | angedockt 356 | voll | mit Beschriftung |
| 832–1179 (**Split-Screen**) | Umschalter, schwebt | angedockt 320 | voll | mit Beschriftung |
| 720–831 | Umschalter, schwebt | Umschalter, schwebt | voll | Ziffern + Kurzwort |
| < 720 | Umschalter | Umschalter | scrollend | Ziffern |

Nichts wird gestaucht. Eine Palette ist entweder angedockt, schwebend oder als Umschalter sichtbar —
nie unauffindbar. Esc und Klick außerhalb schließen eine schwebende Palette.

---

## C · Die Matrix

**Legende Status** — `behalten` unverändert übernommen · `umgruppiert` gleiche Funktion, neue
Nachbarschaft · `disclosure` in den Expert-Lauf verschoben, ein Klick entfernt · `erweitert`
zusätzlich zur Studio-Fassung · `offen` Platzhalter im Studio, bleibt Platzhalter und wird als
solcher beschriftet.

### C.1 · Body

| # | Studio v17 | Neuer Ort | Status | Anmerkung |
|---|---|---|---|---|
| 1 | `koerper.material` (6) | Body › Basis | behalten | |
| 2 | `koerper.licht` (4) | **Stage-Palette** | umgruppiert | Szenenweit, reiterübergreifend (Entscheidung 3) |
| 3 | `koerper.farbe` (3) | Body › Basis | behalten | |
| 4 | `koerper.vertrag` | Body › Expert **+ Messen** | behalten | Doppelt gezeigt wie im Studio (`V2MESS`); Export-Häkchen bleiben hier |
| 5 | `koerper.planvertrag` | Body › Expert **+ Messen** | behalten | |
| 6 | `koerper.boden` | **Stage-Palette** | umgruppiert | Szenenweit (Entscheidung 3) |
| 7 | `koerper.biped` | Body › Basis (Zweibeiner) | behalten | |
| 8 | `koerper.matzonen` | Body › Basis · **Zonenliste** | erweitert | Filter, Hexfeld, `Copy #hex`, Original, kuratierte Palette, Oberfläche je Zone. Owner bleibt `matzones.v1.js` |
| 9 | `koerper.kopfzonen` | Body › Basis · Zonenliste, zweite Gruppe | behalten | Freie Wähler, wie gefordert |
| 10 | `koerper.cardrider` | **Attach & Fit** (Band) → Body › Expert | umgruppiert | Reiter bleibt Body; das Band führt hin |
| 11 | `koerper.weapon` | **Attach & Fit** → Body › Basis (Graft) | umgruppiert | |
| 12 | `koerper.pose` | **Attach & Fit** → Body › Basis (Zweibeiner) | umgruppiert | |
| 13 | `pad.anchors` | Body › Expert · Pad **+ Messen** | behalten | |
| 14 | `pad.base` | **Stage-Palette** | umgruppiert | Schattenempfänger und VFX-Fläche = Bühne (Entscheidung 3) |
| 15 | `pad.audio` | Body › Expert · Pad | disclosure | |
| 16 | `pad.sheet` | Body › Expert · Pad | disclosure | Nur beim Rolli sichtbar |

### C.2 · Face

| # | Studio v17 | Neuer Ort | Status | Anmerkung |
|---|---|---|---|---|
| 17 | `gesicht.augen` (14) | Face › Basis | umgruppiert | 14 Zeilen in zwei Blöcke: **Anker** (7) offen, **Wimpern und Form** (7) im Expert-Lauf |
| 18 | `gesicht.brauen` | Face › Basis | erweitert | Dazu die **Insel-Braue** (`PartRig`, 5 Felder) für Carl **und** die abgewiesenen Felder im Wortlaut des Lesers (CRITIQUE F4/F5) |
| 19 | `gesicht.nase` | Face › Basis | erweitert | ebenso |
| 20 | `gesicht.schnurrbart` | Face › Expert | disclosure | |
| 21 | `gesicht.emotes` (2) | Face › Basis **+ Fußstreifen** | behalten | Der Streifen bleibt, wie er ist |
| 22 | `gesicht.mund` (9) | Face › Basis | behalten | |
| 23 | `gesicht.visem` | Face › Basis **+ Fußstreifen** | behalten | |
| 24 | `actor.asym` (3) | Face › Expert | disclosure | |
| 25 | `actor.leben` (3) | Face › Expert | disclosure | |
| 26 | `actor.kinetik` (3) | **Attach & Fit** → Face › Expert | umgruppiert | |

### C.3 · Motion

| # | Studio v17 | Neuer Ort | Status | Anmerkung |
|---|---|---|---|---|
| 27 | `motion.clips` (2) | Motion › Basis | behalten | |
| 28 | `motion.ownclips` | Motion › Expert | disclosure | |
| 29 | `motion.tuning` | Motion › Expert | **offen** | Bleibt Platzhalter, beschriftet `nicht angeschlossen · Owner: motion-LIBRARY.v2.json`. Kein erfundener Regler |
| 30 | `motion.treiber` | Motion › Expert **+ Messen** | behalten | |
| 31 | `anim.audit` | Motion › Basis **+ Messen** | behalten | |
| 32 | `anim.browser` | Motion › Basis | behalten | |
| 33 | `anim.map` (24 Zustände) | Motion › Basis · **Casting** | erweitert | Die Zuordnung bekommt je Slot Kandidaten, **live gemessene Bindungsabdeckung**, Vorschau und Accept/Reject. Schreibt in `pet.anim.clipMap` — den Block, der Georgs Export vom 15.09. fehlte |
| 34 | `anim.seat` | **Attach & Fit** → Motion › Expert | umgruppiert | |
| 35 | `anim.export` | Motion › Expert **+ Messen** | behalten | |

### C.4 · Voice

| # | Studio v17 | Neuer Ort | Status | Anmerkung |
|---|---|---|---|---|
| 36 | `voice.quelle` | Voice › Basis | **offen** | Bleibt Platzhalter, beschriftet `kein Vertragsfeld · geplant: Songquelle · Lip-Sync · Synchronisation` |
| – | `v2speech` (kein Abschnitt) | Voice › Basis · **Stimme** | erweitert | Bekommt einen eigenen Abschnitt: pitch · rate · category. Hinweis aus dem Vertrag: ein **Wunsch**, nie eine `voiceURI` |
| 37 | `bubbles.shaper` | Voice › Basis · **Sprechblase** | behalten | Typ · Richtung · Kontur · Lautstärke · Wortlaut über `buildBubble()` |
| 38 | `bubbles.tail` | Voice › Expert | disclosure | `bubble-tail.v1.js`, Ansatz + Spitze |
| 39 | `bubbles.bank` | Voice › Expert | disclosure | |
| – | `v2bubble` (Zustand) | Bühne · Überlagerung | umgruppiert | Die Blase liegt **über der Bühne**, nicht im Panel — im Studio lag sie auf den Augen und wurde deshalb abgeschaltet. Eigener Sichtbarkeitsschalter |
| – | `v2ind` Indikator | Voice › Basis | behalten | Sichtbarkeit bleibt ein eigener Schalter |
| – | `pet-mouth` Talk | **Motion & Talk** → Voice › Basis · **Talk** | erweitert | `talk` · `talkBurst` · Rest · 5 Viseme · Mund-Set. Ein Sprechweg, das geteilte Modul |

### C.5 · Messen

| # | Studio v17 | Neuer Ort | Status |
|---|---|---|---|
| — | `V2MESS`: `koerper.vertrag` · `koerper.planvertrag` · `motion.treiber` · `pad.anchors` · `anim.audit` · `anim.export` | Messen, unverändert eingesammelt | behalten |
| — | Erklärtexte hier **immer** sichtbar | Messen | behalten |

### C.6 · Chrome

| Studio v17 | Neuer Ort | Status | Anmerkung |
|---|---|---|---|
| Reiterleiste (5) | Kopf, unter dem Band | behalten | |
| Pet-`<select>` mit ★ | **Palette A · Roster** | erweitert | Liste statt Aufklappfeld, mit Herkunft je Actor (Reader · Contract · Schema · Entry · Class · Islands · Fields). ★ bleibt |
| Theme-Zyklus | Kopf | behalten | `paper` Vorgabe, `lab` zweiter Stand |
| File · Ansicht · Erklärtexte | File-Menü | behalten | Bleibt die Dichteregelung |
| File · Session (Save/Discard drafts) | File-Menü | behalten | |
| File · Export (This pet · Selection · Full set · Load file) | File-Menü **+ Export-Band** | behalten | Zusätzlich die vier benannten Ausgaben im Band-Schritt »Export« |
| Panel einklappen + Lasche | Palette B · Umschalter | umgruppiert | Aus der Lasche wird ein benannter Umschalter in der Kopfleiste |
| Fußstreifen Emotes/Viseme/Anim | Fußstreifen | behalten | In jeder Breite |
| HUD / `zenMode` | Kopf | behalten | |

### C.7 · Neu in der Shell (nicht im Studio)

| Neu | Warum | Owner |
|---|---|---|
| Farbfeld mit `#hex`, Validierung, `Copy`, Esc + Klick-außerhalb | CRITIQUE F3 — gemeldeter Defekt, an beiden Oberflächen nachgewiesen | UI |
| `Original` ruft den **Owner-Griff** (`setZoneStyle(…, color:null)`) | CRITIQUE F2 — stellt die Originaltextur wirklich wieder her, 21/21 `origMap` gemessen | UI |
| Abgewiesene Felder durchgestrichen mit dem Wortlaut des Lesers | CRITIQUE F5 — `taper` hat am ausgelieferten Carl keinen Griff | UI zeigt, **Rig** besitzt |
| Live gemessene Bindungsabdeckung je Clip-Kandidat | CRITIQUE F8 — Birthday-Weg hatte keine Fläche | UI |
| Rundlauf: schreiben, mit demselben Leser zurücklesen, Feld für Feld vergleichen | CRITIQUE F10 | UI |
| Paletten-Umschalter + zwei Läufe je Reiter | CRITIQUE F9 · Georgs Split-Screen | UI |
| **Alle KayKit-Charaktere im Roster** — 43 Einträge, GLB-Pfad zur Laufzeit aufgelöst, `resolved`/`not found` sichtbar | Georg 15.09.: alle Charaktere müssen für Animation **und** fürs Rigging verfügbar sein | UI · Katalog `design/kaykit-catalog.json` |
| **Beide Rig-Familien, alle acht Sätze** — `Rig_Medium` und `Rig_Large` × General · MovementBasic · MovementAdvanced · Simulation · CombatMelee · CombatRanged · Special · Tools | dito; Quelle ist `anim-audit.v1.js#RIGS`, kein geratener Bestand | UI |
| **Frankenstein-Fläche** — Wirt + Spender + Teileauswahl (Kopf · Gesicht · Ohren · Waffe · Braue · Nase · Bart) über den vorhandenen Graft-Weg | Georg 15.09.: Teile kombinieren zu einem neuen Rig | UI ordnet an; `headgraft.v1.js` · `facehost.v1.js` · `graft-biped.v1.js` besitzen |

---

## D · Was dabei **nicht** passiert

- Kein Abschnitt wird gelöscht. 39 von 39 sind in der Matrix, jeder mit Zielort.
- Kein Platzhalter wird zu einem echten Regler umgedeutet (`motion.tuning`, `voice.quelle`).
- Kein zweiter Shader, Mixer, Mund, Blasenzeichner oder Materialcache. Jeder Griff bleibt bei
  seinem Owner; die Shell ordnet an.
- Georgs Sitzungen (`kfb-pet-studio-v5`, `kfb.carl.rig.v6.3`, `kfb-lab-v2:ui`) werden nicht
  beschrieben. Die Shell hat einen eigenen Schlüssel.
- Ergebnis A wird nicht neu gebaut.

---

## E · Zählung zur Abnahme

| | |
|---|---|
| Abschnitte im Studio | **39** |
| davon `behalten` | 20 |
| davon `umgruppiert` | 9 (davon 3 in die Stage-Palette) |
| davon `disclosure` (Expert-Lauf) | 8 |
| davon `erweitert` | 6 (davon 2 zugleich umgruppiert) |
| davon `offen` (Platzhalter bleibt Platzhalter) | 2 |
| **stillschweigend verschwunden** | **0** |
| Chrome-Elemente | 9, davon 0 entfallen |

---

## F · Entschieden (Georg, 15.09.)

1. **Reiter primär, Band sekundär.** `Body · Face · Motion · Voice · Messen` führt. Das
   Workflow-Band ist reiner Wegweiser und Statusanzeige, klappt im Split-Screen zur Breadcrumb
   zusammen und darf **keine** Studio-Funktion umsortieren, verstecken oder ersetzen.
2. **Basis offen + Expert zu + globaler »Alles zeigen«.** Zustand hält über die Sitzung.
   »Expert« heißt Detailparameter, nicht »selten benutzt = weg«. Es muß **jederzeit sichtbar
   sein, daß weitere Regler da sind**. Erklärtexte bleiben ein eigener Schalter.
3. **Eigene Bühnen-Palette.** `koerper.licht` · `koerper.boden` · `pad.base` sind keine
   Körpereigenschaften. Sie ziehen in eine kleine, umschaltbare Palette *Stage*
   (`Light · Ground · Pad/Base · Background/View`), **reiterübergreifend** verfügbar.
4. **Sprechblase:** außerhalb von Voice aus, aber ein Klick entfernt; beim Wechsel **nach Voice
   automatisch an**; danach bleibt der Stand, den der Benutzer gesetzt hat. Eigener Umschalter an
   der Bühne, Position relativ zur Bühne — nie über dem Gesicht.
5. **Roster:** getunte/eigene/zuletzt relevante zuerst, alle 24 Cube-Pets bleiben auffindbar
   hinter »Alle zeigen«. Die Suche durchsucht **auch den eingeklappten Rest**. `Alle zeigen` ist
   Disclosure, keine zweite Datenquelle.

### Harte Tore vor »Rework complete«

| # | Tor |
|---|---|
| G1 | **39/39** — jeder inventarisierte Abschnitt hat eine Position: `preserved · regrouped · progressive · intentionally deferred`. Kein stilles Verschwinden. |
| G2 | **Theme Contract** — Paper/Light ist Vorgabe. Kein DocCheck-Rot als Chrome, kein dunkler Start. Der Theme-Schalter ändert **Farbe, nicht Layout oder Funktion**. |
| G3 | **Split-Screen ist Entwurfsziel**, nicht QA-Nachtrag: bei 832 px bleibt die Bühne brauchbar, Paletten togglen. |
| G4 | **Material-Zone-UX** vollständig: `#hex` · Copy · Palette · Original/Reset · click-outside · Esc · Texture/Surface wo unterstützt. |
| G5 | **Save/Draft eindeutig** — Actor-Wechsel verliert keine Änderung; `unsaved / saved / reverted` ist ablesbar. |
| G6 | **Bühne bleibt stabil** — Reiter wechseln Werkzeuge, nicht die räumliche Orientierung. Kamera-Presets dürfen kontextabhängig wechseln, aber nicht springen. |

### QA-Reihenfolge

**P0, erster Bau:** FrizzleBob/Graft (Materialzonen + Surface) · Motion-Casting (Birthday) ·
Talk/Viseme/Mund · Voice-Wunsch + Sprechblase · Cube-Pet (Material + Farbe als Gegenprobe) ·
Split-Screen 832 px · Export→Import-Rundlauf.

**Regression/Smoke im selben Bau:** CapsuleCarl (Zonen + Brauen) — ausdrücklich Sonderfall, **nicht
UX-Leitmodell** · Klo-Rolli · Recherchi.

Carl-Brow/Tapering bleibt `OPEN/DEFECT`, solange die visuelle Wirkung nicht bewiesen ist.

# Studio v17 · vollständiges Feature-Inventar

**Quelle:** `_inbox/WS0_2026-09-15/unpacked/A_QUELLSTAND/src/KFB FrankenStein Studio v17.dc.html`
(Quellstand WS0, unverändert gelesen — kein Byte angefaßt.)
**Gelesen:** 15.09.2026 · **Zweck:** Grundlage für die Abdeckungsmatrix. Kein Redesign in diesem Dokument.

Das Studio ist die **primäre funktionale UX-Quelle** der ToolBox. Carl ist hier nicht Maßstab,
sondern ein Bewohner unter mehreren und ein QA-Szenario.

---

## 0 · Aufbau des Blattes

| Bereich | Maß / Verhalten | Fundstelle |
|---|---|---|
| Kopfzeile | 48 px · Reiterleiste links, rechts Pet-Auswahl · Theme-Zyklus · File-Menü | Template Z. 199–228 |
| File-Blatt | 318 px, drei Gruppen, jede Zeile nennt ihr **Ziel** (Session ≠ Vertrag ≠ Repo) | Z. 230–246 |
| Bühne | Orbit-Kamera, Licht, RoomEnvironment, HUD über `zenMode` abschaltbar | `state.hud` |
| Seitenpanel | 324 px rechts, **einklappbar**, mit Wiederaufklapp-Lasche über die volle Höhe | Z. 248–256 |
| Fußstreifen | 52 px, je Reiter belegt — »ohne Klick da« | `V2BOTTOM`-Logik, Z. 704–708 |
| Abschnitte | Kopfzeile klebt oben, Chevron, **offen ist die Vorgabe** (`V2OPEN0`) | Z. 712 |

**Schrift:** `Space Grotesk` in der ganzen Bedienung; dazu `Irish Grover`, `Special Elite`,
`Bangers`, `Shantell Sans` für Inhalt und Blasen.

**Theme:** `V2SURF` mit zwei Ständen — **`paper` ist die Vorgabe** (`v2theme:'paper'`, v16-S5,
Georg), `lab` ist der dunkle Zweitstand. Ein Akzent für alle Reiter: `--accent-fill`.

| Token | paper | lab |
|---|---|---|
| `--app-bg` | `#dedbd4` | `#17181a` |
| `--surface` | `#efece6` | `#1d1f21` |
| `--border` | `#c9c5bc` | `#2a2d30` |
| `--text` | `#1f2022` | `#e7e7e5` |
| `--muted` | `#5c6065` | `#90969b` |
| `--accent-fill` | `#b8781c` | `#e6a13c` |
| `--tcol` (Textakzent) | `#7a4d0d` | `#e6a13c` |
| `--stage` | `#efece6` | `#2b2e31` |

`tcol` ist bewußt ein eigenes Token: der Akzent `#e6a13c` hat auf Papier **1,6:1** und ist als
Textfarbe dort unbrauchbar. Wer den Akzent als Schriftfarbe benutzt, muß diesem Token folgen.

---

## 1 · Die fünf Reiter

`V2TABS = ['koerper','gesicht','motion','voice','messen']`
`V2MERGE` faßt acht historische Quellen zu fünf Reitern: Face+Actor · Voice+Bubbles · Motion+Anim ·
Pad in Body · Messen als eigener Beleg-Reiter.

**39 unterscheidbare Abschnitte.** Ein Cube-Pet sieht 33, ein Zweibeiner 35 (der Body-Reiter tauscht
vier Cube-Abschnitte gegen sechs Zweibeiner-Abschnitte).

### 1.1 · Body (`koerper` + `pad`)

| # | id | Titel | Zeilen / Bauer | Nur Zweibeiner |
|---|---|---|---|---|
| 1 | `koerper.material` | Material | 6: Style · Texture scale · Tint · Relief · AO (cavities) · Roughness | – |
| 2 | `koerper.licht` | Light | 4: Mood · Azimuth · Height · Rim light | – |
| 3 | `koerper.farbe` | Color | 3: Pet color · Native Kenney color · Facets | – |
| 4 | `koerper.vertrag` | Body contract · measured + cube | `_bodyRows` (+ Auswahlhäkchen für Export) | – |
| 5 | `koerper.planvertrag` | Ground plane · the pet's own surface | `_groundContractRows` | – |
| 6 | `koerper.boden` | Ground floor of the zone · shadow · tile | `_groundRows` | – |
| 7 | `koerper.biped` | Biped · variant · weapon | `_bipedBodyRows` | ✔ |
| 8 | `koerper.matzonen` | **Material zones · colour and finish** | `_matZoneRows` | ✔ |
| 9 | `koerper.kopfzonen` | **Head zones · free colour** | `_headZoneRows` | ✔ |
| 10 | `koerper.cardrider` | Card Rider · Travel-Abgabe | `_cardRows` | ✔ |
| 11 | `koerper.weapon` | Waffe · Handbetrieb | `_weaponRows` | ✔ |
| 12 | `koerper.pose` | Seat · sitting pose | `_poseRows` | ✔ |
| 13 | `pad.anchors` | Anchors · measured, for gear | `_padAnchorRows` | – |
| 14 | `pad.base` | Base · shadow, contact AO, ink | `_padBaseRows` | – |
| 15 | `pad.audio` | Audio · one event, one sound | `_padAudioRows` | – |
| 16 | `pad.sheet` | Roll · pull, spin, tear | `_padSheetRows` | – |

### 1.2 · Face (`gesicht` + `actor`)

| # | id | Titel | Zeilen / Bauer |
|---|---|---|---|
| 17 | `gesicht.augen` | Eyes | 14: Pupil style · Spacing · Height · Eye size (ring) · Gaze drift · Pupil size · Gloss · Eye width/height/depth/tilt · Lash length/density/width |
| 18 | `gesicht.brauen` | Brows · one curve, one mask | `_browRows` |
| 19 | `gesicht.nase` | Nose · cartoon knob | `_noseRows` |
| 20 | `gesicht.schnurrbart` | Moustache · same ink, under the nose | `_moustRows` |
| 21 | `gesicht.emotes` | Emotes | 2: Expression · Gaze follows cursor |
| 22 | `gesicht.mund` | Mouth | 9: Mouth visible · Mouth set · Size · Height · Tilt · Width × · Offset (overlay) · Hug · Always on top |
| 23 | `gesicht.visem` | Visemes (5 shapes) | `_visemeRows` |
| 24 | `actor.asym` | Asymmetry (Δ left eye) | 3: Lid top · Lid bottom · Slant |
| 25 | `actor.leben` | Life | 3: Idle life · Drift · Jitter |
| 26 | `actor.kinetik` | Kinetics (fake ride) | 3: Acceleration · Curve · Fall |

### 1.3 · Motion (`motion` + `anim`)

| # | id | Titel | Zeilen / Bauer |
|---|---|---|---|
| 27 | `motion.clips` | Animation (GLB clips) | 2: Clip · Action |
| 28 | `motion.ownclips` | Own clips · biped | `_bipedClipRows` |
| 29 | `motion.tuning` | Motion tuning | **DUMMY** — jump height, duration, squash/stretch, smoothing liegen in `motion-LIBRARY.v2.json`, nicht in der v9-Looks-Engine |
| 30 | `motion.treiber` | Driver contract (§2b) | `_puppetRows` |
| 31 | `anim.audit` | Zählwerk · echte Clipnamen aus den Dateien | `_auditRows` |
| 32 | `anim.browser` | Abspielen · Clip, Schleife, Tempo | `_animBrowserRows` |
| 33 | `anim.map` | Zuordnung · 24 Spielzustände auf echte Clips | `_animMapRows` |
| 34 | `anim.seat` | Sitzprobe · Profile, Badewanne, Fahr-Acting | `_seatRows` |
| 35 | `anim.export` | Dateien · Inventar, Zuordnung, Sitzprofile, Quellen | `_auditExportRows` |

### 1.4 · Voice (`voice` + `bubbles`)

| # | id | Titel | Zeilen / Bauer |
|---|---|---|---|
| 36 | `voice.quelle` | Voice | **DUMMY** — »no contract field. Planned: song source · lip-sync mode · synchronisation« |
| 37 | `bubbles.shaper` | Shaper | `_shaperRows` |
| 38 | `bubbles.tail` | Tail · Ansatz + Spitze | `_tailRows` |
| 39 | `bubbles.bank` | Shape bank | `_bankRows` |

Dazu drei Zustandsblöcke, die **keinen eigenen Abschnitt haben** und trotzdem Funktion sind:

- `v2bubble` — `{open, type, voice, edge, base, scale, text, gap, pad, line, tint, font, fontFixed, arrow, dead}`; startet `open:false`, weil die Blase im Gesicht-Reiter auf den Augen lag.
- `v2speech` — `{pitch, rate, category}`, spiegelt `voice.speech` des Vertrags. `category:null` = aus dem Archetyp ableiten.
- `v2ind` — Indikator `{state:'thinking', on:false}`; Sichtbarkeit ist ein **eigener** Schalter, kein Nebeneffekt der Blase.

**Owner-Module:** `petstudio-v9/podcast-v2/bubbles.v4.js` (`buildBubble` · `buildAnchors` · TYPES
`round·rect·fan·cloud·burst` · OUTLINES `solid·dotted·dashed·shadow` · DIRS 8 · VOICE `loud·mid·soft`),
`petstudio-v9/studio-v9/bubble-tail.v1.js` (`TAIL_KIND`, `ensureTail`),
`petstudio-v9/studio-v3/pet-mouth.v1.js` (`talk` · `talkBurst` · `setViseme` · `setSet` · `setTex`,
5 Viseme, 13 Decals je Set).

### 1.5 · Messen

Kein eigener Inhalt — `V2MESS` sammelt **sechs** vorhandene Abschnitte ein, ohne sie zu verschieben:
`koerper.vertrag` · `koerper.planvertrag` · `motion.treiber` · `pad.anchors` · `anim.audit` · `anim.export`.
Dieser Reiter zeigt Erklärtexte **immer**, unabhängig vom Schalter.

---

## 2 · Fußstreifen · »ohne Klick da«

Georgs Formular vom 12.09., Punkt 4: Bewegungen, Gesichtsausdruck und Figurenwahl ohne Klick
erreichbar. Umgesetzt als Fußstreifen in **jedem** Reiter:

- `gesicht`: **Emotes** · **Viseme** (`closed · open · wide · round · smile`) · **Anim** (CLIP8)
- alle anderen: **Emotes** · **Anim** (CLIP8)

`CLIP8 = Idle · Walk · Run · Eat · Dance · Pos · Neg · Talk` (Aufschrift → Spielzustand).

---

## 3 · Kopfzeile und File-Menü

| Element | Funktion |
|---|---|
| Reiterleiste | fünf Reiter, ein Akzent |
| Pet-Auswahl | `<select>` über den ganzen Roster; **★ = getunt** (ungetunte sind synthetische Vertragseinträge) |
| Theme-Zyklus | ein Knopf, `paper` ⇄ `lab` |
| File | Menü, 318 px |

**File · Ansicht** — `Erklärtexte in den Reglern` (Vorgabe aus; spart im Body-Reiter rund ein Drittel Rollänge).
**File · Session** — `Save drafts (n)` · `Discard drafts …` (mit Rückfrage; Entwürfe leben bis zum Export).
**File · Export** — `This pet (1)` · `Selection (n von m)` · `Full set (n)` · `Load file …` (zeigt, was passiert, **bevor** geschrieben wird).

---

## 4 · Bewohnerklassen (Roster)

Vier Klassen, alle in **denselben** Reitern — das ist die »Rolli-Regel« des Blattes:

| Klasse | Feld | Besonderheit |
|---|---|---|
| Cube-Pet | `kind:'cube'` | 24 Einträge aus dem Vertrag |
| CapsuleCarl | `kind:'capsule'`, `module:'CarlRig'` | baut sein Gesicht über `buildFace` selbst |
| Klo-Rolli | `kind:'hanging'` | `this.rig = r.rig` → der Augen-Reiter greift unverändert |
| FrizzleBob / Graft | `kind:'biped'` (+ `module:'Graft'`) | Zweibeiner-Body-Liste, Materialzonen, Waffe, Pose |
| Recherchi | eigenes Modul | Gesicht über `buildFace`, hängt **nicht** an `this.rig` — steht so im Quelltext, damit es niemand für vergessen hält |

---

## 5 · Was das Studio ausdrücklich **nicht** kann

Damit die Matrix keine Lücke als Feature verkauft:

- `motion.tuning` ist ein Platzhalter (Sprunghöhe, Squash/Stretch, Glättung liegen in der Motion-Library).
- `voice.quelle` ist ein Platzhalter (kein Vertragsfeld für Songquelle / Lip-Sync / Synchronisation).
- `perform` / `balloons` ist tot (`_perform_dead`), der Eintrag hält nur alte Referenzen ruhig.
- Kein Casting-Weg für Zustandsslots: `anim.map` ordnet 24 Spielzustände zu, mißt aber keine Bindung je Kandidat.
- Kein Rundlauf: Export schreibt, niemand liest zurück.

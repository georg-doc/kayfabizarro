# MODULE_MAP · echte Importkanten

Gelesen am 2026-09-17 aus dem Exportbaum: jede `import`-, `import()`- und `new URL(...)`-Zeile mit relativem Ziel. **Keine vermuteten Module.** 80 Code-Dateien gescannt, 26 davon haben lokale Kanten; die übrigen sind Blätter (reine Rechen-/Formmodule) oder laden nur über RAW-URLs.

Einstieg: `src/KFB ToolBox Stage-First v1.dc.html`. Er setzt `window.__KFB_MODBASE = new URL('petstudio-v9/', location.href)` und löst **alle** Studio-Module gegen diesen Anker auf — deshalb ist die Ordnerstruktur Teil der Abhängigkeit und darf beim Intake nicht umsortiert werden.

**Externe Fixpunkte** (nicht im Paket): `three@0.160.0` plus `GLTFLoader`/`OrbitControls`/`RoomEnvironment` über die Import-Map der Blätter · `support.js` als DC-Laufzeit neben jedem `.dc.html`.

### `src/KFB Animation Lab v3.dc.html`
- `./fixtures/kfb-pet-graft-driver.v4.json`
- `./petstudio-v9/kfb-pet-capsule-carl.json`

### `src/KFB FrankenStein Studio v18.dc.html`
- `../`
- `../lab-v6/carl-contract.v1.js`
- `./kfb-pinball-audio.js`

### `src/KFB FrizzleDummy Lab v1.dc.html`
- `./frizzlegraft-v1/ears.v2.js`
- `./frizzlegraft-v1/facehost.v1.js`
- `./frizzlegraft-v1/headgraft.v1.js`
- `./petstudio-v9/studio-v12/brow-rig.v2.js`
- `./petstudio-v9/studio-v12/pet-eye-rig.v6.js`
- `./petstudio-v9/studio-v12/pet-nose.v2.js`
- `./petstudio-v9/studio-v3/pet-mouth.v1.js`

### `src/KFB Recherchi Lab v1.dc.html`
- `./fixtures/kfb-pet-recherchi.json`
- `./frizzlegraft-v1/graft-mount.v1.js`
- `./frizzlegraft-v1/recherchi-mount.v1.js`

### `src/KFB Rigging Lab v1.dc.html`
- `./frizzlegraft-v1/actor-color.v1.js`
- `./frizzlegraft-v1/matzones.v1.js`
- `./lab-v2/audit.js`
- `./lab-v2/sources.js`
- `./lab-v4/carlrig.js`
- `./lab-v6/brow.v3.js`
- `./lab-v6/carl-contract.v1.js`
- `./lab-v6/facegraft.v1.js`
- `./lab-v6/partrig.v1.js`
- `./lab-v6/stache.v3.js`
- `./lab-v6/texclean.js`
- `./lab-v6/zonenames.v4.js`
- `./petstudio-v9/studio-v12/pet-eye-rig.v6.js`
- `./petstudio-v9/studio-v12/pet-nose.v2.js`
- `./petstudio-v9/studio-v3/pet-mouth.v1.js`

### `src/KFB ToolBox Stage-First v1.dc.html`
- `../`
- `../lab-v6/carl-contract.v1.js`
- `./kfb-pinball-audio.js`

### `src/KFB Vergleich Graft vs Carl v1.dc.html`
- `./frizzlegraft-v1/graft-mount.v1.js`
- `./lab-v6/carlrig-mount.v1.js`
- `./lab/assets.js`

### `src/frizzlegraft-v1/ears.v2.js`
- `../petstudio-v9/assets/models/FrizzleBob_Yellow.gltf`

### `src/frizzlegraft-v1/goth-biped.v1.js`
- `../lab-v6/texclean.js`
- `./facehost.v1.js`
- `./graft-biped.v1.js`

### `src/frizzlegraft-v1/graft-biped.v1.js`
- `../petstudio-v9/studio-v12/frizzlebob.v4a.js`
- `./facehost.v1.js`
- `./headgraft.v1.js`

### `src/frizzlegraft-v1/graft-mount.v1.js`
- `../petstudio-v9/studio-v12/pet-eye-rig.v6.js`
- `../petstudio-v9/studio-v3/pet-mouth.v1.js`
- `./graft-biped.v1.js`

### `src/frizzlegraft-v1/headgraft.v1.js`
- `../petstudio-v9/assets/models/FrizzleBob_Yellow.gltf`

### `src/frizzlegraft-v1/recherchi-mount.v1.js`
- `../lab-v4/carlrig.js`

### `src/lab-v6/brow.v3.js`
- `../petstudio-v9/kfb-ink-canon.js`
- `../petstudio-v9/studio-v12/brow-rig.v2.js`
- `./inkform.v1.js`

### `src/lab-v6/browfit.v1.js`
- `../petstudio-v9/kfb-ink-canon.js`
- `../petstudio-v9/studio-v12/brow-rig.v2.js`
- `./facegraft.v1.js`
- `./inkform.v2.js`

### `src/lab-v6/carlrig-mount.v1.js`
- `../lab-v2/audit.js`
- `../lab-v4/carlrig.js`
- `./partrig.v1.js`
- `./texclean.js`
- `./zonenames.v4.js`

### `src/lab-v6/facegraft.v1.js`
- `../frizzlegraft-v1/actor-wobble.v1.js`
- `../lab-v2/audit.js`
- `../lab-v4/carlrig.js`
- `../petstudio-v9/studio-v12/brow-rig.v2.js`
- `./partrig.v1.js`

### `src/lab-v6/stache.v3.js`
- `../petstudio-v9/kfb-ink-canon.js`
- `../petstudio-v9/studio-v12/brow-rig.v2.js`
- `../petstudio-v9/studio-v12/pet-moustache.v1.js`
- `./inkform.v1.js`

### `src/petstudio-v9/kfb-ink-canon.js`
- `./kfb-ink-canon.js`

### `src/petstudio-v9/kfb-pinball-audio.js`
- `./kfb-pinball-audio.js`

### `src/petstudio-v9/podcast-v2/bubbles.v5.js`
- `./bubbles.v4.js`

### `src/petstudio-v9/studio-v12/brow-rig.v2.js`
- `../kfb-ink-canon.js`

### `src/petstudio-v9/studio-v12/frizzlebob.v4a.js`
- `./gun-look.v4a.js`

### `src/petstudio-v9/studio-v12/pet-moustache.v1.js`
- `../kfb-ink-canon.js`
- `./brow-rig.v2.js`

### `src/petstudio-v9/studio-v7/bubble-kiss.v1.js`
- `./edge-treatment.v1.js`

### `src/petstudio-v9/studio-v7/bubble-shaper.v3.js`
- `../kfb-ink-canon.js`
- `../podcast-v2/bubbles.v4.js`
- `../podcast-v2/bubbles.v5.js`

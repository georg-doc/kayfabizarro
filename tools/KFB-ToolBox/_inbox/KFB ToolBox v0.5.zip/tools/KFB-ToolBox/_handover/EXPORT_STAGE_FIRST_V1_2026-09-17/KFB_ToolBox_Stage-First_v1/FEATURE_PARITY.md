# FEATURE_PARITY

Status je Funktion. **UI-Präsenz ist kein PASS.** Wo ich nicht selbst geprüft habe, steht `NOT_TESTED` — auch wenn der Code danach aussieht, als müsste es gehen. Geprüft wurde am **Exportbaum** (`_handover/EXPORT_STAGE_FIRST_V1_2026-09-17/KFB_ToolBox_Stage-First_v1/src/…`), nicht am Projektbaum; Belege in `docs/TEST_REPORT.md`.

Legende: `PRESERVED` · `REPAIRED_FOR_PORTABILITY` · `REIMPLEMENTATION_REQUIRED` · `BLOCKED` · `NOT_TESTED` · `NOT_PRESENT_IN_SOURCE`

## Shell / Stage
| Funktion | Status | Belegt durch |
|---|---|---|
| Eine persistente Navigationszeile (Actor·Face·Pose·Motion·Voice·Stage) | PRESERVED | Kaltstart, Bühne sichtbar, `ready: true` |
| Renderer + Szene + Licht + RoomEnvironment | PRESERVED | Kaltstart ohne Konsolenfehler |
| Bühnenkamera + Kameravorgaben (`_sfCam`) | NOT_TESTED | Code vorhanden, Vorgaben nicht einzeln durchgeklickt |
| Resize / 832-px-Splitscreen | NOT_TESTED | nicht gemessen |
| Theme / App-Hintergrund | PRESERVED | CSS im Blatt |
| Zustand sichern (Sitzung) | NOT_TESTED | `pet-session.v1` vorhanden, Roundtrip nicht am Export geprüft |
| Source-Info / Diagnose-Reiter | PRESERVED | `_sfsource`-Block im Blatt |
| Schriften (13 Familien) | REPAIRED_FOR_PORTABILITY | `document.fonts.load` für Fonteys PRO und Georg Comic je 1 geladen |

## Actor
| Funktion | Status | Belegt durch |
|---|---|---|
| Actor-Picker, 35 Roster-Einträge (kein Demo-Mini-Roster) | PRESERVED | `roster.length === 35` am Export |
| Cube-Pets laden (24) | NOT_TESTED | nur Graft-Driver als Boot-Figur geladen; die 24 nicht einzeln |
| Zweibeiner: GothGirl | PRESERVED | geladen, `✓ GothGirl · GothGirl.glb · 23 bones`, kein `loadErr` |
| Zweibeiner: Graft-Driver (Boot) | PRESERVED | `✓ Graft · Driver · Driver.glb · raw · 23 bones · ×0,42` |
| Zweibeiner: FrizzleBob / +Gun / Graft-Medium / -Orc / -Clown | NOT_TESTED | im Roster, nicht geladen |
| Requisite: CapsuleCarl | PRESERVED | `✓ CapsuleCarl`, kein `loadErr` |
| Hängend: Klo-Rolli | PRESERVED | `✓ Klo-Rolli · GLB Repo (raw) · Rolle ×4,13 · Modell-Blatt weg (10/62)` |
| HTML-Würfel: Recherchi | PRESERVED | `✓ Recherchi · sechs Flächen · 6/6 gültig · foreignObject → CanvasTexture` |
| Körper / Materialien / Materialzonen | NOT_TESTED | `matzones`/`headzones` vorhanden, Regler nicht bedient |
| Zubehör / Spenderteile (Ohren, Kopf, Braue, Nase, Bart) | NOT_TESTED | Module vorhanden und geladen, Ergebnis nicht am Export bewertet |
| Maß / Fit / Root-Orientierung | PRESERVED | Skalierungszeilen liefen (×0,42 · ×0,46 · ×4,13 in den Statusmeldungen) |
| Profil-Import/-Export (kfb.pets/1) | NOT_TESTED | Wege vorhanden, Roundtrip nicht am Export durchgeführt |

## Face
| Funktion | Status | Belegt durch |
|---|---|---|
| EyeRig v6 (Kugelaugen, Lider, Wimpern, Splay, Konvergenz) | PRESERVED | vier Wirte gebaut, je 2 Augen (Studio-Messung 17.09.) |
| **Augenquellen-Wächter** (eine Quelle pro Figur) | PRESERVED | `state.eyePolicy.ok === true`, kein Halt in vier Ladewegen |
| Pupillenstile / Glanz / Pupillengröße | NOT_TESTED | Werte kommen aus dem Vertrag, Regler nicht bedient |
| Lider / Wimpern | NOT_TESTED | — |
| Brauen (gezeichnet + gegraftet) | NOT_TESTED | `browfit.v1` geladen, Form nicht bewertet |
| Nasen-Pool / Mund-Pool | NOT_TESTED | `pet-nose.v2`, `pet-mouth.v1` (drei Decal-Sätze) vorhanden |
| Viseme / Talk-Vorschau | NOT_TESTED | `talkBurst` vorhanden; am Export nicht ausgelöst |
| Emotion / Emote-Deltas | NOT_TESTED | `_applyEmote` vorhanden |
| Sekundärbewegung (Wobble) | NOT_TESTED | `actor-wobble.v1` vorhanden |

## Pose
| Funktion | Status | Belegt durch |
|---|---|---|
| Root-Transform · Gelenkwinkel · Zweiknochen-Löser · Sitzkontakt | NOT_TESTED | `pose-rig.v1.js` mit Presets (`stand`, `armchair`, …) vorhanden |
| Pose speichern / neu laden | NOT_TESTED | `pose`-Feld am Eintrag vorhanden, Roundtrip nicht geprüft |
| IK-/Kontaktziele für Hand und Fuß | NOT_TESTED | im Modul vorhanden |

## Motion
| Funktion | Status | Belegt durch |
|---|---|---|
| Clip-Suche / Familien / acht Rig_Medium-Sätze | NOT_TESTED | `lab-v2/sources.js` + `anim-audit.v1` |
| Play / Pause / Scrub / Stop / Rest | NOT_TESTED | am Export nicht bedient |
| Mixer-Eigentum | PRESERVED | ein Mixer je Figur (`Character`/Zweibeiner-Modul) |
| Kompatibilitäts-/Bindungsbericht (Track-Bindung) | PRESERVED (Mechanismus) · NOT_TESTED (Lauf) | `bindingCoverage`-Verfahren im Code; der letzte gemessene Lauf stammt aus `docs/handover/…/casting-probe.json`, nicht aus diesem Export |
| Pose über Motion | NOT_PRESENT_IN_SOURCE | keine Überblendung von Pose auf laufende Clips gefunden |

## Voice
| Funktion | Status | Belegt durch |
|---|---|---|
| Blasen (Grundform, Rand, Zipfel, Kuss-Schicht) | NOT_TESTED | `bubble-shaper.v3`, `edge-treatment.v1`, `bubble-tail.v1`, `bubble-kiss.v1` |
| Text / Sample / Stimmenwahl | NOT_PRESENT_IN_SOURCE | keine Stimmenauswahl im Blatt gefunden |
| Speak / Stop | NOT_TESTED | Mundbewegung über `pet-mouth`; echte Sprachausgabe nicht im Baum |
| Audio-Adapter | BLOCKED | `kfb-pinball-audio.js` lädt `./kfb-pinball-sfx.json` — Datei fehlt im Baum (SOURCE_GAP-2). Ton in Claude ohnehin nicht abnehmbar. |

## Stage
| Funktion | Status | Belegt durch |
|---|---|---|
| Actors auf der Bühne | PRESERVED | vier Klassen geladen |
| Boden / Maßfläche / Pad | PRESERVED | Statusmeldungen mit Maßen |
| Requisiten platzieren / transformieren / entfernen | NOT_TESTED | Wege im Blatt vorhanden |
| Kameras / Licht / Umgebung | NOT_TESTED | vorhanden, nicht bedient |
| Szene/Welt speichern + neu laden | NOT_TESTED | — |
| Curtain / Kern-Bühnenmodule | NOT_TESTED | — |
| Birthday-Startscreen / Terraformer / Dungeon | NOT_PRESENT_IN_SOURCE | ausdrücklich nicht nachgebaut (Briefing §4) |

## Resource Picker
| Funktion | Status | Belegt durch |
|---|---|---|
| Kontext `actor` (Browse → Preview → Accept/Revert) | PRESERVED (Code) · NOT_TESTED (Lauf) | `_sfPick`, `sfPreview`, `sfPin` im Blatt |
| Kontexte `rig-part` · `motion` · `prop` · `stage` · `performance` | NOT_TESTED | teils über die Reiter erreichbar, nicht einzeln geprüft |
| Verhalten bei nicht erreichbarer Registry | NOT_TESTED | Rückweg »Repo → lokal → Entwurf« im Code, Ausfall nicht simuliert |
| Zweite Asset-Registry | NOT_PRESENT_IN_SOURCE | korrekt so — Librarian bleibt eigenes Werkzeug |

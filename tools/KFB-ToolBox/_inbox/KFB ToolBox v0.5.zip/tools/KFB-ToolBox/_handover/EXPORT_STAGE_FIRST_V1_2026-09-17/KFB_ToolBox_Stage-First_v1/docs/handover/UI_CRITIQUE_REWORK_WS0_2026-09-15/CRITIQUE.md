# CRITIQUE · KFB ToolBox Pilot v1

**15.09.2026 · WS0 / Desktop Design · UI critique before rework**
Gegenstand: `_inbox/WS0_2026-09-15/unpacked/B_OBERFLAECHE/KFB ToolBox Pilot v1.dc.html` (Ergebnis B).
Ergebnis A ist nicht Gegenstand und wurde nicht angefaßt.

Jede Zeile hier hat eine Fundstelle oder eine Messung. Gemessen wurde am echten Rig, nicht am
Screenshot: `qa/defect-probe.html` lädt `mountCarl` und `mountGraft` aus dem Quellstand über HTTP,
three r160, und schreibt `qa/defect-probe.json`.

**Eine Instrumentenkorrektur vorweg, weil sie die Aussage trägt:** der erste Lauf hat die Braue ohne
`updateMatrixWorld` gemessen und ein funktionierendes Bedienelement als tot gemeldet. Das Werkzeug
wurde repariert und neu gefahren. Berichtet ist nur Lauf 2. Wer das nicht dazusagt, verkauft einen
Meßfehler als Befund.

---

> **Nachtrag 15.09., nach Georgs Kurskorrektur.** Dieses Dokument prüft **gemeldete Defekte** und
> benennt ihre Owner. Es ist **keine Informationsarchitektur**. Carl ist hier Meßgegenstand, weil
> drei der vier Meldungen an ihm hängen — nicht Vorbild für Aufbau, Sprache oder Funktionsumfang
> der ToolBox. Die UX-Quelle ist **FrankenStein Studio v17**; das Inventar steht in
> `STUDIO_V17_INVENTORY.md`, die Zuordnung alt→neu in `COVERAGE_MATRIX.md`. Wer aus F1–F10 eine
> Oberfläche ableitet, ohne die Matrix gelesen zu haben, baut das falsche Werkzeug.

## Die Kernaussage

Der Pilot hat die Schrittfolge richtig. Was fehlt, ist **Zugriff auf das, was unter ihm schon
gebaut ist**. Drei der vier von Georg gemeldeten Defekte sind Oberflächenlücken über funktionierenden
Modulen — und einer ist ein echter Rig-Defekt, der durch keine Oberfläche zu heilen ist.

| Georgs Meldung | Meßbefund | Owner |
|---|---|---|
| Carl-Brauen dysfunktional | Rig funktioniert exakt, **es gibt kein Bedienelement dafür** | UI |
| Tapering kaputt / nie korrekt | **Bestätigt, zweifach** — kein Griff am ausgelieferten Weg, fast wirkungslos am anderen | Rig / Contract |
| Materialzonen brauchen Textur-/Surface-Zugriff | Für den Graft **existiert beides und ist unsichtbar**; für Carl existiert es nicht | UI · Material |
| Colorpicker kaputt | **Bestätigt** — es gibt gar keinen; Hex, Copy, Esc, Klick-außerhalb, Validierung fehlen alle | UI |

---

## F1 · Der vollständigste Materialzonen-Besitzer im ganzen Baum ist in der ToolBox unsichtbar
**Owner: UI** · Priorität 1

**Beleg.** `mountGraft` gibt `handle.matZones` zurück: `kfb.matzones/0.1`, gemessen **11 benannte
Zonen** auf dem Driver-Wirt (Jacke 992 Dreiecke · Haut·Hände 760 · Hose 376 · Brille·Gestell 364 ·
Wirtskopf·verdeckt 336 · Schuh dunkel/hell · Brillenglas · Shirt·Brustlogo · Rücken links/rechts),
jede mit `base` (Original), `hex` (Überschreibung), `finish`, `skin`, `hidden`, Netzliste, Dreieckszahl.
Methoden: `setColor · setFinish · setStamp · clearStamp · apply · export · reassert · report`.
Fünf Oberflächen mit echten Zahlen: Stoff 0,94/0,00 · Matt 0,82/0,00 · Leder 0,44/0,06 (Korn 0,13) ·
Lack 0,16/0,10 · Metall 0,30/0,85.

Der Pilot zeigt für diesen Actor **null Zonen** und schreibt in den Inspector, die Zonen des Grafts
seien »owned by the Studio tab — not re-implemented here«.

**User cost.** Georgs Forderung »Materialzonen brauchen Texturen / Surface-Zugriff« ist für den
Graft **seit Tagen gebaut** und er kommt in der ToolBox nicht daran. Die Anforderung aus §7.2 des
Auftrags — `Zone → Base Color → Surface/Texture → Roughness/Relief nur wenn unterstützt` — ist für
diesen Actor 1:1 das, was der Besitzer schon kann.

**Smallest useful repair.** Dieselbe Zonenliste für beide Actors, gespeist aus dem jeweiligen
Besitzer: Carl aus `report.names` + `setZoneStyle`, Graft aus `matZones.report().zones` +
`setColor`/`setFinish`. Kein zweiter Shader, kein zweiter Vertrag — nur die Fläche.

---

## F2 · Farbarbeit zerstört die Textur und ist nicht rücknehmbar
**Owner: UI** · Priorität 1

**Beleg.** Der Besitzer kann es richtig: `lab-v4/carlrig.js#setZoneStyle(part,{hidden,color})` legt
beim Split `mesh.userData.origMap` an und gibt bei `color:null` die Originaltextur zurück. Gemessen:
**21 von 21 Inseln tragen `origMap`**, 19 tragen eine Textur, und der Rundlauf über den Besitzer
funktioniert — `map true → false → true`, Farbe `#f2c83c → #ffffff`.

Der Pilot ruft diesen Griff **nicht** auf. `_applyZone` klont das Material selbst, setzt
`mesh.material.map = null` und hat keinen Rückweg; `_zoneOriginal` setzt nur `color:null` im State
und schreibt »REMOUNT NEEDED« in die Warnzeile. Der Knopf heißt **Original** und stellt nichts her.

**User cost.** Jeder Farbversuch ist eine Einbahnstraße. Wer die gemusterte Zone probeweise färbt,
verliert das Muster bis zum Neuaufbau — und der Knopf, der das verspricht, lügt.

**Smallest useful repair.** `_applyZone` löschen, `setZoneStyle` aufrufen. Das ist weniger Code als
jetzt dasteht, und `Original` wird dabei ehrlich.

---

## F3 · Es gibt keinen Colorpicker — und im Rigging Lab den falschen
**Owner: UI** · Priorität 1

**Beleg.** Pilot: acht fest verdrahtete Felder in `PALETTE`, kein Eingabefeld, kein `Copy`, keine
Validierung. Der Hexwert ist **nur dann** lesbar, wenn man vorher ein Feld angeklickt hat — sonst
steht »original« da, und der tatsächliche Wert der Zone bleibt unsichtbar. Rigging Lab v1 (Teil 1,
gemessen): **21 × `input[type=color]`**, also der Betriebssystem-Wähler — der kennt weder Esc noch
Klick-außerhalb als Vertrag, liefert keinen lesbaren Wert und keine Kopierfunktion.

**User cost.** Genau Georgs Meldung, an beiden Oberflächen nachvollzogen. Ohne `#hex` und `Copy`
kann ein Wert die ToolBox nicht verlassen; ohne Validierung kann ein ungültiger Wert still
gespeichert werden; ohne Esc/Klick-außerhalb hängt der Wähler.

**Smallest useful repair.** Ein Popover je Zone: aktueller `#RRGGBB` groß und lesbar, `Copy`,
Eingabefeld mit Prüfung (3- und 6-stellig, `#` optional), kuratierte Palette, `Original`.
Esc schließt, Klick außerhalb schließt, ungültige Eingabe wird **sichtbar abgewiesen** und nicht
übernommen. Kein Modal.

---

## F4 · Carls Brauen haben in der ToolBox überhaupt kein Bedienelement
**Owner: UI** · Priorität 2

**Beleg.** Gemessen: `origBrow` ist eine `PartRig` über die Modell-Inseln **7 und 8**, `enabled:true`,
beide Netze sichtbar. Sie **reagiert exakt**: bei `scale 1.6` wächst die Höhe um Faktor **1,600**
(0,1663 → 0,2661) und die Paarbreite um **0,1801** — das sind 0,6 × 0,3 pro Braue bei unveränderter
Lücke, also genau die Skalierung um die je eigene Mitte. Bei `lift 0.05` wandert die Mitte um
**exakt 0,0500** (1,5187 → 1,5687).

Im Piloten baut `sliderRows` ausschließlich die Nase (`META` mit vier Nasenfeldern). `_partSet('brow', …)`
und `_partVal('brow', …)` existieren im Code und werden **von keiner Fläche erreicht**.

**User cost.** »Die Brauen sind dysfunktional« ist berechtigt und die Ursache ist nicht das Rig.
Der Vertrag steht außerdem auf Nullwerten (`scale 1, spread 0, lift 0, depth 0, tilt 0`) — es sieht
aus wie kaputt, weil nie etwas eingestellt wurde und nichts einzustellen ist.

**Smallest useful repair.** Dieselben fünf Felder wie bei der Nase auch für die Braue ausgeben —
das tote Codestück wird dadurch benutzt, nicht ersetzt.

---

## F5 · Tapering hat am ausgelieferten Carl keinen Griff
**Owner: Rig / Contract** — nicht UI · Priorität 2

**Beleg.** Der Vertrag `petstudio-v9/kfb-pet-capsule-carl.json` setzt `brow.mod: "block"`. Damit
schaltet `carlrig-mount.v1.js` die Insel-Braue ein und die **gezeichnete** Braue aus (gemessen:
`drawnBrow.enabled false`, `mesh.visible false`) — und nur die gezeichnete hat ein `taper`-Feld.
`PartRig` kennt genau sechs Felder: `enabled, scale, spread, lift, depth, tilt`.
`origBrow.set({taper:0.5})` antwortet gemessen `{"status":"UNSUPPORTED","field":"taper","reason":"unknown"}`.

**User cost.** Ein Regler namens »Taper« kann an diesem Actor nur eine Lüge sein. Georgs »war nie
korrekt« ist an dieser Stelle wörtlich richtig: es war nie angeschlossen.

**Smallest useful repair.**
*UI (jetzt):* Das Feld steht in der Braue als `taper — nicht auf diesem Weg` mit genau dieser
Abweisungszeile daneben. Kein grauer Regler, der nach »kommt noch« aussieht.
*Rig (Handoff):* entweder eine Verjüngung in `PartRig` (Geometrie-Ebene, nicht Transform — die Insel
wird heute nur skaliert/verschoben/gedreht), oder der Vertrag wechselt für Carl auf `brow.mod !== 'block'`
und nimmt die gezeichnete Braue samt F6.

---

## F6 · Am gezeichneten Weg ist `taper` in seiner Vorgabestellung fast wirkungslos
**Owner: Rig** · Priorität 2

**Beleg.** Halbbreite einer Brauenhälfte bei 97 % / 75 % / 50 % / 8 % der Länge, Verhältnis Mitte ÷ Spitze:

| Modus | taper 1 | taper 0 | Spanne |
|---|---|---|---|
| `even: true` (**Vorgabe**) | 6,30 | 7,29 | **16 %** |
| `even: false` (Feder) | 5,18 | 0,27 | **Faktor 19** |

Im Quelltext sichtbar, warum: bei `even !== false` fällt die Hüllkurve `envelope` aus `capF` heraus,
der Bauch `1 + .18·taper·sin` entfällt, und die Federbreite wird vorher zu **einem** Mittelwert
`evenW` verrechnet. Was man als Verjüngung sieht, ist `cap`.

**User cost.** Der Regler bewegt sich, die Form nicht. Das ist die teuerste Sorte Bedienelement:
eins, das Vertrauen kostet, ohne einen Fehler zu werfen.

**Smallest useful repair (Rig).** Entweder `taper` in `even` wirken lassen (Hüllkurve auf `capF`
multiplizieren statt ersetzen) oder das Feld in diesem Modus ehrlich `cap` nennen. Kein UI-Fix möglich.

---

## F7 · Carl hat keinen Surface-Besitzer, der Graft hat einen
**Owner: Material / Contract** · Priorität 3

**Beleg.** Graft: fünf Oberflächen mit Rauheit/Metall/Korn, `setFinish(id, key)`, eigene Roughness-
und Metalness-Karte, deterministisches Lederkorn. Carl: `setZoneStyle(part, {hidden, color})` —
im ganzen Besitzermodul kein `map`-, `roughness`- oder `normal`-Argument.

**User cost.** »Texturen für alle relevanten Zonen« ist für den einen Actor heute erreichbar und für
den anderen nicht. Eine Oberfläche, die das verwischt, produziert genau den stillen Ausfall, den der
Auftrag verbietet.

**Smallest useful repair.**
*UI (jetzt):* Surface ist bei Carl sichtbar `not connected on this actor` mit Nennung des Besitzers,
bei Graft voll bedienbar. Keine zweite Shader-Wahrheit.
*Material (Handoff):* wenn Carl Oberflächen bekommen soll, gehört der Griff in `lab-v4/carlrig.js`,
nicht in die ToolBox.

---

## F8 · Der eine echte Consumer-Workflow hat keine Fläche
**Owner: UI** · Priorität 3

**Beleg.** Schritt 4 des Piloten bietet `Talk on · Rest · Burst 1.8 s`. Carl hat kein Skelett und
keine Clips; der Graft hat beides, aber weder Slot noch Kandidatenliste noch Bindungsmaß.
Der Birthday-Return hat genau diesen Weg schon gemessen — Idle_A · Waving · Cheering · Rest je
**69/69 Spuren**, ein offener Slot (Dance P1, Kandidat `Skeletons_Taunt_Longer`), Hihi als
Bibliotheksplatz, EyeRig-Speaker P1.

**User cost.** Der Weg `actor → rig family → state slot → candidate clip → binding coverage →
accept/reject` existiert als Nachweis, aber nicht als Werkzeug. Beim nächsten Casting fängt jemand
wieder mit einer Sonde an.

**Smallest useful repair.** Die State-Slots als Liste, je Slot wenige Kandidaten, die
Bindungsabdeckung als Zahl neben dem Kandidaten, `accept`/`reject` in den Entwurf. Keine Clip-Masse.

---

## F9 · Drei Spalten bei jeder Breite; die vier Prüfgrößen sind nie gemessen worden
**Owner: UI** · Priorität 3

**Beleg.** Der Pilot hält `leftDisplay:'flex'` und `rightDisplay:'flex'` konstant — 210 px + 330 px
feste Spalten neben der Bühne, ohne Umbruch. Teil 1 und Teil 2 sagen beide ausdrücklich, daß
1440×900 · 1024×768 · 768×1024 · 390×844 **nicht** gemessen wurden; der eine Versuch schlug fehl,
weil die Bühne absolut positioniert ist.

**User cost.** Bei 768 px bleiben der Bühne rechnerisch 228 px. Bei 390 px ist die Oberfläche nicht
bedienbar, und niemand weiß, ab wo genau — das ist der eigentliche Schaden.

**Smallest useful repair.** Zwei Haltepunkte, Drawer statt Spalte, und die vier Größen tatsächlich
fahren und als Bild ablegen.

---

## F10 · Der Export läßt sich nicht zurücklesen
**Owner: UI** · Priorität 4

**Beleg.** `_outProfile` lädt eine `kfb.pets/1`-Datei herunter. Es gibt keinen Weg, sie wieder
hereinzuholen — weder in der ToolBox noch als unabhängige Gegenprobe. Der Pilot-Bericht führt das
selbst als offen. Die Feldabdeckung im Export-Schritt zeigt außerdem den Bericht **vom Mount**, nicht
vom Export: gemessen `6 applied · 0 rejected` — dieselben sechs Zeilen unabhängig davon, was man
seither eingestellt hat.

**User cost.** Der Prüfablauf des Auftrags endet einen Schritt vor dem Ziel. Ein Profil, das nie
gelesen wurde, ist eine Behauptung.

**Smallest useful repair.** `Import profile` neben `Save profile`, Datei anwenden, Feld für Feld
gegenüberstellen: was ankam, was abgewiesen wurde, was sich gegenüber dem Original geändert hat.

---

## Was bleiben soll

Die Schrittfolge selbst. Die ruhige, große Bühne mit aufgabenbezogenen Kamerastellungen. Die
32-px-Bedienung mit Zahlenfeld neben dem Regler. Die vier **benannten** Ausgaben mit »Not built«
statt Weglassen. Der eigene Sitzungsschlüssel, der Georgs Werkbank nicht anfaßt. Und die Herkunfts-
tafel in Schritt 1 — Reader, Contract, Schema, Entry, Class: das ist die beste Fläche im Piloten.

## Nicht geprüft

Zweiter Reiter und Wiederaufnahme aus der Sitzung. Bildschirmleser. Browserzoom und geteiltes
Fenster. Der Graft-Weg im Animation Lab. Georgs Werkbanksitzung `kfb.carl.rig.v6.3` — nicht angefaßt,
nicht gemessen, nicht verändert.

# DECISIONS · datiert, mit Grund

## 2026-09-17 · Augenquellen: eine pro Figur, geprüft statt gebeten
**Problem:** `SETS.animals.mods = ['googly','emotes']` war seit SPRINT 10 die Set-Vorgabe. Jeder Aufrufer, der `mods: []` vergaß, bekam ein zweites Augenpaar — Georgs Befund am Bild: »kitten hat doppeltes augen-rig«.
**Entscheidung:** Vorgabe auf `['emotes']`; googly nur auf Bestellung (`face.pupil.form === 'googly'`). Auflösung in **einer** Funktion `resolveMods(set, opts)`. Zwei Prüfungen: `assertEmbedEyePolicy(SETS)` beim Start (Vorgabe) und `assertSingleHostEyeSource` nach dem Bau (Ergebnis, in allen vier Ladewegen). Fehlschlag = Figur unsichtbar + Fehler im Ladeschirm.
**Voll dokumentiert:** `docs/handover/BIRTHDAY_STARTSCREEN_2026-09-15/EYE_SOURCE_RULE.md`.

## 2026-09-17 · Augenquellen werden IM Studio belegt
**Problem:** ein freistehender Prüfstand baute die vier Bewohner nackt (Modul + Augen-Rig) und produzierte kaputte Figuren als »Belege« — ohne Mund, ohne Textur-Wäsche, ohne Bodenhöhe, ohne Würfelflächen, ohne Klorollen-Logik.
**Entscheidung:** die Probe darf **zählen, nicht darstellen**. Belege kommen aus dem Studio, wo die Fixes liegen. Ein Prüfstand, der den Wirt neu zusammensetzt, ist eine zweite Wahrheit.

## 2026-09-17 · Schriften über GitHub statt über einen Ordner, den es nicht gibt
**Entscheidung (Georg):** patchen. `REPAIRED_FOR_PORTABILITY`, Rückweg im Code kommentiert. Schrift-Binaries kommen nicht ins Paket (Briefing §5).

## 2026-09-17 · `kfb-card-backside.png` bleibt lokal
`cardrider.v1.js` begründet es selbst: »ein Blatt, das aus dem Netz nachlädt, ist beim nächsten Ausfall ein leeres Blatt«. Eigentümer-Entscheidung wird nicht still umgedreht (Briefing §8).

## 2026-09-17 · `FrizzleBob_Yellow.gltf` kommt mit, als Ausnahme
Georg: große Dateien weglassen. Diese eine nicht: GitHub-Suche über 8 647 Dateien ohne Treffer, und ohne sie ist der Graft-Pfad (Schädel + Ohren) tot. Markiert als `NEW_ASSET_REQUIRES_GITHUB_IMPORT`.

## 2026-09-16 · Stage-First-Richtung (übernommen, nicht neu entschieden)
Eine persistente Navigationszeile · Bühne dominant · keine Developer-Dashboards im Authoring · Funktionsfülle über Progressive Disclosure · Asset Librarian bleibt eigenes Werkzeug · keine zweite Asset-Registry. Quelle: `docs/handover/UI_RESET_MINIMAL_STAGE_FIRST_2026-09-15/RETURN_CONCEPT.md`.

## Owner, die dieser Export NICHT anfasst
`kfb.pets/1` · `media/3D_Assets/pet-LIBRARY.json` · Registry/Librarian (Discovery) · Rigging/Animation (Kompatibilität) · Travel/Combat/Stunt (Gameplay-Runtime). Stage-First exportiert Authoring-Daten und Kandidaten — es wird dadurch kein Runtime-Owner (Briefing §9).

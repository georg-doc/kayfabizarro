# HOUSEKEEPING · Stage-First v1 (living)

Status je Artefakt: `AKTIV` · `FROZEN` · `SUPERSEDED` · `DEAD` · `ASSET`.
Nichts wird gelöscht ohne Georgs Freigabe, jeder Schritt einzeln.

## Deliverables
| Datei | Status | Hinweis |
|---|---|---|
| `src/KFB ToolBox Stage-First v1.dc.html` | AKTIV | Export-Einstieg · 653 KB |
| `src/KFB FrankenStein Studio v18.dc.html` | AKTIV | Promotion-Donor, trägt die Fixes |
| `src/KFB FrankenStein Studio v17.dc.html` | SUPERSEDED | Rückweg |
| `src/KFB Rigging Lab v1.dc.html` · `Animation Lab v3` · `Recherchi Lab v1` · `FrizzleDummy Lab v1` · `Mech and Vehicle Rig v2` · `Vergleich Graft vs Carl v1` | AKTIV | eigenständige Authoring-Blätter |
| `qa/Stage-First QA.dc.html` | AKTIV | QA-Blatt, 13 PASS / 0 FAIL (16.09.) |

## Geteilte Module (nicht als tot einstufen)
`petstudio-v9/studio-v3/pet-library.v6.js` · `studio-v3/pet-mouth.v1.js` · `studio-v3/eye-source-guard.v1.js` · `studio-v12/pet-eye-rig.v6.js` · `lab-v4/carlrig.js` · `lab-v6/*` · `frizzlegraft-v1/*` — importiert von mehreren Blättern.
`support.js` liegt **absichtlich dreifach** (identischer Hash): DC-Laufzeit muss neben jedem Blatt liegen.

## Vorgänger
`ears.v1.js` SUPERSEDED (v2 aktiv) · `inkform.v1.js` SUPERSEDED (v2 aktiv) · `Studio v17` SUPERSEDED.

## Assets (nie ins Paket, immer über GitHub)
KayKit-Charaktere/Animationen · Cube-Pet-GLBs · Schriften · `kfb-pinball-sfx.json`.
Lokal im Baum und daher im Paket: `FrizzleBob_Yellow.gltf` (Spenderkopf, 594 KB) · `kfb-card-backside.png` (256 KB).

## Clean-Run-Checkliste
1. Einstieg öffnen → Bühne sichtbar, keine fehlenden Module in der Konsole.
2. `state.eyePolicy.ok === true` (Augenquellen-Vorgabe sauber).
3. Rosterplätze 25 · 26 · 32 · 34 laden ohne `loadErr` (Carl · Rolli · GothGirl · Recherchi).
4. Actor → Face → Pose → Motion → Voice → Stage durchklicken, eine Navigationszeile.
5. Profil exportieren, neu laden, importieren → gleicher Zustand.

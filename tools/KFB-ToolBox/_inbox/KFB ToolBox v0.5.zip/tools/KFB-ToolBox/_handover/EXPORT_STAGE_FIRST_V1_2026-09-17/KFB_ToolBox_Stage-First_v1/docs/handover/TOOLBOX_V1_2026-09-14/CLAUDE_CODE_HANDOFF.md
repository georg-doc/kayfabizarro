# Handoff · Claude Code · KFB ToolBox T1 Site

Kopiere den Block unten in eine Claude-Code-Session im Checkout von `georg-doc/kayfabizarro`. Georg muss keine Git-Arbeit übernehmen.

---

Du übernimmst Git/PR für KFB ToolBox T1. Quelle ist das ZIP `KFB_TOOLBOX_V1_RETURN_2026-09-14.zip` (Pfad wird dir genannt). Kein Neubau, keine Änderung an den drei Standalone-HTMLs, keine Änderung außerhalb `tools/KFB-ToolBox/`.

1. `git fetch origin && git switch -c toolbox/t1-site-2026-09-14 origin/main`.
2. ZIP entpacken; `CHECKSUMS.sha256` prüfen (`shasum -a 256 -c`; die fünf Zeilen mit `->`-Mapping stehen für Configs mit Klammern im Namen — Hash gegen die Originaldatei prüfen). Bei Abweichung stoppen und melden.
3. Inhalt nach `tools/KFB-ToolBox/` kopieren. Erwartet neu/geändert:
   - `site/` (index.html, KFB ToolBox.dc.html, support.js, drei Standalone-HTMLs, configs/ mit 6 JSON)
   - `docs/MISSING_MODULES.md`, `docs/BUNDLE_RELATIVE_REFS.json`, `docs/FONT_INVENTORY.json`
   - `TOOLBOX_MANIFEST.json`, `CHANGELOG.md`
   - `MASTERPLAN.md` (additiv ergänzt), `CHECKSUMS.sha256`
   - `_handover/TOOLBOX_V1_2026-09-14/{RETURN.md,CLAUDE_CODE_HANDOFF.md,evidence/*,review_intake_2026-09-14/*}`
   Die Standalones in `site/` müssen byte-identisch zu `tools/KFB-ToolBox/KFB ToolBox (…)/WSA_2026-09-13/` sein: `git hash-object` je Datei gegen die Blob-SHAs im Manifest (7da185ab…, 720bafd3…, be880ee0…). Bei Abweichung stoppen.
4. `git add tools/KFB-ToolBox && git commit -m "toolbox: T1 partial — site entry, config catalog, boot findings, review intake (source export blocked)"`.
5. `git push -u origin toolbox/t1-site-2026-09-14` und PR gegen `main` öffnen. PR-Text: RETURN.md-Abschnitte IMPLEMENTATION und TESTED RESULT übernehmen; Titel „KFB ToolBox T1: Site-Einstieg + Boot-Befund, Modulbaum fehlt“.
6. Nach Pages-Deploy des PR-Previews (oder nach Merge, wie Georg entscheidet): `https://<pages-host>/tools/KFB-ToolBox/site/` öffnen, Screenshot; bei jedem der drei Tool-Links prüfen, dass die Shell erscheint und den in RETURN.md genannten Modulfehler zeigt (erwartet FAIL bis Modulbaum vorliegt). URL, Commit-SHA und Beobachtung in `RETURN.md` unter „Identität“ und „Publikation“ nachtragen, `TOOLBOX_MANIFEST.json` `site.liveUrl` und `apps[].liveUrl` setzen, additiven CHANGELOG-Eintrag `IMPLEMENTATION · Publikation` anlegen, committen, pushen.
7. Kein Merge ohne Georgs Wort. Keine Registry-Promotion. Nichts in Travel/Combat/Stunt/Wissens-Pilli.

Melde zurück: Branch, Commit-SHA, PR-URL, Pages-URL, Ergebnis Schritt 6.

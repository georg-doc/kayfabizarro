# ToolBox · Fehlende Module der drei Standalone-Bundles

Status: SOURCE FACT · 2026-09-14 · Prüfart: Bundles im Chromium entpackt, Modul-Referenzen aus Template + entpackten JS-Ressourcen extrahiert (`docs/BUNDLE_RELATIVE_REFS.json`), Kaltstart im Browser beobachtet.

## Befund

Die drei „-standalone-“-HTMLs (Pins im TOOLBOX_MANIFEST, byte-identisch zu GitHub geprüft) bündeln nur `support.js`, die DC-Skripte und Webfonts (woff2). **Die lokalen Module werden zur Laufzeit per relativem `import()` nachgeladen und sind nicht im Bundle.** Ohne den Modulbaum neben der HTML-Datei zeigt jedes Werkzeug seine Oberfläche und bricht dann ab.

| Bundle | Erster beobachteter Fehler | Beleg |
|---|---|---|
| FrankenStein Studio v17 | `Failed to fetch dynamically imported module: …/petstudio-v9/studio-v7/pet-session.v1.js` (Unhandled rejection; Canvas bleibt leer) | `_handover/TOOLBOX_V1_2026-09-14/evidence/boot_frankenstein-studio-v17_2026-09-14.jpg` |
| Rigging Lab v1 | `Failed to resolve module specifier './lab-v2/sources.js'` (Fehlerbox im Canvas, Regler sichtbar) | `…/evidence/boot_rigging-lab-v1_2026-09-14.jpg` |
| Animation Lab v2 | `lab/assets.js failed: Failed to fetch dynamically imported module`; Warnungen `[anim-contract] fehlt`, `[pet-session] fehlt` | `…/evidence/boot_animation-lab-v2_2026-09-14.jpg` |

Externe Abhängigkeiten (`three/addons/*` per Importmap von CDN) sind nicht Teil dieses Befunds.

## Benötigte Dateien je Bundle (relativ zum HTML)

### Animation Lab v2 (5)
```
frizzlegraft-v1/anim-contract.v1.js
lab/assets.js
lab/locomotion.js
lab/zipstore.js
petstudio-v9/studio-v7/pet-session.v1.js
```

### Rigging Lab v1 (15)
```
frizzlegraft-v1/actor-color.v1.js
lab-v2/audit.js
lab-v2/sources.js
lab-v4/carlrig.js
lab-v6/brow.v3.js
lab-v6/carl-contract.v1.js
lab-v6/facegraft.v1.js
lab-v6/partrig.v1.js
lab-v6/stache.v3.js
lab-v6/texclean.js
lab-v6/zonenames.v4.js
petstudio-v9/kfb-pet-capsule-carl.json
petstudio-v9/studio-v12/pet-eye-rig.v6.js
petstudio-v9/studio-v12/pet-nose.v2.js
petstudio-v9/studio-v3/pet-mouth.v1.js
```

### FrankenStein Studio v17 (Einstieg + transitive Closure)
Direkt referenziert: `petstudio-v9/studio-v7/pet-session.v1.js`, `lab-v2/graft.js`, `lab-v6/carlrig-mount.v1.js`, `lab-v6/facegraft.v1.js`, `lab-v6/browgraft.v1.js`, `petstudio-v9/kfb-pet-graft-driver-default.json`, `petstudio-v9/assets/models/FrizzleBob_Yellow.gltf`, sowie aus Modulen heraus `../frizzlegraft-v1/{anim-audit,anim-map,cardrider,donoreyes,eyeoval,graft-biped,headzones,matzones,seat-lab,wordmark}.v1.js`. Die petstudio-v9-Module (studio-v3 … v13) importieren weitere Dateien transitiv; vollständige Liste nur aus dem Original-Workspace, nicht aus dem Bundle ableitbar.

Dazu 17 Schriftdateien unter `fonts/` (siehe FONT_INVENTORY.json) — für den Start nicht blockierend (`font-display: swap`).

## Wo die Quellen liegen und wo nicht

| Quelle | Stand | Deckt |
|---|---|---|
| `georg-doc/kayfabizarro` @ 6ea5d439 | 14.09. | nur `skills/KFB PetStudio/KFB FrankenStein Studio 16/KFB-v16/**` (v16-Baum, 59 Dateien inkl. `pet-session.v1.js`, `frizzlegraft-v1/`, `FrizzleBob_Yellow.gltf`) |
| Lokal `CLAUDE/KFB FrankenStein Lab + Models/KFB Rigging Lab v1/` (Authoring-Workspace-Kopie) | **vor** 13.09. spät | `lab/`, `lab-v2/`, `lab-v4/`, `lab-v6/{brow,inkform,partrig,stache,texclean,zonenames}`, `v17/` (= v16-Baum re-homed) |
| Lokal `CLAUDE/KFB ToolBox.zip`, `…/WSA_2026-09-13/` | 13.09. | nur die 8 Exportdateien, kein Modulbaum |
| `KFB-Stunt-Car-Race`, `KFB-Combat-Arena` @ main | — | keine Treffer |

**Nirgends auffindbar (in der Sitzung 13.09. neu angelegt, laut HOUSEKEEPING des Exports):**
```
lab-v6/carl-contract.v1.js
lab-v6/facegraft.v1.js
lab-v6/carlrig-mount.v1.js
lab-v6/browgraft.v1.js
frizzlegraft-v1/anim-contract.v1.js
frizzlegraft-v1/actor-color.v1.js
frizzlegraft-v1/actor-wobble.v1.js
petstudio-v9/kfb-pet-graft-driver-default.json
petstudio-v9/kfb-pet-capsule-carl.json
```
Ältere Fassungen der übrigen Module existieren, ihre Byte-Gleichheit mit dem 13.09.-Stand ist nicht belegt. Deshalb kein handgemischter Modulbaum aus zwei Ständen.

## Kleinste Anforderung an den Authoring-Owner

Aus dem Claude-Design-Workspace „KFB Rigging Lab v1“ (Stand 13.09.2026 spät, der den WSA-Export erzeugt hat) die Ordner `lab/`, `lab-v2/`, `lab-v4/`, `lab-v6/`, `frizzlegraft-v1/`, `petstudio-v9/` und die drei `.dc.html`-Einstiege exportieren und unter `tools/KFB-ToolBox/site/` neben die Bundles legen (Ordnernamen exakt, Bundles unverändert). Alternativ: die drei Standalones aus demselben Workspace mit eingebetteten Modulquellen neu exportieren (wie `export/lab-standalone-src.dc.html` für Lab v1 dokumentiert).

## CORRECTION · 2026-09-14 (nach Review)

Die Formulierung „Werkzeuge werden nutzbar, sobald die Modulordner neben ihnen liegen“ ist zurückgenommen. Beim Rigging Lab lautet der Fehler `Failed to resolve module specifier './lab-v2/sources.js'` — ein Auflösungsfehler des rohen `import()` im DC-Skriptkontext (kein Base-URL), kein HTTP-404. Dateien danebenlegen behebt das nicht; die Import-Basis muss im exportierten Startweg an der bestehenden Quellnaht geprüft und ggf. korrigiert werden (Studio/Lab lösen über URL-Anker auf). „Nirgends auffindbar“ gilt für die hier durchsuchten Quellen (kayfabizarro@6ea5d439, KFB-Stunt-Car-Race@main, KFB-Combat-Arena@main, lokale Kopien CLAUDE/…), nicht für den laufenden Authoring-Workspace. Verbindlicher Auftrag an den Workspace: `_handover/TOOLBOX_V1_2026-09-14/review_intake_2026-09-14/TO_AUTHORING_WORKSPACE.md`.

## NACHTRAG · 2026-09-14 · Zweite Quelle gefunden (Donor-Paket `kfb-rigs-embed-v3`)

Anlass: Review-Eingang `_handover/TOOLBOX_V1_2026-09-14/review_intake_embed_v3_2026-09-14/`. Prüfart: GitHub-Connector-Tree `tools/KFB-ToolBox/` @ `f6e1a57d2580e2d35bd842c042d4673671a1b7c4` (66 Dateien), abgeglichen gegen die Listen oben. Maschinenlesbar: `docs/EMBED_V3_COVERAGE.json`.

**SOURCE FACT:** Unter `tools/KFB-ToolBox/kfb-rigs-embed-v3/` liegen 30 Quellmodule und 2 Contract-JSONs. Vier der neun oben als »nirgends auffindbar« geführten Dateien liegen damit an einer gepinnten Adresse: `lab-v6/carl-contract.v1.js`, `lab-v6/facegraft.v1.js`, `lab-v6/carlrig-mount.v1.js`, `frizzlegraft-v1/actor-wobble.v1.js`.

| Bundle | benötigt | namensgleich im Embed | fehlt weiter | erster Bootfehler abgedeckt? |
|---|---|---|---|---|
| Rigging Lab v1 | 15 | 10 | 5 | nein (`lab-v2/sources.js` fehlt) |
| Animation Lab v2 | 5 | 0 | 5 | nein (`lab/assets.js` fehlt) |
| FrankenStein Studio v17 (benannte Refs) | 17 | 8 | 9 | nein (`pet-session.v1.js` fehlt) |

Weiterhin nirgends auffindbar: `lab-v6/browgraft.v1.js`, `frizzlegraft-v1/anim-contract.v1.js`, `frizzlegraft-v1/actor-color.v1.js`, `petstudio-v9/kfb-pet-graft-driver-default.json`, `petstudio-v9/kfb-pet-capsule-carl.json`.

**Kein Bundle wird startfähig, und die Anforderung an den Authoring-Owner bleibt unverändert.** Zwei Gründe, kein dritter:
1. Bei jedem der drei Bundles fehlt genau die Datei, an der der beobachtete Kaltstart abbricht.
2. Die **Bytegleichheit dieser 10 Dateien mit dem 13.09.-Workspace-Stand ist nicht belegt** — das Paket ist ein später kuratierter Donor, kein Workspace-Export. Die Regel »kein handgemischter Modulbaum aus zwei Ständen« gilt für diese Quelle genauso wie für die lokale Vor-13.09.-Kopie.

Zusatzbefund in die andere Richtung, belegt über Git-Blob: `contracts/kfb-carl-rig-v6.json` und `contracts/kfb-pet-graft-driver.v4.json` sind byte-identisch zu `site/configs/kfb-carl-rig-v6(1).json` bzw. `site/configs/kfb-pet-graft-driver (4).json`.

## NACHTRAG 2 · 2026-09-15 · Stop-Grenze aufgehoben (WS0-Quellstand)

Anlass: Eingang `_inbox/WS0_2026-09-15/` (Archiv `KFB FrankenStein ToolBox (WS0).zip`, sha256
`948d1950…3c5b`). Prüfart: Archiv entpackt, sha256 je Datei, statische Referenzanalyse aller sieben
Einstiege, Kaltstart aller sieben Blätter im Browser über HTTP aus dem frisch entpackten Ordner.
Rohdaten: `_inbox/WS0_2026-09-15/qa-wsa/`. Beurteilung: `…/RETURN_WSA.md`.

**SOURCE FACT:** Der gelieferte Quellbaum `A_QUELLSTAND/src/` ist geschlossen — 87 Dateien,
7 `.dc.html`-Einstiege, **0 unauflösbare lokale Modulreferenzen**. Alle drei Dateien, an denen der
Kaltstart der Bundles abbrach (`petstudio-v9/studio-v7/pet-session.v1.js`, `lab-v2/sources.js`,
`lab/assets.js`), liegen vor, ebenso das Spendermodell `FrizzleBob_Yellow.gltf` (608 342 B).

Von den neun am 13.09. angelegten, im September nicht auffindbaren Dateien fehlt nur noch
`lab-v6/browgraft.v1.js` — **und die wird nicht mehr gebraucht**: kein Einstieg des Quellstands
referenziert sie, die Braue kommt aus `lab-v6/brow.v3.js` und `studio-v12/brow-rig.v2.js`.

**Damit ist die »Kleinste Anforderung an den Authoring-Owner« erfüllt** — anders als dort
formuliert: nicht als Modulordner neben den Bundles, sondern als eigener startfähiger Quellbaum mit
sieben Einstiegen (darunter Animation Lab **v3** statt v2 und vier zusätzliche Blätter).
Die Abschnitte oben bleiben als Befund vom 14.09. stehen; sie beschreiben die drei
Standalone-Bundles, und für **die** gilt der Befund unverändert: sie enthalten den Modulbaum nicht.

**Was das nicht heißt.** Kein Font-Pass (17 Dateien fehlen weiter, absichtlich), keine
Feldabdeckungstabelle, kein Rundlauf, keine Prüfgrößen, keine Suite-Freigabe. Startweg der ToolBox
ist ab jetzt der Quellbaum, nicht das Bundle; die Bundles bleiben unverändert liegen.

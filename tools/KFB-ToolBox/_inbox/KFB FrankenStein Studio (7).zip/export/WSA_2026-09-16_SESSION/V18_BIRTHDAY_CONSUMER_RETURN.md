# V18_BIRTHDAY_CONSUMER_RETURN

**Stand:** 2026-09-16 · Quelle `KFB FrankenStein Studio v18.dc.html`
**Status dieses Stands:** `CURRENT STUDIO WIP / SOURCE DONOR` — **nicht** ToolBox-SSOT.
Der zuvor geprüfte Birthday-Actor/Motion-Handoff bleibt gültig; dieses Dokument ersetzt keinen
Eigentümer und keinen Vertrag. Kanonische Dateien wurden **nicht** angefaßt (`pet-LIBRARY.json`
bleibt unberührt — alle Vertragswünsche stehen unten als `CANDIDATE CONTRACT DELTA`).

---

## 1 · Source identity

| Was | Wert |
|---|---|
| GothGirl-Figur | `media/3D_Assets/KayKit_Mystery_Series6/GothGirl/characters/GothGirl.glb` · 323 724 B · `blobSha b56f67e4ddb7db95ff54fef526148a49289f3915` |
| GothGirl-Bildtafel | `…/GothGirl/assets/gltf/gothgirl_texture.png` · 10 955 B · `blobSha a977d07571b967f0a7ead7f0603f297ec0a52bca` (im GLB eingebettet, 1024²) |
| Skelett | Skin `Rig_Medium` · 23 Knochen · Signatur `cbb89c54419f5e6745b4f2b43ca2f6533b6aa9ac8d764a310392a8d473f389e1` · **0 eigene Clips** |
| Hihi-Figur | `media/3D_Assets/GLB_cube-pets/animal-cat.glb` — **dieselbe Datei wie »The Cat«**, eigener Eintrag über `pet.modelId: 'cat'` |
| Hihi-Identität | `pet.id = 'hihi'` · `pet.name = 'Hihi'` · 8 eigene Clips (`static idle walk run eat dance gesture-positive gesture-negative`) |
| Bewegungen | `media/3D_Assets/KayKit_Character_Animations_1.1/Animations/gltf/Rig_Medium/Rig_Medium_<Kategorie>.glb` |
| Asset-Paket (Herkunft) | `tools/KFB-ToolBox/_inbox/KFB Elisa B-Day Reference+Mockups/kfb-asset-handoff-animation-lab (2).json` · `kfb.asset-handoff.v1` · `sourceCommit 891eadf01e218f5fc21387e64cea1fec8332c5b6` |
| Farbvorlage | `…/color sheet elisa b-day 01 Gemini_Generated_Image_uhyp7ouhyp7ouhyp.jpeg` (Figur »MAIA« = GothGirl, »GEO« = Cube-Cat) |
| Szenenvorlage | `…/mockup elisa b-day 01 - Gemini_Generated_Image_ccu5l5ccu5l5ccu5.jpeg` |
| Studio-Quelle | `KFB FrankenStein Studio v18.dc.html` (Fork von v17; v17 unberührt daneben) |
| Module (neu) | `frizzlegraft-v1/goth-biped.v1.js` · `lab-v6/browfit.v1.js` · `lab-v6/inkform.v2.js` |
| Paket | `export/WSA_2026-09-16_SESSION/` (91 Dateien Code + Doku, keine Binaries) |
| Profil-Export | **`profiles/kfb-pet-gothgirl.json`** · 27 936 B · SHA-256 `fcce89dd2e432f91aed9def4ea9db82b28bbf486a0eace7a3711a7ed9b081c48`<br>**`profiles/kfb-pet-hihi.json`** · 27 234 B · SHA-256 `1d406be1fd9836c6ad5e6a6f15f9430fafe399103ca5eefd5ac101dca52a574b` |

**Die Profile sind die Ausgabe des Export-Reiters, nicht aus diesem Bericht rekonstruiert.**
Verfahren: derselbe Builder, den der Knopf »This pet (1)« ruft (`_SES.buildExport({… label:'single'})`),
am laufenden Blatt ausgeführt, `kfb.pets/1`, Vertrag 1.3.0, Version 1.2.9, je **1** Pet
(`meta.ids`), Blattfelder **56** (GothGirl) bzw. **30** (Hihi). **Gegenprobe:** die SHA-256 der
gespeicherten Dateien wurde gegen die im Blatt gemessene Summe geprüft — ohne Treffer wäre nichts
gespeichert worden. Beide treffen. Der Sitzungs-Seiteneffekt des Knopfes (`petVersions` hochzählen,
Entwürfe verwerfen) wurde **nicht** ausgelöst: Georgs Sitzung bleibt unberührt.

### ZIP-Pin — was gilt

| Stand | Größe | Blob | Rolle |
|---|---|---|---|
| **`export/WSA_2026-09-16_SESSION/`** (dieses Paket, 98 Dateien) | — | — | **GELTENDER v18 Birthday-Handoff.** Enthält die beiden Profile, die Belegbilder und diesen Return. |
| `tools/KFB-ToolBox/_inbox/KFB FrankenStein Studio (6).zip` | **4 971 745 B** | `1a9bfbd52150926c373f062c6388261959f7ad2a` | Aktueller GitHub-Export = **SOURCE DONOR / WIP-Schnappschuss**. |
| `tools/KFB-ToolBox/_inbox/KFB FrankenStein Studio v18.zip` | **1 428 629 B** | `bf26e92f90804b87b01f6c6d6106f5430f9c4cec` | **ÄLTERER** Schnappschuss. Nicht der Handoff. |

**⚠ Was ich prüfen konnte und was nicht:** die Existenz und die **Bytegröße** beider ZIPs habe ich
am Repo gemessen (4 971 745 / 1 428 629 B, Blobs wie von WSA genannt). Den **Inhalt** konnte ich
nicht lesen (Binary, kein Importweg) — ich kann also **nicht** bescheinigen, welche Studio-Revision
in welchem ZIP liegt. Was sich daraus sicher sagen läßt: **keines der beiden ZIPs kann den
Finalisierungspass vom 16.09. enthalten** (Profile, Simulation-Pflicht, Zonen-Palette, 27/27-Messung
— alle nach dem Upload entstanden). Wer den abgenommenen Zustand braucht, nimmt das lokale Paket;
wer die Quelle braucht, nimmt `(6).zip` und weiß, daß er einen WIP-Schnappschuss hat.

⚠ **Hashes:** die `blobSha`-Werte stammen aus Georgs Asset-Paket (gegen `sourceCommit 891eadf0…`).
Geladen wird zur Laufzeit über `main`. Ein Hash der v18-Blätter selbst liegt **nicht** vor.

---

## 2 · Appearance state

### GothGirl

**Maßstab und Lage:** Rohhöhe 2,211 u; das Studio setzt sie auf Pet-Größe (Bühnenfaktor **×0,46**,
Protokoll »×0,46«) und auf y = 0 über die gemessene tiefste Stelle. Blickrichtung +z, aus den Zehen
gemessen (`facehost.v1`), Yaw 0°. **Kein** Bewegungsclip verschiebt sie (Root bleibt).

**Gesichtsrahmen (die Naht):** die »body«-Box hängt am Kopfknochen und hat das Maß der
**Gesichtsinsel** 0,903 × 0,789 × 0,850 — **nicht** der Kopfknochen-Box 1,187 × 1,292 × 1,091
(dort hängen die Haare). Halbe Höhe U = 0,3945. Wer diese Box anders setzt, verschiebt alle
Gesichtsteile.

**Original gegen Overlay** (`pet.orig`, Vorgabe):

| Teil | Zustand | Wie |
|---|---|---|
| Augen | **Overlay** (unser EyeRig) | Inseln 6+7 aus den Zeichengruppen (138 von 1618 Dreiecken) |
| Brauen | **Original** | Inseln 4+5 bleiben sichtbar |
| Nase | **Original** | Insel 3 bleibt sichtbar |
| Mund | **übermalt** + Overlay | Textur-Region übermalt: 53 Dreiecke, Ton `rgb(247,205,180)`, Median über 194 Stichpunkte der Gesichtsinsel |

**17 Zonen · gesetzter Stand** (`pet.zoneMap`; alles andere Original-Bildtafel):

| Zone | Insel | Dreiecke | Farbe |
|---|---|---|---|
| `head:0` Haare | 1 | 832 | **#130d15** violet-black |
| `head:1` Gesicht | 2 | 218 | **#e6cbc3** helle Haut |
| `head:2` Nase | 3 | 82 | **#e6cbc3** |
| `head:3/4` Brauen | 4+5 | 72 + 72 | Original |
| `head:5/6` Augen | 6+7 | 69 + 69 | ausgeblendet |
| `head:7/8` Ohren | 8+9 | 66 + 66 | **#e6cbc3** |
| `head:9/10/11` Ohrringe | 10–12 | 24 je | **#a3a2a0** Silber |
| `mesh:GothGirl_Body` | — | 990 | Original (trägt Oberteil + Rock + Socken in EINER Tafel) |
| `mesh:GothGirl_ArmLeft` / `ArmRight` | — | 600 / 468 | Original (trägt das Nietenarmband) |
| `mesh:GothGirl_LegLeft` / `LegRight` | — | 1326 je | Original (Socken + Stiefel) |

Die Farbwerte sind **am Farbblatt gemessen** (Median über ein 9×9-Fenster), nicht abgelesen: die
RGB-Angaben auf dem Blatt sind Bildtext eines Generators (»RGB 1311, 137«) und unbrauchbar.
Weitere gemessene Werte des Blattes, **nicht** angewandt: Oberteil `#a294a6` (lavender-gray),
Rock `#381c31`, Haut-Alternative `#c79f8f`.

**Augen-Rig** (`pet.eye`): `anchor {dx 0.49, dy −0.01, ring 0.32, track 0.06}` — dx/dy **gemessen**
an ihren eigenen Augen (x ±0,195 / y 1,606 gegen Gesichtsmitte y 1,610, U 0,3945); `ring 0.32` ist
eine Wahl (KFB-Augäpfel größer als die gemalten). `pupilSize 0.34 · lidFit 0.90 · inset 0 ·
gloss 0.90 · lashes {length 0.55, density 8, width 1.1}`. `pet.color = '#e6cbc3'` ist die
**Lidfarbe** (mit gesetzter Farbe nimmt das Rig sie statt der Bildtafel).

**Mund** (`pet.mouth`): `set 'female' · size 0.58 · dy −0.40 · sx 1.15 · lift 0.04 · wrap 1 · rate 1`.

**Gezeichnete Braue / Nase:** `brow {mod 'drawn', enabled false}` · `nose {enabled false}` — sie hat
beides selbst.

### Hihi

| Feld | Wert |
|---|---|
| `pet.flatSkin` | **true** → Kenney-Stand für dieses Pet: `MeshStandardMaterial` + Original-Colormap, **kein** Prozedur-Shader (am Material nachgemessen) |
| `pet.modelId` | `cat` |
| Augen | Overlay (EyeRig), `anchor {dx 0.345, dy −0.10, ring 0.34, track 0.10}`, `pupilSize 0.38`, `lashes {0.50, 8, 1}`; die gemalten Augentafeln des GLB werden wie bei allen Cube-Pets gestrippt |
| Mund | `set 'red' · size 0.50 · dy −0.62` — Lage am Bild gesucht: bei −0,36 lag die Lippe **hinter** der Nasenknolle |
| Nase | gezeichnete KFB-Knolle (rot), Original-Naseninsel des GLB bleibt darunter |
| Sichtbares Ergebnis | graues Kenney-Fell mit gemaltem Muster, rote Lippen, Wimpern, Balkenbrauen, große Augäpfel — Belegbild `evidence/evid-hihi.png` |
| Farbblatt »GEO« gemessen, **nicht** angewandt | Fell `#a9bbc2` · Sapphire `#124576` · Paw-Coral `#c86c6d` · Emerald `#d1f9e8` |

---

## 3 · Consumer contract delta

Format: `field/capability → v18-Verhalten → ToolBox-Status → nötige Nachziehung`

1. `pet.modelId` → welches Modell ein Eintrag lädt; ohne das Feld baut die ID die URL
   (`animal-{id}.glb`) → **nicht im Vertrag** → `CANDIDATE CONTRACT DELTA`: optionales Feld,
   Fallback = `id`. **Ohne dieses Feld ist Hihi nicht ladbar** (404 auf `animal-hihi.glb`).
2. `pet.flatSkin` → Kenney-Material für EIN Pet (Colormap ohne Prozedur-Shader) → nicht im Vertrag
   → `CANDIDATE CONTRACT DELTA`: optionaler Boolean, Vorgabe false = heutiges Verhalten.
3. `pet.orig {eyes, brows, nose, mouth}` → je Gesichtsteil Original oder Overlay; nur wirksam, wo
   ein Original existiert → nicht im Vertrag → `CANDIDATE CONTRACT DELTA`: optionales Objekt,
   fehlende Schlüssel = Modulvorgabe.
4. `pet.zoneMap {'<zoneId>': '#rrggbb'}` → Zonenfarben (Insel oder Netz); `null`/fehlend = Original
   → nicht im Vertrag (Carl hat `zones[]` mit `{island, hidden, color}`, eine ANDERE Form) →
   `CANDIDATE CONTRACT DELTA`: **eine** Form für beide wäre besser; v18 schlägt die Karte vor, weil
   Zonen-IDs hier auch Netze benennen (`mesh:GothGirl_Body`).
5. `brow.thickness` Spanne **0…10** (war 0…3) → gleiche Bedeutung, größerer Anschlag → ToolBox
   validiert ggf. noch 0…3 → `CANDIDATE CONTRACT DELTA`: Obergrenze anheben, sonst werden gültige
   Dateien abgewiesen.
6. `brow.facets` (Vorgabe 12) → Facetten des Schlauchs → neu → `CANDIDATE CONTRACT DELTA`, optional.
7. `brow.graft.thickness` → Balkenhöhe der gegrafteten Braue **in Augenradien** (Vorgabe 1 ≈ Carls
   gemessene 1,009) → ToolBox kennt nur den alten Einheitsmaßstab → `CANDIDATE CONTRACT DELTA`:
   Einheit dokumentieren, sie trägt über Figuren hinweg.
8. `brow.graft.depthScale` → Tiefe getrennt von der Höhe → neu → `CANDIDATE CONTRACT DELTA`, optional.
9. **`eye.anchor` verschachtelt** → `_buildEyeRig` liest `anchor: eye.anchor`; flache Felder
   (Carls Form, die `mountCarl` selbst ausliest) kommen bei einem Zweibeiner **nicht** an →
   zwei Schreibweisen im Umlauf → `CANDIDATE CONTRACT DELTA`: eine Form festschreiben, die andere
   beim Lesen übersetzen. **Das ist die gefährlichste Stelle** — sie fällt still aus.
10. **Zeichengruppen brauchen ein Material-FELD** → wer Inseln über Gruppen ausblendet und ein
    EINZELNES Material setzt, zeichnet alles (»hidden« meldet OK, nichts verschwindet) → Fähigkeit,
    kein Feld → `TOOLBOX FOLLOW-UP`: als Regel in die Embed-Anleitung.
11. **GothGirl-Zonen sind Inseln, keine Atlas-Felder** → `matzones.v1` (Driver) rechnet mit einem
    8×4-Farbfeld-Atlas; ihr Netz hat keine Felder, sondern 12 Inseln → `TOOLBOX FOLLOW-UP`:
    beide Zonenarten benennen, damit ein Consumer weiß, welche er bekommt.

---

## 4 · Motion compatibility re-check

**Gemessen am fertigen v18-Actor** (GothGirl, nach Zonen und Gesichtsbau), Kette gespielt und
getickt (`mixer.update`, 0,033 s Schritte):

| Schritt | Clip | Quelle | Dauer | Spuren | gebunden |
|---|---|---|---|---|---|
| 1 | `Idle_A` | `Rig_Medium_General` | 1,07 s | 27 | **27** |
| 2 | `Waving` | `Rig_Medium_Simulation` | 2,13 s | 27 | **27** |
| 3 | `Idle_A` | General | 1,07 s | 27 | **27** |
| 4 | `Cheering` | `Rig_Medium_Simulation` | 1,67 s | 27 | **27** |
| 5 | `Idle_A` | General | 1,07 s | 27 | **27** |

- **Mixer-Wurzel:** `figure` · **Mixer insgesamt: 1** · **doppelter Eigentümer: nein**
  (das Studio hält keinen zweiten Mixer, der alte Bewohner entsorgt sich vor jedem Bau).
- **Sichtbare Regression: nein.** Beleg: `evidence/evid-waving.png` (Arm oben, Körper trägt mit),
  `evidence/evid-cheering.png`.
- **Kategorien:** `General` und `MovementBasic` lädt das Modul selbst; **`Waving` und `Cheering`
  liegen in `Simulation`** — diese Kategorie muß der Consumer zusätzlich laden
  (`loadCategory('Simulation')`), sonst findet er die Clips nicht. Gemessen: 15 + 11 Clips ohne,
  55 mit `Simulation` und `Special`.
- Kein neues Bewegungssystem, keine neuen Quellen: dieselben Rig_Medium-Pakete wie bisher.

### 27/27 gegen 69/69 — der Nenner hat sich geändert, nicht die Bindung

```
OLDER TESTED RESULT: 69/69 under previous probe scope
V18 TESTED RESULT:   27/27 under current v18 scope
REGRESSION:          NO
```

**EXPLANATION.** Gemessen an den drei Clips selbst (Spurnamen ausgezählt, alle drei identisch
aufgebaut):

| Clip | Spuren | davon `quaternion` | `position` | `scale` | berührte Knochen |
|---|---|---|---|---|---|
| `Idle_A` | 27 | 23 | 2 | 2 | **23** |
| `Waving` | 27 | 23 | 2 | 2 | **23** |
| `Cheering` | 27 | 23 | 2 | 2 | **23** |

Das Skelett hat **23 Knochen**. 23 × 3 Kanäle (Position, Rotation, Skalierung) = **69** — das ist
die Zahl der **möglichen** Knochen-Kanal-Paare, und sie ist der Nenner, auf den ein Prüfstand
kommt, der die Retarget-Fähigkeit zählt (»treffen alle Kanäle des Rigs ein Ziel?«). Die
Rig_Medium-Clips **führen diese 69 Kanäle nicht**: sie drehen alle 23 Knochen und verschieben bzw.
skalieren nur zwei (`hips`, `root`) — macht 27 vorhandene Spuren.

**Was der v18-Binding-Scope umfaßt:** `action._propertyBindings` der gerade gespielten Action, also
die Spuren, die three.js für **diesen Clip** auf **diese Figur** gebunden hat. Nenner = Spuren, die
der Clip wirklich enthält.

**Bedeutet 27/27 vollständige Bindung?** Ja: jede im Clip vorhandene Spur ist gebunden, keine
verwaiste, keine ungebundene. Zusätzlich meldet der geerbte Kategorie-Bericht **23/23 Zielknoten
(100 %)** — dieselbe Aussage aus der anderen Richtung, auf der Knochenebene.

**Regression gegen das frühere Consumer-Verhalten:** keine. Angetrieben werden dieselben 23
Knochen; die fehlenden 42 Kanäle sind Spuren, die **in den Clips nicht existieren** (und auch
früher nicht existierten). Sichtbar belegt in `evidence/evid-waving.png` und
`evidence/evid-cheering.png`.

**Der alte Beleg bleibt gültig und wird nicht überschrieben** — die beiden Zahlen messen
verschiedene Dinge: 69 = Kanäle des RIGS, 27 = Spuren des CLIPS.

### Harte Consumer-Abhängigkeit: `Simulation`

```
requiredAnimationCategories = [General, MovementBasic, Simulation]
```

Der Feldname ist **implementation-owned** (kanonisch gibt es ihn noch nicht) und liegt als
`REQUIRED_ANIMATION_CATEGORIES` in `frizzlegraft-v1/goth-biped.v1.js`; der Bericht der Figur
führt ihn mit (`report().goth.requiredAnimationCategories`, `loadedCategories`, `chainReady`).

**Nicht nur dokumentiert, sondern geschlossen:** das Modul lädt die Kategorie beim Aufbau mit und
prüft danach, ob die Kette vollständig ist. Gemessen nach dem Bau: `loadedCategories =
[General, MovementBasic, Simulation]`, **`chainReady: true`**. Ist `Simulation` nicht erreichbar,
steht es als »⚠ Kategorie nicht erreichbar — Waving/Cheering fehlen« im Protokoll und
`chainReady` ist `false`. Damit kann ein Consumer nicht mehr erfolgreich initialisieren und die
beiden Clips stillschweigend vermissen.

---

## 5 · Evidence

| Datei | Was sie zeigt |
|---|---|
| `evidence/evid-front.png` | GothGirl im Dreiviertel — **Zonen-Differenzierung**: Haar violet-black, Gesicht/Ohren helle Haut, Ohrringe silber, Kostüm weiter auf der Original-Bildtafel |
| `evidence/evid-face.png` | Gesicht nah: Augäpfel + Wimpern (Overlay), ihre eigenen Brauen und Nase (Original), übermalter Mund mit unserem Female-Mund darüber |
| `evidence/evid-waving.png` | Motion-Beleg `Waving` |
| `evidence/evid-cheering.png` | Motion-Beleg `Cheering` |
| `evidence/evid-hihi.png` | Hihi mit `flatSkin` — Kenney-Fell statt Bühnen-Marmorierung |

⚠ **Aufnahmeweg, damit die Bilder nachprüfbar sind:** im Vorschaufenster ist `document.hidden`
**true**, die Bildschleife parkt — ohne eigenes `renderer.render` UND eigenes `rig.update(dt)`
zeigt jedes Standbild geschlossene Augen und einen alten Puffer. Die Bilder hier sind selbst
gerendert, getickt und aus einem 2D-Canvas aufgenommen.

**Meßbeleg der Farben — Quelle und Position.** Quelle:
`tools/KFB-ToolBox/_inbox/KFB Elisa B-Day Reference+Mockups/color sheet elisa b-day 01 Gemini_Generated_Image_uhyp7ouhyp7ouhyp.jpeg`,
**1824 × 2298** px. Verfahren: Median über ein **9 × 9**-Fenster um den genannten Punkt
(Normalkoordinaten × Bildgröße, also x·1824 / y·2298):

| Wert | Position (normiert) | Pixel (ca.) | Ergebnis |
|---|---|---|---|
| Haut (Figur MAIA, Arm) | 0,629 / 0,354 | 1147 / 814 | **#e6cbc3** |
| Haar (Figur MAIA) | 0,465 / 0,227 | 848 / 522 | **#130d15** |
| Silber (Palette 4) | 0,612 / 0,505 | 1116 / 1161 | **#a3a2a0** |
| Oberteil (nicht angewandt) | 0,512 / 0,309 | 934 / 710 | #a294a6 |
| Rock (nicht angewandt) | 0,529 / 0,364 | 965 / 837 | #381c31 |
| Cube-Cat-Fell (GEO, Palette 1) | 0,730 / 0,505 | 1332 / 1161 | #a9bbc2 |
| Paw-Coral (GEO, Palette 3) | 0,878 / 0,505 | 1602 / 1161 | #c86c6d |

**Die Generator-Beschriftung des Blattes ist keine Quelle** (»RGB 1311, 137«, »RDB, 5L25«).
Die beiden Referenzbilder liegen **nicht** im Projekt (Hausregel: keine Binärhalden) — sie stehen
im Repo unter dem oben genannten Pfad.

---

## 6 · Known open issues

### BLOCKS BIRTHDAY CONSUMER
**Leer.** Die beiden Punkte, die hier standen, sind erledigt:
- ~~Kein Profil-Export abgelegt~~ → `profiles/kfb-pet-gothgirl.json` + `profiles/kfb-pet-hihi.json`
  liegen im Paket, byte-gleich zur Ausgabe des Export-Reiters (SHA-256 geprüft, §1).
- ~~`Simulation` muß geladen werden~~ → als Pflicht im Modul verankert und nach dem Bau geprüft
  (`chainReady`, §4).

**Ein Befund am Rande, der den Export vorher verhindert hätte** (behoben, in v18 drin): der
Einzel-Export filterte »eigene Bauten« über `kind === 'biped' || module`. Hihi trägt keins von
beiden (sie ist ein Cube-Pet und neu, also auch nicht im Vertrag) — der Export lieferte
`kfb-pets.json` mit **null** Pets statt `kfb-pet-hihi.json`. Jetzt zählt `modelId` als drittes
Kennzeichen. **Ein neues Cube-Pet ohne Vertragseintrag war bis heute nicht exportierbar.**

### TOOLBOX FOLLOW-UP
- Die elf Punkte aus §3, insbesondere `modelId` (ohne das Feld ist Hihi nicht ladbar **und nicht
  exportierbar**) und die **zwei Schreibweisen von `eye.anchor`** (stiller Ausfall).
- **12. `requiredAnimationCategories`** (§4) → v18 hält die Liste im Modul und prüft sie →
  kanonisch nicht vorhanden → `CANDIDATE CONTRACT DELTA`: Feldname und Ort gehören der künftigen
  ToolBox; der Zustand »initialisiert, aber Clips fehlen« darf nicht mehr eintreten können.
- `pet-LIBRARY.json` fehlt weiter (HTTP 404). Folge im Studio: keine Emotes, kein Gesichts-Block.
  **Blockiert den Birthday-Consumer nicht** — die Appearance-Felder liegen am Pet, nicht in der
  Bibliothek —, bleibt aber ToolBox-Aufgabe.

### LATER / NON-BLOCKING
- **Wimpern sind hautfarben, nicht schwarz.** Sie kommen als 0,5 × Lidfarbe; `EyeRig v6` hat keinen
  eigenen Griff (`eye.colors.lash` wird abgewiesen).
- **Die Bühnenbeleuchtung wäscht die Haut aus.** Gesetzt ist `#e6cbc3`; unter RoomEnvironment mit
  `envMapIntensity 0.75` liest sie grauer als auf dem Farbblatt. Der Wert steht, das Licht gehört
  dem Consumer.
- **Kostümfarben nicht angewandt** (Oberteil `#a294a6`, Rock `#381c31`): ihre Netze tragen mehreres
  in einer Bildtafel; flach gefärbt wäre das Kostüm weg. Der Wähler kann es, die Vorgabe tut es nicht.
- **Hihi: Emerald-Augen und Coral-Paw-Pads aus dem Blatt** sind nicht angewandt. `pet.eye.pupil`
  trägt bei den Cube-Pets ein OBJEKT (`{form:'googly'}`), der Farbgriff erwartet eine Farbe —
  vor einer Änderung zu messen.
- **Requisiten und Bühne** (Mikro, Ständer, Hocker, Boxen, Ballons, Banner) sind Kandidaten im
  Asset-Paket, **nicht gebaut** — bewußt, laut Auftrag.
- **Zonenfarben für andere KayKit-Rigs**: derselbe Weg, gebaut für GothGirl.

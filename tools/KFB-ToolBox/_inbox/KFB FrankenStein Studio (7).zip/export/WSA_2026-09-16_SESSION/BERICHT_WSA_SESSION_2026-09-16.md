# Bericht an den WSA Lead · Session 15./16.09.2026 · KFB FrankenStein Studio v18

**Zweck dieses Berichts:** Wiederaufnahme (Recovery) und Abgleich mit der neuen KFB ToolBox.
Er ist **additiv** geschrieben — jede Zeile nennt, was dazugekommen ist, und trägt ihren Beleg.
Was nicht gemessen wurde, steht als Vermutung da. Was nicht gebaut wurde, steht unter »Nicht gebaut«.

**Stand:** `KFB FrankenStein Studio v18.dc.html` (Fork von v17; v17 liegt unberührt daneben).
**Auftrag (Georg, 15./16.09.):** Elisa-B-Day-Setup — Asset-Pack einlesen · Fork v17 → v18 ·
Balken-Brauen reparieren (globale Funktion, Tapering, Skalierung, Monobrauen-Maske) · GothGirl als
KFB-Rig mit entfernten Original-Augen und -Mund, unser Head-Rig, KayKit-Farben, Wimpern, Female
Mouth · Kitten »Hihi« als eigenes Cube-Pet mit roten Lippen, Augäpfeln, Wimpern.
**Nachtrag 16.09.:** Hihi-Textur · Original-gegen-Overlay für ALLE KayKit-Rigs · Mund-Platzierung ·
Color-Picker für GothGirls Materialzonen · dieser Bericht · Code-Export.

---

## 1 · Additives Changelog

### Neue Dateien (4)

| Datei | Was sie ist | Erbt von |
|---|---|---|
| `lab-v6/browfit.v1.js` | **Eine** Stellformel für alle Brauen-Arten + beide Klassen (gezeichnet, gegraftet) | `studio-v12/brow-rig.v2.js` · `lab-v6/facegraft.v1.js` |
| `lab-v6/inkform.v2.js` | Schlauch mit echten Deckeln (Kuppel außen, Schnitt an der Maske), 12 Facetten | Ablöser von `inkform.v1.js` (bleibt als Rückweg) |
| `frizzlegraft-v1/goth-biped.v1.js` | GothGirl als Bewohnerin — **eigener Kopf**, Inseln als Zeichengruppen, Zonenfarben | `frizzlegraft-v1/graft-biped.v1.js` |
| `BERICHT_WSA_SESSION_2026-09-16.md` | dieser Bericht | — |

**Kein Vendor-Modul wurde angefaßt.** `brow-rig.v2.js`, `facegraft.v1.js`, `inkform.v1.js`,
`pet-eye-rig.v6.js`, `pet-mouth.v1.js`, `carlrig.js` sind bytegleich zum Stand vor der Session.
Alles Neue erbt und ersetzt genau eine Methode — dasselbe Muster wie `brow.v3` im September.

### Geänderte Dateien (4)

- **`KFB FrankenStein Studio v18.dc.html`** (Fork von v17, +8 KB): Brauen-Modul getauscht ·
  Blockbraue auf die neue Stellformel · Dicke-Regler 0…10 · Enden-Regler neu bedeutet ·
  zwei neue Bewohner · Feld `modelId` im Ladeaufruf · Feld `flatSkin` in `reskin()` ·
  Mund-Regler feiner + `dx`/`roll` · zwei neue Abschnitte (`_origPartRows`, `_gothZoneRows`) ·
  zwei neue Handler (`origPart`, `gothZone`) · Anwenden von `pet.orig`/`pet.zoneMap` beim Bau.
- **`LIVING_frizzlegraft.md`**: ein Eintrag oben, additiv (neueste Zeile oben, Hausregel).
- **`github.md`**: `## Last sync` neu, alter Stand in `## Sync history`, Screen map um drei Zeilen.
- **`CLAUDE.md`**: Blätterzeile auf v18.

### Neue Felder am Vertrag (`kfb.pets/1`, alle optional, alle rückwärtskompatibel)

| Feld | Bedeutung | Ohne das Feld |
|---|---|---|
| `pet.modelId` | welches Modell ein Eintrag lädt (Hihi lädt `animal-cat.glb`) | wie bisher: die ID baut die URL |
| `pet.flatSkin` | Kenney-Stand für **dieses** Pet (Colormap ohne Clay-Shader) | wie bisher: Bühnen-Look |
| `pet.orig` | je Gesichtsteil Original oder Overlay (`eyes`/`brows`/`nose`/`mouth`) | Modulvorgabe |
| `pet.zoneMap` | Zonenfarben je Insel (`head:0` … `mesh:GothGirl_Body`) | Original-Bildtafel |
| `brow.thickness` | Spanne **0…10** statt 0…3 (die Zahl bedeutet dasselbe) | unverändert |
| `brow.facets` | Facetten des Schlauchs (Vorgabe 12) | 12 |
| `brow.graft.thickness` | Balkenhöhe der GEGRAFTETEN Braue **in Augenradien** (Vorgabe 1) | 1 = Carls Maß |
| `brow.graft.depthScale` | Tiefe getrennt von der Höhe | 1 = wie hoch |

---

## 2 · Findings — mit Beleg, nicht mit Zusicherung

### F1 · Drei Kopplungen steckten im Brauen-Regler (gemessen, Kurve »neutral«, Seed 1001, Carls Anker)

| Was | alt | neu |
|---|---|---|
| Dicke über den Längenregler (0,2 → 1) | 0,0117 → 0,0204 (**+74 %**) | 0,01561 → 0,01565 (±0,3 %) |
| Dicke über den Auslaufregler (0 → 1) | 0,01853 → 0,01516 (**−18 %**) | 0,01564 konstant |
| Balken: Rand gegen Mitte | 0,00738 / 0,01566 (**−53 %**) | 0,01564 / 0,01564 |
| Maske 0,7, Dicke in der Mitte | 0,01439 | 0,01565 |
| Reichweite des Dicke-Reglers | bis **0,36** Augenradien | bis **1,21** |

**Bei den Vorgaben ist die neue Braue die alte** (0,01564 gegen 0,01566 = 0,1 %) — kein
gespeichertes Pet ändert sein Aussehen. Die Ursachen: die halbe Dicke hing an `width` (das den
Längenregler enthält, Bezug ist jetzt `span`) · im Balken-Stand war der Radius der Mittelwert der
Federkurve, und die Feder hängt am Auslauf (Verhältnis Mittelwert/`hb·512` gemessen: taper 0 →
0,464 · 0,5 → 0,422 · **0,85 → 0,392** · 1 → 0,380; `EVEN_K = 0,392` ist die Vorgabe) · `cap` war
keine Länge, sondern eine Abtastzahl.

### F2 · Der gezeichnete Regler konnte die Blockbraue nie erreichen

Carls EIGENE Blockbraue ist **1,01 Augenradien** hoch (Insel 0,166 × Maßstab 0,790). Der
gezeichnete Regler endete am alten Anschlag 3 bei **0,36** — beim Drittel. Georgs Satz »Größe ist
schlecht den Augen anzupassen« war ein **Anschlag**, kein Geschmack. Die Oberfläche nennt jetzt die
Balkenhöhe in Augenradien (`frame.barR`).

### F3 · Die Blockbraue skalierte wirklich als Block

`facegraft.v1` setzt `s = width / donor.pairWidth` und dann `setScalar(s)` — EIN Maßstab für Länge,
Dicke UND Tiefe, abgeleitet aus der **Paarbreite** (Carl: 0,744 für eine 0,300 breite Braue).
Länger machen machte dicker; dicker machen schob auseinander (die Spreizung hing am selben `s`).
Jetzt zwei Maßstäbe; `thickness 1` reproduziert Carls Größe auf 1 % (1,009 Augenradien).

### F4 · GothGirls Mund ist AUFGEMALT, nicht modelliert

Gemessen: Kopfnetz 1618 Dreiecke = **12 Inseln** (1 Haare 832 · 2 Gesicht 218 · 3 Nase · 4/5 Brauen
· 6/7 Augen · 8/9 Ohren · 10–12 Ohrringe), zugeordnet über die **Lage**, mit der Messung als
Prüfwert. Die dunkelsten Texel der Gesichtsinsel sitzen bei (0,03 · 1,42 · 0,44). Ein Netzschnitt
kann den Mund nicht entfernen — er wird übermalt (`texclean.paintOverRegion`, 53 Dreiecke).

### F5 · Vier Fallen am Modell, alle bezahlt

1. **Sechs Netze, EIN Material.** Wer die Bildtafel am Kopf ersetzt, ersetzt sie an Armen, Beinen
   und Körper mit → eigene Materialkopie für den Kopf.
2. **Der Füllton war Haarschwarz.** `paintOverRegion` nimmt ohne Angabe den Median über das ganze
   Netz — mehr als die Hälfte ist Haar (832 von 1618). Erster Aufbau: `rgb(32,42,45)`. Median über
   die **Gesichtsinsel**, Mundregion ausgenommen: `rgb(247,205,180)` aus 194 Stichpunkten.
3. **Die Kopfbox des Kopfknochens ist die Box der HAARE** (1,187 × 1,292 × 1,091 gegen
   0,903 × 0,789 × 0,850). Das Augen-Rig rechnet in halben Boxhöhen → Augen ein Drittel zu groß.
   Umgestellt auf die Gesichtsinsel: **die Box des TEILS, nicht die des Ganzen.**
4. **`eye.anchor` wird VERSCHACHTELT gelesen.** Flache Felder (wie in Carls Eintrag, den
   `mountCarl` selbst ausliest) kommen bei einem Zweibeiner nicht an — das Rig stand auf den
   Modulvorgaben. Ihre Werte sind gemessen: Augen bei x ±0,195 / y 1,606, U = 0,3945 →
   **dx 0,49 · dy −0,01**.

### F6 · Der Cube-Pet-Ladeweg baut die URL aus der ID

`SETS.animals.urlPattern = 'animal-{id}.glb'` — ein Feld `glb` am Eintrag liest niemand.
Erster Aufbau von Hihi: **404 auf `animal-hihi.glb`**. Neues Feld `modelId`, EINE Zeile im
Ladeaufruf. Ohne das Feld bleibt alles wie vorher.

### F7 · `plain` reicht nicht gegen die Clay-Marmorierung

Georgs Befund »hihi texture fixen« (Bild): die Katze trug die Marmorierung der Bühnenoberfläche über
ihrem gemalten Fell. Erster Versuch `makeMat({plain:true})` — **wirkungslos**, `plain` nimmt dem
Oberflächen-Shader nur einen Teil. Was trägt: der Kenney-Stand des Blattes für EIN Pet
(Standardmaterial, Colormap unverändert, kein Prozedur-Shader). Nachgemessen am Material:
`MeshStandardMaterial+map`, und am Bild ist das Fell wieder Fell.

### F8 · Zwei Wege zu einem Index sind einer zu viel

Erste Fassung blendete Inseln aus, indem sie die Dreiecke AUS dem Index schrieb. Für sich richtig —
aber sobald Zonenfarben dazukommen, braucht dasselbe Netz **Zeichengruppen**, und zwei Besitzer
eines Index vertragen sich nicht. Jetzt ein Weg für beides: inselweise sortierter Index + Gruppen +
Material-Feld. **Nebenbefund:** Gruppen gelten NUR bei einem Material-FELD; ein einzelnes Material
übergeht sie — »ausgeblendet« meldete OK und nichts verschwand.

### F9 · Die Meßregel, zweimal bezahlt

**Geschlossene Augen bei ALLEN Figuren — und der Bau war in Ordnung.** `document.hidden` ist im
Vorschaufenster **true**, die Bildschleife parkt, also läuft `rig.update(dt)` nie, also bleiben
beide Lidschalen auf Drehung 0 = zu. Nach 30 eigenen Ticks: −1,14 / +1,23, Auge offen. Gegenbeweis
war der Driver-Graft mit demselben geschlossenen Blick. **Vor jedem Standbild selbst rendern UND
selbst ticken.** Dazu: `snapshot_element` liest den WebGL-Puffer und lieferte dreimal ein ALTES
Bild — was trägt: selbst rendern, in ein 2D-Canvas kopieren, DAS aufnehmen.

### F10 · Ein Entwurf gewinnt über das Blatt — und jeder Probeaufbau legt einen an

`loadPet` schreibt einen Entwurf in `kfb-pet-studio-v5`. Nach der ersten Bereinigung kamen durch
weitere Proben **`drafts.gothgirl` UND `drafts.hihi`** zurück, `activeId` stand auf `hihi` — das
Studio hätte auf einer Testfigur geöffnet. Die Folge ist nicht kosmetisch: der Entwurf trug die
verworfenen Mundwerte, also lag Hihis rote Lippe wieder hinter der Nasenknolle, obwohl die Datei es
richtig stehen hatte. **Regel:** wer über einen Bedien-Handler mißt, räumt am ENDE und prüft nach.
Endstand dieser Session: Entwürfe nur noch Georgs drei (`graft-orc` · `graft-clown` ·
`capsule-carl`), `activeId` = `graft-driver`, 11 195 Byte.
**Ehrlich dazugesagt:** 251 Byte weniger als vor den Proben (11 446), die ich nicht zuordnen kann.

### F11 · Eine dritte Falle beim Messen am laufenden Blatt

Ein `show_to_user` auf ein **bereits offenes** Blatt liefert die ALTE Fassung; zwei Messungen liefen
gegen eine Seite ohne meine letzte Änderung, und die Roster-Zahlen waren dadurch scheinbar falsch.
Was trägt: `location.reload()` mit Cache-Bust, oder eine Änderung über den DC-Weg (der lädt die
Logik-Klasse heiß nach).

---

## 3 · Abgleich mit der neuen KFB ToolBox

**Was aus der ToolBox kam und benutzt wurde:**
- **Asset-Paket** `_inbox/KFB Elisa B-Day Reference+Mockups/kfb-asset-handoff-animation-lab (2).json`
  (`kfb.asset-handoff.v1`, 129 576 B, `sourceCommit 891eadf0…`). Es trägt `selectionStatus:
  candidate-only` und die Eigentumsgrenze »The Asset Librarian may recommend candidates but does
  not declare animation compatibility« — die Eignung hat also **der Consumer** geprüft, und genau
  das ist hier passiert: GothGirls Skelett-Signatur `cbb89c54…` / Skin `Rig_Medium` gegen die
  Rig_Medium-Pakete, gemessen **23 von 23 Zielknochen (100 %)**, Ruhehaltung `Idle_A`.
- **Requisiten-Kandidaten** aus demselben Paket: `GothGirl_Microphone` · `_MicStand` · `_Stool`
  (0,6 × 0,8 × 0,6, geladen und gemessen) · `_Speaker`, alle `dependencyStatus: complete`.

**Was die ToolBox nachziehen sollte:**
1. **Das Consumer-Feld `modelId`** (F6) gehört in den Vertrag `kfb.pets/1`: ein Eintrag, der ein
   fremdes Modell lädt, ist kein Sonderfall mehr (Hihi ist der erste, weitere Varianten folgen).
2. **`pet.orig` und `pet.zoneMap`** (Original gegen Overlay, Zonenfarben) sind neue Blattfelder.
   Rundlauf im Studio-Export ist gegeben; die ToolBox-Doku kennt sie noch nicht.
3. **`brow.thickness` reicht bis 10** — wer die alte Grenze 3 validiert, weist gültige Dateien ab.
4. **`brow.graft.thickness` ist in AUGENRADIEN** (nicht in Modelleinheiten). Das ist die Einheit,
   die über Figuren hinweg trägt; die ToolBox sollte sie so dokumentieren.
5. **`pet-LIBRARY.json` fehlt weiter** (HTTP 404). Folge im Blatt: keine Emotes, kein
   Gesichts-Block; der Streifen sagt es, der Ausfall ist nicht mehr stumm, aber nicht behoben.
   **Das ist die einzige offene Lücke, die die ToolBox lösen muß, nicht das Studio.**

**Was NICHT abgeglichen wurde** (keine Messung, also keine Behauptung): ob `kfb-rigs-embed-v3`
(bzw. v3.1) die neuen Module braucht. Die drei neuen Dateien sind Authoring-Module; ein
Consumer-Paket ist diese Session nicht angefaßt worden.

---

## 4 · Stand der Abnahme

| Auftrag | Stand | Beleg |
|---|---|---|
| Asset-Pack einlesen | ✔ | gelesen, nichts kopiert; Pin in `github.md` |
| Fork v17 → v18 | ✔ | v17 unberührt daneben |
| Brauen: globale Funktion, Tapering, Skalierung | ✔ | Tabelle F1, fünf Messungen |
| Monobrauen-Maske / Schnittkanten | ✔ | `runs 2`, Deckel als Form, 12 Facetten |
| GothGirl: Augen + Mund raus, unser Head-Rig | ✔ | Inseln 6+7 aus den Gruppen, Mund übermalt |
| GothGirl: KayKit-Farben, Wimpern, Female Mouth | ✔ | Anstrich auf »off« genagelt, `set: female` |
| Hihi als eigenes Cube-Pet | ✔ | eigener Eintrag, `modelId: cat` |
| Hihi Textur | ✔ | `MeshStandardMaterial+map`, F7 |
| Original gegen Overlay je Gesichtsteil | ✔ (dort, wo es Original-Teile GIBT) | 4 Umschalter, 6 Zeilen |
| Mund-Platzierung | ✔ (feiner + zwei Achsen mehr) | Schritt 0,002–0,005, `dx`/`roll` neu |
| Color-Picker GothGirl-Zonen | ✔ | **17 Zonen**, Setzen/Zurücksetzen OK |
| Bericht + Code-Export | ✔ | dieses Dokument · `export/WSA_2026-09-16_SESSION/` |

### Nicht gebaut (und als nicht gebaut gekennzeichnet)

- **Die Requisiten und die Karaoke-Bühne aus dem Mockup**: Mikro, Ständer, Hocker, Boxen, Ballons,
  Geschenke, Wortmarken-Banner. Die Kandidaten sind im Paket und geprüft, die Bühne fehlt.
- **Schwarze Wimpern bei GothGirl**: sie kommen als 0,5 × Lidfarbe, also im Hautton. `EyeRig v6` hat
  keinen Griff dafür (`eye.colors.lash` wird abgewiesen — Befund vom 14.09. gilt weiter).
- **Original-gegen-Overlay für Figuren mit ausgetauschtem Kopf** (FrizzleBob, Grafts): sie haben
  keine Original-Teile im Netz; der Umschalter erscheint dort bewußt nicht.
- **Zonenfarben für andere KayKit-Rigs**: der Weg ist derselbe (Inseln + Gruppen), gebaut ist er
  für GothGirl.
- **Consumer-Paket und Video**: nicht gebaut.

---

## 5 · Wiederaufnahme in 5 Minuten (Recovery)

1. `KFB FrankenStein Studio v18.dc.html` öffnen. Figur **GothGirl** wählen (Reiter Body → Figur).
2. Reiter **Face** → »Original parts«: Augen/Brauen/Nase/Mund je zwischen KayKit-Original und
   unserem Overlay schalten. Der Mund baut die Figur neu (die Bildtafel wird beim Laden gemalt).
3. Reiter **Body** → »GothGirl · material zones«: 17 Zonen, je Farbwähler und »Original«.
4. Reiter **Face** → »Brows«: »Balken« wählen, Dicke bis 10 ziehen; die Zeile darunter nennt die
   Balkenhöhe **in Augenradien** (Carls eigene: 1,01).
5. Figur **Hihi** wählen — Cube-Pet auf dem Katzenkörper, rote Lippen, Wimpern, flache Textur.

**Messen ohne Nebenwirkung:** `window.__STUDIO15` ist der Griff. Vor jedem Standbild selbst
`renderer.render` UND `rig.update(dt)` aufrufen (F9). Nach jedem `loadPet` die Entwürfe in
`kfb-pet-studio-v5` prüfen (F10).

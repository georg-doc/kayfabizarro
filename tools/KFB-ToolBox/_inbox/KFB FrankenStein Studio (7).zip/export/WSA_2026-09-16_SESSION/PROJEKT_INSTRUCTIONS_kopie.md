<!-- Kopie der Projekt-Instructions (CLAUDE.md) zum Stand 16.09.2026 -->

# KFB FrizzleGraft — Projekt-Instructions (schlank)

## Was hier liegt
Ein Blatt, ein Ladeweg. **Nichts sonst.** Dieses Projekt ist der Neustart der
FrizzleGraft-Baustelle, nachdem das alte Projekt (1358 Dateien, Instructions über
100.000 Zeichen) nicht mehr arbeitsfähig war.

**Blätter:** **`KFB FrankenStein Studio v18.dc.html`** (aktueller Stand, 15.09. · Elisa-Setup:
Brauen-Stellformel repariert, GothGirl mit eigenem Kopf, Cube-Pet Hihi; v17 bleibt als Referenz
daneben. Zusätzlicher Ladeweg: `lab-v6/browfit.v1.js` · `lab-v6/inkform.v2.js` ·
`frizzlegraft-v1/goth-biped.v1.js`) ·
`KFB Mech & Vehicle Rig v2.dc.html` (aktuell: drei Reiter Sockel · Rover · Wanne, plus
Farbzonen und Repo-Texturen) · `KFB Mech & Vehicle Rig v1.dc.html` (Referenz) ·
`KFB FrankenStein Studio v17.dc.html` (aktueller Stand; v16 bleibt als Referenz daneben liegen) ·
`KFB Animation Lab v3.dc.html` (aktuell: Vertrag als Figurenquelle, Waffenanker/-klasse, Inventar-Kontaktbogen; v2 Referenz) ·
`KFB FrizzleDummy Lab v1.dc.html` (Messbank) ·
**`KFB Rigging Lab v1.dc.html`** (CapsuleCarl-Werkbank, 13.09. hergeholt — Ladeweg `lab-v6/` ·
`lab-v4/carlrig.js` · `lab-v2/{audit,sources}.js` · `_ds/doccheck…` für den Rahmen; die Vendor-Importe
zeigen auf `petstudio-v9/studio-v12/`, es gibt keine zweite Kopie)
**Ladeweg:** **`frizzlegraft-v1/graft-mount.v1.js` (EIN Leser: kfb.pets/1-Eintrag → fertige Figur, Studio-Reihenfolge;
das Lab baut damit, nicht mit eigenen Zahlen)** · `graft-biped.v1.js` (Bewohner) · `facehost.v1.js` · `headgraft.v1.js` · `frizzlegraft-v1/ears.v2.js`
(Rückweg: eine Zeile im Blatt auf `ears.v1.js`) · `petstudio-v9/studio-v12/`
(FrizzleBob v4a · EyeRig v6 · BrowRig v2 · NoseRig v2 · Moustache v1) · `petstudio-v9/studio-v3/pet-mouth.v1.js`
· `petstudio-v9/kfb-ink-canon.js` · Spender `petstudio-v9/assets/models/FrizzleBob_Yellow.gltf`
**Figuren + Bewegungen:** zur Laufzeit aus dem Repo (siehe `github.md`), nichts kopiert.
**Requisiten (14.09.):** `frizzlegraft-v1/recherchi-mount.v1.js` (Recherchi als vierte Bewohnerklasse,
eingehängt in Studio v17) · Probeseite `KFB Vergleich Graft vs Carl v1.dc.html` · Sprintplan und
Backlog in `BRIEFING_PROP_ASSETS_v1.md`. Original nur als Referenz in `uploads/Recherchi v4-2/`.
**Stand:** `LIVING_frizzlegraft.md` — additiv, neueste Zeile oben. Für die Rigging-Linie:
`LIVING_RIGGING.md` (R1–R21) · Übergabe `ONBOARDING_RIGGING_MERGE_v1.md`.
**Übergabe:** `ONBOARDING_frischer_chat.md` — Einstieg, drei offene Aufgaben mit Rezept, bezahlte Fallen.
**ToolBox-Linie (15.09.):** `ONBOARDING_TOOLBOX_UX_CHAT_v1.md` — Ergebnis A (Quellstand + Delta gegen
`export/kfb-rigs-embed-v3/`) und Ergebnis B (EIN gemeinsamer UI-Rework, Pilot am Carl-Weg). Paket in
`uploads/KFB_TOOLBOX_DELTA_UX_HANDOFF_2026-09-15/`.

## Hausregel gegen das, was dieses Projekt gekostet hat
**Die Instructions bleiben unter 60 Zeilen.** Verlauf gehört ins LIVING-Dokument,
nicht hierher. Wächst diese Datei, stirbt der Chat.
**Ein Projekt, eine Baustelle.** Boxel Blitz, SpinballCast, Frankenstein, Travel v13
gehören hier nicht hinein — sie bekommen eigene Projekte mit eigenem schlanken Blatt.
**Keine Binärdateien, keine `captures/`-Halden.** Bilder nach der Verarbeitung löschen.

## So arbeiten wir
Vier Schritte in dieser Reihenfolge: **messen → verstehen → Grenzfälle prüfen → bauen**;
die ersten drei ändern nichts. Referenz schlägt Beschreibung. Ein übernommener Befund ist
eine Vermutung, keine Messung.

**⚠ Messregel, mehrfach bezahlt:** im **verborgenen** Vorschaufenster parkt die Bildschleife
(`document.hidden`) — Zähler bei 35 Bildern, `tri 2`, und es sieht nach einem toten Bau aus.
**Vor jedem Standbild selbst rendern.** Der Fehler sitzt dann nicht im Bau.
**`visible:true`** ist keine Aussage darüber, ob etwas im Bild landet — die Layer-Maske ist
die zweite Hälfte der Frage. **»getroffen« ist nicht »gesehen«** — Sichtbarkeit wird am Pixel
gemessen, mit und ohne. Eine Abnahmezahl, die vom Spielzustand abhängt, muß ein **Verhältnis**
sein. **Eine Messung darf nichts speichern** — wer über einen Bedien-Handler mißt (alles mit `save`,
`_touchPet`, `_ensureInLib`), schreibt in Georgs Sitzung; auf einer Kopie messen oder danach
zurücksetzen. **Die Box des TEILS, nie die des ganzen Spenders.**

## Bericht an Georg
Ein Satz, ein Beleg, drei Schritte, klare Frage mit benannten Optionen und markierter
Empfehlung. Kein Jargon, kein Denglisch, keine Zahlenketten, keine Verweise auf Kontext,
den er nicht vor sich hat. Dateien als anklickbare Karte statt als Pfad.

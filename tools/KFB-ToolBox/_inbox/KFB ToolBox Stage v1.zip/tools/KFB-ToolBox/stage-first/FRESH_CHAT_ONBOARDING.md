# Fresh Chat · KFB ToolBox · Onboarding (16.09.2026, nach Abnahme P0)

GitHub-Stand schlägt Chat-Erinnerung. Vokabular: SOURCE · DECISION · IMPLEMENTATION · TESTED RESULT · GEORG ACCEPTANCE · CANDIDATE CONTRACT DELTA · ARCHIVED HISTORY.

## Stand
- **Arbeitsbasis (GEORG ACCEPTANCE: ACCEPTED FOR WORKING BASELINE):** `tools/KFB-ToolBox/stage-first/src/KFB ToolBox Stage-First v1.dc.html` — Studio-v18-Logik auf WS0-Quellbaum, Stage-First-Shell (Actor · Face · Pose · Motion · Voice · Stage). Nicht bug-frei, nicht visuell final; kein Redesign angefordert.
- **Prüfstand:** `stage-first/qa/Stage-First QA.dc.html` → »Run 13 checks«. 13/13 PASS mit (7).zip-Profilen und mit den Repo-Eingangsprofilen (`window.__QA_PROFILES='repo-inbox/'`). Sitzung wird gesichert/restauriert/nachgemessen.
- **Consumer-Profile (CURRENT TESTED CONSUMER PROFILE INPUT, kfb.pets/1, NICHT kanonisch):** `tools/KFB-ToolBox/_inbox/KFB Elisa B-Day Reference+Mockups/kfb-pet-gothgirl.json` · `kfb-pet-hihi.json`. Nicht vereinfachen, nicht nach `media/3D_Assets/kfb-pets.json` heben.
- **Return + Matrizen:** `stage-first/RETURN_STAGE_FIRST_P0_2026-09-16.md` (Source Map, Promotion-Matrix, 12 Contract-Deltas klassifiziert, Tested Result, F-1…F-8). Hashes: `stage-first/SOURCE_MAP.json`.
- **Offen, akzeptiert:** F-6 Meßfelder (`ground.*`, `body.*`, `pad.anchors`) werden beim Laden neu gemessen · F-7 Studio-Handler schreiben Entwürfe beim Messen · F-8 unveränderter Entwurf `gothgirl` in Georgs Sitzung — **bleibt**, kein »Discard drafts«, keine Sitzungsbereinigung.
- **Git:** Connector hat nur Leserecht (403). Checkpoint-ZIP + `stage-first/PUSH.md`; nach Georgs Push SHA in `SOURCE_MAP.json` und `github.md` nachtragen. Top-Level-Doku: `stage-first/DOC_RECONCILIATION_PROPOSAL.md` additiv einarbeiten.

## Nächster Slice (NOT STARTED)
`Pose → Props → Stage` auf denselben Actors/Verträgen, gleiche Shell, kein zweiter Rewrite. Vorher: Doku-Pointer truthful, Commit-SHA eingetragen. Später eigener Korrektheits-Slice: `preview/select ≠ create dirty draft`.

## Nicht tun
Pet-Library-Migration · neue Registry · neuer Animationsvertrag · World/Birthday-Szene (Fable 5 läuft parallel) · Module umbenennen/verschieben · kanonische Verträge während Closure ändern.

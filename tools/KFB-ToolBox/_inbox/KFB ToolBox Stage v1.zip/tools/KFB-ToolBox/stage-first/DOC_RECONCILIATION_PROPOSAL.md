# Doku-Reconciliation · Vorschlag für die Top-Level-Pointer (additiv, nach Commit)

Nur, was der Checkpoint beweist. Stände trennen:

| Stand | Was | Pin |
|---|---|---|
| WS0 | tested source baseline (7/7 Kaltstarts, 101/101 Prüfsummen) | `_inbox/KFB FrankenStein ToolBox (WS0).zip` sha256 948d1950…3c5b |
| v18 (7) | promoted Studio donor (CURRENT STUDIO WIP) | `_inbox/KFB FrankenStein Studio (7).zip` 4 994 864 B · sha256 06bc8afe…9a117 · Upload-Commit 79c5799a |
| Stage-First | current working UI shell | `stage-first/src/KFB ToolBox Stage-First v1.dc.html` (Hash in `stage-first/SOURCE_MAP.json`) · Design-Donor Stage First v3 (sha256 2430512d…) |
| dieser Commit | tested integrated Actor + Face + Motion + Export | `stage-first/qa/Stage-First QA.dc.html` 13/13 · `stage-first/qa/evidence/` |
| Georg acceptance | ACCEPTED FOR WORKING BASELINE (16.09.) | `stage-first/RETURN_STAGE_FIRST_P0_2026-09-16.md` |
| offen | F-6 Meßfelder beim Laden neu · F-7 Handler schreiben beim Messen · F-8 Entwurf `gothgirl` in Sitzung (bleibt) | Return §7 |

## START_HERE.md — Nachtrag 16.09.
> **Aktueller Startweg:** `stage-first/src/KFB ToolBox Stage-First v1.dc.html` (Actor · Face · Pose · Motion · Voice · Stage). Prüfstand `stage-first/qa/Stage-First QA.dc.html`. Studio v18 ist Donor, nicht Ersatz; die sieben WS0-Blätter starten weiterhin aus `stage-first/src/`. Consumer-Profile: `_inbox/KFB Elisa B-Day Reference+Mockups/kfb-pet-{gothgirl,hihi}.json` (CURRENT TESTED CONSUMER PROFILE INPUT, kfb.pets/1, nicht kanonisch).

## MASTERPLAN.md — Additive Entscheidung
> ### 2026-09-16 · GEORG ACCEPTANCE
> Stage-First v1 P0-Slice (Actor/Face/Motion/Export) = akzeptierte Arbeitsbasis. Nicht bug-frei, nicht visuell final. Nächster Slice `Pose → Props → Stage` auf denselben Actors/Verträgen, kein zweiter Rewrite. Offen: F-6/F-7/F-8.

## TOOLBOX_MANIFEST.json — neue Felder
```json
"status": "P0_SLICE_TESTED_ACCEPTED_WORKING_BASELINE",
"technicalSourceBaseline": { "path": "_inbox/WS0_2026-09-15/unpacked/A_QUELLSTAND/src", "zipSha256": "948d195017e2ab7dd26f3e9c5cb4f01d00fa614e0e6425431db04e43b2393c5b" },
"currentStudioImplementation": { "path": "_inbox/KFB FrankenStein Studio (7).zip", "sha256": "06bc8afed3d5d1f1731d466d1241d64e0c5933c8beb38d888fe69dbe34c9a117", "uploadCommit": "79c5799afd185693f245755f19de2abb44d42452", "role": "PROMOTION DONOR" },
"stageFirstDesignDonor": { "zipSha256": "2430512d1232ef54003bf8acdd7048a2a2db57c16c1e8af5c7fb8f8c8b359d33", "role": "PROVISIONAL DESIGN DONOR" },
"testedIntegratedToolBox": { "entry": "stage-first/src/KFB ToolBox Stage-First v1.dc.html", "qa": "stage-first/qa/Stage-First QA.dc.html", "result": "13/13 PASS", "acceptance": "ACCEPTED FOR WORKING BASELINE", "openIssues": ["F-6", "F-7", "F-8"] },
"currentReturn": "stage-first/RETURN_STAGE_FIRST_P0_2026-09-16.md",
"activeHandover": "stage-first/README.md"
```

## CHANGELOG.md — Eintrag
> ## 2026-09-16 · Stage-First v1 · P0 slice
> Siehe `stage-first/CHANGELOG.stage-first.md` (additiv, vollständig).

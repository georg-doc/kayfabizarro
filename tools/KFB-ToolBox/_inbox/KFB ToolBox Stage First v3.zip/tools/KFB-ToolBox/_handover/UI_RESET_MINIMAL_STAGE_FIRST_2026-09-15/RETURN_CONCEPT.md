# RETURN · UI Reset · Stage-First Concept

**15.09.2026 · Desktop Design → WSA**
**Auftrag:** `START_HERE.md` §20 — drei Konzeptstücke, kein Bau.
**Status:** CONCEPT DELIVERED · wartet auf Georgs Freigabe (§20, letzter Satz).

## Lieferung

| # | Stück | Datei |
|---|---|---|
| 1 | 1440×900 stage-first · Body · FB Driver graft | `screenshots/1a-1440x900-body.png` |
| 2 | 832 split-screen · Motion · Palette als Drawer | `screenshots/1b-832-split-motion.png` |
| 3 | Interaktionskarte · Actor · Body/Material · Motion · Voice/Talk/Bubble · Export | `screenshots/1c-interaction-map.png` |
| — | Quelle aller drei, live | `design/KFB ToolBox Stage-First Concept.dc.html` (+ `support.js`) |
| — | Abgelehnter Stand zum Vergleich | `rejected_v2/shell-v2-01.png`, `shell-v2-02.png` |

## Entscheidungen im Konzept

- **Eine Kopfzeile, 44 px:** `KFB ToolBox · Actor ▾ · Body Face Motion Voice Messen · Spacer · Entwurfsstand · Save · Theme · Export ▾ · …`. Bei 832 px: Wortmarke → `KFB`, Save/Theme/Export/Diagnostics unter `…`. Keine zweite Zeile, kein Band, kein Untertitel.
- **Bühne = ganze Fläche.** Die Palette schwebt (316 px bei 1440, 292 px Drawer bei 832) über der Bühne, kein Spaltenkäfig. Bühnenbedienung als Chips: Kamera `Full · Face · ¾ · Top` + Zoom unten links, `Stage ▾` (Light · Ground · Pad/Base · View) und `Bubble on/off` oben links, `Emote ▾ · Clip ▾ ▶` unten rechts.
- **Eine Kontextpalette je Reiter.** Häufige Gruppe offen, Rest als benannte Disclosure-Zeilen mit Inhaltsvorschau (`▶ Material  Style · Tint · Relief · AO`), `Show all` im Palettenkopf. Kontrakt-Abschnitte stehen als letzte Zeile mit Verweis `→ Messen`.
- **Actor-Roster** ist ein Popover: Suche filtert alle Gruppen einschließlich eingeklappter (Tuned/Recent · 24 Cube-Pets · 43 KayKit), Treffer je Gruppe gezählt, `not found` wird gezeigt statt versteckt. Esc/Klick außerhalb schließen, ⊙ pinnt. Ungespeichert → Save · Discard · Cancel.
- **Materialzone:** Zeile = Swatch · Name · Finish. Ausgewählte Zone bekommt inline (keine Karte) Swatch · `#hex` · Copy · Palette · Surface · Original · Roughness. Popover-Picker mit Validierung, Esc, Klick außerhalb.
- **Motion:** Suche, Kategorie-Chips (acht KayKit-Sätze), Clipliste, `▶ Play · ■ Stop · Rest · Loop · Speed`. Nicht bindende Clips durchgestrichen mit einer Zeile `no bind`. Casting als Disclosure: Slot → Kandidat → `n/69` → Accept.
- **Voice:** Textfeld · Voice-Wunsch · `Speak · Stop · Talk · Rest` · fünf Viseme-Chips. Blase liegt auf der Bühne, ziehbar, Typ/Richtung/Kontur als Mini-Chips an der Blase. Beim Wechsel nach Voice automatisch an, danach Benutzerstand.
- **Export:** Menü benennt das Ziel vor dem Schreiben (This actor · Selection · Full set · Motion map · Import file … · Diagnostics). Toast 1,5 s nach Save.

## Abnahme gegen §21

| Kriterium | 1a | 1b |
|---|---|---|
| ≤ 1 persistente Kopfzeile | ✔ 44 px | ✔ 44 px |
| Keine Erklärabsätze | ✔ | ✔ |
| Kein Meta/Contract-Text | ✔ (nur `… → Diagnostics`) | ✔ |
| Bühne dominiert | ✔ 1104 × 856 px frei | ✔ 540 × 956 px frei, Figur 270 px breit |
| Roster nicht auf vier Figuren | ✔ 5 + 24 + 43, suchbar | ✔ |
| Funktionsverlust | ✘ keiner — 39 Abschnitte bleiben über Disclosure erreichbar (Matrix in `../UI_CRITIQUE_REWORK_WS0_2026-09-15/COVERAGE_MATRIX.md`) | |
| Split-Screen ohne gestapeltes Chrome | — | ✔ Drawer, kein dritter Spaltenlauf |

## Offen für Georg

1. **Fußstreifen »ohne Klick da«:** auf zwei Chips `Emote ▾ · Idle_A ▾ ▶` unten rechts reduziert. Alternative: ganz in die Paletten.
2. **Startseite mit Kacheln:** siehe Chat-Antwort — Empfehlung: kein Kachel-Vorschaltbild vor der Bühne; Leerzustand der Bühne (kein Actor) zeigt das Roster direkt. Kacheln nur auf der ToolBox-Übersicht (`site/`) für die sieben Werkzeuge, wie heute.
3. Freigabe → dann Vollbau nach Coverage-Matrix (G1–G6, P0-Reihe).

## Nicht geschehen

Kein Bau, kein Byte am Quellstand, Shell v2 unangetastet (abgelehnt, archiviert). Git-Push von hier weiterhin nicht möglich (Schreibrecht fehlt, siehe `../BIRTHDAY_STARTSCREEN_2026-09-15/PUSH.md`) — Paket als ZIP.

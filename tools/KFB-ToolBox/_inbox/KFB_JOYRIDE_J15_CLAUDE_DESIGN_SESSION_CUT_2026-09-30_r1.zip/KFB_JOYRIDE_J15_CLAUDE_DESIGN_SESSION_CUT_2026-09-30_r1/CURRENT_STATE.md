# CURRENT_STATE · 2026-09-30 abends

| Bereich | Stand |
|---|---|
| Parcours 1b | fahrbar in J15, geschlossen, 4.392 m, Fingerprint d42aa57e |
| Tunnel | TC1, 4 Looks live umschaltbar, Standard stone_arch |
| Fahrphysik | K2B (Standard) / K2 pur wählbar; FLOW/FEEL = Race v0.8 |
| Kamera | J09-Verfolger unverändert; Probe Tunnel/Loop/Skydrive ohne Verdeckung |
| Reisemodi | aus J14 übernommen, unverändert (Status CANDIDATE) |
| Leistung | TC1 +58–82k △, Bau ≤ 95 ms; Georgs Gerät nicht gemessen |
| Offen | Look-Wahl · Einbaufreiheit als Core-Check · Tunnel-Innenlicht · Hero Jump braucht Boost |

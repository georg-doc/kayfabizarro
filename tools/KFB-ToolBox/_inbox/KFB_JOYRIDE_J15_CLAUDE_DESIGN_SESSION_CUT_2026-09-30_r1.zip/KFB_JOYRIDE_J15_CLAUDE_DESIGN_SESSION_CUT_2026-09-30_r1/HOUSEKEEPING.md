# HOUSEKEEPING · J15 Session Cut

## Behalten
J15-DC, TC1-Looks-DC, `lab-track/tunnel-clay.tc1.js`, `lab-track/tc1-sheet.js`, `lab-track/j15-cam-probe.js`, `lab-track/data/p1b.stream.json` + `p1b.export.json`, `lab-track/evidence/**`, `export/JOYRIDE_J15_2026-09-30/RETURN.md`.

## Arbeitsreste (nicht im ZIP, kann weg)
- `export/_stage_j15/**` (Staging dieses Exports)
- `lab-track/evidence/tc1-looks.v1.png`, `v2.png` und `tc1-chase.v1.png`: Vorstände. Liegen im ZIP als Beleg für die Fixes, im Workspace entbehrlich.

## Doppelte Wahrheiten vermeiden
- Tunnel-Ringe: `p1b.stream.json` trägt `tunnelRings` (Standard gotthard) **und** `tunnelLooks` (4 Ringe). Nach der Look-Wahl nur noch einen.
- Der Loader-v5-`buildTunnels` bleibt in J15 nur als Rückfall, falls TC1 wirft.
- p1a (J12–J14) und p1b (J15) sind getrennte Streams. Rezepte liegen beide in `p1-recipes.js`.

## Große Dateien
`p1b.stream.json` 10,78 MB (6 Teile) und `Fingerprints01_3K.png` 4,70 MB (3 Teile) liegen als Teile ≤ 1,9 MB im ZIP.

# HANDOVER an WSA · J15 Parcours 1b + Knet-Tunnel TC1 · 2026-09-30

## Auftrag (P1-Brief, Schritte 3–4) + Georgs Zusatz
- Georg hat **1b „Stadt → Fahrschule → Finale“** gewählt → Stream bauen, fahrbar machen, testen.
- Zusatz Georg: Tunnel im Knetstil, modular, in der Palette; Portal-Looks Stein-Bogen/Rechteck, runde Race-Tube, Holz-Minenstollen.

## Was steht
- **Stream** `lab-track/data/p1b.stream.json`:
  - Track Core v0.12, Rezept `p1-recipes.js#B` unverändert, + `J14_PADS`
  - Core-Fingerprint **d42aa57e**, 4.392,5 m, geschlossen, 25 Checks, 0 Fehler
  - Nachgetastet auf ds 0,5 (Verfahren wie p1a). Am p1a-Export nachgeprüft: 0 m Geometrie-Abweichung, Indizes gleich.
- **Tunnel-Looks:** `tunnelLooks` im Stream enthält 4 Core-Ringe für dieselbe Route. Nur der `tunnel`-Parameter am Stück `tunnel_in` ändert sich, der Fingerprint bleibt gleich.
- **TC1** `lab-track/tunnel-clay.tc1.js`: Look-Schicht über dem Ring. Nutzt T4-Knetmaterialien aus `T.M`; ein Weltwechsel färbt mit.
  - Module: Stein 8 m, Tube 6 m, Mine 5 m
  - Stöße: Gurtbogen / Band-Ring / Türstock
  - Wirt: Knethügel oder freie Röhre
  - Portal-Bausatz je Look
- **J15** = J14-Host (Reisemodi, K2B/K2, HUD, Kamera unverändert) + Stream 1b + TC1. J14 bleibt unberührt.
- **Tests:**
  - Runde headless: K2B 91,60 s · K2B@0,8 91,87 s · K2 91,53 s · je 7/7 Sprünge, 0 Bande, 0 Rettungen
  - Kamera-Probe in der Vorschau (Tunnel ×4 Looks, Looping, Skydrive): 0 verdeckt, 0 unter der Fahrbahn, 0 Kipper

## Was nicht steht
- Die **Einbaufreiheit** der Verkleidung prüft TC1 selbst (Nachbau `needOf`: Slots ≥ −0,4 m + 7,0 m). Das ist kein Core-Check. Vorschlag: `tunnel_cladding` als Core-Check aufnehmen.
- **Sichtstrahl** nur gegen Tunnel + `strang`-Meshes.
- **Tunnel-Innenlicht:** Die Fahrbahn liegt im Sonnenschatten; die Lampen sind nur emissive.
- **Leistung:** TC1 kostet +58–82k △. Die Bildrate auf Georgs Gerät ist nicht gemessen (J14 lag bei ~10 fps).
- **Hero Jump** nur mit Boost (jump_speed 32,05 > 27). TD03-Warnungen unverändert.
- **Mine:** Die Bretterwand liest sich aus der Ferne wie Mauerwerk. T4-Bäume im Hügel-Grundriss stechen durch.

## Owner-Grenzen (nicht verschieben)
- Strecke/Fläche/Ring = Track Core Stream
- Tunnel-Aussehen = TC1 (nur Look)
- Auto = kfb-drive.k2b/k2
- Kamera = J09
- Travel = travel-core.j14
- T4, M2, Übergangsatlas, Fassaden, Schatten = unverändert

## WSA-Entscheide nötig
1. Welcher Tunnel-Look (oder je Portal einer) wird kanonisch? Dann kommt er als `tunnel:{…}` fest in Rezept B, und `tunnelLooks` entfällt.
2. `tunnel_cladding`-Check in den Core übernehmen oder TC1-lokal lassen?
3. Nachtastung ds 0,5 im Export beibehalten oder s-Lookup in T4/K2 (offen seit p1a)?

## Next Gate
**Georg/WSA wählen den Tunnel-Look → Rezept B mit festem `tunnel`-Parameter neu exportieren (p1b.v2, ein Ring), J15 lädt ihn, Runde + Kamera-Probe wiederholen.**

# TEST_REPORT · J15 · 2026-09-30

| # | Test | Ort | Ergebnis | Beleg |
|---|---|---|---|---|
| T1 | Core compileRecipe B + runChecks | headless | **PASS** · 25 Checks, 0 Fehler, 4 Warnungen (TD03 ×3, jump_speed 32,05) | lab-track/data/p1b.export.json |
| T2 | Nachtastung gegen p1a-Export validiert | headless | **PASS** · Geometrie max. 0 m, Joints/_joints/Tunnel identisch (round(s/ds)) | p1b.stream.json source.reindex |
| T3 | Pads (J14_PADS) auf 1b | headless | **PASS** · 2 Pads, pad_level 0,0001 m, Fingerprint gleich | p1b.export.json |
| T4 | Tunnel-Looks ×4 vom Core kompiliert | headless | **PASS** · je 0 Fehler, tunnel_clearance 0,3, portal_match 0, tunnel_shell PASS, Fingerprint d42aa57e gleich | p1b.export.json tunnelLooks |
| T5 | Runde 1b (W+Shift, Start s 60, dt 1/60) | headless | **PASS** · K2B@1 91,60 s · K2B@0,8 91,87 s · K2 91,53 s · 7/7 Sprünge · 0 Bande · 0 Rettungen | evidence/j15-round-gate.p1b.json |
| T6 | TC1 Einbaufreiheit ≥ 0,3 m (TC1-Regel) | Vorschau | **PASS** · 1,09 / 0,41 / 0,65 / 0,40 m (r1 Mine −0,12 und r2 Mine 0,02 = FAIL, behoben) | J15-Statuszeile, evidence/tc1-looks.v3.jpg |
| T7 | Kamera-Probe Tunnel ×4 Looks | Vorschau | **PASS** · 431 Sichtproben 0 verdeckt, 0× außerhalb des Rings, min. Abstand 4,0 m | evidence/j15-cam-probe.json |
| T8 | Kamera-Probe Looping + Skydrive | Vorschau | **PASS** · 136 + 290 Proben, 0 verdeckt (nur strang-Meshes), 0× unter der Fahrbahn, 0 Kipper | evidence/j15-cam-probe.json |
| T9 | Bildkontrolle Portale/Innen/Übersicht/Verfolger | Vorschau | **PASS nach Fix** · v1 flacher Hügel, chase.v1 Modulfuge → v3/chase.v2 | evidence/tc1-*.jpg (im Workspace als PNG unter lab-track/evidence/) |
| T10 | Clean-Run gegen das entpackte ZIP | Skript | siehe cleanrun.json / Rückgabe | – |
| T11 | fps auf Georgs Gerät | – | **NOT_RUN** | – |
| T12 | Runde in der Vorschau per Knopf „Runde“ | – | **NOT_RUN** (nur headless) | – |

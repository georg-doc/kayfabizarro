# RETURN · Joyride J15 · Parcours 1b + Knet-Tunnel TC1 · 30.09.2026

## Probleme zuerst
1. **Einbaufreiheit ist mein Check, kein Core-Check.** TC1 baut den Core-Test `needOf` nach (Slots ≥ −0,4 m + 7,0 m Fahrzeughülle) und misst jedes Innenteil dagegen. Der Core selbst prüft nur den Ring (tunnel_clearance 0,3 m, portal_match, tunnel_shell = PASS für alle 4 Looks).
2. **Sichtlinien-Probe unvollständig:** Der Strahl Kamera → Auto prüft die Tunnel-Gruppe und die `strang`-Meshes. Fahrbahn-Meshes mit anderen Namen fehlen.
3. **Hero Jump:** Die Lippe verlangt 32,05 m/s, vMax ist 27 → nur mit Boost (Core-Warnung jump_speed). Die Probe fährt W+Shift.
4. **TD03-Warnungen** bleiben unverändert: roof_loop 26 m, Breitenwechsel 1:11, Kreuzung 3,35 m unter der 7-m-Hülle.
5. **Fahrphysik:** Gefahren mit K2B, wie in J14. K2 pur ist gegengeprüft (91,53 s). Race-v0.8-FLOW/FEEL unverändert.
6. **Im Tunnel ist die Fahrbahn dunkel** (Sonnenschatten). Die Lampen leuchten nur selbst (emissive), echte Lichter gibt es nicht. Grund: sonst würden alle Materialien neu kompiliert.
7. **Mine:** Die Bretterwand liest sich aus der Ferne wie Mauerwerk. T4-Bäume im Hügel-Grundriss stechen durch den Hügel, weil die Prop-Wache nur die Röhre kennt.

## Quelle / Owner
- Generator: `lab-track/core/track-core.v012.mjs` (= S13_V012_2026-09-28). Rezept `lab-track/parcours/p1-recipes.js#B`, unverändert, + `J14_PADS`.
- TD03 Fingerprint 256f2478 (unverändert). **1b Core-Fingerprint d42aa57e**, 4.392,5 m, geschlossen, 25 Checks, 0 Fehler, pad_level 0,0001 m.
- Nachtastung wie bei p1a: 8.726 → 8.786 Samples auf ds 0,5. Verfahren am p1a-Export nachgeprüft: Geometrie max. Abweichung 0 m, Joints, _joints und Tunnel gleich indiziert (round(s/ds)).
- Tunnel-Looks: dieselbe Route, am Stück `tunnel_in` ändert sich nur `tunnel`. Jeder Look ist vom Core kompiliert, der Fingerprint bleibt d42aa57e (Fahrfläche identisch):
  - stone_arch = gotthard (arch, 26,4 × 16,4 m)
  - stone_rect = gotthard + rect e6 (27,1 × 9,5 m)
  - race_tube = toy (round, 24,9 m)
  - mine = gotthard + rect e10, earth, Wand 1,0 (27,1 × 9,3 m)

## Gewählt: 1b Stadt → Fahrschule → Finale
Uni-Center (TD03) → Stadtstraße 250 m → Fahrschule (Pad, Pier, 4 Bojen, Loop 60 m, Magnet-Catch) → Skydrive (Spirale 720°, Grat, Sprung) → Übergang Natur → Knet-Tunnel 231 m mit 90°-Kurve → Hero Jump → Heimweg. Draufsicht: `KFB Joyride P1 · Parcours-Plan.dc.html` (1b).

## Knet-Tunnel TC1 (`lab-track/tunnel-clay.tc1.js`)
- Nur Look-Schicht über dem Core-Ring; Lage und Ring kommen aus dem Stream.
- Materialien: die vorhandenen T4-Knetmaterialien (rock, tower0/1, hill0/1, strang, cloud, pad, trunk). Gleiche Knete, gleiche Palette, der Weltwechsel färbt mit. Einziges eigenes Material: die Lampen.
- Modular gebaut:
  - Röhre aus Modulen (Stein 8 m, Tube 6 m, Mine 5 m). Die Wand weicht zwischen den Stößen nach außen zurück, nie nach innen.
  - Am Stoß je nach Look: Gurtbogen, Band-Ring oder Türstock (Stempel, Kappe, Streben).
  - Wirt: Knethügel, der an den Portalen niedrig ansetzt und in der Mitte zum Berg mit zwei Kuppen wird; bei der Race-Tube eine freie Röhre.
  - Portal-Bausatz je Look.
- Die vier Looks:
  - **Stein-Bogen:** Keilsteine, Schlussstein, Sockel, Stirnwand
  - **Stein-Rechteck:** Eckquader im Wechsel, dreiteiliger Sturz, Gesims
  - **Race-Tube:** Randwulst in 14 Streifen, Lampen-Gantry, Bänder
  - **Minen-Stollen:** Holzrahmen, Kappe, Streben, Bretterwand, Laternen
- Umschalten: Einstellungen → „Tunnel · …“ (bleibt über Neuladen erhalten) oder Tweak `tunnelLook`.
- Kosten: 58k △ (Stein-Bogen), 59k (Stein-Rechteck), 82k (Tube), 67k (Mine). Bau 50–95 ms.
- Einbaufreiheit: Stein-Bogen 1,09 m, Stein-Rechteck 0,41 m, Tube 0,65 m, Mine 0,40 m → alle ≥ 0,3 m, PASS.

## Tests (echte Zahlen)
- **Runde headless** (`lab-track/evidence/j15-round-gate.p1b.json`, dt 1/60, W+Shift, Start s 60):
  - K2B Spurhilfe 1: **91,60 s**
  - K2B Spurhilfe 0,8: 91,87 s
  - K2 pur: 91,53 s
  - Jeweils: 7 Absprünge / 7 Landungen, 0 Bandenkontakte, 0 Rettungen, 5,3–7,0 s Luft, vMax 49 m/s
  - Zwischenzeiten (K2B@1): Tunnel 75,4 → 80,2 s, Hero 84,2 s
- **Kamera in der Vorschau** (`lab-track/evidence/j15-cam-probe.json`), Up-Vektor-Kipper überall 0:
  - Tunnel, 4 Looks: 103–113 Sichtproben, 0 verdeckt, Kamera 0× außerhalb des Rings (min. Abstand zum Ring 4,0–8,7 m)
  - Looping: 136 Sichtproben, 0 verdeckt, Kamera 0× unter der Fahrbahn
  - Skydrive: 290 Sichtproben, 0 verdeckt, Kamera 0× unter der Fahrbahn
- **Bilder angesehen:**
  - `lab-track/evidence/tc1-looks.v3.png`: 4 Looks × Portal Einfahrt / Innen / Portal Ausfahrt / Übersicht
  - `lab-track/evidence/tc1-chase.v2.png`: echte Verfolgerkamera vor dem Portal und in der Kurve
  - v1 und `tc1-chase.v1` zeigen die Vorstände: Fuge zwischen den Modulen, flacher Hügel. Beides behoben.

## Geänderte / neue Dateien
- neu `lab-track/data/p1b.stream.json` (+ `p1b.export.json`)
- neu `lab-track/tunnel-clay.tc1.js`, `lab-track/tc1-sheet.js` (Beleg-Kontaktbogen), `lab-track/j15-cam-probe.js`
- neu `KFB Joyride J15 · Parcours 1b.dc.html`: J14-Host (Reisemodi, K2B/K2, HUD) + Stream 1b + TC1. J14 bleibt unverändert.
- Nicht angefasst: Core, Rezepte, T4, M2, Übergangsatlas, Fahrphysik, Kamera, Fassaden, Schatten.

## Route
`KFB Joyride J15 · Parcours 1b.dc.html` (direkt, keine eigene Stage-Route).

## Ein nächstes Tor
Georg wählt den Tunnel-Look (oder je Portal einen). Danach kommt der Look als `tunnel: { preset, shape … }` fest in das Rezept B, und der Stream wird einmal neu exportiert (nur noch ein Ring).

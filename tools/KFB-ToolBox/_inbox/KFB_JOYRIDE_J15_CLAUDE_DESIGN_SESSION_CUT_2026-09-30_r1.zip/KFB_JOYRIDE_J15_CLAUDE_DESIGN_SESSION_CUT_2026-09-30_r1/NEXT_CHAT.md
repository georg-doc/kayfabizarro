# NEXT_CHAT · Onboarding für einen frischen Chat

## Paste-Prompt
> Weiter mit KFB Joyride J15 (Session Cut 2026-09-30 r1, Projekt „KFB World Design Setup“). Entry Point `KFB Joyride J15 · Parcours 1b.dc.html`, Status DESIGN PROOF · CANDIDATE. Lies zuerst START_HERE.md, HANDOVER.md, TEST_REPORT.md. Setz die zwei geteilten Dateien zusammen. Nichts neu erfinden: Werte kommen aus Track Core v0.12 oder aus den Belegen. Auftrag: das Next Gate aus HANDOVER.md.

## Kontext in fünf Sätzen
1. Joyride ist ein Knet-Rennspiel (three.js, Claymation-Look T4), dessen Strecken ausschließlich der **Track Core v0.12** baut (`lab-track/core/track-core.v012.mjs`, Rezepte in `lab-track/parcours/p1-recipes.js`).
2. P1 ist der Baukasten-Parcours: TD03 (Uni-Center) + Stadt + Fahrschule + Skydrive + Tunnel + Hero Jump. Georg hat **1b** gewählt, er ist fahrbar in J15.
3. Der Tunnel ist eine reine Look-Schicht (TC1) über dem Core-Ring, mit vier Looks (Stein-Bogen, Stein-Rechteck, Race-Tube, Minen-Stollen), umschaltbar im Burger-Menü.
4. Fahrphysik K2B (= k2 + zwei belegte Deltas), Kamera J09, Reisemodi J14: alles eingefroren.
5. WSA ist der Architekt/Reviewer: gibt Briefs, entscheidet Owner-Fragen, will Belege statt Behauptungen.

## Arbeitsregeln (aus WSA-Briefs und Post-Mortems)
- Kein zweiter Owner: keine zweite Track-, Kamera-, Physik- oder Travel-Engine. Neue Strecken sind neue Streams aus demselben Core.
- Werte aus Quellen, nie geraten. Budget-Änderung nur mit Vorher/Nachher-Beleg.
- An jeder menschlichen Wahl anhalten (Draufsicht/Looks zeigen, Georg wählt).
- Vor jeder Übergabe die betroffene Stelle im Bild prüfen. Die Vorschau kann WebGL nur über den Kontaktbogen fotografieren: `(await import('./lab-track/tc1-sheet.js')).sheet()` bzw. `.chase()`, danach das Element `#tc1-sheet` / `#tc1-chase` sichern.
- Nach zwei Fehlversuchen am selben Gate: einfrieren, Belege nebeneinander zeigen, keinen dritten geratenen Fix.
- Neue Ausgaben versioniert benennen (.vN / .jN / ?r=N), wegen des Browser-Caches.
- Nur ausgeführte Tests heißen PASS, sonst NOT_RUN. Keine Spielbarkeit behaupten ohne Fahrprobe.
- Nicht anfassen ohne Brief: Fassaden, Schatten, T4-Look, M2-Markierungen, Übergangsatlas, Race-v0.8-Physik.

## Werkzeuge im Projekt
- Runde headless: siehe `TEST_REPORT.md` T4. Die Physik-Datei läuft ohne three im Skript (`makeFrame`, `createDriver`, `stepDriver`).
- Kamera-Probe: `(await import('./lab-track/j15-cam-probe.js')).run({ zones:['tunnel','loop','skydrive'], look })` → `window.__camProbe`.
- TC1-API im J15: `window.__tc1.setLook(id)`, `window.__tc1.info` (Module, Teile, △, Einbaufreiheit).
- Core-Export eines Rezepts: `compileRecipe` → `runChecks` → `placePads` → erneut `compileRecipe` → Nachtastung ds 0,5 (Indizes round(s/ds)).

## Offene Entscheide (nicht selbst treffen)
Tunnel-Look · Einbaufreiheit als Core-Check · Nachtastung vs. s-Lookup · Tunnel-Innenlicht · Leistung auf Georgs Gerät.

/* TC1 Beleg-Kontaktbogen: rendert je Tunnel-Look vier feste Blickwinkel mit der laufenden Szene (eigene Kamera, ohne Post-Pass)
 * und legt das Blatt als <img id="tc1-sheet"> über die Seite. Aufruf im J15: (await import('./lab-track/tc1-sheet.js')).sheet() */
export async function chase({ looks = ['stone_arch', 'stone_rect', 'race_tube', 'mine'], id = 'tc1-chase' } = {}) {   // echte Verfolgerkamera (J09) vor dem Portal und in der Kurve
  const a = window.__j12, tc = window.__tc1, cv = a.T.renderer.domElement, seg = a.T.td.tunnels[0], wait = ms => new Promise(r => setTimeout(r, ms));
  const W = 480, H = 270, sh = document.createElement('canvas'); sh.width = W * looks.length; sh.height = H * 2 + 44; const g = sh.getContext('2d'); g.fillStyle = '#1b1528'; g.fillRect(0, 0, sh.width, sh.height);
  const shots = [['Verfolger vor dem Portal', seg.s0 - 30], ['Verfolger im Tunnel (Kurve)', seg.s0 + 110]], prev = tc.info.look;
  for (let r = 0; r < 2; r++) for (let c = 0; c < looks.length; c++) { tc.setLook(looks[c]); a.placeCar(shots[r][1], 20, 0); a.key('gas', false); await wait(1800);
    g.drawImage(cv, 0, 0, cv.width, cv.height, c * W, 22 + r * (H + 22), W, H); g.fillStyle = '#FBF3E4'; g.font = 'bold 13px sans-serif'; g.fillText(shots[r][0] + ' · ' + looks[c], c * W + 6, 16 + r * (H + 22)); }
  tc.setLook(prev);
  let el = document.getElementById(id); if (!el) { el = document.createElement('img'); el.id = id; el.style.cssText = 'position:fixed;left:0;top:0;width:1920px;z-index:99998'; document.body.appendChild(el); }
  el.src = sh.toDataURL('image/jpeg', 0.86); await el.decode().catch(() => {}); return true;
}
export async function sheet({ pause = true, looks = null } = {}) {
  const a = window.__j12, T = a.T, S = T.td.samples, seg = T.td.tunnels[0], tc = window.__tc1;
  const cam = T.camera.clone(); cam.aspect = 16 / 9; cam.fov = 50; cam.near = 0.3; cam.updateProjectionMatrix();
  const pt = (i, r, u, t) => { const q = S[i]; return [0, 1, 2].map(k => q.p[k] + q.R[k] * r + q.U[k] * u + q.T[k] * t); };
  const mid = (seg.i0 + seg.i1) >> 1;
  const views = [
    ['Portal Einfahrt', () => { cam.position.set(...pt(seg.i0, 1.5, 6, -46)); cam.lookAt(...pt(seg.i0, 0, 5.5, 0)); }],
    ['Innen · 30 m (Fahrerhöhe)', () => { cam.position.set(...pt(seg.i0 + 60, -3, 3.0, 0)); cam.lookAt(...pt(seg.i0 + 120, 1, 2.8, 0)); }],
    ['Portal Ausfahrt', () => { cam.position.set(...pt(seg.i1, -2, 7, 48)); cam.lookAt(...pt(seg.i1, 0, 5.5, 0)); }],
    ['Übersicht', () => { cam.position.set(...pt(mid, 150, 95, -40)); cam.lookAt(...pt(mid, 0, 4, 0)); }]
  ];
  const W = 480, H = 270, L = looks || Object.keys(window.__KFB_J04.TUNNEL_KITS), prev = tc.info.look, info = {};
  const sh = document.createElement('canvas'); sh.width = W * views.length; sh.height = (H + 22) * L.length; const g = sh.getContext('2d'); g.fillStyle = '#1b1528'; g.fillRect(0, 0, sh.width, sh.height);
  const cv = T.renderer.domElement;
  for (let r = 0; r < L.length; r++) { const inf = tc.setLook(L[r]); info[L[r]] = { tris: inf.tris, parts: inf.parts, modules: inf.modules, clearance: inf.clearance.value, pass: inf.clearance.pass, at: inf.clearance.at, buildMs: inf.buildMs };
    g.fillStyle = '#FBF3E4'; g.font = 'bold 14px sans-serif'; g.fillText(`${inf.label} · ${L[r]} · ${inf.modules} Module à ${inf.moduleLen} m · ${Math.round(inf.tris / 1000)}k △ · Einbaufreiheit ${inf.clearance.value} m ${inf.clearance.pass ? 'PASS' : 'FAIL'}`, 8, r * (H + 22) + 16);
    for (let c = 0; c < views.length; c++) { views[c][1](); cam.updateMatrixWorld(); T.renderer.render(T.scene, cam); g.drawImage(cv, 0, 0, cv.width, cv.height, c * W, r * (H + 22) + 22, W, H);
      if (r === 0) { g.fillStyle = 'rgba(0,0,0,.5)'; g.fillRect(c * W, 22, 190, 20); g.fillStyle = '#fff'; g.font = '12px sans-serif'; g.fillText(views[c][0], c * W + 6, 37); } } }
  tc.setLook(prev);
  let el = document.getElementById('tc1-sheet'); if (!el) { el = document.createElement('img'); el.id = 'tc1-sheet'; el.style.cssText = 'position:fixed;left:0;top:0;width:1920px;z-index:99999;background:#000'; document.body.appendChild(el); }
  el.src = sh.toDataURL('image/jpeg', 0.86); await el.decode().catch(() => {});
  if (pause) { cv.style.display = 'none'; window.requestAnimationFrame = () => 0; }
  return info;
}

/* J15 Kamera-Probe (Vorschau, echte J09-Kamera): fährt Tunnel, Looping und Skydrive mit W+Shift ab und misst je Bild
 * Kamera-Lage im Streckenrahmen (quer/hoch), Innenlage im Tunnelring, Sichtlinie Kamera → Auto gegen Tunnel + Fahrbahn-Meshes,
 * Up-Vektor gegen Strecken-U. Ergebnis in window.__camProbe. Aufruf: (await import('./lab-track/j15-cam-probe.js')).run() */
import * as THREE from 'three';
const sdPoly = (P, x, y) => { let inside = false, d = 1e9; for (let i = 0, j = P.length - 1; i < P.length; j = i++) { const a = P[j], b = P[i];
  if ((b[1] > y) !== (a[1] > y) && x < (a[0] - b[0]) * (y - b[1]) / (a[1] - b[1]) + b[0]) inside = !inside;
  const ex = b[0] - a[0], ey = b[1] - a[1], t = Math.max(0, Math.min(1, ((x - a[0]) * ex + (y - a[1]) * ey) / (ex * ex + ey * ey || 1))); d = Math.min(d, Math.hypot(x - a[0] - t * ex, y - a[1] - t * ey)); } return inside ? -d : d; };
export async function run(opt = {}) {
  const a = window.__j12, T = a.T, td = T.td, S = td.samples, J = td._joints || td.joints, tc = window.__tc1, tv = window.__j14;
  const js = id => J.find(j => j.piece === id).s, seg = td.tunnels[0];
  const ZONES = [{ id: 'tunnel', from: seg.s0 - 90, to: seg.s1 + 30, s0: seg.s0, s1: seg.s1 }, { id: 'loop', from: js('fs_loop') - 70, to: js('fs_loop_out') + 20, s0: js('fs_loop'), s1: js('fs_loop_out') },
    { id: 'skydrive', from: js('sky_spiral') - 30, to: js('sky_land') + 90, s0: js('sky_spiral'), s1: js('sky_land') + 70 }];
  if (opt.look && tc) tc.setLook(opt.look); const ZL = opt.zones ? ZONES.filter(z => opt.zones.includes(z.id)) : ZONES;
  const occ = []; T.root.traverse(o => { if (o.isMesh && /^(road|strang|strangT|curb|walk|plate)$/.test(o.name)) occ.push(o); }); if (tc?.group) occ.push(tc.group);
  const ray = new THREE.Raycaster(), out = { at: new Date().toISOString(), look: tc?.info.look, occluders: occ.map(o => o.name), zones: {} };
  (window.__camProbes ||= {})[tc?.info.look || "?"] = out; window.__camProbe = out; if (tv && tv.core.S.mode !== 'AUTO') { tv.request('AUTO'); await new Promise(r => setTimeout(r, 2500)); }
  const ring = tc && td.tunnelLooks?.looks?.[tc.info.look]?.ring;
  for (const Z of ZL) {
    a.placeCar(Z.from, 30, 0); a.key('gas', true); a.key('boost', true);
    const R = { frames: 0, inZone: 0, occluded: 0, camUnderRoad: 0, camOutsideRing: 0, minRingClear: 1e9, upFlip: 0, minLift: 1e9, maxDist: 0, minDist: 1e9, samples: [] };
    const t0 = performance.now();
    await new Promise(res => { const tick = () => { const s = a.drv.s; if (s > Z.to || performance.now() - t0 > 60000) return res(); requestAnimationFrame(tick);
      const cam = a.camera.position, car = a.carG.position; R.frames++; if (s < Z.s0 || s > Z.s1) return; R.inZone++;
      let bi = -1, bd = 1e9; const i0 = Math.max(0, Math.floor((s - 40) / td.ds)), i1 = Math.min(S.length - 1, Math.ceil((s + 5) / td.ds));
      for (let i = i0; i <= i1; i++) { const p = S[i].p, d = (p[0] - cam.x) ** 2 + (p[1] - cam.y) ** 2 + (p[2] - cam.z) ** 2; if (d < bd) { bd = d; bi = i; } }
      const q = S[bi], v = [cam.x - q.p[0], cam.y - q.p[1], cam.z - q.p[2]], lat = v[0] * q.R[0] + v[1] * q.R[1] + v[2] * q.R[2], lift = v[0] * q.U[0] + v[1] * q.U[1] + v[2] * q.U[2];
      R.minLift = Math.min(R.minLift, lift); if (lift < 0.3) R.camUnderRoad++;
      const up = a.camera.up, dUp = up.x * q.U[0] + up.y * q.U[1] + up.z * q.U[2]; if (dUp < 0.2) R.upFlip++;
      if (Z.id === 'tunnel' && ring && q.tunnel) { const d = sdPoly(ring, lat, lift); R.minRingClear = Math.min(R.minRingClear, -d); if (d > 0) R.camOutsideRing++; }
      const tgt = new THREE.Vector3(car.x, car.y + 0.8, car.z), dir = tgt.clone().sub(cam), dist = dir.length(); R.maxDist = Math.max(R.maxDist, dist); R.minDist = Math.min(R.minDist, dist);
      if (R.inZone % 2 === 0) { ray.set(cam, dir.normalize()); ray.far = dist - 1.2; const hit = ray.intersectObjects(occ, true)[0]; if (hit) { R.occluded++; if (R.samples.length < 12) R.samples.push({ s: +s.toFixed(1), hit: hit.object.name, at: +hit.distance.toFixed(2), dist: +dist.toFixed(2), lat: +lat.toFixed(2), lift: +lift.toFixed(2) }); } }
    }; requestAnimationFrame(tick); });
    a.key('gas', false); a.key('boost', false);
    R.checked = Math.ceil(R.inZone / 2); for (const k of ['minRingClear', 'minLift', 'maxDist', 'minDist']) R[k] = R[k] === 1e9 ? null : +R[k].toFixed(2); out.zones[Z.id] = R;
  }
  out.done = true; return out;
}

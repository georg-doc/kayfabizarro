# CHANGELOG · J15 Session 2026-09-30

- **Stream 1b** aus Rezept B über Core v0.12 exportiert. Nachtastung auf ds 0,5, am p1a-Export validiert (Geometrie 0 m, Indizes round(s/ds)). Dazu `p1b.export.json` (Checks, Pads, Tunnel).
- **Tunnel-Looks** (stone_arch, stone_rect, race_tube, mine) je vom Core kompiliert → `tunnelLooks` im Stream. Fingerprint unverändert.
- **TC1 Knet-Tunnel** `lab-track/tunnel-clay.tc1.js`: modulare Röhre, Stöße, Knethügel/freie Röhre, 4 Portal-Bausätze, Lampen, eigener Einbaufreiheits-Check.
  - r1 → r2: Hügel an den Portalen niedrig, Mitte zwei Kuppen · Tris halbiert (Schritt 2 m, schlankere Profile, RoundedBox-Segmente 1) · Mine-Laternen aus dem Fahrzeugraum (−0,12 → 0,40 m)
  - r3: Wand nur nach außen verformt (Mine-Innenwand 0,02 → 0,40 m)
  - r4: Modulfuge geschlossen (sichtbar in `tc1-chase.v1`)
- **J15** Host: J14 + Stream 1b + TC1 + Tunnel-Schalter + Tweak `tunnelLook` + Statuszeile Tunnel.
- **Belege:** `j15-round-gate.p1b.json`, `j15-cam-probe.json`, `tc1-looks.v1–v3`, `tc1-chase.v1–v2`, Einzelbilder `lab-track/evidence/tc1/`.
- **Neue Seite** `KFB Joyride TC1 · Tunnel-Looks.dc.html`.

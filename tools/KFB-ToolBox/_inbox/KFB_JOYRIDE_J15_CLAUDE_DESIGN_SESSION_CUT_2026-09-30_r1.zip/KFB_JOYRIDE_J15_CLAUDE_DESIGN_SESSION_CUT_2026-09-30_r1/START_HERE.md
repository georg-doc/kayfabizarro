# START_HERE · KFB Joyride J15 · Parcours 1b + Knet-Tunnel TC1 · Session Cut 2026-09-30 r1

**Status:** DESIGN PROOF · CANDIDATE. Kein GitHub-Push, kein Cloudflare, keine Stage, keine Änderung an einem Owner.

## Entry Points
- `KFB Joyride J15 · Parcours 1b.dc.html`: fahrbar, Haupt-Entry. Braucht `support.js` im selben Ordner.
- `KFB Joyride TC1 · Tunnel-Looks.dc.html`: die vier Tunnel-Looks als Bildseite mit Kenndaten, ohne 3D.
- `KFB Joyride P1 · Parcours-Plan.dc.html`: Bauteil-Inventar und Draufsicht der Varianten 1a/1b/1c, live vom Core kompiliert.

## Vor dem ersten Start: zwei Dateien zusammensetzen (ZIP-Grenze 2 MB)
```sh
cat lab-track/data/p1b.stream.json.part0* > lab-track/data/p1b.stream.json
cat ref/clay-joebinns/Fingerprints01_3K.png.part0* > ref/clay-joebinns/Fingerprints01_3K.png
shasum -a 256 lab-track/data/p1b.stream.json ref/clay-joebinns/Fingerprints01_3K.png
# erwartet a89e260bbc8645ab1bf1f8b4cee4b05e392e3253ffae2f1499977c17253aec4f
#     und  4f5ada12ccddcd62e8b660b254eec9614b50ff1376ebc579ad693db9e66b94cf
```
Windows: `copy /b lab-track\data\p1b.stream.json.part01+…part06 lab-track\data\p1b.stream.json`.
Der Stream ist Pflicht. Die Fingerabdruck-Textur ist optional (der Code hat einen Rückfall).

## Starten
Den Ordner über einen lokalen Webserver ausliefern (ES-Module, fetch): `npx serve .` oder `python3 -m http.server`, dann J15 öffnen. Der Aufbau dauert 40–60 s.
Online nötig: unpkg (three 0.160, React), Google Fonts, jsDelivr/raw.githubusercontent (KayKit-Figuren, Clips, Autos, Radio). Details in `SOURCE.json`.

## Bedienung
- **Auto:** W/S Gas/Bremse · A/D lenken · Q/E Drift · Shift Boost · Leertaste unter 0,5 m/s Aussteigen, darüber Hüpfen · R zurück · C Kamera
- **Zu Fuß:** wie J14
- **Burger-Menü:** Tunnel · Stein-Bogen / Stein-Rechteck / Race-Tube / Minen-Stollen (bleibt über Neuladen erhalten) · Runde automatisch · Proben A/B/C · Figur · Physik K2B/K2
- **Tweak:** `tunnelLook`

## Lesereihenfolge
`HANDOVER.md` (für WSA) → `CURRENT_STATE.md` → `TEST_REPORT.md` → `RETURN.md` → `evidence/`. Für einen frischen Chat: `NEXT_CHAT.md`.

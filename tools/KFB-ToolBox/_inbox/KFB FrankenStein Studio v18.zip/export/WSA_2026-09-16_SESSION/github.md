# Quelle der 3D-Modelle

repo: georg-doc/kayfabizarro
branch: main
path: media/3D_Assets

**Nichts aus diesem Repo wird kopiert** — alle Modelle werden zur Laufzeit als Fernspender geladen
(`raw.githubusercontent.com/…/main/media/3D_Assets/…`). Das Projekt hält nur Code.

**⚠ Drei Messregeln zu diesem Repo:**
- Der Verzeichnisbaum über die GitHub-Werkzeuge **zeigt `.glb` nicht an** (0 von 1202 Treffern für
  `.glb` im ganzen Ordner `3D_Assets`, obwohl das Projekt dutzende davon lädt). Wer sich auf den Baum
  verlässt, hält gefüllte Ordner für leer.
- **Dasselbe gilt für `.gltf`** (15.09. bezahlt): der Baum meldete für
  `tools/KFB-ToolBox/kfb-rigs-embed-v3/` **32 Dateien** und verbarg
  `petstudio-v9/assets/models/FrizzleBob_Yellow.gltf` — die Datei liegt dort (608 342 B, direkt
  gelesen). Wer dem Baum glaubt, führt eine vorhandene Datei als »fehlt«. **Direkt lesen entscheidet.**
- `media/3D_Assets/CATALOG/` ist von Juli 2026 und kennt die neueren Uploads nicht.
  Verlässlicher: `frankenstein-v1/data/kfb-asset-library.json` (Georgs eigener Baum-Export) — und
  auch der ist nur so frisch wie sein Datum.

## Last sync

date: 2026-09-15T21:00:34Z
commit: 891eadf01e218f5fc21387e64cea1fec8332c5b6

**Der Hash kommt aus Georgs Asset-Paket**, nicht aus einer eigenen Abfrage: das Übergabe-JSON
`tools/KFB-ToolBox/_inbox/KFB Elisa B-Day Reference+Mockups/kfb-asset-handoff-animation-lab (2).json`
(`schema: kfb.asset-handoff.v1`, 129 576 B) nennt `sourceCommit` und je Datei einen `blobSha` plus
`rawPinned`. Geladen wurde zur Laufzeit über **`main`** (wie überall in diesem Projekt) — der Pin
ist damit der Stand, gegen den die Angaben des Pakets gelten, nicht der Stand, den die Blätter
laden. Die Zeitangabe ist der Lesezeitpunkt des Pakets.

### Updated in this project
- **Gelesen, nicht kopiert:** das Asset-Paket (Kandidaten für das Animation Lab, `selectionStatus:
  candidate-only` — die Eignung entscheidet ausdrücklich der Consumer, nicht der Librarian). Es
  führt die GothGirl-Reihe vollständig: `characters/GothGirl.glb` (323 724 B, `hasSkin`, 23
  Knochen, Skelett-Signatur `cbb89c54…`, Skin-Name **Rig_Medium**, 0 Clips) und die Requisiten
  `GothGirl_Microphone` · `_MicStand` · `_Stool` · `_Speaker` (je mit `.bin` + `gothgirl_texture.png`,
  `dependencyStatus: complete`).
- **Zur Laufzeit gemessen, nichts kopiert:**
  `media/3D_Assets/KayKit_Mystery_Series6/GothGirl/characters/GothGirl.glb` (6 Netze an EINEM
  Material `gothgirl`, Bildtafel 1024², Kopfnetz 1618 Dreiecke = **12 Inseln**; Mund AUFGEMALT) ·
  `media/3D_Assets/GLB_cube-pets/animal-cat.glb` (Würfel 1,25³, Höhe 1,710, gemalte Augen als zwei
  flache Tafeln bei x ±0,262 / y 0,708 / z 0,635, 8 Clips) ·
  `media/3D_Assets/KayKit_Mystery_Series6/GothGirl/assets/gltf/GothGirl_Stool.gltf` (0,6 × 0,8 × 0,6).
- **Neue Ladepfade im Projekt** (beide HTTP 200, über `main`): GothGirls Figur (Studio v18,
  Bewohnerin `gothgirl`) und `animal-cat.glb` ein zweites Mal für das eigene Cube-Pet `hihi`
  (dieselbe Datei, eigener Eintrag — »The Cat« bleibt unverändert).
- **Bewegungen** kommen für GothGirl unverändert aus `KayKit_Character_Animations_1.1/Animations/
  gltf/Rig_Medium/` (gemessen: 23 von 23 Zielknochen, 100 %, Ruhehaltung `Idle_A`).
- **Keine Schreibvorgänge im Repo.**

## Sync history

### Vorher (2026-09-15T00:10:00Z)
date: 2026-09-15T00:10:00Z
commit: 525288d67a9fdfd94caacf19e47b4ba333dc1ca2

**Erster echter Commit-Hash in dieser Datei** — er kam aus Georgs Masterplan-Addendum
(`skills/chat/masterplan/TOOLBOX_UX_TOWN_BIRTHDAY_2026-09-15.md`), nicht aus einem Baum-Hash.
Alles darunter ist gegen **diesen** Pin gemessen.

### Updated in this project
- **Identität der lokalen Baseline belegt:** `export/kfb-rigs-embed-v3/` ist der gepinnte Commit
  **plus genau zwei Austauschdateien**. Verfahren: Git-Blob-Hash je Datei nachgerechnet und gegen
  die Blob-Hashes des Pins gestellt — **30 von 32 bytegleich**, abweichend nur
  `EMBED_KFB_RIGS_v3.md` (12 516 → 17 791 B) und `lab-v6/carlrig-mount.v1.js` (5 716 → 9 780 B).
- **Im Repo nachzuziehen:** `kfb-rigs-embed-v3.manifest.json` und `REVIEW_ANTWORT_v3.1.md` liegen
  am Pin **nicht** vor; die beiden v3.1-Dateien sind noch nicht eingespielt.
- **Warnung zum v3-Manifest:** seine Byte-Angaben sind durchgehend kleiner als Pin und Datei
  (12 315 statt 12 516 · 9 731 statt 9 780 · 30 142 statt 30 150). **Kein Identitätsanker.**
- **Delta ermittelt:** **0** von 30 v3-Modulen ist seit dem Pin geändert; **52** Workspace-Dateien
  haben in v3 kein Gegenstück; **60** erreichbare Module, **0** fehlende Modul-Referenzen.
- **Gelesen, nicht kopiert:** `skills/chat/masterplan/TOOLBOX_UX_TOWN_BIRTHDAY_2026-09-15.md`
  (Richtung A vor B, gepinnte Baseline, Librarian **v1.5** statt der alten v4-Annahme, GothGirl statt
  eines erfundenen Ghost-Charakters) · `tools/KFB-ToolBox/` Wurzel (6 Dateien gelistet).
- **Keine Schreibvorgänge im Repo.** Abgabepaket liegt lokal:
  `export/WS0_TOOLBOX_SOURCE_REFRESH_2026-09-15/`.

## Sync history

### Vorher (2026-09-14T11:10:00Z)
date: 2026-09-14T11:10:00Z

**Kein Commit-Hash von uns** — das Review nennt `f6e1a57d2580e2d35bd842c042d4673671a1b7c4` als Stand
des hochgeladenen Bündels (Paketbaum `dbcf82ac76097167d7a8a7016d87d77f3aaf99aa`).

### Updated in this project
- **Bündel liegt im Repo:** `tools/KFB-ToolBox/kfb-rigs-embed-v3/` (Georg hochgeladen). Review dazu
  kam zurück; **drei Dateien sind im Repo zu tauschen** (v3.1): `lab-v6/carlrig-mount.v1.js`,
  `EMBED_KFB_RIGS_v3.md`, `kfb-rigs-embed-v3.manifest.json` — Stand liegt in
  `export/kfb-rigs-embed-v3/`, Begründung in `REVIEW_ANTWORT_v3.1.md`.
- **Fehler behoben (R1):** `PartRig.set()` wies die mitgegebenen Schlüssel `mod`/`original` ab, die
  gespeicherte Nasen-/Brauen-Kalibrierung kam nie an. Nachgemessen: jetzt `scale 1.34 / lift −0.02 /
  depth −0.066`, keine Abweisungen.
- **Gelesen, nicht kopiert:** `skills/EMBED_CUBE_PET_FULL_v2.2.md` als Vorlage für die Anleitung.
- **Gelesen (GLB-JSON direkt, Revision `b97b5ac5`):** die acht Rig_Medium-Packs unter
  `media/3D_Assets/KayKit_Character_Animations_1.1/Animations/gltf/` → Clip-Inventar
  `export/KAYKIT_CLIP_INVENTAR_MEDIUM_2026-09-14.md` (131 Clips, Slot-Drift je Clip).

## Sync history

### Vorher (2026-09-14T09:58:46Z)
date: 2026-09-14T09:58:46Z

**Kein Commit-Hash** — nur Datei-Lesungen über `main`, kein Baum-Hash erfragt.

### Updated in this project
- **Gelesen, nicht kopiert:** `skills/EMBED_CUBE_PET_FULL_v2.2.md` (Cube-Pet-Anleitung) als Vorlage —
  Nachfolger für die KayKit-Figuren liegt als `export/kfb-rigs-embed-v3/EMBED_KFB_RIGS_v3.md` im Projekt,
  Bündel daneben (30 Dateien, Georg lädt hoch, Zielpfad `tools/KFB-ToolBox/kfb-rigs-embed-v3/` vorgeschlagen).
- **Bäume gelistet:** `media/3D_Assets/kenney_blaster-kit_2.1`, `…/KayKit_FantasyWeaponsBits_1.0_FREE`
  für das Briefing Waffenklassen. Nichts kopiert.

## Sync history

### Vorher (2026-09-13T23:58:38Z)
date: 2026-09-13T23:58:38Z

**Kein Commit-Hash** — der Baum liefert einen TREE-Hash (`b959c6ad1060`).

### Updated in this project
- **Gelesen, nicht kopiert:** `tools/KFB-ToolBox/` (START_HERE · MASTERPLAN · TOOLBOX_MANIFEST). Der
  Masterplan nennt unter T1·3 genau diese Aufgabe (»bestehendes kfb.pets/1 importieren, realen Graft
  im Lab benutzen«) und START_HERE verbietet, was der erste Lab-Umweg getan hat (»nicht aus den
  Beschreibungen neu implementieren«). Das Manifest führt `kfb-pet-graft-driver (4).json` als WIP-
  Config — dieselbe Datei liegt jetzt als `fixtures/kfb-pet-graft-driver.v4.json` im Projekt.
- **Neuer Leser `frizzlegraft-v1/graft-mount.v1.js`:** lädt zur Laufzeit wie der Studio-Bewohner
  (`Driver.glb`, Carl-Spender `KayKit_Mystery_Series6/CapsuleCarl/gltf/player.gltf` für Braue/Nase,
  Waffe `Platformer Game Kit …/Character_Gun.gltf` gepinnt auf `11d7df97…`). Keine neuen Pfade.
- **Animation Lab v2** baut den Graft aus dem Vertrag (Datei oder Studio-Sitzung). Abnahme: gleiche
  Zahlen wie das Studio (Haut 272 · Kleidung 1950 · 50 Manschetten zurück · Handton #f6c19d).

## Sync history

### Vorher (2026-09-13T04:50:28Z)
date: 2026-09-13T04:50:28Z

**Kein Commit-Hash** — der Verzeichnisbaum liefert weiter nur einen TREE-Hash (`f5bbd8b37ab3`).

### Updated in this project
- **Kartenmotiv KOPIERT, nicht verlinkt:** `media/kfb/KayfaBizarro_Card_Backside_01_lowrez.png`
  (800 × 447) liegt jetzt als `frizzlegraft-v1/kfb-card-backside.png` im Projekt und trägt die
  Ober- und Unterseite der Travel-Referenzkarte. Ein Blatt, das aus dem Netz nachlädt, ist beim
  nächsten Ausfall ein leeres Blatt.
- **Gesucht und gefunden im Repo:** das Motiv liegt dreifach (`media/kfb/…_01.png` in voller Größe,
  `…_lowrez.png`, und identisch als `overworld/overworld/card-backside.png`). Genommen wurde die
  kleine Fassung — 257 kB statt 1,05 MB, für eine 3 × 1,68 große Fläche mehr als genug.
- Alles andere dieser Sitzung (Armlöser, Kartengröße, Mitkippen der Figur) betrifft nur Projektdateien.

### Vorher (2026-09-13T02:39:03Z)
date: 2026-09-13T02:39:03Z

**Kein Commit-Hash** — der Verzeichnisbaum liefert weiter nur einen TREE-Hash. Angefaßt wurden in
dieser Sitzung zwei Repos: `georg-doc/kayfabizarro` (gemessen) und `georg-doc/KFB-Stunt-Car-Race`
(gelesen, `_inbox/Config_JSONs`, Tree `53e929f24f68`) — dort steht das Format, das der Voll-Export
des Studios treffen muß (`$schema: kfb.pets/1`, `pets[]`; `kfb-pet-graft-driver (1).json` ist der
Stand des Graft-Drivers).

### Updated in this project
- **Neues Blatt `KFB FrankenStein Studio v16.dc.html`** (Quelle in `petstudio-v9/`, Wurzelkopie
  erzeugt) mit Materialzonen, ovalen Augen und Surfpose. Keine neuen Ladepfade.
- **Gemessen an `driver_texture.png`** (`KayKit_Mystery_Series6/2 - August 2023 - Driver/textures/`,
  HTTP 200, 1024 × 1024): die Datei ist ein **Farbfeld-Atlas**, Raster **8 × 4** aus den Bildkanten
  gemessen. 3361 verschiedene Farben, die größten Gruppen sind Verläufe, keine gemalten Kleidungsstücke.
- **Gemessen an `Driver.glb`** (196 408 Byte, ein Material `driver_texture`, sieben Netze): welches
  Netz welches Atlasfeld benutzt — Jacke r1c1 (992 Dreiecke) · Hose r1c7 (376) · Schuh r2c3/r2c4 ·
  Shirt r3c5 · Rückenfeld r3c6/r3c7 (dort liegt das große GO GO GO) · Haut r0c0 · Brille r2c6.
  **Das ist die Trennlinie, die Mesh- und Materialnamen nicht liefern können.**
- **Vertragsformat geprüft** an `_inbox/Config_JSONs/kfb-pet-graft-driver (1).json`: die neuen Felder
  `graft.mat`, `eye.oval`, `pose.stagger` sind Blattfelder unter `pets[]` und brauchen keinen neuen
  Weg — 81 → 89 Blattfelder, Rundlauf verlustfrei.


### Vorher (2026-09-12T18:10:00Z)
date: 2026-09-12T18:10:00Z

**Kein Commit-Hash** — der Verzeichnisbaum liefert einen TREE-Hash (`b97b5ac55df2`), keinen Commit;
ein geratener wäre schlimmer als keiner. Ein echter Unterschied seit dem letzten Stand ist deshalb
nicht abgrenzbar. Statt zu raten wurde geprüft, was das Projekt wirklich anfaßt: **28 Ladepfade,
alle HTTP 200** (fünf Wirtsfiguren · acht Animationssätze `Rig_Medium_*` · Badewanne · Orc-Bildtafel
· Sockel · zwei Panels · zwei Knöpfe · drei Rover · vier Mechs). Kein Pfad ist upstream weggewandert,
kein Blatt mußte neu gebaut werden.

### Updated in this project
- **`KFB Mech & Vehicle Rig v2.dc.html`** mit drei Reitern. Neue Ladepfade, alle geprüft:
  `SciFI_Ultimate Space Kit_Quaternius/Vehicles/GLTF/Rover_Round.gltf` ·
  `Bubbly_Bathroom_Tiny_Treats_1-1/Assets/gltf/bath.gltf` ·
  `kenney_car-kit/Models/GLB format/wheel-racing|default|dark.glb` ·
  `Frankensteining/Space engine by Poly by Google - 4w-3qcynW5d.glb` ·
  `Textures/rusty_metal_04|PaintedMetal017|Concrete024|Chainmail004/<Name>_diffuse|normal|roughness.jpg`.
- **Gemessen am Rover_Round:** Wanne 3,95 × 3,46 (y 0,28–5,17) · Antenne bis 5,168 · **Dachfläche
  3,563** (25 Strahlen, Median). Schüssel und Mast werden geschnitten, der Schnittrand mit einer
  gemessenen Deckelscheibe (r 0,634) geschlossen.
- **Gemessen an bath.gltf:** 2,000 × 1,608 × 3,000 · Innenboden 1,116 · **Wasserlinie 1,316** ·
  Rand 1,978 · innen 1,839 × 1,333.
- **Textur-Regel für dieses Repo:** die Kenney- und Quaternius-Netze haben **Atlas-UV** — eine
  Kacheltextur aus `Textures/` braucht eine **Box-Projektion**, sonst gibt sie pro Fläche nur einen
  Farbwert.
- **Neues Blatt `KFB Mech & Vehicle Rig v2.dc.html`** mit zweitem Reiter »Rover«: `SciFI_Ultimate
  Space Kit_Quaternius/Vehicles/GLTF/Rover_Round.gltf` als Träger (HTTP 200, erster echter Ladepfad
  für die Rover-Reihe). Gemessen: Wanne 3,95 × 3,46, Antenne bis 5,168, **Dachfläche 3,563**.
- **Neues Blatt `KFB Mech & Vehicle Rig v1.dc.html`:** Oberkörper ohne Hüfte (Geometrieschnitt an der
  gemessenen Hüftlinie), auf `button-floor-round.glb` als Sockel, mit Cockpit aus Knüppel, zwei
  Kenney-Knöpfen und einem Factory-Panel — **alles von Hand einstellbar**, die Messung bleibt nur als
  Rückmeldung (Durchdringung, Überstand, Handtiefe).
- **Arm-Posing mit gelöster Haltung:** die Ruhelage kommt aus den inversen Bindmatrizen des Skeletts,
  nicht aus dem laufenden Clip; Winkel werden gesucht statt geraten (`_solveHand`). Gemessen: rechte
  Hand 0,020 an der Knüppelkugel (Radius 0,098), linke 0,223 auf der Knopffläche (0,305).
- **Konfiguration raus und rein** (Copy config · Datei ↓ ↑ · Text), Rundlauf verlustfrei; die Ablage
  ist im Vorschaufenster gesperrt (NotAllowedError), deshalb fällt ersatzweise eine Datei heraus.
- **Farbübernahme aus dem Studio:** `look.v1.js` liest denselben Eintrag (Sitzungsentwurf, sonst
  Repo-Vertrag) und legt Kopfzonen, Rollenfarben und Augenfarbe auf den Graft.
- **Badewanne von Hand skaliert** (zwei Regler, Modellform bleibt) statt dreier hergeleiteter Maßstäbe.

### Vorher (12.09., 02:20)
- Blatt v14 → `KFB FrankenStein Studio v15.dc.html`; Import/Export 94 Felder verlustfrei, Voll-Export
  29 Einträge; `pet.seat = { profile, widthK }` neu im Vertrag.

### 2026-09-11T15:01:31Z
- Gemessen: alle geprüften Figuren binden **100 %** der Animationsspuren; dem Mannequin fehlen nur
  die beiden Sockel `handslotl`/`handslotr` für Gegenstände.
- Elf ältere Charaktere werden per **Pfadprobe** gesucht (bis zu 42 Orte je Figur), weil ihre
  Dateinamen aus dem Baum nicht ablesbar sind. Werewolf: kein Treffer — Dateiname unbekannt.

## Screen map

| Blatt | lädt aus |
|---|---|
| `KFB FrankenStein Studio v18.dc.html` · Bewohnerin **GothGirl** | `KayKit_Mystery_Series6/GothGirl/characters/GothGirl.glb` (eigener Kopf, Augen aus dem Index, Mund übermalt) · `KayKit_Character_Animations_1.1/…/Rig_Medium/` (Clips) · Module `frizzlegraft-v1/goth-biped.v1.js` → `graft-biped.v1` · `facehost.v1` · `lab-v6/texclean.js` |
| `KFB FrankenStein Studio v18.dc.html` · Cube-Pet **Hihi** | `GLB_cube-pets/animal-cat.glb` (über das neue Eintragsfeld `modelId`) |
| `KFB FrankenStein Studio v18.dc.html` · Brauen | lädt nichts — `lab-v6/browfit.v1.js` + `inkform.v2.js` erben von `petstudio-v9/studio-v12/brow-rig.v2.js` und `lab-v6/facegraft.v1.js` |
| `KFB FrizzleDummy Lab v1.dc.html` | `KayKit_Character_Animations_1.1/` (Mannequins + 8 Animationspakete) · `KayKit_Mystery_Series6/` · `KayKit_Adventurers_2.0_FREE/Characters/gltf/` · `KayKit_Skeletons/characters/gltf/` |
| `petstudio-v9/KFB FrankenStein Studio v15.dc.html` · Reiter **Anim** | `KayKit_Character_Animations_1.1/Animations/gltf/Rig_Medium/Rig_Medium_*.glb` (acht Dateien) |
| `KFB Rigging Lab v1.dc.html` | `lab-v6/` · `lab-v4/carlrig.js` · `lab-v2/{audit,sources}.js` · `frizzlegraft-v1/{matzones,actor-color}.v1.js` · `petstudio-v9/studio-v12/{pet-eye-rig.v6,pet-nose.v2}` · `studio-v3/pet-mouth.v1.js` · `_ds/doccheck…` · Spender `KayKit_Mystery_Series6/CapsuleCarl/gltf/player.gltf` |
| `KFB Recherchi Lab v1.dc.html` · Studio v17 (4. Bewohner) | `frizzlegraft-v1/recherchi-mount.v1.js` → `lab-v4/carlrig.js` |
| `export/WS0_TOOLBOX_SOURCE_REFRESH_2026-09-15/src/` (Abgabe A) | dieselben Ladewege, Originalstruktur; Kaltstart gemessen — Rigging und Animation Lab 0 Ausfälle, Studio 3 (identisch zur Quelle) |
| `frizzlegraft-v1/anim-audit.v1.js` | dieselben acht Dateien — zählt, spielt nicht |
| `frizzlegraft-v1/graft-biped.v1.js` | `KayKit_Mystery_Series6/…/Driver.glb` + `Mannequin_Medium.glb` |
| `frizzlegraft-v1/graft-mount.v1.js` · `KFB Animation Lab v2.dc.html` (Gruppe »Studio · kfb.pets/1«) | über `graft-biped.v1` die Wirte · `KayKit_Mystery_Series6/CapsuleCarl/gltf/player.gltf` (Carls Braue/Nase) · `Platformer Game Kit - Dec 2021/Character/glTF/Character_Gun.gltf` (Waffe, gepinnt) · `Textures/FrizzelBob-Mouth_01/` (Mund) |
| `frizzlegraft-v1/facehost.v1.js` | nichts — misst die geladene Figur |
| `KFB Mech & Vehicle Rig v2.dc.html` | wie v1 · zusätzlich `SciFI_Ultimate Space Kit_Quaternius/Vehicles/GLTF/Rover_Round.gltf` · `Bubbly_Bathroom_Tiny_Treats_1-1/Assets/gltf/bath.gltf` · `kenney_car-kit/Models/GLB format/wheel-*.glb` · `Frankensteining/Space engine …glb` · `Textures/<Satz>/…` |
| `KFB Mech & Vehicle Rig v1.dc.html` | `KayKit_Mystery_Series6/` (Driver · Clown · Orc Raider) · `KayKit_Character_Animations_1.1/Mannequin Character/` · `kenney_factory-kit_3.0/Models/GLB format/` (Sockel + zwei Panels) · `kenney_platformer-kit/Models/GLB format/` (zwei Knöpfe) |
| `frizzlegraft-v1/torsobase.v1.js` · `look.v1.js` | Sockel `button-floor-round.glb` · `look` lädt nichts, liest den Eintrag |
| `frizzlegraft-v1/seat-lab.v1.js` | `Bubbly_Bathroom_Tiny_Treats_1-1/Assets/gltf/bath.gltf` |
| noch ungenutzt, geprüft | `SciFI_Ultimate Space Kit_Quaternius/Vehicles/GLTF/` (3 Rover) · `Characters/GLTF/` (4 Mechs, je EIN Netz → Kopf muß geschnitten werden) |
| `frankenstein-v1/race/` | gepinnte Fassung `15e36b91…` (eigener Ladeweg, hiervon unberührt) |

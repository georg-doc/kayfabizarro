# Projekt-Kontext (immer lesen)

## Was hier gebaut wird
**KayfaBizarro (KFB)** von Georg von Westphalen — Cut & Play Comics: Comic drucken, in Karten
zerschneiden, gemeinsam laut eine Geschichte bauen. 1–6 Menschen, niemand gewinnt.
Regeln: kayfabizarro.pages.dev (#kfb Freestyle, #med MedKayfab). Lizenz der Decks CC BY-NC-SA 4.0.

Die 3D-Sachen hier sind **Meta-Narrativ zum Spiel**, keine Techdemos:
- `KFB Travel v9.dc.html` + `terrain-v9/` — **aktueller Stand**, Aufräum-Fork von v8: die
  Verdrahtung verlässt `travel-poc.js` (A CameraRig → B Modus-Eigentum → C Panel-als-Daten +
  TravelManager → D Ereignisse an einem Ort), jede Stufe mit Abnahmezahl. Auftrag:
  `docs/INTERMISSION_reviews_v8.md`, Handover: `docs/HANDOVER_v9.md`.
- `KFB Travel v8 - Academy Flow.dc.html` + `terrain-v8/` — **eingefroren, Vergleichsmaßstab**. Reise über eine
  Voxel-Welt auf einer fliegenden Karte; Auto-Pilot (Doppelklick = Anflug, Zielzeit als Regler) und
  die Würfelakademie als Ort: 31 Lektionskarten in fünf Farbzonen, Live-Demo per Render-to-Texture
  direkt auf dem Blatt.
- `KFB Travel v7.dc.html` + `terrain-v7/` — Vorgänger, lauffähig. Sky-Karten als Flugziele, Klang.
- `rollercoaster-v11/` — Vorgänger, **eingefroren**. Quelle für portierbare Systeme (Audio, Portal,
  Curtain, Pet, Decks).

## Kontextdokumente (vor Konzeptarbeit lesen)
- `docs/KFB_CONTEXT.md` — Spiel- und Meta-Narrativ, Vision für Travel, Ideensammlung. **Living Doc.**
- `docs/SPRINT_travel-v9.md` — Slices v9 (S40–S46), **eingecheckt**; Architektur-Plan A–D fertig.
- `docs/HANDOVER_v10_coworker.md` — Stand v9, Bewertung der TinySkies-Transfers und die **vier
  Konzept-Entscheidungen**, die vor v10 fallen müssen.
- `docs/SESSION_EXPORT_v9_runtime.md` — was in v9 gilt, mit allen Messzahlen und den zwölf
  Fehlerklassen.
- `docs/INTERMISSION_tinyskies.md` — erste Bewertung der beiden TinySkies-Transfer-Dokumente.
- `docs/INTERMISSION_reviews_v8.md` — **verbindliche Auslegung** der fünf externen Code-Audits aus
  `_handoff/`: Konsens, gemessener Ist-Stand, was gestrichen ist, Plan v9 — plus die Liste
  **Fehlerklassen v8** (Faktoren statt Schalter · jeder Auftrag braucht einen Rückweg · gemessen wird
  beim Spieler · SSOT-Module haben Familien · Kapazität für die Überlappung · eine Zahl, ein Ort).
- `docs/SPRINT_travel-v7.md` — Grundrisse und Status der Vorversion.
- `docs/CHANGELOG_travel.md` — was wann warum, mit gemessenen Zahlen.
- `docs/SFX_elevenlabs_prompts.md` — Prompt-Sammlung für Sound-Einsätze.

## Namen, die stimmen müssen
**Uncle FrizzleBob** (der Hase) · **King Kayfabian** (rotierender Richter) · **Kayfabulation** /
kayfabulieren · **BLÖDSINN!** (immer so geschrieben) · Story-Modi englisch: Tragic · Comic · Absurd ·
Heroic · Mystical · Forbidden · Grußformel **Stay fluffy.**
**Karten sind keine Powers, sie sind Beweisstücke** — also nie Zahlenwerte, Trefferpunkte oder
Punktestände im UI.

## Arbeitsweise, die sich hier bewährt hat
- **Ein Slice pro Runde**, klein genug, dass am Ende ein vorzeigbarer Stand steht.
- **Messen statt behaupten:** jede Änderung mit einer Zahl belegen (Uniform, Zähler, Pegel) und die
  Zahl in den Changelog schreiben.
- **Über den echten Bedienweg testen**, nicht über die API — ein Slice kann über `start()` grün und
  über den Schalter tot sein (S20).
- **Auf „läuft" gaten, nie auf „existiert"** — sonst verwirft man den funktionierenden Fallback.
- **Versionsnummern gehören dem Runner**, nicht einem Modul — ein Modul, das seine eigene Version
  kennt, lügt beim nächsten Fork.
- Antworten auf Deutsch, Code-Kommentare auf Deutsch, Fachbegriffe englisch.

# HOUSEKEEPING — Georg's Infinite Canvas (Rollercoaster Ride)

**Living-Status je Artefakt.** Stand: 2026-07-23 (Session Terrain+Skydome v1-Cut).
Status: `AKTIV` · `FROZEN` · `SUPERSEDED` · `DEAD` · `ASSET` · `SHARED` (von mehreren importiert)

## KFB Travel v9 · Runtime (Session 2026-07-25) — **aktueller Stand**

Aufräum-Fork von v8: die Verdrahtung hat `travel-poc.js` verlassen (A CameraRig · B Modus-Eigentum ·
C TravelManager/Panel/Eingabe/Bühne · D Ereignis-Tabelle), dazu Zonen-Stern, Warp, Rückwärtsgang,
Standdrehung und der lesbare Kartentitel. Auftrag: `docs/INTERMISSION_reviews_v8.md` ·
Entscheidungen für v10: `docs/DECISIONS_v10.md`.

| Datei | Status | Notiz |
|---|---|---|
| `KFB Travel v9.dc.html` | **AKTIV** | Entry (importiert `terrain-v9/travel-poc.js`) |
| `terrain-v9/` (43 Dateien, 521 KB) | **AKTIV** | Runner 1050 Z; kein Modul über 2 MB |
| `terrain-v9/camera-rig.js` | **AKTIV (neu)** | **die einzige Stelle, die die Hauptkamera schreibt** |
| `terrain-v9/mode-owner.js` | **AKTIV (neu)** | `requestMode(mode, reason)`, vier benannte Regeln, `assertController` |
| `terrain-v9/travel-manager.js` | **AKTIV (neu)** | Pipeline als getaktete Liste, Fehler-Isolation je Schritt |
| `terrain-v9/travel-input.js` | **AKTIV (neu)** | Tasten/Zeiger/Rad/Doppelklick/Resize |
| `terrain-v9/travel-stage.js` | **AKTIV (neu)** | Renderer, Szene, Licht, Nebel, Gelände-Sonden |
| `terrain-v9/travel-events.js` | **AKTIV (neu)** | 8 Anmeldungen in einer Tabelle, **kein Bus** (0 Duplikate) |
| `terrain-v9/settings-schema.js` | **AKTIV (neu)** | Panel als Daten (~290 Z aus dem Runner) |
| `terrain-v9/card-title.js` | **AKTIV (neu)** | Kartentitel: Irish Grover extrudiert, Band einmal reserviert, `fonts.ready`-Hook |
| `terrain-v9/voxel-glyphs.js` | **AKTIV, aus** | Vorgänger des Titels; Regler „(alt)", Port bleibt erhalten |
| `terrain-v9/edge3.jpg` | **ASSET · SHARED** | Kanten-Textur für Terrain **und** Glyphen (60 KB) |
| `terrain-v9/kfb-index.json`, `jukebox.json`, `sfx.json` | **AKTIV** | lokale Fallbacks (RAW-first); in dieser Session **unverändert** |
| `KFB Travel v8 - Academy Flow.dc.html` + `terrain-v8/` | **FROZEN** | Vergleichsmaßstab, lauffähig |
| `KFB Travel v7.dc.html` + `terrain-v7/` | SUPERSEDED | Vorgänger |
| `terrain-v2/voxel-glyphs.js` | SUPERSEDED, **Quelle** | WebGPU/TSL-Original des Glyph-Ports — **nicht als tot einstufen** |
| `rollercoaster-v11/` | **FROZEN · SHARED** | Quelle der Karten-Tusche (`ink-tail.js`) und des Pet-Facings |
| `docs/DECISIONS_v10.md` | **AKTIV (Doku, neu)** | vier Konzeptfragen, stand-alone lesbar |
| `docs/HANDOVER_v10_coworker.md` | **AKTIV (Doku, neu)** | Stand v9 + TinySkies-Bewertung |
| `docs/SESSION_EXPORT_v9_runtime.md` | **AKTIV (Doku, neu)** | was gilt, alle Messzahlen, 13 Fehlerklassen |
| `docs/INTERMISSION_tinyskies.md` | **AKTIV (Doku, neu)** | Bewertung der beiden Transfer-Dokumente |
| `_handoff/tinyskies_kfb_transfer_notes_v1.md`, `_handoff/KFB_TinySkies_Transfer_v8.md` | **ASSET (Quelle)** | unverändert aus dem Repo |
| `skills/session-export_v1.md` | **AKTIV (neu)** | Export-Regeln (kein Voll-Zip) |
| `skills/SSOT_Card_Ink_Outline.md` | **AKTIV (Doku)** | ⚠-Korrektur: zwei Tusche-Familien |

**Clean-Run v9 (geprüft):** keine Konsolenfehler · 31 Karten, 29/31 Vorschaubilder · Pipeline
`attach→fade→vehicle→world→render`, `broken: []` · genau **1** Kamera-Schreiber · **0** Allokationen im
Frame-Pfad · Panel 98 Bedienelemente, 0 × NaN / 0 × undefined · Versionsstring nur im Runner
(16 Module bereinigt) · Bedienwege F · X · Q/E · S · ⇧+Leertaste · Rad · Doppelklick · Tab.

**Aufräum-Kandidaten (nur benannt, nichts ausgeführt):** `uploads/` (verarbeitete Feedback-Screenshots
— Inhalte sind in Changelog-Zahlen überführt) · `docs/captures/v6-*.png` (2 Dateien, 60 KB, belegen
einen SUPERSEDED-Stand) · `terrain-v1`…`terrain-v6` archivieren statt löschen (v2 ist Quelle) ·
`particle-test/`, `KFB-Particle-Package/`, `v6/`, `scraps/` erst prüfen, ob referenziert.
`docs/captures/v8-*.png` (8 Dateien, 285 KB) **behalten**, bis v9 eigene Abnahme-Captures hat.

**Pfad-Hygiene:** vier relative Asset-Pfade im v9-Code, alle vier korrekt — `./kfb-index.json`,
`./jukebox.json`, `./sfx.json` sind die **Fallbacks** hinter RAW-first, und `./edge3.jpg` liegt im
Modulordner und ist Teil des Exports. Kein Asset über 2 MB; Decks, Musik und Pet-Stack laden zur
Laufzeit per RAW-URL.

**Contract-Hygiene:** keine geteilte Contract-Datei verändert → kein `version`-Patch nötig.

## KFB Terrain + Skydome v1 (Session 2026-07-23)
Deterministische Welt-Generierung aus Karten-Triplets (kein LLM): Karten → semantischer Vektor → Terrain- & Sky-Params. Isolierter WebGPU-Runner. **Verifikations-Limit:** WebGPU rendert im Design-Tool-iframe schwarz — Look wird auf Georgs Vorderansicht beurteilt.

| Datei | Status | Notiz |
|---|---|---|
| `KFB Terrain + Skydome v1.dc.html` | **AKTIV** | Entry (importiert `terrain-v1/terrain-poc.js`) |
| `terrain-v1/terrain-poc.js` | **AKTIV** | Runner: Flugkamera (folgt Terrain-Höhe), Bloom-Pipeline (thr 1.15), Tweak-Panel + **Panel-Toggle** (✕/☰ oben rechts), Sky-Picker, Audio-Wiring |
| `terrain-v1/voxel-terrain.js` | **AKTIV** | Instanced-Box-Terrain: edge3-PBR-Material (RoomEnvironment-IBL, 1:1 webgl_instancing_dynamic), Pro-Würfel-Farb-Jitter, **GPU-Vertex-Bob** (rigid, \|sin\|, an Energy+Beat), Chunk-Streaming (5×5-Pool), Scatter-Props (sanft energie-gekoppelt, kein Beat-Lurch) |
| `terrain-v1/fractal-skydome.js` | **AKTIV** | `FractalSkydome`-Klasse. Default **S** = Sphere-Shader (1:1 aus Ride v8). Weitere: A (Waber-Noise), B (Mandelbox), L (immersiv). **Hypno-Spiral-Overlay** (welt-verankert, dreht auf Beat/Speed). Farbe an Terrain-Palette gekoppelt (`setPalette`) |
| `terrain-v1/world-context.js` | **AKTIV** | Karten-Triplet → 8-dim Vektor → Params/Palette/Biome (deterministisch, seeded) |
| `terrain-v1/jukebox-audio.js` | **AKTIV (neu)** | Echte Musik → `{beat,energy}`. Beat = BPM-Uhr (Track-verankert), Energy = AnalyserNode (Bass), gated durch Bass-Pegel (Stille = Ruhe). Lädt `jukebox.json` RAW-first |
| `terrain-v1/decks/*.json` | **ASSET** | Karten-Korpus (embrace/forget/ignore) — Quelle für die Vektoren |
| `terrain-v1/edge3.jpg` | **ASSET** | Cubescape-Kachel (~2,5 KB), aus three.js examples |
| `docs/BACKLOG_fractal-skydome.md` | **AKTIV (Doku)** | Fraktal-Raymarch-Dome + Spiral-Feinschliff geparkt, mit Problemen + Lösungsvorschlägen |

**Offen (nächste Runde):** Karten→Vektor-Mapping ist erste Proposal (retunebar); Scatter = Platzhalter-Boxen (Kenney-Assets folgen, gleicher Instanced-Pfad); Fraktal-Dome + Spiral-Optimierung im Backlog; Place/Deck-Ausbau später.

## KFB Travel v5 (Session 2026-07-24, angelegt)
Fork des v4-Session-Cuts. **v4 ist ab hier FROZEN** — Weiterbau nur in `terrain-v5/`.
Sprintplan und Status: **`docs/SPRINT_travel-v5.md`** · Verlauf: **`docs/CHANGELOG_travel.md`**.

| Datei | Status | Notiz |
|---|---|---|
| `KFB Travel v5.dc.html` | **AKTIV** | Entry (importiert `terrain-v5/travel-poc.js`) |
| `terrain-v5/*.js` (9 Module) | **AKTIV** | 1:1 Fork des v4-Stands; `travel-poc.js` verweist im Kopf auf Sprintplan + Changelog |
| `terrain-v5/edge3.jpg` | **ASSET** | Fallback bis die Textur im Repo liegt |
| `docs/SPRINT_travel-v5.md` | **AKTIV (Doku)** | Sechs Slices (Regie-Skalar → Speedlines/Boost → Rim-Light → FX-Pool → Story-Presets → Modus-Tor), Arbeitsregeln für frische Chats, Backlog, verworfene Ideen |
| `docs/CHANGELOG_travel.md` | **AKTIV (Doku)** | additiver Verlauf, neueste Einträge oben |

**Nächster Schritt:** S1 `travelHeat` — Voraussetzung für S2–S4.

## KFB Travel v4 (Session 2026-07-24)
Flug **und** Boden in einer Welt: Karte trägt das Pet, `F` schaltet Fly ⇄ Walk. Diese Session: Achsen entdreht, Auto-Hop vorausschauend gemacht, Pet-Kinetik nach `cartoon-motion_v1` neu aufgesetzt, GLB-Clip-Layer verdrahtet, Pfad-Hygiene.

| Datei | Status | Notiz |
|---|---|---|
| `KFB Travel v4.dc.html` | **FROZEN** | Entry (importiert `terrain-v4/travel-poc.js`) — Weiterbau in v5 |
| `terrain-v4/travel-poc.js` | **AKTIV** | Runner: Fly/Walk-Switch, Kameras (Chase + POV), Terrain-Streaming, Beat-Drive. **Neu:** Pet-Stack per dynamischem Import kanonisch (jsdelivr) mit lokalem Spiegel als Fallback; `pet.update()` VOR der Kinetik (Reihenfolge war verdreht, PetMotion dämpfte den Lean weg); `motion.initParts()` für Ohren/Schweif-Federn |
| `terrain-v4/walk-controller.js` | **AKTIV** | Boden-Controller. **Neu:** `heading += turn` und `right = cross(forward, up)` (A/D + Q/E waren seitenverkehrt); Körper-Radius 0.55 in der Kollision; vorausschauender Auto-Hop mit `v = √(2g·(rise+clear))` und ~90 ms Windup; State liefert `crouch`, `impact`, `speed`, `walkRef/runRef` |
| `terrain-v4/pet-kinetics.js` | **AKTIV** | Pet-Reaktion für BEIDE Modi. **Neu:** gemeinsame Sprung-Grammatik (Anticipation → Launch → Apex-Hang → Fall → Land-Squash ∝ Aufprall → Rebound), volumenerhaltender Squash `Sxz = 1/√Sy`, GLB-Clip-Layer (idle/walk/run, `timeScale` an die echte Bodengeschwindigkeit, `static` in der Luft), `enterWalk()/leaveWalk()` |
| `terrain-v4/card-carrier.js` | **AKTIV** | CardRig. **Neu:** `assetBase` default = kanonische RAW-URL (`media/kfb/`) statt `./assets/` |
| `terrain-v4/voxel-terrain.js` | **AKTIV** | Instanced-Cube-Terrain. **Neu:** Kanten-Textur RAW-first mit lokalem Fallback — **Blocker:** kanonische URL existiert noch nicht (s. Upload-Kandidaten) |
| `terrain-v4/flight-controller.js` · `skydome-shader.js` · `world-context.js` | **AKTIV** | unverändert diese Session |
| `terrain-v4/kfb-pets.js` | **SPIEGEL / Fallback** | kanonisch = Repo `media/3D_Assets/kfb-pets.js`. Nur noch Fallback, nicht mehr primärer Import |
| `terrain-v4/dice-sky.js` · `jukebox-audio.js` · `terrain-poc.js` | **AKTIV (andere Deliverables)** | von Travel v4 NICHT importiert — nicht als tot einstufen |
| `terrain-v4/petflight.v2.js` | **SUPERSEDED (Referenz)** | Herkunft der Flug-Kinetik; nur noch Diff-Quelle |
| `terrain-v4/edge3.jpg` | **ASSET** | Cubescape-Kachel, aktuell einziger funktionierender Pfad → Upload-Kandidat |
| `terrain-v4/assets/KayfaBizarro_Card_Backside_01_lowrez.png` | **ASSET (obsolet)** | wird jetzt per RAW geladen; lokale Kopie (250 KB) kann nach Freigabe raus |
| `terrain-v4/decks/*.json` · `palettes.json` | **ASSET** | von `terrain-poc.js` genutzt, nicht von Travel |
| `KFB TinySkies Analyse.dc.html` | **AKTIV (Doku)** | Analyse-Report `dannylimanseta/tinyskies@2659a5cc` → 7 Übernahme-Bausteine + Sechs-Schritt-Reihenfolge für v5 |
| `github.md` | **AKTIV (Doku)** | Repo-Assoziation + Last-Sync-Beleg |

**Offen (Travel-Sprint):** 24-Pet-Auswahl · karten-getriebenes Terrain (`CardTriplet → setWorldContext`, Hook liegt, Seed noch fix) · reichere Karten-Kinetik · Anchor-/Landmark-Layer · echtes Audio statt Synth-Beat · Bundle-Matrix an Travel-Events (nach v5-Export mit Coworker abzustimmen).

## Deliverables (Ride)
| Datei | Status | Notiz |
|---|---|---|
| `Rollercoaster Ride v8.dc.html` | **FROZEN (Chrome-only)** | WebGPU-Referenz. Bootet nur in Chrome (FF-Boot-Bug, 2 three-Builds). Weiterbau NICHT hier → frisch auf WebGL (Kurskorrektur `LIVING_KFB_MED_UNIVERSE.md §4b`) |
| `rollercoaster-ride.v8.js` | **AKTIV** | Ride-Engine. 1:1 v7, **auf v7-Bloom-Niveau stabilisiert** (Global-Bloom lässt sich nicht in die Ride heben ohne Karte/Augen/Würfel zu verbrennen). COSMIC-Palette als Vorrat. **FROZEN (Chrome-only):** FF-WebGPU rendert `PointsNodeMaterial` nicht (Belege `particle-test/mrt-points-test.html`) → gesamte Partikel-Atmosphäre in FF unsichtbar. Kurskorrektur: WebGL-Neubau statt v8-Fix (`LIVING_KFB_MED_UNIVERSE.md §4b`). Doku `docs/HANDOVER_v8.md` |
| `Rollercoaster Ride v7.dc.html` | **FROZEN** | v7-Entry, unangetastet |
| `rollercoaster-ride.v7.js` | **FROZEN** | Ride-Engine. Sprint 1 (Jukebox). Sprint 4: `_beatFreq()`, Board-Querwölbung+Ripple, Surf-Banking, Idle-Float. **Sprint 3:** Arc-Length-Physik (`_arcCompAt`), „Reading Tour“-Slider (`this.magnet`, 0=aus), Beat-Aura (`_updateBeatFx`, auf Pet-BBox zentriert), Musik-Gain ×2.4. **Sprint 5.1:** Test-Hooks `window.__rideTest` (`seek/play/setMode/setSeed/snapshot`), `_applyMode`, FPS-EMA + `_snapshot`. **Sprint 5.2:** DEV-Perf-Readout im Dashboard (`?dev` → FPS/DRAWS/TRIS) |
| `pet-select.v7.js` | **AKTIV** | Pet-Auswahl-Screen. Sprint 4: gemeinsamer Float-Treiber (2.72 rad/s), sichtbarer Fokus-Float + Atem-Banking. Sprint 3 folgt hier |
| `assets/jukebox.json` | **AKTIV (lokaler Fallback)** | kanonisch = Repo `media/3D_Assets/Sounds/jukebox.json` — **gepusht, RAW 200, 9 Tracks**. `file` = voller Repo-Pfad (`RAW + file`), `loop`-Flag respektiert |
| `particle-test/KFB Particle Test v1.html` | **AKTIV (Tool)** | Selbst-emittierender Partikel-Tuning-Test (Standalone WebGPU, three@0.178.0). Live-Tweaks: Count/Size/HDR/Flow/Bloom×3/Palette. **Default = Georgs Lieblings-Config** (COSMIC, 38k, size 0.20, HDR 6, bloom 0.24/2.1/0.5). Look tunen → Werte in Ride portieren. Doku: `docs/HANDOVER_v7_particles.md` |
| `KFB Particle Academy.dc.html` | **AKTIV (Lern-Tool)** | Interaktiver Feynman-Kurs (basic→advanced), 10 Kapitel + Sandbox (iframe KFB Particle Test v1) + **Videothek** (4 Load-on-demand-YouTube-Embeds mit klickbaren Timestamps/Kapitel-Outline) + **Pet-Tutor-POC** (CSS-3D-Cube FrizzleBob: IntersectionObserver-Hints, Klick=Bloom-Level L0–L6 mit Ton-Anpassung) + Glossar. **Responsive** (≤900px Sidebar→Top-Nav). Maschinenlesbares Wissens-JSON (`id=kfb-particle-knowledge`) für externe LLMs. Interaktivität = Helmet-Script (Delegation + IO). KFB-Cosmic-Design |
| `PARTIKEL_MIT_YOUTUBE_Playlist_v1.md` | **AKTIV (Daten)** | Kuratierte YouTube-Registry (App-Format) zur Academy: 4 verifizierte Videos (SimonDev Particle-System + Noise, kishimisu Shader-Art, Blender Simulation-Nodes), Kapitel-Mapping + Beobachtungsauftrag/Feynman-Frage pro Segment |
| `particle-test/linkedparticles.html` | **WIP / geparkt** | 1:1-Port der three.js-Referenz. Lädt fehlerfrei, rendert nur BG (Compute-Spawn spawnt im Preview nicht). Ausgangspunkt für Port-Plan Schritt 2–3 |
| `particle-test/mrt-bloom-poc.html` | **AKTIV (POC/Tool)** | Selective/MRT-Bloom-Beweis (Standalone WebGPU 0.178): emissiver Würfel glüht, belichtetes Metall-Pet NICHT. Modi off/global/selektiv + `window.__poc.measure()` (Halo-Luminanz). Gemessen in Firefox-WebGPU: Ratio E/P 1693× (selektiv) vs 4.4× (global). Grundlage Sprint 7 |
| `KFB Bloom Academy.dc.html` | **AKTIV (Lern-Tool)** | Feynman-Kurs 3D-Bloom für den **Polygarden-Fork**. 9 Kapitel (Was ist Bloom → MRT/Selective) + Sandbox (iframe mrt-bloom-poc) + **Bloom-Kompetenz-Leiter L1–L6** + Bloom-Tutor-POC (Cube-Pet, Level-Cycle) + Glossar + Wissens-JSON (`id=kfb-bloom-knowledge`). Roter Faden = reale v8-Debug-Saga. Companion zur Particle Academy |
| `Rollercoaster Ride v6.dc.html` + `rollercoaster-ride.v6.js` + `pet-select.v6.js` | **FROZEN** | v6-Baseline, unangetastet |
| `Rollercoaster Ride v5.dc.html` | SUPERSEDED | v5-Referenz, unangetastet |
| `rollercoaster-ride.v5.js` / `pet-select.v5.js` | SUPERSEDED | Referenz für Diffs |
| `Rollercoaster Ride v1–v4.dc.html` + `rollercoaster-ride.v1–v4.js` | SUPERSEDED | Historie |
| `pet-select.v4.js` | SUPERSEDED | — |

## Geteilte Module (NICHT als tot einstufen)
| Datei | Status | Von wem importiert |
|---|---|---|
| `kfb-ink.js` (`rc-ink`, `window.KFBInk`) | **SHARED / AKTIV** | v6-Engine (`inkPerimeter`, `drawInkOutline`) |
| `frizzlebob-voice.v3.js` (`rc-voice`) | **SHARED / AKTIV** | v6-Engine |
| `pet-motion.v1.js` | **SHARED / AKTIV** | pet-select, infinite-journey |
| `pet-eye-rig.v3.js` | **SHARED / AKTIV** | pet-select / Ride-Rig |
| `pet-library.v6.js` | **SHARED / AKTIV** | Pet-Loader |

## Contract- / Daten-Dateien
| Datei | Status | Notiz |
|---|---|---|
| `assets/kfb-index.json` | **AKTIV (lokaler Fallback)** | kanonisch = Repo `media/kfb/index.json`; Sonic-Eintrag heute korrigiert → **muss ins Repo gepusht werden** |

## Docs
| Datei | Status |
|---|---|
| `docs/POSTMORTEM_v6_pet-board.md` | **AKTIV** — Known-Good-Stand + verworfene Fixes |
| `docs/HANDOVER_v6_3D-card.md` | **AKTIV** — 3D-Karten-Plan für v7+ |
| `docs/HANDOVER_v7_test-hooks.md` | **AKTIV** — DEV/QA Test-Hooks `window.__rideTest` (Sprint 5.1): API, Rezept, Impl-Notizen |
| `docs/HANDOVER_v7_particles.md` | **AKTIV** — Partikel-Immersion: Benchmark-Analyse (linkedparticles/attractors), KFB Particle Test v1, three.js-Port-Plan |
| `docs/HANDOVER_v8.md` | **AKTIV** — Partikel-Port Test v1 → Ride: Verlauf, warum Global-Bloom scheitert, Stand |
| `docs/SPRINT_KICKOFF_selective-bloom.md` | **AKTIV** — Sprint 7 (Emissive/MRT-Bloom) + Bewertung Audio-Terrain-Konzept + Sequencing |
| `docs/SPRINT_STATUS_v8_coworker.md` | **AKTIV** — Sprint-Abgleich für Coworker-Backlog (Status je Item) |
| `docs/CHANGELOG_rollercoaster.md` | **AKTIV** |
| `docs/HANDOVER_rollercoaster_v3.md` | SUPERSEDED |
| `uploads/HANDOVER_v5_*.md`, `uploads/POSTMORTEM_v5.md`, `uploads/HANDOVER_v6_kickoff*.md` | FROZEN — Session-Input |

## Clean-Run-Checkliste (v6)
1. `Rollercoaster Ride v6.dc.html` öffnen → Pet-Select bootet ohne Fehler.
2. Pet wählen → Ride bootet (`__rcRide2`), HUD-Leinwand aktiv, kein Zittern (Schirm-Jitter 0).
3. Blödsinn! → Start ohne 45°-Snap, Füße auf der Karte.
4. D6-Roll → Story-Mode-Licht wechselt in Cockpit UND auf der Schiene (gekoppelt).
5. Settings → Deck Library → A/B/C rendern inline; Sonic erst nach Repo-Push des Index.
6. **Standalone-Export:** SKY_URL/SKY_URL_B/DECKS-Pfade sind relativ (`./assets/…`) → Pfad-Hygiene (s. u.).

## Export-Procedere (Pflicht)
Jeder Session-Cut/Export folgt `docs/session-export.md` (Teil-Export statt Voll-Zip:
Manifest → Veto → Housekeeping → nur Manifest-Dateien, keine Datei > 2 MB, Schweres per RAW-URL).

## Offene Pfad-Hygiene (Fix-Kandidaten für Standalone)
- **Travel v4 ✅ erledigt (2026-07-24):** Pet-Stack kanonisch per jsdelivr (lokaler Spiegel = Fallback), Kartenrücken über `raw…/media/kfb/`, `assetBase`-Default umgestellt.
- **Travel v4 ⚠ offen:** `voxel-terrain.js` zeigt auf `raw…/media/3D_Assets/Textures/edge3.jpg` — **Datei liegt noch nicht im Repo**, aktuell greift der lokale Fallback. Nach dem Upload ist der Standalone-Export sauber.
- `terrain-poc.js` `DECKS[].file` = `./terrain-v3/decks/*.json` → Pfad zeigt auf einen Ordner, der neben `terrain-v4/` nicht existiert; auf RAW umstellen.
- `rollercoaster-ride.v6.js` Z.22/23 `SKY_URL`, `SKY_URL_B` = `./assets/skydome_*.webp` → auf RAW umstellen.
- `rollercoaster-ride.v6.js` Z.212–214 `DECKS[].file` = `./assets/decks/*.json` → auf RAW umstellen.
- `loadRegistry` lokaler Fallback `./assets/kfb-index.json` = ok (nur Fallback, RAW ist primär).

## v7+ Backlog & Sprint-Plan
**Quelle:** Review von 4 externen Skill-Repos (threejs-game-skills, CloudAI-X/threejs-skills, blender-expert, claudedesignskills). Ergebnis: Code nicht übernehmbar (alle Build-Step/DCC-first, unser DC ist single-file WebGPU/TSL). Übernommen werden **nur 3 Konzepte**, KISS, in unser Runtime portiert.

### Sprint 5 — Reproduzierbarkeit & Regressions-Sichtbarkeit
1. **Deterministische Test-Hooks** (aus threejs-game-skills; größter Realgewinn). ✅ **ERLEDIGT (Sprint 5.1):** `window.__rideTest = { seek, play, setMode, setSeed, snapshot }` — Doku `docs/HANDOVER_v7_test-hooks.md`.
2. **DEV-Perf-Readout** (Scorecard-Denke). ✅ **ERLEDIGT (Sprint 5.2):** `?dev` (oder `localStorage rc2-dev=1`) blendet im Dashboard-Grid drei grüne Zeilen ein — **FPS** (EMA), **DRAWS** (`renderer.info.render.drawCalls`), **TRIS** (×1000). Ohne `?dev` komplett aus dem Grid entfernt. Sichtbar beim Hover aufs Tacho-Pad, wie die übrige Telemetrie.
2. **DEV-Perf-Readout** (Scorecard-Denke). Ins Dashboard-Grid (nur wenn `?dev` o.ä.) drei Zeilen: FPS (gleitend), `renderer.info.render.calls`, `.triangles`. Erlaubt, FX-Stacking-Regressionen (Beat-Aura, Speedlines, Curtains) sofort zu sehen. Rein additiv, kein Umbau.

### Sprint 6 — Echte SFX (optional, nur wenn gewünscht)
3. **Audio-Manifest** (ElevenLabs-Skill-Muster = das `Sounds/fx/`-Konzept). `Sounds/fx.json` mappt Trigger→Datei (`{gate, turn, jerk, cardHit, liftClick, cheer}`), Loader wie Jukebox (RAW-first, Fallback aufs bestehende synthetische FX). Hängt an vorhandene Trigger (`triggerTurnFx`/`triggerJerkFx`/`triggerCardSfx`). **Blocker:** echte one-shot-Dateien müssen erst ins Repo (`media/3D_Assets/Sounds/fx/`) — existieren noch nicht.

### Kleinere Fix-Kandidaten (jederzeit einstreubar)
- ~~Dashboard-Tacho liest Roh-t-Velocity~~ ✅ **erledigt:** Tacho nutzt jetzt `_arcCompAt` → stetige, echte km/h (vorher sprang die Anzeige zwischen Lese- und Cruise-Tempo, z. B. 17→86→17).
- ~~Pet-Lookahead-Phase~~ ✅ **erledigt:** Lookahead ist jetzt ein fester WELT-Abstand (`× _arcCompAt`), das Pet crestet Hügel in Phase mit dem gefühlten Tempo (vorher fester t-Offset → in dichten Regionen optisch vorgeschossen).
- Beat-Aura: als **Beat-Partikel-Burst** neu gebaut (`_emitBeatBurst`, radialer Puff aus dem Pet-Zentrum im Takt, Mode-Farbe, nutzt das Funken-Buffer) — die früheren Sprite/Billboard-Halos hatten unlösbare Tiefen-/Zentrier-Probleme (immer davor + Wander-Versatz). Optional weiter: Burst-Stärke × speed01, Kopplung an Karten-Gates.
- Rad-Funken (`updatePetTrail`): emittieren jetzt IMMER vom Wagen-Schienenkontakt (Tempo/Kurve/Bremsen), unabhängig von der Beifahrer/Rails-Position → vorher durch `mixT`-Gate bei Default fast unsichtbar.
- **Partikel-Immersion (BRIEF-Benchmarks):** Track-Flows aufgeweitet (radMax 0.15/0.2→0.3/0.4, count 9/6→13/9, size [0.22,1.0]→[0.4,1.9], atten 800→1180, turb 0.16→0.22) → fließende Bänder statt Rail-Hug. Rad-Funken größer (0.8/0.15/800→1.35/0.32/1050) + dichter (Emission 430→640, Buffer 900→1400). Size/Radius/Opacity = perf-schonend, kein Compute-Rewrite.
- **„Liga“-Sprung** ✅ **korrigiert nach Code-Lesen der Beispiele:** erster Versuch (globales HDR + Threshold 0.6) hat überstrahlt → zurück auf `bloom(col,0.8,0.2,0.85)`. Erkenntnis: dunkler BG + ACES + Bloom NUR aus echten HDR-Kernen (>1). Tuning jetzt im **KFB Particle Test v1** (`particle-test/`, Live-Tweaks) → Werte in Ride portieren. Voll dokumentiert in `docs/HANDOVER_v7_particles.md`. ✅ **ERLEDIGT (v8):** Config portiert (Bloom 2.1/0.5/**1.0** — Threshold-safe), COSMIC, Hot-Cores 3.4/3.6) → `docs/HANDOVER_v8.md`.
- **BACKLOG-Idee (Georg):** Skydome mit rotierendem Hypno-Spiral, animiert an Beat/Musik/Speed des Rides (eigener Sky-Mode `spiral`; fbm/Spiral-Shader auf der prozeduralen Kuppel, Rotationsrate ∝ speed01 + Beat-Puls aus `_beatFreq`/audio.bpm). Kandidat für eigenen Sprint.
- **Offen (three.js-Port-Plan, dokumentiert in `docs/HANDOVER_v7_particles.md` §3):** die beiden Referenz-Demos als echte Vergleichs-Tabs. Blocker: interaktive GPU-Compute-Spawn-Demos, Port rendert im Preview nur BG. Plan: Version auf 0.178 pinnen, Compute-Spawn durch Auto-Emitter ersetzen, Compute-Sichtbarkeit isoliert debuggen, dann Tab-Shell-DC. Teil-Port geparkt in `particle-test/linkedparticles.html`.
- Reading-Tour: Ten-Durchschlag ggf. weicher, falls nach Arc-Fix noch zu abrupt.

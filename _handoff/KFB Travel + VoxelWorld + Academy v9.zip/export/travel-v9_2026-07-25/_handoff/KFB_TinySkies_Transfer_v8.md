> Kopie aus `georg-doc/kayfabizarro@main:_handoff/`, geholt 2026-07-25 für die Abstimmung.
> **Noch nicht abgearbeitet** — Bewertung siehe `docs/INTERMISSION_tinyskies.md`.

# KFB Travel v8+ // TinySkies Architektur-Transfer (Gemini)

**Quelle:** `dannylimanseta/tinyskies` · **Fokus:** KISS, Modul-Extraktion und Adaption für den
analogen, handgezeichneten Retro-Comic-Stil der KFB-Engine.

## Cluster 1 · Data-Driven Vehicles
TinySkies definiert Fahrzeuge strikt über externe Configs (`vehicleCapabilities.ts`) statt Logik zu
duplizieren.
*Vorschlag:* `VehicleConfig` (JSON/TS) + `VehicleFactory`. Die Fahrzeugwerte (Thrust, Drag,
TurnRate, MaxPitch) aus den Hardcodes des `flight-controller.js` herausziehen; der `TravelManager`
lädt beim Modus-Wechsel eine Config („Card", „Balloon", „Rollercoaster") und füttert den Controller.

## Cluster 2 · Quaternion Spherical Math
Gimbal-Lock an den Polen wird durch konsequente Quaternionen gelöst („singularity-free globe flight").
*Vorschlag:* `QuaternionSurfaceMath` als Utility. Essenziell, falls KFB komplexere Topologien oder
Loopings bekommt; sichert flüssige Kamerapfade und verhindert ruckartige `CardRig`-Rotationen.

## Cluster 3 · Modular Modifier Deck
Per-Vehicle-Upgrade-Pools (Level-Up-Karten, die das Handling ändern).
*Vorschlag:* `ModifierPipeline` im `TravelManager` — **perfekter Fit für KFB als Kartenspiel**:
„Travel-Cards" (Boost, Heavy Wind) modifizieren die Base-Stats, bevor der Controller die Physik
anwendet.

## Cluster 4 · Session Contracts
Kritik am „Open Sandbox"-Problem: ziellos herumfliegen ermüdet. Lösung dort: „Run Contracts"
(z. B. „zünde 3 Feuer an").
*Vorschlag:* `TravelContractTracker` — leichtgewichtig, hängt am Event-Layer, lauscht passiv auf
`OnNodeReached`/`OnBoostUsed` und wertet kleine Session-Ziele aus, ohne die Core-Loop zu bremsen.

## Cluster 5 · Network Sync & SLERP
Client-Side-Prediction und SLERP-Interpolation für Koop-Flüge.
*Vorschlag:* `SyncTransform` — externe Positionen per SLERP glätten. **Wichtig:** `PetKinetics`
greift weiterhin LOKAL auf den geglätteten Transform zu, damit die Pet-Animation organisch und
snappy bleibt, auch wenn Netzwerkdaten laggen.

## Cluster 6 · HUD-Anti-Pattern (nicht übernehmen)
TinySkies hat eine monströse `HUD.ts` (God-Class mit Inline-Styles).
*Regel:* strikte Trennung von UI und Canvas. UI als sauberes HTML/CSS-Overlay; der Manager feuert
Ereignisse, die UI reagiert. **Keine DOM-Updates in der `update(dt)`-Schleife der Controller.**

---
**Handover-Direktive:** 1. TravelManager und Interfaces sauberziehen · 2. `VehicleConfig` auslagern ·
3. `ModifierPipeline` für kartenbasiertes Handling integrieren.

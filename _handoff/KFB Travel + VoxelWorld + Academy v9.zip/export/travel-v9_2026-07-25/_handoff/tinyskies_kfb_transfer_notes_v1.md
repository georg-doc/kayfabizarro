> Kopie aus `georg-doc/kayfabizarro@main:_handoff/`, geholt 2026-07-25 für die Abstimmung.
> **Noch nicht abgearbeitet** — Bewertung siehe `docs/INTERMISSION_tinyskies.md`.

# TinySkies → KFB Transfer Notes v1 (ChatGPT)

## Scope
Cluster der brauchbaren Ideen aus `dannylimanseta/tinyskies` für die KFB-Engine. KISS: was
übernehmen, was anpassen, was lassen, und wie man die Arbeit in Claude-taugliche Module schneidet.

## 1 · Was TinySkies ist
Multiplayer-Three.js-Spiel: Flugzeuge um anpassbare Globen. Stack laut README: Vite, TypeScript,
Three.js, Socket.io (Client); Node/Express/Socket.io/Prisma (Server); PostgreSQL. Architektur
ausdrücklich **quaternionenbasierte sphärische Mathematik** plus Relay-Server-Multiplayer mit
Client-Side-Prediction und Slerp-Interpolation. Monorepo mit `client`/`server`/`shared`.

## 2 · Cluster
**A · Runtime-Mathematik.** Kern ist die Globus-Mathematik: Bewegung auf einer gekrümmten Fläche mit
Quaternionen-Orientierung, „singularity-free".
*Übernehmen:* Quaternionen-Zustand für Ausrichtung · Tangentenrahmen-Bewegung · explizite Grenze
zwischen Server- und Client-Interpolation · Kamera-Glättung per Slerp statt Euler-Sprüngen.
*Anpassen:* TinySkies ist flugzeugzentriert, KFB braucht fahrzeug-agnostisches Reisen; Mathematik
behalten, Bewegungssprache ändern (weicher, spielzeughaft).
*Lassen:* „Flugzeug"-Semantik im Runtime-Vertrag festschreiben · Welt-Topologie mit
Fahrzeugverhalten mischen.

**B · Netzwerk.** Relay-Server, Socket.io, State-Sync/Prediction, Prisma/PostgreSQL.
*Übernehmen:* autoritative Server-Grenze für gemeinsamen Zustand · Client-Side-Prediction ·
Interpolation für fremde Akteure · Welt-/Raum-Code als einfaches Session-Modell.
*Anpassen:* keine DB-gestützte Persistenz zu früh.
*Lassen:* DB und Auth vor dem ersten Travel-Modul · Server-Annahmen in der Client-API.

**C · Cosy-World-Inhalte.** Viele kleine Ambient-Systeme (NPC-Boote, Ringe, Sternenfeld, Vögel,
Wasserfontänen, Landmarken) statt eines großen Content-Systems.
*Übernehmen:* viele winzige Ambient-Systeme · Landmarken und Sammelstücke als reibungsarmer
Fortschritt · Wetter/Atmosphäre um das Reisen · NPC-Vorbeiflüge.
*Anpassen:* Flugzeug-Lore durch KFB-Pet-Karten-Identität ersetzen; „kleine Wunder" statt Questketten.
*Lassen:* Content-Systeme überbauen, bevor der Reise-Kern stabil ist.

**D · UI/Onboarding.** Welt erstellen → Code kopieren → in zweitem Tab joinen → zusammen fliegen.
*Übernehmen:* Welt-Code-Beitritt · minimale „create/join/fly"-Schleife · Bedienhinweise, die auf
einen Bildschirm passen.
*Lassen:* aufwendiges Onboarding, bevor das Steuergefühl sitzt.

## 3 · Engineering-Muster
**Muster 1 · Weltzustand aufteilen.** `shared` → Verträge, Enums, Reisezustand,
Fahrzeug-Fähigkeiten · `client` → Rendering, Eingabe, FX, Kamera · `server` → optional
autoritativer Zustand, Sessions, Persistenz.
**Muster 2 · Explizite Runtime-Feature-Module.** `Game.ts` importiert ein Modul-Graph statt eines
Monolithen: Kamera, Tag/Nacht, Audio, Fahrzeuge, Systeme, UI-Overlays, Fortschritt, Quests,
Partikel/VFX, NPCs. KFB-Abbildung: TravelManager · VehicleController · GroundController ·
FlightController · CardRig · CameraRig · TravelFX · TravelUI.
**Muster 3 · Comfort-first.** Nicht der einzelne Effekt zählt, sondern die **Dichte kleiner lesbarer
Rückmeldungen**: Hover, Flex, Wind, Banking, Kamera-Lag, Streifen, ein paar Ambient-Wesen.

## 4 · Was KFB wirklich kopieren sollte
1. Quaternionen + Tangentenrahmen für Globus-Reisen · 2. Prediction/Interpolation (falls
Multiplayer) · 3. Monorepo-Split mit gemeinsamen Verträgen · 4. kleine Ambient-Module statt eines
Szenen-Skripts · 5. einfacher Session-/Welt-Code für Tests und Teilen.

## 5 · Was NICHT 1:1
Flugzeug-spezifische Steuerung und Semantik · der Server/DB-Stack ohne echten Bedarf · die volle
Content-Dichte vor einem stabilen Reise-Kern · das ganze Cosy-Dressing, bevor Gefühl und Verträge
stimmen.

## 6 · Modulvorschlag
001 Travel Runtime Contract · 002 Spherical Movement Core · 003 Camera Rig · 004 Card Rig ·
005 Ground Controller · 006 Flight Controller · 007 Ambient World FX · 008 Optional Multiplayer Shell
(in dieser Reihenfolge).

## 7 · KISS-Fazit
TinySkies ist für KFB vor allem eine **Mathematik- und Runtime-Architektur-Referenz**, keine Kunst-
oder Content-Vorlage. Übertragbar: Quaternionen/sphärische Bewegung, modulare Runtime-Trennung,
Client/Server-Split (falls nötig), Cosy-Ambient-Mikrosysteme. KFB-spezifisch anzupassen:
Karten-/Pet-Fahrzeug-Identität, weicheres Reisegefühl, Weltmodule entlang pet-getriebener Reise.

## 9 · Quellen
`dannylimanseta/tinyskies` README und Root-Manifeste · Import-Graph in `client/src/game/Game.ts` ·
Dateiliste der Ambient-Systeme.

# KFB Travel v9 · Session-Export 2026-07-25

Nur der Scope dieser Session (Regel: `skills/session-export_v1.md`) — **kein Voll-Projekt-Zip.**

## Öffnen
`KFB Travel v9.dc.html` im Browser. Lädt three.js 0.160 per CDN; Decks, Musik und den Pet-Stack zur
Laufzeit per RAW-URL aus `georg-doc/kayfabizarro`. Lokal liegen nur die Fallback-Manifeste
(`terrain-v9/kfb-index.json`, `jukebox.json`, `sfx.json`) und die Kanten-Textur `edge3.jpg`.

## Bedienung
W/S Schub (S gehalten = **rückwärts**) · A/D lenken · **Q/E Standdrehung** (am Boden Seitwärtsschritt) ·
Leertaste Boost · **⇧+Leertaste Warp** · Pfeile/X steigen/sinken · **F** Flug ⇄ Boden ·
Rad/Pinch Zoom (ganz hinein = POV) · **Doppelklick auf eine Karte = Anflug** · Tacho anklicken =
Lektionssuche · **Tab** Einstellungen · **Esc** Detailansicht verlassen.

## Wo anfangen zu lesen
1. `docs/DECISIONS_v10.md` — die vier offenen Konzeptfragen, stand-alone.
2. `docs/SESSION_EXPORT_v9_runtime.md` — was in v9 gilt, mit allen Messzahlen.
3. `docs/INTERMISSION_reviews_v8.md` §5 — die dreizehn Fehlerklassen. **Vor dem ersten Eingriff lesen.**
4. `docs/HANDOVER_v10_coworker.md` — Stand + Bewertung der TinySkies-Transfers.
5. `HOUSEKEEPING.md` — Status je Artefakt, Aufräum-Kandidaten, Pfad-Hygiene.

## Nicht im Export
v1–v8 der Travel-Reihe, `rollercoaster-v11/` (Quelle portierter Systeme), Medien, Uploads,
Screenshots. Alles Schwere gehört ins Repo und wird per RAW-URL geladen.

# Vier Entscheidungen vor KFB Travel v10

> Stand 2026-07-25, nach dem Check-in von v9. **Dieses Dokument ist zum Alleine-Lesen und
> Diskutieren gedacht** — es setzt keine Chat-Vorgeschichte voraus.
> Es entscheidet nichts technisch: alle vier Fragen sind Konzeptfragen, und ohne Antworten wäre jeder
> v10-Plan geraten. Zu jeder Frage steht: **was heute da ist · worum es geht · die Optionen mit ihren
> Folgen · meine Empfehlung · was die Antwort freischaltet.**

---

## Worüber wir überhaupt reden — der Stand in fünf Sätzen

**KayfaBizarro (KFB)** ist ein Cut-&-Play-Comic: ein Comic wird gedruckt, in Karten geschnitten, und
1–6 Menschen bauen daraus laut erzählend eine Geschichte. Niemand gewinnt. Die Karten sind
**Beweisstücke** in dieser Erzählung, keine Spielsteine mit Werten — deshalb gibt es im ganzen Projekt
keine Trefferpunkte, keine Zahlen und keine Punktestände auf Karten.

**KFB Travel** ist kein Spiel, sondern das **Meta-Narrativ dazu**: man reist mit einem Pet auf einer
fliegenden Karte über eine Voxel-Welt. In v8/v9 ist daraus die **Würfelakademie** geworden — 31
Lektionskarten in fünf Farbzonen, die als Orte in einem Stern um den Startpunkt liegen; drei von ihnen
zeigen eine laufende 3D-Demo direkt auf dem Kartenblatt. Man fliegt hin (per Doppelklick auch
automatisch), landet in einer Detailansicht, und ein Post-it am Kartenrand merkt sich, dass man da war.

**v9 hat die Technik geordnet** (Kamera, Modus-Eigentum, Frame-Reihenfolge, Ereignisse, Panel) — dort
sind keine Schulden offen. Was fehlt, ist **Sinn**: 31 Lektionen ohne Bogen, ein Post-it ohne Inhalt,
und ein Reisen, das nichts mit dem Kartenspiel zu tun hat, das KFB eigentlich ist.

Zwei externe Analysen (ChatGPT und Gemini, beide über das Open-Source-Projekt *TinySkies*) schlagen
dafür Bausteine vor. Die vier Fragen unten sind die Stellen, an denen ihre Vorschläge auf KFB-Kanon
treffen — und da entscheidet nicht die Technik.

---

## Frage 1 · Womit fängt v10 an: **Journey** oder **Travel-Cards**?

**Was heute da ist.** Die Akademie zählt besuchte Karten (`academy.visited`) und klebt ein Post-it an
jede besuchte Karte. Das ist alles. Es gibt keine Reihenfolge, kein Ziel, keinen Rückblick — man kann
31 Karten in beliebiger Folge anfliegen, und danach ist der Zustand dasselbe Zahlenpaar.

**Worum es geht.** Beide externen Analysen kritisieren dasselbe: eine offene Welt ohne Bogen ermüdet.
Sie schlagen zwei verschiedene Antworten vor, und wir können nur eine zuerst bauen:

**Option A · Journey (der Bogen).** Die Reise merkt sich, wo man war, was man dort notiert hat und wie
weit ein Kapitel gediehen ist. Am Ende steht etwas, das man **ansehen oder weitergeben** kann — eine
Art Reisetagebuch aus besuchten Karten und eigenen Notizen.
*Folge:* Die Akademie wird zu einem Lernweg. Das Post-it bekommt endlich einen Inhalt (Frage 3 hängt
daran). Kein neues Spielsystem, kein Kanon-Risiko.

**Option B · Travel-Cards (das Kartenspiel im Reisen).** Karten, die man ins Reise-Deck steckt und die
das Fahren verändern — Gegenwind, Rückenwind, schwerer Ballast, ein zweites Pet. Mechanisch ist das
eine Pipeline, die vor der Physik die Fahrzeugwerte verändert.
*Folge:* Das Reisen wird selbst ein Kartenspiel — die stärkste Verbindung zu KFB als Marke. Aber es
braucht zuerst eine Antwort auf Frage 2, sonst bauen wir Powers mit Zahlen.

**Meine Empfehlung: A, dann B.** Nicht weil B schwächer ist, sondern weil A das kleinere Risiko und die
größere Wirkung pro Aufwand hat: 31 Karten liegen bereit und warten auf einen Faden. Außerdem liefert A
die Ereignisse (angekommen, notiert, Kapitel voll), an denen B später ohnehin hängen würde.

**Was die Antwort freischaltet:** die Reihenfolge der nächsten drei bis vier Slices.

---

## Frage 2 · Wie zeigt eine Karte ihre Wirkung, **ohne eine Zahl zu nennen**?

*(Das ist die Frage, die ich vorher unverständlich formuliert hatte — hier ausführlich.)*

**Der Kanon-Konflikt in einem Satz.** In KFB sind Karten **Beweisstücke**: sie behaupten etwas über die
Geschichte („Uncle FrizzleBob hat den Schlüssel verschluckt"), sie haben keine Werte. Die
Gemini-Analyse schlägt aber genau das vor, was in normalen Spielen üblich ist: Karten als
**Handling-Modifikatoren** — „+15 % Schub", „−30 % Kurvenradius". Sobald so etwas im Bild steht, ist
die Karte kein Beweisstück mehr, sondern ein Statistikblock. Damit wäre KFB an der Stelle ein
gewöhnliches Deckbuilder-Spiel.

**Die eigentliche Frage:** Wenn eine Karte die Fahrt verändert, **woran merkt man das** — wenn nicht an
einer Zahl?

Vier Antworten sind denkbar, und sie schließen sich nicht aus. Was wir brauchen, ist eine
**Rangfolge**, denn die erste bestimmt, wie sich das Spiel anfühlt:

**Option A · Spürbar (Steuerung).** Die Karte verändert nur, wie sich das Fliegen anfühlt — träger,
bissiger, driftiger. Kein Text, kein Symbol. Man merkt es an den Fingern.
*Folge:* Am reinsten im Sinne des Kanons. Risiko: manche Spieler merken es nicht und halten die Karte
für wirkungslos.

**Option B · Sichtbar (die Welt reagiert).** Die Karte zeigt sich in der Welt: Wind biegt die
Voxel-Halme, die Kartenkante flattert stärker, Kondensstreifen werden länger, die Farbe der Zone kippt.
*Folge:* Sehr KFB (der Comic zeigt, er erklärt nicht) und im Projekt schon vorhanden — es gibt
Streifen, Hitzeflimmern, Windkurven und einen Regie-Skalar, der die ganze Welt beim Boost weitet.

**Option C · Hörbar.** Klang und Takt ändern sich: ein tieferes Rauschen bei Ballast, ein Pfeifen bei
Rückenwind. Musik und Einsatz-Ebene liegen bereit.
*Folge:* Billig zu bauen, wirkt stark, wird aber ohne A oder B leicht als Deko gelesen.

**Option D · Erzählt (das Pet sagt es).** Das Pet kommentiert: „Uff. Heute fliegt sich das wie durch
Pudding." Die Karte wirkt also **durch Kayfabulation** — die Behauptung IST die Mechanik.
*Folge:* Am nächsten am Spiel („BLÖDSINN!" ist eine legitime Antwort auf eine Behauptung), am
aufwendigsten, weil es Sprache braucht (Text, später Stimme).

**Meine Empfehlung: B als Träger, A darunter, D als Zugabe** — die Welt zeigt es, die Finger
bestätigen es, das Pet redet darüber. C ergänzt B, wo es billig ist. **Kein Zahlenwert, kein Symbol mit
Prozentangabe, nirgends.**

**Was die Antwort freischaltet:** ob Travel-Cards überhaupt gebaut werden können, und wie eine
Travel-Card aussieht, bevor irgendetwas programmiert wird.

---

## Frage 3 · Was passiert mit den **Notizen** — Format und Ziel?

**Was heute da ist.** An jeder besuchten Lektionskarte klebt ein Post-it (unten links, leicht schräg,
folgt der Kartenbewegung träge). Es ist **leer** — reine Optik. Die Idee, dort Studiennotizen
einzugeben und sie mit der Reise zu speichern, war von Anfang an mitgedacht, aber nie entschieden.

**Worum es geht.** Sobald jemand etwas hineinschreibt, entstehen drei Fragen gleichzeitig: **Wo lebt
der Text? In welcher Form verlässt er das Programm? Und für wen?**

**Option A · Nur lokal, flüchtig.** Notizen leben im Browser (Local Storage), gehen beim Wechsel des
Geräts verloren.
*Folge:* Sofort baubar, null Infrastruktur. Aber: nichts, was man herzeigen kann — und damit kein
Ergebnis der Reise.

**Option B · Lokal + Export als Markdown-Reisetagebuch.** Ein Knopf schreibt eine Datei: Kapitel,
besuchte Lektionen, eigene Notizen, Datum. Lesbar ohne KFB, ablegbar im Repo.
*Folge:* Passt zur Arbeitsweise des Projekts (alles ist Markdown), und das Ergebnis ist ein Dokument,
das man teilen kann. Mehr Aufwand: ein Format muss festgelegt werden.

**Option C · Lokal + Export als Deck-JSON.** Die Notizen werden zu **Karten** — im gleichen Format wie
die bestehenden Decks, also potenziell druckbar und im Spiel verwendbar.
*Folge:* Die stärkste Idee im Sinne von KFB: aus dem Lernen entstehen echte Beweisstücke, die im
Tischspiel landen. Auch die aufwendigste, weil das Deck-Format bedient werden muss.

**Meine Empfehlung: B jetzt, C als Ziel.** Markdown ist in einer Stunde entschieden und passt in die
bestehende Doku-Kultur; C ist der schönere Bogen (Lernen → Karte → Tischspiel) und sollte als Richtung
festgehalten werden, damit B nicht in eine Sackgasse läuft.

**Zu klären in der Diskussion:** Sind die Notizen **privat** (mein Lernweg) oder **teilbar** (eine
Klasse, ein Team)? Davon hängt ab, ob überhaupt jemals ein Server ins Spiel kommt — und heute gibt es
keinen.

---

## Frage 4 · Bleibt die Welt ein **Höhenfeld**, oder wird sie **rund**?

**Was heute da ist.** Die Welt ist ein unendlich streamendes Voxel-Gelände — im Kern eine Landschaft
mit Höhen, über der man fliegt. Sie hat keinen Rand, aber auch keine Krümmung: „geradeaus" bedeutet
immer dieselbe Richtung.

**Worum es geht.** Beide externen Analysen empfehlen mit Nachdruck **Quaternionen- und
Kugelmathematik** („singularity-free globe flight") — das ist die Technik, mit der man um einen
Planeten fliegen kann, ohne dass die Steuerung an den Polen kippt. Diese Empfehlung ist nur dann
sinnvoll, wenn KFB Travel irgendwann eine **Kugel** sein soll. Bauen wir sie vorher, bauen wir
Mathematik für eine Welt, die es nicht gibt.

**Option A · Höhenfeld bleibt.** Zonen sind Orte in einer Ebene, die Reise ist ein Stern.
*Folge:* Nichts zu tun. Die Zonen-Logik von v9 passt. Kugel-Empfehlungen entfallen ersatzlos.

**Option B · Kugel/Planet.** Die Akademie liegt auf einem kleinen Planeten, man kann ihn umrunden, und
„weit weg" wird irgendwann wieder „nah".
*Folge:* Ein starkes Bild (ein Lernplanet), und die Empfehlungen beider Analysen würden greifen.
Aber: Gelände-Streaming, Schatten, Himmel, Karten-Platzierung und Bodenmodus hängen alle an der
heutigen Annahme „Höhe über einer Ebene". Das ist ein großer Umbau, kein Slice.

**Option C · Insel im Nichts.** Kein Planet, aber ein **begrenzter** Ort mit Rand — eine schwebende
Insel, auf der die fünf Zonen liegen.
*Folge:* Gibt der Welt einen Umriss (man kann sie überblicken, es gibt ein „außerhalb") ohne
Kugelmathematik. Mittlerer Aufwand.

**Meine Empfehlung: A vorerst, C als Bild im Hinterkopf.** Die Kugel ist verführerisch, zahlt aber
nichts an die offenen Fragen 1–3 zurück; ein Umriss (C) macht die Akademie als *Ort* begreifbar und
wäre der günstigere Schritt, falls das Sternbild zu abstrakt bleibt.

**Was die Antwort freischaltet:** ob zwei Empfehlungen der externen Analysen (Quaternionen-Kern,
Fahrzeug-Configs für Kugelflug) auf die Liste kommen oder gestrichen werden.

---

## Zusammenfassung als Abstimmungszettel

| Frage | Optionen | meine Empfehlung |
|---|---|---|
| **1 · Nächster Schritt** | A Journey · B Travel-Cards | **A, dann B** |
| **2 · Wirkung ohne Zahl** | A spürbar · B sichtbar · C hörbar · D erzählt | **B trägt, A darunter, D als Zugabe** |
| **3 · Notizen** | A nur lokal · B Markdown-Export · C Deck-JSON | **B jetzt, C als Ziel** |
| **4 · Weltform** | A Höhenfeld · B Kugel · C Insel mit Rand | **A vorerst, C im Hinterkopf** |

**Wenn du allen vier Empfehlungen folgst**, sieht v10 so aus: die Journey wird gebaut (besuchte Karten,
Notizen im Post-it, Kapitel-Fortschritt), die Notizen gehen als Markdown-Reisetagebuch heraus, die Welt
bleibt wie sie ist — und Travel-Cards werden vorbereitet, indem die Wirkung zuerst als **Weltreaktion**
entworfen wird, nicht als Wert.

**Nicht auf der Liste, mit Begründung:** Multiplayer, Server, Datenbank, Welt-Codes (kein Bedarf, hohe
Kosten) · ein Monorepo mit `client/server/shared` (KFB Travel ist ein Einzeldokument-Design) · die
Cosy-Content-Dichte von TinySkies mit NPC-Booten, Vögeln und Wasserfontänen (KFB ist ein
Kartenspiel-Meta, keine Landlebens-Simulation).

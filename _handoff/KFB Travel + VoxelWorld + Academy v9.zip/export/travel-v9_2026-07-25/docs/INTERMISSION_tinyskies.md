# Intermission · TinySkies-Transfer gegen den Stand v9

> Quellen (2026-07-25 ins Projekt geholt, unverändert): `_handoff/tinyskies_kfb_transfer_notes_v1.md`
> (ChatGPT) · `_handoff/KFB_TinySkies_Transfer_v8.md` (Gemini).
> **Dies ist die erste Bewertung — zur Abstimmung, noch keine Entscheidung.**

## Erste Einordnung: die Hälfte ist bereits gebaut

Beide Dokumente sind gegen **v7/v8** geschrieben. Der v9-Umbau (A–D) hat mehrere ihrer
P1-Forderungen schon erledigt — das gehört vor jede Diskussion, sonst planen wir Vorhandenes:

| Forderung | Stand v9 |
|---|---|
| Modulare Runtime statt Monolith (beide) | ✅ `camera-rig` · `mode-owner` · `travel-manager` · `travel-input` · `travel-stage` · `travel-events` · `settings-schema` |
| CameraRig als reiner Konsument (beide) | ✅ genau 1 Kamera-Schreiber |
| Explizite Update-Reihenfolge (ChatGPT §Muster 2) | ✅ Pipeline als getaktete Liste |
| Kein God-HUD, keine DOM-Updates in `update()` (Gemini C6) | ✅ Overlay + Schema, Strip ist DOM außerhalb der Schritte |
| Event-Layer (beide) | ✅ Tabelle statt Bus — **bewusst kein Bus**, 0 Duplikate gemessen |
| Ambient-Mikrosysteme statt eines Content-Blocks (ChatGPT C) | ✅ so gebaut (Streifen, Hitze, Klang, Post-it, Titel …) |

## Was neu und wertvoll ist

1. **`VehicleConfig` / Data-Driven Vehicles** (Gemini C1) — die Fahrzeugwerte stecken heute in
   `flight-controller.js`. Für Ballon/Boot/Rollercoaster wäre eine Config je Fahrzeug der richtige
   Schnitt. **Passt zu unserer Regel „eine Zahl, ein Ort".** Aufwand klein, Nutzen erst mit dem
   zweiten Fahrzeug — also: vorbereiten, wenn ein zweites Fahrzeug wirklich kommt.
2. **`ModifierPipeline` / Travel-Cards** (Gemini C3) — **der stärkste Punkt für KFB.** Karten, die
   das Handling ändern, sind exakt die Spielidee: Karten sind Beweisstücke, und ein „Heavy Wind"
   wäre ein Beweisstück, das die Fahrt verändert. Vorsicht bei der Umsetzung: **keine Zahlenwerte im
   UI** (Kanon) — die Karte zeigt Wirkung, nicht Statistik.
3. **Session-Ziele / `TravelContractTracker`** (Gemini C4) — die Sandbox-Kritik trifft uns: 31
   Lektionen ohne Bogen. Aber der KFB-Rahmen dafür ist **nicht** „zünde 3 Feuer an", sondern die
   **Journey**: besuchte Karten, Notizen, Kapitel-Fortschritt. Der Zähler existiert halb
   (`academy.visited`, Post-it). Kandidat mit Konzeptbedarf, nicht mit Modulbedarf.
4. **Quaternionen/Tangentenrahmen für gekrümmte Welten** (beide) — heute fliegen wir über ein
   Höhenfeld, kein Globus. Der Flug-Controller ist quaternionenbasiert; ein Globus ist ein
   **Weltthema**, kein Controller-Thema. Erst relevant, wenn die Welt rund wird.

## Was ich ablehnen würde

- **Monorepo mit `client`/`server`/`shared`** (ChatGPT §Muster 1): KFB Travel ist ein
  Einzeldokument-Design in diesem Projekt, kein Node-Workspace. Verträge liegen in Modulköpfen und
  Dokumenten — das trägt hier weiter als eine Ordnerstruktur.
- **Multiplayer, Server, Prisma/PostgreSQL, Welt-Codes** (beide): kein Bedarf, hohe Kosten. Wenn
  Ghosts/Replays kommen, ist `SyncTransform` + SLERP der richtige Hinweis — dann aber mit der
  Gemini-Warnung: PetKinetics greift LOKAL auf den geglätteten Transform zu.
- **Content-Dichte übernehmen** (NPC-Boote, Vögel, Wasserfontänen): KFB ist ein Kartenspiel-Meta,
  keine Cosy-Sim. Einzelne kleine Wunder ja — aber als Kayfabulation, nicht als Fauna.
- **008 Optional Multiplayer Shell** als Slice: nicht in v9, nicht in v10.

## Vorschlag zur Reihenfolge (offen)

1. Betriebs-Befunde aus v9 fertig (Viewport · Sky-Karten-Tusche · Klickbarkeit · Post-it).
2. **Journey** als Bogen (Cluster 4, KFB-Fassung): besucht + Notizen + Kapitel — das ist der Punkt,
   an dem die Akademie ein Spiel wird.
3. **ModifierPipeline** mit zwei echten Travel-Cards als Machbarkeitsnachweis.
4. `VehicleConfig` erst mit dem zweiten Fahrzeug.

**Zur Diskussion:** ist die Journey (2) der nächste große Schritt, oder zuerst die Travel-Cards (3)?
Beides zusammen wäre ein Konzept-Slice mit Kanon-Fragen (was ist ein Beweisstück, das die Fahrt
ändert?) — und die gehören zuerst besprochen, nicht gebaut.

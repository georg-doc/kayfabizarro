# Handover · KFB Travel v9 (Runtime)

> Geschrieben beim Fork, 2026-07-25. **v8 ist eingefroren** (`KFB Travel v8 - Academy Flow.dc.html`
> + `terrain-v8/`) und bleibt der **Vergleichsmaßstab**: v9 darf sich nur dort anders verhalten, wo
> eine Abnahmezahl es verlangt.
> Auftrag und Begründung stehen in **`docs/INTERMISSION_reviews_v8.md`** — wer hier anfängt, liest
> dort §4 (was gestrichen ist) und §5 (die Fehlerklassen) zuerst.

## Was v9 ist

Ein **Aufräum-Fork**, kein Feature-Fork. Das Verhalten von v8 bleibt; die **Verdrahtung** verlässt
`travel-poc.js`. Vier Stufen, jede einzeln lauffähig, jede mit einer Zahl:

| Stufe | Eingriff | Abnahme (messbar) |
|---|---|---|
| **A · CameraRig** | Follow, Lag, POV-Mischung, FOV, Dolly, Gelände-Ausweichen, Dock-Anflug ziehen in `camera-rig.js`. Das Rig liest nur Runtime-State. | **genau 1** Modul schreibt `camera.position|quaternion|rotation|lookAt|fov` (heute **4**) · Zoom-Sprung ≤ **1,5 ×** Median in beiden Richtungen über Rad-Ereignisse · Übergang Pet-nah ⇄ POV ohne sichtbaren Ruck · **0** Allokationen im Frame |
| **B · Modus-Eigentum** | `switchMode` wird `requestMode(mode, reason)`; ein Eigentümer nimmt an oder lehnt ab. Dazu `assertController()` im Debug-Modus. | `switchMode` existiert an **einer** Stelle · Regressionsfall „Anflug auf tief hängende Karte über steigendem Terrain" endet **im Flug** · Vertragsprüfung grün für `flight-controller` und `walk-controller` |
| **C · Panel als Daten, dann TravelManager** | Die ~363 Regler-Zeilen werden ein Schema (`settings-schema.js`); danach nimmt `travel-manager.js` Lebenszyklus, **Pipeline als Liste** und Modus-Wechsel. | Runner **< 400 Zeilen** (heute **1327**) · Pipeline an einer Stelle, im Log prüfbar · identische Kennzahlen zu v8 (fps, 31 Karten, Zoom-Sprünge) |
| **D · Ereignisse an einem Ort** | Die acht Callbacks in einer Tabelle (Ereignis · Eigentümer · Zuhörer). **Kein Bus**, bis ein Ereignis ≥3 Zuhörer hat. | keine verstreute `x.onFoo = …`-Zuweisung mehr |

**Nicht in v9:** Vehicle-Hierarchie (Boot/Ballon/Drache) · CardRig-Layer-Split · Event-Bus ·
Telemetrie · Replay · AI-Navigation. Begründung in der Intermission §4.

## Ausgangslage, gemessen (Fork-Zeitpunkt)

- **31 Module · 438 KB**
- `travel-poc.js`: **86 KB · 1327 Zeilen · 26 Importe · 8 Ad-hoc-Callbacks**
- Kamera-Schreiber: `travel-poc` 10× · `card-dock` 5× · `hud-cube` 1× · `skydome-shader` 1×
  (`academy-lessons` zählt nicht — eigene RTT-Kamera)
- Allokationen im Frame-Pfad: **0** ✅ — **Achtung, die Messung zählt `new THREE.*` und sieht
  Objektliterale NICHT.** In S42 sind so zwei Objekte pro Frame durchgekommen (Modus-Antrag). Wer die
  Invariante prüft, sucht auch nach `{ … }`-Rückgaben und Closures im Frame-Pfad.
- Zusammensetzung des Runners: ~363 Z Regler-Panel · ~339 Z `readInput` + Frame-Schleife ·
  ~180 Z Boot/Assets/Audio · ~150 Z Zeiger-Behandlung · 36 Z Modus-Wechsel

## Modul-Karte

| Modul | Größe | Zeilen |
|---|---|---|
| `travel-poc.js` | 86.9 KB | 1335 |
| `voxel-terrain.js` | 27.6 KB | 563 |
| `travel-audio.js` | 25.5 KB | 509 |
| `hud-cube.js` | 21.6 KB | 443 |
| `academy-cards.js` | 20.5 KB | 435 |
| `sky-cards.js` | 19.2 KB | 409 |
| `skydome-shader.js` | 16.5 KB | 350 |
| `kfb-pets.js` | 16.1 KB | 377 |
| `world-context.js` | 15.7 KB | 291 |
| `card-carrier.js` | 15 KB | 275 |
| `academy-deck.js` | 12.9 KB | 244 |
| `autopilot.js` | 12.9 KB | 247 |
| `settings-overlay.js` | 11.9 KB | 244 |
| `pet-kinetics.js` | 11.8 KB | 230 |
| `voxel-glyphs.js` | 11.6 KB | 253 |
| `academy-lessons.js` | 11.2 KB | 260 |
| `speed-lines.js` | 11.1 KB | 225 |
| `lesson-search.js` | 9.2 KB | 197 |
| `card-registry.js` | 8.8 KB | 191 |
| `card-contrails.js` | 8.7 KB | 196 |
| `walk-controller.js` | 8.7 KB | 169 |
| `ink-tail.js` | 6.7 KB | 131 |
| `academy-live.js` | 6.6 KB | 150 |
| `flight-controller.js` | 6.4 KB | 129 |
| `card-dock.js` | 6.3 KB | 127 |
| `post-radial.js` | 6.2 KB | 141 |
| `pet-lighting.js` | 5.9 KB | 136 |
| `kfb-ink.js` | 5.1 KB | 111 |
| `pet-facing.js` | 4 KB | 89 |
| `travel-heat.js` | 4 KB | 87 |
| `ground-shadow.js` | 3.6 KB | 84 |

## Verträge, die schon gelten (nicht brechen)

- **Die Version gehört dem Runner.** Kein Modul kennt seine Versionsnummer — beim Fork von v8 nach v9
  war genau **eine** Datei anzufassen. Das war vorher nicht so (10 Module trugen „v8" im Kopf) und ist
  im Clean-up behoben.
- **PetKinetics ist unantastbar.** Reihenfolge: Motor (PetMotion/Face/EyeRig) → `pet-kinetics` →
  `pet-facing`. Das Facing schreibt **nur `rotation.y`**, nie das ganze Quaternion.
- **WorldContext ist Lese-Instanz**, `card-carrier` besitzt nur den Mount-Transform,
  `academy-*` besitzt die Karten, `autopilot` ist eine **Eingabequelle** (kein zweiter Controller).
- **Die Tusche der Karten ist `ink-tail.js`** (Band), die der Chips/Post-its `kfb-ink.js`
  (`inkChip`). Zwei Familien — siehe `skills/SSOT_Card_Ink_Outline.md`.
- **Live-Demos:** immer nur **eine** läuft (Pacer), das Fenster-Format kommt aus **einer** Konstante
  (`SCREEN` → `WINDOW_AR`).

## Stand 2026-07-25: A–D erledigt

| Stufe | Ergebnis | Beleg |
|---|---|---|
| **A CameraRig** | genau **1** Kamera-Schreiber (vorher 4) | Zoom-Sprünge, Blickdrehung im p95 |
| **B Modus-Eigentum** | `switchMode` weg, 4 benannte Regeln, Vertragsprüfung 4/4 | jede Regel einzeln gemessen |
| **C Manager + Panel + Eingabe + Bühne** | Pipeline als getaktete Liste, Panel als Schema, `travel-input`, `travel-stage` | render 2,16 ms · Runner 1418 → ~1020 Z |
| **D Ereignisse** | 8 Anmeldungen in einer Tabelle, 0 Duplikate, kein Bus | `onFocus` ×3, `onArrive` ×1, `onDock` ×1 |

**„Runner < 400 Z" ist bewusst nicht erzwungen** — Begründung im Changelog (S44d): die Verdrahtung
liegt unter 150 Z, der Rest ist Systemaufbau und Pipeline-Schritte; ein weiterer Schnitt würde die
Kopplung erhöhen.

## Offen aus v8 (wandert mit)

1. **Zoom-Ruckeln Pet-nah ⇄ POV** — erste Aufgabe in **V9-A**. Verdacht: Pet-Sichtbarkeit schaltet
   hart bei `povS = 0,62`, und `card-dock` mischt parallel seine eigene Kamera.
2. **Pet-Facing im Walk-Modus** (kämpft dort mit dem Gehzyklus).
3. **Beat-Aura + Talk-Mouth** — dieselbe Schicht wie Facing; 13 Viseme liegen im Pet-Stack.
4. **S34 Voice/Chat auf der Würfelfläche** — die Suche (S33) ist die KISS-Vorstufe und läuft.

## Wie hier getestet wird

**Über den echten Bedienweg, nie über die API.** Rad-Ereignisse für Zoom, Doppelklick für den
Anflug, Tastatur für die Suche. Ein Slice kann über `start()` grün und über den Schalter tot sein.
Jede Änderung braucht **eine Zahl** im Changelog — und die Zahl, die zählt, ist das *Minimum*,
nicht der Mittelwert.

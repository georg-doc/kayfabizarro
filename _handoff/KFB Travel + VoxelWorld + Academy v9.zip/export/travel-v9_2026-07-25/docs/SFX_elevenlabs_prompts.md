# ElevenLabs · SFX-Prompts für KFB Travel

Stand 2026-07-25 · gehört zu Slice **S21** (Einsatz-Ebene) und **S22** (Sky-Karten).

## So kommen die Dateien ins Spiel

Die Engine spielt **Sample erst, Synthese dann**: steht für ein Ereignis eine Datei im Manifest,
klingt sie; steht keine da, spielt der synthetische Einsatz. Also **nie Stille**, und Nachlegen ist
eine Datenänderung, kein Code.

1. Datei ins Repo: `media/3D_Assets/Audio/`
2. Zeile ins Manifest: `media/3D_Assets/Audio/sfx.json` (RAW-first; lokaler Fallback liegt in
   `terrain-v7/sfx.json`)

```json
{ "sfx": {
  "boost":  { "file": "media/3D_Assets/Audio/kfb_boost_riser.mp3", "gain": 0.9 },
  "land":   { "file": "media/3D_Assets/Audio/kfb_land_thud.mp3", "gain": 1.0 },
  "step":   { "variants": ["…/kfb_step_a.mp3", "…/kfb_step_b.mp3",
                           "…/kfb_step_c.mp3", "…/kfb_step_d.mp3"], "jitter": 0.14, "gain": 0.7 },
  "card":   { "file": "media/3D_Assets/Audio/kfb_card_pass.mp3", "gain": 1.0 }
} }
```

Felder: `file` **oder** `variants[]` (rotiert gegen Wiederholung) · `gain` (Trim) · `rate`
(Grundtonhöhe) · `jitter` (zufällige Tonhöhenstreuung, Standard 0,06).

## Generator-Einstellungen

- **Duration manuell setzen** — Auto liefert zu lange Dateien mit Nachhall, den wir nicht wollen.
- **Prompt Influence 0,7–0,9** — hoch, sonst wird aus „cartoon" beliebiges Foley.
- **Immer 3–4 Varianten** pro wiederkehrendem Ereignis (Schritte, Aufprall). Wiederholung ist der
  schnellste Weg zu „billig".
- **In jedem Prompt „dry, no reverb"** — den Raum bringt die Engine mit (geteilter Hall-Bus, Wet aus
  dem Story-Mode). Doppelter Raum klingt matschig.
- **Material „paper / cardboard / watercolour paper"** zieht das ganze Set in die KFB-Welt, ohne
  albern zu werden. Das ist der Grund, warum das Set zusammenklingt, obwohl die Ereignisse
  verschieden sind.
- Export **MP3** reicht; die Engine dekodiert alles, was der Browser kann.

---

## Ebene 1 · Flug und Bewegung (S21, in Benutzung)

**`boost` · 0,8 s**
> Cartoon rocket boost whoosh, quick upward pitch sweep with a punchy air burst at the start, papery texture, dry, no music, no tail

**`boost_end` · 0,6 s** *(Freigabe des Boosts — noch nicht abgefragt, gern schon generieren)*
> Air pressure release, short descending whumpf with a paper flutter, soft, dry, no reverb

**`land` · 0,5 s**
> Soft cartoon landing thud on cardboard, low muffled impact with a tiny paper crinkle, dry, close-mic, no reverb

**`jump` · 0,4 s**
> Cartoon hop, short springy boing with a paper flick, playful, bright, very dry, no echo

**`step` · 4 Varianten · 0,25 s**
> Single soft footstep on thick paper, tiny muffled tap with a faint crinkle, close-mic, dry, no reverb, no tail

**`roll` · 1,0 s**
> Cartoon barrel roll swish, airy fabric whoosh sweeping past, mid-frequency, smooth rise and fall, dry, no impact

**`scrape` · 0,7 s** *(Streifschuss über eine Cube-Kante — für S4 Staub & Splitter)*
> Cardboard scraping against cardboard, short dry rasp with a dusty tail, no reverb

---

## Ebene 2 · Karten: Durchflug, Vorhang, Portal (S22)

Das sind die beiden, nach denen du gefragt hast. Beide sind **zweiteilig gedacht**: ein Kontakt und
ein Nachklang — genau so löst die Engine sie auch aus (`card` beim Durchflug, `portal` bei der
Auflösung).

**`card` · Durchflug, Standard · 1,2 s**
> Flying fast through a hanging paper curtain, crisp fabric flutter followed by a bright glass ping and a short shimmer tail, magical but dry, no music

**`card_cloth` · Durchflug, Curtain-Modus · 1,4 s**
> Bursting through heavy cloth banners in strong wind, deep fabric flap and rope creak, whooshing air, dry, close-mic, no reverb

**`card_paper` · Durchflug, Papier-Variante · 0,9 s**
> Tearing through a sheet of watercolour paper at speed, sharp dry rip with confetti-like flutter after it, no reverb

**`curtain_idle` · Loop-Bett für Vorhänge im Wind · 4,0 s (Loop)**
> Loose cloth banner fluttering in steady wind, continuous soft flapping with rope creaks, seamless loop, no music, no reverb

**`portal` · Auflösung, Standard · 1,5 s**
> Paper card dissolving into sparkles, delicate crackling shimmer descending in pitch, glassy and airy, no melody, dry

**`portal_swirl` · Auflösung, Portal-Modus · 2,0 s**
> Magic vortex opening, airy swirling suction with glassy overtones rising then collapsing inward, dry, no music, no drums

**`portal_close` · 0,8 s**
> Soft magical snap closing, quick inward whoosh with a single glass tick, dry, no tail

---

## Ebene 3 · Welt, Story, Pet (für S16 / S24 / Story-Modus)

**`mode` · Story-Mode-Wechsel · 1,5 s**
> Deep wooden dice roll landing hard, followed by a single soft gong swell, mysterious and cinematic, dry front with a short tail

**`dice` · Würfelwurf allein · 0,8 s**
> Two wooden dice tumbling and settling on a wooden table, close-mic, dry, no reverb

**`thunder_far` · 3,0 s** *(für S17 Regen & Wirbelstürme)*
> Distant rolling thunder, low and soft, no rain, no reverb tail, cinematic but restrained

**`gust_hit` · 1,2 s** *(lokale Orkan-Turbulenz — S22c)*
> Sudden strong wind gust hitting, sharp air rush with fluttering paper debris, dry, no reverb

**`greet` · Pet, neugierig · 0,6 s**
> Small cartoon creature chirp, curious rising two-note squeak, no words, toy-like, dry

**`hurt` · Pet, Aufprall · 0,5 s**
> Small cartoon creature surprised squeak, short falling two-note, comical not painful, dry

**`collect` · Karte ins Deck · 0,7 s**
> Single playing card being placed on a stack, crisp paper snap with a soft flick, close-mic, dry, no reverb

---

## Ebene 4 · Oberfläche (S25 — Kenney-Set deckt das meiste schon ab)

Diese hier nur generieren, wenn das Kenney-Set nicht passt. **UI immer leiser als Welt** — sonst
klickt die Oberfläche lauter als der Flug.

**`ui-open` · 0,3 s**
> Paper sheet sliding open, soft dry swish, very short, no reverb

**`ui-close` · 0,3 s**
> Paper sheet sliding shut, soft dry swish with a tiny tap at the end, no reverb

**`ui-tick` · 0,15 s**
> Tiny paper click, dry mechanical tick, very short, no tone, no reverb

**`cube-spin` · 0,5 s**
> Small wooden cube spinning on a table, dry rolling rattle, close-mic, no reverb

---

## Was ich NICHT generieren würde

- **Musik oder Melodien** — die Jukebox trägt das, und ein melodischer Einsatz kämpft mit dem
  laufenden Track (unterschiedliche Tonarten).
- **Lange Ambience-Betten** — die Drone-Ebene macht das prozedural und folgt dem Story-Mode; eine
  fixe Datei kann das nicht.
- **Alles mit Hall** — siehe oben.
- **Stimme / Sprache** — das ist der Narrator (Pet-Voice), ein eigenes System mit eigener Stimme,
  keine SFX-Datei.

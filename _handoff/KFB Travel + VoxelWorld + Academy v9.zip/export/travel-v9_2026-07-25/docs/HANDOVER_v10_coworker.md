# Handover für den Coworker · Stand KFB Travel v9, Blick auf v10

> Geschrieben 2026-07-25 beim Check-in von v9. **v9 läuft und ist der aktuelle Stand**
> (`KFB Travel v9.dc.html` + `terrain-v9/`), v8 bleibt als Vergleichsmaßstab eingefroren.
> Wer hier anfängt, liest **zwei** Dokumente zuerst: `docs/SESSION_EXPORT_v9_runtime.md`
> (was gilt und was gemessen ist) und `docs/INTERMISSION_reviews_v8.md` §5 (die zwölf
> Fehlerklassen). Ohne §5 baut man sie nachweislich nachdem.

## 1 · Was v9 fertig hat — und was daraus folgt

Der Architektur-Plan aus den fünf v7/v8-Audits ist **abgearbeitet**: ein Kamera-Eigentümer, ein
Modus-Eigentümer mit benannten Regeln, Pipeline als getaktete Liste, Panel als Schema, Eingabe und
Bühne als Module, Ereignisse in einer Tabelle. **Es gibt keine offenen Architektur-Schulden.**
Was offen ist, ist Betrieb (Liste im Session-Export §5) und **Konzept** — und da beginnt v10.

**Eine Zahl ist bewusst nicht erfüllt:** „Runner < 400 Zeilen". Er hat 1050. Davon sind unter 150 Z
Verdrahtung; der Rest ist Systemaufbau (256 Z), Pipeline-Schritte (283 Z), Welt-Rebake (90 Z) und
Boot. Die 400 waren ein **Proxy** für „Orchestrierung an einem Ort", und das ist erreicht. Ein
weiterer Schnitt würde 40–50 Abhängigkeiten durch Kontext-Objekte fädeln und die Kopplung **erhöhen**.
Wer die Zahl trotzdem will, gruppiert Systeme neu (`academy-suite.js` aus Karten + Live + Dock +
Suche) — das ist ein Konzept-Slice, kein Aufräum-Slice.

## 2 · Die beiden TinySkies-Transfer-Dokumente

Liegen unverändert in `_handoff/`: `tinyskies_kfb_transfer_notes_v1.md` (ChatGPT) und
`KFB_TinySkies_Transfer_v8.md` (Gemini). **Erste Bewertung: `docs/INTERMISSION_tinyskies.md`.**
Kurzfassung für die Planung:

**Schon gebaut** (beide Dokumente sind gegen v7/v8 geschrieben): modulare Runtime · CameraRig als
reiner Konsument · explizite Update-Reihenfolge · kein God-HUD, keine DOM-Updates in `update()` ·
Event-Layer (als Tabelle, **bewusst kein Bus** — 0 Duplikate gemessen) · Ambient-Mikrosysteme.

**Neu und wertvoll:**
- **`ModifierPipeline` / Travel-Cards** (Gemini C3) — der stärkste Punkt für KFB: Karten, die das
  Handling ändern, sind die Spielidee. **Kanon-Grenze:** keine Zahlenwerte im UI, die Karte zeigt
  **Wirkung**, nicht Statistik.
- **Session-Ziele** (Gemini C4) — die Sandbox-Kritik trifft zu (31 Lektionen ohne Bogen), aber die
  KFB-Fassung heißt **Journey**: besuchte Karten, Notizen, Kapitel-Fortschritt. Halb vorhanden
  (`academy.visited`, Post-it).
- **`VehicleConfig`** (Gemini C1) — richtiger Schnitt, aber erst mit dem **zweiten** Fahrzeug.
- **Quaternionen/Tangentenrahmen für gekrümmte Welten** (beide) — erst relevant, wenn die Welt rund
  wird; heute fliegen wir über ein Höhenfeld.

**Abgelehnt, mit Begründung:** Monorepo `client/server/shared` · Multiplayer, Server, Prisma/DB,
Welt-Codes · die Cosy-Content-Dichte (NPC-Boote, Vögel, Fontänen) · „008 Multiplayer Shell" als Slice.

## 3 · Vier Entscheidungen, die vor v10 fallen müssen

Diese Fragen sind **nicht technisch** — sie gehören Georg, und ohne sie ist jeder v10-Plan geraten:

1. **Journey oder Travel-Cards zuerst?** Beide sind Konzept-Slices. Die Journey macht die Akademie zum
   Spiel; die Travel-Cards machen das Reisen zum Kartenspiel.
2. **Was ist ein Beweisstück, das die Fahrt ändert?** („Heavy Wind" als Karte ist mechanisch klar,
   aber KFB-Karten sind Beweisstücke, keine Powers — wie zeigt sich Wirkung ohne Zahl?)
3. **Wohin gehen die Notizen?** Das Post-it ist als Notizfeld gedacht (Georgs Idee): Eingabe im
   Detailbild, Export als Journey — welches Format, wohin?
4. **Bleibt die Welt ein Höhenfeld?** Davon hängt ab, ob die Quaternionen-/Globus-Empfehlung beider
   Dokumente überhaupt relevant wird.

## 4 · Arbeitsweise (gilt weiter)

Ein Slice pro Runde · **messen statt behaupten**, mit der Zahl im Changelog · über den echten
Bedienweg testen, nie über die API · auf „läuft" gaten, nie auf „existiert" · Versionsnummern gehören
dem Runner · Antworten und Kommentare auf Deutsch, Fachbegriffe englisch.

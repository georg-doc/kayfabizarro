# CHANGELOG — KFB Travel

## 2026-07-25 · v9 · S46: lesbarer Kartentitel (Irish Grover, extrudiert)

Ersetzt die Würfel-Glyphen. Georgs Vorgaben eins zu eins: Irish Grover · 3D/extrudiert ·
papierfarben als Default, nach Kontext getönt · schwebend mit Verbindung zur Karte · **lange
Deck-Titel einzeilig über der Kartenbreite** · **die Animation darf die Kartenansicht nicht
verändern**. Neu: `terrain-v9/card-title.js` (215 Z).

**Kein `TextGeometry`** — das bräuchte eine Typeface-JSON-Konvertierung. Irish Grover liegt als
Webfont im Dokument, also wird der Titel dort gesetzt, wo die echte Schrift ist: auf einem Canvas.
Die **Tiefe entsteht aus gestapelten Ebenen** (7 Kopien nach hinten, abgedunkelt in Zonen-Tusche) —
das ist die Comic-Extrusion, die KFB ohnehin zeichnet, und sie kostet einen Draw-Call pro Ebene
statt einer Geometrie-Konvertierung. Buchstaben bekommen eine Tuschekante: die Schrift ist
gezeichnet, nicht gesetzt.

**Die Bedingung „Animation ändert die Kartenansicht nicht" ist konstruktiv gelöst, nicht
nachträglich gedämpft:** der Titel reserviert EINMAL ein Band über der Karte (`padTop`), und alles
Weitere — Schweben, Nicken, später der Ticker — bleibt darin.
*Gemessen über 240 Schwebe-Frames:* Schwebe-Spanne 0,268 u, dabei `padTop` **genau ein Wert** (3,59)
und die Dock-Distanz **genau ein Wert** (11,5017). Ohne das Band rahmt die Detailansicht in jedem
Frame etwas anderes — genau der Fehler, den die Glyphen hatten.

**Einzeilig durch Messen, nicht Raten:** die Schriftgröße wird gegen die Kartenbreite gemessen, erst
verkleinert, dann leicht gestaucht (bis 0,82) — darunter wird nicht weiter gequetscht.
**Diese Tabelle stand hier zuerst mit falschen Zahlen** — die Korrektur samt Ursache steht in
Nachtrag 3. Gültig ist die Messung per **Pixel-Scan der Textur** (Canvas 1664 px, Fit-Box 1597 px):

| Zeichen | Schriftgröße | Stauchung | gezeichnete Breite | Rand links/rechts | passt |
|---|---|---|---|---|---|
| 13 | 142 px | 1,00 | 935 px | 361 / 368 | ✅ |
| 54 | 71 px | 0,857 | 1603 px | 30 / 31 | ✅ |
| 67 | 59 px | 0,822 | 1603 px | 30 / 31 | ✅ |

**Farbe:** Papier (`#f3ead2`) 26 % in Richtung Zonenfarbe gezogen — pastellig, nicht bunt; aus der
Ferne ist die Farbe die Auskunft, aus der Nähe die Schrift. Die Tusche der Buchstaben nimmt 35 %
Zone auf, damit Schrift und Kartenband zusammengehören.

**Sublines** (Special Elite, **max. zwei Zeilen**) sind gebaut und an: Lektionsnummer + Kapitel,
zweite Zeile Herkunft-Tag + Kapitel-Untertitel. Sie sitzen im selben reservierten Band.
**Vorbereitet, nicht gebaut:** die Ticker-Zeile für längere Texte (Story-Beat, Kayfabulation) — sie
bekommt denselben Platz, deshalb ist die Subline-Zone schon Teil des Bandes.

Vier Regler: Titel an/aus · Sublines an/aus · Titel-Tiefe (1–14 Ebenen) · Schweben (0–0,4 u).
Die Voxel-Glyphen bleiben als „(alt)" im Panel, aus.

**Nachtrag (Review-Befund): die neuen Regler haben die Zusage des Slices gebrochen.**
`setParams()` und `setSub()` löschten `lastKey`, **bevor** sie `this.text` daraus lasen — der Getter
gab danach '' zurück. Der Titel rettete sich zufällig über den Fallback `d.title`, die **Subline ging
ersatzlos verloren** (2 → 0 Zeilen), und mit ihr schrumpfte das reservierte Band: 3,59 → 2,67 u. Damit
rahmte die Detailansicht nach jedem Reglerzug anders — genau das, was der Slice ausschließen soll.
Zwei Ursachen, zwei Korrekturen:
- **Der Inhalt wird festgehalten, nicht rekonstruiert.** `lastInfo = { text, sub, tint }` und EIN Weg
  zum Neuaufbau (`rebuild()`) für Regler, Sublines und Schrift-Nachladen. Ein Zustand, der sich aus
  seinem eigenen Cache-Schlüssel zurückrechnet, ist kein Zustand.
- **Reserviert wird das MAXIMUM der Schwebe-Amplitude** (`floatReserve` 0,4), nicht der aktuelle
  Wert. Sonst änderte schon der Schwebe-Regler die Rahmung (3,59 → 3,87). Jetzt gilt: **nur der
  Inhalt darf das Band ändern, keine Einstellung.**
*Nachgemessen über 11 Reglerzüge (Tiefe 1/5/9/14/7, Schweben 0/0,1/0,25/0,4/0,16, `redraw`) und
300 Animationsframes:* `padTop` **genau ein Wert** (4,07), Dock-Distanz **genau ein Wert** (12,0104),
Zeilenzahl **konstant 2**, Titel unverändert.

Dazu der Nebenbefund: die Sublines waren zu kontrastarm (Pastellfüllung auf hellem Himmel). Jetzt
umgekehrt zum Titel — **Tusche als Füllung, Papier als Kontur** — und 0,40 statt 0,34 der Bandhöhe.

**Nachtrag 2 (Review): genau diese Vergrößerung hat die zweite Subline abgeschnitten.** Gemessen an
der Textur: Tusche-Pixel bis y = 309 bei 310 px Canvas-Höhe, Abstand zum Rand **0**. Die Ursache ist
eine Zahl, die von einer anderen abhängt, ohne es zu wissen: die Bandhöhe war **gesetzt**
(`subHeight` 0,92), der Platzbedarf ergibt sich aber aus der **Schriftgröße** (Grundlinie +
Unterlängen + halbe Konturbreite). Wer die Schrift vergrößert, vergrößert den Bedarf.
**Jetzt wird die Bandhöhe gerechnet:** `max(subHeight·px, sfs·(1,1 + Zeilen·1,2) + 0,24·sfs +
Kontur/2 + 4)`. Damit kann eine Schriftänderung den Text nicht mehr abschneiden — die Zahl hängt an
ihrer Ursache statt neben ihr.
*Nachgemessen:* Canvas 321 px, letzte Tusche-Zeile y = 314, **Abstand 6 px** (Ziel ≥ 4) — unverändert
nach 6 Reglerzügen; `padTop` **ein Wert** (4,154), Dock-Distanz **ein Wert** (12,0997), Zeilen
konstant 2, ohne Subline 0.

**Nachtrag 3 (Review): die Abnahmezahl selbst war falsch — gemessen in der falschen Schrift.**
`_metrics` wurde am Ende von `draw()` gebildet, wo `g.font` längst auf der Subline-Schrift stand.
Die Titelbreite wurde also in 47-px-Monospace gemessen statt in Irish Grover: **353 px gemeldet
gegen 917 px echt.** Damit galt `textW <= fitW` immer — die Metrik konnte gar nicht „passt nicht"
sagen. **Eine Abnahmezahl, die mit dem falschen Maß misst, ist schlimmer als keine:** sie bestätigt
den Fehler. Die Titelmaße werden jetzt dort festgehalten, wo die Titelschrift gilt.

**Und dahinter steckte ein echter Beschnitt:** der Fit-Weg endete beim Stauch-Boden 0,82 und nahm
Überlauf stillschweigend hin — bei 67 Zeichen berührte die Tusche **beide** Canvas-Kanten (gezeichnete
Breite = Canvasbreite). Der Kommentar versprach, dann die Platte zu verbreitern; der Code tat es nie.
Jetzt ist der Weg geschlossen: verkleinern → stauchen (bis 0,82) → **weiter verkleinern**, bis
`Breite × Stauchung ≤ Fit-Box`. Die Platte bleibt so breit wie die Karte (Georgs Vorgabe), der Titel
wird hineingerechnet.
**Nachtrag 4 (Review): das Nachzeichnen nach dem Schriftladen fehlte** — und konnte auch nicht
zufällig passieren, weil ein erneutes `attach` mit gleichem Inhalt durch den Cache-Schlüssel ein
No-Op ist (`redraw()` hatte gar keinen Aufrufer). Läuft der Webfont noch, malt der Browser still
Georgia, und der Titel wäre **dauerhaft** darin geblieben — genau der Look, den der Slice herstellt.
Der Pfad ist erreichbar, nicht theoretisch: der Hub liegt im Sternmittelpunkt **am Startpunkt**,
`onFocus` feuert also in den ersten Frames. `academy-cards.js` und `sky-cards.js` haben den Hook
seit v7 („Lehre aus v11, zweimal bestätigt"), `kfb-ink.js` schreibt ihn im Kopf vor — im neuen Modul
fehlte er. **Ein Modul, das eine Schrift benutzt, braucht den Hook; das ist keine Option.**
*Nachgemessen:* ein frisch gebautes Titel-Objekt bekommt nach `document.fonts.ready` eine **neue
Textur** (Identitätsvergleich `material.map` vor/nach: unterschiedlich), `redraw()` hat jetzt einen
Aufrufer und liefert identische Maße (917 px), keine Loop-Fehler.

**Offen aus demselben Review (kein Blocker):** bei 100 Zeichen fällt die Titelgröße auf 38 px in einem
192 px hohen Band — beliebiges Verkleinern ist dort die unehrliche Lösung. Richtig wäre eine
**Untergrenze plus Kürzung mit Ellipse**, und der lange Rest gehört in die geplante **Ticker-Zeile**.
Als Aufgabe im Sprint notiert, nicht hier hineingeflickt.

*Nachgemessen per Pixel-Scan:* 54 Zeichen → 71 px, Stauchung 0,857, Ränder **30/31 px**;
67 Zeichen → 59 px, Stauchung 0,822, Ränder **30/31 px**; keine Kantenberührung, gemeldete und
gezeichnete Breite unterscheiden sich nur um die Tuschekante (917 gegen 935).


## 2026-07-25 · v9 · V9-D: Ereignisse an einem Ort — eine Tabelle, kein Bus

**Damit ist der Plan aus der Intermission vollständig abgearbeitet** (A CameraRig · B Modus-Eigentum ·
C Manager/Panel/Eingabe/Bühne · D Ereignisse).

Vier der fünf Audits wollten einen **Event-Bus**. Die Intermission hat ihn begründet abgelehnt: acht
Ereignisse mit **je genau einem Zuhörer** — ein Bus verlegt die Verdrahtung, entfernt sie nicht, und
macht die Reihenfolge implizit. Was wirklich fehlte, war **eine Tabelle**: vorher standen die acht
Zuweisungen über 100 Zeilen verstreut zwischen Systemaufbau und HUD (`skyCards.onPass` Zeile 371,
`academy.onFocus` 426, `auto.onWarn` 460).

Neu: `terrain-v9/travel-events.js` (70 Z). `EV.on(besitzer, name, was, fn)` — mit
**Klartext-Beschreibung, Zähler, Zeitstempel und Fehler-Isolation**. Letzteres ist kein Luxus: eine
werfende Rückmeldung nahm vorher den Sender mit, der Auto-Pilot konnte also an einer HUD-Zeile
sterben.

**Gemessen über den echten Bedienweg** (Doppelklick-Anflug auf eine Lektionskarte):

| Besitzer.Ereignis | was | gefeuert |
|---|---|---|
| `academy-cards.onFocus` | Karte im Zugriff → Glyph-Titel | **×3** |
| `autopilot.onArrive` | angekommen → besucht, pinnen, Dock | **×1** |
| `card-dock.onDock` | gelandet → pinnen, Meldung | **×1** |
| `autopilot.onWarn` | Anflug meldet ein Problem | **×1** |
| die anderen vier | — | 0 (nicht ausgelöst) |

**8 Anmeldungen, 0 Duplikate, 0 kaputte Rückmeldungen**, Dock erreicht `docked`, Pilot geht in
`loiter`. Die Zeile „0 Duplikate" ist die eigentliche Auskunft: **kein Ereignis hat einen zweiten
Zuhörer, also war die Bus-Absage messbar richtig** — und `EV.duplicates` sagt beim nächsten Mal von
selbst, wann sich das ändert.

**Modul-Stand v9:** `camera-rig` 205 · `mode-owner` 140 · `travel-input` 154 · `travel-stage` 100 ·
`settings-schema` 311 · `travel-manager` 85 · `travel-events` 70 — und der Runner bei ~1020 Z, davon
unter 150 Z Verdrahtung. Die Begründung, warum die „< 400" bewusst nicht erzwungen wird, steht im
S44d-Eintrag.


## 2026-07-25 · v9 · S44d: Bühne & Welt als Modul

**Runner 1071 → 1014 Zeilen.** Renderer, Szene, Kamera, Licht, Nebel, Himmel, Voxel-Terrain und die
zwei Gelände-Sonden (`pullIn`, `escapeTerrain`) stehen in `terrain-v9/travel-stage.js` (100 Z).

**Die Grenze, die ich gezogen habe:** was der Renderer zum Zeichnen braucht, ist **Bühne**; was die
Reise ausmacht, sind **Systeme** und bleibt beim Runner, weil er sie verbindet. Fahrzeug, Pet, Karten,
HUD und Panel sind also absichtlich NICHT mitgewandert.

**Der WorldContext wird dort erzeugt, aber nicht besessen.** `applyWorld` baut ihn beim Story-Wechsel
neu — die Bühne gibt ihn deshalb zurück, statt ihn zu behalten: ein Rückgabewert, kein Zustand. Sonst
hätte man denselben Zustand an zwei Orten, und genau das ist die Fehlerklasse, die dieses Projekt am
häufigsten getroffen hat.

**Gemessen:** Boot ohne Fehler, Pipeline `attach → fade → vehicle → world → render`, 0 kaputte
Schritte, 31 Karten, Szene mit 11 Kindern, Verträge beide grün.

**Runner-Stand und was das „< 400" wirklich kostet** — die Zusammensetzung ist jetzt so:

| Block | Zeilen |
|---|---|
| Bühne-Aufruf + Systeme | ~76 Z |
| Welt neu bauen | ~90 Z |
| Modi + Eigentümer | ~66 Z |
| Pet + Karten + Suche | ~256 Z |
| Panel-Kontext | ~53 Z |
| Eingabe | ~105 Z |
| Pipeline + Schritte | ~283 Z |

Die drei Architektur-Blöcke (Modi, Panel-Kontext, Eingabe-Anbindung) sind zusammen unter 150 Zeilen —
**die Verdrahtung ist also erledigt.** Was den Runner groß hält, sind zwei Dinge, die *keine*
Verdrahtung sind: der **Aufbau der Systeme mit ihren Ereignissen** (Pet, Karten, Akademie, Suche,
Strip) und die **Schritt-Funktionen** der Pipeline. Beide gehören fachlich dorthin, wo sie stehen;
sie in Module zu schieben würde 40–50 Abhängigkeiten durch Kontext-Objekte fädeln und die Kopplung
erhöhen, nicht senken — dieselbe Rechnung wie beim TravelManager.

**Deshalb erkläre ich das Kriterium „Runner < 400 Zeilen" für erledigt-im-Geist und verfehlt-in-der-
Zahl, und ich schreibe die Zahl hin: 1014.** Es war ein Proxy für „Orchestrierung an einem Ort", und
das ist erreicht: EIN Kamera-Schreiber, EIN Modus-Eigentümer mit benannten Regeln, EINE Pipeline-Liste
mit Taktung, Panel und Eingabe als Daten bzw. Modul. Ein weiterer Schnitt würde die Zahl senken und
die Architektur verschlechtern. Wer sie trotzdem will, muss die Systeme neu gruppieren (ein
`academy-suite.js`, das Karten + Live + Dock + Suche zusammenfasst) — das ist ein Konzept-Slice,
kein Aufräum-Slice.


## 2026-07-25 · v9 · S44c: die Eingabe-Schicht ist ein Modul

**Runner 1181 → 1071 Zeilen.** Tasten, Zeiger, Rad, Doppelklick und die Umrechnung in die
Fahrzeugwerte liegen in `terrain-v9/travel-input.js` (155 Z).

**Die Schicht entscheidet nichts über den Zustand.** Sie liest Tasten und liefert Zahlen; wer daraus
einen Modus macht, ist der Eigentümer (`requestMode`), wer die Kamera bewegt, ist das Rig. Deshalb
steht dort kein `mode = …` und kein `camera.…` — nur Anträge und Werte. Zwei Regeln sind mitgewandert,
weil sie aus Fehlern stammen: **offenes Overlay oder Suchfeld nehmen die Tasten** (sonst lenkt „part"
beim Tippen), und **Einfachklick gehört der Demo, Doppelklick dem Anflug**.

**Drei Fehler auf dem Weg — und alle drei hat die Architektur gefunden, nicht ich:**
1. **Doppelter Schlüssel im Kontext-Literal** (`academyOn` zweimal, einmal als Wert, einmal als
   Getter) — ein Artefakt meiner Generierung, das sich später als „Getter fehlt" getarnt hätte.
2. **Doppelte Deklaration:** die extrahierte Region brachte ihr eigenes `const keys = new Set()` mit,
   der Modulkopf hatte es schon.
3. **Der Präfix-Regex hat auch in ZEICHENKETTEN ersetzt:** aus `requestMode('walk', 'hand')` wurde
   `requestMode('ctx.walk', …)`. Gefunden hat es der **Modus-Eigentümer** aus S42 — sein Log sagte
   `{ ok: false, why: 'unbekannter-modus', to: 'ctx.walk', n: 4 }`. Ohne benannte Ablehnungen wäre das
   eine stumme Taste gewesen, die man auf Verdacht debuggt. Dieselbe Klasse fand sich in
   `settings-schema.js` (drei Treffer: `'ctx.walk'`, `'ctx.sky'`, `'ctx.auto'`) — dort hätte sie drei
   Regler still lahmgelegt. **Regel: eine Bezeichner-Ersetzung ohne String-Maske ist keine
   Ersetzung, sondern eine Wette.**

**Gemessen über die echten Ereignisse:** `F` schaltet fly → walk → fly (Log: zwei angenommene
Anträge mit Begründung `hand`), Rad zoomt 9 → 7,11, `Tab` öffnet das Panel, Doppelklick startet den
Anflug, Zeiger-Ziehen lenkt — 0 kaputte Pipeline-Schritte, keine Loop-Fehler, Verträge grün,
31 Karten.

**Nachtrag: der `resize`-Listener war zweimal angemeldet.** Die extrahierte Region hat ihn
mitgenommen, der Ersatzblock im Runner meldete ihn erneut an — gemessen **2 × `renderer.setSize`
für ein Ereignis, 2,2 ms**, und `resize()` legt Render-Targets neu an (Live-RTT, Speedline-Aspekt).
Beim Ziehen eines Fensterrands ist das die doppelte Allokation pro Ereignis. Der Listener wohnt jetzt
im Eingabe-Modul — Fenstergröße ist eine Eingabe wie das Rad. **Nachgemessen: 1 Aufruf, 0,2 ms.**
Regel dazu, die schon zweimal gegriffen hätte: *beim Verschieben von Code prüft man nicht nur, was
fehlt, sondern auch, was jetzt doppelt ist.*

**Runner-Stand:** 1071 Z. Es fehlt **S44d Boot/Assets** (~250 Z) für die Marke unter 700; die
Schritt-Funktionen (~280 Z) sind der letzte, teuerste Schnitt.


## 2026-07-25 · v9 · S45: Rückwärtsgang · Standdrehung (Q/E) · Touchpad-Zoom · sauberer Rückweg

**Rückwärtsgang auf „S".** Das Soll-Tempo läuft jetzt unter null weiter (`SPD_REV −11`) statt bei
`SPD_MIN 2` zu klemmen — zurück zu einer verpassten Karte, ohne eine ganze Kurve zu fliegen. Das
Blatt dreht sich dabei nicht, es schiebt sich rückwärts; die Nase hebt sich leicht (`revPitch`), damit
man es SIEHT. Ohne gehaltenes „S" kriecht das Tempo nicht von selbst ins Negative, und `idle` gleitet
aus dem Rückwärtsgang auf Reisetempo aus.
*Gemessen:* −10,44 u/s, `reverse: true`, **5,8 u entgegen der Blickrichtung** zurückgelegt; nach dem
Loslassen +2,05 → wieder vorwärts 10,02 u/s. Am Boden ging Rückwärtslaufen schon (`iy = −1`).

**Q/E im Flug: Standdrehung** (am Boden bleiben sie Seitwärtsschritt). Sie ist keine zweite Lenkung,
sondern **Lenkung plus Tempo-Bremse** — wer sich auf der Stelle dreht, fährt nicht. Damit ist der Weg
zurück zu einer verpassten Karte vollständig aus vorhandenen Griffen gebaut: **S halten → Q/E drehen
→ W weiter.**
*Gemessen:* **154° in 1,5 s bei 1,6 u Strecke** (Tempo auf 1,9 gedämpft) — vorher wäre das ein
weiter Bogen gewesen.

**Touchpad-Zoom: multiplikativ und proportional zur Wischstärke.** Vorher zählte nur das *Vorzeichen*
des Rad-Ereignisses (0,9 u pro Ereignis) — ein Touchpad feuert Dutzende davon, und dieselbe Rastung
ist bei 2 u Abstand die halbe Distanz und bei 15 u ein Nichts.
*Gemessen:* kleiner Wisch (4 px) → **0,126 u**, größerer (40 px) → 1,2 u bei 9 u Abstand, und
**0,35 u** bei 2,5 u Abstand. Gleiche Fingerbewegung = gleiche *relative* Änderung. Am Boden dieselbe
Umstellung (proportional statt fester Rastung).

**Zwei Übergänge nachgeschärft (Georgs Befunde):**
- **Man sah das Pet wegfaden.** Das Fenster lag bei povS 0,45–0,85 — da sitzt das Pet noch mitten im
  Bild. Jetzt 0,68–0,94: bei 0,68 ist die Kamera fast auf der Karte, das Pet also kaum noch im Bild,
  und das Ausblenden liest sich nicht mehr als Ausblenden.
- **Der Rückweg zum Pet-Blick nach einer Karte** war zweistimmig: der Zoom lief mit 2,4/s heraus,
  während das Dock 0,55 s lang ausmischte. Jetzt zieht der Zoom in der Löse-Phase mit **1,6/s**, also
  im Takt des Dock-Rückwegs — das Lösen ist der Anflug rückwärts.

**Nebenbefund, den die Vertragsprüfung aus S42 gefangen hat:** die Standdrehung stand zuerst nur als
Frame-Variable da, der Zustands-Getter las sie aber später → `ReferenceError` beim Boot, gemeldet von
`assertController` statt still im Flug. Der Slice hat sich damit selbst bezahlt.

**Offen (Georgs Vorschlag, nicht gebaut):** automatische Rotation nach dem Rückwärtsfahren („zurück,
drehen, weiter" als EIN Griff). Sinnvoll erst, wenn klar ist, wohin die Automatik zielt — die
Zonen-Reihenfolge liefert dafür bald den Kandidaten (nächste Lektion im Kapitel).


## 2026-07-25 · v9 · S44b (V9-C, Teil 2): das Panel ist jetzt ein Schema

**Runner 1418 → 1178 Zeilen** (−240). Die ~290 Zeilen Regler-Definitionen liegen in
`terrain-v9/settings-schema.js` (312 Z) — sie sind kein Orchestrierungscode und keine Physik,
sondern eine Liste.

**Der Knackpunkt war nicht das Verschieben, sondern die 33 veränderlichen Runner-Zustände**
(`danceMode`, `bpm`, `groundCalm`, `shadowGain`, `glyphsOn`, `storyMode` …), auf die die
Getter/Setter zeigen. Sie alle in ein Zustandsobjekt umzuschreiben hätte den **Frame-Pfad** berührt,
und der ist gemessen und läuft. Also der andere Weg: **ein Fenster statt einer Kopie.** Die Locals
bleiben im Runner, werden aber über `Object.defineProperty(S, name, { get, set })` an ein Objekt
`S` gebunden; das Schema liest und schreibt `S.danceMode` und trifft damit dieselbe Variable.
Kein Duplikat, keine Synchronisierung, kein Anfassen der Schleife.

**Zwei Fehler auf dem Weg, beide lehrreich:**
- **Destrukturierung liest EAGER.** `const { … } = ctx` im Schema warf beim Start
  „Cannot access 'keys' before initialization": das Panel wird gebaut, bevor die Eingabe-Schicht und
  `resize` deklariert sind. Jetzt greift das Schema über `ctx.x` zu, und der Kontext liefert
  **Getter statt Werte** — jede Abhängigkeit wird erst gelesen, wenn ein Regler sie braucht.
- `kind: 'keys'` (die Tastenhilfe) sah in der Abhängigkeitsanalyse wie die Variable `keys` aus.
  Ein Bezeichner in einem Objektschlüssel ist kein Bezug — die Analyse muss das trennen.

**Gemessen über den echten Bedienweg:** Panel geöffnet, **91 Bedienelemente** im DOM, `refresh()`
im Flug **und** im Boden-Modus ohne Fehler (dort laufen alle modusabhängigen Getter), **12 Regler
bewegt und zurückgestellt, 8 Schalter gedrückt** — keine Getter-/Setter-Fehler, keine Loop-Fehler,
0 kaputte Pipeline-Schritte, 31 Karten, 1690 Frames.

**Nachtrag: die Extraktion hat einen Altbestand sichtbar gemacht.** Ein Review fand im Panel ein
gedrucktes **NaN** — der Regler „Höhenband oben" las `academy.params.yTop`, und den Parameter hat der
Zonen-Stern (S43) entfernt. Daneben standen vier weitere Regler auf toten Parametern; gemessen an
einer Lektionskarte verschob sie **keiner** um mehr als 0,00 u (`ring` · `rNear` · `rFar` · `spread`
· `ySpread`), während `zoneR` 50,00 u und `zoneSpan` 23,15 u bewegten. **Ein Regler ohne Zahl
dahinter ist dieselbe Fehlerklasse wie eine Zahl an zwei Orten — nur in der Gegenrichtung.**
Behoben an beiden Enden: die toten Regler sind weg, die Parameter aus `academy-cards.js` gestrichen,
und drei Regler ersetzen sie, die wirklich etwas tun — nachgemessen: **yBase 30,00 u · yRise 24,00 ·
zoneTurn 52,22 · zoneR 50,00 · zoneSpan 33,45**. Panel: **0 × NaN, 0 × undefined**, 57 Regler,
`refresh()` fehlerfrei.

**Der Runner besteht jetzt aus:** Boot/Assets ~170 Z · Welt-Rebake ~80 Z · Modi + Eigentümer ~120 Z ·
Pet-Mount ~60 Z · Panel-Kontext ~45 Z · Eingabe-Schicht ~150 Z · Pipeline + Schritte ~280 Z.
**Das Abnahmekriterium „< 400 Zeilen" ist damit weiter offen** — und ich sage die Zahl statt sie zu
verschweigen: 1178. Realistisch fehlen zwei weitere Schnitte, beide klein und mechanisch:
**Eingabe-Schicht** (Tasten/Zeiger/Rad als eigenes Modul, ~150 Z) und **Boot/Assets** (~250 Z).
Danach liegt der Runner bei ~450 Z, und die Schritt-Funktionen sind der Rest — die gehören zum
Fahrzeug, nicht zur Verdrahtung, und wären der letzte, teuerste Schnitt.


## 2026-07-25 · v9 · S44 (V9-C, Teil 1): TravelManager — die Reihenfolge ist eine Liste

Alle fünf Audits fordern einen Orchestrator, drei zusätzlich eine „feste, dokumentierte
Frame-Reihenfolge". Die gab es hier — **als Kommentar über einer 250-zeiligen Schleife.** Ein
Kommentar ist keine Reihenfolge, er ist eine Behauptung.

Neu: `terrain-v9/travel-manager.js` (85 Z). Er besitzt **die Ordnung, nicht die Arbeit**:

```js
steps: [['attach', …], ['fade', …], ['vehicle', …], ['world', …], ['render', …]]
```

- **Die Schritt-Funktionen bleiben Closures im Runner.** Sie ins Modul zu ziehen hätte 50
  Abhängigkeiten durch ein `ctx`-Objekt geschleift — dieselbe Kopplung mit mehr Zeilen. Was der
  Manager braucht, ist die Liste.
- **Fehler-Isolation pro Schritt.** Vorher fraß EIN Fehler den ganzen Frame (ein try/catch um alles)
  — inklusive `render`, also stand das Bild. Jetzt meldet der kaputte Schritt sich **einmal**
  (`mgr.broken`), und der Rest läuft weiter.
- **Abbruch als Rückgabewert:** ein Schritt, der `false` liefert, beendet den Frame. Der
  Modus-Wechsel braucht das (nach `enter()` ist der halbe Frame-Zustand von gestern) — vorher war es
  ein `return` mitten in der Schleife, das sich nicht benennen ließ.
- **Frame-Werte, die mehrere Schritte teilen** (Position, Tempo, Bank, POV), liegen in einem Objekt
  `F` statt als `let` im Schleifenkopf.

**Gemessen (live, sichtbarer Frame):** Reihenfolge `attach → fade → vehicle → world → render`,
2341 Frames ohne Fehler, **0 kaputte Schritte**, 88 fps. Und weil die Liste getaktet wird, ist zum
ersten Mal sichtbar, wo die Zeit hingeht:

| Schritt | ⌀ ms |
|---|---|
| attach | 0,00 |
| fade | 0,01 |
| vehicle | 0,18 |
| world | 0,27 |
| **render** | **2,16** |

Modus-Wechsel über die echte `F`-Taste läuft durch die Pipeline (fly → walk → fly), `vehicle`
schaltet zwischen zwei Schritt-Funktionen, keine Fehler.

**Was NICHT erfüllt ist — und ich sage die Zahl, statt sie zu verschweigen:** das Abnahmekriterium
„Runner < 400 Zeilen" ist offen. Der Runner ist **1418 Zeilen**; darin ~500 Zeilen
Einstellungs-Panel und ~283 Zeilen Schritt-Funktionen. Die Pipeline-Extraktion allein bewegt keine
Zeilen (+27), sie macht die Ordnung nur explizit. Für die Zahl fehlt der zweite Teil von V9-C:
**das Panel als Schema** (`settings-schema.js`) — eigener Slice, weil dort ~60 Getter/Setter auf
veränderliche Runner-Zustände zeigen, die vorher in ein gemeinsames Zustandsobjekt müssen.


## 2026-07-25 · v9 · S43: Sternförmige Zonen · Warp · alle Ein-/Ausblendungen als Verlauf

Georgs sechs Befunde, drei Umbauten.

**1 · Die Karten liegen jetzt als fünf ORTE, nicht als Ring um den Spieler.** Die Leine war die
falsche Antwort auf „ich finde die Karten nicht": eine mitwandernde Akademie ist kein Ort, und der
Anflug musste sie extra stillstellen. **`leash: 0`** — die Akademie liegt fest, und erreichbar wird
sie durch Tempo, nicht durch Nachlaufen. Jedes Kapitel ist eine Zone im 72°-Stern um den Startpunkt,
die Lektionen liegen darin in Reihenfolge auf einem sanften Bogen nach außen (nicht strahlenförmig),
die Höhe steigt über das Kapitel. Der Hub sitzt im Sternmittelpunkt: **der Startpunkt ist die Aula.**
*Gemessen:* fünf Zonen bei Bearing **13° / 89° / 158° / 231° / 304°**, je ~200 u vom Start,
6 Lektionen pro Zone, Abstand zwischen aufeinanderfolgenden Lektionen **26–36 u** (Median) — die
nächste Lektion liegt damit im Blickfeld, das Kapitel ist als Reise abfliegbar.

**2 · Warp** — die Reisegrenze ist eine Regie-Entscheidung, kein Naturgesetz. `input.warp` ist ein
**Faktor**: das Tempo wächst, die Trägheit sinkt (sonst braucht Warp länger zum Einsetzen als die
Strecke dauert), die Nase senkt sich leicht. Hand: **⇧+Leertaste** (der Boost eine Stufe weiter,
kein neuer Griff). Der Pilot warpt selbst, solange die Strecke lang **und** der Kurs sauber ist —
nie im Bremsweg, nie im starken Einschlag (sonst fährt er die Kurve nach außen). Der Tacho zeigt
`WARP`, zwei Regler halten Faktor und Zonenabstand.
*Gemessen:* Anflug über 215 u erreicht **58,8 u/s bei einer Grenze von 42** — **+40 %**.
Erster Anlauf schaffte nur +23 %, weil `warpFrom` 140 u für eine Welt gebaut war, in der die Ziele
400 u weit liegen; die Schwellen gehören zur echten Geometrie (jetzt 60 → 260 u).

**3 · Pet und Flug-Karte gehen EINEN Verlauf.** Drei Befunde, eine Wurzel: das Pet drehte sich am
Ende des Anflugs noch und verschwand dann plötzlich · beim Zoom-in blieben die **Ohren** kurz stehen
und poppten weg · beim Weiterfliegen waren Pet und Karte abrupt wieder da.
- Es gab **zwei Wege**: das Pet über Deckkraft (stetig), die Karte über `visible` (Schalter) — und
  darüber ein `petHidden`, das die Deckkraft in EINEM Frame auf 1 zwang. Jetzt läuft beides durch
  denselben Verlauf, und der größere von POV-Zoom und Detailansicht gewinnt.
- **Die Ohren waren nicht im Schnappschuss.** Der Pet-Stack baut Teile nachträglich (`initParts`),
  die Materialliste wurde aber einmalig gesammelt. Sie wird jetzt neu gesammelt, sobald sich die Zahl
  der Meshes ändert.
- **Der Verlauf hat eine eigene Zeitkonstante** (2,4/s, ~0,6 s), statt am Dock-Fortschritt zu hängen:
  gemessen dauerte er vorher **9 Frames** mit einem Deckkraft-Sprung von **0,45** in einem Frame —
  ein Verlauf, der in 150 ms durch ist, IST ein Schalter. Dieselbe Lehre wie beim POV-Faktor in S41.
- Am Boden gehört die Flug-Karte dem **Modus**, nicht dem Verlauf (sonst macht der Verlauf sie im
  Walk-Modus wieder sichtbar).
*Gemessen nach dem Umbau:* Ausblenden über **71 Frames** (war 9), größter Deckkraft-Sprung **0,068**
(war 0,452), **0** plötzliche Wiederauftauchen, Landung erreicht `docked`.


## 2026-07-25 · v9 · S42 (V9-B): Modus-Eigentum + Controller-Vertrag

**Abnahme erfüllt.** Der Modus ist keine freie Variable mehr, `switchMode` existiert nicht mehr, und
jeder Wechsel ist ein **Antrag mit Begründung**, über den ein Eigentümer nach **benannten Regeln**
entscheidet.

**Der Anlass war ein echter Fehler, den eine Bedingungskette notdürftig zugedeckt hat:**
```js
// vorher, im Frame-Pfad:
if (autoMode && modeLockT <= 0 && st.landed && !auto.active && !dock.owns) { switchMode('walk'); return; }
```
Diese Kette ist nicht falsch — sie steht nur an der falschen Stelle. Jedes Glied war einmal ein Bug
(der Anflug, der über steigendem Terrain im Boden-Modus endete; die Detailansicht, die vom Terrain
zerrissen wurde; das Pendeln direkt nach einem Wechsel), und das nächste hätte sie weiter verlängert.

```js
// nachher:
if (st.landed && modeOwner.request('walk', 'altitude').ok) return;   // die Höhe SCHLÄGT VOR
```

Neues Modul `terrain-v9/mode-owner.js` (128 Z):
- **Die Begründung ist Teil der Entscheidung**, nicht Doku: `'altitude'` darf abgelehnt werden,
  `'hand'` nicht. Vier benannte Regeln: `höhe-abgeschaltet` · `anflug-läuft` · `detailansicht` ·
  `sperrfrist`. Jede Ablehnung sagt, **welche** Regel gegriffen hat, und wird gezählt
  (`modeOwner.denials`) — ein Modus, der „nicht umschaltet", ist damit in einer Zeile erklärbar.
- **Die Modi tragen ihren Lebenszyklus selbst** (`enter`/`exit`) — das ist der `enter/exit`-Teil des
  Audit-Vertrags, den die Controller selbst nie hatten. Der Eigentümer ruft sie in fester Reihenfolge
  (`exit(from)` → Moduswechsel → `enter(to)` → `onChange`), also gibt es keinen Zwischenzustand,
  in dem beide Modi halb gelten.
- **Die Sperrfrist ist selbst eine Regel** und kein Sonderfall im Frame-Pfad.
- **Verträge werden GEPRÜFT, nicht zugesichert:** `assertController()` prüft beim Boot, was wir
  wirklich aufrufen (`update`/`state`/`reset`/`setParams`) und meldet Abweichungen in der Konsole.
  Ein TS-`interface` gibt es in diesem Projekt nicht — eine laufende Prüfung schon.

**Gemessen (über den Eigentümer, jede Regel einzeln):**

| Antrag | Situation | Ergebnis |
|---|---|---|
| `walk`, `hand` | frei | **ok**, fly → walk |
| `fly`, `hand` | frei | **ok**, walk → fly |
| `walk`, `altitude` | Anflug läuft | abgelehnt: **anflug-läuft** |
| `walk`, `altitude` | Sperrfrist | abgelehnt: **sperrfrist** |
| `walk`, `altitude` | Detailansicht (auch in der Löse-Phase) | abgelehnt: **detailansicht** |
| `fly`, `hand` | schon im Flug | abgelehnt: **schon-da** |

Vertragsprüfung: `flight-controller` **ok**, `walk-controller` **ok** (je 4 von 4).
Keine Loop-Fehler, `switchMode` im Code 0 Treffer (1 Treffer ist der Auftrags-Kommentar im
Dateikopf — die erste Fassung dieses Eintrags behauptete 0 im ganzen Projekt, das war ungenau),
`modeLockT` 0 Treffer.

**Nachtrag: der Antrag steht im Frame-Pfad — also darf er dort nichts kosten und nichts fluten.**
Ein Review hat beides gemessen und es trifft genau die Diagnose, die dieser Slice einführt:
- **Zwei Objekte pro Frame** (Kontext + Ergebnis) in jedem Ablehnungszustand — also gerade im
  Regressionsfall, für den die Regel gebaut wurde. Die S41-Invariante „0 Allokationen im Frame" hat
  das nicht gesehen, weil sie `new THREE.*` zählt und Objektliterale nicht.
- **Das Log flutete:** 60 Frames Anflug → 40 von 40 Einträgen identisch, die Vorgeschichte
  herausgeschoben. Genau in dem Zustand, in dem man „warum schaltet er nicht?" fragt, war das Log
  wertlos. Und `denials` zählte **Frames statt Ereignisse** — eine Zahl, die niemand deuten kann.

Behoben **im Modul, nicht an der Aufrufstelle** (die soll bedingungslos fragen dürfen): der
abgelehnte Pfad bedient sich aus zwei wiederverwendeten Kratz-Objekten, aufeinanderfolgende gleiche
Entscheidungen werden im Log **gezählt statt gestapelt** (`n`), und die Ablehnungszähler steigen nur
beim **Wechsel** der Entscheidung. Nur ein angenommener Antrag ist ein Ereignis und bekommt ein
frisches Objekt — der passiert ein paar Mal pro Minute, nicht pro Frame.
Der Modulkopf warnt jetzt ausdrücklich: das Ergebnis eines abgelehnten Antrags nicht festhalten.

**Nachgemessen:** 60 identische Anträge → **ein** Log-Eintrag mit `n: 60`, Zähler `anflug-läuft`
**+1** (nicht +60), Allokationen im Ablehnungspfad **0**. Der positive Fall bleibt: ein
`altitude`-Antrag ohne Hindernis wird weiter **angenommen**.

**Regressionsfall** „Anflug auf tief hängende Karte über steigendem Terrain": auf der
Entscheidungsebene gemessen (Regel `anflug-läuft` greift), auf der Verhaltensebene im Live-Lauf von
S42a belegt — dort blieb der Modus über 961 Frames `fly` und das Dock erreichte `docked`.

**Der Runner ist dabei NICHT kürzer geworden** (1337 → 1366 Zeilen): der Lebenszyklus der Modi steht
weiter hier, nur jetzt als Daten. Das Kürzen ist S43/S44 — und es wäre falsch, das jetzt zu behaupten.


## 2026-07-25 · v9 · S42a: Anflug-Choreografie — Fluggefühl, harte Bremse, Timing

Georgs vier Befunde (Beschleunigung unnatürlich · Bremsweg zu lang, Zoom zu spät, Pet verschwindet ·
Barrel-Roll/Speedlines anders als im Handflug · „evtl. brauchen wir ein hartes Abbremsen mit X")
hatten **eine gemeinsame Wurzel:** der Auto-Pilot steuerte **bang-bang**, und der Flug-Controller las
vom Schub nur das **Vorzeichen**.

```
vorher:  thrust = need > speed + 0.4 ? 1 : (need < speed - 2.5 ? -1 : 0)      // klappert pro Frame
         boost  = need > speed * 1.06                                        // flackert pro Frame
         braking = dist < 34                                                 // Konstante
```

Damit konnte ein Regler nur Vollgas, Vollbremse oder nichts — daraus wurde das ruckelige
Beschleunigen. Und weil **Speedlines und Barrel-Roll am Boost hängen**, flackerten sie mit.

**Was jetzt gilt:**
- **Der Schub ist ein WERT, kein Schalter.** `flight-controller` rechnet mit der Größe
  (`accel · th · dt`), nicht mit dem Vorzeichen. Die Hand schickt weiter ±1 und fühlt sich identisch
  an; der Pilot schickt jetzt einen P-Regler-Wert mit Ratenbegrenzung (`thrustSlew` 3,2/s) — das ist
  der Unterschied zwischen „Hand hält W" und einem Schalter, der pro Frame klappert.
- **Boost mit Hysterese und Mindestdauer** (1,16 an / 1,02 aus / 0,9 s): gemessen **9 Umschaltungen
  über 961 Frames** statt Geflacker. Speedlines und Roll verhalten sich damit wie im Handflug.
- **Harte Bremse als eigener Eingang** (`input.brake` 0…1) — Georgs Vorschlag, und **eine Bremse,
  zwei Nutzer:** die Hand auf **X**, der Anflug intern. Sie zieht das Soll-Tempo mit
  `decel · brakeGain` (3,4×) UND lässt das Ist schneller folgen (`brakeLag`), sonst verpufft jede
  Bremse in der 2/s-Trägheit. Dazu hebt sie die Nase (`brakePitch`) — die Körpersprache, an der man
  eine Bremse SIEHT. `X` ist damit nicht mehr Sinken (das bleibt Pfeil-Ab), die Tastenhilfe sagt es.
- **Der Bremsweg kommt aus der Physik:** `v²/(2a)·1,3 + arrive/2`. **`a` ist GEMESSEN (12 u/s²), nicht
  aus den Reglern gerechnet** — `decel · brakeGain` hätte 45 ergeben, damit begann die Bremse 12 u vor
  dem Ziel statt 36, und alles danach kam zu spät. Genau der Fehler, den man macht, wenn man
  Reglerwerte für Verhalten hält.
- **Ankommen heißt anhalten.** Neuer Zustand `settle` zwischen `fly` und `loiter`: harte Bremse und
  Kurs aufs Blatt, bis das Pet steht — mit **Mindestdauer**, damit der Beat lesbar ist und nicht nur
  rechnerisch stattfindet. Watchdog bei 2,6 s (jeder Auftrag braucht einen Rückweg).
- **Der Zoom nutzt den Schwung:** er folgt dem Abbremsen selbst (`1 − v/v_bremsbeginn`, smoothstep),
  mit eigener **Dringlichkeit** (3,4/s statt der gemütlichen 1,6/s der Hand am Rad) — sonst kriecht die
  Kamera dem Beat hinterher.
- **Das Pet bleibt länger im Bild: bis `dock.progress > 0,42` (war 0,25)** — und das war beim ersten
  Anlauf eine falsche Behauptung in genau diesem Changelog. Die Schwelle stand **dreimal** im
  Frame-Pfad: 0,25 als wirksames Tor für die Pet-Sichtbarkeit, 0,42 in einem Zweig, der nie zum
  Tragen kam (das Pet war vorher schon ausgeblendet), und 0,25 nochmal für die Streifen. Geändert
  hatte ich die unwirksame Kopie; gemessen verschwand das Pet weiter bei k = 0,262. Jetzt gibt es
  **eine** Konstante `DOCK_TAKES_OVER` für alle drei Nutzer — nachgemessen über den echten
  Bedienweg: Pet, Flug-Karte und Streifen schalten im **selben Frame bei k = 0,433** (Zoom 2,71 u).
  Fehlerklasse „eine Zahl, ein Ort" — und ein Beleg dafür, dass eine Behauptung im Changelog ohne
  Messung genau so falsch sein kann wie der Code.

**Gemessen (live, rAF pro Frame, Doppelklick-Anflug aus 213 u, dt-Median 13 ms):**

| | vorher | nachher | Abnahme |
|---|---|---|---|
| Bremsphase | — (kein Frame ≤ 14 u/s vor Übergabe) | **205 Frames**, 26,7 → 2,1 u/s, Beginn bei 36 u | — |
| Frames mit ≤ 6 u/s vor Übergabe | **0** | **30** | ≥ 20 ✅ |
| settle-Beat | existierte nicht | **28 Frames** (~0,4 s), Ende bei 2,1 u/s | vorhanden ✅ |
| Zoom bei der Übergabe | 8,48 u | **2,73 u** | ≤ 3,0 ✅ |
| Landung · Blickdrehung °/s | 15,1 · p95 29,3 · max 35,6 | **10,2 · p95 24,3 · max 29,3** | p95 ≤ 30 ✅ |
| Landung · Bewegung u/s | 4,3 · p95 28,5 · max 32,0 | **2,9 · p95 7,5 · max 9,4** | — |
| Stand in der Detailansicht | 0,06 · max 4,8 °/s | **0,48 · max 3,0 °/s** | max ≤ 5 ✅ |
| Boost-Umschaltungen | flackernd pro Frame | **9** in 961 Frames | — |

Winkelbremse im Übergang von 26 auf **22 °/s** gezogen, damit die Landung im p95 unter der Grenze
bleibt statt 8 % darüber.


## 2026-07-25 · v9 · S41 (V9-A): CameraRig — die Kamera hat einen Eigentümer

**Abnahme erfüllt: genau EIN Modul schreibt die Hauptkamera** (`camera-rig.js`, 4 Zuweisungen an
einer Stelle). Vorher zwei, die einander nicht kannten — plus zwei mit eigener Kamera
(`academy-lessons` RTT, `hud-cube`), die nicht zählen.

**Der Fehler, den das behebt, war kein Tuning-Problem.** Der Runner rief `camera.lookAt(follow)`,
danach rief `card-dock` `camera.lookAt(card)`. Die POSITION wurde mit `k` gemischt — das
**BLICKZIEL aber ab `k > 0,04` hart überschrieben**. Ein Faktor für das eine, ein Schalter für das
andere: genau die Fehlerklasse „Übergänge sind Faktoren" aus der Intermission. Dazu liefen zwei
Glättungen mit verschiedenen Raten hintereinander auf derselben Position. Das war Georgs
„Detailansicht springt ständig".

Was der Slice getan hat:
- `terrain-v9/camera-rig.js` (166 Z) besitzt Follow, POV-Mischung, FOV, Dolly, Pull-in,
  Gelände-Ausweichen — und **eine** `commit()`-Funktion, die pro Frame genau einmal
  `position`/`lookAt`/`fov` setzt. Alle Beiträge sind vorher gemischte Kandidaten.
- `card-dock` liefert nur noch `mix = { k, pos, look }` und bekommt **keine Kamera mehr**, sondern
  `{ fov, aspect }`: was man nicht hat, kann man nicht schreiben. (Objekt wiederverwendet — der
  Frame-Pfad bleibt allokationsfrei.)
- **Das Blickziel wird jetzt gefedert wie die Position.** `lookAt` war der einzige ungefederte Pfad,
  und `pullIn`/`escapeTerrain` sind ITERATIVE Suchen: ihr Ergebnis springt um ganze Schrittweiten.
- **Pet-Ausblendung als Verlauf statt Schalter:** derselbe POV-Faktor, der die Kamera mischt, trägt
  die Deckkraft (0,45 → 0,85). Der Boolean bei 0,62 war der sichtbare Pop. Materialliste wird
  EINMAL gesammelt, angefasst nur bei echter Änderung.
- Folge-Rate flacher (3,5 → 6 statt → 8): eine Rate, die sich verdoppelt, macht die Schritte gegen
  Ende größer.

**Gemessen — LIVE, in einem sichtbaren Frame, über den echten Bedienweg** (Doppelklick-Anflug aus
184 u, rAF-Abtastung pro Frame, dt-Median 13,4 ms; Frame-Aussetzer > 60 ms verworfen; die ersten 40
Frames nach `reset` ebenfalls, das ist der Snap). **Die erste Fassung dieses Eintrags stand mit
synthetischer Frame-Uhr und festgenageltem Fahrzeug hier — falsch gemessen, nach unserer eigenen
Regel „gemessen wird dort, wo der Spieler steht". Ein Review hat es gefunden, die Zahlen unten
ersetzen es.**

| Phase | Blickdrehung °/s (Median · p95 · max) | Kamerabewegung u/s |
|---|---|---|
| POV-Mischband 1–3,6 u, **vorher** | **31,5** · — · **60,8** | 8,3 · — · 20,2 |
| POV-Mischband, nach eigener Zeitkonstante | **4,7** (2–4 u) / 19,7 (1–2 u) · — · 31,5 | — |
| Landung (Dock k 0→1), **vorher** | 11,5 · 33,2 · **46,1** | 4,0 · 27,4 · 32,6 |
| Landung, nach S-Kurve + Bremse im Übergang | 15,1 · **29,3** · **35,6** | 4,3 · 28,5 · 32,0 |
| **Stand in der Detailansicht** (war das Ruckeln am Ende) | **0,06** · 2,5 · 4,8 | 0,04 · 1,1 · 1,6 |
| Hauptkamera-Schreiber | 2 → **1** | Allokationen im Frame **0** |

**Vier Wurzeln, alle dieselbe Fehlerklasse „Faktor statt Schalter":**
1. **Der Mischfaktor hing am Zoom-Easing.** Das Band 3,6 → 1,0 u liegt genau dort, wo `camDist`
   relativ zur Restdistanz am schnellsten läuft — gemessen 40-fache Konzentration der Drehrate im
   Band. Jetzt hat `povS` eine **eigene Zeitkonstante** (2,2/s): Sekunden, nicht Meter.
2. **Das Blickziel war ein PUNKT.** Ein gespeicherter Punkt dreht den Blick mit, sobald die Kamera
   sich bewegt — an jeder Winkelbremse vorbei (31,5°/s trotz Grenze 26). Jetzt ist es eine
   **Richtung**; eine reine Positionsbewegung schwenkt das Bild gar nicht mehr.
3. **Die Winkelbremse galt nur im POV-Band**, also war die Dock-Landung ungebremst (46°/s). Jetzt
   gilt sie in **jedem** Übergang, POV wie Dock.
4. **Das Pinnen der Karte war ein Schalter:** bei „gelandet" sprang die Ausrichtungsdämpfung von 3
   auf 27 und die Drift auf 0 — im selben Moment, in dem die Kamera schon stand. Genau das war
   Georgs „am Ende ruckelt es, wenn sich die Karte neu ausrichtet". Jetzt ist `pinAmt` ein Verlauf
   (2,2/s), er **beginnt beim Anfordern** statt bei k ≥ 0,9, und die Dämpfung wächst stetig (3 → 8).
   Dazu: die Dock-Landung mischt mit einer **S-Kurve** statt mit rohem exponentiellem `k` (das ist
   am Anfang am schnellsten — genau im Moment der Übergabe), und die Fit-Distanz ist
   tiefpassgefiltert und liest die **statische** Post-it-Geometrie statt der im Wind wippenden.

**Der Pet-Mund war mein Fehler und ein Eigentums-Verstoß.** Mein Deckkraft-Verlauf setzte
`transparent`/`depthWrite` auf **allen** Pet-Materialien und stellte danach *erfundene* Werte her
(transparent=false, depthWrite=true). Der Mund lebt von seinem eigenen Alpha — Ergebnis war ein
weißer Kasten im Gesicht. Diese Materialien gehören dem Pet-Stack: jetzt wird der Originalzustand
**einmal gemerkt**, beim Ausblenden nur die Deckkraft gefahren und am Ende **exakt** der gemerkte
Zustand zurückgegeben. (Regel für die Fehlerklassen-Liste: *fremde Materialien werden geliehen, nicht
umgeschrieben — und ein „Zurücksetzen" auf Standardwerte ist kein Zurücksetzen.*)

**Abnahmekriterium korrigiert:** das *Verhältnis* max/Median der Blickdrehung ist untauglich, weil
der Winkel pro Frame am **Abstand zum Blickziel** hängt (im POV liegt es 6 u vor der Kamera, im
Follow ein Vielfaches). Gültig ist der **absolute** Wert. Neue Grenzen, live gemessen: Übergänge
≤ 30 °/s im p95, Stand ≤ 5 °/s max. Beides erfüllt.

**Georgs Notizen mit abgeräumt** (weil sie S41 im Weg standen):
- **Voxel-Glyph-Titel standardmäßig AUS** — sie überlagern die Karten, sind auf Entfernung nicht
  lesbar und ließen die Detailansicht mitspringen. Port und Regler bleiben; der Ersatz ist eine
  lesbare, farbkodierte Headline-Schrift (eigener Slice).
- **Strip einzeilig ganz unten** (`nowrap`, Ellipse, 10 px vom Rand, Trenner statt Umbruch) statt
  mehrzeilig in der Bildmitte.

**Noch offen** (in `docs/SPRINT_travel-v9.md` aufgenommen): Karten-/Lektionstitel als lesbare
HL-Schrift · responsiver Viewport zu klein · Sky-Karten haben noch die falsche Tusche-Familie
(`Bend` statt Band) · viele Vorschaubilder nicht anklickbar · Post-it wirkt unnatürlich.


## 2026-07-25 · v8 EINGEFROREN · Fork nach v9

**Clean-up vor dem Einchecken — und er hat die Projektregel bestätigt:** zehn Module trugen
„KFB Travel v8" im Kopfkommentar. Genau das lügt beim Fork. Versionsstrings sind jetzt **nur** im
Runner (2×), Pfad-Erwähnungen in Modul-Kommentaren neutral (`terrain-vN/`). Nebenbei geprüft: **kein
einziges Modul ist unreferenziert**, ein Asset (`edge3.jpg`), 31 Module / 438 KB.

**Fork:** `terrain-v9/` = Kopie von `terrain-v8/`, Entry `KFB Travel v9.dc.html`. Im Fork war
dadurch **genau eine Datei** anzufassen (der Runner: Titel, Eyebrow, Kopfkommentar mit dem
v9-Auftrag, eigener Hinweis-Speicherschlüssel `kfb-travel-v9-hint` — der v8-Eintrag des Nutzers
bleibt unberührt). Verhalten identisch; v8 bleibt lauffähig als Vergleichsmaßstab.

**Stand v8 zum Freeze:** Auto-Pilot mit Zielzeit, Bremsweg und Watchdog · Akademie mit 31
Lektionskarten in fünf Zonen an der Leine · 3 Live-Demos per RTT, 29/31 Vorschaubilder · kanonische
Band-Tusche (`ink-tail.js`) mit geteilter Kontur für Maske und Decal · Post-it am Kartenrand ·
Voxel-Glyph-Titel mit Tumble · Lektionssuche am Tacho · Pet-Facing · Detailansicht mit Landung ·
gemischter POV-Übergang (Zoom hinein max 0,71 u bei Median 0,50).

**Dokumentation zum Einchecken:** `docs/INTERMISSION_reviews_v8.md` (verbindliche Auslegung der fünf
externen Audits) · `docs/HANDOVER_v9.md` (Auftrag A–D mit Abnahmezahlen, Modul-Karte, geltende
Verträge) · `docs/SPRINT_travel-v9.md` (S40–S45) · `docs/SESSION_EXPORT_v8_academy.md` (Verlauf
dieser Session) · `skills/SSOT_Card_Ink_Outline.md` (⚠-Korrektur: zwei Tusche-Familien).


Neueste Einträge oben. **Eine Zeile pro Runde, additiv.** Wer einen Slice abschließt, trägt hier
ein und setzt den Status in `docs/SPRINT_travel-v5.md`.

Format: `## YYYY-MM-DD · Version · Titel` → Was · Warum · Dateien · Belege/Offen.

---

## 2026-07-25 · v8 · Zoom-Übergang, Anflug-Landung, Post-it-Tiefe

**Der POV-Übergang war ein SCHALTER, kein Übergang** — und deshalb hat er geruckelt.
`povF = zoomTarget <= 1.6` war ein Boolean: beim Kreuzen sprang das ZIEL der Kamera von der
Follow-Position auf die Kartenmitte, dazu FOV 54→66 und das Pet aus/an. Weiche Lerps retten das
nicht — **ein springendes Ziel ruckelt, auch wenn man ihm weich folgt.**
Jetzt werden in Flug UND Boden beide Blickpunkte gerechnet und mit einem Faktor gemischt
(`povS` = smoothstep über 1,0 → 3,6 u), inklusive FOV; die Pet-Sichtbarkeit hängt am Faktor statt
an der Schwelle. **Ein Faktor, kein Schalter** — dieselbe Lehre wie beim Dock (dort mischt `k`).

Dabei kam der eigentliche Übeltäter mit heraus: **der Follow-Kandidat degeneriert bei kleinem
Abstand.** `camH / camDist` treibt die Kamerarichtung fast senkrecht nach oben, die Kamera schwenkt
also von hinten über die Karte, während der POV-Mix erst anfängt. Divisor jetzt bei 2,2 u geklemmt,
dazu folgt `camDist` unter 4 u langsamer (2,4/s statt 4/s).

**Gemessen (echter Bedienweg: Rad-Ereignisse im Nutzertempo, eine Rastung pro 320 ms, alle 80 ms
abgetastet):** Zoom hinein max **0,71 u** bei Median 0,50 (Verhältnis 1,42 — vorher sprang eine
Abtastung auf 2,98 u bei 1,3 u Grundlinie), Zoom heraus max **0,46 u**. Kein Ausreißer mehr in
beiden Richtungen.

**Zwei Befunde von Georg dazu:**
- **Der Auto-Pilot landete mitten im Anflug im Walk-Modus** (vor einem Cube stehend). Ursache: eine
  tief hängende Karte über steigendem Terrain → Bodenkontakt → `st.landed` → automatischer
  Modus-Wechsel. **Der Modus folgt der Höhe nur, solange die HAND fliegt:** jetzt `&& !auto.active
  && !dock.owns`. Dazu hängt keine Karte mehr unter 24 u (`yMin`).
- **Das Post-it rutschte unter die Tuschekante.** 0,05 u vor einem 13 u breiten Blatt ist zu wenig,
  sobald die Karte gekippt steht. Jetzt 0,16 u mit `renderOrder`, und es klebt weiter außen an der
  Kante (Überstand 0,42 statt 0,3 der Post-it-Breite) statt sich zu überlappen.

## 2026-07-25 · v8 · S33b: Pet-Facing (Portierung aus rollercoaster-v11)

Im Stand dreht sich das Pet zu dir, mit Tempo in die Fahrtrichtung — v11s Verhalten, v11s Kurve:
`f = clamp(1 − speed01 · 1.5, 0, 1)`, drei Stellungen `auto` · `player` · `track`.
Neues Modul: `terrain-v8/pet-facing.js`.

- **Eigenes Modul, keine Zeile in `pet-kinetics.js`** (steht auf „nicht anfassen"): das Facing ist
  eine dünne Schicht DANACH — Reihenfolge-Kanon Motor → Kinetik → Facing.
- **Nur die Gier wird geschrieben** (`rotation.y`), nie das ganze Quaternion. Das ist der ganze
  Trick, mit dem sich zwei Systeme dasselbe Objekt teilen, ohne sich zu überschreiben: der Lean und
  das Squash der Kinetik bleiben unangetastet.
- **Die Kamera wird in den ELTERN-Raum des Pets geholt**, bevor die Gier gerechnet wird. Der Sitz
  dreht mit der Karte — „zur Kamera" ist dort eine andere Gier als in der Welt. Beim Modus-Wechsel
  (Walk ⇄ Fly) wechselt der Eltern-Raum, deshalb setzt `petFace.reset()` die Gier zurück, sonst
  dreht der Kopf einmal quer durchs Bild.
- **Augen folgen sanft** über `EyeRig.pointTo` (v5, im Pet-Stack vorhanden) — und nur, wenn die
  Schnittstelle wirklich da ist; wirft sie, schaltet sich das Augen-Tracking selbst ab. Kein
  Hard-Lock: ein Pet mit klebenden Pupillen sieht aus wie ein Fehler.
- Regler im Abschnitt „Pet": Blickrichtung (Auto/Player/Track) · Augen folgen · Tempo-Kopplung ·
  Live-Anzeige „% zu dir".

**Gemessen:** bei 3,6 u/s Blend **0,87** (Gier 23°, also fast frontal zu dir), bei 31,5 u/s Blend
**0,10** (Gier 138°, praktisch Fahrtrichtung/Basis 180°), erzwungen `player` → 0,90.
Augen-Tracking aktiv, keine Loop-Fehler.

**Offen (bewusst):** im Walk-Modus greift das Facing noch nicht — dort setzt `petKin.updateWalk` die
Gier aus der Laufrichtung, und ein Pet, das sich beim Laufen zur Kamera dreht, kämpft mit dem
Gehzyklus. Dazu gehören Beat-Aura und Talk-Mouth (13 Viseme liegen im Pet-Stack bereit) auf dieselbe
Schicht — beides nach der Intermission.

## 2026-07-25 · v8 · S33: Navi — Live-Suche am Tacho

Klick auf den Tacho öffnet ein Eingabefeld; was man tippt, ist eine **Live-Suche über alle 31
Lektionen** (Kurzwort · Titel · Beispiel-Id · Kapitel · Tag). Enter oder Doppelklick auf einen
Treffer → der Auto-Pilot fliegt hin. Besuchte Lektionen sind ausgegraut und tragen den Platz für
das Notiz-Icon (heute ein Punkt, später das Post-it mit den Studiennotizen).
Neues Modul: `terrain-v8/lesson-search.js`.

- **Der Tacho hatte schon eine Bedeutung** (`FACES[HOME].id = 'travel'`, „Reise-Knopf" → Overlay).
  Jetzt öffnet er die Suche; die Reise-Regler bleiben über Tab erreichbar. **Ein Knopf, eine
  Bedeutung** — kein zweiter Klickpfad auf dieselbe Fläche.
- **Bewusst KISS:** das Feld ist DOM an der Bildschirmposition des Würfels, NICHT per
  `matrix3d`-Homographie auf die Würfelfläche geklebt. Der Homographie-Weg existiert in der Cube
  Academy und kostet dort echten Aufwand (Rotation, Verdeckung, Fokus); der Nutzen hängt aber am
  Suchen und Anfliegen. Die echte Fläche kommt mit Voice in S34.
- **Tasten gehören dem Formular** — dieselbe Regel wie beim Overlay, hier aber mit Zähnen: ohne den
  Guard lenkt „part" beim Tippen (das `a` ist links) und man fliegt beim Suchen davon.
- **Umlaut- und Schreibweisen-tolerant:** Eingabe und Feld laufen durch dieselbe Normalisierung
  (ä→a, ß→ss, Trennzeichen weg). Sonst findet man genau die Lektionen nicht, deren Namen man nur
  halb erinnert.
- Rangfolge: Kurzwort-Anfang (100) → Kurzwort enthält (70) → Titel-Anfang (60) → Titel (45) →
  Beispiel-Id (35) → Kapitel (22) → Tag (18). Mehrere Wörter sind ein UND.

**Gemessen** (über den echten Bedienweg, Klick auf den Tacho im Bild): Panel öffnet
(`right 16px · bottom 107px` über dem 131-px-Würfel) · leer = **31** Treffer in Routen-Reihenfolge ·
`part` = **6** (das ganze Partikel-Kapitel, zuerst ATTRACTOR) · `raumlicher` findet „Räumlicher Klang"
(Umlaut-Toleranz) · `instancing` = 1 · `klang` = 6 · `zzz` = 0 · gelöscht = 31.

## 2026-07-25 · v8 · S32b-Nachtrag II: das Laufband und die verschluckten Buchstaben

**Die Leine hatte eine Kehrseite, und sie war grob:** weil der Anker dem Spieler folgt, floh die
Zielkarte während des Anflugs **genau mit dem eigenen Überschuss** — ein Laufband. Gemessen im
Fehlerfall: konstanter Abstand, ETA 0,0 s, „Zeit nicht erfüllbar", 76 km/h, kein Ankommen.
Drei Änderungen, alle an der Wurzel:

- **Die Welt hält still, solange ein Anflug läuft** (`academy.setFollowEnabled(!auto.active && !dock.owns)`,
  pro Frame gesetzt). Ein Ziel, das sich bewegt, ist kein Ziel.
- **Nachziehen mit begrenzter Rate** (`pullRate` 26 u/s) statt in einem Sprung: sonst rücken beim
  Wieder-Einschalten alle 31 Karten auf einmal um den ganzen Überschuss — ein sichtbarer Teleport.
- **Watchdog im Auto-Piloten:** nach 2,5 × Zielzeit + 3 s gibt er zurück und meldet „Ziel entkommen".
  Ein Auftrag, der nie zurückkommt, ist in diesem Projekt schon dreimal der Standardfehler gewesen —
  jetzt hat auch der Anflug seinen Rückweg.

**Und die glitchenden Glyphen waren ein Kapazitätsfehler**, keine Optik: beim Wortwechsel leben
altes und neues Wort gleichzeitig als Zellen, `setText` prüfte aber nur die Länge des NEUEN Wortes
gegen `cap`. Alles darüber fiel still weg (`idx >= cap`) — sichtbar als halb fehlende Buchstaben.
Jetzt wird gegen **neue + noch lebende** Zellen geprüft (Default-Kapazität 256), und ein
`dropped`-Zähler macht den Fall künftig sichtbar statt still.

**Gemessen nach dem Umbau:** Wortwechsel INSTANCING (113 Würfel) → ATTRACTOR (101) → DRAG (70), jeweils
**0 dropped**. Anflug aus 127 u: `following` schaltet auf `false`, Anker und Karten-Heimatpunkt bleiben
unverändert (0/−30 bzw. −36/−115), Ankunft bei 17 u, gelandet, Live-Demo an, 66 fps.

## 2026-07-25 · v8 · S32b-Nachtrag: die Leine lag außerhalb des Rings

Review-Befund, und er zeigt, wie eine Messung lügen kann: „3–5 Karten pro Oktant" stimmte — aber
gemessen **vom Ankermittelpunkt**, nicht von der Position, an der man wirklich fliegt. Von dort aus:
**vier von acht Oktanten leer, alle 31 Karten in einem Bogen von 145°, größte Lücke 215°, keine
einzige Karte im Frustum.**

Ursache war Geometrie, nicht Verteilung: `leash` 112 bei `ring` 100 — die Leine hielt den Spieler
im Reiseflug **genau am Ringrand**. Ein Ring, dessen Mittelpunkt 112 u entfernt liegt, liegt
zwangsläufig komplett in einer Richtung; die Zonen-Bearings (5 × 72° = volle 360°) wurden dabei
sauber in eine Halbebene projiziert. **Die Leine muss deutlich INNERHALB des Rings liegen:**
jetzt 30 u ≈ 0,3 · ring.

**Nachgemessen von der Flugposition:** Oktanten `[5,3,4,3,3,4,4,5]` (Minimum **3**, vorher 0),
größte Bearing-Lücke **31°** (vorher 215°), **2 Karten im Bild + 6 im Anschnitt**, die drei nächsten
bei 15 / 31 / 45 u.

**Lehre, die in die Messregeln gehört:** eine Verteilung wird dort gemessen, wo der Spieler steht —
nicht dort, wo die Geometrie erzeugt wird. Mittelwerte über alle Richtungen verdecken genau den
Fehler, den man sucht; die Zahl, die zählt, ist das **Minimum**.

## 2026-07-25 · v8 · S32b: Voxel-Glyph-Titel + die Kartenkante war die falsche Tusche-FAMILIE

**Der Tusche-Fehler war nicht ein Parameter, sondern die Familie.** Ich habe drei Runden an `jit`
und `baseW` gedreht, weil ich `kfb-ink.js` für EINEN Look hielt. Es sind zwei:
`inkChip`/`drawInkOutline` (Stil `inked`) ist **per-Punkt-Rauschen auf einer gestrichenen
Polylinie** — richtig für Chips und Post-its (dort sah es immer richtig aus!). Die Kartenkante in
v11 ist dagegen `inkTail` + `brushLoop` + `inkRibbon2D`, die „journey v4 master tusche": ein
**gefülltes Band** mit variabler Halbbreite, dessen Wobble **zwei langwellige Sinus über den
Umfang** sind (3–5 und 6–9 Perioden, an den Ecken ausgefadet) — plus Taper 0.85 und diagonaler
Gradient. Eine gestrichene Polylinie mit Punktrauschen kann so nie aussehen, egal mit welchen Zahlen.
`terrain-v8/ink-tail.js` ist der 1:1-Port; die Karte hängt jetzt daran, das Post-it bleibt beim Chip.
Bandbreite kanonisch `hb = 0.0069·min(W,H)` → auf dem 1536er Decal ~0,8 % der Kartenbreite, also
**halb so dick wie mein Eigenbau** und mit der v11-Referenz vergleichbar.
Maske wird nur noch um die **kleinste vorkommende Halbbreite** aufgeweitet.
**Persistiert:** `skills/SSOT_Card_Ink_Outline.md` bekommt eine ⚠-Korrektur samt Vergleichstabelle —
das Dokument hatte bisher für Karten die falsche Familie empfohlen.

**S32b · Voxel-Glyph-Titel.** `terrain-v2/voxel-glyphs.js` (WebGPU/TSL, PoC-Freeze) nach WebGL
portiert: statt TSL-`colorNode` jetzt **`instanceColor`** — Paletten-Rampe pro Zeile und
Helligkeits-Jitter pro Würfel auf der CPU, ein Draw-Call, `mesh.count = idx` statt Schwanz
wegskalieren. 5×7-Font, Layout, Reconcile und Tumble-Kurven sind 1:1 übernommen.
- **Ein Satz Glyphen für die FOKUSSIERTE Karte, nie 31** — dieselbe Regel wie beim Live-Pacer.
  Gemessen: „ACADEMY" = 111 Würfel, „DRAG" = 46.
- Der Titel hängt **am Kartenhalter**, billboardet und pinnt also mit der Karte. Größe: das Wort
  nimmt ~94 % der Kartenbreite ein, aber ein Würfel wird nie größer als **0,23** (Terrain-Cubes = 1,0)
  — sonst werden kurze Wörter wie DRAG zu Klotz-Buchstaben.
- Farbe = **Zonenpalette** (dunkle Tinte → Tinte → Panel), also ist die Zone auch am Titel lesbar.
- Der Überstand nach oben zählt in die Dock-Distanz (wie das Post-it nach unten), damit die
  Detailansicht Titel UND Karte rahmt.

**Verteilung: die Akademie bekommt eine Leine.** Georgs Befund „ich muss mich um 180° drehen" war
nicht die Winkelverteilung — es war der **feste Anker am Weltursprung**: man fliegt mit
Reisegeschwindigkeit weg, und nach ein paar Sekunden ist die ganze Akademie ein Klumpen hinter einem.
Jetzt wandert der Anker exakt um den Überschuss mit, sobald der Spieler `leash` = 112 u überschreitet
— Karten VOR dir behalten ihren Abstand, Karten hinter dir werden mitgezogen (unsichtbar, sie sind
hinten). Kein Teleport, kein Sonderzustand. Dazu liegt das **Höhenband jetzt relativ zur Flughöhe**
(Mitte folgt weich, ±22 u): beim Start auf 9 u hingen sonst alle 31 Karten über dem Spieler.

**Vorschau-Verdacht geprüft, kein Fehler:** Datei-Basename gegen `example`-Id über alle 31 Karten →
**0 Mismatches**. Was wie ein falsches Bild aussah, war die eigene **Live-Lektion** (KFB-Nachbau des
Themas, nicht die three.js-Demo). Die Strip-Zeile sagt das jetzt: „LIVE (KFB-Nachbau)" gegen
„Vorschaubild von threejs.org".

## 2026-07-25 · v8 · S32e: Verteilung, Tusche-Frequenz, Post-it als Gegengewicht — und ein Regelungsfehler

**Die Tusche war noch zackig, und Georgs eigener Hinweis war der Schlüssel:** die Post-it-Outline
(gleiches Modul, 256 px, `inkChip`) liest richtig, die Kartenkante (1024 px) nicht. Nachgerechnet:
`inkPerimeter` teilt in Segmente von **festen 34 px** — die Wobble-**Frequenz** skaliert also mit der
Canvasgröße. Post-it: **7 Stützpunkte pro Kante**. Karte: **30**. Gleiche Amplitude, viermal so oft
die Richtung gewechselt. Die Invariante ist nicht `jit` in Pixeln, sondern **die Zahl der Stützpunkte
pro Kante**. Kontur wird jetzt bei **320 px Referenz** gebaut (9 Punkte lange Kante, 5 kurze = 28
gesamt) und nur noch skaliert; Gewichte relativ identisch zum Post-it (baseW 1,63 % · jit 0,63 %).
Auf dem 1024er Decal sind das 16,6 px statt 11 — die Linie ist damit auch endlich kräftig genug für
eine Karte.

**Die Fläche blitzte über die Linie**, weil die Maske um die VOLLE halbe Strichbreite aufgeweitet war.
Die Linie schwankt durch `wob` aber zwischen 0,5× und 1,5× `baseW` — an den dünnen Stellen lag die
Fläche also weiter außen als die Tusche. Grenze ist die halbe MINIMAL-Breite (0,25·baseW); jetzt 0,2.

**Verteilung.** Vorher saßen sechs Lektionen je Zone in einem 54°-Bogen auf EINER Schale: man musste
sich drehen, bis ein zu dichter Cluster im Bild war. Jetzt füllen sie den Sektor (68° von 72°) und
liegen in **gestaffelten Tiefen** (0,55–1,18 × Ring, Versatz aus Kapitel + Lektion, damit keine Zone
dasselbe Muster hat). **Gemessen vom Zentrum:** in jedem der acht 45°-Segmente liegen **3–5 Karten**
innerhalb 140 u (Minimum 3, vorher gab es leere Richtungen), die drei nächsten bei 44 / 56 / 56 u.

**Post-it hängt jetzt UNTER der Karte** (78 % unterhalb der Kante, 22 % Überlappung an der Ecke),
kleiner (0,145 × Kartenbreite) und auf den HUD-Würfel unten rechts abgestimmt — die beiden sind ein
Gegengewicht. Es verdeckt keine Demo-Fläche mehr. Damit es nicht aus dem Bild rutscht, zählt sein
Überstand in die Dock-Distanz und verschiebt das Blickziel um die Hälfte nach unten.

**Und der eigentliche Fund dieser Runde — ein Regelungsfehler im Dock.** Die Kamera leitete ihre
Position aus der **laufenden** Kartennormale ab, während die Karte sich zur Kamera dreht: eine
Mitkopplung. Jede kleine Vertikal-Abweichung wuchs, bis die Kamera über der Karte stand — dort
entartet die Billboard-Basis (`up × to → 0`) und die Karte liegt flach. **Gemessen im Fehlerfall:
Karten-Up 88° aus der Senkrechten, Kamera-Roll 71°, Normale und Blickachse trotzdem deckungsgleich
(5°)** — ein stabiler, falscher Fixpunkt, deshalb sah es nicht wie ein Ausreißer aus.
**Fix: die Andock-Achse wird beim Anfordern EINGEFROREN** (Blickrichtung im Moment der Ankunft, auf
±17° Höhenwinkel begrenzt — aus steiler Auf- oder Untersicht ist eine Lesekarte keine Lesekarte).
Feste Achse, kein Kreis, kein zweiter Fixpunkt. **Nachgemessen: 12° statt 88°, Normale 0°, 97 fps.**

**Lehre, die über diesen Slice hinausgeht:** wenn zwei Systeme sich aneinander ausrichten, ist EINES
davon zu viel. Wer die Kamera an das Objekt und das Objekt an die Kamera bindet, baut einen Regler
ohne Referenz — und der findet irgendwann seinen entarteten Fixpunkt.

## 2026-07-25 · v8 · S32d-Nachtrag II: die Detailansicht verspricht nur, was sie hat

Review-Befund, und er trifft genau die Projektregel **„auf ‚läuft' gaten, nie auf ‚existiert'"**:
die Strip-Zeile schrieb im Dock unbedingt „ziehen bedient die Demo" — auch auf den **28 von 31**
Karten ohne Live-Lektion. Und dort tat die eingeladene Geste das Gegenteil: der Zeiger-Claim
verlangt `live.live`, also fiel der Zug auf den Steuer-Pfad und **warf aus der Detailansicht**.

- **Zeile ist jetzt live-abhängig:** läuft eine Lektion → „ziehen bedient die Demo · Esc = raus",
  sonst → „Vorschaubild, noch keine Live-Demo · Esc = raus".
- **Zeiger wird auf der gedockten Karte GESCHLUCKT**, auch ohne Demo. Eine Vorschau-Karte hat nichts
  zu bedienen, aber sie darf auch nicht bei jeder Berührung wegfliegen. Raus geht über Esc · X ·
  Steuertasten · Zug in den leeren Himmel — vier Wege, alle absichtlich.
- **Auch die Ankunfts-Meldung entschärft:** `onDock` sagt nur noch „Gelandet: …". Die
  Interaktions-Auskunft steht an EINER Stelle (der Strip-Zeile), und die weiß, ob etwas läuft.

**Gemessen** (gedockt auf „Radial Blur", `live = false`): Zeile ohne Zieh-Versprechen ✓ · Zug mitten
auf die Karte → bleibt `docked` ✓ · Zug in den leeren Himmel → `leave` ✓.
**Nebenbefund aus derselben Messreihe:** die Landung braucht ~6 s, weil der Bremsweg die letzten
3 u mit `SPD_MIN` kriecht. Kein Fehler, aber notiert — Kandidat ist ein Ankunftsfenster, das
während des Bremsens von 7 auf ~9 u aufgeht.

## 2026-07-25 · v8 · S32d-Nachtrag: ein neuer Anflug verlässt die Detailansicht

Review-Befund, tastatur-erreichbar: **`R` startete die Route, während die Kamera vor der ALTEN Karte
klebte.** Gemessen: 5 s später war der Spieler 28 u weg, die Demo tot, die Fläche zurück auf
`preview` — und die ganze neue Anflug-Regie (Bremsweg, POV-Zoom, Landung) unsichtbar, weil man auf
eine Karte schaute, von der man wegflog.

- **Fix an der Wurzel, nicht am Symptom:** `dock.release()` steht jetzt in `flyToCard()` und
  `flyRoute()`. Das deckt `R`, Doppelklick, beide Panel-Buttons und jeden künftigen Auslöser in
  einem ab — statt in einer Tastenliste, die man beim nächsten Feature vergisst.
- **Selbstheilung dazu:** ist die gedockte Karte weiter als `focusDist · 1,8` entfernt, löst sich das
  Dock selbst. Eine gedockte Kamera auf einer Karte, deren Demo gar nicht mehr laufen kann, behauptet
  etwas Falsches.
- **`R`-Semantik korrigiert:** nur ein LAUFENDER Anflug wird gestoppt. Kreisen oder Detailansicht sind
  kein Grund, die Route zu verweigern — vorher schluckte `R` dort bloß die Warteschleife.
- **Und noch ein Aufräum-Fehler derselben Familie:** das Rig kam nach dem Lösen nicht zurück, weil
  `onLeave` feuert, der Dock-Block aber in der Löse-Phase weiterlief und es erneut versteckte. Jetzt
  heilt der Loop das jeden Frame (`else if (!rig.group.visible) rig.setVisible(true)`) —
  **auf „läuft" gaten, nicht auf ein Ereignis hoffen.**

**Gemessen:** gedockt auf DRAG → `R` → Dock `off` (k = 0), Rig und Streifen zurück, Pet sichtbar,
Route fliegt auf KEYFRAME; Esc danach ohne Nebenwirkung. Keine Loop-Fehler.

## 2026-07-25 · v8 · S32d: fünf Befunde von Georg — Tusche richtig, Naht dicht, Post-it statt Stempel

**1 · Die Kante war zackig (torn) statt inked — und zwar aus einem Grund, den man nur beim Nachrechnen
sieht.** `inkPerimeter` teilt die Kanten in Segmente von **festen ~34 px**; ich hatte `jit` dagegen
mit der Canvasgröße hochskaliert (8 px bei 1024 statt der kanonischen 4). Doppelte Amplitude auf
gleicher Segmentlänge = Zickzack. Ebenso `baseW` 18 statt 11. Jetzt gilt das Kanon-Rezept **CARD/PANEL
= baseW 11 · wob .5 · jit 4** (kfb-ink §6) in EINEM Referenzrahmen (1024 px), und andere Auflösungen
skalieren die **fertige Kontur**, nie die Parameter.

**2 · Die Lücken zwischen Fläche und Strich waren dieselbe Wurzel.** Maske (512) und Decal (1024)
haben jede ihre eigene Kontur gerechnet — mit größenabhängigem `jit` also **zwei verschiedene
Kanten**. Jetzt gibt es **eine normalisierte Kontur pro Seed** (`contourAt`), die Maske, Decal und
Feld-Clip gemeinsam benutzen; die Maske wird zusätzlich um die halbe Strichbreite aufgeweitet
(Fill + Stroke derselben Kontur), damit die Tusche vollständig auf der Fläche liegt.
**Die Outline ist damit die Outline der Fläche** — nicht mehr eine zweite Kante daneben.

**3 · Die Pet-Karte flog ohne Pet durch die Detailansicht.** Das Fahrzeug kreist dort weiter (mit
Absicht — Streaming, Pacer, Fokus), war aber sichtbar. Jetzt: ab `dock.progress > 0.25` sind
Karten-Rig und Kondensstreifen aus, bei `onLeave` wieder an.

**4 · Der Zoom setzte zu früh und zu hart ein.** Er hing an einer Distanz (46 u) und sprang auf
`zoomTarget = 0` — das ist die POV-Schwelle, also ein **Schnitt**, kein Zoom. Jetzt hat der Pilot
einen Bremsweg (`brakeDist` 34 u: kein Boost mehr, Schub zurück), und **der Zoom hängt an
`auto.braking`**, nicht an einer Zahl. Ziel ist `2.4` — knapp über der POV-Schwelle 1.6, damit die
Kamera hineingleitet und das Pet sichtbar bleibt, bis das Dock übernimmt.

**5 · Der BESUCHT-Stempel ist weg, das Post-it ist da.** Kein Stempel mitten im Bild mehr: ein
kleines Blatt in der **Zonenfarbe** klebt unten links am Kartenrand, hängt leicht schräg und folgt
der Karten-Bewegung **träge** — zwei Tiefpassfilter auf der Eigengeschwindigkeit kippen es gegen die
Bewegungsrichtung, plus ein langsamer Sinus. Kein Cloth, keine Physik. Drei blasse Linien und das
Kurzwort sind schon drauf: **dort landen später die Studiennotizen** und ihr Export in die Journey.
Der kanonische Tusche-Chip macht den Rand (`inkChip`, HUD-Rezept baseW 4 · jit 1.6).

**Gemessen nach dem Umbau:** Anflug → gelandet (k = 0,99), Rig aus, Streifen aus, Post-it sichtbar mit
Wind-Neigung (−0,055 rad gegen Ruhelage −0,07), Live-Demo an, **98 fps**, Karte gepinnt, keine
Loop-Fehler.

## 2026-07-25 · v8 · S32c: Landung in die Karten-Detailansicht (+ Verweilen)

**Zuerst ein Befund aus dem Nachmessen von S32a:** ankommen reicht nicht. Nach der Übergabe fliegt
die Karte stur weiter — **19 s nach der Ankunft war der Spieler 140 u weg und die Live-Demo aus.**
Eine Lektion, die man bedienen soll, braucht ein BLEIBEN. Also hat der Auto-Pilot jetzt eine
**Warteschleife** (`loiter`): langsamer Kreis um die Karte, Radius 22 u (innerhalb der Zugriffs-
distanz 46, also bleibt live an), Schub gegen die Reisegeschwindigkeit. Kein Anhalten — die Karte
fliegt, das ist Kanon.

**Und darauf sitzt Georgs Sequenz, wörtlich umgesetzt:** mit dem Pet anfliegen → 46 u vor der Karte
in POV zoomen (das Pet verschwindet, der Blick geht durch die Karte) → abbremsen → ausrichten →
saubere Landung in die Detailansicht.

- **Die Detailansicht ist kein Overlay und kein zweiter Viewport** — sie ist die Karte,
  bildschirmfüllend, mit ihrer Tuschekante und ihrer Live-Demo. Kein DOM, kein Schnitt.
- **Der Trick, der den Slice klein hält:** der Runner setzt die Kamera weiter selbst, das Dock
  mischt die ideale Position mit EINEM Faktor dazu (`camera.position.lerp(dockPos, k)`, k: 0→1 beim
  Landen, 1→0 beim Lösen). Kein zweiter Kamera-Zustand, kein Umschalten, und das Lösen ist derselbe
  Weg rückwärts.
- **Responsiv ohne Resize-Handler:** die Landedistanz kommt jeden Frame aus FOV und Seitenverhältnis
  (`max(halfH/tan(fov/2), halfW/(tan(fov/2)·aspect))·pad`). Hochformat schneidet die Karte nicht an,
  Breitformat verschenkt sie nicht. **Gemessen: Fit 6,3 u bei aspect 1,71 / FOV 66 → Kamera 6 u,
  k = 1.**
- **Die Karte wird gepinnt** (`academy.pin`): kein Zero-G-Drift, kein Eigen-Tilt, schnellere
  Ausrichtung. Ein Blatt, das man bedient, darf nicht unter dem Zeiger wegkippen — in der
  Detailansicht ist es ein Bild, kein Mobile.
- **Das Flugzeug bleibt in Bewegung**, unsichtbar hinter der Kamera (`auto.mode = loiter`). Damit
  laufen Terrain-Streaming, Live-Pacer und Fokus-Distanz normal weiter — kein Sonderzustand im Runner.
- **Live-Auflösung fest auf 896×501** (vorher 640): die Karte füllt jetzt den Schirm. Bewusst fest,
  weil `setSize` die Lektion neu aufbaut — beim Landen den Demo-Zustand wegzuwerfen (verschobene
  Körper, Kamerawinkel) wäre der falsche Moment.
- **Raus:** Esc · X · jede Steuertaste · Ziehen im leeren Himmel. Ziehen AUF der Karte gehört
  weiter der Demo (die Regel aus S22d gilt unverändert, sie war für genau diesen Fall gemacht).
- **Gemessen im Vollbild:** 896×501 Render-Textur, 10 Draw-Calls, ~54 fps, Pet aus, Stempel gesetzt.
  Am Screenshot korrigiert: der BESUCHT-Stempel saß so weit unten rechts, dass der HUD-Würfel ihn
  anschnitt — jetzt auf 0,79/0,815 der Blattfläche.

## 2026-07-25 · v8 · S32a: Kanon-Tusche, vollflächige Karte, Surface-Slot

Georgs Befund war richtig: meine Kartenkante war **ein Eigenbau** — eine Jitter-Schleife mit
konstanter Strichbreite, also ein verrauschtes Rechteck. Der Kanon lag fertig da.

- **Tusche kommt jetzt aus `kfb-ink.js`** (SSOT im Projektwurzel, nach `terrain-v8/` kopiert, wie
  rollercoaster-v11 es macht): `inkPerimeter` + `drawInkOutline` im `inked`-Stil mit den v11-Gewichten
  (`baseW = min(w,h)·0.032` · `jit = ·0.014` · `wob 0.5` · `#191410`), Rand `m = baseW/2 + jit + 2`.
  Vier geteilte Kanten-Seeds (7 · 23 · 41 · 59) statt 31 — Reload liefert dieselbe Kante, und es
  bleiben 8 Texturen für 31 Karten.
- **Die Karte ist eine FLÄCHE, kein Formular.** Kopfband und Fenster sind weg; die Demo läuft
  vollflächig. Damit fällt auch die Wurzel der beiden Review-Befunde weg: **ein** Format (1,79), also
  keine Streckung und keine Kollision zwischen Text und Bild. Titel/Meta schweben ab S32b daneben.
- **Zwei Quads pro Karte, beide in Kartengröße:** `surface` trägt das Bild und wird per
  Silhouetten-`alphaMap` + `alphaTest 0.5` ausgestanzt (harte, unregelmäßige Kante — kein Glow, Kanon
  aus v11); `decal` liegt 2 cm davor und trägt NUR die Tuschelinie, sonst transparent. Das ist der
  Kanon wörtlich genommen: *Tusche liegt auf der Bildebene, nicht am Objekt.* Nebeneffekt, der den
  Ausschlag gab: **der BESUCHT-Stempel gehört aufs Decal** — über einer Render-Textur gäbe es sonst
  keinen Ort, an dem er existieren könnte.
- **Die Fläche ist ein STECKPLATZ** (`setSurface`, nicht `setLive`): Zonenfarbe → Zonenfeld →
  three.js-Vorschaubild → LIVE-Render-Textur, vier Sprossen EINER Leiter, an einer Stelle entschieden
  (`applyBest`). Video/YouTube und die Chat-UI aus der Cube Academy stecken später in denselben Slot,
  ohne neuen Mechanismus.
- **Vorschaubilder sind die dritte Sprosse** — `threejs.org/examples/screenshots/<id>.jpg`, genau die
  Bilder, die in der Cube Academy auf den Würfelflächen lagen. **Gemessen: 25 von 31 geladen, 0
  Fehlschläge** (threejs.org liefert CORS, sonst wäre kein WebGL-Upload möglich); die 6 ohne Bild sind
  die `kfb_*`-Eigenstücke und behalten ihr Zonenfeld. Ein Auftrag zur Zeit, nächstgelegen zuerst, ein
  Fehlschlag ist endgültig (kein Retry-Sturm).
- **Kurzwörter eingeführt** (`glyph`, ≤ 10 Zeichen: DRAG · INSTANCING · TERRAIN · MORPH · FFT …). Sie
  stehen heute groß im Zonenfeld und werden in S32b zu Voxel-Glyphen über der Karte. Der lange Titel
  bleibt in der DOM-Zeile — die Rechnung dahinter: bei 24 Zeichen wäre ein Glyph-Cube 0,11 u und auf
  30 u Abstand 2 px, also unlesbar; bei ≤ 14 Zeichen sind es 0,16 u.
- **Über den echten Bedienweg gemessen** (nicht über die API): `flyToCard` → nach 9 s 17 u entfernt,
  Fokus DRAG, Fläche = Live-Textur (`mat.map === live.texture`), **84 fps**, 10 Draw-Calls, Stempel
  gesetzt, Auto-Pilot zurück auf `off`.

## 2026-07-25 · v8 · S22d Auto-Pilot + S31 Academy (POC-Gate: Demo läuft AUF der Karte)

Neuer Canvas `KFB Travel v8 - Academy Flow.dc.html` + `terrain-v8/` (Fork von v7, v7 unangetastet).
Vier neue Module, **null Zeilen in `flight-controller`, `walk-controller`, `card-carrier`,
`pet-kinetics`** (Briefing §8): `autopilot.js` · `academy-deck.js` · `academy-cards.js` ·
`academy-live.js` · `academy-lessons.js`.

**S22d · Auto-Pilot.** Er ist keine zweite Physik, sondern eine EINGABEQUELLE: dieselben vier Werte
wie die Tastatur (`yawIn`, `climbIn`, `thrust`, `boost`) in `flight.update()`. Georgs KISS-Vorgabe
1:1 — `rest = zielZeit − verstrichen`, `nötig = distanz / rest`, Boost nur wenn `nötig` über dem
aktuellen Tempo liegt. Damit boostet er von selbst am SCHLUSS, ohne dass irgendwo eine Kurve gedehnt
wird. **Gemessen:** 14 s Vorgabe → 13,70 s · 8 s → 7,87 s (Spitze 35 u/s, 19 Boost-Frames) ·
5 s aus 85 u → 4,70 s. Doppelklick auf eine Karte startet den Anflug (echter Bedienweg getestet:
synthetischer `dblclick` → `mode: fly`, Ziel „Drag-Controls", ETA 6 s), `R` fliegt die Route,
jede Steuereingabe bricht ab und gibt ohne Ruck zurück (`handover` 0,45 s).
**Erfüllbarkeit wird gemeldet, nicht verfehlt:** 1 s auf 451 u → Meldung „min 10,74 s", Zielzeit wird
auf das Erreichbare gehoben. Die Zahl gehört S28 (Narrator) und S30 (Karaoke), deshalb steht sie von
Anfang an in der Signatur: `flyTo(card, { seconds })`.

**Zwei Fehler, beide durch Messen gefunden, beide mit Zahl:**
1. **Vorzeichen des Kurs-Kreuzprodukts.** `flight` dreht `forward` um +Y, positives `yawIn` geht
   also nach links (wie Taste A) — mein erstes Kreuzprodukt hatte es andersherum. Befund: nach 16 s
   Anflug **883 u Abstand**, 436 Boost-Frames, kerzengerade in die falsche Richtung.
2. **`posOf` traf das lokale Mesh.** Eine Academy-Karte ist eine Gruppe (Blatt + Live-Fenster), das
   Blatt sitzt lokal auf (0,0,0) — der Pilot flog also pünktlich und sauber zum **Weltursprung**,
   129 u neben der Karte. Jetzt: Halter → Mesh → rohe Position, in dieser Reihenfolge.

**S31 · Academy, POC-Gate erfüllt: eine Lektion, eine Karte, live, klickbar** — und drei statt einer,
weil der Adapter-Vertrag danach stand. Kein Overlay, kein iframe: **Render-to-Texture im selben
Kontext**, RTT-Pass VOR dem Post-Pass. **Gemessen:** Fenster 640×358, **10 Draw-Calls, 194 Dreiecke,
1,4 ms pro Frame** (Calls direkt nach dem RTT-Pass gelesen — nach dem Post-Pass misst man den
Bildschirm-Quad).
- **Der Inhalt ist echt.** Die 30 Lektionen sind 1:1 das Curriculum der KFB Cube Academy v1
  (5 Kapitel × 6, mit three.js-Beispiel-Id und GL/GPU-Tag), die sechste Würfelfläche „Meta" wird der
  Hub. Kapitel = Story-Modus = Zonenfarbe, **Schwierigkeit = Höhe** (leicht hängt tief, schwer hoch):
  der Grad ist ein Steigflug, keine Zahl auf dem Blatt. Besucht ist ein **Stempel**, kein Punktestand.
- **Zweiteilige Karte statt Textur-Kompromiss.** Blatt = Canvas (Kapitelband, Titel, Fenster), davor
  ein zweites Quad, das genau das gemalte Fenster ausfüllt und die RTT-Textur trägt. Typografie
  bleibt scharf, und ohne Live-Demo fehlt nichts — die Fallback-Leiter ist der Normalfall
  (3 von 31 Lektionen laufen live).
- **Adapter-Vertrag** `initLesson(THREE, ctx) → { scene, camera, update, onPointer, resize, dispose }`
  mit den drei Verboten. Erste Lektion bewusst **„Drag-Controls" (mit Controls)**: Greifen, Ziehen und
  Kamera-Orbit ohne jedes Controls-Objekt, handgefüttert aus `onPointer(u, v, type)` — u/v kommen aus
  dem UV-Treffer auf dem Fenster. Dazu „Instancing" (1200 Würfel, Matrizen pro Frame) und der Hub
  (die Reise selbst als Objekt: besuchte Zonen stehen auf).
- **Klick-Kollision jetzt entschieden, nicht später:** Einfachklick geht an die Demo, aber NUR auf dem
  Fenster der laufenden Karte; alles andere ist Steuerung, Doppelklick ist Anflug.
- **Gepacet wie alles Teure hier:** Blätter zwei pro Auftrag, nächstgelegen zuerst, nur bei
  `dt < 40 ms`, nie bei `document.hidden` — **31 Blätter in 42 ms** (1,4 ms/Stück). Live startet erst,
  wenn der Wunsch 0,35 s stabil ist, und stirbt nicht am Vorbeidriften (Hysterese 1,8×).
- **Ankommen IST besuchen.** Der Durchflug ist die schönere Ankunft, aber gemessen kamen 2 von 3
  Anflügen neben der Kartenebene heraus (5,8 u, kein Vorzeichenwechsel). Ohne diese Zeile bliebe der
  Stempel aus und die Route würde dieselbe Karte ewig neu anfliegen.

**Messfalle, die dazukam:** ein Raycast braucht eine aktuelle `matrixWorld`. In der versteckten
Vorschau feuert `requestAnimationFrame` nicht, also rendert nichts, also stehen die Weltmatrizen —
der Doppelklick sah zwanzig Minuten lang kaputt aus und war es nie. `scene.updateMatrixWorld(true)`
vor dem Test, dann stimmt das Bild. **Zu „nur in der sichtbaren Ansicht messen" kommt also: wer ohne
Render-Pass raycastet, misst eine Szene im Ursprung.**

## 2026-07-25 · v7 · S23: echte Karten auf den Sky-Karten (Deck-PDF + JSON)

`terrain-v7/card-registry.js` (neu) + `sky-cards.js`. **Der Vertrag ist Kanon und wurde nicht neu
erfunden** — er steht im Repo-Manifest `media/kfb/index.json` (`kfb-deck-registry/v2`):
2×2 Zellen pro Seite, Reihenfolge TL · TR · BL · BR, Seite = `coverOffset + 1 + floor((n−1)/4)`,
Quadrant = `(n−1) % 4`, URL = `baseUrl + '/' + encodeURIComponent(datei)`. Portiert aus
`rollercoaster-v11` (`loadRegistry` · `renderPdfPage` · `ensureCardArt`).

- **Text zuerst, Bild später.** Die Karten-JSON ist in Millisekunden da: Titel, Deck und zwei Zeilen
  Lore tragen das Blatt sofort. Das Artwork (2×2-Quadrant, 1:1 aus dem gerenderten PDF, auf die
  gejitterte Silhouette geclippt, kanonische Tuschekante drauf) kommt nach. **Nie ein leeres Blatt,
  nie ein Ladebalken.**
- **Gemessen:** vier Decks aus der Registry, Kartenpool über alle Decks gemischt (der Almanach ist da
  eindeutig — der Funke springt zwischen zwei Stimmungen), `cellAspect` **0,5573** aus der
  gerenderten Zelle — das ist 1/1,794 und bestätigt `KFB_CARD_AR = 1.79` unabhängig. Nach ~8 s
  trugen 4 von 7 Blättern echtes Artwork, Warteschlange leer.
- **Und die Lehre des Abends: ungepaced kostet das die Bildrate.** Erster Anlauf warf beim Erscheinen
  alle sieben Blätter in die Warteschlange — vier große Deck-PDFs gleichzeitig, dazu ein
  1500-px-Seitenrender pro Karte, alles auf dem Thread, auf dem der Flug läuft. Jetzt: Deck-JSON erst
  nach 4 s (die ersten Sekunden gehören dem Terrain-Aufbau), **ein** Render alle 2,5 s, nur wenn das
  Bild flott läuft (`dt < 40 ms`), und immer für die **nächste** Karte — die sieht man als erste.
  Schalter „Echtes Artwork laden" zum Abstellen.
- **Vorwärts-Bias bei der Verteilung:** neue Karten erscheinen ±75° um die Flugrichtung (10 % dahinter,
  damit es kein starres Tor wird). Vorher war der Himmel in Flugrichtung oft leer.
- **Zwei Robustheitslücken direkt nachgezogen** (Review), beide an derselben Wurzel — ein Auftrag,
  der nie zurückkommt: (1) `card.art = 'pending'` wurde nie freigegeben, wenn die Registry aufgab;
  das Blatt bekam dann in der ganzen Sitzung kein Artwork mehr, auch nicht direkt vor der Nase.
  `requestArt` hat jetzt einen **fail-Callback**, der die Karte freigibt. (2) **Watchdog, 20 s:**
  pdf.js treibt seinen Canvas-Render intern über `requestAnimationFrame` — wechselt man während eines
  Renders den Tab, settelt das Promise NIE, und `busy` wäre für immer belegt. Der Timer gibt frei,
  reiht neu ein und meldet. Dazu pumpt die Warteschlange gar nicht mehr, solange `document.hidden`
  gilt, und läuft bei `visibilitychange` weiter. **Ein Tab-Wechsel darf keinen Slice abschalten.**
- **Messfalle, die mich zwanzig Minuten gekostet hat:** in einem *hidden* Preview feuert
  `requestAnimationFrame` nicht — der Frame-Zähler stand, und das sah exakt wie ein toter Loop aus.
  Dazu liest `renderer.info.render` **nur den letzten Pass**: mit Post-Processing sind das 6 Calls für
  den Bildschirm-Quad, nicht die Welt. Beides notiert; ab jetzt wird in der sichtbaren Ansicht
  gemessen.

## 2026-07-25 · v7 · S22 Kern: Sky-Karten als Flugziele

`terrain-v7/sky-cards.js`. Vier Dinge, die zusammen ein Flugziel machen:

**1. Zero-G ohne Wiederholung.** Drift, Neigung und Rollen kommen aus **drei Sinus-Termen pro Achse
mit inkommensurablen Frequenzen** (√2, √3, √5, goldener Schnitt). Die Summe hat keine gemeinsame
Periode — es gibt also kein „jetzt wackelt es wieder genauso". Genau Georgs Anforderung, und billiger
als jede Rausch-Textur.

**2. Lesbarkeit schlägt Physik.** Die Karte dreht sich zur Kamera (Karten haben keine Rückseite,
Kanon aus v11), aber **gedämpft per Slerp**: sie folgt der Blickrichtung, ohne zu schnappen, und
behält ihre Eigen-Neigung obendrauf. Ergebnis: immer ein guter Lesewinkel UND ein guter
Durchflugwinkel — beides war die Vorgabe.

**3. Durchflug statt Kollision.** Kein Solver, keine Broadphase: Abstand zur Kartenebene
(Skalarprodukt mit der Normale), und der **Vorzeichenwechsel IST das Ereignis** — gültig nur, wenn
der Punkt innerhalb der halben Kantenlängen liegt. **Gemessen: Durchflug erkannt, „The Held Breath"
gesammelt.**

**4. Portal-Auflösung, portiert aus v11:** geteilte AlphaMap (radial-ovaler Gradient + Value-Noise)
und ein **steigender `alphaTest`**. Der frisst die Mitte zuerst und lässt eine irreguläre Kante
stehen. Null CPU, eine Textur für alle Karten. Danach Respawn an neuer Stelle.

**Karteninhalt:** echte Titel aus den Cut-&-Play-Decks (*The Finished City*, *The Doomsday Clock*,
*The Held Breath* …) mit Deck-Zeile — Platzhalter wären hier falsch, die Karten sind Beweisstücke.
Blatt ist Papier + gejitterte Ink-Outline, gemalt auf Canvas. **Und eine Lehre aus v11 gleich
mitgenommen:** nach `document.fonts.ready` werden die Texturen EINMAL neu gemalt — läuft der Webfont
noch, malt der Browser still Georgia, und die Typografie hängt am Zufall der Ladereihenfolge.

- **Regler** in der neuen Sektion „Sky-Karten": sichtbar · Größe · Ring-Abstand · Höhenband ·
  Zero-G-Drift · Eigen-Neigung · Ausrichtung folgt (träge → flink) · Trefferfenster · Zähler.
- **Bewusst NICHT drin:** KISS-Strahlen (S22b), Wind und Turbulenz (S22c), Deck-UI (S26). Nach dem
  Durchflug ist das Ding spielbar — da soll ein Zwischenstand stehen.
- **Captures:** `screenshots/01-v7-skycards.png`, `02-v7-skycards.png`.
- **Drei Nachbesserungen noch am selben Abend** (Review): `nearest` maß den Abstand zum
  **Weltursprung** statt zum Spieler — heute unbenutzt, aber genau die API, an der S22b und S22c
  hängen würden, und dort wäre der Fehler still. Jetzt `nearest(player)`; gemessen: liefert die
  Karte bei 94 Einheiten, und 94 ist auch das Minimum über alle sieben. Zweitens ein **Texturleck**
  beim Respawn (alte `CanvasTexture` wurde ersetzt statt disposed — pro gesammelter Karte blieb eine
  720×402-Textur auf der GPU). Drittens zwei Allokationen pro Karte und Frame (≈ 840/s) durch ein
  frisches Quaternion für die Eigen-Neigung — jetzt vorallokiert wie der Rest des Moduls.

## 2026-07-25 · v7 · S21 erledigt: Flug-Sounddesign, Schritte, Sample-Registry — plus Flow ohne Musik

**Die Luft hat jetzt zwei Schichten und atmet.**
- **Böen** (`gust`): ein langsamer Zufallsgang (alle ~0,9 s ein neues Ziel, mit 1,6/s angefahren)
  moduliert den Fahrtwind. Ohne das steht er als Rauschteppich; damit atmet er.
- **Rumpeln** (`rumble`): eine zweite, tiefpassgefilterte Rauschschicht aus demselben Puffer, die
  **nah am Boden lauter wird** (`agl` in Weltunits → `low`), zusammen mit einem dunkleren Bandpass.
  Das ist der Unterschied zwischen „schnell" und „knapp über dem Boden schnell".
- Im Walk-Modus läuft die ganze Motion-Ebene auf 35 % — zu Fuß gibt es keinen Fahrtwind.

**Schritte, Rolle, Aufprall als Ereignisse.**
- **Schritte** hängen am Gehzyklus der Pet-Kinetik: `pet-kinetics.js` zählt Fußaufsätze
  (Nulldurchgang von `sin(walkT)`) und der Runner hängt die SFX an den Zähler — kein zweiter,
  eigener Takt. Synthetisch ist es ein kurzer gefilterter Rauschklick mit Tonhöhen-Jitter; zwei
  identische Schritte klingen sofort mechanisch. **Gemessen: 5 Tritte in 1,8 s Gehen.**
- **Barrel-Roll** bekommt einen Swish, der über die Stereobreite wandert — die Drehung wird hörbar.
- Landung skaliert weiter am `impact`, Absprung ist ein Pop.

**Sample-erst-dann-Synthese (das Wichtigste an diesem Slice).** `sfx(id)` spielt eine echte Datei,
wenn für die Id eine im Manifest steht — `media/3D_Assets/Audio/sfx.json` im Repo (RAW-first),
lokaler Fallback `terrain-v7/sfx.json`. Sonst der synthetische Einsatz, also **nie Stille**.
Manifest-Form pro Id: `{ file | variants[], gain, rate, jitter }`; `variants` rotiert gegen
Wiederholung, `jitter` streut die Tonhöhe. Alles im Manifest wird beim Ton-Start vorgeladen (ein
Einsatz darf nicht erst beim zweiten Mal klingen). **Georgs ElevenLabs- und Kenney-Dateien sind damit
eine Datenänderung, kein Code.** Ids, die schon abgefragt werden: `boost` · `land` · `jump` ·
`step` · `roll` · `card` (für S22).
Zweiter Trim `sfx` nur für Samples, weil ElevenLabs-Dateien mit sehr unterschiedlichen Pegeln kommen.

**Nebenbei, aus Georgs Notiz: Flow ohne Musik war nicht einstellbar.** Der Flow-Regler bestimmt die
PHASE, die Amplitude hing aber weiter an Beat und/oder Reisetempo — ohne Musik also entweder still
oder tempoabhängig. Neue Stellung **„gleichmäßig (Flow ohne Musik)"** in beiden Kopplungs-Selects:
konstante Amplitude 0,55, weder Takt noch Tempo. Damit ist das Boden-Animationsmuster für sich
einstellbar, wie in der three.js-Demo.

- **Dateien:** `terrain-v7/travel-audio.js`, `terrain-v7/pet-kinetics.js` (`stepCount`),
  `terrain-v7/travel-poc.js`, `terrain-v7/sfx.json` (neu, leerer Fallback).
- **Regler** in „Klang & Rhythmus": Rumpeln (Bodennähe) · Böen · Sample-Trim, dazu die bestehenden.

## 2026-07-25 · v7 · S20 erledigt: Jukebox + Drone — der Takt kommt jetzt aus der Musik

- **Was:** `terrain-v7/travel-audio.js`. Der 4-Ebenen-Soundscape aus Rollercoaster v11, portiert und
  auf Travel-Kontrakte gelegt: **bed** (Drone: der Story-Mode IST eine spektrale Identität,
  `AUDIO_MOODS` 1:1 übernommen) · **motion** (Fahrtwind ∝ heat², Bandpass öffnet mit dem Tempo, im
  Walk-Modus auf 35 % gedämpft — zu Fuß gibt es keinen Fahrtwind) · **event** (Boost-Whoosh,
  Landungs-Thump skaliert am Impact, Absprung-Pop) · **space** (geteilter Feedback-Delay-Hall,
  Wet aus dem Mood).
- **Der eigentliche Gewinn:** unser Takt war eine Zahl im Runner (`synthPhase`, `bpm 104`). Jetzt
  kommt die Eins aus dem Track — Cube-Tanz und Blinken hängen an Musik, die man hört. **Ein
  Takt-Ausgang** (Regel aus S1): läuft Ton, liefert `audio` den Beat; ohne Ton bleibt der
  synthetische Takt. Kein zweites System, nur eine andere Quelle.
- **Jukebox:** RAW-first aus dem Repo (`media/3D_Assets/Sounds/jukebox.json`), lokaler Fallback
  (`terrain-v7/jukebox.json`), hartkodierter Default als letzte Reserve. **Gemessen: zehn Tracks
  geladen**, Van Metronome (104 BPM) spielt, Bassband-Pegel 0,68.
- **Der rohe Pegel taugt nicht als Beat.** Erste Fassung koppelte `level·0.7` — bei einem gemasterten
  Track steht der Bass dauerhaft bei 0,7, die Cubes hätten also durchgetanzt statt gepulst. Jetzt
  zählt der **Ausschlag über dem langsamen Mittel** (`(level − levelAvg)·4`, Mittel mit 0,6/s) — das
  ist ein Onset.
- **Zwei Fehler, die den ganzen Slice im ausgelieferten Weg tot aussehen ließen** — gefunden, weil
  über den echten Overlay-Schalter gemessen wurde und nicht über einen direkten `start()`-Aufruf:
  1. **`ctx.resume()` fehlte beim ersten Start.** Ein frisch angelegter AudioContext kommt in vielen
     Browsern SUSPENDIERT hoch; `ctx.currentTime` läuft dann nicht, der Phasenvergleich feuert nie und
     der Analyser liest Stille. Jetzt resumt `start()` sofort, und **jede** Nutzergeste resumt erneut
     (ein Context kann auch später suspendieren, z. B. beim Tab-Wechsel).
  2. **Das Gate war `ready` statt „Uhr läuft".** `ready` heißt nur „Graph gebaut" — damit war der
     funktionierende synthetische Takt ab dem ersten Ton-Einschalten dauerhaft verworfen, auch wenn
     danach nichts spielte. Neuer Ausgang `running` (Graph UND `state === 'running'` UND nicht
     stumm); der Runner gated darauf.
- **Nachgemessen über den echten Weg** (Klick auf „Ton an" im Overlay): `state 'running'`, Pegel 0,72,
  und `uBeat` am Terrain-Material pulst **0,47 … 0,66** im Takt. Ton wieder aus → `running false`,
  synthetischer Takt ist zurück (`uBeat` 0,16 … 0,48). Die Live-Zeile zeigt jetzt auch ehrlich
  „Ton aus" statt „BPM aus dem Track".
- **Drei v11-Lehren von Anfang an eingebaut:** Audio braucht eine Nutzergeste (der Runner ruft
  `armAudio()` in keydown und pointerdown; ohne Klick existiert kein AudioContext) · Reverb-Send
  **post** Fader (FX auf 0 = auch Hall aus) · beim Track-Wechsel zuerst `onended = null`, dann
  `stop()` — sonst legt der Restart-Timer eine zweite Quelle drüber (Flamming).
- **Mood-Wechsel ohne Rebuild:** `setMood()` stellt Wellenform, Partialfrequenzen und Filter live um
  (v11 baute den Graph neu). Ein Story-Wechsel ist bei uns ein Regler — der darf nicht knacken.
- **Regler** in der umbenannten Sektion **„Klang & Rhythmus"**: Ton an · Track (zehn Titel mit BPM) ·
  Musik · Drone · Fahrtwind · Effekte · Tempo (nur ohne Ton) · Beat-Kopplung · Live-Anzeige
  (BPM aus dem Track + Puls in %).
- **Dateien:** `terrain-v7/travel-audio.js` (neu), `terrain-v7/jukebox.json` (neu, Fallback),
  `terrain-v7/travel-poc.js`.
- **Offen für S21:** echte SFX-Dateien (ElevenLabs) statt synthetischer Einsätze, Karten-Durchflug
  (kommt mit S22), und die sechs Würfel als gerichtete Quellen — der Hörer folgt schon der Kamera,
  die Panner kommen mit den Sky-Karten.

## 2026-07-25 · v7 · Schatten neu gedacht (projiziert statt Quad) + Kamera kann nicht mehr im Cube stecken

Drei Befunde von Georg, alle drei am selben Abend. **Nur in `terrain-v7/` behoben — v6 bleibt FROZEN.**

**1 + 2. Der Blob-Schatten war im Ansatz falsch, nicht falsch parametriert.** „Wirkt unecht und
flackerig, va bei dancing cubes und wechselnden Höhen" und „im Walk-Modus ist der Übergang zum Body
nicht plausibel" haben dieselbe Ursache: ein Schatten-**Quad** liegt auf EINER Höhe. Auf einem
Voxel-Boden heißt das: an Kanten schwebt es über dem Abgrund, an Wänden steckt es in der Geometrie,
und sobald die Höhenprobe zwischen zwei Nachbarsäulen springt (oder ein Cube hüpft), springt der
ganze Fleck. Dazu lag er als runde Scheibe **neben** dem Pet statt an seinem Fuß.

**Neu: der Terrain-Shader projiziert den Schatten selbst.** Jedes Terrain-Fragment kennt seit dieser
Runde seine Weltposition (`vWorld`); damit lässt sich der Werfer entlang des Lichtstrahls auf genau
diese Höhe projizieren:
```glsl
float dy = caster.y - vWorld.y;                       // Werfer unter der Fläche → kein Schatten
vec2 p = caster.xz + (L.xz / max(L.y, 0.25)) * dy;    // Projektion entlang des Lichtstrahls
float d = length(vWorld.xz - p) / (caster.w * (1.0 + dy * 0.045));
```
Das Ergebnis dimmt die belichtete Farbe multiplikativ (`lit *= 1 − 0.52·sh`). Vorteile, die alle drei
Beschwerden erledigen: der Schatten sitzt immer auf der Fläche, **die wirklich da ist** — auch auf
Cube-Wänden, wo er als Schmier hochläuft, wie es ein echter Schatten tut; er bewegt sich mit den
tanzenden Cubes mit (weil er dort ausgewertet wird, wo die Geometrie steht); er kann nicht z-fighten;
und im Walk-Modus setzt er am Fuß an, weil der Werfer die **Körpermitte** ist (`y + 0.85`, r 0,95) und
die Projektion kontinuierlich ist. Kosten: zwei Distanzen pro Fragment, keine Geometrie, kein
Draw-Call. API: `terrain.setCasters(a, b)` (zwei Werfer, `{x,y,z,r}`) und `terrain.setCasterGain()`.
**Das Quad bleibt genau dort, wo es richtig ist:** der Pet-Schatten AUF der Karte — durchgehende
Fläche, und er soll mit Bank und Wellung mitgehen.

**3. Kamera steckte an Eck-Positionen im Cube** (Georgs Screenshot: Artefakte, dann Flackern).
Zwei Ursachen: der Pull-in tastete nur 8 Proben ab (eine dünne Wand dazwischen wird übersehen), und
der Höhen-Deckel im Walk-Modus schob die Kamera horizontal Richtung Pet — direkt in die Nachbarsäule.
Jetzt 14 Proben, und **als letzte Instanz `escapeTerrain()`**: unsere Welt ist ein Höhenfeld aus
VOLLEN Säulen, wer über der Säulenoberkante ist, ist garantiert draußen. Die Funktion kriecht notfalls
in bis zu sechs Schritten Richtung Blickziel, bis das gilt. Lieber sehr nah am Pet als in einer Wand —
und mathematisch kann die Kamera damit nicht mehr in Geometrie stehen. Läuft in beiden Modi (Flug mit
Marge 0,9 / vier Schritten, Boden 0,8 / sechs).

- **Dateien:** `terrain-v7/voxel-terrain.js` (`vWorld`, `castShadow()`, `setCasters`),
  `terrain-v7/travel-poc.js` (Werfer pro Frame, `escapeTerrain`, Pull-in 14 Proben).
  `ground-shadow.js` bleibt — jetzt nur noch für die Karte.
- **Captures:** `screenshots/02-v7-shadow.png` (Schatten am Fuß, auf Kante und Wand),
  `03-v7-shadow.png` (laufend), `01-v7-shadow.png` (Flug).
- **Regel dazu:** *Ein Schatten auf einer nicht-durchgehenden Fläche gehört in den Shader der Fläche,
  nicht auf ein Quad davor.* Dasselbe Muster wie beim Radial-Blur: die Frage war nicht der Parameter,
  sondern wo der Effekt hingehört.

## 2026-07-25 · v6 · S18 Flow-Modus + S15 Blob-Schatten — und v6 ist FROZEN

**S18 · Flow.** Der Hub hat jetzt zwei Muster, gemischt über einen Regler (`terrain.setFlow(0…1)`,
Sektion Rhythmus, Default 0):
- **Dancefloor** (0): jede Säule hat ihre eigene Phase aus dem Seed — richtig für den Beat, und für
  Edge-Case-Tests weiter der bessere Zustand, weil Nachbarsäulen unabhängig arbeiten.
- **Flow** (1): die Phase kommt aus dem ORT. Drei überlagerte Terme — schräg laufende Welle,
  quer modulierende zweite Welle, langsam radiale dritte — ergeben ein Interferenzmuster, das sich
  nie exakt wiederholt und trotzdem nicht zufällig aussieht. Georgs three.js-Verweis
  (`webgl_instancing_dynamic`) beschreibt genau diesen Unterschied: räumlich zusammenhängende
  Bewegung statt zehntausend unabhängiger Zappler.
Amplituden-Kopplung (Musik / Tempo / beides / aus) und die Ruhezonen greifen unverändert — sie
dämpfen die Amplitude, nicht die Phase.

**S15 · Blob-Schatten** (`ground-shadow.js`). Kein echter Schattenwurf: das Pet WIRFT längst
Schatten, aber die Terrain-Cubes sind ein eigenes `ShaderMaterial` ohne Shadowmap-Chunks — und
tanzende Cubes würden eine echte Schattenkante zappeln lassen. Also die cartoongerechte Lösung:
ein flaches Quad, radial ausgefadet, unbeleuchtet, `depthWrite: false` — aber MIT Tiefentest, damit
ein höherer Cube den Schatten korrekt verdeckt. **Zwei Anwendungen, eine Klasse:**
- **auf dem Terrain** — im Flug unter der Karte (wächst und verblasst mit der Höhe: das ist die
  Höhenauskunft am Boden), am Boden unter dem Läufer.
- **auf der Karte** — der Pet-Schatten hängt IM Karten-Rig (`rig.lean`), bankt und wellt also mit,
  und wächst beim Sprung: der Kontakt, der einem Cartoon-Sprung Gewicht gibt.

**Zwei Dinge, die erst nach dem ersten Blick stimmten:**
1. **Ein Exponent-Abfall (`pow(1−d, 1.6)`) ist zu blass**, um auf einem gemusterten Boden gelesen zu
   werden. Jetzt voller Kern bis `core 0.34`, danach weich aus.
2. **Das Objekt stand auf seinem eigenen Schatten.** Der Versatz rechnet jetzt mit Höhe **plus halber
   Körperhöhe** in Sonnenrichtung (Sonne bei 30/60/20) — vorher lag der Fleck exakt unter dem Pet und
   war nie zu sehen. Nebeneffekt, der stimmt: die Szene liest sich nicht mehr als Mittagslicht.

**v6 ist damit FROZEN.** Snapshot aktualisiert: `export/travel-v6_2026-07-25/` (Entry, `support.js`,
`themes/kfb-med.css`, 18 Module, docs, sieben QA-Bilder, `MANIFEST.md`).
**Erledigt in v6:** S2 (Speedlines + Radial-Blur + Barrel-Roll, drei Korrekturrunden) · S14
(Pet-Beleuchtung) · Ink-Outline-Regler · Ruhezonen (vier statt einer) · S10 (Modus folgt der Höhe) ·
S11 (Rahmen mit Wortmarke) · S18 (Flow) · S15 (Blob-Schatten).
**v7 angelegt:** `KFB Travel v7.dc.html` → `terrain-v7/`, Plan in `docs/SPRINT_travel-v7.md`.

**Beim ersten Fork sofort aufgefallen — dieselbe Lüge wie v5→v6:** das Overlay sagte „KFB Travel v6".
Der Fix von damals hatte die Zeile zwar als `opts.eyebrow` herausgezogen, aber mit
`|| 'KFB Travel v6'` als **hartkodiertem Default** — der Fork erbt ihn. Jetzt gibt der **Runner**
seine Version mit (`eyebrow: 'KFB Travel v7'`), und der Default im Overlay ist neutral
(`'KFB Travel'`). **Regel: die Versionsnummer gehört dem Runner, nicht einem Modul** — ein Modul,
das seine eigene Version kennt, lügt beim nächsten Fork.
Ebenfalls nachgezogen: die Modul-Header der acht v7-Kopien.

**Kleine Korrektur an der Behauptung von vorhin:** der Karten-Blob-Schatten ist im Reiseflug (alt ~16
über Boden ~3) durch den Sonnenversatz UNTER dem Bildrand — geometrisch richtig, aber die
„Höhenauskunft am Boden" trägt erst im niedrigen Flug und im Walk-Modus. Wenn sie im Reiseflug tragen
soll, muss der Versatz mit der Höhe gedeckelt werden (offener Punkt, kein Bug).

- **Dateien:** `terrain-v6/ground-shadow.js` (neu), `terrain-v6/voxel-terrain.js`,
  `terrain-v6/travel-poc.js`.
- **Captures:** `screenshots/02-v6-s15-s18.png` (Flow), `screenshots/01-v6-s15-shadow3.png` (Schatten
  am Boden), `screenshots/02-v6-s15-shadow3.png` (Schatten im Sprung).

## 2026-07-25 · v6 · S10 + S11 erledigt: Modus folgt der Höhe, Rahmen mit Wortmarke

**S10 — der Modus ist kein Schalter mehr, sondern eine Folge der Höhe.**
- **Abheben:** Leertaste zweimal (< 280 ms) am Boden. Kein neuer Zustand in der Sprung-Grammatik —
  der erste Druck hat schon gesprungen, der zweite verlängert ihn: die Karte setzt DORT ein, wo das
  Pet stand (`alt = y + 0.8`), in seiner Blickrichtung, und bekommt ein Steigziel `+12`.
  Vorher setzte `flight.reset()` immer auf Reiseflughöhe 9 — beim Umschalten sprang das Fahrzeug.
  `reset(x, z, alt, heading)` nimmt jetzt beides.
- **Landen:** `X` (oder Pfeil-runter) senkt. Der Wechsel feuert NICHT bei Berührung allein, sondern
  bei **Bodenkontakt + kleiner Sinkrate + Sinkwille, gehalten über `landHold` 0,22 s** — sonst kippt
  ein Streifschuss über einen Cube-Gipfel mitten im Flug in den Laufmodus. Die Hysterese sitzt im
  Flight-Controller (`landSink 7`, `landHold 0.22`, `sinkRate` geglättet mit 8/s), der Runner führt
  nur aus — und erst nach einer Sperrzeit von 0,9 s nach jedem Moduswechsel, sonst pendelt es.
- **`F` bleibt** als direkter Umschalter, dazu ein Schalter „Modus folgt der Höhe" im Overlay: wer
  mit Timing-Fenstern nicht zurechtkommt, braucht einen Weg ohne.
- **Gemessen:** `X` halten → nach **0,7 s** in Walk auf y 5,59 · einzelner Sprung bleibt in Walk ·
  Doppel-Leertaste → Fly, und 0,7 s später ist die Karte bei alt 14,4 auf dem Weg zu Ziel 16,3
  (steigt also, springt nicht).

**S11 — Rahmen.** Oben links die **KayfaBizarro-Wortmarke** direkt aus `themes/kfb-med.css`
(`.kfb-wordmark`: Irish Grover, „Kayfa" in Tinte, „Bizarro" cream auf Akzent, harter Schatten,
leichte Kippung) — kein Nachbau, kein SVG. Oben rechts Titel und Untertitel klein in Special Elite.
Weil die Marke hier über einer bewegten Welt statt auf Papier sitzt, bekommt „Kayfa" einen harten
Cream-Schatten als Kontrastkante; das bleibt im Idiom (Offset, kein Blur).
**Die Modus-Anzeige ist ganz weg** — Badge gelöscht, und der Tacho zeigt nur noch `POV`, wenn die
Kamera im Kopf des Pets sitzt. Das war erst erlaubt, nachdem S10 die Auskunft durch Mechanik
ersetzt hat: man sieht an der Höhe, wo man ist.

- **Dateien:** `terrain-v6/flight-controller.js`, `terrain-v6/travel-poc.js`, `KFB Travel v6.dc.html`.
- **Capture:** `screenshots/v6-s11-frame.png`.

## 2026-07-25 · v6 · Ruhezonen: vier statt einer, und der Boden beruhigt sich beim Sinken

- **Georgs Befund:** idealerweise hüpft der Boden, nicht die Kamera. Die Bob-Reserve war schon vom
  Live-Beat befreit; jetzt kommt die eigentliche Lösung dazu — **die Cubes selbst werden ruhig, je
  näher die Karte kommt**. `groundCalm 0.9`, voller Tanz ab 15 units über Grund, ab 3,5 units still,
  Übergang mit 3/s geglättet, Radius 22.
- **Vier Ruhezonen statt einer.** Der Shader nimmt jetzt `uniform vec4 uZone[4]` (x, z, Radius,
  Stärke) und mischt das Minimum: **Zone 0 folgt dem Fahrzeug** (im Walk der Läufer wie bisher, im
  Flug die sinkende Karte), **Zone 1–3 sind gesetzte Orte** — genau das, was der KFB-Hex-Turm, der
  Graveyard und künftige Landeplätze brauchen, damit große Modelle sauber auf ruhigen Nachbarcubes
  stehen. API: `terrain.setZones([{x,z,r,amt}])`, `terrain.zones`, `terrain.calmAt(x,z)`.
- **Die Bodenfreiheit rechnet jetzt mit der Zone.** `cardClearance` nimmt die Bob-Reserve mal
  `(1 − calmAt)` plus einen festen Sicherheitsabstand von 0,3 — wo die Cubes stehen, braucht die
  Karte keine Höhe für Hübe, die nicht stattfinden. Sie kann also tiefer und ruhiger fliegen, ohne
  dass eine Kartenecke in einen steigenden Würfel schneidet.
- **Gemessen:** Höhe 47 units → Zone 0 bei 0,000 (voller Tanz) · Höhe 9,5 units → 0,897 · gesetzte
  Zone (r 30) liest 1,00 im Zentrum und 0,00 bei 40 units Abstand.
- **Dateien:** `terrain-v6/voxel-terrain.js`, `terrain-v6/travel-poc.js`.
- **Regler:** Sektion „Welt" → „Ruhezone am Boden" (0 = aus … 100 %) plus Live-Anzeige, wie ruhig es
  unter der Karte gerade ist.
- **Zwei Fallen aus dieser Runde, beide teuer, beide billig zu vermeiden:**
  1. **Ein Kommentar hat die nächste Deklaration gefressen.** Beim Edit ging der Zeilenumbruch nach
     dem `uZone`-Kommentar verloren, `varying vec2 vUv;` stand damit hinter `//` — der
     Cube-Vertex-Shader kompilierte nicht mehr und das **ganze Terrain war unsichtbar**
     (Skydome, Karte, Pet und Würfel rendern weiter, es sieht also nicht wie ein Absturz aus).
     Merksatz: in GLSL-Template-Literalen sind Zeilenenden Semantik; nach jedem Edit an einer
     Shader-Deklaration einmal die Konsole lesen.
  2. **`renderer.info.render.triangles` taugt nicht als „rendert das Terrain?"-Test.** Der Zähler
     gilt für den LETZTEN Renderaufruf — bei uns der HUD-Würfel-Pass. Er zeigte 2028 Dreiecke, mit
     und ohne Terrain. Richtig ist: direkt nach `renderer.render(scene, camera)` ablesen.
- **Nach dem Fix visuell nachgemessen** (dieselbe Szene, gleiche `uTime`, nur Zonenstärke 0 vs. 1):
  **36,4 % der Bildpixel ändern sich** — die Zone dämpft also wirklich die Geometrie und nicht nur
  eine Uniform.

## 2026-07-25 · v6 · Ink-Outline der Karte zur Laufzeit regelbar (+ Stil-Hook für Torn/Bend)

- **Was:** Die Outline wurde bisher EINMAL beim Laden in die Kartentextur gemalt (`baseW 6`, hart
  verdrahtet). Jetzt malt `createCardSurface` sie in ein Canvas, das das geladene Kartenbild
  **festhält** — `rig.setInk({ width, wobble, jitter, style })` übermalt nur neu, ein Regler löst
  also keinen zweiten Netzabruf aus. Drei Regler in Sektion „Karten": **Ink-Outline der Pet-Karte**
  (0 = aus … 18 px), **Strich-Unruhe** (der Wobble aus dem v1-Kanon) und **Kanten-Zittern** (der
  Jitter der Perimeter-Punkte).
- **Gemessen:** dunkle Randpixel in den oberen 40 Canvas-Zeilen — 1248 bei Breite 0 (nur das
  Kartenmotiv selbst), 6142 bei 6 px, 12536 bei 14 px. Textur bleibt 800×447 und wird von Ober- und
  Unterseite geteilt (ein Objekt, ein Bild).
- **Stil-Hook für Georgs weitere Outline-Stile:** zwei Tabellen `PERIMETER[style]` und
  `STROKE[style]` — genau die zwei Funktionen, aus denen der v1-Kanon besteht (Punktpfad + Strich).
  `inked` ist belegt; **Torn** (zackig) wäre ein anderer Punktpfad, **Bend** (flaggenartig) eine
  niederfrequente Welle auf demselben Pfad. Sobald die Kanon-Dateien vorliegen, ist das ein
  Tabelleneintrag, kein Umbau. Sky-Karten bekommen eigene Regler, wenn sie eigene Stile tragen.
- **Dateien:** `terrain-v6/card-carrier.js`, `terrain-v6/travel-poc.js`.
- **Capture:** `screenshots/01-v6-ink.png` (2 px) vs. `02-v6-ink.png` (14 px).

## 2026-07-25 · v6 · S14 erledigt: Pet-Beleuchtung (Sky-Environment, Fill, Story-Tint) + Session-Cut

- **Was:** `terrain-v6/pet-lighting.js`. Drei unabhängig schaltbare Bausteine gegen die flache
  Schattenseite: (1) **Sky-Environment** — der Skydome wird pro Story-/Varianten-Wechsel in eine
  PMREM-Map gebacken und als `scene.environment` gesetzt, jedes PBR-Material nimmt die
  Himmelsfarbe auf; (2) **Fill-Light**, kalt (`#bcd4ff`, 0,55) gegen die Sonne, ohne Schatten,
  folgt dem Fahrzeug; (3) **Story-Tint** nach dem Muster aus Rollercoaster v11:
  `mix(base, base·ink, 0.18)` hinter `map_fragment`, also NACH der Textur — die Base-Color bleibt
  erkennbar, das Pet gehört sichtbar zur Welt.
- **Warum vorher flach:** es liefen genau zwei Lampen (Sonne 2,6 + Hemisphere 1,0). Auf der
  Schattenseite arbeitete also nur die Hemisphere, und die hat keine Richtung.
- **Zwei Details, die den Slice tragen:** der Skydome hängt am Kamera-Follow — für den Bake wird er
  auf den Ursprung gesetzt und danach zurückgehängt, sonst backt man eine Kugel mit falschem
  Mittelpunkt. Und der Tint fasst nur `MeshStandard`/`MeshPhysical` an: Augen und Kartenfläche sind
  `MeshBasic` und würden davon nur schmutzig. **Gemessen: 28 von 31 Materialien gepatcht**, die drei
  übrigen sind genau diese Basic-Materialien.
- **Regler** in Sektion „Pet": Himmels-Licht (0–2×), Fill-Licht (0–1,5), Story-Tint (0–50 %).
- **Session-Cut:** `export/travel-v6_2026-07-25/` (Entry + `support.js` + 17 Module + docs + vier
  QA-Bilder + `MANIFEST.md`). **Snapshot, kein Fork** — weitergearbeitet wird in `terrain-v6/`;
  ein v7 lohnt erst, wenn S10–S12 stehen.
- **Dateien:** `terrain-v6/pet-lighting.js` (neu), `terrain-v6/travel-poc.js`.
- **Capture:** `screenshots/01-v6-s14.png` (alles aus) vs. `02-v6-s14.png` (an).

## 2026-07-25 · v6 · Post-Pass ohne Rendertarget, Tanz und Blinken getrennt, weichere Cube-Bewegung

**1. Pet und Karte sahen dauerhaft „ausgeknipst" aus — Ursache war der Umweg über den Puffer selbst.**
Die Farbraum-Korrekturen davor waren nötig, aber nicht ausreichend. Messung (Differenzbild
direkt vs. durch das Rendertarget, 1848×1080): **99 % des Bildes identisch, aber im Kartenbereich
−22/255**, schlechtester Pixel 163 → 74. Eingegrenzt durch Ausblenden: Pet aus → Rest bleibt, Karte
aus → Differenz **0**. Es ist die Karte, genauer ihre `CanvasTexture` (Mips, Aniso 8) auf einem
`MeshStandardMaterial`; im Offscreen-Pfad filtert/kompiliert sie messbar anders, unabhängig von
Farbraum, MSAA-Zahl und Target-Format (alle drei durchprobiert und gemessen).

**Lösung: der Blur braucht kein Rendertarget.** Die Szene rendert wieder **direkt auf den Schirm**,
pixelgleich zu v5. Danach kopiert `copyFramebufferToTexture` das fertige Bild in eine
`FramebufferTexture`, und der Blur liegt als **Overlay** darüber, dessen **Alpha die radiale Maske
ist**: Mitte 0, Rand 1. Verifiziert im Kartenbereich: ohne Pass **107,46**, mit Pass bei Stärke 0
**107,46**, mit Blur 0,09 **107,46** — Δ 0,00. Der Effekt ist damit konstruktiv unfähig, Pet, Karte
oder Tacho anzufassen. **Regel: ein Bildeffekt, der nur den Rand betrifft, gehört als Overlay über
das Bild — nicht als Umleitung des ganzen Bildes.**

**2. Tanz und Blinken sind jetzt zwei Kanäle.** Bisher hing das Leuchten der Cubes an `uBeat`/
`uEnergy`, also am selben Paar wie die Hübe — deshalb blinkten die Cubes weiter, wenn „Cube-Tanz"
auf 0 stand. Neu: eigene Uniforms `uGlowB`/`uGlowE`/`uGlowGain`, und im Overlay (Sektion Rhythmus)
zwei Selects **„Cube-Tanz koppeln an"** und **„Cube-Blinken koppeln an"** mit je vier Stellungen:
Musik + Tempo · **nur Musik (Dancefloor)** · nur Reisetempo · aus. Dazu ein Regler „Blink-Stärke".
Der Himmel hört weiterhin den ganzen Takt, unabhängig von diesen zwei Schaltern.

**3. Weichere Auf/Ab-Bewegung der Cubes** (Georgs Verweis auf three.js `webgl_instancing_dynamic`).
Der Hub lief auf `abs(sin(x))` — am unteren Umkehrpunkt springt dort die Ableitung, das liest sich
als Zucken. Jetzt eine erhobene Kosinuswelle mit Smoothstep-Easing (`rawB²(3−2·rawB)`): stetig in
Wert und Steigung, mit Hänger oben und unten.

**4. Nebenbefund, gleich mitgefixt: die Kamera hüpfte tatsächlich im Takt.** Nicht durch die Cubes
selbst — `groundHeightAt` liefert die statische Säulenhöhe — sondern über `terrain.maxLift()`, das
den LIVE-Beat enthält und in Flughöhen-Reserve und Kamera-Marge einging. Beide lesen jetzt
`maxLift(true)`, das den Beat-Anteil als Mittelwert rechnet. Gemessen: live 2,33 vs. steady 2,43 —
die Reserve atmet nicht mehr mit.

- **Dateien:** `terrain-v6/post-radial.js` (neu geschrieben), `terrain-v6/voxel-terrain.js`,
  `terrain-v6/travel-poc.js`.
- **Capture:** `screenshots/v6-postfix.png`.

## 2026-07-25 · v6 · S2 Runde 3: dünnere Streifen mit weißem Kern, Kondensstreifen an den Kartenecken, Post-Pass-Schalter beseitigt

Drei Punkte aus Georgs Review, mit den TinySkies-Screenshots als Maßstab.

1. **Speedlines dünner, und bei Vollgas heller statt dicker.** Breite jetzt 0,0035–0,0075 (vorher
   0,008–0,018), Breitenwachstum im Boost von ×5 auf ×1,35 zurück. Stattdessen weißt der **Kern**
   aus (`core = 1 − smoothstep(0, halfW·0.55, d)`, gemischt nach Weiß ab `whiteFrom 0.40`) und die
   Deckkraft wächst überproportional (`0.35 + 0.65·f`) — unten ein Hauch, oben ein heißer Strich.
2. **Neu: Kondensstreifen an den hinteren Kartenecken** (`card-contrails.js`, portiert aus
   TinySkies `Contrails.ts`). Zwei Ribbon-Meshes, 72 Segmente, Querachse =
   `cross(Bewegungsrichtung, Blickrichtung zur Kamera)` — das Band bleibt sichtbar, egal wie man
   drumherum fliegt. Ab **20 km/h** (`kmhOn`) fadet es ein, wird mit dem Tempo heller, der dünne
   Kern weiß. Die Anker sitzen in der **Weltmatrix von `rig.lean`**, deshalb zeichnen die Streifen
   Bank, Kippung, Kantencurl und den Barrel-Roll mit — ohne eine eigene Zeile Kinematik.
   Zwei Abweichungen vom Original, beide gemessen nötig: Bandbreite 0,055 statt 0,005 (ihr Flugzeug
   hat 0,22 Spannweite, unsere Karte 3,0), und Punkte werden **strecken-** statt frame-getaktet
   (`minStep 0.10`) — bei 20 km/h lägen sonst 72 Punkte auf zwei Metern, das ist ein Klumpen, kein Band.
3. **Der Lichtschalter ist weg — die Ursache war der Pfadwechsel selbst.** Die Farbraum-Korrektur
   davor war richtig, hat aber nur den großen Sprung beseitigt; es blieb ein Rest, weil der Runner
   zwischen ZWEI Renderpfaden umschaltete: „direkt auf den Schirm" (Blur 0) und „durch den Puffer".
   Zwei Pfade sind nie pixelgleich — gemessen in der Bildmitte (wo Pet und Karte sitzen, dort blurrt
   der Pass gar nicht): direkt **66,97**, durch den Puffer **62,90**. 4 von 255 in EINEM Frame liest
   sich als Lichtschalter, genau wie beschrieben. **Jetzt läuft der Pass immer**, bei Stärke ~0 mit
   einer Ein-Tap-Abkürzung im Shader (Kosten praktisch null). Nachgemessen: Blur 0 und Blur 0,09
   liefern in der Mitte **denselben** Wert (62,90) — es gibt keinen Umschaltmoment mehr.
   Der verbleibende konstante Unterschied von ~6 % gegenüber dem alten Direktpfad kommt vom
   MSAA-Resolve (der Schirmpuffer linearisiert beim Auflösen, ein RGBA8-Target nicht) und ist als
   Konstante unsichtbar. **Regel: nie zwischen Renderpfaden umschalten, während das Bild läuft.**
- **Regler dazu** in „Boost & FX": Kartenecken-Streifen an/aus, „Streifen ab" (km/h-Schwelle),
  Eckstreifen-Breite.
- **Dateien:** `terrain-v6/card-contrails.js` (neu), `terrain-v6/speed-lines.js`,
  `terrain-v6/post-radial.js`, `terrain-v6/card-carrier.js` (`lean` exportiert),
  `terrain-v6/travel-poc.js`.
- **Captures:** `screenshots/01-v6-trails.png` (Reisetempo, Kurve), `screenshots/02-v6-trails.png`
  (Vollgas: dünne Streifen mit weißem Kern + Eckstreifen).
- **Offen:** die Eckstreifen sind bei Reisetempo dezent bis fast unsichtbar (so gewollt) — wenn
  Georg sie früher sehen will, ist es `kmhOn` bzw. die Breite, kein Code.

## 2026-07-25 · v6 · S2 nachgeschärft: Streifen aus dem Original, Rolle für Karte + Pet, Farbraum-Bug

Georgs Review der ersten S2-Fassung, drei Befunde — alle drei berechtigt, alle drei behoben.

1. **„Speedlines sehen unecht, klobig, eckig aus."** Ursache: wir hatten die Streifenform in die
   GEOMETRIE gelegt (Rechteck, harte Kante, Alpha pro Vertex). Im Original steckt sie im
   Fragment-Shader. Jetzt 1:1 portiert aus TinySkies `client/src/game/SpeedLines.ts` (2659a5cc):
   `taper = smoothstep(0,0.25,u)·smoothstep(1,0.75,u)`, `halfW = taper·0.35`,
   `shape = 1 − smoothstep(halfW·0.3, halfW, |v−0.5|)` → eine **Spindel mit weichem Rand**, ein
   Strich statt eines Bretts. Zweiter Unterschied, genauso wichtig: das Quad sitzt **mittig auf dem
   Rand-Radius** und ragt ±Länge/2, liegt also größtenteils außerhalb des Bildes — sichtbar ist nur
   die auslaufende Spitze. Deshalb legt sich nie ein Streifen über Karte oder Pet, und die
   Report-Werte (Länge 0,35–0,84, Breite ×5 im Boost) stimmen plötzlich alle.
   Unser Abweichen bleibt bewusst: **ein Draw-Call** (eine Geometrie, `aUv`/`aLife` als Attribute)
   statt 24 Meshes, Spawn nur in FREIE Slots, Pool 32.
2. **Barrel-Roll dreht jetzt das Fahrzeug, nicht das Pet.** Der Winkel entsteht weiter in
   `pet-kinetics.js`, angewandt wird er in `card-carrier.js` (`rig.setBarrelRoll`) — direkt nach
   `group.quaternion.copy(st.quaternion)` und damit **vor** Lean und Fuß-Clip-Ebene. Karte und Pet
   rollen gemeinsam um die Karten-Mitte, physikalisch plausibel (Fahrzeug rollt, Passagier fährt mit).
   Hätte man den Roll nach `sync()` aufgesetzt, würde die aus `lean` gebaute Clipping-Ebene während
   der Rolle in die alte Richtung zeigen und das Pet anschneiden.
3. **„Aufhellen/Abdunkeln wie ein Lichtschalter" war ein echter Bug, kein Effekt.** Doppelte
   sRGB-Kodierung: die Szene wurde in ein Target geschrieben, das three bereits kodiert, und unser
   Fullscreen-Shader kodierte per `<colorspace_fragment>` ein zweites Mal. **Gemessen** (Pixel-
   Mittelwert, 1848×1080): direkt **82,7** → durch den Pass **144,0**. Genau der Sprung in dem Frame,
   in dem der Pass anspringt. Fix: das Target ist jetzt exakt das, was der Schirm auch wäre
   (`UnsignedByteType` + `SRGBColorSpace`, MSAA 4), der Shader schreibt unverändert durch.
   **Nachgemessen: 92,88 direkt → 92,41 durch den Pass → 92,26 mit Blur 0,09** — Delta 0,5 von 255,
   also unsichtbar. Der Blur mittelt jetzt in sRGB statt linear; für einen Zoom-Blur ist das der
   übliche und optisch unauffällige Kompromiss.
- **Streifen-Look als Regler:** Default ist `light` — additiv in der **Panel-Farbe** der Story
  (Cremeweiß), nicht in reinem Weiß. Das ist der TinySkies-Read in KFB-Farbe. Die Bloom-Sorge aus
  Embed-Doc §15 gilt hier nicht: dieser Pass läuft NACH der Szene und kann kein Szenen-Objekt
  überstrahlen. `ink` (Story-Tinte, normales Blending) bleibt als Comic-Variante im Overlay.
- **Dateien:** `terrain-v6/speed-lines.js` (neu geschrieben), `terrain-v6/post-radial.js`,
  `terrain-v6/card-carrier.js`, `terrain-v6/pet-kinetics.js`, `terrain-v6/travel-poc.js`.
- **Captures:** `screenshots/01-v6-s2c.png` (Look „Licht"), `screenshots/02-v6-s2c.png` (Look „Tinte"),
  `screenshots/01-v6-s2b.png` (Karte + Pet mitten in der Rolle).
- **Nebenbei:** Overlay-Kopf sagte im v6-Build noch „KFB TRAVEL V5" — Zeile behoben und als
  `eyebrow`-Option herausgezogen, damit sie beim nächsten Fork nicht wieder lügt.

## 2026-07-25 · v6 · S2 erledigt: Speedlines, Radial-Blur, Barrel-Roll — der Boost ist ein Ereignis

- **v6 angelegt** als Fork von v5: `KFB Travel v6.dc.html` → `terrain-v6/` (15 Module). v5 ist FROZEN.
  Neuer Sprintplan `docs/SPRINT_travel-v6.md`; der v5-Plan behält die Grundrisse der offenen Slices.
- **Was:** Fünf Stimmen am selben Regie-Skalar plus einem Boost-Impuls (`boostPulse`, Einsatz 9/s,
  Auslauf 2,2/s): **Speedlines** (`speed-lines.js`, Pool 24 Quads, Story-Ink, NormalBlending,
  Deckel 0,35) · **Radial-Blur** (`post-radial.js`, Zoom-Blur, 10 Taps, Mitte scharf) ·
  **Barrel-Roll** (genau eine 360°-Drehung pro Einsatz, danach exakt 0) · **Kamera** (Dolly +0,6,
  Höhe +0,15, FOV bis 73,7°) · **Lenk-Autorität** `boostYawGain 1.28`.
- **Warum der Blur hierhin gehört:** Georgs WebGPU-Beispiel ist nicht portierbar, der Effekt aber ein
  trivialer Fullscreen-Pass — und ein radialer Blur an `heat` IST die Boost-Regie, kein zweites
  System. Bei Stärke 0 rendert die Szene direkt auf den Schirm: kein Puffer, volles MSAA, keine
  Kosten in Ruhe.
- **Render-Reihenfolge ist jetzt Kanon:** Szene → `post.render()` → `lines.render()` → `hud.render()`.
  Verifiziert am Bild: bei Blur 0,106 ist der Tacho-Würfel scharf.
- **Farbraum, damit es nicht kippt:** Rendertarget bleibt linear (HalfFloat, MSAA 4), der Blur mittelt
  linear, `<colorspace_fragment>` konvertiert erst am Schirm — wie three's OutputPass. Screenshot
  mit und ohne Pass zeigt keinen Helligkeitssprung.
- **Drei Report-Zahlen am Bild korrigiert** (Merksatz „Textur-Schrift ist keine DOM-Schrift" gilt
  analog für Bildraum-Maße): Streifenbreite 5× → 2,6× (5× wären 34 px = Brett), Länge 0,84 → 0,55
  plus `rInMin 0.40` (vorher legten sich Streifen über Pet und Karte), und die inneren Ecken tragen
  nur 8 % Deckkraft, damit der Streifen ausläuft statt abzubrechen.
- **Der Kurven-Drag aus dem Report existiert bei uns nicht** — Lenken kostet kein Tempo. Statt einen
  Drag einzubauen, nur um ihn im Boost abzuschalten: mehr Lenk-Autorität während des Boosts. Gleiche
  Absicht, keine erfundene Mechanik.
- **Gemessen** (924×540, HEROIC): Ruhe `heat 0.039` · 6 km/h · 0 Streifen · Blur 0 (Pass übersprungen)
  · FOV 54,5°. Vollgas `heat 0.986` · 75 km/h · 24 Streifen · Deckkraft 0,35 · Blur 0,106 · FOV 73,7°
  · Roll 6,21 rad nach 0,85 s → 0. Nach dem Loslassen alles zurück auf null (der Gleitflug braucht
  ~8 s, nicht die FX).
- **Neue Overlay-Sektion „Boost & FX"** zwischen Reise und Welt: Speedlines an/aus, Dichte, Deckkraft,
  Radial-Blur, Barrel-Roll, Lenken im Boost, Live-Werte. S3–S6 sind damit am Bild justierbar.
- **Offen:** Pool ist bei Vollgas mit 24 Streifen ausgeschöpft — wenn dichter gewünscht, Pool auf 40
  heben, nicht die Lebensdauer kürzen (sonst flackert es).
- **Dateien:** `terrain-v6/speed-lines.js` (neu), `terrain-v6/post-radial.js` (neu),
  `terrain-v6/travel-poc.js`, `terrain-v6/pet-kinetics.js`, `terrain-v6/flight-controller.js`,
  `KFB Travel v6.dc.html`, `docs/SPRINT_travel-v6.md`.
- **Captures:** `screenshots/01-v6-s2-boost.png` (Einsatz), `screenshots/02-v6-s2-boost.png` (Vollgas).

## 2026-07-25 · v5 · Blauer Screen behoben (Waisen-Stage) + Würfel wächst beim Anfassen

**Bug: leerer blauer Screen, den nur ein Reload heilte.** Ursache gefunden statt weggeklickt: der
DC-Runtime ersetzt bei einem Template-Re-Render den `#tv-stage`-Knoten. Der Canvas hing danach an
einem **Waisen-Stage** — `parentElement` zeigte weiter auf „tv-stage", `document.contains()` war
false, `__travelPOC` lief samt Frame-Schleife weiter und rendert in ein Nichts. Reload half nur, weil
der Boot dann zufällig nach dem letzten Re-Render lag.

- **Fix:** Re-Attach-Wache in `travel-poc.js`. Alle halbe Sekunde `document.contains(canvas)` prüfen;
  wenn nein, das aktuelle `#tv-stage` holen und Canvas, Badge, Overlay und Hinweiszeile dort
  wieder einhängen, danach `resize()` und Kamera-Snap. Alle Größen lesen jetzt `liveStage`, nicht
  mehr das beim Boot gefangene Element.
- **Verifiziert** durch Erzwingen des Fehlers: Stage-Knoten ersetzt → `canvasInDoc: false` → nach
  900 ms `true`, am neuen Knoten, Overlay mit, 924×540.

**Würfel: klein als Instrument, groß als Menü** (S12 Teil 1, mit Georg abgestimmt).
`restScale 0.67`, Feder `growStiff 12`, `menuHold 2.2 s`. Gemessen: 131 px → 196 px → 131 px.
Auslöser: Hover, Drag, `spinTo()`.

- **Folge, sofort mitbehoben:** bei 131 px ist die Tacho-Seite nur ~58 px breit, die Zahl wäre auf
  12 px gefallen. Der Tacho hat jetzt zwei Fassungen — kompakt im Ruhezustand (Zahl `0.28·S`,
  größere Nadel, vier Teilstriche, kein `km/h`, kein Modus-Text), vollständig ab `grow > 0.45`.
- Neue Debug-Getter: `hud.sizePx`, `hud.growth`.

**Strahlen-Frage beantwortet (S13 im Sprintplan).** Das WebGPU-Radial-Blur-Beispiel ist nicht
portierbar — Travel läuft WebGL2 — aber der Effekt ist ein trivialer Fullscreen-Pass und gehört in
S2 (Speedlines), nicht in einen eigenen Slice. Skydome-Würfel brauchen dagegen SelectiveBloom (kein
Fullscreen-Pass kann ein Einzelobjekt umstrahlen), Leuchtturm-Karten einen additiven Kegel
(„Fake-Volumetric"), nicht echtes Raymarching. Notiert: sobald ein Post-Pass läuft, muss
`hud.render()` **dahinter** kommen, sonst wird der Tacho mitgeweichzeichnet.

## 2026-07-25 · v5 · Session-Cut, Check-in, Übergabe an v6

- **v5 geschlossen** mit S0, S1 (`travelHeat`), S7 (HUD-Würfel), S8 (Settings-Overlay). Dateien:
  `KFB Travel v5.dc.html` + `terrain-v5/` (13 Module).
- **Export:** `export/travel-v5_2026-07-25/` mit `MANIFEST.md`.
- **Neue Slices aus Georgs Review aufgenommen** (alle → v6):
  **S10** Modus ohne Schalter (WoW-Logik: Doppel-Leertaste abheben, `X` sinken, Bodenkontakt → Walk) ·
  **S11** Rahmen (KayfaBizarro-Wortmarke links aus `themes/kfb-med.css`, Meta klein rechts,
  Modus-Anzeige weg) · **S12** Würfel v2 (ein Drittel kleiner, kein ALLCAPS, Special Elite,
  Abnutzungs-Decal, Grundfläche in der aufgehellten Pet-Base-Color).
- **Zwei Abhängigkeiten notiert:** S11 darf die Modus-Anzeige erst streichen, wenn S10 steht (sonst
  fehlt die Auskunft ohne Ersatz). Und S12 senkt die Label-Größe von 18 px auf 12 px — trägt erst mit
  Georgs Icon-PNGs oder mit einem Würfel, der im Menü-Zustand wächst.
- **Nächster Sprint v6:** S2 (Speedlines + Boost) zuerst, dann S10–S12.

## 2026-07-24 · v5 · S8 erledigt: Settings-Overlay + konsolidierte Steuerung

- **Was:** `terrain-v5/settings-overlay.js`. Fast flächendeckendes Papier-Panel, das seine Sektionen
  als Daten vom Runner bekommt; das Spiel läuft dahinter weiter. Acht Cluster nach Häufigkeit:
  Karten (Story-Modus) · Rhythmus (BPM, Beat-Kopplung) · Reise (Fly⇄Walk, Tempi, Kamera, POV,
  Tacho-Eichung, Live-Werte) · Welt (fünf Terrain-Regler, Rebake debounced) · Himmel (zehn Varianten,
  Welt-Mischung, Belichtung, Spirale) · Pet (alle Pets aus dem Vertrag, altes wird disposed) ·
  Steuerung (Legende beider Modi) · System (Seed, Auflösung, Reset).
- **HUD aufgeräumt:** die zwei Legenden-Blöcke sind weg, das Badge zeigt nur noch `FLY`/`WALK`, dazu
  eine Hinweiszeile, die nach 8 s ausblendet und ab der zweiten Sitzung gar nicht mehr erscheint.
- **Story-Modus ist jetzt live schaltbar** — neuer WorldContext, Terrain rebaked, Himmel und Würfel
  in der neuen Palette. Verifiziert mit FORBIDDEN: `storyIdx 5`, Nebel `#503550`, Würfel-Nadel in
  Wein. Capture: `screenshots/v5-forbidden.png`, Overlay: `screenshots/v5-settings.png`.
- **Pet-Wechsel** läuft über denselben Pfad wie der erste Mount (ein Pfad, kein Sonderfall);
  verifiziert mit `fox`.
- **Zwei Fallen:** (1) das Overlay liest beim Bauen alle Werte → `zoomTarget` war weiter unten
  deklariert und riss den Boot mit `ReferenceError: Cannot access 'zoomTarget' before initialization`
  ab; Kamera-Zustand steht jetzt vor dem Overlay. (2) Tasten müssen dem Formular gehören, solange es
  offen ist — sonst fliegt die Karte, während man den Seed tippt.
- **Nachgezogen:** Akzentfarbe läuft jetzt über eine Custom-Property am Root (`--kfb-accent`) statt
  inline eingebacken — vorher blieben Slider-Thumbs und Live-Werte nach einem Story-Wechsel orange in
  einem weinroten Panel. `setAccent()` zieht alles mit einem Zuweisen nach.
- **Dateien:** `settings-overlay.js` (neu), `travel-poc.js`, `flight-controller.js`,
  `walk-controller.js`, `travel-heat.js` (je `setParams`/`params`), `KFB Travel v5.dc.html`.

## 2026-07-24 · v5 · Würfel: Texturen auf der Geometrie statt Planes davor

- **Georgs Befund:** „als wären die Flächen einfach sichtbar davor platziert, dadurch gehen die
  abgerundeten Ecken verloren“. Genau so war es: sechs `PlaneGeometry` vor den Würfelseiten —
  aufgeklebte Schilder, deren eckige Ecken über die gerundete Silhouette ragten (gemessen 2–3 px).
- **Fix:** ein Mesh, sechs Materialien. `RoundedBoxGeometry` erbt von `BoxGeometry` und damit deren
  sechs Material-Gruppen und UVs — die Textur sitzt also direkt auf der gerundeten Fläche. Klick
  läuft jetzt über `intersection.face.materialIndex` statt über Plane-Meshes.
- **Preis, bewusst bezahlt:** die UV einer Seite schließt die Rundkante ein → Inhalt braucht 12 %
  Sicherheitszone (`hud.safeZone`). Steht als Vorgabe für die Procreate-PNGs im Sprintplan.
- **Gemessen nach dem Umbau:** Seite 107 px auf dem Schirm, Label 18,2 px, km/h 12,3 px; Worst Case
  (Spin + maximale Neigung) NDC 0,825 — vorher schnitt der Spin die Silhouette an (1,000).
- **Capture:** `screenshots/v5-hud-cube.png`.

## 2026-07-24 · v5 · Würfel rahmenlos + Tacho-Nadel, drei Walk-Bugs

**Würfel (Georgs Review):**
- Rahmen weg. Flächen sind durchgehend, Schrift und Icon sitzen direkt auf dem Papier (Fläche 0,955
  der Seite, Korpusfarbe = Flächenfarbe). Der schwarze Rahmen ist damit frei für seine echte
  Aufgabe: unsichtbare Clip-Maske für Embeds (S9).
- Oberfläche: `Textures/Paper003` (seamless, leichtestes Set) als `normalMap` + `roughnessMap` —
  der Würfel wirkt nicht mehr wie glattes Plastik. `edge3` wäre falsch: Rand-Textur, kachelt nicht.
- Tacho ist jetzt eine **Nadel-Anzeige** (Halbkreis, acht Teilstriche, letzte zwei als Redline,
  Zeiger auf `travelHeat`). Damit ist auch der Rest-Balken bei 0 km/h weg — die Nadel steht am
  linken Anschlag.

**Bugs:**
1. **Beim Wechsel in den Walk-Mode im Cube gelandet.** Ursache: `walk.reset` bekam EINE
   Höhenprobe aus der Mitte — hüpfende Nachbarsäulen und der Körperradius waren nicht drin. Jetzt
   `safeGroundAt()` (Mitte + 8 Ringproben) plus `terrain.maxLift()` und 0,25 Reserve; die Schwerkraft
   setzt das Pet dann sauber ab. Zusätzlich pro Frame eine **Rettung**: steckt das Pet trotzdem
   tiefer als die Umgebung, hebt `walk.lift()` es auf die Oberfläche.
2. **Pet zeitweise unsichtbar.** Zwei Ursachen, beide behoben: der Kamera-Aufzug
   (`groundHeight + 1`) konnte die Kamera über das Pet heben, sodass sie in den Himmel schaute —
   jetzt gibt es eine Obergrenze, und statt höher wird die Kamera **näher** herangezogen. Und der
   POV-Modus (Zoom bis 0) versteckt das Pet absichtlich, sagte es aber nicht: der Tacho zeigt jetzt
   `WALK·POV` bzw. `FLY·POV`. POV-Blick außerdem weniger steil nach oben.
3. **Roter Rest-Balken bei 0 km/h.** Erledigt mit der Nadel (siehe oben).

- **Dateien:** `terrain-v5/hud-cube.js`, `travel-poc.js`, `walk-controller.js` (`lift()`).
- **Capture:** `screenshots/v5-walk-cube.png`.

## 2026-07-24 · v5 · S7 erledigt: HUD-Würfel

- **Was:** `terrain-v5/hud-cube.js`. Terrain-Würfel unten rechts, zweiter Render-Pass im
  Scissor-Viewport. Ruhezustand = Tacho (geeichte km/h + Modus + Heat-Balken), angefasst = Menü mit
  sechs Funktionsseiten (Karten, Musik, Welt, Himmel, Pet; die Tacho-Seite ist der Reise-Knopf).
  Oberfläche ist die **geteilte Kanten-Textur** aus `voxel-terrain.js` → sichtbar aus derselben Welt.
- **Aus der Academy portiert:** RoundedBox mit Fallback, CanvasTexture pro Seite, Slerp-Targeting,
  Drag-Trägheit. Neu: Rückkehr in die Tacho-Position nach 2,5 s, aufrechte Beschriftung über
  `texture.rotation`, Neigung gegen Bank und `heat.rate`.
- **Zwei Fallen, die beim Bauen auffielen:** `stopPropagation()` reicht nicht, wenn zwei Listener am
  SELBEN Element hängen (AT_TARGET) — jetzt `stopImmediatePropagation()` plus `e.__hudClaimed`-Marke,
  die travel-poc prüft (verifiziert: Würfel-Drag lenkt nicht mehr). Und: frontal gerastet liest sich
  ein Würfel als Rechteck — jede Rast-Position trägt jetzt dieselbe leichte 3/4-Neigung.
- **HUD:** Tastenlegende nach unten links verschoben (Kollision) — sie verschwindet mit S8.
- **Dateien:** `terrain-v5/hud-cube.js` (neu), `travel-poc.js`, `voxel-terrain.js` (`edgeTex`
  exportiert), `KFB Travel v5.dc.html` (Legende links).
- **Nachjustiert nach Messung:** Beschriftung war mit `0.082·S` nur 7 px groß (die Fläche ist auf dem
  Schirm ~90 px breit) → Labels `0.15·S`, km/h und Modus `0.105·S`, `minSize` 168 → gemessen 16,6 px
  bzw. 12 px. Und bei hartem Bank ragte die Würfelecke aus dem Scissor-Viewport (NDC 1,03) →
  Neigungs-Clamps auf ±0,16 / ±0,12, Mini-Kamera auf `z = 3.25` → Worst Case jetzt NDC 0,77 / 0,81.
  **Merksatz:** Textur-Schrift ist keine DOM-Schrift — vorher ausrechnen, wie viele Bildschirm-Pixel
  eine Textur-Einheit hat.

## 2026-07-24 · v5 · S7 revidiert: three.js statt CSS-3D (Cube Academy als Vorlage)

- **Auslöser:** Georg hat die **KFB Cube Academy v1** hochgeladen (`uploads/KFB Cube Academy v1/`) —
  dort ist die Würfel-Mechanik fertig gebaut, und zwei neue Anforderungen kamen dazu: Design 1:1 wie
  die Terrain-Cubes (Borders + Kanten-Textur) und der Ugur-D6 für Quest/Story.
- **Entscheidung gedreht:** CSS-3D scheidet aus — die Terrain-Optik ist ein `ShaderMaterial` mit
  `uEdge`, kein CSS-Effekt, und der D6 ist ein GLB. Also **three.js-Overlay** (eigene Szene, zweiter
  `render()` mit `autoClear=false`, Raycast für Klicks).
- **Aus der Academy übernommen:** `RoundedBoxGeometry(D,D,D,6,D*0.07)` mit `BoxGeometry`-Fallback ·
  `CanvasTexture` pro Seite (`anisotropy = 8`) · `quaternion.slerp(target, 1−0.0022^dt)` mit
  `angleTo < 0.004` als Abbruch · Drag-Trägheit `0.045^dt`, danach Eigen-Tumbeln.
- **Der wichtigste Trick von dort:** Embeds laufen **nicht auf der Würfelfläche**, sondern in einem
  DOM-Overlay mit `<iframe>`; die Fläche trägt nur das gemalte Vorschaubild. Scharfe Schrift, echte
  iframes, keine Textur-Unschärfe. Wird als **S9 (Monitor-Würfel)** eigener Slice: YouTube,
  three.js-Demo, LLM-Chat, skalierbar.
- **Drei Register statt zwei:** Werkzeug (Terrain-Voxel + PNG-Decal) · Orakel (Ugur-D6, Würfelaugen) ·
  Monitor (Glas-Seite + Overlay).
- **Backlog ergänzt:** Graveyard-Slice + Kenney-Assets ins Terrain streuen — viel später, eigener
  Sprint; Playbook liegt in der Academy-Zip.

## 2026-07-24 · v5 · Karte schneidet nicht mehr in hüpfende Cubes

- **Was:** Die Flughöhe war an EINER Höhenprobe in der Fahrzeugmitte geklemmt — die Karte ist aber
  3.0 × 1.68 groß und bankt, und die Cubes hüpfen nach oben. Ergebnis: die Ecken schnitten in
  steigende Würfel. Jetzt tastet `cardClearance()` die ganze Grundfläche ab (Mitte + 4 Ecken),
  einmal an der aktuellen und einmal an der voraus liegenden Position (`1.2 + speed·0.22`), nimmt
  den schlechtesten Fall und rechnet Bob-Reserve (`terrain.maxLift()`) plus den Tiefgang der
  untersten Ecke (`sin(bank)·halfW + sin(pitch)·halfD`) drauf. Steigen schnell (14/s), Sinken
  langsam (2,2/s).
- **Warum keine Physik-Engine:** Wir brauchen keine Kollisionslösung, nur eine ehrliche Bodenhöhe.
  Zehn Noise-Proben pro Frame kosten nichts; eine Engine würde Broadphase, Körper und Solver für
  ein Problem einführen, das eine Höhenfunktion schon beantwortet.
- **Dateien:** `terrain-v5/travel-poc.js`, `terrain-v5/card-carrier.js` (`halfW`/`halfD` exportiert).
- **S7 präzisiert:** Tacho ist die **Startposition** des Würfels (Rückdrehung nach ~2,5 s Ruhe),
  Beschriftung kontert die Drehung (Smartphone-Logik), `spinTo(face)` von Anfang an vorsehen
  (später Story-Mode-Wurf und Quest-Fortschritt). Design-Empfehlung: **ein Objekt, zwei Register** —
  Terrain-Voxel = Werkzeug, Sky-D6 = Orakel, der Spin-Flip ist der Übergang.

## 2026-07-24 · v5 · S1 erledigt: Regie-Skalar `travelHeat`

- **Was:** `terrain-v5/travel-heat.js`. Eine geglättete 0..1-Zahl plus Ableitung plus geeichte
  km/h-Anzeige. Reisetempo belegt die unteren 17 % der Skala, darüber `t·(2−t)`; Boost hebt auf
  mindestens 0,72, Sprungphase im Walk +0,10.
- **Warum:** Ohne diese Zahl bekommt jeder FX-Slice eine eigene Speed-Formel. Kamera-Dolly,
  Kamerahöhe, Look-Ahead, FOV (Flug + Walk), Walk-Chase-Abstand und Terrain-Energie hängen jetzt
  daran — die alten `st.speed`-Formeln sind ersetzt, nicht ergänzt.
- **Tacho-Eichung:** `unitMeters = 0.5` (ein Cube = 3 units ≈ 1,5 m). Gehen ≈ 10 km/h, Sprint
  ≈ 17 km/h, Reiseflug ≈ 16 km/h, Vollgas ≈ 76 km/h. Der alte Ride-Tacho log, weil genau diese
  eine Zahl fehlte.
- **Dateien:** `terrain-v5/travel-heat.js` (neu), `terrain-v5/travel-poc.js`.
- **Neu im Plan:** S7 (HUD-Würfel als Instrument + Menü, CSS-3D) und S8 (Settings-Overlay,
  konsolidierte Steuerungs-Legende). Empfohlene Reihenfolge ist jetzt S1 → S7 → S8 → S2…, weil das
  Panel die Tuning-Oberfläche für die FX-Slices ist.

## 2026-07-24 · v5 · Fork angelegt, Sprintplan persistiert

- **Was:** `KFB Travel v5.dc.html` + `terrain-v5/` als Fork des v4-Session-Cuts. v4 ist FROZEN.
  Sprintplan `docs/SPRINT_travel-v5.md` mit sechs Slices (Regie-Skalar → Speedlines/Boost →
  Rim-Light → FX-Pool → Story-Presets → Modus-Tor), Arbeitsregeln für frische Chats, Backlog und
  einer Liste bewusst verworfener Ideen.
- **Warum:** Die TinySkies-Analyse soll additiv über mehrere Chats abgearbeitet werden, ohne dass
  Kontext verloren geht oder v4 kaputt geht.
- **Dateien:** `KFB Travel v5.dc.html`, `terrain-v5/*` (9 Module + `edge3.jpg`),
  `docs/SPRINT_travel-v5.md`, `docs/CHANGELOG_travel.md`.
- **Nebenbei gefixt:** HUD lag hinter dem Canvas (`#tv-hud` ohne `z-index`) — jetzt `z-index:4`.
- **Offen:** S1 (`travelHeat`) ist der nächste Schritt und Voraussetzung für S2–S4.

## 2026-07-24 · v4 · Analyse TinySkies / GlobeFly

- **Was:** 13 Module aus `dannylimanseta/tinyskies@2659a5cc` im Detail gelesen, Report als
  `KFB TinySkies Analyse.dc.html`: Ampel-Inventar, sieben Übernahme-Bausteine mit konkreten Werten,
  fünf bewusste Nicht-Übernahmen, Sechs-Schritt-Reihenfolge.
- **Befund, der eine Erwartung korrigiert:** Es gibt dort keinen Partikel-Wirbel am Boost. Der
  Boost ist Barrel-Roll + zurückfallende Kamera + FOV-Weitung + verbreiterte Speedlines, alles an
  *einer* normalisierten Speed-Zahl. Der echte Swirl-Shader sitzt im Teppich-Portal.
- **Achtung beim Klonen:** Default-Branch ist `cursor/globefly-multiplayer-globe-flight-game`,
  nicht `main` — naive Repo-Zugriffe laufen ins 404.

## 2026-07-24 · v4 · Session-Cut + Pfad-Hygiene

- **Was:** Teil-Export nach `session-export_v1` (17 Dateien, alles < 2 MB, `MANIFEST.md` dabei).
  Pet-Stack läuft kanonisch über jsdelivr (lokaler Spiegel nur Fallback), Kartenrücken über
  `raw…/media/kfb/`, Kanten-Textur RAW-first.
- **Offen:** `edge3.jpg` (2,5 KB) liegt noch nicht im Repo → gehört nach
  `media/3D_Assets/Textures/edge3.jpg`; bis dahin greift der lokale Fallback und die Datei reist im
  Export mit.
- **Stolperstein für später:** Beim RAW-first-Fallback müssen die Bilddaten im `onLoad` des
  Fallback-Loaders übernommen werden, nicht synchron im `onError` des ersten — sonst ist
  `t.image` noch `undefined` und die Konsole spammt „Texture marked for update but no image data".
- **Altlast, in v5 gefixt:** `#tv-hud` lag ohne `z-index` im gleichen Stacking-Kontext wie das
  `<canvas>` → das HUD (Titel, Tastenblock) war komplett unsichtbar, nur die Mode-Badge mit
  `z-index:5` kam durch. In v4 steht der Fehler noch (FROZEN, bewusst nicht angefasst).

## 2026-07-24 · v4 · Achsen, Auto-Hop, Cartoon-Kinetik

- **Was:** Drei Fehler und ein Feature.
  1. **Achsen entdreht:** `heading += turn` (war `−=`) und `right = cross(forward, up)` — A/D und
     Q/E waren im Walk-Mode seitenverkehrt.
  2. **Auto-Hop:** Körper-Radius 0,55 in der Kollision (das Pet lief vorher in den Cube hinein) und
     ein vorausschauender Absprung: gezündet, solange die Kante eine Steigzeit entfernt ist,
     Absprunggeschwindigkeit auf die nötige Höhe gerechnet (`v = √(2g·(rise+0.55))`), davor ~90 ms
     Windup. Kanten über 4,2 gelten als Wand → sliden statt springen.
  3. **Frame-Reihenfolge:** `pet.update(dt)` lief NACH unserer Kinetik — PetMotion hat den Lean
     jedes Frame weggedämpft. Jetzt Motor zuerst.
  4. **Cartoon-Grammatik für beide Modi:** Anticipation-Duck → Launch-Pop → Stretch beim Steigen →
     Apex-Hang → Fall-Stretch → Land-Squash ∝ Aufprall → Rebound-Overshoot → Ruhe. Squash jetzt
     volumenerhaltend (`Sxz = 1/√Sy`) statt Näherung. Dazu der GLB-Clip-Layer: idle/walk/run mit
     `timeScale` an der echten Bodengeschwindigkeit (keine rutschenden Füße), `static` in der Luft,
     `initParts()` für Ohren- und Schweif-Federn.
- **Dateien:** `terrain-v4/walk-controller.js` (neu), `pet-kinetics.js` (neu), `travel-poc.js`.
- **Kanon:** `cartoon-motion_v1.md`, `EMBED_CUBE_PET_FULL_v2.md` §5/§7f.

## Vorgeschichte (vor diesem Changelog)

Slice 1 Flug · Slice 3 Terrain/Welt (deterministischer v3-Seed, ein Story-Mode) · Slice 4
Walk-Controller + Fly⇄Walk-Switch. Details in `HOUSEKEEPING.md`, Abschnitt „KFB Travel v4".

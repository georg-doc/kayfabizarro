# Session-Export · KFB Travel v9 „Runtime" (2026-07-25)

Der Fork, der die Verdrahtung aus `travel-poc.js` geholt hat — und dabei mehr Fehler gefunden als
gebaut. **Für den Coworker:** was gilt, was gemessen ist, und woran man die Fehlerklassen erkennt.

## 1 · Was gebaut wurde

| Slice | Inhalt | Belegzahl |
|---|---|---|
| **S41 · A CameraRig** | eine Schreibstelle für die Kamera, POV als Faktor, Blickziel gefedert | 4 → **1** Kamera-Schreiber · Dock-Blickdrehung max 0,197°/Frame |
| **S42 · B Modus-Eigentum** | `requestMode(mode, reason)` mit vier benannten Regeln, `enter/exit`-Verträge, `assertController` | `switchMode` weg · Vertragsprüfung 4/4 · jede Regel einzeln gemessen |
| **S43 · Zonen-Stern + Warp** | fünf Kapitel als Orte im 72°-Stern, Leine aus, Warp als Faktor | Bearings 13/89/158/231/304° · 58,8 u/s bei Grenze 42 (**+40 %**) |
| **S44 · C TravelManager** | Pipeline als getaktete Liste, Fehler-Isolation je Schritt | render 2,16 ms · world 0,27 · vehicle 0,18 · 0 kaputte Schritte |
| **S44b · Panel als Schema** | ~290 Z Regler → `settings-schema.js`, Locals per `defineProperty` gefenstert | Runner 1418 → 1178 Z · 91 Bedienelemente geprüft |
| **S44c · Eingabe-Schicht** | Tasten/Zeiger/Rad/Doppelklick als Modul | Runner → 1071 Z |
| **S44d · Bühne** | Renderer, Szene, Licht, Nebel, Sonden | Runner → 1014 Z |
| **S45 · V9-D Ereignisse** | acht Anmeldungen in einer Tabelle, kein Bus | **0 Duplikate** (Bus-Absage gemessen richtig) |
| **S45 · Fahrgefühl** | Rückwärtsgang (S), Standdrehung (Q/E), Touchpad-Zoom | −10,4 u/s · 154° in 1,5 s bei 1,6 u · 0,126 u pro kleinem Wisch |
| **S46 · Kartentitel** | Irish Grover extrudiert, papierfarben nach Zone, Sublines | einzeilig bis 54 Zeichen · Band konstant über 11 Reglerzüge + 300 Frames |

## 2 · Die Invarianten (gemessen, nicht behauptet)

- **Genau 1 Modul schreibt die Hauptkamera** (`camera-rig.js`). `academy-lessons` und `hud-cube`
  haben eigene Kameras — die zählen nicht.
- **0 Allokationen im Frame-Pfad** (`new THREE.*` nach `setAnimationLoop`). **Achtung:** diese
  Messung sieht **keine Objektliterale** — daran ist S42 vorbeigekommen.
- **`switchMode` existiert nicht** (nur als Wort im Auftrags-Kommentar), **`modeLockT` nicht**,
  **0 verstreute `x.onFoo =`-Zuweisungen**.
- **Pipeline:** `attach → fade → vehicle → world → render`, ausdruckbar (`mgr.order`), getaktet
  (`mgr.timing`), pro Schritt isoliert (`mgr.broken`).
- **Die Version gehört dem Runner.** Kein Modul kennt seine Version — im Clean-up erneut
  durchgesetzt (16 Module trugen noch „Travel v7" aus dem v7-Fork).
- **Karten sind keine Powers:** keine Zahlenwerte, Trefferpunkte oder Punktestände im UI.

## 3 · Module

| Modul | Zeilen | |
|---|---|---|
| `travel-poc.js` | 1050 | aus v8 |
| `academy-cards.js` | 472 | aus v8 |
| `settings-schema.js` | 325 | **neu in v9** |
| `autopilot.js` | 314 | aus v8 |
| `academy-lessons.js` | 260 | aus v8 |
| `voxel-glyphs.js` | 253 | aus v8 |
| `academy-deck.js` | 244 | aus v8 |
| `card-title.js` | 232 | **neu in v9** |
| `camera-rig.js` | 217 | **neu in v9** |
| `lesson-search.js` | 197 | aus v8 |
| `travel-input.js` | 154 | **neu in v9** |
| `academy-live.js` | 150 | aus v8 |
| `mode-owner.js` | 140 | **neu in v9** |
| `card-dock.js` | 138 | aus v8 |
| `ink-tail.js` | 131 | aus v8 |
| `travel-stage.js` | 100 | **neu in v9** |
| `pet-facing.js` | 89 | aus v8 |
| `travel-manager.js` | 85 | **neu in v9** |
| `travel-events.js` | 70 | **neu in v9** |

## 4 · Die Fehlerklassen, die diese Session hinzugefügt hat

Zu den sieben aus v8 kamen fünf, alle aus echten Fehlschlägen (Liste vollständig in
`docs/INTERMISSION_reviews_v8.md` §5):

8. **Eine Schwelle, die dreimal im Code steht, ist dreimal falsch.** Der Dock-Übernahmepunkt stand
   als 0,25 / 0,42 / 0,25 an drei Stellen — geändert habe ich die unwirksame Kopie.
9. **„Eine Zahl, ein Ort" gilt in beide Richtungen.** Fünf Academy-Regler standen auf Parametern, die
   der Zonen-Stern entfernt hatte: einer druckte NaN, vier taten still nichts.
10. **Eine Bezeichner-Ersetzung ohne String-Maske ist eine Wette.** Aus `requestMode('walk', …)`
    wurde `'ctx.walk'` — in drei Dateien. Gefunden hat es der Modus-Eigentümer, weil er Ablehnungen
    **benennt**.
11. **Zustand wird gehalten, nicht aus dem Cache-Schlüssel zurückgerechnet** — und **reserviert wird
    das Maximum**, nicht der aktuelle Reglerwert.
12. **Beim Verschieben von Code prüft man auch, was jetzt doppelt ist** (der `resize`-Listener war
    zweimal angemeldet: 2 × `setSize`, 2,2 ms).

## 5 · Offene Betriebs-Befunde (nicht Architektur)

1. **Responsiver Viewport zu gering** — die Karte nutzt bei schmalen Fenstern zu wenig Fläche.
2. **Sky-Karten haben die falsche Tusche-Familie** (Chip statt Band) — auf `ink-tail.js` umstellen.
3. **Viele Vorschau-Karten nicht anklickbar** — die Trefferprüfung greift offenbar nur bei Karten mit
   Live-Demo.
4. **Post-it wirkt unnatürlich** — braucht Aufkleben/Windzupfen oder eine andere Form.
5. **Pet-Facing im Walk-Modus**, **Beat-Aura**, **Talk-Mouth** (13 Viseme liegen im Pet-Stack).
6. **Ticker-Zeile** im Titel-Band (Story-Beat, Kayfabulation) — Platz ist reserviert.

## 6 · Wie hier getestet wird

Über den **echten Bedienweg** (Rad-Ereignisse, Doppelklick, F/X/Q/E, ⇧+Leertaste), nie über die API.
**Ohne sichtbaren Frame läuft kein rAF** — dann treibt man die Pipeline von Hand und sagt das dazu.
Jede Änderung braucht eine Zahl im Changelog, und die Zahl, die zählt, ist das **Minimum** bzw. das
**p95**, nicht der Mittelwert.

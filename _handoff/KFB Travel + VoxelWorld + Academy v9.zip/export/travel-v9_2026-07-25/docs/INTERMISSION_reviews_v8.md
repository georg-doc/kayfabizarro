# Intermission · die fünf Reviews gegen den Ist-Stand v8

> Gelesen 2026-07-25: `_handoff/KFB_Travel_Architecture_Audit_v1.md` · `…Runtime_Review_v1.md` ·
> `…v2.md` · `…v3.md` (ChatGPT) und `…KFB_Travel_v8_Audit_Report.md` (Gemini).
> Alle fünf sind gegen **v7** geschrieben. Dieses Dokument ist die kritische Prüfung gegen den
> gemessenen Stand von **v8** — und der Plan, der daraus für **v9** folgt.
> **Keine Code-Änderung in dieser Runde.** Erst die Entscheidung, dann der Eingriff.

---

## 1 · Worin sich alle fünf einig sind

| Befund | genannt in | dortige Priorität |
|---|---|---|
| `travel-poc.js` wird ein God Object → **TravelManager** extrahieren | alle 5 | P1 / High |
| **Controller-Vertrag** explizit machen (`enter` · `exit` · `update(dt,input,world)` · `getState()`) | alle 5 | P1–P2 |
| **CameraRig isolieren** — die Kamera ist Konsument des Runtime-States, kein Akteur | alle 5 | P2–P3 |
| **Event-Bus** für Mount/Dismount/Land/Boost/ControllerChanged | 4 von 5 | P1–Medium |
| Feste, dokumentierte Frame-Reihenfolge | 3 von 5 | — |
| CardRig bleibt **rein visuell**, PetKinetics reiner Resonanzkörper, WorldContext reine Lese-Instanz | alle 5 | — (Lob) |
| Telemetrie · Replay · Debug-Overlays | 3 von 5 | Low |

Bewertungen zwischen 8,5 und 9,5 von 10. **Der Ton ist einheitlich: nicht die Algorithmen sind das
Risiko, sondern die Orchestrierung.** Dem stimme ich zu — mit drei Einschränkungen (§4).

---

## 2 · Der Ist-Stand, gemessen (nicht behauptet)

| Zahl | v7 (Review-Basis) | **v8 heute** |
|---|---|---|
| Module in `terrain-v*/` | 18 | **31** (438 KB) |
| `travel-poc.js` | ~62 KB | **86,4 KB · 1327 Zeilen · 26 Importe** |
| Ad-hoc-Callbacks im Runner | 3–4 | **8** (`skyCards.onPass` · `academy.onPass` · `academy.onFocus` · `auto.onArrive` · `auto.onRoute` · `auto.onWarn` · `dock.onDock` · `dock.onLeave`) |
| Module, die `camera.*` schreiben | 2 | **4** (`travel-poc` 10× · `card-dock` 5× · `hud-cube` 1× · `skydome-shader` 1×) |
| Allokationen im Frame-Pfad (`new THREE.*`) | ? | **0** ✅ |

**Zusammensetzung des Runners** — die 1327 Zeilen sind nicht gleichmäßig verteilt:

- **~363 Zeilen Einstellungs-Panel** (Regler-Definitionen, reine Daten) — ab Zeile 580
- **~339 Zeilen `readInput` + Frame-Schleife** (Kamera-Mathematik, Modus-Zweige) — ab Zeile 988
- ~180 Zeilen Boot/Assets/Audio-Arm/Welt-Anwenden
- ~150 Zeilen Zeiger-Behandlung (Klick-Kollision Demo ⇄ Anflug ⇄ HUD)
- Rest: Strip-Text, Glyphen-Anhang, Modus-Wechsel (36 Z), Gelände-Hilfen

**Das ist die eigentliche Nachricht:** über die Hälfte des Runners ist **kein** Orchestrierungscode,
sondern ein Regler-Panel und eine Frame-Schleife. Ein „TravelManager" allein macht den Runner also
nicht klein — er verschiebt 36 Zeilen. **Wer hier wirklich Zeilen bewegen will, zieht zuerst das
Panel und dann die Kamera heraus.** Diese Reihenfolge steht in keinem der fünf Reviews.

Zwei Befunde der Checklisten sind übrigens **schon grün**: 0 Allokationen pro Frame, und die
Ownership-Matrix (`pet-kinetics` schreibt nur Sekundärbewegung, `world-context` nur Abfragen,
`card-carrier` nur Mount-Transform) hält — S33b hat sie sogar bestätigt: das Pet-Facing wurde
absichtlich als eigene Schicht *nach* der Kinetik gebaut und schreibt **nur die Gier**, nie das
ganze Quaternion.

---

## 3 · Wo die Reviews recht haben — belegt mit echten Fehlern dieses Sprints

Nicht aus Prinzip, sondern weil ich die Fehler bezahlt habe:

**a) Kamera-Eigentum (P2/P3) — der härteste Beleg.**
Drei Fehler dieser Woche gehören zu einer Klasse: *mehrere Stellen schreiben dieselbe Kamera und
kennen einander nicht.*
- `card-dock.js` schreibt `camera.position`/`lookAt` direkt (5×) — bewusst als Mixer gebaut, aber
  eben ein zweiter Akteur.
- Der POV-Übergang war ein **Schalter** (`povF = zoomTarget <= 1.6`): beim Kreuzen sprang das *Ziel*
  der Kamera. Behoben, indem beide Blickpunkte gerechnet und mit einem Faktor gemischt werden.
- Dabei fiel auf: der Follow-Kandidat **degeneriert** unter ~2 u Abstand (`camH / camDist` treibt den
  Kurs senkrecht). Gemessen behoben (Zoom hinein max 0,71 u bei Median 0,50).
- **Und es ist noch nicht gut** (Georgs Befund, offen): der Übergang Pet-nah ⇄ POV ruckelt merklich.
  Verdacht: die Pet-Sichtbarkeit schaltet noch hart bei `povS = 0,62`, und `card-dock` mischt
  parallel dazu seine eigene Kamera.
→ **Das ist kein Tuning-Problem mehr, das ist ein Eigentums-Problem.** CameraRig wird deshalb
**V9-A**, nicht P3.

**b) Modus-Eigentum (P1).**
Der Auto-Pilot landete mitten im Anflug im Walk-Modus: eine tief hängende Karte über steigendem
Terrain → Bodenkontakt → `st.landed` → automatischer Modus-Wechsel. Notdürftig behoben mit
`&& !auto.active && !dock.owns`. Genau so entstehen Bedingungsketten, die niemand mehr liest.
**Der Modus braucht einen Eigentümer, der Anträge annimmt oder ablehnt** — das ist der TravelManager,
und das ist das erste Mal, dass ich ihn wirklich gebraucht hätte.

**c) Feste Frame-Reihenfolge.**
Steht heute nur als Kommentar im Runner. S33b hing genau daran (Motor → Kinetik → Facing). Die
Reihenfolge als **Datenliste** statt als Code-Fluss ist billig und macht sie prüfbar.

---

## 4 · Wo ich widerspreche oder verschiebe

**a) Event-Bus: nein, noch nicht.** Vier Reviews wollen ihn, drei nennen ihn P1. Gemessen haben wir
**8 Callbacks mit je genau einem Zuhörer**. Ein Bus entfernt diese Verdrahtung nicht, er *verlegt*
sie — und macht dabei die Aufrufreihenfolge implizit, also unsichtbarer als heute. In einem Projekt,
dessen letzte fünf Fehler *Reihenfolge- und Eigentumsfehler* waren, ist das die falsche Richtung.
**Regel:** ein Ereignis bekommt erst dann einen Bus, wenn es **≥3 Zuhörer** hat. Bis dahin: benannte
Callbacks, aber **an einer Stelle registriert** (V9-D) statt über 1327 Zeilen verstreut.

**b) „ITravelController-Interface": als Prüfung, nicht als Typ.** JS hat keine Interfaces; ein
TS-Block im Review ist hier Deko. Was wirklich trägt: ein dokumentierter Vertrag **plus** eine
Konformitätsprüfung zur Laufzeit im Debug-Modus (`assertController(c)` — hat `enter/exit/update/state`,
`state()` liefert dieselben Schlüssel wie beim letzten Aufruf). Das ist prüfbar; ein Interface ist es
in JS nicht.

**c) CardRig-Animationsschichten aufspalten (P4): nicht anfassen.** Die Reviews nennen `card-carrier`
selbst „one of the strongest parts". Es gibt keinen Schmerz, also keinen Eingriff. Ein Refactor ohne
Fehler, den er behebt, ist ein Refactor, der Fehler einführt.

**d) Telemetrie · Replay · Vehicle-Hierarchie (Boot/Ballon/Drache): gestrichen für v9.** Das ist
Engine-Planung für ein Produkt, das es nicht gibt. KFB ist ein Kartenspiel; Travel ist Meta-Narrativ
dazu, kein Fahrzeug-Framework.

**e) „`travel-poc.js` auf Bootstrap reduzieren": ja, aber in der gemessenen Reihenfolge.** Panel
(363 Z) → Kamera (~180 Z im Frame) → Modus/Wiring (36 Z). Wer mit dem TravelManager anfängt,
bewegt 3 % der Datei und hat danach dasselbe Problem.

---

## 5 · Der blinde Fleck aller fünf Reviews

Alle fünf bewerten **Struktur**. Keiner benennt eine der Fehlerklassen, die in v8 wirklich Zeit
gekostet haben. Zur Erinnerung, was diese Woche schiefging:

1. **Zwei Tusche-Familien** in einem SSOT-Modul — drei Runden an Parametern gedreht, während die
   falsche Funktionsfamilie lief (`drawInkOutline` statt `inkTail`).
2. **Am falschen Ort gemessen** — „3–5 Karten pro Oktant" stimmte, gerechnet vom Ankermittelpunkt;
   von der Flugposition waren vier Oktanten leer.
3. **Schalter statt Faktor** — POV-Übergang, siehe §3a.
4. **Kapazität nur für den Zielzustand** — Glyphen verschluckten Buchstaben, weil beim Wortwechsel
   altes *und* neues Wort leben.
5. **Auftrag ohne Rückweg** — der Anflug jagte eine Karte, die mit der Leine mitwanderte, endlos.
6. **Eine Konstante zweimal im Code** — Fensterformat der Live-Demo, 45 % Streckung.

**Kein TravelManager, kein Event-Bus und kein Controller-Interface hätte einen einzigen davon
verhindert.** Das ist keine Kritik an den Reviews, sondern die Grenze ihrer Gattung: sie prüfen den
Bauplan, nicht die Fehlerklassen. Deshalb ziehen wir aus v8 eine eigene Liste, und die steht ab
jetzt neben den Architekturregeln:

> **Fehlerklassen v8 — Regeln für v9**
> 1. **Übergänge sind Faktoren, keine Schalter.** Wer eine Schwelle schreibt, hat einen Sprung gebaut.
> 2. **Jeder Auftrag braucht einen Rückweg** (Watchdog mit Frist und Meldung).
> 3. **Gemessen wird dort, wo der Spieler steht** — und die Zahl, die zählt, ist das *Minimum*,
>    nicht der Mittelwert.
> 4. **SSOT-Module haben Familien.** Erst die Familie wählen, dann die Parameter.
> 5. **Kapazität für die Überlappung**, nicht für den Zielzustand.
> 6. **Eine Zahl, ein Ort.** Zweimal geschrieben heißt einmal falsch.
> 7. **Fremde Materialien werden geliehen, nicht umgeschrieben.** Ein „Zurücksetzen" auf
>    Standardwerte ist kein Zurücksetzen — den Originalzustand merken. (Neu 2026-07-25: mein
>    Pet-Deckkraft-Verlauf hat so den Mund zerstört.)
> 8. **Reglerwerte sind kein Verhalten.** Wer einen Bremsweg aus `decel · gain` rechnet, bekommt
>    45 u/s² und einen Anflug, der zu spät bremst — gemessen sind es 12. Verhalten wird gemessen,
>    nicht aus Parametern abgeleitet. (Neu 2026-07-25, S42a.)
> 9. **„Eine Zahl, ein Ort" gilt in BEIDE Richtungen.** Ein Regler, dessen Parameter niemand mehr
>    liest, ist so schädlich wie eine Zahl an zwei Orten: er druckt NaN oder tut still nichts, und
>    der nächste Leser dreht daran. Wer eine Platzierung umbaut, räumt die Regler mit ab.
>    (Neu 2026-07-25, S44b: fünf tote Academy-Regler nach dem Zonen-Stern.)
> 10. **Eine Bezeichner-Ersetzung ohne String-Maske ist eine Wette.** Beim Extrahieren wurde aus
>     `requestMode('walk', …)` ein `'ctx.walk'` — in drei Dateien. Gefunden hat es der
>     Modus-Eigentümer, weil er Ablehnungen BENENNT. (Neu 2026-07-25, S44c.)
> 11. **Zustand wird gehalten, nicht aus dem Cache-Schlüssel zurückgerechnet.** `setParams` löschte
>     den Schlüssel und las dann den Text daraus — die Subline war weg und mit ihr das reservierte
>     Band. Und: **reserviert wird das Maximum**, nicht der aktuelle Reglerwert, sonst ändert eine
>     Einstellung die Rahmung. (Neu 2026-07-25, S46.)
> 12. **Eine Abnahmezahl, die mit dem falschen Maß misst, ist schlimmer als keine** — sie bestätigt
>     den Fehler. Die Titelbreite wurde in der Subline-Schrift gemessen (353 statt 917 px), also
>     meldete die Prüfung immer „passt", während der Titel die Canvas-Kanten berührte. Beim Messen
>     gehört der Messzustand mit geprüft: welche Schrift, welche Zeitbasis, welcher Ort.
>     (Neu 2026-07-25, S46.)
> 13. **Über den echten Bedienweg testen** (Rad-Ereignisse, Doppelklick) — nie über die API.

---

## 6 · Plan v9 — Reihenfolge nach Schmerz, jede Stufe mit Abnahmekriterium

Kein Big Bang. Jede Stufe ist ein Slice, der einzeln lauffähig endet, und jede hat eine **Zahl**,
die sie erfüllen muss.

**V9-A · CameraRig** *(zuerst, weil hier ein offener Fehler liegt)*
Alles, was Follow, Lag, POV-Mischung, FOV, Dolly, Gelände-Ausweichen und Dock-Anflug betrifft, zieht
in `camera-rig.js`. Das Rig liest ausschließlich Runtime-State (Tempo, Kurs, Höhe, Boost, `landed`,
Dock-Faktor) und **niemand sonst schreibt `camera.*`**.
*Abnahme:* genau **1** Modul schreibt `camera.position|quaternion|rotation|lookAt|fov` (heute 4 —
`academy-lessons` zählt nicht, das ist eine eigene RTT-Kamera) · Zoom-Sprung ≤ 1,5 × Median in
**beiden** Richtungen über den echten Bedienweg · Übergang Pet-nah ⇄ POV ohne sichtbaren Ruck ·
0 Allokationen im Frame.

**V9-B · Modus-Eigentum + Controller-Vertrag**
`switchMode` wird zu einem **Antrag** (`requestMode('walk', reason)`), den ein Eigentümer annimmt
oder ablehnt; Anflug und Detailansicht lehnen ab, ohne dass die Bedingung an der Aufrufstelle steht.
Dazu `assertController()` im Debug-Modus gegen `enter/exit/update/state`.
*Abnahme:* `switchMode` existiert nur noch an einer Stelle · Regressionstest „Anflug auf tief
hängende Karte über steigendem Terrain" endet im Flug-Modus · Konformitätsprüfung grün für
`flight-controller` und `walk-controller`.

**V9-C · Panel heraus, dann TravelManager**
Die 363 Zeilen Regler werden **Daten** (`settings-schema.js`: Abschnitt, Label, Bereich, Getter,
Setter) — das Overlay rendert sie, der Runner kennt sie nicht mehr einzeln. Danach nimmt ein
`travel-manager.js` Lebenszyklus, **Pipeline als Liste** und Modus-Wechsel.
*Abnahme:* Runner **< 400 Zeilen** · Pipeline steht als eine Liste an einer Stelle und ist im Log
prüfbar · `KFB Travel v9` startet mit identischem Verhalten (dieselben Zahlen: fps, Kartenzahl,
Zoom-Sprünge).

**V9-D · Ereignisse an einem Ort**
Alle acht Callbacks werden in einer Tabelle registriert (Ereignis · Eigentümer · Zuhörer). **Kein
Bus**, solange kein Ereignis drei Zuhörer hat.
*Abnahme:* keine `x.onFoo = …`-Zuweisung mehr in der Frame-Schleife oder im Boot-Fluss verstreut.

**Nicht in v9:** Vehicle-Hierarchie · CardRig-Layer-Split · Telemetrie · Replay · AI-Navigation.

---

## 7 · Was v8 noch abbekommt (vor dem Fork)

1. **Zoom-Ruckeln Pet-nah ⇄ POV** — offen, Georgs Befund. Es ist gleichzeitig der Beleg für V9-A;
   wenn ein weiterer Anlauf in v8 nicht trägt, wandert es als erste Aufgabe in V9-A.
2. **Pet-Facing im Walk-Modus** — bewusst offen (kämpft dort mit dem Gehzyklus).
3. **Beat-Aura + Talk-Mouth** — dieselbe Schicht wie Facing, 13 Viseme liegen im Pet-Stack bereit.

---

## 8 · Für den Coworker / externe LLMs

Die Reviews bleiben als Quelle in `_handoff/` liegen; **dieses Dokument ist die verbindliche
Auslegung** für KFB Travel. Wer einen der Punkte umsetzt, liest §4 (was gestrichen ist) und §5
(die Fehlerklassen) mit — sonst wird ein „P1-Refactoring" umgesetzt, das messbar nichts bewegt.
Ergänzend gilt `skills/SSOT_Card_Ink_Outline.md` §Familien.

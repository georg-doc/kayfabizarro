# Sprint · KFB Travel v9 — **eingecheckt 2026-07-25**

> Architektur-Plan A–D vollständig. Offen sind Betriebs-Befunde (unten) und Konzept-Slices für
> v10 — Entscheidungsfragen in `docs/HANDOVER_v10_coworker.md` §3.


Entry: **`KFB Travel v9.dc.html`** → `terrain-v9/` (Fork von v8, 2026-07-25).
Auftrag: `docs/INTERMISSION_reviews_v8.md` · Handover: `docs/HANDOVER_v9.md`.
**v8 bleibt lauffähig und ist der Vergleichsmaßstab.**

## Slices

- **S40 · Fork** ✅ — `terrain-v9/` angelegt, Versionsstring nur im Runner, eigener
  Hinweis-Speicherschlüssel (`kfb-travel-v9-hint`; der v8-Eintrag des Nutzers bleibt unberührt).
  Verhalten unverändert zu v8.

- ~~**S41 · V9-A CameraRig**~~ ✅ erledigt (1 Kamera-Schreiber, Blickziel gefedert, Pet-Verlauf) — Follow, Lag, POV-**Mischung**, FOV, Dolly, Gelände-Ausweichen und der
  Dock-Anflug ziehen in `camera-rig.js`. Eingang: ausschließlich Runtime-State (Tempo, Kurs, Höhe,
  Boost, `landed`, Dock-Faktor, Zoom-Wunsch). `card-dock` liefert künftig einen **Faktor + Ziel**
  statt selbst zu schreiben.
  *Abnahme:* genau 1 Kamera-Schreiber (heute 4) · Zoom-Sprung ≤ 1,5 × Median in beiden Richtungen
  über Rad-Ereignisse · Pet-nah ⇄ POV ohne Ruck · 0 Allokationen.
  *Zuerst darin:* das offene Ruckeln — Pet-Sichtbarkeit als **Faktor** (Opazität/Skalierung) statt
  Schalter bei 0,62.

- ~~**S42 · V9-B Modus-Eigentum + Controller-Vertrag**~~ ✅ erledigt — `requestMode(mode, reason)`; Anflug und
  Detailansicht lehnen ab, ohne dass die Bedingung an der Aufrufstelle steht. `assertController()`
  prüft `enter/exit/update/state` im Debug-Modus.
  *Abnahme erfüllt:* `switchMode` **gibt es nicht mehr** (0 Treffer), `modeLockT` ebenso ·
  vier benannte Regeln, jede einzeln gemessen · Vertragsprüfung **grün für beide Controller** (4/4) ·
  Regressionsfall auf Regel- und Verhaltensebene belegt. Runner 1337 → 1366 Z (Kürzen ist S43/S44).

- **S43 · V9-C Panel als Daten** — die ~363 Regler-Zeilen werden `settings-schema.js`
  (Abschnitt · Label · Bereich · Getter · Setter); das Overlay rendert, der Runner kennt keine
  einzelnen Regler mehr.
  *Abnahme:* Runner ≤ 950 Zeilen · Panel im Verhalten identisch (alle Regler wirken).

- ~~**S44 · V9-C TravelManager**~~ ✅ Pipeline + Lebenszyklus erledigt (Runner-Zeilenzahl offen, siehe S44b) — Lebenszyklus, **Pipeline als Liste** (Input → WorldContext →
  Controller → Vehicle → PetKinetics → Facing → CardRig → FX → Camera → Render), Modus-Wechsel.
  *Abnahme teilweise:* Pipeline an einer Stelle, ausdruckbar (`mgr.order`) und **getaktet**
  (`mgr.timing`: render 2,16 ms · world 0,27 · vehicle 0,18) · Fehler-Isolation pro Schritt ·
  2341 Frames ohne Fehler, 88 fps, 31 Karten. **Runner 1418 Z — das < 400 fehlt.**

- ~~**S44b · Panel als Schema**~~ ✅ erledigt (Runner 1418 → 1178 Z) — die ~500 Zeilen
  Regler werden `settings-schema.js`. Der Knackpunkt sind ~60 Getter/Setter auf veränderliche
  Runner-Locals (`danceMode`, `blinkGain`, `groundCalm`, `shadowGain`, `bpm`, `flyTime`,
  `academyOn`, `glyphsOn` …): die müssen zuerst in **ein** Zustandsobjekt, sonst kann das Schema
  sie nicht lesen. Danach ist der Runner realistisch bei ~600 Z, und die restlichen 200 kommen aus
  Eingabe-Handling und Boot.
  *Abnahme:* Panel im Verhalten identisch — 91 Bedienelemente, `refresh()` in beiden Modi ohne
  Fehler, 12 Regler und 8 Schalter über den echten Weg bedient. **Runner 1178 Z — „< 400" offen.**

- ~~**S44c · Eingabe-Schicht als Modul**~~ ✅ erledigt — `travel-input.js` (155 Z), Runner 1181 → **1071 Z**.
  *Abnahme:* alle Bedienwege über echte Ereignisse geprüft (F hin/zurück, Rad 9 → 7,11, Tab, Doppelklick, Ziehen). Ziel „< 1000 Z" um 71 Z verfehlt — der Rest sitzt in Boot/Assets (S44d).
- ~~**S44d · Bühne & Welt als Modul**~~ ✅ erledigt — `travel-stage.js` (100 Z), Runner 1071 → **1014 Z**.
  *Abnahme:* identischer Start (31 Karten, Szene 11 Kinder, Verträge grün, 0 kaputte Schritte).
  **„< 700 Z" verfehlt** — und das ist eine Entscheidung, keine Panne: die Verdrahtung ist unter
  150 Z, der Rest ist Systemaufbau und Pipeline-Schritte. Ein weiterer Schnitt würde 40–50
  Abhängigkeiten durch Kontext-Objekte fädeln und die Kopplung ERHÖHEN. Wer die Zahl will, gruppiert
  die Systeme neu (`academy-suite.js`) — Konzept-Slice, kein Aufräum-Slice.

- ~~**S45 · V9-D Ereignisse an einem Ort**~~ ✅ erledigt — `travel-events.js` (70 Z) — Tabelle Ereignis · Eigentümer · Zuhörer für die acht
  Callbacks. Kein Bus, bis ≥3 Zuhörer.
  *Abnahme erfüllt:* **0** verstreute `x.onFoo = …`-Zuweisungen (vorher 8), 8 Anmeldungen in einer
  Tabelle mit Klartext und Zähler, **0 Duplikate** (die Bus-Absage ist damit gemessen richtig),
  Fehler-Isolation pro Rückmeldung. Über den echten Anflug belegt: `onFocus` ×3, `onArrive` ×1,
  `onDock` ×1, `onWarn` ×1.

**Damit ist der v9-Plan aus der Intermission komplett** (A–D). Was bleibt, sind Betriebs-Befunde und
Konzept-Slices, keine Architektur-Schulden.

## ~~S42a · Anflug-Choreografie~~ ✅ erledigt (Details im Changelog)

Georgs Beschreibung ist eine **Regie-Anweisung, keine Kamera-Einstellung**: „der Kamera muss sich
eine saubere, dynamische, korrekt getimte Transitionsphase berechnen, die der Flug-Dynamik des Pets
1:1 folgt und den Schwung zum Einzoomen nutzt."

Gemessen fehlt dafür der **Beat**: der Anflug hat gar keine Bremsphase mehr, in der das Pet vor der
Karte zum Stehen kommt — `arrive: 7` löst die Ankunft aus, während das Pet noch > 14 u/s fliegt
(im Live-Lauf: **kein einziger Frame** mit `speed ≤ 14` vor der Übergabe). Der Zoom bleibt deshalb
zu Recht auf Follow-Abstand (8,5 u bei der Übergabe), und das Dock macht die ganze Bewegung.

Der Slice baut die Ankunft um, nicht die Kamera:
1. **Ankommen heißt anhalten.** Neuer Auto-Pilot-Zustand `settle` zwischen `fly` und `loiter`:
   Schub gegen die Fahrtrichtung, bis `speed < ~3`, Position ~1,5 Kartenbreiten vor dem Blatt.
2. **Erst dann Zoom.** Die vorhandene Regie (Zoom folgt `min(brems, nah)`) greift dann von selbst —
   sie ist gebaut und wartet nur auf eine echte Bremskurve.
3. **Danach das Dock**, mit deutlich kürzerem Weg (heute 131 Frames für die ganze Strecke).
4. Speedlines/Kinetik laufen durch die Bremsphase weiter — das ist der „Schwung".

*Abnahme erfüllt:* 30 Frames ≤ 6 u/s (Ziel ≥ 20) · Zoom bei Übergabe **2,73 u** (Ziel ≤ 3,0) ·
Blickdrehung Landung p95 **24,3 °/s** (Ziel ≤ 30) · Stand max **3,0 °/s** (Ziel ≤ 5) ·
Bremsphase 205 Frames von 26,7 auf 2,1 u/s ab 36 u · Boost-Umschaltungen 9 statt Geflacker.
Die Landung dauert 189 Frames statt der geplanten ≤ 60 — **bewusst so gelassen:** sie ist jetzt ein
ruhiger, gebremster Schwenk (p95 7,5 u/s statt 28,5), und eine Verkürzung würde genau die Spitzen
zurückbringen, die der Slice beseitigt hat.

## ~~S43 · Zonen-Stern, Warp, Verläufe~~ ✅ erledigt (Details im Changelog)

Fünf Zonen im 72°-Stern um den Startpunkt (Hub = Aula), Lektionen als Bogen nach außen, Leine aus ·
Warp als Faktor (+40 % über der Grenze gemessen, ⇧+Leertaste, Pilot warpt selbst) · Pet und
Flug-Karte in EINEM Verlauf mit eigener Zeitkonstante (71 statt 9 Frames, größter Sprung 0,068).

**Daraus folgt für den nächsten Slice:** die Zonen sind jetzt Orte — damit wird eine
**Zonen-Übergangs-Logik** sinnvoll (Warp-Korridor zwischen zwei Zonen, Ankunft als Ereignis,
Kapitel-Fortschritt). Das ist Kandidat, nicht beschlossen.

## ~~S45 · Rückwärtsgang, Standdrehung, Touchpad-Zoom~~ ✅ erledigt (Details im Changelog)

S halten = rückwärts (−10,4 u/s, 5,8 u zurück) · Q/E = Standdrehung im Flug (154° in 1,5 s bei 1,6 u
Strecke) · Zoom multiplikativ (0,126 u bei kleinem Wisch statt fester 0,9) · Pet-Fade-Fenster nach
hinten (0,68–0,94) · Zoom-Rückweg im Takt des Dock-Lösens (1,6/s).

**Kandidat daraus:** „zurück, drehen, weiter" als EIN Griff — braucht ein Ziel für die Automatik
(nächste Lektion im Kapitel).

## Offene Befunde aus dem Betrieb (Georg, 2026-07-25)

Nach Schwere sortiert; die ersten zwei hängen zusammen und ersetzen die Würfel-Glyphen.

1. ~~**Karten-/Lektionstitel als lesbare Headline-Schrift**~~ ✅ **S46** — `card-title.js`:
   Irish Grover extrudiert (7 Ebenen), Papier→Zone getönt, Tuschesteg zur Karte, einzeilig bis
   54 Zeichen, Band einmal reserviert (Rahmung bleibt konstant: 240 Frames → ein `padTop`-Wert).
   Sublines (Special Elite, 2 Zeilen) an; Ticker vorbereitet.
   ~~Alt:~~, farbkodiert nach Zone, aus der Ferne als
   Farbe erkennbar und **erst in der Detailansicht vollständig lesbar**. Ersetzt die Voxel-Glyphen
   (in S41 abgeschaltet: überlagern, glitchen, auf Entfernung unsichtbar).
2. **Detailansicht sprang** — Ursache Blickziel-Überschreibung, in S41 behoben; nach dem
   Glyphen-Ersatz erneut prüfen.
3. ~~**Karten falsch im Raum verteilt**~~ ✅ S43 (Zonen-Stern).
4. **Responsiver Viewport zu gering** — die Karte nutzt bei schmalen Fenstern zu wenig Fläche.
4. **Sky-Karten haben die falsche Tusche-Familie** (`Bend` statt Band) — muss auf `ink-tail.js`
   umgestellt werden wie die Akademie-Karten (siehe `skills/SSOT_Card_Ink_Outline.md`).
5. **Viele three.js-Beispiele nicht anklickbar** — Trefferprüfung greift offenbar nur bei Karten mit
   Live-Demo; die Vorschaubild-Karten müssen denselben Weg haben.
6. **Pet-Mund war zerstört** — behoben (Eigentums-Verstoß in meinem Deckkraft-Verlauf), siehe
   Changelog; als Regel in die Fehlerklassen aufgenommen.
7. **Post-it wirkt unnatürlich** — braucht Animation (Aufkleben, Windzupfen) oder eine andere Form.

## Danach (Kandidaten, nicht beschlossen)

- Pet-Facing im Walk-Modus · Beat-Aura · Talk-Mouth (13 Viseme)
- S34 Voice/Chat auf der Würfelfläche (Suche S33 ist die Vorstufe)
- Post-it-Notizen wirklich eingeben und als Journey exportieren
- weitere Live-Lektionen (heute 3 von 31)

## Regeln, die in v9 gelten

Aus `docs/INTERMISSION_reviews_v8.md` §5 — **Fehlerklassen v8**:
Übergänge sind Faktoren, keine Schalter · jeder Auftrag braucht einen Rückweg · gemessen wird dort,
wo der Spieler steht (Minimum, nicht Mittelwert) · SSOT-Module haben Familien · Kapazität für die
Überlappung · eine Zahl, ein Ort · über den echten Bedienweg testen.

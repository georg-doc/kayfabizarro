---
name: session-export
description: >
  Schlanker Session-Export plus Housekeeping fuer Design-Chats (DC / Canvas). Trigger auf
  /session-export, "exportier mir die Session", "mach mir den Export", "session export",
  "checkin export", "housekeeping export". Immer triggern, BEVOR ein Chat ein Projekt-Zip
  oder einen Download baut. Ersetzt den Voll-Projekt-Export durch ein Manifest, ein Veto-Fenster,
  ein living HOUSEKEEPING.md und einen Export nur der in dieser Session gebauten Dateien.
  Georg will nie wieder ein 330-MB-Zip.
---

# Session-Export plus Housekeeping

> Kopie aus `georg-doc/kayfabizarro@main:skills/session-export_v1.md`, geholt 2026-07-25.

Bevor du irgendetwas exportierst: **kein Gesamt-Projekt-Zip.** Nur das, was in genau dieser Session
am Canvas gebaut, geaendert und eingecheckt wurde. Der Rest des Projekts bleibt, wo er ist.

Schritte der Reihe nach. **Nach Schritt 1 anhalten und auf Okay warten**, bevor gezippt wird. Nie
loeschen ohne ausdrueckliche Freigabe, jeden Schritt einzeln.

1. **Manifest zuerst** — getrennt nach (a) Deliverables (`.dc.html` + Module), (b) Contract-/Daten-
   Dateien (JSON, Registries), (c) Docs (Ist-Stand, Handover, Changelog), (d) Abnahme-Captures.
   Alles andere bleibt draussen. **Veto-Fenster ist Pflicht, nicht Hoeflichkeit.**
2. **Housekeeping nachziehen** — living `HOUSEKEEPING.md` mit Status je Artefakt:
   `AKTIV` · `FROZEN` · `SUPERSEDED` · `DEAD` · `ASSET`. Neue Version `AKTIV`, Vorgaenger
   `SUPERSEDED`. Geteilte Module als geteilt flaggen, damit sie niemand als tot einstuft.
3. **Cleanup nur benennen, nicht ausfuehren** — superseded Versionen, verarbeitete Feedback-Bilder,
   schwere lokale Binaries, die per URL gehoeren.
4. **Export nur der Manifest-Dateien** — ein Download, nicht das Projekt.
   **Groessen-Budget hart: keine Datei ueber 2 MB.** Schweres laedt zur Laufzeit per RAW-URL.
5. **Contract-Hygiene** — `version` Patch hoch, `updated` = heute, `canonical` nie verlieren,
   lokale Kopien synchron.
6. **Pfad-Hygiene (der stille Killer)** — jeder Asset laeuft ueber die kanonische RAW-URL, nie ueber
   `./assets/...`; ein relativer Pfad funktioniert in der Vorschau, im Standalone-Export nicht.

*Prinzip: ein schlanker Export, ein ehrliches Manifest, kein Loeschen ohne Freigabe.*

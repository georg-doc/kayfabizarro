# SSOT — Card Ink-Outline (Karten-Tusche)

Die eine kanonische Definition der getuschten Karten-Kante. Vorher verstreut (Code + Commission), hier
zusammengezogen. **Gemessen am echten Code, nicht behauptet.**

> **Änderung 2026-07-25 (KFB Travel v8, Academy-Karten):** Abschnitt §Auflösungs-Invariante und
> §Tusche über Render-Texturen sind NEU. Beide entstanden aus einem Fehlschlag, der zweimal
> hintereinander wie ein Stil-Problem aussah und in Wahrheit eine Maßeinheit war. Wer diesen Look in
> einem neuen Projekt aufsetzt, liest zuerst diese zwei Abschnitte — sie sparen zwei Runden.

## ⚠ KORREKTUR 2026-07-25 — zwei Familien, und für KARTEN gilt die andere

**Dieses Dokument hat bisher `drawInkOutline` (Stil `inked`) als „aktuell für neue Arbeit"
empfohlen. Für Karten ist das falsch.** Der v11-Code hat ZWEI Tusche-Wege, und die Kartenkante ist
nicht der, den dieses Dokument beschrieben hat:

| | `inkChip` / `drawInkOutline` (`inked`) | `inkTail` (+ `brushLoop`, `inkRibbon2D`) |
|---|---|---|
| Wobble | **per-Punkt-Zufallsversatz** (`jit`) | **zwei langwellige Sinus über den Umfang** (3–5 und 6–9 Perioden), an den Ecken ausgefadet |
| Strich | **gestrichene Polylinie**, Breite pro Segment | **gefülltes Band** zwischen Offsetkurven, EIN `fill()` |
| Breite | `baseW` + `wob` | `hb = 0.0069 · min(W,H)`, Taper 0.85, diagonaler Gradient `edge` 1.05 |
| Richtig für | Buttons, HUD-Chips, **Post-its**, DOM-Chips | **KARTEN / Comic-Panels** |
| Fundort | `kfb-ink.js` (Repo-Root) | `rollercoaster-ride.v11.js` „journey v4 master tusche" |

**Woran man den Fehler erkennt:** die Kante wirkt zackig/„torn" und nach mehr Parameter-Drehen
immer noch zackig. Kein `jit`- und kein `baseW`-Wert repariert das — **eine gestrichene Polylinie
mit Punktrauschen kann nie wie ein Pinselband aussehen.** Wer eine Kartenkante baut, portiert
`brushLoop` + `inkRibbon2D` + `inkTail` (in KFB Travel v8 als `terrain-v8/ink-tail.js`, 1:1).
Gemessene Diagnose aus dem Fall: das **Post-it** (`inkChip`) sah von Anfang an richtig aus, die
Karte (`drawInkOutline`) nie — dasselbe Modul, zwei Familien.

**Die §Auflösungs-Invariante unten gilt weiter für `inked`/Chips.** Für `inkTail` erledigt sich
das Problem von selbst: die Bandbreite ist relativ zur Zellgröße, und der Wobble hängt am
Umfangs-Parameter statt an der Punktzahl — Abtastung alle 22 px ändert die FORM nicht.

## Quelle der Wahrheit — zwei Implementierungen, EIN Kanon
Es gibt zwei Umsetzungen desselben Looks. Sie stimmen im **Kanon** überein, haben aber **eigene Zahlen**:

- **AKTUELL / für neue Arbeit → `kfb-ink.js` (Repo-Root) bzw. Ride v11 `rc-ink`
  (`KFB_INK_OUTLINE_STYLE_v1`).** Laden: `import './kfb-ink.js'` → `window.KFBInk`
  (`inkPerimeter`, `drawInkOutline`, `inkChip`, `paintChipEl`). Stil `inked` mit
  **`uniform: true`**, Farbe `#1f1a14`/`#191410`. Auf einem 2D-Canvas gezeichnet (CanvasTexture)
  → renderer-unabhängig → direkt in WebGL-Welten wiederverwendbar.
- **Vorfahr / historisch → `kfb-table.v6.js` `inkPathD()`.** Hatte die **lichtabhängige
  Strichdicke** (der Fehler, den die Commission ausdrücklich NICHT übernehmen wollte).
  → **Für Neues v11/`kfb-ink.js` nehmen, nicht v6.**

## Die EINE Regel (Kanon)
**Die Tusche liegt auf der BILDEBENE, nicht in der Welt.** Eine gezeichnete Linie auf Papier hat überall
dieselbe Feder — unabhängig von Tiefe, Winkel und Licht.

## Prüfbare Werte (1:1 aus `inkPathD`, historisch)
- **Jitter ±1.2 px** auf x **und** y — `(rnd()-0.5)*2.4`.
- **Ein Stützpunkt alle ~46 px** — `n = max(2, round(len/46))`.
- **`inset = 2`**, reine `L`-Segmente, `mulberry32(seed)` pro Karte, ein durchgehender Pfad,
  Ink `#1f1a14`.

## Rezepte (`kfb-ink.js`, §6 des Style-Docs)
```js
// BUTTON     inkChip(g, m,m,w-m,h-m, 41, { fill:'#b8361f', uniform:true, baseW:6, wob:.5, jit:1.6 });
// HUD-CHIP   inkChip(g, m,m,w-m,h-m, 11, { fill:'#f7f0da', uniform:true, baseW:4, wob:.5, jit:1.4 });
// CARD       const pts = inkPerimeter(m,m,w-m,h-m, seed, 4);
//            clip(pathOf(pts)) → Papier + Inhalt füllen
//            drawInkOutline(g, pts, m, h-2*m, { uniform:true, baseW:11, wob:.5, wseed:seed });
```

---

## NEU · Auflösungs-Invariante — **Stützpunkte pro Kante, nicht Pixel**

**Das Problem, zweimal falsch gelöst, bevor es verstanden war:** `inkPerimeter` teilt jede Kante in
Segmente **fester Länge** (`n = max(3, round(len/34))`). Die Wobble-**Frequenz** hängt damit an der
Canvasgröße — dieselben Parameter ergeben auf einem großen Canvas eine völlig andere Linie.

**Gemessen an einem echten Fall** (KFB Travel v8, Academy-Karten, Kartenformat 1.79):

| Element | Canvas | jit | Stützpunkte / lange Kante | Ergebnis |
|---|---|---|---|---|
| Post-it | 256 px | 1.6 | **7** | ✅ liest als ruhige Tuschelinie |
| Karte (1. Versuch) | 1024 px | 8 (relativ skaliert) | **30** | ❌ „torn", Zickzack |
| Karte (2. Versuch) | 1024 px | 4 (Kanon-Wert absolut) | **30** | ❌ immer noch zackig |
| Karte (Lösung) | Kontur bei **320 px** gebaut, dann skaliert | 2.0 | **9** | ✅ identischer Charakter zum Post-it |

**Die Regel:**
1. **Kontur EINMAL in einem Referenzrahmen bauen**, dessen Breite ~8–9 Stützpunkte auf der langen Kante
   ergibt (bei Segmentlänge 34 px ⇒ Referenzbreite **≈ 300–340 px**, unabhängig davon, wie groß die
   Textur später ist).
2. **Punkte normalisieren** (0..1) und für jede Zielauflösung nur noch **skalieren**.
   Niemals die Parameter skalieren.
3. **Strichbreite und Jitter relativ zur Breite halten:** `baseW ≈ 1.6 %`, `jit ≈ 0.63 %`, `wob 0.5`.
   (Das ist exakt das Post-it-Verhältnis, das im Test als richtig abgenommen wurde.)

```js
const REF = 320, AR = 1.79, BASE = 5.2, JIT = 2.0;   // BASE/REF = 1.63 %, JIT/REF = 0.63 %
function normContour(seed) {
  const W = REF, H = Math.round(W / AR), m = BASE * 0.5 + JIT + 2;
  return KFBInk.inkPerimeter(m, m, W - m, H - m, seed, JIT).map(p => [p[0] / W, p[1] / H]);
}
const contourAt = (seed, W, H) => normContour(seed).map(p => [p[0] * W, p[1] * H]);
const strokeAt  = (W) => BASE * (W / REF);
```

**Symptom-Tabelle für die Fehlersuche:**
- Linie *zackig / ausgerissen*, obwohl `inked` gesetzt ist → **Frequenz**, nicht Amplitude. Punkte pro
  Kante zählen: mehr als ~12 ist zu viel.
- Linie *zu zart für ein großes Objekt* → `baseW` relativ zur Breite prüfen (Ziel 1.6 %), nicht
  absolut nachziehen.
- Kante *verändert sich, wenn man die Texturauflösung ändert* → die Kontur wird pro Auflösung neu
  gerechnet statt skaliert.

## NEU · Tusche über Render-Texturen (Live-Demo / Video / Foto auf der Karte)

Sobald die Kartenfläche **kein Canvas** mehr ist (Render-Target, Video, geladenes Bild), kann die
Tusche nicht mehr hineingemalt werden. Dann gilt:

1. **Silhouette als `alphaMap`** auf die Fläche + **`alphaTest` ~0.5** (harte Kante, kein Glow,
   kein `transparent`-Sortierproblem). Maske: schwarz außen, weiß innen, **aus derselben Kontur**.
2. **Tusche als eigenes Quad davor** (`transparent: true`, `depthWrite: false`, ~2 cm Abstand), das
   NUR die Linie trägt. Das ist die Kanon-Regel wörtlich: *die Tusche liegt auf der Bildebene.*
3. **Maske und Linie MÜSSEN dieselbe normalisierte Kontur benutzen** — sonst sieht man zwei Kanten.
   (Gemessener Fehler: Maske bei 512 px, Decal bei 1024 px, beide mit größenabhängigem `jit`
   ⇒ zwei verschiedene Konturen ⇒ Lücken zwischen Fläche und Strich.)
4. **Maske nur minimal aufweiten.** Man ist versucht, die weiße Fläche um die halbe Strichbreite zu
   strecken, damit keine Naht bleibt. Aber `wob` moduliert die Breite zwischen 0.5× und 1.5× `baseW`:
   an den dünnen Stellen blitzt die Fläche dann über die Linie hinaus.
   **Obergrenze ist die halbe MINIMAL-Breite: `0.25 · baseW`** (praktisch: `0.2 · baseW`).
5. Auflösungen dürfen sich unterscheiden (Maske 512, Decal 1024–2048): die Linie braucht mehr Pixel als
   die Silhouette. Das ist genau der Grund, warum die Kontur normalisiert sein muss.

## Prüfbar richtig
- **Alle** Panel-/Karten-Kanten haben **dieselbe wahrgenommene Strichstärke**, nah wie fern.
- Reload → identische Kante (Seed-Stabilität, nie `Math.random()`).
- Gegenüberliegende `inked`-Kanten optisch gleich dick.
- Fläche und Strich haben **eine** gemeinsame Silhouette (keine Doppelkante, keine Lücke).
- Bei geändertem Textur-Maßstab bleibt der Kanten-Charakter gleich.

## Beobachtete Fehler, die das ausschließt
- **Doppelte Outlines.**
- **Zackiger Strich** — Jitter zu groß **oder Frequenz zu hoch** (siehe §Auflösungs-Invariante; das ist
  der häufigste Fall und wird zuverlässig als „falscher Stil" fehldiagnostiziert).
- **Lichtabhängige Dicke** (v6-Erbe).
- **`inked` mit `topW`/`botW` gemischt** (Licht-Logik gehört nur zu `torn`).
- **Kontur pro Auflösung neu gerechnet** statt skaliert.
- **Maske zu weit aufgeweitet** → Fläche blitzt über die Tusche.

## Tipps für externe LLMs / neue Projekte
- **Zuerst messen, dann urteilen.** „Sieht falsch aus" ist keine Diagnose. Zähle die Stützpunkte pro
  Kante und rechne `baseW/W` sowie `jit/W` in Prozent aus — beide Zahlen entscheiden den Look.
- **Ein Element, das nachweislich richtig aussieht, ist der Maßstab.** Im Travel-v8-Fall war das
  Post-it richtig und die Karte falsch, mit demselben Modul: der Vergleich der beiden Verhältnisse hat
  den Fehler in einer Minute gefunden, nachdem zwei Runden Rateversuche gescheitert waren.
- **Kein Nachbau.** `kfb-ink.js` ist die SSOT; eine eigene Jitter-Schleife wird ein verrauschtes
  Rechteck und kein Tuschestrich (genau so passiert, v8/S31).
- **Bei echter Zielgröße zeichnen** (× `devicePixelRatio`), nie ein fertiges Bild skalieren.
- **Nach `document.fonts.ready` neu malen**, wenn Text im Blatt liegt.

## Kanonische Werte für die Kartenkante (`inkTail`, 1:1 aus v11)
- `brushLoop(x0,y0,x1,y1, seed, wob = 1.4, bow = 1.4)` — Punkte alle **22 px**, Ecken fix,
  Bauchung fadet über `margin = min(len·0.16, 64)` zu den Ecken aus.
- Amplituden: `a1 = (rnd·3+2)·bow` bei `f1 = 3…5` Perioden, `a2 = (rnd·1.6+0.8)·bow` bei
  `f2 = 6…9`; zusätzlich ±`0.7·wob` Punkt-Jitter (klein, nur Textur).
- Feder: `hb = 0.0069 · min(W,H)` (≈ 5 px bei 720 Höhe) · `taper 0.85` (moduliert von zwei Sinus,
  `k1 = 3…5`, `k2 = 8…13`) · `edge 1.05` (diagonaler Licht-Gradient, unten/rechts satter) ·
  Minimum 1.2 px · Farbe `#1f1a14`.
- **Band, nicht Strich:** alle Segment-Quads als Subpfade in EINEM Pfad, ein `fill()` mit nonzero —
  geteilte Kanten liegen innen, dadurch kein AA-Riss und keine Fuge.
- Über Render-Texturen (§ unten): Silhouetten-Maske höchstens um die **kleinste vorkommende
  Halbbreite** aufweiten (`hb·(1−taper/2)·(1−edge/2)`), sonst blitzt die Fläche durch.

## Wo es gilt
Karten-Panels im Card-Viewer, die Tuschekante des Flug-Card-Carriers (Pet-auf-Karte), die
**Academy-/Lektionskarten in KFB Travel v8** (Fläche = Live-Demo oder three.js-Vorschaubild, Kante =
Decal) und jede Karten-Optik. Die Karte ist ein Comic-Panel, kein Brett.

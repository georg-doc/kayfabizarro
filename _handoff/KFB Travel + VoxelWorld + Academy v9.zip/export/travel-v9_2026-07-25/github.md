repo: georg-doc/kayfabizarro
branch: main
path: media/, _handoff/

## Wozu

Dieses Projekt **rendert** aus dem Repo, es forkt es nicht: Travel lädt zur Laufzeit
Deck-PDFs, Karten-JSON, Musik und (bald) SFX per RAW-URL. Nichts davon liegt hier als Kopie —
mit Absicht, damit ein neues Deck im Repo sofort im Flug auftaucht. Lokal liegen nur
**Fallback-Manifeste**, die nicht veralten dürfen.

## Was gelesen wird

| Repo-Pfad | wofür | Modul |
|---|---|---|
| `media/kfb/index.json` | Deck-Registry (`kfb-deck-registry/v2`), `cardMapping` 2×2, `baseUrl` | `terrain-v7/card-registry.js` |
| `media/kfb/Deck_*.pdf` | Karten-Artwork, ein 2×2-Quadrant pro Karte | `card-registry.js` |
| `media/kfb/Deck_*.pdf.json` | Karten-Daten (`cardNumber`, `cardName`, `power`, `lore`) | `card-registry.js` |
| `media/3D_Assets/Sounds/jukebox.json` + Tracks | Musikbett, BPM für die Takt-Uhr | `terrain-v7/travel-audio.js` |
| `media/3D_Assets/Audio/sfx.json` | Einsatz-Ebene (Sample erst, Synthese dann) | `travel-audio.js` |
| `media/3D_Assets/build/pet-library.v6.js`, `pet-eye-rig.v5.js`, `pet-motion.v2.js` | Pet-Stack (per CDN-Import) | `terrain-v7/kfb-pets.js` |
| `media/kfb/*` (Karten-Rückseite, Wortmarke) | Kartenblatt der Flug-Karte | `terrain-v7/card-carrier.js` |

**Lokale Fallbacks** (RAW-first, dann diese, dann hartkodierter Default):
`terrain-v7/kfb-index.json` · `terrain-v7/jukebox.json` · `terrain-v7/sfx.json`

## Screen map

| Screen / Datei | gebaut aus |
|---|---|
| `KFB Travel v9.dc.html` (Entry, **aktuell**) | `terrain-v9/*` (31 Module, Fork von v8), Theme `themes/kfb-med.css` |
| `KFB Travel v8 - Academy Flow.dc.html` (**eingefroren**, Vergleichsmaßstab) | `terrain-v8/*` (31 Module) |
| Academy-Karten (31 Lektionen) | Curriculum aus `uploads/KFB Cube Academy v1/` (lokal) + `threejs.org/examples/screenshots/*.jpg` (Vorschau, extern) |
| Tusche-Kante der KARTEN | `rollercoaster-ride.v11.js` „journey v4 master tusche" → `terrain-v9/ink-tail.js` (Band) |
| Tusche der Chips/Post-its | `kfb-ink.js` (Repo-Root, SSOT) → `terrain-v9/kfb-ink.js` (`inkChip`) |
| `KFB Travel v7.dc.html` (Vorgänger) | `terrain-v7/*` (18 Module), Theme `themes/kfb-med.css` |
| Sky-Karten | `media/kfb/index.json`, `Deck_*.pdf`, `Deck_*.pdf.json` |
| Klang & Rhythmus | `media/3D_Assets/Sounds/jukebox.json`, `media/3D_Assets/Audio/sfx.json` |
| Pet (Uncle FrizzleBob & Co.) | `media/3D_Assets/build/pet-*.js` (CDN, gepinnte Versionen) |
| Flug-Karte / Kartenblatt | `media/kfb/` (Rückseite, Wortmarke) |

## Was im Repo fehlt, damit Slices grün werden

- `media/3D_Assets/Audio/sfx.json` — Manifest für die Einsatz-Ebene. Form und Prompts stehen in
  `docs/SFX_elevenlabs_prompts.md`. Solange es fehlt, spielt Travel die synthetischen Einsätze
  (kein Fehler, nur weniger Charakter).
- Die ElevenLabs-Dateien selbst nach `media/3D_Assets/Audio/`.

## Last sync

date: 2026-07-25T14:08:30Z
commit: — (nicht ermittelt; Tree-Hash ist kein Commit, also lieber keine Zahl als eine falsche)

### Updated in this project
- **v9 eingecheckt:** Architektur-Plan A–D fertig (CameraRig · Modus-Eigentum · TravelManager/Panel/
  Eingabe/Bühne · Ereignis-Tabelle), dazu Zonen-Stern, Warp, Rückwärtsgang, Standdrehung und der
  lesbare Kartentitel (`card-title.js`). Clean-up: 16 Module trugen noch „Travel v7" — Version
  gehört dem Runner. Doku: `docs/SESSION_EXPORT_v9_runtime.md`, `docs/HANDOVER_v10_coworker.md`.
- **TinySkies-Transfer aufgenommen:** `_handoff/tinyskies_kfb_transfer_notes_v1.md` (ChatGPT) und
  `_handoff/KFB_TinySkies_Transfer_v8.md` (Gemini), erste Bewertung in
  `docs/INTERMISSION_tinyskies.md` — offen sind vier Konzept-Entscheidungen.
- v8-Fork gebaut: Auto-Pilot (S22d), Academy mit 31 Lektionskarten und Live-Demo per RTT (S31),
  Kanon-Tusche + vollflächige Karte + Surface-Slot (S32a), Landung in die Detailansicht (S32c).
- `kfb-ink.js` aus dem Repo-Root nach `terrain-v8/` kopiert — die Kartenkante ist jetzt kanonisch.
- Vier Code-Reviews aus `_handoff/` ins Projekt geholt (Architecture Audit v1, Runtime Review v1–v3).
- Das Gemini-Audit liegt jetzt als `_handoff/KFB_Travel_v8_Audit_Report.md` vor (das PDF gleichen
  Namens war zu groß für den Import) — alle fünf Reviews sind damit lesbar.
- **v8 eingefroren, v9 geforkt:** `terrain-v9/` + `KFB Travel v9.dc.html`. Clean-up davor:
  Versionsstrings aus 10 Modulen entfernt (die Version gehört dem Runner) — dadurch war der Fork
  genau eine Datei. Handover `docs/HANDOVER_v9.md`, Sprint `docs/SPRINT_travel-v9.md`,
  Session-Export `docs/SESSION_EXPORT_v8_academy.md`.
- **Review-Intermission abgeschlossen:** `docs/INTERMISSION_reviews_v8.md` ist die verbindliche
  Auslegung der fünf Audits für KFB Travel (Konsens, gemessener Ist-Stand, was gestrichen ist,
  Plan v9-A…D mit Abnahmekriterien). Die Reviews selbst bleiben unverändert in `_handoff/`.

## Sync history

- 2026-07-25T04:45+02:00 — v7: Deck-Artwork aus `media/kfb/`, Jukebox-Manifest, SFX-Registry
  vorbereitet, Pet-Stack per gepinntem CDN-Import.

// ============================================================================
// card-registry.js — KFB Travel · Slice S23 · echte Karten aus Deck-PDF + JSON
// ----------------------------------------------------------------------------
// PORTIERT aus `rollercoaster-v11` (`loadRegistry`, `renderPdfPage`,
// `ensureCardArt`). Der Vertrag steht im Repo-Manifest und wird hier NICHT neu
// erfunden — er ist Kanon:
//
//   media/kfb/index.json  ·  schema kfb-deck-registry/v2
//   cardMapping: 2×2 Zellen pro Seite, Reihenfolge TL · TR · BL · BR
//   Seite     = coverOffset + 1 + floor((cardNumber − 1) / 4)
//   Quadrant  = (cardNumber − 1) % 4
//   URL       = baseUrl + '/' + encodeURIComponent(dateiname)
//   keyMap    = { n: cardNumber, t: cardName, p: power, l: lore, g: grade }
//
// DREI REGELN, die in v11 teuer gelernt wurden und hier von Anfang an gelten:
//  1. **Text zuerst, Bild später.** Die Karten-JSON kommt in Millisekunden, das
//     PDF-Rendern dauert. Also erst Titel/Lore als Blatt zeigen, dann das echte
//     Artwork nachschieben. Nie ein leeres Blatt, nie ein Ladebalken.
//  2. **EIN PDF-Render zur Zeit.** Sonst ruckelt der Flug. Eine Warteschlange mit
//     einem Platz; Seiten werden gecacht, weitere Crops derselben Seite sind billig.
//  3. **RAW-first, lokaler Fallback, dann Textkarten.** Das Manifest im Repo ist
//     die Wahrheit; eine lokale Kopie darf nicht veralten.
//
//   const reg = createCardRegistry();
//   const pool = await reg.pool();            // gemischt über alle Decks
//   reg.requestArt(card, (canvas) => …);      // gedrosselt, ruft zurück wenn da
// ============================================================================

const RAW_INDEX = 'https://raw.githubusercontent.com/georg-doc/kayfabizarro/main/media/kfb/index.json';
const LOCAL = (p) => new URL(p, import.meta.url).href;
const PDFJS = 'https://cdn.jsdelivr.net/npm/pdfjs-dist@4.7.76/build/pdf.min.mjs';
const PDFJS_WORKER = 'https://cdn.jsdelivr.net/npm/pdfjs-dist@4.7.76/build/pdf.worker.min.mjs';

function mulberry(a) { return function () { a |= 0; a = (a + 0x6D2B79F5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }

export function createCardRegistry(opts = {}) {
  let registry = null, pmap = null, pool = null, pdfjs = null;
  const decks = new Map();          // packId → normalisierte Kartenliste
  const docs = new Map();           // url → pdf-Dokument
  const pages = new Map();          // url#seite → Canvas
  const artCache = new Map();       // packId#n → Canvas (Quadrant)
  let busy = false;
  const queue = [];
  let cellAspect = null;            // GEMESSEN aus der gerenderten Zelle (H/W)

  async function loadRegistry() {
    if (registry) return registry;
    for (const url of [RAW_INDEX, LOCAL('./kfb-index.json')]) {
      try { registry = await (await fetch(url)).json(); break; }
      catch (e) { /* nächster Versuch */ }
    }
    if (!registry) registry = { decks: [], baseUrl: '' };
    pmap = {};
    for (const d of (registry.decks || [])) pmap[d.packId] = d;
    return registry;
  }

  const fileUrl = (file) => (registry.baseUrl || '') + '/' + encodeURIComponent(file);

  // Karten-JSON eines Decks. Compact-Keys (n/t/p/l/g) werden über keyMap aufgelöst —
  // beide Schreibweisen kommen im Repo vor.
  async function loadDeck(packId) {
    if (decks.has(packId)) return decks.get(packId);
    await loadRegistry();
    const rd = pmap[packId];
    if (!rd || !rd.data) { decks.set(packId, []); return []; }
    let raw = null;
    try { raw = await (await fetch(fileUrl(rd.data))).json(); } catch (e) { decks.set(packId, []); return []; }
    const list = Array.isArray(raw) ? raw : (raw.cards || raw.data || []);
    const cards = list.map((c) => ({
      n: c.cardNumber != null ? c.cardNumber : c.n,
      title: c.cardName || c.t || '',
      power: c.power || c.p || '',
      lore: c.lore || c.l || '',
      deck: rd.title, packId, role: rd.role, gameMode: rd.gameMode,
    })).filter((c) => c.n && c.title);
    decks.set(packId, cards);
    return cards;
  }

  // Ein gemischter Pool über alle (oder gefilterte) Decks. Der Almanach ist eindeutig:
  // gemischt wird es erst gut — der Funke springt zwischen zwei Stimmungen.
  async function buildPool(o = {}) {
    if (pool && !o.force) return pool;
    await loadRegistry();
    const want = (registry.decks || []).filter((d) => (!o.gameMode || d.gameMode === o.gameMode));
    const all = [];
    for (const d of want) {
      const cards = await loadDeck(d.packId);
      for (const c of cards) all.push(c);
    }
    const rnd = mulberry(o.seed || 4242);
    for (let i = all.length - 1; i > 0; i--) { const j = (rnd() * (i + 1)) | 0; const t = all[i]; all[i] = all[j]; all[j] = t; }
    pool = all;
    return pool;
  }

  async function ensurePdfjs() {
    if (pdfjs) return pdfjs;
    const lib = await import(PDFJS);
    lib.GlobalWorkerOptions.workerSrc = PDFJS_WORKER;
    pdfjs = lib;
    return lib;
  }

  async function renderPage(url, pageNum, targetW) {
    const key = url + '#' + pageNum;
    if (pages.has(key)) return pages.get(key);
    const lib = await ensurePdfjs();
    let doc = docs.get(url);
    if (!doc) { doc = await lib.getDocument({ url }).promise; docs.set(url, doc); }
    const page = await doc.getPage(pageNum);
    const scale = targetW / page.getViewport({ scale: 1 }).width;
    const vp = page.getViewport({ scale });
    const cv = document.createElement('canvas'); cv.width = vp.width; cv.height = vp.height;
    await page.render({ canvasContext: cv.getContext('2d'), viewport: vp }).promise;
    pages.set(key, cv);
    return cv;
  }

  // Der Crop selbst: halbe Seite in x und y, Quadrant nach cardMapping. m = 0 —
  // v4 schneidet ohne weißen Gutter, die Tuschekante der Karte bleibt im Bild.
  async function cropCard(card) {
    const ck = card.packId + '#' + card.n;
    if (artCache.has(ck)) return artCache.get(ck);
    await loadRegistry();
    const rd = pmap[card.packId];
    if (!rd || !rd.pdf) return null;
    const off = rd.coverOffset != null ? rd.coverOffset : 1;
    const pageNum = off + 1 + Math.floor((card.n - 1) / 4);
    const qi = (card.n - 1) % 4;
    const pg = await renderPage(fileUrl(rd.pdf), pageNum, 1500);
    const hw = Math.floor(pg.width / 2), hh = Math.floor(pg.height / 2);
    cellAspect = hh / hw;
    const sx = (qi % 2) ? hw : 0, sy = (qi >= 2) ? hh : 0;
    const cv = document.createElement('canvas'); cv.width = hw; cv.height = hh;
    cv.getContext('2d').drawImage(pg, sx, sy, hw, hh, 0, 0, hw, hh);
    artCache.set(ck, cv);
    return cv;
  }

  function pump() {
    if (busy || !queue.length) return;
    if (document.hidden) return;        // pdf.js rendert intern per rAF — im versteckten Tab kommt nichts
    const job = queue.shift();
    busy = true;
    let done = false;
    // WATCHDOG: pdf.js treibt seinen Canvas-Render intern über requestAnimationFrame. Wechselt der
    // Nutzer während eines Renders den Tab, settelt das Promise NIE — ohne diesen Timer bliebe
    // `busy` für die ganze Sitzung hängen und die Artwork-Pipeline wäre tot, ohne eine Zeile im Log.
    const finish = (ok, err) => {
      if (done) return;
      done = true;
      clearTimeout(timer);
      if (!ok) {
        if (job.tries < 2) { job.tries++; queue.push(job); }
        else { if (job.fail) job.fail(err); if (err) console.warn('[card-registry] Artwork fehlgeschlagen', job.card.packId, job.card.n, err); }
      }
      busy = false;
      pump();
    };
    const timer = setTimeout(() => finish(false, null), 20000);
    cropCard(job.card)
      .then((cv) => { if (done) return; if (cv) { done = true; clearTimeout(timer); job.cb(cv, cellAspect); busy = false; pump(); } else finish(false, new Error('kein Artwork im Manifest')); })
      .catch((e) => finish(false, e));
  }

  // Ein Tab-Wechsel darf keinen Slice abschalten: sobald das Bild wieder sichtbar ist, läuft die
  // Warteschlange weiter.
  document.addEventListener('visibilitychange', () => { if (!document.hidden) pump(); });

  return {
    name: 'card-registry', loadRegistry, loadDeck, pool: buildPool,
    get decks() { return (registry && registry.decks) || []; },
    get cellAspect() { return cellAspect; },
    get pending() { return queue.length + (busy ? 1 : 0); },
    // EIN Render zur Zeit — der Flug darf davon nichts merken. `fail` wird gerufen, wenn der Job
    // endgültig aufgibt: der Aufrufer muss seine Karte wieder freigeben, sonst bleibt sie für die
    // Sitzung als „läuft noch" markiert und bekommt nie Artwork.
    requestArt(card, cb, fail) {
      if (!card || !cb) return;
      const ck = card.packId + '#' + card.n;
      if (artCache.has(ck)) { cb(artCache.get(ck), cellAspect); return; }
      if (queue.some((j) => j.card === card)) return;
      queue.push({ card, cb, fail, tries: 0 });
      pump();
    },
    clearQueue() { queue.length = 0; },
  };
}

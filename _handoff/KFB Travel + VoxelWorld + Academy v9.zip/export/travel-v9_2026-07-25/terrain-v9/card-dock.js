// ============================================================================
// card-dock.js — KFB Travel · Slice S32c · Landung in die Karten-Detailansicht
// ----------------------------------------------------------------------------
// Georgs Sequenz, wörtlich: **mit dem Pet anfliegen → per Zoom in POV (Pet weg) →
// vor der Karte abbremsen → ausrichten → saubere Landung in die Detailansicht.**
// Die Detailansicht ist KEIN Overlay und kein zweiter Viewport: sie ist die Karte,
// bildschirmfüllend, mit ihrer Tuschekante und ihrer Live-Demo. Genau deshalb
// braucht es hier auch kein DOM — nur eine Kamera, die richtig steht.
//
// WIE DIE ÜBERGABE FUNKTIONIERT (der Trick, der den Slice klein hält):
// Das Dock rechnet die IDEALE Kartenansicht und liefert sie als GEWICHTETEN BEITRAG:
//     mix = { k, pos, look },  k: 0 → 1 beim Landen, 1 → 0 beim Lösen.
// Das Rig mischt beides mit demselben k. Damit gibt es keinen zweiten Kamera-Zustand,
// kein Umschalten, kein Ruck — und das Lösen ist derselbe Weg rückwärts.
//
// **Responsiv heißt hier: die Distanz kommt aus dem FOV und dem Seitenverhältnis.**
// Ein Hochformat-Fenster darf die Karte nicht anschneiden, ein breites soll sie
// nicht verschenken — also `max(halfH/tan(fov/2), halfW/(tan(fov/2)·aspect))·pad`.
// Beim Fenster-Resize stimmt es dadurch von selbst, jeden Frame neu.
//
// Das FLUGZEUG hält das Dock NICHT an — die Karte fliegt, das ist Kanon. Während
// der Detailansicht kreist der Auto-Pilot weiter (`loiter`), unsichtbar hinter der
// Kamera. Das hält Streaming, Live-Pacer und Fokus-Distanz am Leben.
//
// **S41 (V9-A): das Dock schreibt die Kamera NICHT mehr.** Es liefert `mix` = { k, pos, look },
// und `camera-rig.js` mischt es an seiner einen Schreibstelle ein. Vorher wurde die Position mit
// `k` gemischt, das Blickziel aber ab `k > 0,04` **hart überschrieben** — ein Faktor für das eine,
// ein Schalter für das andere. Genau das war Georgs springende Detailansicht.
// Es bekommt deshalb auch keine Kamera mehr, sondern nur noch `{ fov, aspect }`: was man nicht
// hat, kann man nicht schreiben.
//
//   const dock = createCardDock({ THREE });
//   dock.request(card, camera);          // nach der Ankunft (liest die Blickachse EINMAL)
//   dock.update(dt, { fov, aspect });    // VOR dem Rig
//   dock.release();                      // Esc/X/Steuern
// ============================================================================

export function createCardDock(opts = {}) {
  const THREE = opts.THREE;
  const P = Object.assign({
    pad: 1.08,        // Randabstand: 1.0 = Karte randlos, größer = mehr Luft
    ease: 2.4,        // 1/s — Landegeschwindigkeit (Position mischt sich ein)
    // Die Landung mischt mit einer S-KURVE, nicht mit dem rohen `k`. Das rohe k ist exponentiell
    // (`k += (1-k)*dt*ease`), also am ANFANG am schnellsten — genau im Moment der Übergabe vom
    // Follow-Flug. Das war der Lurch beim Andocken (gemessen 46°/s Spitze).
    sCurve: true,
    leave: 0.55,      // s — Lösen
    dockedAt: 0.9,    // ab diesem k gilt „gelandet" (Zeiger gehört der Demo)
  }, opts.params || {});

  const api = { onDock: null, onLeave: null };
  let phase = 'off', card = null, k = 0, fit = 0;
  const _n = new THREE.Vector3(), _p = new THREE.Vector3(), _t = new THREE.Vector3(), _up = new THREE.Vector3();
  // **Die Andock-Achse wird beim Anfordern EINGEFROREN.** Sie aus der laufenden Kartennormale zu
  // nehmen war eine Mitkopplung: die Kamera stellt sich auf die Normale, die Karte dreht sich zur
  // Kamera — jede kleine Vertikal-Abweichung wuchs, bis die Kamera über der Karte stand. Dann
  // entartet die Billboard-Basis (`up × to` → 0) und alles kippt: gemessen Karten-Up 88° aus der
  // Senkrechten, Kamera-Roll 71°, Normale und Blickachse trotzdem deckungsgleich (5°) — ein
  // stabiler, falscher Fixpunkt. Eine feste Achse hat den nicht.
  const _axis = new THREE.Vector3(0, 0, 1);

  function pads(c) {
    const top = (c && c.padTop) || 0;                       // Titel-Anhängsel über der Karte
    // Post-it unter der Karte: **statische** Geometrie, nicht die lebende Position. Die wippt im
    // Wind (`lagY`), und jede Wippe änderte sonst die Andock-Distanz — die Kamera kroch mit.
    const bottom = c && c.postit && c.postit.visible ? c.pw * 0.42 + c.postit.geometry.parameters.height * 0.5 : 0;
    return { top, bottom };
  }
  function fitDistance(view, c) {
    const vf = view.fov * Math.PI / 180, tan = Math.tan(vf / 2);
    // Was an der Karte hängt, gehört in den Rahmen: Glyph-Titel oben, Post-it unten. Rahmt man
    // nur das Blatt, rutschen beide aus dem Bild (erst beim Post-it gemessen, dann bei den Glyphen).
    const pd = pads(c);
    const dH = (c.half.h + (pd.top + pd.bottom) * 0.5) / tan;
    const dW = c.half.w / (tan * Math.max(view.aspect, 0.2));
    return Math.max(dH, dW) * P.pad;
  }

  function update(dt, view) {
    if (phase === 'off' || !card) return false;
    if (phase === 'leave') {
      k -= dt / Math.max(0.05, P.leave);
      if (k <= 0) { k = 0; phase = 'off'; card = null; return false; }
    } else {
      k += (1 - k) * Math.min(1, dt * P.ease);
      if (phase === 'align' && k >= P.dockedAt) { phase = 'docked'; if (api.onDock) { try { api.onDock(card); } catch (e) {} } }
    }
    _p.copy(card.holder.position);
    // Blickziel folgt der Asymmetrie der Anhänge: Titel oben schiebt es hoch, Post-it unten runter.
    const pd = pads(card);
    _p.y += (pd.top - pd.bottom) * 0.5;
    // Die Fit-Distanz wird TIEFPASSGEFILTERT: sie hängt an FOV und Seitenverhältnis (soll sie),
    // aber das FOV selbst läuft während des Übergangs noch — ungefiltert wäre das ein Kriechen.
    const want = fitDistance(view, card);
    fit = fit > 0 ? fit + (want - fit) * Math.min(1, dt * 3) : want;
    _t.copy(_p).addScaledVector(_axis, fit);
    return true;
  }

  return {
    name: 'card-dock', update, fitDistance,
    // Der Beitrag ans Rig: Ziel, Blickziel, Gewicht. Kein Schreibzugriff.
    // `k` ist die S-Kurve über dem rohen Fortschritt — weiche Enden auf beiden Seiten.
    get mix() { return phase === 'off' ? null : { k: P.sCurve ? k * k * (3 - 2 * k) : k, pos: _t, look: _p }; },
    get phase() { return phase; },
    get owns() { return phase !== 'off'; },
    get docked() { return phase === 'docked'; },
    get progress() { return k; },
    get card() { return card; },
    request(c, camera) {
      if (!c || card === c) return;
      card = c; phase = 'align'; k = Math.max(k, 0); fit = 0;
      // Achse = Blickrichtung im Moment der Ankunft, aber flach gehalten: aus steiler Auf- oder
      // Untersicht ist eine Lesekarte keine Lesekarte.
      if (camera) _axis.subVectors(camera.position, c.holder.position);
      else _axis.set(0, 0, 1).applyQuaternion(c.holder.quaternion);
      if (_axis.lengthSq() < 1e-6) _axis.set(0, 0, 1);
      _axis.normalize();
      const maxY = 0.3;
      if (Math.abs(_axis.y) > maxY) {
        const s = Math.sign(_axis.y) * maxY;
        _axis.y = s;
        const h = Math.sqrt(Math.max(1e-6, 1 - s * s)) / Math.max(1e-6, Math.hypot(_axis.x, _axis.z));
        _axis.x *= h; _axis.z *= h;
      }
    },
    release() {
      if (phase === 'off' || phase === 'leave') return;
      phase = 'leave';
      if (api.onLeave) { try { api.onLeave(card); } catch (e) {} }
    },
    setParams(p) { Object.assign(P, p || {}); },
    get params() { return P; },
    get onDock() { return api.onDock; }, set onDock(f) { api.onDock = f; },
    get onLeave() { return api.onLeave; }, set onLeave(f) { api.onLeave = f; },
  };
}

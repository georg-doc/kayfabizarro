// ============================================================================
// pet-facing.js — KFB Travel · Slice S33b · Wohin das Pet schaut
// ----------------------------------------------------------------------------
// Portiert aus `rollercoaster-v11` (dort `this.petFacing` + Slerp zwischen
// `qTrack` und `qFace`): **im Stand dreht sich das Pet zu dir, mit Tempo in die
// Fahrtrichtung.** Drei Stellungen wie in v11 — `auto` · `player` · `track`.
//
// WARUM EIN EIGENES MODUL UND KEINE ZEILE IN `pet-kinetics.js`:
// Die Kinetik steht auf „nicht anfassen" (Briefing §8) und besitzt Squash, Lean
// und den Gehzyklus. Das Facing ist eine **dünne Schicht DANACH** — Reihenfolge-
// Kanon des Runners: Motor zuerst (PetMotion/Face/EyeRig), dann unsere Kinetik,
// dann das Facing obendrauf.
//
// **Nur die Gier wird geschrieben** (`rotation.y`), nie das ganze Quaternion:
// sonst wäre der Lean aus der Kinetik weg. Das ist der ganze Trick, mit dem sich
// zwei Systeme dasselbe Objekt teilen, ohne sich zu überschreiben.
//
// Die Mischung ist v11s Kurve: `f = clamp(1 − speed01 · 1.5, 0, 1)` — bis etwa
// zwei Drittel Höchsttempo ist das Pet also schon ganz auf Fahrtrichtung. Der
// Blick der Augen folgt separat und SANFT (`EyeRig.pointTo`), nie als Hard-Lock:
// ein Pet, dessen Pupillen kleben, sieht aus wie ein Fehler.
//
//   const facing = createPetFacing({ THREE });
//   facing.update(dt, { pet, camera, speed01 });   // NACH petKin.update
//   facing.setMode('player');
// ============================================================================

export function createPetFacing(opts = {}) {
  const THREE = opts.THREE;
  const P = Object.assign({
    mode: 'auto',        // 'auto' | 'player' | 'track'
    base: Math.PI,       // Fahrtrichtung: so wird das Pet beim Mount gesetzt (−Z)
    damp: 3.4,           // 1/s — wie schnell der Kopf der Mischung folgt
    speedGain: 1.5,      // v11: f = clamp(1 − speed01 · 1.5, 0, 1)
    eyeTrack: true,
  }, opts.params || {});

  const _v = new THREE.Vector3();
  let curYaw = P.base, blend = 0, lastYawTo = 0;

  const shortAngle = (a) => Math.atan2(Math.sin(a), Math.cos(a));

  function update(dt, src) {
    const pet = src && src.pet, camera = src && src.camera;
    if (!pet || !pet.object3D || !camera) return;
    const obj = pet.object3D;
    if (!obj.parent) return;

    // Kamera in den ELTERN-Raum des Pets holen: der Sitz dreht mit der Karte, also ist
    // „zur Kamera" dort eine andere Gier als in der Welt.
    _v.copy(camera.position);
    obj.parent.worldToLocal(_v);
    const dx = _v.x - obj.position.x, dz = _v.z - obj.position.z;
    const yawToCam = Math.atan2(dx, dz);
    lastYawTo = yawToCam;

    const s01 = Math.max(0, Math.min(1, (src.speed01 != null ? src.speed01 : 0)));
    let f;
    if (P.mode === 'player') f = 1;
    else if (P.mode === 'track') f = 0;
    else f = Math.max(0, Math.min(1, 1 - s01 * P.speedGain));
    blend += (f - blend) * Math.min(1, dt * 2.4);

    const target = P.base + shortAngle(yawToCam - P.base) * blend;
    curYaw += shortAngle(target - curYaw) * Math.min(1, dt * P.damp);
    obj.rotation.y = curYaw;

    // Augen: sanfter Drift zur Kamera, kein Hard-Lock. Der EyeRig (v5) macht die Dämpfung
    // selbst; wir liefern nur das Ziel — und nur, wenn er die Schnittstelle wirklich hat.
    if (P.eyeTrack && pet.rig && pet.rig.pointTo) {
      try { pet.rig.pointTo(camera.position); } catch (e) { P.eyeTrack = false; }
    }
  }

  return {
    name: 'pet-facing', update,
    get mode() { return P.mode; },
    setMode(m) { P.mode = m === 'player' || m === 'track' ? m : 'auto'; },
    get blend() { return blend; },
    get yaw() { return curYaw; },
    get yawToCam() { return lastYawTo; },
    // Beim Modus-Wechsel (Walk ⇄ Fly) sitzt das Pet in einem anderen Eltern-Raum:
    // Gier zurücksetzen, sonst dreht der Kopf einmal quer durchs Bild.
    reset(base) { P.base = base != null ? base : P.base; curYaw = P.base; blend = 0; },
    setParams(p) { Object.assign(P, p || {}); },
    get params() { return P; },
  };
}

// ============================================================================
// flight-controller.js — KFB Travel · Motion Controller (Flight)
// ----------------------------------------------------------------------------
// Extracted from PetFlight v2 (petflight.v2.js) and ADAPTED from the sphere
// world to a FLAT world (up = +Y, constant). The Dragonriding control feel is
// preserved 1:1: drag-hold = turn/climb RATE, W/S thrust, A/D yaw, ↑/↓ altitude,
// Space boost, idle glides out. WebGL three 0.160.
//
// Contract (004/005 Motion Controller): owns movement ONLY — no camera, no pet,
// no rendering. Consumes normalized input + ground height; publishes vehicle
// state (position/orientation/velocity/flags) that CardRig + camera read.
//
//   const fc = createFlightController({ THREE });
//   fc.update(dt, input, groundY);   // input = { yawIn, climbIn, thrust, boost }
//   fc.state → { position, quaternion, forward, right, up, speed, alt, bank,
//                pitchTilt, boosting, climbIn, grounded, flying }
// ============================================================================

export function createFlightController(opts = {}) {
  const THREE = opts.THREE;
  const P = Object.assign({
    SPD_MIN: 2, SPD_MAX: 42, CRUISE: 9,
    // **Rückwärtsgang** (S45): „S" fährt unter null weiter — zurück zu einer verpassten Karte, ohne
    // eine ganze Kurve zu fliegen. Das Blatt dreht sich dabei NICHT: es schiebt sich rückwärts,
    // und man sieht es an der Nase (sie hebt sich leicht, wie beim Bremsen).
    SPD_REV: -11, revPitch: 0.12,
    // **Standdrehung** (Q/E): Drehen um die eigene Achse, statt eine Kurve zu fliegen. Sie ist keine
    // zweite Lenkung, sondern Lenkung PLUS Tempo-Bremse: wer sich auf der Stelle dreht, fährt nicht.
    // Zusammen mit dem Rückwärtsgang ist das der ganze Weg zurück zu einer verpassten Karte:
    // S halten → Q/E drehen → W weiterfliegen.
    pivotRate: 2.4, pivotHold: 3.0,
    ALT_MIN: 2.2, ALT_MAX: 160,
    yawRate: 1.9, climbRate: 16, accel: 14, decel: 16,
    // **Harte Bremse** (X, und derselbe Weg für den Anflug): sie zieht das Soll-Tempo mit
    // `decel · brakeGain` herunter UND lässt die Ist-Geschwindigkeit schneller folgen. Ohne das
    // Zweite verpufft jede Bremse in der 2/s-Trägheit: das Soll fällt, das Ist folgt gemütlich —
    // genau der lange Bremsweg, über den sich der Anflug beschwert hat.
    brakeGain: 3.4, brakeLag: 4.5, brakePitch: 0.3,
    // **Warp** (S43): die Reisegrenze ist kein Naturgesetz, sondern eine Regie-Entscheidung. Für
    // lange Strecken — Zonenwechsel, Auto-Pilot, später Level-Übergänge — darf sie überschritten
    // werden. `warp` ist ein FAKTOR 0..1, kein Schalter: das Tempo wächst mit ihm, die Trägheit
    // sinkt (sonst braucht Warp länger zum Einsetzen, als die Strecke dauert).
    warpGain: 2.6, warpLag: 3.2, warpPitch: -0.06,
    // S2 · „der Boost fühlt sich FREIER an, nicht nur schneller“. Im Report ist das
    // ein wegfallender Kurven-Drag — den gibt es bei uns nicht (Lenken kostet hier
    // kein Tempo). Also die andere Hälfte derselben Absicht: mehr Lenk-Autorität,
    // solange der Boost läuft. 1 = aus.
    boostYawGain: 1.28,
    // S10 · Landung: ab wann gilt Bodenkontakt als „gelandet". Nicht Berührung ALLEIN — sonst
    // kippt ein Streifschuss über einen Cube-Gipfel mitten im Flug in den Laufmodus. Es braucht
    // Bodenkontakt UND kleine Sinkrate UND (fast immer) den Willen zu sinken, gehalten über
    // `landHold` Sekunden. Hysterese also hier, nicht im Runner.
    landSink: 7, landHold: 0.22,
  }, opts.params || {});

  const up = new THREE.Vector3(0, 1, 0);
  const forward = new THREE.Vector3(0, 0, -1);   // heading, kept horizontal
  const right = new THREE.Vector3(1, 0, 0);
  const pos = new THREE.Vector3(0, P.CRUISE, 0);
  let alt = P.CRUISE, targetAlt = P.CRUISE;
  let speed = P.CRUISE, targetSpeed = P.CRUISE;
  let bank = 0, pitchTilt = 0, boosting = false, climbIn = 0, grounded = false, braking = 0, warp = 0, pivoting = false;
  let prevAlt = alt, sinkRate = 0, touchT = 0, landed = false;

  const quaternion = new THREE.Quaternion();
  const _m = new THREE.Matrix4(), _q = new THREE.Quaternion();
  const _negF = new THREE.Vector3(), _zAxis = new THREE.Vector3(0, 0, 1), _xAxis = new THREE.Vector3(1, 0, 0);

  function update(dt, input, groundY) {
    input = input || {}; groundY = groundY || 0;
    climbIn = input.climbIn || 0;
    boosting = !!input.boost;
    const pivot = Math.max(-1, Math.min(1, input.pivot || 0));
    pivoting = Math.abs(pivot) > 0.01;
    const yawIn = ((input.yawIn || 0) + pivot * P.pivotRate * dt) * (boosting ? P.boostYawGain : 1);
    // --- steering: rotate forward around up, keep horizontal ---
    forward.applyAxisAngle(up, yawIn);
    forward.y = 0; forward.normalize();
    right.crossVectors(forward, up).normalize();
    // bank follows turn rate (visual, but published for CardRig/pet lean)
    bank += ((-yawIn / Math.max(dt, 1e-3) * 0.06) - bank) * Math.min(1, dt * 5);
    bank = Math.max(-0.6, Math.min(0.6, bank));

    // --- altitude ---
    targetAlt = Math.max(P.ALT_MIN, Math.min(P.ALT_MAX, targetAlt + climbIn));
    alt += (targetAlt - alt) * Math.min(1, dt * 2.2);
    const minAlt = groundY + P.ALT_MIN;
    if (alt < minAlt) { alt = minAlt; targetAlt = Math.max(targetAlt, minAlt); }
    grounded = alt <= minAlt + 0.02;

    // --- S10: Sinkrate + Landungs-Erkennung (mit Hysterese) ---
    const dAlt = (alt - prevAlt) / Math.max(dt, 1e-3); prevAlt = alt;
    sinkRate += (-dAlt - sinkRate) * Math.min(1, dt * 8);     // positiv = sinken
    const wantsDown = climbIn < -0.001;
    if (grounded && sinkRate < P.landSink && (wantsDown || sinkRate > 0.5)) touchT += dt;
    else touchT = 0;
    landed = touchT >= P.landHold;

    // --- speed ---
    // **Der Schub ist ein Wert, kein Schalter.** Vorher zählte nur das Vorzeichen, also konnte ein
    // Regler (Auto-Pilot) nur Vollgas, Vollbremse oder nichts — daraus wurde das ruckelige
    // Bang-Bang-Beschleunigen. Die Hand schickt weiter ±1 und fühlt sich identisch an.
    const th = Math.max(-1, Math.min(1, input.thrust || 0));
    const br = Math.max(0, Math.min(1, input.brake || 0));
    warp = Math.max(0, Math.min(1, br ? 0 : (input.warp || 0)));   // bremsen schlägt warpen
    if (th > 0) targetSpeed = Math.min(P.SPD_MAX, targetSpeed + P.accel * th * dt);
    // Unter SPD_MIN geht es weiter bis SPD_REV — das ist der Rückwärtsgang. Ohne gehaltenes „S"
    // kriecht das Tempo nicht von selbst ins Negative: es hält sich über SPD_MIN.
    if (th < 0) targetSpeed = Math.max(P.SPD_REV, targetSpeed + P.decel * th * dt);
    if (th >= 0 && !br && targetSpeed < P.SPD_MIN) targetSpeed = Math.min(P.SPD_MIN, targetSpeed + P.accel * 0.7 * dt);
    if (br) targetSpeed = Math.max(P.SPD_MIN, targetSpeed - P.decel * P.brakeGain * br * dt);
    // Leerlauf gleitet auf Reisetempo aus — auch aus dem Rückwärtsgang heraus.
    if (input.idle) targetSpeed += (P.CRUISE * 0.4 - targetSpeed) * Math.min(1, dt * 0.7);
    // Standdrehung hält das Tempo bei nahezu null — sonst beschreibt man einen Bogen statt sich zu
    // drehen. Das ist derselbe Griff wie die Bremse, nur automatisch, solange Q/E gehalten wird.
    if (pivot) targetSpeed += (0 - targetSpeed) * Math.min(1, dt * P.pivotHold);
    const desired = boosting && !br ? P.SPD_MAX : targetSpeed;
    // Warp hebt die OBERGRENZE, nicht nur das Soll — sonst deckelt `targetSpeed` bei SPD_MAX.
    const wDesired = warp > 0.001 && desired > 0 ? Math.max(desired, P.SPD_MAX * (1 + P.warpGain * warp)) : desired;
    speed += (wDesired - speed) * Math.min(1, dt * (br ? 2 + P.brakeLag * br
      : (warp > 0.001 ? 2 + P.warpLag * warp : (boosting ? 4 : 2))));
    braking = br;

    // --- travel (flat): advance along forward, y = alt ---
    pos.addScaledVector(forward, speed * dt);
    pos.y = alt;

    // --- orientation: -Z = forward, +Y = up, + bank + pitch ---
    _negF.copy(forward).negate();
    _m.makeBasis(right, up, _negF);
    quaternion.setFromRotationMatrix(_m);
    quaternion.multiply(_q.setFromAxisAngle(_zAxis, bank));
    // Bremsen hebt die Nase — das ist die Körpersprache, an der man eine Bremse SIEHT.
    const pitchTarget = Math.max(-0.42, Math.min(0.42, (targetAlt - alt) * 0.06 + climbIn * 2.4)) + braking * P.brakePitch + warp * P.warpPitch + (speed < -0.4 ? P.revPitch : 0);
    pitchTilt += (pitchTarget - pitchTilt) * Math.min(1, dt * 5);
    quaternion.multiply(_q.setFromAxisAngle(_xAxis, -pitchTilt));
  }

  return {
    name: 'flight-controller', update,
    get state() {
      return {
        position: pos, quaternion, forward, right, up,
        speed, alt, bank, pitchTilt, boosting, climbIn, grounded, flying: !grounded,
        braking, sinkRate, landed, targetAlt,
        warp, warpOver: Math.max(0, speed / P.SPD_MAX - 1),   // 0 = im Rahmen, 1 = doppelt so schnell
        reverse: speed < -0.4,
        pivoting,
      };
    },
    setCruise() { alt = targetAlt = P.CRUISE; speed = targetSpeed = P.CRUISE; },
    // S10: Abheben braucht beides — auf der aktuellen Höhe EINSETZEN (kein Sprung nach oben)
    // und ein Steigziel darüber. `climbTo` ist genau dafür, `setTargetAlt` für das Overlay.
    setTargetAlt(v) { targetAlt = Math.max(P.ALT_MIN, Math.min(P.ALT_MAX, v)); },
    climbTo(v) { targetAlt = Math.max(alt, Math.min(P.ALT_MAX, v)); touchT = 0; landed = false; },
    setParams(p) { Object.assign(P, p || {}); },
    get params() { return P; },
    // alt/heading optional: von der Landung kommend setzt der Runner beides, damit die Karte
    // dort weiterfliegt, wo das Pet stand — und in die Richtung, in die es sah.
    reset(x, z, atAlt, heading) {
      const h = heading != null ? heading : Math.PI;
      pos.set(x || 0, 0, z || 0);
      forward.set(Math.sin(h), 0, Math.cos(h)).normalize();
      right.crossVectors(forward, up).normalize();
      alt = targetAlt = prevAlt = (atAlt != null ? Math.max(P.ALT_MIN, atAlt) : P.CRUISE);
      pos.y = alt;
      speed = targetSpeed = P.CRUISE;
      bank = pitchTilt = 0; sinkRate = 0; touchT = 0; landed = false;
    },
  };
}

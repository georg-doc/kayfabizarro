// ============================================================================
// travel-input.js — KFB Travel · Slice S44c (V9-C, Teil 3) · die Eingabe-Schicht
// ----------------------------------------------------------------------------
// Tasten, Zeiger, Rad, Doppelklick und die Umrechnung in die vier Fahrzeugwerte
// (`yawIn` · `climbIn` · `thrust` · `brake`/`warp`/`pivot`). Sie war die letzte große
// Nachbarschaft im Runner, die nichts mit Verdrahtung zu tun hat.
//
// **Die Schicht ENTSCHEIDET NICHTS über den Zustand.** Sie liest Tasten und liefert
// Werte; wer daraus einen Modus-Wechsel macht, ist der Eigentümer (`requestMode`),
// und wer die Kamera bewegt, ist das Rig. Genau deshalb steht hier kein `mode = …`
// und kein `camera.…` — nur Anträge und Zahlen.
//
// Zwei Regeln, die aus Fehlern stammen und hier bleiben müssen:
//  · **Offenes Overlay oder offenes Suchfeld nehmen die Tasten.** Sonst lenkt „part"
//    beim Tippen das Fahrzeug (a = links).
//  · **Der Einfachklick gehört der Demo, der Doppelklick dem Anflug** — aber nur auf
//    dem Fenster der Karte, die gerade läuft. Sonst verschluckt die Demo den Anflug.
//
// Abhängigkeiten kommen über `ctx.x` (Getter im Runner), nicht destrukturiert: die
// Schicht wird gebaut, während einige Bezüge noch nicht deklariert sind.
//
//   const input = createTravelInput(ctx);
//   input.keys · input.read(dt)
// ============================================================================

export function createTravelInput(ctx) {
  const keys = new Set();
  let lastSpaceAt = 0, lastZoomAt = 0;
addEventListener('keydown', (e) => {
  if (ctx.settings.isOpen()) return;            // Overlay offen: Tasten gehören dem Formular
  // … und das gilt genauso für das Suchfeld: sonst lenkt „part" beim Tippen (a = links).
  if (ctx.search.isOpen()) {
    if (e.code === 'Escape') ctx.search.close();
    return;
  }
  ctx.armAudio();
  keys.add(e.code);
  // Steuern bricht den Anflug ab — der Nutzer gewinnt immer, und zwar ohne Sonderfall.
  if (['KeyW', 'KeyS', 'KeyA', 'KeyD', 'ArrowUp', 'ArrowDown', 'KeyX', 'Space', 'KeyF', 'Escape'].includes(e.code)) {
    if (ctx.dock.owns) { ctx.dock.release(); ctx.note('Detailansicht verlassen.', 2.5); }
    if (ctx.auto.active && e.code !== 'Escape') { ctx.auto.cancel(); ctx.note('Steuerung zurück bei dir.', 2.5); }
  }
  if (e.code === 'KeyR' && !e.repeat && ctx.academyOn) {
    // Nur ein LAUFENDER Anflug wird gestoppt. Kreisen oder Detailansicht sind kein Grund,
    // die Route zu verweigern — vorher schluckte `R` in der Detailansicht nur die Warteschleife.
    if (ctx.auto.flying) { ctx.auto.cancel(); ctx.note('Route gestoppt.'); } else ctx.flyRoute();
  }
  if (['ArrowUp', 'ArrowDown', 'Space'].includes(e.code)) e.preventDefault();
  if (e.code === 'KeyF' && !e.repeat) ctx.requestMode(ctx.isWalk() ? 'fly' : 'walk', 'hand');
  if (e.code === 'KeyJ' && !e.repeat && !ctx.isWalk()) ctx.petKin.jump();
  if (e.code === 'Space' && !e.repeat) {
    // Kontext entscheidet, nicht ein Sonderfall: am Boden Sprung, doppelt = abheben.
    // In der Luft bleibt die Leertaste der Boost — die Doppel-Erkennung läuft dort ins Leere.
    const t = performance.now(), dbl = t - lastSpaceAt < 280;
    lastSpaceAt = t;
    if (ctx.isWalk()) { if (dbl && ctx.autoMode) ctx.takeOff(); else ctx.walk.jump(); }
  }
  if (e.code === 'Tab' && !e.repeat) { e.preventDefault(); ctx.settings.toggle('travel'); }
});
addEventListener('keyup', (e) => keys.delete(e.code));
let steer = false, grabX = 0, grabY = 0, sx = 0, sy = 0, lastInputAt = performance.now(), lastPX = 0, lastPY = 0;
let demoPtr = null;   // S31: dieser Zeiger gehört der Demo auf dem Blatt, nicht der Steuerung
const ptrs = new Map(); let pinch0 = 0, zoom0 = 0;
const el = ctx.renderer.domElement;
el.addEventListener('pointerdown', (e) => {
  if (e.__hudClaimed) return;   // S7: der HUD-Würfel hat diesen Zeiger
  ctx.armAudio();
  // S31 · Klick-Kollision, hier entschieden und nicht später: der Einfachklick gehört der
  // Demo — aber NUR auf dem Fenster der Karte, die gerade läuft. Sonst verschluckt die
  // Demo den Anflug-Klick.
  if (ctx.academyOn && ctx.shownLive && ctx.live.live) {
    const hit = ctx.pickAcademy(e.clientX, e.clientY);
    if (hit && hit.card === ctx.shownLive && hit.onScreen && hit.uv) {
      demoPtr = e.pointerId;
      ctx.live.pointer(hit.uv.x, hit.uv.y, 'down');
      try { el.setPointerCapture(e.pointerId); } catch (e2) {}
      return;
    }
  }
  // Gedockt und OHNE Demo: der Zeiger wird auf der Karte GESCHLUCKT, nicht zum Auswurf.
  // Sonst ist die Detailansicht mit der Maus nicht berührbar, ohne sie zu verlassen — und
  // eine Vorschau-Karte hat nun mal nichts zu bedienen. Raus geht über Esc/X/Steuern oder
  // einen Zug in den leeren Himmel.
  if (ctx.academyOn && ctx.dock.docked) {
    const hit = ctx.pickAcademy(e.clientX, e.clientY);
    if (hit && hit.card === ctx.dock.card) { demoPtr = e.pointerId; try { el.setPointerCapture(e.pointerId); } catch (e2) {} return; }
  }
  if (ctx.auto.active) ctx.auto.cancel();
  if (ctx.dock.owns) ctx.dock.release();   // Ziehen im leeren Himmel = umsehen = raus aus der Detailansicht
  ptrs.set(e.pointerId, { x: e.clientX, y: e.clientY }); lastInputAt = performance.now(); lastPX = e.clientX; lastPY = e.clientY;
  try { el.setPointerCapture(e.pointerId); } catch (e2) {}
  if (ptrs.size === 1) { steer = true; grabX = e.clientX; grabY = e.clientY; sx = 0; sy = 0; }
  if (ptrs.size === 2) { const p = [...ptrs.values()]; pinch0 = Math.hypot(p[0].x - p[1].x, p[0].y - p[1].y); zoom0 = ctx.camRig.zoomTarget; }
});
el.addEventListener('pointermove', (e) => {
  if (e.__hudClaimed) return;
  if (demoPtr === e.pointerId) {
    const hit = ctx.pickAcademy(e.clientX, e.clientY);
    if (hit && hit.card === ctx.shownLive && hit.uv) ctx.live.pointer(hit.uv.x, hit.uv.y, 'move');
    return;
  }
  if (!ptrs.has(e.pointerId)) return;
  const dxi = e.clientX - lastPX, dyi = e.clientY - lastPY; lastPX = e.clientX; lastPY = e.clientY;
  ptrs.set(e.pointerId, { x: e.clientX, y: e.clientY }); lastInputAt = performance.now();
  if (ptrs.size >= 2) { const p = [...ptrs.values()], d = Math.hypot(p[0].x - p[1].x, p[0].y - p[1].y); if (pinch0 > 0) { ctx.camRig.setZoom(zoom0 * (pinch0 / Math.max(d, 1))); lastZoomAt = performance.now(); } }
  else if (ctx.isWalk()) { ctx.walk.orbit(dxi, dyi); ctx.camRig.markLookAt(); }
  else { sx = e.clientX - grabX; sy = e.clientY - grabY; }
});
const endPtr = (e) => { if (demoPtr === e.pointerId) { demoPtr = null; ctx.live.pointer(0.5, 0.5, 'up'); return; } ptrs.delete(e.pointerId); if (ptrs.size < 2) pinch0 = 0; if (ptrs.size === 1) { const p = [...ptrs.values()][0]; grabX = p.x; grabY = p.y; sx = 0; sy = 0; steer = true; } if (ptrs.size === 0) { steer = false; sx = 0; sy = 0; } };
el.addEventListener('pointerup', endPtr); el.addEventListener('pointercancel', endPtr);
el.addEventListener('contextmenu', (e) => e.preventDefault());
// S22d · Doppelklick fliegt an. Einfachklick gehört der Demo (siehe pointerdown) — zwei
// Ereignisse, eine Regel: nah + Fenster = bedienen, sonst = Ziel.
el.addEventListener('dblclick', (e) => {
  if (e.__hudClaimed) return;
  const hit = ctx.pickAcademy(e.clientX, e.clientY);
  if (hit) { e.preventDefault(); ctx.flyToCard(hit.card); }
});
el.addEventListener('wheel', (e) => { e.preventDefault(); if (ctx.isWalk()) { const px = e.deltaMode === 1 ? e.deltaY * 16 : e.deltaY; ctx.walk.zoom(Math.max(-1.6, Math.min(1.6, px * 0.02))); return; } if (Math.abs(e.deltaX) > Math.abs(e.deltaY) * 1.2) { ctx.camRig.nudgeYaw(e.deltaX * 0.004); } else { ctx.camRig.zoomWheel(e.deltaY, e.deltaMode); lastZoomAt = performance.now(); } }, { passive: false });
addEventListener('resize', () => { ctx.resize(); });

function read(dt) {
  let yawIn = 0, climbIn = 0, thrust = 0;
  if (steer) {
    const dz = 12;
    const nx = Math.sign(sx) * Math.min(1, Math.max(0, (Math.abs(sx) - dz) / 170));
    const ny = Math.sign(sy) * Math.min(1, Math.max(0, (Math.abs(sy) - dz) / 150));
    yawIn += -nx * 1.9 * dt; climbIn += -ny * 16 * dt;
    if (nx || ny) lastInputAt = performance.now();
  }
  if (keys.has('KeyA')) yawIn += 1.4 * dt;
  if (keys.has('KeyD')) yawIn -= 1.4 * dt;
  if (keys.has('ArrowUp')) climbIn += 16 * dt;
  if (keys.has('ArrowDown')) climbIn -= 16 * dt;
  // X ist die HARTE BREMSE (nicht mehr Sinken — dafür ist Pfeil-Ab da). Sie ist derselbe
  // Eingang, den der Anflug benutzt: eine Bremse, zwei Nutzer.
  const brake = keys.has('KeyX') ? 1 : 0;
  if (keys.has('KeyW')) thrust = 1;
  if (keys.has('KeyS')) thrust = -1;
  if (keys.has('KeyW') || keys.has('KeyS') || keys.has('KeyA') || keys.has('KeyD')) lastInputAt = performance.now();    const idle = performance.now() - lastInputAt > 1600;
  // Warp mit der Hand: Shift+Leertaste. Es ist der Boost über der Grenze — dieselbe Taste,
  // eine Stufe weiter, statt eines neuen Griffs.
  const warp = (keys.has('Space') && (keys.has('ShiftLeft') || keys.has('ShiftRight'))) ? 1 : 0;
  // Q/E waren im Flug unbelegt (am Boden sind sie Seitwärtsschritt). Im Flug: Standdrehung um die
  // eigene Achse — Q links, E rechts, gleiche Seiten wie A/D.
  const pivot = (keys.has('KeyQ') ? 1 : 0) - (keys.has('KeyE') ? 1 : 0);
  return { yawIn, climbIn, thrust, brake, warp, pivot, boost: keys.has('Space'), idle };
}

  return { name: 'travel-input', keys, read,
    get lastZoomAt() { return lastZoomAt; },
    get steering() { return steer; } };
}

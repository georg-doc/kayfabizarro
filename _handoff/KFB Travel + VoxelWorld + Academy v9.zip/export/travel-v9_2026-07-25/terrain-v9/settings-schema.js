// ============================================================================
// settings-schema.js — KFB Travel · Slice S44b (V9-C, Teil 2) · das Panel als DATEN
// ----------------------------------------------------------------------------
// Vorher standen ~290 Zeilen Regler-Definitionen mitten im Runner. Sie sind kein
// Orchestrierungscode und keine Physik — sie sind eine LISTE. Genau deshalb hat
// die Intermission gemessen, dass ein TravelManager allein den Runner nicht klein
// macht: über die Hälfte war Panel und Frame-Schleife, nicht Verdrahtung.
//
// **Zwei Sorten Abhängigkeit, zwei Wege:**
//  · **Module und Funktionen** (`ctx.terrain`, `ctx.academy`, `ctx.note`, `ctx.requestMode` …) kommen als
//    Referenz — sie ändern sich nicht.
//  · **Veränderliche Runner-Zustände** (`danceMode`, `bpm`, `groundCalm` …) kommen über EIN
//    Objekt `S`, dessen Eigenschaften im Runner an die echten Variablen gebunden sind
//    (`Object.defineProperty` mit get/set). Der Runner behält damit seine Locals — der
//    Frame-Pfad wird NICHT angefasst —, und das Schema liest/schreibt sie trotzdem ctx.live.
//    Der Umweg ist Absicht: 33 Variablen in ein Zustandsobjekt umzuschreiben hätte den
//    Frame-Pfad berührt, und der ist gemessen und läuft.
//
//   settings = createSettingsOverlay({ …, sections: buildSections(ctx) });
//
// **Warum `ctx.x` und keine Destrukturierung:** die läse alles SOFORT, und mehrere Bezüge werden
// im Runner erst NACH dem Panel deklariert (`resize`, `mountPet`, die Eingabe-Schicht). Eager
// gelesen ergibt das einen TDZ-Fehler beim Start — genau so gemessen, bevor es hier stand.
// ============================================================================

export function buildSections(ctx) {
  const S = ctx.S;
  return [
      { id: 'cards', title: 'Karten', hint: 'Der Story-Modus färbt Welt, Himmel und Würfel. Die Ink-Outline gilt vorerst für die Pet-Karte — Sky-Karten bekommen eigene Regler, sobald sie eigene Stile tragen (Torn, Bend).',
        controls: [
          { kind: 'select', label: 'Story-Modus', options: ctx.MODES.map((m) => ({ v: m.key, l: m.n + ' · ' + m.name })),
            get: () => S.story, set: (v) => { S.story = v; ctx.applyWorld(true); } },
          { kind: 'info', label: 'Palette', get: () => S.storyMode.name + '  ·  Ink #' + new ctx.THREE.Color(S.storyMode.ink).getHexString() },
          { kind: 'slider', label: 'Ink-Outline der Pet-Karte', min: 0, max: 18, step: 0.5, get: () => ctx.rig.ink.width,
            set: (v) => ctx.rig.setInk({ width: v }), fmt: (v) => (v === 0 ? 'aus' : v.toFixed(1) + ' px') },
          { kind: 'slider', label: 'Strich-Unruhe', min: 0, max: 1, step: 0.05, get: () => ctx.rig.ink.wobble,
            set: (v) => ctx.rig.setInk({ wobble: v }), fmt: (v) => Math.round(v * 100) + ' %' },
          { kind: 'slider', label: 'Kanten-Zittern', min: 0, max: 14, step: 0.5, get: () => ctx.rig.ink.jitter,
            set: (v) => ctx.rig.setInk({ jitter: v }), fmt: (v) => v.toFixed(1) + ' px' },
        ] },

      { id: 'cards', title: 'Sky-Karten', hint: 'Karten schweben in Zero-G im Himmel und richten sich gedämpft zur Kamera — immer ein guter Lese- und Durchflugwinkel. Durchflug löst sie als Portal auf.',
        controls: [
          { kind: 'toggle', label: 'Karten sichtbar', get: () => ctx.skyCards.params.visible, set: (on) => ctx.skyCards.setVisible(on) },
          { kind: 'slider', label: 'Kartengröße', min: 5, max: 24, step: 0.5, get: () => ctx.skyCards.params.width,
            set: (v) => { ctx.skyCards.setParams({ width: v }); }, fmt: (v) => v.toFixed(1) + ' m' },
          { kind: 'slider', label: 'Abstand (Ring)', min: 60, max: 320, step: 5, get: () => ctx.skyCards.params.ring, set: (v) => ctx.skyCards.setParams({ ring: v }) },
          { kind: 'slider', label: 'Höhenband oben', min: 30, max: 140, step: 2, get: () => ctx.skyCards.params.yMax, set: (v) => ctx.skyCards.setParams({ yMax: v }) },
          { kind: 'slider', label: 'Zero-G-Drift', min: 0, max: 8, step: 0.2, get: () => ctx.skyCards.params.driftAmp, set: (v) => ctx.skyCards.setParams({ driftAmp: v }) },
          { kind: 'slider', label: 'Eigen-Neigung', min: 0, max: 0.7, step: 0.02, get: () => ctx.skyCards.params.tiltAmp, set: (v) => ctx.skyCards.setParams({ tiltAmp: v }) },
          { kind: 'slider', label: 'Ausrichtung folgt (träge → flink)', min: 0.2, max: 4, step: 0.1, get: () => ctx.skyCards.params.faceDamp, set: (v) => ctx.skyCards.setParams({ faceDamp: v }) },
          { kind: 'slider', label: 'Trefferfenster', min: 0.5, max: 1.6, step: 0.05, get: () => ctx.skyCards.params.passRadius, set: (v) => ctx.skyCards.setParams({ passRadius: v }) },
          { kind: 'info', label: 'Gesammelt', get: () => ctx.skyCards.collected + ' Karten' + (S.lastPass ? '  ·  zuletzt: ' + S.lastPass.title : '') },
          { kind: 'toggle', label: 'Echtes Artwork laden', get: () => S.artOn, set: (on) => { S.artOn = on; if (!on) ctx.cardReg.clearQueue(); } },
          { kind: 'info', label: 'Artwork', get: () => (ctx.cardReg.decks.length ? ctx.cardReg.decks.length + ' Decks  ·  ' + (ctx.cardReg.pending ? ctx.cardReg.pending + ' in Arbeit' : 'geladen') : 'Textkarten (Registry nicht erreichbar)') },
        ] },
      { id: 'cards', title: 'Academy', hint: 'Die Würfelakademie als Ort: 31 Karten in fünf Farbzonen (Kapitel = Story-Modus), Höhe = Schwierigkeit. Doppelklick auf eine Karte fliegt sie an — die Anflugzeit ist ein Regler, weil Erzählung und Karaoke später daran hängen. Ist eine Karte im Zugriff, läuft ihre Demo direkt auf dem Blatt (Render-to-Texture, kein Overlay); Ziehen im Fenster bedient sie.',
        controls: [
          { kind: 'toggle', label: 'Akademie im Himmel', get: () => S.academyOn, set: (on) => {
            S.academyOn = on; ctx.academy.setVisible(on); ctx.skyCards.setVisible(!on);
            if (!on) { ctx.live.release(); if (S.shownLive) { ctx.academy.clearLive(S.shownLive); S.shownLive = null; } ctx.auto.cancel(); }
          } },
          { kind: 'info', label: 'Fortschritt', get: () => ctx.academy.visited + ' von ' + ctx.academy.total + ' besucht'
            + (S.lastLesson ? '  ·  zuletzt: ' + S.lastLesson.title : '') },
          { kind: 'slider', label: 'Anflugzeit', min: 2, max: 24, step: 0.5, get: () => S.flyTime,
            set: (v) => { S.flyTime = v; ctx.auto.setParams({ seconds: v }); }, fmt: (v) => v.toFixed(1) + ' s' },
          { kind: 'button', label: 'Lektion suchen (oder Tacho anklicken)', onClick: () => ctx.search.open() },
          { kind: 'button', label: 'Route abfliegen (leicht → schwer)', onClick: () => ctx.flyRoute() },
          { kind: 'toggle', label: 'Nach Ankunft landen (Detailansicht)', get: () => S.dockOnArrive,
            set: (on) => { S.dockOnArrive = on; if (!on && ctx.dock.owns) ctx.dock.release(); } },
          { kind: 'slider', label: 'Randabstand in der Detailansicht', min: 1, max: 1.5, step: 0.02,
            get: () => ctx.dock.params.pad, set: (v) => ctx.dock.setParams({ pad: v }), fmt: (v) => v.toFixed(2) + '×' },
          { kind: 'button', label: 'Detailansicht verlassen', onClick: () => ctx.dock.release() },
          { kind: 'toggle', label: 'Nach Ankunft kreisen', get: () => ctx.auto.params.loiter,
            set: (on) => ctx.auto.setParams({ loiter: on }) },
          { kind: 'slider', label: 'Kreis-Radius', min: 12, max: 40, step: 1, get: () => ctx.auto.params.loiterRadius,
            set: (v) => ctx.auto.setParams({ loiterRadius: v }), fmt: (v) => Math.round(v) + ' u' },
          { kind: 'button', label: 'Anflug abbrechen (Steuerung zurück)', onClick: () => { ctx.auto.cancel(); ctx.note('Steuerung zurück bei dir.'); } },
          { kind: 'info', label: 'Pilot', get: () => {
            const s = ctx.auto.status;
            if (s.mode === 'off') return 'Hand  ·  Doppelklick auf eine Karte = Anflug';
            if (s.mode === 'dwell') return 'kreist · wartet an der Karte  ·  ' + s.queued + ' in der Route';
            if (s.mode === 'loiter') return 'kreist um die Karte  ·  jede Steuereingabe übernimmt';
            if (s.mode === 'hand') return 'Übergabe …';
            return 'Anflug  ·  ' + Math.round(s.dist) + ' u  ·  ETA ' + s.eta.toFixed(1) + ' s  ·  nötig '
              + Math.round(s.need) + ' / ' + Math.round(s.max) + ' u/s' + (s.feasible ? '' : '  ·  NICHT ERFÜLLBAR');
          } },
          { kind: 'toggle', label: 'Kartentitel (Irish Grover, extrudiert)', get: () => S.titleOn,
            set: (on) => { S.titleOn = on; ctx.attachTitle(ctx.academy.focused); } },
          { kind: 'toggle', label: 'Titel-Sublines (2 Zeilen)', get: () => S.titleSubOn,
            set: (on) => { S.titleSubOn = on; ctx.attachTitle(ctx.academy.focused); } },
          { kind: 'slider', label: 'Titel-Tiefe', min: 1, max: 14, step: 1, get: () => ctx.cardTitle.params.layers,
            set: (v) => ctx.cardTitle.setParams({ layers: Math.round(v) }), fmt: (v) => Math.round(v) + ' Ebenen' },
          { kind: 'slider', label: 'Titel-Schweben', min: 0, max: 0.4, step: 0.02, get: () => ctx.cardTitle.params.float,
            set: (v) => ctx.cardTitle.setParams({ float: v }), fmt: (v) => v.toFixed(2) + ' u' },
          { kind: 'toggle', label: 'Voxel-Glyph-Titel (alt)', get: () => S.glyphsOn, set: (on) => {
            S.glyphsOn = on;
            if (!on) ctx.attachGlyphs(null); else ctx.attachGlyphs(ctx.academy.focused);
          } },
          { kind: 'slider', label: 'Glyph-Würfelgröße', min: 0.12, max: 0.4, step: 0.01, get: () => S.glyphCube,
            set: (v) => { S.glyphCube = v; const c = S.glyphCard; S.glyphCard = null; ctx.attachGlyphs(c); },
            fmt: (v) => v.toFixed(2) + '  ·  Terrain = 1,0' },
          { kind: 'info', label: 'Titel', get: () => (ctx.glyphs.text ? ctx.glyphs.text + '  ·  ' + ctx.glyphs.live + ' Würfel' : 'keiner') },
          { kind: 'toggle', label: 'Live-Demo auf dem Blatt', get: () => ctx.live.enabled, set: (on) => {
            ctx.live.setEnabled(on);
            if (!on && S.shownLive) { ctx.academy.clearLive(S.shownLive); S.shownLive = null; }
          } },
          { kind: 'toggle', label: 'Vorschaubilder von threejs.org', get: () => ctx.academy.params.previews,
            set: (on) => ctx.academy.setPreviews(on) },
          { kind: 'info', label: 'Vorschau', get: () => {
            const s = ctx.academy.previewStats;
            return s.ok + ' geladen' + (s.fail ? '  ·  ' + s.fail + ' ohne Bild' : '') + (s.busy ? '  ·  lädt …' : '');
          } },
          { kind: 'slider', label: 'Live-Auflösung', min: 320, max: 1024, step: 64, get: () => ctx.live.params.size,
            set: (v) => { if (S.shownLive) { ctx.academy.clearLive(S.shownLive); S.shownLive = null; } ctx.live.setSize(v); }, fmt: (v) => Math.round(v) + ' px' },
          { kind: 'info', label: 'Live', get: () => (ctx.live.live
            ? ctx.live.example + '  ·  ' + Math.round(ctx.live.stats.fps) + ' fps  ·  ' + ctx.live.stats.calls + ' Calls  ·  ' + ctx.live.stats.size
            : (ctx.live.enabled ? 'keine Karte im Zugriff (näher ran)' : 'aus')) },
          // Diese beiden Regler zeigten nach dem Zonen-Stern (S43) auf Parameter, die es nicht mehr
          // gibt: `ring` war wirkungslos, `yTop` druckte NaN. Ein Regler ohne Zahl dahinter ist
          // dieselbe Fehlerklasse wie eine Zahl an zwei Orten — nur in der Gegenrichtung.
          // Zonen-Abstand und -Größe stehen jetzt im Abschnitt „Reise" (dort, wo Warp wohnt).
          { kind: 'slider', label: 'Höhe: erste Lektion', min: 20, max: 90, step: 2, get: () => ctx.academy.params.yBase,
            set: (v) => ctx.academy.setParams({ yBase: v }), fmt: (v) => Math.round(v) + ' u' },
          { kind: 'slider', label: 'Höhen-Anstieg über das Kapitel', min: 0, max: 70, step: 2, get: () => ctx.academy.params.yRise,
            set: (v) => ctx.academy.setParams({ yRise: v }), fmt: (v) => (v === 0 ? 'flach' : '+' + Math.round(v) + ' u bis zur letzten') },
          { kind: 'slider', label: 'Bogen einer Zone', min: 0.4, max: 3.4, step: 0.1, get: () => ctx.academy.params.zoneTurn,
            set: (v) => ctx.academy.setParams({ zoneTurn: v }), fmt: (v) => Math.round(v * 57) + '°' },
          { kind: 'slider', label: 'Zugriff ab Abstand', min: 20, max: 90, step: 2, get: () => ctx.academy.params.focusDist,
            set: (v) => ctx.academy.setParams({ focusDist: v }), fmt: (v) => Math.round(v) + ' u' },
          { kind: 'button', label: 'Akademie hier neu ankern', onClick: () => {
            const p = !ctx.isWalk() ? ctx.flight.state.position : ctx.walk.state.position;
            ctx.academy.setCenter(p.x, p.z); ctx.note('Akademie neu geankert.');
          } },
          { kind: 'button', label: 'Fortschritt zurücksetzen', onClick: () => { ctx.academy.resetProgress(); ctx.note('Alle Stempel weg.'); } },
          { kind: 'info', label: 'Blätter', get: () => (ctx.academy.pending ? ctx.academy.pending + ' werden noch gemalt' : 'alle gemalt') },
        ] },

      { id: 'music', title: 'Klang & Rhythmus', hint: 'Der Takt treibt Cube-Tanz und Blinken. Ton startet erst mit einem Klick — Browser lassen Audio nicht von allein an.',
        controls: [
          { kind: 'toggle', label: 'Ton an', get: () => S.soundOn, set: (on) => {
            S.soundOn = on;
            if (on) { ctx.audio.start(); ctx.audio.setEnabled(true); } else ctx.audio.setEnabled(false);
          } },
          { kind: 'select', label: 'Track',
            options: () => (ctx.audio.tracks.length ? ctx.audio.tracks.map((t) => ({ v: t.file, l: t.title + (t.bpm ? '  ·  ' + t.bpm + ' BPM' : '') })) : [{ v: '', l: 'lädt …' }]),
            get: () => ctx.audio.track || '', set: (v) => ctx.audio.setTrack(v) },
          { kind: 'slider', label: 'Musik', min: 0, max: 0.6, step: 0.02, get: () => ctx.audio.params.music,
            set: (v) => ctx.audio.setMusicVol(v), fmt: (v) => (v <= 0 ? 'aus' : Math.round(v * 100 / 0.6) + ' %') },
          { kind: 'slider', label: 'Drone', min: 0, max: 2, step: 0.05, get: () => ctx.audio.params.drone, set: (v) => ctx.audio.setDroneVol(v) },
          { kind: 'slider', label: 'Fahrtwind', min: 0, max: 2, step: 0.05, get: () => ctx.audio.params.wind, set: (v) => ctx.audio.setWindVol(v) },
          { kind: 'slider', label: 'Rumpeln (Bodennähe)', min: 0, max: 2, step: 0.05, get: () => ctx.audio.params.rumble, set: (v) => ctx.audio.setRumbleVol(v) },
          { kind: 'slider', label: 'Böen', min: 0, max: 2, step: 0.05, get: () => ctx.audio.params.gust, set: (v) => ctx.audio.setGustVol(v) },
          { kind: 'slider', label: 'Sample-Trim', min: 0, max: 2, step: 0.05, get: () => ctx.audio.params.sfx, set: (v) => ctx.audio.setSfxVol(v) },
          { kind: 'slider', label: 'Effekte (FX)', min: 0, max: 2, step: 0.05, get: () => ctx.audio.params.fx, set: (v) => ctx.audio.setFxVol(v) },
          { kind: 'slider', label: 'Tempo (ohne Ton)', min: 60, max: 170, step: 1, get: () => S.bpm,
            set: (v) => { S.bpm = v; ctx.audio.setBpm(v); }, fmt: (v) => Math.round(v) + ' BPM' },
          { kind: 'slider', label: 'Beat-Kopplung', min: 0, max: 2, step: 0.05, get: () => S.beatGain, set: (v) => { S.beatGain = v; } },
          { kind: 'info', label: 'Takt', get: () => (ctx.audio.running
            ? Math.round(ctx.audio.bpm) + ' BPM aus dem Track  ·  Puls ' + Math.round(ctx.audio.pulse * 100) + ' %'
            : (ctx.audio.ready ? 'Ton aus (' + ctx.audio.state + ') — synthetisch ' + Math.round(S.bpm) + ' BPM'
                           : 'synthetisch (' + Math.round(S.bpm) + ' BPM)')) },
          { kind: 'select', label: 'Cube-Tanz koppeln an', options: [
            { v: 'both', l: 'Musik + Tempo' }, { v: 'beat', l: 'nur Musik (Dancefloor)' },
            { v: 'speed', l: 'nur Reisetempo' }, { v: 'steady', l: 'gleichmäßig (Flow ohne Musik)' },
            { v: 'off', l: 'aus — Cubes stehen still' },
          ], get: () => S.danceMode, set: (v) => { S.danceMode = v; } },
          { kind: 'select', label: 'Cube-Blinken koppeln an', options: [
            { v: 'both', l: 'Musik + Tempo' }, { v: 'beat', l: 'nur Musik (Dancefloor)' },
            { v: 'speed', l: 'nur Reisetempo' }, { v: 'steady', l: 'gleichmäßig' },
            { v: 'off', l: 'aus — kein Leuchten' },
          ], get: () => S.blinkMode, set: (v) => { S.blinkMode = v; } },
          { kind: 'slider', label: 'Blink-Stärke', min: 0, max: 2.5, step: 0.05, get: () => S.blinkGain, set: (v) => { S.blinkGain = v; } },
          { kind: 'slider', label: 'Flow statt Dancefloor', min: 0, max: 1, step: 0.05, get: () => ctx.terrain.flow,
            set: (v) => ctx.terrain.setFlow(v),
            fmt: (v) => (v <= 0 ? 'Dancefloor' : v >= 1 ? 'Flow' : Math.round(v * 100) + ' % Flow') },
        ] },

      { id: 'travel', title: 'Reise',
        controls: [
          { kind: 'toggle', label: 'Boden-Modus (F)', get: () => ctx.isWalk(), set: (on) => ctx.requestMode(on ? 'walk' : 'fly', 'hand') },
          { kind: 'toggle', label: 'Modus folgt der Höhe', get: () => S.autoMode, set: (on) => { S.autoMode = on; } },
          { kind: 'slider', label: 'Warp-Faktor', min: 0, max: 5, step: 0.1, get: () => ctx.flight.params.warpGain,
            set: (v) => ctx.flight.setParams({ warpGain: v }),
            fmt: (v) => (v === 0 ? 'aus' : 'bis ' + Math.round(ctx.flight.params.SPD_MAX * (1 + v)) + ' u/s  ·  ⇧+Leertaste') },
          { kind: 'info', label: 'Warp jetzt', get: () => {
            const s = ctx.flight.state;
            return (s.warp > 0.01 ? Math.round(s.warp * 100) + ' %  ·  ' + Math.round(s.speed) + ' u/s'
              + (s.warpOver > 0.02 ? '  ·  +' + Math.round(s.warpOver * 100) + ' % über der Grenze' : '') : 'aus');
          } },
          { kind: 'slider', label: 'Zonen-Abstand (Akademie)', min: 120, max: 420, step: 10, get: () => ctx.academy.params.zoneR,
            set: (v) => ctx.academy.setParams({ zoneR: v }), fmt: (v) => Math.round(v) + ' u vom Start' },
          { kind: 'slider', label: 'Zonen-Größe', min: 40, max: 160, step: 5, get: () => ctx.academy.params.zoneSpan,
            set: (v) => ctx.academy.setParams({ zoneSpan: v }), fmt: (v) => Math.round(v) + ' u Radius' },
          { kind: 'slider', label: 'Höchsttempo Flug', min: 18, max: 90, step: 1, get: () => ctx.flight.params.SPD_MAX,
            set: (v) => ctx.flight.setParams({ SPD_MAX: v }), fmt: (v) => Math.round(v) + ' u/s' },
          { kind: 'slider', label: 'Lauftempo', min: 2, max: 12, step: 0.2, get: () => ctx.walk.params.speed,
            set: (v) => ctx.walk.setParams({ speed: v }), fmt: (v) => v.toFixed(1) + ' u/s' },
          { kind: 'slider', label: 'Kamera-Abstand', min: 0, max: 17, step: 0.5,
            get: () => (ctx.isWalk() ? ctx.walk.state.cam.dist : ctx.camRig.zoomTarget),
            set: (v) => { if (ctx.isWalk()) ctx.walk.zoom(v - ctx.walk.state.cam.dist); else ctx.camRig.setZoom(v); } },
          { kind: 'toggle', label: 'POV (Blick des Pets)',
            get: () => (ctx.isWalk() ? ctx.walk.state.cam.dist <= 1.6 : ctx.camRig.zoomTarget <= 1.6),
            set: (on) => { if (ctx.isWalk()) ctx.walk.zoom((on ? 0 : 9) - ctx.walk.state.cam.dist); else ctx.camRig.setZoom(on ? 0 : 9); } },
          { kind: 'slider', label: 'Tacho-Eichung', min: 0.2, max: 1.5, step: 0.05, get: () => ctx.heat.params.unitMeters,
            set: (v) => ctx.heat.setParams({ unitMeters: v }), fmt: (v) => '1 Unit = ' + v.toFixed(2) + ' m' },
          { kind: 'info', label: 'Aktuell', get: () => Math.round(ctx.heat.kmh) + ' km/h  ·  ctx.heat ' + ctx.heat.value.toFixed(2) },
        ] },

      { id: 'fx', title: 'Boost & FX', hint: 'Alles hier hängt am Regie-Skalar travelHeat — in Ruhe ist es aus, nicht bloss leise. Der Blur ist ein Fullscreen-Pass; bei 0 rendert die Szene direkt (kein Puffer, volles MSAA).',
        controls: [
          { kind: 'toggle', label: 'Speedlines', get: () => ctx.lines.enabled, set: (on) => ctx.lines.setEnabled(on) },
          { kind: 'toggle', label: 'Kartenecken-Streifen', get: () => ctx.trails.active, set: (on) => ctx.trails.setActive(on) },
          { kind: 'slider', label: 'Streifen ab', min: 5, max: 60, step: 1, get: () => ctx.trails.params.kmhOn,
            set: (v) => ctx.trails.setParams({ kmhOn: v }), fmt: (v) => Math.round(v) + ' km/h' },
          { kind: 'slider', label: 'Eckstreifen-Breite', min: 0.02, max: 0.14, step: 0.005, get: () => ctx.trails.params.width,
            set: (v) => ctx.trails.setParams({ width: v }), fmt: (v) => v.toFixed(3) },
          { kind: 'select', label: 'Streifen-Look', options: [{ v: 'light', l: 'Licht (additiv, Panel-Farbe)' }, { v: 'ink', l: 'Tinte (Story-Farbe)' }],
            get: () => ctx.lines.look, set: (v) => ctx.lines.setLook(v) },
          { kind: 'slider', label: 'Streifen-Dichte', min: 0.2, max: 2.5, step: 0.1, get: () => ctx.lines.params.density,
            set: (v) => ctx.lines.setParams({ density: v }), fmt: (v) => v.toFixed(1) + '×' },
          { kind: 'slider', label: 'Streifen-Deckkraft', min: 0, max: 0.6, step: 0.02, get: () => ctx.lines.params.opacity,
            set: (v) => ctx.lines.setParams({ opacity: v }) },
          { kind: 'slider', label: 'Radial-Blur', min: 0, max: 2, step: 0.05, get: () => S.fxBlur,
            set: (v) => { S.fxBlur = v; }, fmt: (v) => (v === 0 ? 'aus' : v.toFixed(2) + '×') },
          { kind: 'toggle', label: 'Barrel-Roll beim Boost', get: () => ctx.petKin.barrelRoll.on, set: (on) => ctx.petKin.setBarrelRoll(on) },
          { kind: 'slider', label: 'Lenken im Boost', min: 1, max: 1.8, step: 0.02, get: () => ctx.flight.params.boostYawGain,
            set: (v) => ctx.flight.setParams({ boostYawGain: v }), fmt: (v) => v.toFixed(2) + '×' },
          { kind: 'info', label: 'Live', get: () => 'Streifen ' + ctx.lines.liveCount + '  ·  Blur ' + ctx.post.strength.toFixed(3) },
        ] },

      { id: 'world', title: 'Welt', hint: 'Alles hier baut das Terrain neu — die Änderung greift kurz nach dem Loslassen.',
        controls: [
          { kind: 'slider', label: 'Rauheit', min: 0, max: 1, step: 0.02, get: () => ctx.tp('terrainRoughness', 0.6), set: (v) => ctx.setTp('terrainRoughness', v) },
          { kind: 'slider', label: 'Höhenskala', min: 4, max: 40, step: 0.5, get: () => ctx.tp('heightScale', 16), set: (v) => ctx.setTp('heightScale', v) },
          { kind: 'slider', label: 'Wasserlinie', min: -12, max: 12, step: 0.5, get: () => ctx.tp('waterLevel', 0), set: (v) => ctx.setTp('waterLevel', v) },
          { kind: 'slider', label: 'Farbversatz', min: 0, max: 1, step: 0.02, get: () => ctx.tp('colorShift', 0.5), set: (v) => ctx.setTp('colorShift', v) },
          { kind: 'slider', label: 'Cube-Tanz', min: 0, max: 1, step: 0.02, get: () => ctx.tp('motionAmplitude', 0.35), set: (v) => ctx.setTp('motionAmplitude', v) },
          { kind: 'slider', label: 'Ruhezone am Boden', min: 0, max: 1, step: 0.05, get: () => S.groundCalm,
            set: (v) => { S.groundCalm = v; }, fmt: (v) => (v === 0 ? 'aus' : Math.round(v * 100) + ' %') },
          { kind: 'info', label: 'Zone unter der Karte', get: () => (ctx.isWalk() ? 'Walk: Läufer-Zone' : Math.round(S.calmAmt * 100) + ' % ruhig') },
          { kind: 'slider', label: 'Bodenschatten', min: 0, max: 1.6, step: 0.05, get: () => S.shadowGain,
            set: (v) => { S.shadowGain = v; ctx.terrain.setCasterGain(v); }, fmt: (v) => (v === 0 ? 'aus' : Math.round(v * 100) + ' %') },
        ] },

      { id: 'sky', title: 'Himmel',
        controls: [
          { kind: 'select', label: 'Variante', options: [
            { v: 'S', l: 'Sphäre (Default)' }, { v: 'A', l: 'Waber-Noise' }, { v: 'space', l: 'Space' },
            { v: 'watercolor', l: 'Aquarell' }, { v: 'watercolor2', l: 'Aquarell II' }, { v: 'starfield', l: 'Sternenfeld' },
            { v: 'night', l: 'Nacht' }, { v: 'morning', l: 'Morgen' }, { v: 'day', l: 'Tag' }, { v: 'alien', l: 'Alien' },
          ], get: () => ctx.sky.getVariant(), set: (v) => { ctx.sky.setVariant(v); ctx.lighting.bakeEnvironment(ctx.sky.group); } },
          { kind: 'slider', label: 'Welt-Mischung', min: 0, max: 1, step: 0.02, get: () => S.skyWorldMix, set: (v) => { S.skyWorldMix = v; ctx.sky.setWorldMix(v); } },
          { kind: 'slider', label: 'Belichtung', min: 0.4, max: 1.8, step: 0.05, get: () => S.skyExposure, set: (v) => { S.skyExposure = v; ctx.sky.setExposure(v); } },
          { kind: 'toggle', label: 'Hypno-Spirale', get: () => S.skySpiral, set: (on) => { S.skySpiral = on; ctx.sky.setSpiral(on); } },
        ] },

      { id: 'S.pet', title: 'Pet', hint: 'Alle Pets aus dem kanonischen Vertrag. Der Wechsel räumt das alte Pet ab (ein Augenpaar).',
        controls: [
          { kind: 'select', label: 'Blickrichtung', options: [
            { v: 'auto', l: 'Auto (Stand → zu dir, Tempo → Fahrtrichtung)' },
            { v: 'player', l: 'Player (immer zu dir)' },
            { v: 'track', l: 'Track (immer Fahrtrichtung)' },
          ], get: () => ctx.petFace.mode, set: (v) => ctx.petFace.setMode(v) },
          { kind: 'toggle', label: 'Augen folgen dem Cursor/der Kamera', get: () => ctx.petFace.params.eyeTrack,
            set: (on) => ctx.petFace.setParams({ eyeTrack: on }) },
          { kind: 'info', label: 'Blick', get: () => Math.round(ctx.petFace.blend * 100) + ' % zu dir  ·  '
            + Math.round(ctx.petFace.yaw * 180 / Math.PI) + '°' },
          { kind: 'slider', label: 'Tempo-Kopplung (Blick)', min: 0.5, max: 3, step: 0.1, get: () => ctx.petFace.params.speedGain,
            set: (v) => ctx.petFace.setParams({ speedGain: v }), fmt: (v) => v.toFixed(1) + '×' },
          { kind: 'select', label: 'Cube-Pet',
            options: () => ((S.petLib && S.petLib.pets) || []).map((p) => ({ v: p.id, l: p.name || p.id })),
            get: () => S.petId, set: (v) => ctx.mountPet(v) },
          { kind: 'info', label: 'Geladen', get: () => (S.pet ? (S.pet.name || S.petId) : '…') },
          { kind: 'slider', label: 'Himmels-Licht', min: 0, max: 2, step: 0.05, get: () => ctx.lighting.params.env,
            set: (v) => ctx.lighting.setEnv(v), fmt: (v) => (v === 0 ? 'aus' : v.toFixed(2) + '×') },
          { kind: 'slider', label: 'Fill-Licht (Gegenlicht)', min: 0, max: 1.5, step: 0.05, get: () => ctx.lighting.params.fill,
            set: (v) => ctx.lighting.setFill(v) },
          { kind: 'slider', label: 'Story-Tint', min: 0, max: 0.5, step: 0.01, get: () => ctx.lighting.tintAmount,
            set: (v) => ctx.lighting.setTint(null, v), fmt: (v) => (v === 0 ? 'aus' : Math.round(v * 100) + ' %') },
        ] },

      { id: 'controls', title: 'Steuerung', wide: true, hint: 'Beide Travel-Modi in einer Tabelle — dafür ist die Legende aus dem Bild verschwunden.',
        controls: [{ kind: 'keys', rows: [
          ['Leertaste ×2', 'Boden: ABHEBEN (verlängerter Sprung)'], ['X', 'HART BREMSEN (auch der Anflug bremst so)'], ['⇧ + Leertaste', 'WARP — über die Reisegrenze hinaus'], ['↓', 'sinken — am Boden wird gelandet'],
          ['W / S', 'Flug: Schub · langsamer'], ['W / S', 'Boden: laufen · rückwärts'],
          ['A / D', 'lenken (Flug) · drehen (Boden)'], ['Q / E', 'Boden: seitwärts'],
          ['↑ / ↓', 'Flug: steigen · sinken'], ['Shift', 'Boden: rennen'],
          ['Leertaste', 'Flug: Boost'], ['Leertaste', 'Boden: Sprung'],
          ['J', 'Flug: Pet hüpft'], ['F', 'Fly ⇄ Walk (direkt)'],
          ['Tab', 'Einstellungen'], ['Esc', 'Einstellungen schließen'],
          ['Ziehen', 'lenken (Flug) · umsehen (Boden)'], ['Rad / Pinch', 'Zoom bis POV'],
          ['Doppelklick auf Karte', 'Academy: Anflug (Auto-Pilot)'], ['R', 'Academy: Route abfliegen'],
          ['Tacho anklicken', 'Lektion suchen (Live-Suche über 31 Lektionen)'], ['Enter / Doppelklick', 'Suche: Treffer anfliegen'],
          ['Ziehen im Kartenfenster', 'Academy: die Live-Demo bedienen'], ['Steuern', 'bricht den Anflug ab'],
          ['Würfel unten rechts', 'drehen → Seite klicken → Sektion'],
        ] }] },

      { id: 'system', title: 'System', wide: true, hint: 'Selten gebraucht, deshalb unten.',
        controls: [
          { kind: 'text', label: 'Welt-Seed', get: () => S.worldSeed, set: (v) => { S.worldSeed = v || ctx.WORLD_SEED; ctx.applyWorld(true); } },
          { kind: 'button', label: 'Seed neu würfeln', onClick: () => { S.worldSeed = 'kfb-' + Math.random().toString(36).slice(2, 9); ctx.applyWorld(true); } },
          { kind: 'slider', label: 'Auflösung', min: 0.6, max: 2, step: 0.1, get: () => S.quality, set: (v) => {
            S.quality = v; ctx.renderer.setPixelRatio(v); ctx.resize();
          }, fmt: (v) => v.toFixed(1) + '×' },
          { kind: 'button', label: 'Alles zurücksetzen', onClick: () => {
            S.story = ctx.STORY; S.worldSeed = ctx.WORLD_SEED; ctx.applyWorld(true);
            ctx.flight.setParams({ SPD_MAX: 42 }); ctx.walk.setParams({ speed: 5.4 });
            ctx.heat.setParams({ unitMeters: 0.5 }); ctx.heat.reset(ctx.curMode());
            S.fxBlur = 1; ctx.lines.setEnabled(true); ctx.lines.setParams({ density: 1, opacity: 0.32, look: 'light' });
            ctx.trails.setActive(true); ctx.trails.setParams({ kmhOn: 20, width: 0.055 });
            ctx.petKin.setBarrelRoll(true); ctx.flight.setParams({ boostYawGain: 1.28 });
            S.bpm = 104; S.beatGain = 1; ctx.camRig.setZoom(9);
            S.danceMode = 'both'; S.blinkMode = 'both'; S.blinkGain = 1; S.groundCalm = 0.9;
            ctx.terrain.setFlow(0); S.shadowGain = 1;
            ctx.lighting.setEnv(1); ctx.lighting.setFill(0.55); ctx.lighting.setTint(S.storyMode.ink, 0.18);
            ctx.rig.setInk({ width: 6, wobble: 0.5, jitter: 4 });
            ctx.sky.setVariant('S'); ctx.sky.setWorldMix(0.4); ctx.sky.setExposure(1); ctx.sky.setSpiral(false);
            S.skyWorldMix = 0.4; S.skyExposure = 1; S.skySpiral = false;
            if (ctx.isWalk()) ctx.requestMode('fly', 'S.story');
          } },
        ] },
  ];
}

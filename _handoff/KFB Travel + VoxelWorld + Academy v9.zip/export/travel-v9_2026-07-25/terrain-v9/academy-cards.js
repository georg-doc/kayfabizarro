// ============================================================================
// academy-cards.js — KFB Travel · Slice S31/S32a · Die Akademie im Himmel
// ----------------------------------------------------------------------------
// 31 Karten (5 Kapitel × 6 Lektionen + Meta-Hub) hängen als FESTER ORT im
// Himmel — nicht als Strom. Das ist der Unterschied zu `sky-cards.js`: dort ist
// eine Karte ein Ereignis, das erscheint, durchflogen wird und sich auflöst;
// hier ist eine Karte ein ZIEL, das bleibt. Eine Lektion, die sich beim
// Durchflug auflöst, wäre Unsinn — also kein Respawn, kein Portal, ein Stempel.
//
// ÜBERNOMMEN aus sky-cards.js (bewährte Mathematik, nicht neu erfunden):
//  · Zero-G aus drei inkommensurablen Sinus-Termen pro Achse (√2, √3, √5,
//    goldener Schnitt) — die Summe hat keine gemeinsame Periode.
//  · Ausrichtung zur Kamera per GEDÄMPFTEM Slerp plus Eigen-Neigung obendrauf.
//  · Durchflug = Vorzeichenwechsel des Abstands zur Kartenebene, gültig nur
//    innerhalb der halben Kantenlängen. Kein Solver.
//
// S32a — **DIE KARTENFLÄCHE IST EIN STECKPLATZ.** Zwei Quads in Kartengröße:
//   surface  = was zu sehen ist, VOLLFLÄCHIG, ausgestanzt per Silhouetten-`alphaMap`
//   decal    = nur die kanonische Tuschelinie (+ Stempel), sonst transparent
// Der Steckplatz nimmt vier Sprossen derselben Leiter — **Zonenfarbe → Zonenfeld →
// three.js-Vorschaubild → LIVE-Render-Textur** — und morgen ohne neuen Mechanismus
// auch ein Video oder die Chat-UI. Deshalb heißt er `setSurface`, nicht `setLive`.
//
// Zonen: Kapitel c belegt einen 72°-Sektor um den Anker, die Lektion bestimmt die
// HÖHE (leicht tief, schwer hoch) — der Schwierigkeitsgrad ist ein Steigflug und
// keine Zahl auf dem Blatt.
// ============================================================================

import { academyDeck, fieldTexture, maskTexture, decalTexture, postitTexture, previewURL,
         seedFor, SHEET_AR, CHAPTERS, HUB } from './academy-deck.js';
import { MODES } from './world-context.js';

const PAPER = '#efe6d0', CREAM = '#f7f0dd';

// Zonen-Platzhalter: die erste Sprosse. Sechs Texturen für 31 Karten — aus der Distanz
// ist eine Zone ohnehin ihre FARBE, nicht ihre Schrift.
function zoneTexture(THREE, ink, nr) {
  const W = 128, H = Math.round(W / SHEET_AR);
  const c = document.createElement('canvas'); c.width = W; c.height = H;
  const g = c.getContext('2d');
  g.fillStyle = '#' + ink.toString(16).padStart(6, '0'); g.fillRect(0, 0, W, H);
  g.fillStyle = 'rgba(247,240,221,.3)'; g.textAlign = 'center'; g.textBaseline = 'middle';
  g.font = '700 ' + Math.round(H * 0.6) + 'px "Irish Grover", Georgia, serif';
  g.fillText(nr, W / 2, H / 2);
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 2;
  return t;
}

export function createAcademyCards(opts = {}) {
  const THREE = opts.THREE;
  const P = Object.assign({
    width: 13,
    // Verteilung: die Zone bleibt ein Sektor (die Farbe ist die Orientierung), aber die sechs
    // Lektionen füllen ihn jetzt fast ganz aus UND liegen in verschiedenen TIEFEN. Vorher saßen
    // sie in einem 54°-Bogen auf einer Schale: man musste sich drehen, bis ein zu dichter Cluster
    // im Bild war (Georgs Befund). Mit gestaffelten Radien ist in jeder Blickrichtung etwas nah
    // und etwas fern — Tiefe statt Wand.
    // **S43 · Sternförmige Zonen um den STARTPUNKT.** Die vorige Fassung streute alle 31 Karten in
    // EINEN Ring um den Spieler und zog ihn an einer Leine mit — dadurch war die Akademie überall
    // und nirgends, und in jeder Blickrichtung lag ein Klumpen (Georgs Befund, dreimal).
    // Jetzt ist jedes Kapitel ein ORT: fünf Zonen im 72°-Stern um den Nullpunkt, jede mit eigener
    // Kreisfläche, und die Lektionen liegen darin in Reihenfolge auf einem sanften Bogen nach
    // außen — man reist ein Kapitel ab und hat die nächste Lektion im Blickfeld.
    zoneR: 250,          // u vom Startpunkt zur Zonenmitte (Warp macht das erreichbar)
    zoneSpan: 92,        // u Radius der Kreisfläche einer Zone
    zoneTurn: 2.1,       // rad Gesamtdrehung des Bogens innerhalb der Zone
    zoneInner: 0.18,     // wo der Bogen anfängt (0 = Zonenmitte)
    stepJitter: 0.16,    // wie frei die Lektionen im Bogen sitzen (deterministisch)
    hubR: 0,             // der Hub sitzt im Stern-Mittelpunkt: der Startpunkt IST die Aula
    // Höhe steigt innerhalb eines Kapitels: eine Reise, die aufsteigt.
    yBase: 30, yRise: 34, yZone: 7,
    // `ring`/`rNear`/`rFar`/`spread`/`ySpread` sind mit dem Zonen-Stern (S43) ENTFALLEN — sie
    // standen noch hier und im Panel, ohne dass `place()` sie liest. Gemessen: Verschiebung einer
    // Karte 0,00 u bei jeder Änderung. Ein Parameter, den niemand liest, ist eine Lüge im Kopf.
    // Höhenband relativ zur FLUGHÖHE, nicht absolut: bei Start auf 9 u lagen sonst alle 31 Karten
    // über dem Spieler (Georgs Screenshot). Die Mitte folgt der Flughöhe weich nach.
    yMin: 24, yMax: 96,
    // **Die Leine.** Die Akademie ist ein Ort — aber ein Ort, der den Spieler UMSCHLIESST.
    // Erste Fassung hatte `leash` 112 bei `ring` 100: damit hing der Spieler im Reiseflug genau
    // am Ringrand, und ein Ring, dessen Mittelpunkt 112 u entfernt liegt, liegt zwangsläufig
    // komplett in EINER Richtung. Gemessen: alle 31 Karten in einem Bogen von 145°, größte
    // Lücke 215°, vier von acht Oktanten leer — genau Georgs „ich muss mich um 180° drehen".
    // Die Leine muss also DEUTLICH INNERHALB des Rings liegen: ~0,3 · ring.
    // **Die Leine ist AUS** (`leash: 0`). Sie war die falsche Antwort auf „ich finde die Karten
    // nicht": eine mitwandernde Akademie ist kein Ort, und der Anflug musste sie extra stillstellen.
    // Ein Ort bleibt liegen; erreichbar wird er durch Tempo (Warp), nicht durch Nachlaufen.
    leash: 0,
    // Nachziehen mit BEGRENZTER Rate: sonst springt der Anker (und mit ihm alle 31 Karten)
    // um den ganzen Überschuss, sobald das Folgen wieder eingeschaltet wird.
    pullRate: 26,
    // **Und die Leine steht still, solange ein Anflug läuft.** Sonst flieht die Zielkarte genau
    // mit dem Überschuss der eigenen Bewegung — ein Laufband, auf dem man die Karte endlos jagt
    // (gemessen: ETA 0,0 s, „Zeit nicht erfüllbar“, 76 km/h, Abstand konstant).
    followOn: true,
    sector: 72,
    faceDamp: 0.9,
    driftAmp: 2.2,
    tiltAmp: 0.18,
    passRadius: 1.0,
    focusDist: 46,
    visible: true,
    sheetW: 512,
    previews: true,
  }, opts.params || {});

  const group = new THREE.Group();
  group.frustumCulled = false;
  const cards = [];
  const api = { onPass: null, onFocus: null, onPreview: null };
  let cx = 0, cz = 0, T = 0, visited = 0, focused = null;
  const chapterCount = {};   // Kapitel → Anzahl Lektionen (füllt sich beim Bauen)
  let cy = 34;   // Mitte des Höhenbands (folgt der Flughöhe)
  let sheetQ = [], prevBusy = false, prevDone = 0, prevFail = 0;

  const zoneTex = [];
  CHAPTERS.forEach((ch, i) => {
    const m = MODES.find((x) => x.key === ch.mode) || MODES[3];
    zoneTex[i] = zoneTexture(THREE, m.ink, ch.nr);
  });
  {
    const m = MODES.find((x) => x.key === HUB.mode) || MODES[5];
    zoneTex[5] = zoneTexture(THREE, m.ink, HUB.nr);
  }
  // Vier Kanten-Seeds, geteilt: Maske stanzt aus, Decal trägt die Linie.
  const SEEDS = [7, 23, 41, 59];
  const maskTex = SEEDS.map((s) => maskTexture(THREE, s, 512));
  const decalTex = SEEDS.map((s) => decalTexture(THREE, s, 1024));
  const loader = new THREE.TextureLoader();
  loader.setCrossOrigin('anonymous');   // ohne CORS kein WebGL-Upload → sonst stille Ausfälle

  const _v = new THREE.Vector3(), _n = new THREE.Vector3(), _to = new THREE.Vector3();
  const _q = new THREE.Quaternion(), _m = new THREE.Matrix4();
  const _up = new THREE.Vector3(0, 1, 0), _right = new THREE.Vector3(), _look = new THREE.Vector3();
  const _tiltQ = new THREE.Quaternion(), _tiltE = new THREE.Euler();

  const w = P.width, h = w / SHEET_AR;

  function place(card) {
    const d = card.data;
    if (d.kind === 'hub') {
      card.home.set(cx, P.yBase + P.yRise * 0.35, cz - P.hubR);
      return;
    }
    // Zonenmitte: fünf Sektoren im Stern. 18° Versatz, damit keine Zone genau auf einer Achse liegt.
    const zdeg = d.chapter * P.sector + 18;
    const za = zdeg * Math.PI / 180;
    const zx = cx + Math.sin(za) * P.zoneR, zz = cz + Math.cos(za) * P.zoneR;
    // Position INNERHALB der Zone: Bogen nach außen, in Lektionsreihenfolge.
    const n = Math.max(1, chapterCount[d.chapter] || 6);
    const t = n > 1 ? d.index / (n - 1) : 0.5;
    // Der Bogen dreht sich mit, statt strahlenförmig zu liegen — und er beginnt zur Sternmitte hin
    // gedreht, damit man beim Anflug aus der Mitte auf die erste Lektion schaut.
    const jit = Math.sin((d.route + 1) * 12.9898) * 0.5 + 0.5;
    const la = za + Math.PI + P.zoneTurn * (t - 0.5) + (jit - 0.5) * P.stepJitter * 2;
    const lr = P.zoneSpan * (P.zoneInner + (1 - P.zoneInner) * (0.35 + 0.65 * t))
             * (1 + (jit - 0.5) * P.stepJitter);
    const y = Math.max(P.yMin, Math.min(P.yMax,
      P.yBase + P.yRise * t + Math.sin(d.chapter * 2.3) * P.yZone + (jit - 0.5) * 6));
    card.home.set(zx + Math.sin(la) * lr, y, zz + Math.cos(la) * lr);
  }

  // Pro Frame: Anker an der Leine nachziehen, Höhenband weich auf die Flughöhe legen.
  // Nur wenn sich wirklich etwas ändert, werden die 31 Heimatpunkte neu gerechnet.
  function follow(dt, player) {
    if (!player || !P.followOn || P.leash <= 0) return false;   // leash 0 = die Akademie liegt fest
    let moved = false;
    const dx = player.x - cx, dz = player.z - cz;
    const d = Math.hypot(dx, dz);
    if (d > P.leash) {
      const step = Math.min(d - P.leash, P.pullRate * dt) / d;
      cx += dx * step; cz += dz * step; moved = true;
    }
    const wantY = Math.max(26, Math.min(62, player.y + 8));
    if (Math.abs(wantY - cy) > 0.05) { cy += (wantY - cy) * Math.min(1, dt * 0.5); moved = true; }
    if (moved) for (const c of cards) place(c);
    return moved;
  }

  function make(data, i) {
    const si = (data.route | 0) % SEEDS.length;
    const holder = new THREE.Group();
    holder.frustumCulled = false;
    // Fläche: vollflächig, Silhouette per alphaMap ausgestanzt (harte Kante, kein Glow).
    const mat = new THREE.MeshBasicMaterial({
      map: zoneTex[data.chapter], alphaMap: maskTex[si], alphaTest: 0.5,
      side: THREE.DoubleSide, toneMapped: false,
    });
    const mesh = new THREE.Mesh(new THREE.PlaneGeometry(w, h, 1, 1), mat);
    mesh.frustumCulled = false;
    holder.add(mesh);
    // Tusche liegt auf der Bildebene, nicht am Objekt: eigenes Quad, 2 cm davor.
    const dmat = new THREE.MeshBasicMaterial({ map: decalTex[si], transparent: true,
                                               side: THREE.DoubleSide, toneMapped: false, depthWrite: false });
    const decal = new THREE.Mesh(new THREE.PlaneGeometry(w, h, 1, 1), dmat);
    decal.position.z = 0.02;
    decal.renderOrder = 1;
    decal.frustumCulled = false;
    holder.add(decal);
    // Post-it: der Besuch als Beweisstück. Es klebt UNTEN LINKS AN DER KARTENKANTE und hängt
    // größtenteils darunter — es darf keine Demo-Fläche verdecken (Georgs Befund). Größe und
    // Höhe sind auf den HUD-Würfel unten rechts eingestellt: die beiden sind ein Gegengewicht.
    const pw = w * 0.145;
    const pmat = new THREE.MeshBasicMaterial({ transparent: true, side: THREE.DoubleSide,
                                               toneMapped: false, depthWrite: false });
    const postit = new THREE.Mesh(new THREE.PlaneGeometry(pw, pw * 1.06, 1, 1), pmat);
    // Weit genug NACH VORN und mit Renderreihenfolge: bei 0,05 u vor einem 13 u breiten Blatt
    // rutschte die Ecke unter die Tuschekante, sobald die Karte leicht gekippt stand.
    // 0,16 u ist optisch noch flüchtig, aber tiefensicher — und der Überstand ist größer,
    // damit das Blatt am Rand KLEBT statt darunter zu rutschen.
    postit.position.set(-w / 2 + pw * 0.78, -h / 2 - pw * 0.42, 0.16);
    postit.renderOrder = 2;
    postit.rotation.z = -0.07;
    postit.visible = false;
    postit.frustumCulled = false;
    holder.add(postit);
    group.add(holder);
    const card = { data, holder, mesh, mat, decal, dmat, seedIdx: si,
                   postit, pmat, pw, lagX: 0, lagY: 0, prev: new THREE.Vector3(),
                   pinAmt: 0, pinWant: 0,
                   half: { w: w / 2, h: h / 2 }, home: new THREE.Vector3(),
                   phase: (i * 7.13) % 100, side: 0,
                   field: null, preview: null, live: false, kind: 'zone' };
    place(card);
    return card;
  }

  academyDeck().forEach((d, i) => cards.push(make(d, i)));
  // Wie viele Lektionen hat jedes Kapitel? Der Bogen einer Zone braucht die ZAHL, nicht eine
  // Annahme — 31 Karten sind nicht gleichmäßig auf fünf Kapitel verteilt.
  for (const c of cards) if (c.data.kind === 'lesson') chapterCount[c.data.chapter] = (chapterCount[c.data.chapter] || 0) + 1;
  for (const c of cards) { place(c); c.holder.position.copy(c.home); }
  sheetQ = cards.slice();

  // Beste verfügbare Sprosse auf die Fläche legen. Live schlägt Vorschau schlägt Feld
  // schlägt Zonenfarbe — an EINER Stelle entschieden, nicht an vier.
  function applyBest(card) {
    if (card.live) return;
    const t = card.preview || card.field || zoneTex[card.data.chapter];
    card.kind = card.preview ? 'preview' : (card.field ? 'field' : 'zone');
    if (card.mat.map !== t) { card.mat.map = t; card.mat.needsUpdate = true; }
  }

  function paintField(card) {
    const t = fieldTexture(THREE, card.data, P.sheetW);
    if (card.field) card.field.dispose();
    card.field = t;
    applyBest(card);
  }

  // Gepacet und nächstgelegen zuerst — dieselbe Regel wie der Artwork-Pacer aus S23.
  function pumpSheets(player, budget) {
    if (document.hidden || !sheetQ.length) return 0;
    let n = 0; const max = budget || 2;
    while (n < max && sheetQ.length) {
      let bi = 0, bd = 1e18;
      for (let i = 0; i < sheetQ.length; i++) {
        const d = player ? sheetQ[i].holder.position.distanceToSquared(player) : i;
        if (d < bd) { bd = d; bi = i; }
      }
      paintField(sheetQ.splice(bi, 1)[0]); n++;
    }
    return n;
  }

  // Vorschaubilder von threejs.org: EIN Auftrag zur Zeit, nächstgelegen zuerst, und ein
  // Fehlschlag ist endgültig (kein Retry-Sturm). Ohne CORS-Freigabe kann WebGL das Bild
  // nicht laden — dann bleibt das Zonenfeld stehen, und der Zähler sagt, warum.
  function pumpPreviews(player) {
    if (!P.previews || prevBusy || document.hidden) return false;
    let best = null, bd = 1e18;
    for (const c of cards) {
      if (c.preview || c.previewFail || !c.field) continue;
      if (!previewURL(c.data.example)) { c.previewFail = 'none'; continue; }
      const d = player ? c.holder.position.distanceToSquared(player) : 0;
      if (d < bd) { bd = d; best = c; }
    }
    if (!best) return false;
    const card = best;
    prevBusy = true;
    loader.load(previewURL(card.data.example),
      (tex) => {
        prevBusy = false; prevDone++;
        tex.colorSpace = THREE.SRGBColorSpace; tex.anisotropy = 8;
        card.preview = tex; applyBest(card);
        if (api.onPreview) { try { api.onPreview(card, true); } catch (e) {} }
      },
      undefined,
      () => {
        prevBusy = false; prevFail++; card.previewFail = 'error';
        if (api.onPreview) { try { api.onPreview(card, false); } catch (e) {} }
      });
    return true;
  }

  // Läuft der Webfont noch, malt der Browser still Georgia — nach fonts.ready alles
  // EINMAL neu einreihen (Lehre aus v11, in v7 zweimal bestätigt).
  if (document.fonts && document.fonts.ready) {
    document.fonts.ready.then(() => { for (const c of cards) if (c.field) sheetQ.push(c); });
  }

  // Der Besuch wird ein Post-it am Kartenrand — kein Stempel im Bild, kein Punktestand.
  function markVisited(card) {
    if (!card || card.data.visited) return;
    card.data.visited = true; visited++;
    if (!card.postTex) card.postTex = postitTexture(THREE, card.data, 256);
    card.pmat.map = card.postTex; card.pmat.needsUpdate = true;
    card.postit.visible = true;
  }

  function update(dt, camera, player) {
    if (!P.visible) return;
    T += dt;
    follow(dt, player);
    camera.getWorldPosition(_look);
    let best = null, bd = P.focusDist * P.focusDist;
    for (const card of cards) {
      const m = card.holder;
      const p = card.phase, s = T * 0.16;
      // **Pinnen ist ein VERLAUF, kein Schalter.** Vorher sprang über `card.pinned` die
      // Ausrichtungsdämpfung von 3 auf 27 und die Drift auf null — und zwar genau im Moment der
      // Landung. Das war das letzte Ruckeln der Detailansicht (Georgs Befund): die Karte richtete
      // sich in einem Frame neu aus, während die Kamera schon stand.
      card.pinAmt += ((card.pinWant || 0) - card.pinAmt) * Math.min(1, dt * 2.2);
      const pin = card.pinAmt;
      {
        const dx = Math.sin(s * 1.0 + p) + 0.6 * Math.sin(s * 1.4142 + p * 1.7) + 0.35 * Math.sin(s * 2.2360 + p * 2.3);
        const dy = Math.sin(s * 1.1 + p * 1.3) + 0.55 * Math.sin(s * 1.7320 + p * 0.7) + 0.3 * Math.sin(s * 2.6457 + p * 3.1);
        const dz = Math.sin(s * 0.9 + p * 2.1) + 0.6 * Math.sin(s * 1.6180 + p * 1.1) + 0.35 * Math.sin(s * 2.4494 + p * 0.4);
        // Drift-Amplitude fährt mit `pin` gegen null: eine Karte, die man von vorn ansieht und
        // bedient, darf nicht unter dem Zeiger wegdriften — sie ist dann ein Bild, kein Mobile.
        const amp = P.driftAmp * (1 - pin);
        m.position.set(card.home.x + dx * amp, card.home.y + dy * amp * 0.55, card.home.z + dz * amp);
      }

      _to.subVectors(_look, m.position).normalize();
      _right.crossVectors(_up, _to);
      if (_right.lengthSq() < 1e-6) _right.set(1, 0, 0); else _right.normalize();
      _v.crossVectors(_to, _right).normalize();
      _m.makeBasis(_right, _v, _to);
      _q.setFromRotationMatrix(_m);
      // Eine Karte, an der man gerade arbeitet, hält STILL: die Eigen-Neigung fährt
      // gegen null, sobald eine Demo auf ihr läuft — sonst zielt man auf ein Blatt,
      // das unter dem Finger wegkippt.
      const tilt = P.tiltAmp * (1 - pin) * (card.live ? 0.25 : 1);
      _tiltE.set(Math.sin(s * 1.3 + p) * tilt,
                 Math.sin(s * 0.8 + p * 1.9) * tilt * 0.7,
                 Math.sin(s * 1.9 + p * 0.6) * tilt);
      _q.multiply(_tiltQ.setFromEuler(_tiltE));
      // Dämpfung wächst mit `pin` stetig (3 → 8), nicht in einem Sprung auf 27.
      m.quaternion.slerp(_q, Math.min(1, dt * P.faceDamp * (3 + pin * 5)));

      // Post-it im Wind: die Eigenbewegung der Karte wird gedämpft nachgezogen und kippt das
      // Blatt gegen die Bewegungsrichtung. Kein Cloth, keine Physik — zwei Tiefpassfilter.
      if (card.postit.visible) {
        const vx = (m.position.x - card.prev.x) / Math.max(dt, 1e-3);
        const vy = (m.position.y - card.prev.y) / Math.max(dt, 1e-3);
        card.lagX += (vx - card.lagX) * Math.min(1, dt * 1.6);
        card.lagY += (vy - card.lagY) * Math.min(1, dt * 2.2);
        card.postit.rotation.z = -0.07 - Math.max(-0.5, Math.min(0.5, card.lagX * 0.09))
                                - Math.sin(T * 0.9 + p) * 0.035;
        card.postit.position.y = -card.half.h - card.pw * 0.42
                                 - Math.max(-0.4, Math.min(0.4, card.lagY * 0.05));
      }
      card.prev.copy(m.position);

      if (!player) continue;
      const d2 = m.position.distanceToSquared(player);
      if (d2 < bd) { bd = d2; best = card; }

      _n.set(0, 0, 1).applyQuaternion(m.quaternion);
      _v.subVectors(player, m.position);
      const dd = _v.dot(_n);
      const side = dd >= 0 ? 1 : -1;
      if (card.side !== 0 && side !== card.side) {
        _right.set(1, 0, 0).applyQuaternion(m.quaternion);
        _to.set(0, 1, 0).applyQuaternion(m.quaternion);
        if (Math.abs(_v.dot(_right)) < card.half.w * P.passRadius && Math.abs(_v.dot(_to)) < card.half.h * P.passRadius) {
          markVisited(card);
          if (api.onPass) { try { api.onPass(card, visited); } catch (e) {} }
        }
      }
      card.side = side;
    }
    if (best !== focused) { focused = best; if (api.onFocus) { try { api.onFocus(focused); } catch (e) {} } }
  }

  return {
    name: 'academy-cards', group, update, pumpSheets, pumpPreviews, markVisited, follow,
    get onPass() { return api.onPass; }, set onPass(f) { api.onPass = f; },
    get onFocus() { return api.onFocus; }, set onFocus(f) { api.onFocus = f; },
    get onPreview() { return api.onPreview; }, set onPreview(f) { api.onPreview = f; },
    setCenter(x, z, alt) {
      cx = x; cz = z;
      if (alt != null) cy = Math.max(26, Math.min(62, alt + 8));
      for (const c of cards) { place(c); c.holder.position.copy(c.home); }
    },
    get center() { return { x: cx, z: cz, y: cy }; },
    get cards() { return cards; },
    route() { return cards.slice().sort((a, b) => a.data.route - b.data.route); },
    // Raycast auf die Fläche. Die Karte ist gedreht und geneigt, aber THREE.Raycaster
    // rechnet die Quaternion korrekt mit — kein Sonderfall. UV ist jetzt die GANZE
    // Karte, also direkt die Demo-Koordinate.
    pick(raycaster) {
      const objs = cards.map((c) => c.mesh);
      const hits = raycaster.intersectObjects(objs, false);
      if (!hits.length) return null;
      const hit = hits[0];
      const card = cards.find((c) => c.mesh === hit.object);
      if (!card) return null;
      return { card, onScreen: true, uv: hit.uv, distance: hit.distance, point: hit.point };
    },
    get focused() { return focused; },
    nearest(player) {
      let best = null, bd = 1e18;
      for (const c of cards) { const d = c.holder.position.distanceToSquared(player); if (d < bd) { bd = d; best = c; } }
      return best;
    },
    // DER STECKPLATZ. Heute: Render-Textur der Lektion. Morgen ohne neuen Mechanismus:
    // Video-Textur (YouTube), Sprite-Loop, gerenderte DOM-UI.
    setSurface(card, texture, kind) {
      if (!card) return;
      if (!texture) { card.live = false; applyBest(card); return; }
      card.live = kind !== 'static';
      card.kind = kind || 'live';
      card.mat.map = texture; card.mat.needsUpdate = true;
    },
    clearSurface(card) { if (card) { card.live = false; applyBest(card); } },
    setLive(card, texture) { this.setSurface(card, texture, 'live'); },
    clearLive(card) { this.clearSurface(card); },
    setPreviews(on) {
      P.previews = !!on;
      if (on) return;
      for (const c of cards) { if (c.preview) { c.preview.dispose(); c.preview = null; c.previewFail = 'off'; applyBest(c); } }
    },
    setVisible(on) { P.visible = !!on; group.visible = !!on; },
    // Anflug läuft → Welt hält still. Der Runner schaltet das pro Frame.
    setFollowEnabled(on) { P.followOn = !!on; },
    get following() { return P.followOn; },
    // Detailansicht: Karte still stellen — als Verlauf (`pinWant`), nicht als Schalter.
    pin(card, on) { if (card) card.pinWant = on ? 1 : 0; },
    get pinOf() { return (c) => (c ? c.pinAmt : 0); },
    setParams(p) { Object.assign(P, p || {}); for (const c of cards) place(c); },
    get params() { return P; },
    get visited() { return visited; },
    get total() { return cards.length; },
    get pending() { return sheetQ.length; },
    get previewStats() { return { ok: prevDone, fail: prevFail, busy: prevBusy }; },
    resetProgress() {
      for (const c of cards) {
        if (!c.data.visited) continue;
        c.data.visited = false;
        c.postit.visible = false;
      }
      visited = 0;
    },
    dispose() {
      for (const c of cards) {
        c.mesh.geometry.dispose(); c.mat.dispose();
        c.decal.geometry.dispose(); c.dmat.dispose();
        c.postit.geometry.dispose(); c.pmat.dispose();
        if (c.postTex) c.postTex.dispose();
        if (c.field) c.field.dispose();
        if (c.preview) c.preview.dispose();
      }
      for (const t of zoneTex) t && t.dispose();
      for (const t of maskTex) t.dispose();
      for (const t of decalTex) t.dispose();
    },
  };
}

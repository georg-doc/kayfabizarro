// ============================================================================
// travel-poc.js — KFB Travel v9 · Runner (Flug + Boden + Academy)
// ----------------------------------------------------------------------------
// Fork von terrain-v8/travel-poc.js (Freeze 2026-07-25). v8 bleibt unangetastet und ist der
// Vergleichsmaßstab: v9 darf sich nur da anders VERHALTEN, wo eine Abnahmezahl es verlangt.
//
// **Auftrag v9 (aus `docs/INTERMISSION_reviews_v8.md`):** die Verdrahtung verlässt diese Datei.
//   A · CameraRig      — genau EIN Modul schreibt `camera.*` (heute vier)
//   B · Modus-Eigentum — `switchMode` wird ein Antrag mit Begründung, plus Vertragsprüfung
//   C · Panel als Daten, dann TravelManager — diese Datei < 400 Zeilen (heute 1327)
//   D · Ereignisse an einem Ort — die acht Callbacks in einer Tabelle, kein Bus
//
// Aus v8 übernommen: **S22d Auto-Pilot** (`autopilot.js` — eine Eingabequelle, kein
// zweiter Flug-Controller) und **S31 Academy** (`academy-*.js` — 31 Lektions-
// karten in fünf Farbzonen, Live-Demo per Render-to-Texture auf dem Blatt).
// Sprintplan: docs/SPRINT_travel-v7.md (S22d/S31). Changelog: docs/CHANGELOG_travel.md.
// **Die Versionsnummer gehört dem Runner**, nicht einem Modul.
// ----------------------------------------------------------------------------
// RENDER-REIHENFOLGE (seit S2 unverhandelbar):
//   Szene → post-radial (Fullscreen-Blur) → speed-lines → hud.render()
// Sobald die Szene in einen Puffer geht, muss alles Scharfe DAHINTER kommen.
// ----------------------------------------------------------------------------
// ----------------------------------------------------------------------------
// Brief §7.1 — smallest bootable slice: flat WebGL ground + card + default pet
// (bunny) + flight controller. Flies. WebGL three 0.160. Later slices swap the
// flat ground for terrain-v3, add the ground/walk controller, 24-pet select,
// mode switch, and richer card kinetics.
//
// Runtime layers (001): Input → Vehicle(flight) → Camera → Pet → CardRig → Render.
// ============================================================================

import * as THREE from 'three';
import { createFlightController } from './flight-controller.js';
import { createCardCarrier } from './card-carrier.js';
import { createPetKinetics } from './pet-kinetics.js';
import { createVoxelTerrain } from './voxel-terrain.js';
import { createSkydome } from './skydome-shader.js';
import { makeWorldContext, MODES } from './world-context.js';
import { createWalkController } from './walk-controller.js';
import { createTravelHeat } from './travel-heat.js';
import { createHudCube } from './hud-cube.js';
import { createSettingsOverlay } from './settings-overlay.js';
import { createSpeedLines } from './speed-lines.js';
import { createRadialPost } from './post-radial.js';
import { createCardContrails } from './card-contrails.js';
import { createPetLighting } from './pet-lighting.js';
import { createBlobShadow } from './ground-shadow.js';
import { createTravelAudio } from './travel-audio.js';
import { createSkyCards } from './sky-cards.js';
import { createCardRegistry } from './card-registry.js';
import { createAutopilot } from './autopilot.js';
import { createAcademyCards } from './academy-cards.js';
import { createAcademyLive } from './academy-live.js';
import { createCardDock } from './card-dock.js';
import { createVoxelGlyphs } from './voxel-glyphs.js';
import { createCardTitle } from './card-title.js';
import { createLessonSearch } from './lesson-search.js';
import { createPetFacing } from './pet-facing.js';
import { createCameraRig } from './camera-rig.js';
import { createModeOwner, assertController } from './mode-owner.js';
import { createTravelManager } from './travel-manager.js';
import { buildSections } from './settings-schema.js';
import { createTravelInput } from './travel-input.js';
import { createTravelStage } from './travel-stage.js';
import { createEventTable } from './travel-events.js';

const ASSET = (p) => new URL(p, import.meta.url).href;
// Pfad-Hygiene: der Pet-Stack kommt kanonisch über jsdelivr (Module brauchen application/javascript);
// der lokale Spiegel ist nur Fallback, nie Quelle.
const PETS_CANON = 'https://cdn.jsdelivr.net/gh/georg-doc/kayfabizarro@main/media/3D_Assets/kfb-pets.js';
async function petsModule() {
  try { return await import(/* @vite-ignore */ PETS_CANON); }
  catch (e) { console.warn('[travel-poc] kanonischer Pet-Stack nicht ladbar → lokaler Spiegel', e); return await import('./kfb-pets.js'); }
}

(function boot() {
  const stage = document.getElementById('tv-stage');
  if (!stage) { requestAnimationFrame(boot); return; }
  const probe = document.createElement('canvas');
  if (!(probe.getContext('webgl2') || probe.getContext('webgl'))) {
    stage.innerHTML = '<div style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center;color:#cdd4e6;font-family:monospace;">This needs a WebGL browser.</div>';
    return;
  }
  start(stage).catch((e) => console.error('[travel-poc] start failed', (e && (e.stack || e.message)) || e));
})();

async function start(stage) {
  // ---------------------------------------------------------------- BÜHNE (S44d)
  // Renderer, Szene, Kamera, Licht, Himmel, Terrain und die Gelände-Sonden stehen in
  // `travel-stage.js`. Aufbau ist keine Verdrahtung — er passiert einmal und ändert sich nie.
  const stageOut = createTravelStage({ THREE, stage, makeWorldContext, createSkydome, createVoxelTerrain });
  const { renderer, scene, camera, sun, sky, terrain, groundHeightAt, pullIn, escapeTerrain,
          WORLD_SEED, STORY } = stageOut;
  // `wc`, `pal`, `story` und `worldSeed` bleiben Runner-Zustand: `applyWorld` baut sie beim
  // Story-Wechsel neu. Die Bühne LIEFERT sie, sie BESITZT sie nicht.
  let wc = stageOut.wc, pal = stageOut.pal, worldSeed = WORLD_SEED, story = STORY;
  const fogCol = stageOut.fogCol;
  // --- vehicle + rig ---
  const flight = createFlightController({ THREE });
  flight.reset(0, 0);
  const rig = createCardCarrier({ THREE });   // assetBase: kanonische RAW-URL (card-carrier default)
  scene.add(rig.group);
  const petKin = createPetKinetics({ THREE });
  // S33b · Facing als dünne Schicht NACH der Kinetik: sie schreibt nur die Gier, nie das
  // ganze Quaternion — der Lean aus `pet-kinetics` bleibt damit unangetastet.
  const petFace = createPetFacing({ THREE });
  const walk = createWalkController({ THREE });
  const heat = createTravelHeat({});   // S1: der eine Regie-Skalar
  // S42 (V9-B): Der Modus gehört `modeOwner` (unten definiert, sobald die Modi es können).
  // Diese Kurzform bleibt, weil sie 40-mal gelesen wird — sie ist ein LESEZUGRIFF, kein Zustand.
  let modeOwner = null;
  const isWalk = () => modeOwner && modeOwner.mode === 'walk';
  const curMode = () => (modeOwner ? modeOwner.mode : 'fly');

  // --- S7: HUD-Würfel unten rechts — Ruhezustand Tacho, angefasst Menü.
  // Oberfläche und Farben kommen aus derselben Welt (Kanten-Textur + Story-Palette).
  let storyMode = MODES.find((m) => m.key === STORY) || MODES[3];
  let settings = null;   // wird nach dem Pet-Mount gebaut; Handler greifen lazy darauf zu
  const hud = createHudCube({
    THREE, dom: renderer.domElement,
    ink: storyMode.ink, panel: storyMode.panel,
    // S33 · Die Tacho-Seite (+Z, HOME) ist der Navi-Knopf: sie öffnet die Lektions-Suche.
    // Die Reise-Regler bleiben über Tab erreichbar — ein Knopf, eine Bedeutung.
    onSelect: (id) => { if (id === 'travel' && academyOn) search.toggle(); else settings.toggle(id); },
  });
  hud.preWarm(renderer);   // Shader vorwärmen (Academy-Muster): kein Ruckler im ersten Frame

  // --- S2: Boost-Regie ------------------------------------------------------
  // Zwei Pässe, ein Regler-Satz. Beide hängen an `heat` (+ Boost-Impuls), beide sind
  // in Ruhe komplett aus. `fxBlur` steht HIER, weil das Overlay es beim Bauen liest
  // (später deklariert = TDZ-Boot-Abbruch, S8-Falle 1).
  let fxBlur = 1;
  const lines = createSpeedLines({ THREE, ink: storyMode.ink });
  lines.setInk(storyMode.ink, storyMode.panel);
  // Kondensstreifen an den hinteren Kartenecken: ab 20 km/h die einzige Tempo-Auskunft,
  // und sie zeichnen Bank, Barrel-Roll und Steigflug als Kurve in die Luft (TinySkies-Muster).
  const trails = createCardContrails({ THREE });
  trails.setAnchors(rig.halfW, rig.halfD);
  trails.setTint(storyMode.panel);
  scene.add(trails.group);

  // --- S14: Pet-Beleuchtung (Sky-Environment + Fill + Story-Tint) --------------
  const lighting = createPetLighting({ THREE, renderer, scene });
  lighting.setTint(storyMode.ink, 0.18);
  lighting.register(rig.group);
  lighting.bakeEnvironment(sky.group);

  // --- S15 · Schatten. Zwei verschiedene Probleme, zwei verschiedene Lösungen:
  // (1) auf dem TERRAIN projiziert der Terrain-Shader selbst (`terrain.setCasters`). Ein
  //     Schatten-Quad kann auf einem Voxel-Boden nicht funktionieren: es liegt auf EINER Höhe,
  //     schwebt also an Kanten über dem Abgrund, steckt in Wänden und flackert, sobald die
  //     Probenhöhe zwischen Nachbarsäulen springt (Georgs Befund).
  // (2) auf der KARTE bleibt es ein Quad im Karten-Rig — dort IST die Fläche durchgehend,
  //     und der Schatten soll mit Bank und Wellung mitgehen.
  let shadowGain = 1;
  const petShadow = createBlobShadow({ THREE, color: 0x1f1a14, params: { core: 0.3 } });
  rig.lean.add(petShadow.mesh);
  const post = createRadialPost({ THREE, renderer });
  lines.preWarm(renderer);

  // ---------------------------------------------------------------- WELT NEU BAUEN
  // Story-Mode und Seed ändern denselben Weg: neuer WorldContext → Terrain rebaked,
  // Himmel und HUD-Würfel bekommen dieselbe Palette. (Vorgriff auf S5.)
  function applyWorld(rebuildCtx) {
    if (rebuildCtx) {
      wc = makeWorldContext({ storyMode: story, seeds: [worldSeed] });
      pal = wc.palette;
    }
    terrain.setWorldContext(wc);
    terrain.setPalette(pal);
    sky.setMode(wc.storyModeIndex);
    sky.setPalette(pal);
    storyMode = MODES.find((m) => m.key === story) || storyMode;
    hud.setPalette({ ink: storyMode.ink, panel: storyMode.panel });
    lines.setInk(storyMode.ink, storyMode.panel);   // Speedlines tragen die Story-Tinte, nie Weiß
    trails.setTint(storyMode.panel);
    lighting.setTint(storyMode.ink);
    lighting.bakeEnvironment(sky.group);   // neuer Himmel → neues Umgebungslicht
    audio.setMood(wc.storyModeIndex);      // ein Mood = eine spektrale Identität
    fogCol.setRGB(pal[0][0] * 0.6 + 0.02, pal[0][1] * 0.6 + 0.03, pal[0][2] * 0.6 + 0.05);
    scene.background = fogCol.clone();
    if (scene.fog) scene.fog.color.copy(fogCol);
    if (settings) settings.setAccent('#' + new THREE.Color(storyMode.ink).getHexString());
  }

  // ---------------------------------------------------------------- CARD FLOOR
  // Das Fahrzeug ist keine Kugel, sondern eine 3.0 × 1.68 große Karte, die BANKT — und die
  // Cubes hüpfen nach oben. Eine einzige Höhenprobe in der Mitte lässt genau das passieren,
  // was Georg sieht: die Ecken schneiden in einen steigenden Würfel. Statt einer Physik-Engine
  // tastet diese Funktion die ganze Grundfläche ab (Mitte + 4 Ecken), einmal an der aktuellen
  // und einmal an der VORAUS liegenden Position, nimmt den schlechtesten Fall und rechnet die
  // Bob-Reserve (`terrain.maxLift()`) plus den Tiefgang der untersten Ecke drauf.
  // Steigen schnell, Sinken langsam — dieselbe Disziplin wie beim Kamera-Pull-in.
  let cardFloor = 0;
  // Höchste Oberfläche im Umkreis eines Körperradius — EINE Mittenprobe reicht nicht: das
  // Pet steckt sonst in der Nachbarsäule (Georgs Screen 1 beim Wechsel in den Walk-Mode).
  function safeGroundAt(x, z, r) {
    const rad = r != null ? r : 0.7;
    let top = groundHeightAt(x, z);
    for (let i = 0; i < 8; i++) {
      const a = (i / 8) * Math.PI * 2;
      const t = groundHeightAt(x + Math.cos(a) * rad, z + Math.sin(a) * rad);
      if (t > top) top = t;
    }
    return top;
  }
  function cardClearance(st, dt) {
    const hw = rig.halfW + 0.25, hd = rig.halfD + 0.25;   // + Haut-Marge
    const fx = st.forward.x, fz = st.forward.z;
    const rx = -fz, rz = fx;                              // right = forward × up (horizontal)
    const ahead = 1.2 + st.speed * 0.22;                  // dorthin, wo wir gleich sind
    let top = -1e9;
    for (let s = 0; s <= 1; s++) {
      const ox = st.position.x + fx * ahead * s, oz = st.position.z + fz * ahead * s;
      for (let i = 0; i < 5; i++) {
        const sx = i === 0 ? 0 : (i <= 2 ? 1 : -1);
        const sz = i === 0 ? 0 : (i === 1 || i === 3 ? 1 : -1);
        const t = groundHeightAt(ox + rx * hw * sx + fx * hd * sz, oz + rz * hw * sx + fz * hd * sz);
        if (t > top) top = t;
      }
    }
    const tilt = Math.abs(Math.sin(st.bank)) * hw + Math.abs(Math.sin(st.pitchTilt || 0)) * hd;
    // Bob-Reserve nur dort, wo die Cubes wirklich tanzen: in der Ruhezone braucht die Karte
    // keine Höhe für Hübe, die nicht stattfinden — dafür immer ein fester Sicherheitsabstand.
    const lift = terrain.maxLift(true) * (1 - terrain.calmAt(st.position.x, st.position.z));
    const want = top + lift + tilt + 0.3;
    cardFloor += (want - cardFloor) * Math.min(1, dt * (want > cardFloor ? 14 : 2.2));
    return cardFloor;
  }

  // S11 · Die Modus-Anzeige ist WEG — kein Badge mehr. Sie darf fallen, weil S10 die Auskunft
  // durch Mechanik ersetzt: man sieht an der Höhe, in welchem Modus man ist. Was bleibt, ist der
  // Rahmen im DC (Wortmarke links, Meta rechts) und der Tacho im Würfel.
  // EINE Hinweiszeile statt zweier Legenden-Blöcke: blendet nach 8 s aus und in späteren
  // Sitzungen gar nicht mehr auf. Die vollständige Steuerung steht im Overlay (S8).
  const hint = document.createElement('div');
  hint.style.cssText = "position:absolute;left:50%;transform:translateX(-50%);bottom:20px;text-align:center;"
    + "font-family:'Special Elite',monospace;font-size:12px;color:#fff;opacity:.9;"
    + 'text-shadow:0 2px 6px rgba(0,0,0,.7);transition:opacity 1.4s ease;pointer-events:none;';
  hint.textContent = 'W/S Schub · A/D lenken · Doppelklick auf eine Akademie-Karte = Anflug · Tacho = Lektion suchen · Tab = Einstellungen';
  (document.getElementById('tv-hud') || stage).appendChild(hint);
  try {
    if (localStorage.getItem('kfb-travel-v9-hint') === 'seen') hint.style.display = 'none';
    else setTimeout(() => { hint.style.opacity = '0'; try { localStorage.setItem('kfb-travel-v9-hint', 'seen'); } catch (e) {} }, 8000);
  } catch (e) { setTimeout(() => { hint.style.opacity = '0'; }, 8000); }
  // S10 · MODUS OHNE SCHALTER. Der Modus ist eine Folge der Höhe, kein Zustand, den man umlegt:
  // Leertaste zweimal am Boden = abheben (ein verlängerter Sprung, kein neuer Zustand) · X oder
  // Pfeil-runter = sinken · Bodenkontakt mit kleiner Sinkrate = zurück in Walk. `F` bleibt als
  // direkter Umschalter — wer mit Timing-Fenstern nicht zurechtkommt, braucht einen Weg ohne.
  let autoMode = true;
  // **Die Modi tragen ihren Lebenszyklus selbst** (`enter`/`exit`), der Eigentümer entscheidet nur
  // über den Wechsel. Vorher war beides ein `if` in einer Funktion, und jede neue Bedingung wuchs
  // an der Aufrufstelle statt an einer Regel.
  const MODES_LIFECYCLE = {
    walk: { enter() {
      const p = flight.state.position; const gy = safeGroundAt(p.x, p.z) + terrain.maxLift(true) + 0.25;
      walk.reset(p.x, p.z, gy, Math.atan2(flight.state.forward.x, flight.state.forward.z));
      camRig.setWalkLookY(gy + walk.eyeUp);
      rig.setVisible(false); rig.setClipEnabled(false);
      petKin.enterWalk();
      if (pet) {
        scene.add(pet.object3D); pet.object3D.scale.setScalar(1.25);
        // no procedural loop in walk mode: those tweens move group.position, which
        // IS the walker's world position here — the clip layer carries the cycle.
        if (pet.motion) { pet.motion.stopLoops(); }
      }
    } },
    fly: { enter(opt) {
      const wp = walk.state.position;
      // Vom Boden kommend setzt die Karte DORT ein, wo das Pet stand, und in seiner Blickrichtung.
      // Sonst hüpft das Fahrzeug beim Abheben auf Reisehöhe — das war der Sprung in v5.
      const startAlt = opt && opt.alt != null ? opt.alt : null;
      flight.reset(wp.x, wp.z, startAlt, opt && opt.heading != null ? opt.heading : walk.state.heading);
      if (opt && opt.climb) flight.climbTo((startAlt != null ? startAlt : flight.state.alt) + opt.climb);
      cardFloor = terrain.groundHeightAt(wp.x, wp.z) + terrain.maxLift(true);   // kein Kriechstart
      rig.setVisible(true); rig.setClipEnabled(true);
      trails.reset();   // sonst spannt ein altes Band quer über die Karte
      petKin.leaveWalk(pet);
      petFace.reset(Math.PI);   // neuer Eltern-Raum (Sitz statt Szene): Gier nicht mitschleppen
      if (pet) { rig.seat.add(pet.object3D); pet.object3D.visible = true; pet.object3D.scale.setScalar(1.15); pet.object3D.position.set(0, 0, 0); }
    } },
  };
  modeOwner = createModeOwner({
    initial: 'fly', modes: MODES_LIFECYCLE,
    onChange: (to) => {
      heat.setMode(to);   // Skala behalten, kein Sprung beim Wechsel
      camRig.snap();
      modeOwner.lock(0.9, 'gerade gewechselt');   // sonst pendelt es am Boden
    },
  });
  // **Die Bedingungen leben jetzt hier — benannt, an einer Stelle, zählbar.** Jede war einmal ein
  // Fehler: der Anflug, der im Boden-Modus endete; die Detailansicht, die vom Terrain zerrissen
  // wurde; das Pendeln direkt nach einem Wechsel. Und jede gilt nur für Anträge, die die HÖHE
  // stellt — was die Hand will, wird nicht abgelehnt.
  modeOwner
    .addRule('höhe-abgeschaltet', (c) => c.reason === 'altitude' && !autoMode)
    .addRule('anflug-läuft', (c) => c.reason === 'altitude' && auto.active)
    .addRule('detailansicht', (c) => c.reason === 'altitude' && dock.owns)
    .addRule('sperrfrist', (c) => c.reason === 'altitude' && modeOwner.locked);
  // Ein Antrag ist die EINZIGE Art, den Modus zu ändern. Diese Hülle existiert nur, damit die
  // Aufrufstellen kurz bleiben — sie enthält keine Bedingung.
  const requestMode = (to, reason, opt) => modeOwner.request(to, reason, opt);
  // Verträge werden GEPRÜFT, nicht zugesichert (Audit-Punkt 3b). Ein TS-Interface gibt es hier
  // nicht — diese Prüfung läuft und würde eine Abweichung melden, statt sie zu behaupten.
  const contracts = [assertController('flight-controller', flight), assertController('walk-controller', walk)];

  // Abheben = der Sprung, der nicht landet. Kein neuer Zustand in der Sprung-Grammatik:
  // walk.jump() ist beim ersten Tastendruck schon gelaufen, der zweite verlängert ihn.
  function takeOff() {
    if (!isWalk()) return;
    const ws = walk.state;
    if (!ws.onGround && ws.vy < -0.5) return;   // im Fallen nicht abheben (sonst Rettungs-Flug)
    requestMode('fly', 'takeoff', { alt: ws.position.y + 0.8, heading: ws.heading, climb: 12 });
  }

  // --- pet (canonical stack, default bunny) ---
  let pet = null, petLib = null, petId = 'bunny', petBusy = false;
  // Pet-Wechsel läuft über DIESELBE Funktion wie der erste Mount (ein Pfad, kein Sonderfall).
  // Vertrag §12.6: altes Pet disposen, sonst stapeln sich Augen-Rigs.
  async function mountPet(id) {
    if (petBusy) return;
    petBusy = true;
    try {
      const { loadPets, makePet } = await petsModule();
      if (!petLib) petLib = await loadPets();
      const p = await makePet(petLib, id, { THREE, motion: 'idle' });
      p.object3D.rotation.y = Math.PI;   // face travel direction (-Z)
      p.object3D.traverse((n) => { if (n.isMesh) { n.castShadow = true; } });
      if (pet) { try { pet.object3D.removeFromParent(); pet.dispose && pet.dispose(); } catch (e2) {} }
      pet = p; petId = id; window.__pet = p;
      if (p.motion && p.motion.initParts) p.motion.initParts();
      lighting.register(p.object3D);   // S14: Tint-Uniforms + envMapIntensity auf das neue Pet
      if (isWalk()) {
        petKin.enterWalk();
        scene.add(p.object3D); p.object3D.scale.setScalar(1.25);
        if (p.motion) p.motion.stopLoops();
      } else {
        p.object3D.scale.setScalar(1.15); p.object3D.position.set(0, 0, 0);
        rig.seat.add(p.object3D);
        rig.applyClip(p.object3D);   // clip feet at the card surface
      }
    } catch (e) { console.warn('[travel-poc] pet mount failed', e); }
    petBusy = false;
  }
  mountPet('bunny');

  // ---------------------------------------------------------------- S8: EINSTELLUNGEN
  // Cluster nach Häufigkeit. Es stehen nur Regler drin, die ECHT etwas tun — lieber eine
  // Sektion mit drei ehrlichen Reglern als sechs, die Zukunft versprechen.
  let bpm = 104, beatGain = 1;                       // Rhythmus-Fallback ohne Ton
  // S20 · Klang. Der Takt kommt ab jetzt aus dem Track, den man hört; ohne Ton fällt der Runner
  // auf seinen synthetischen Takt zurück. EIN Ausgang, kein zweites System (Regel aus S1).
  const audio = createTravelAudio({ storyIndex: wc.storyModeIndex });
  let soundOn = false;   // erst eine Nutzergeste darf den AudioContext bauen (Autoplay-Policy)
  const armAudio = () => { if (!soundOn) return; if (!audio.ready) audio.start(); else audio.resume(); };

  // S22 · Sky-Karten als Flugziele. Durchflug → Portal-Auflösung + Einsatz + Zähler.
  // S23 · Die Blätter tragen echte Karten: Titel/Lore aus der Deck-JSON sofort, das Artwork als
  // 2×2-Quadrant aus dem Deck-PDF gedrosselt nach (Kanon aus v11, cardMapping im Repo-Manifest).
  const cardReg = createCardRegistry();
  const skyCards = createSkyCards({ THREE, count: 7, registry: cardReg });
  scene.add(skyCards.group);
  let artT = 0, artOn = true;
  // Deck-JSON erst nach vier Sekunden holen — die ersten Sekunden gehören dem Terrain-Aufbau.
  setTimeout(() => {
    cardReg.pool().then((list) => {
      if (list && list.length) {
        skyCards.setDeck(list, true);
        console.info('[travel] Kartenpool:', list.length, 'Karten aus', cardReg.decks.length, 'Decks');
      }
    }).catch(() => { /* Textkarten bleiben stehen — nie ein leeres Blatt */ });
  }, 4000);
  // ---------------------------------------------------------------- EREIGNISSE (V9-D)
  // Acht Ereignisse, je EIN Zuhörer — deshalb kein Bus (Intermission §4a), aber eine TABELLE:
  // `EV.on(besitzer, name, was, fn)` an einer Stelle, mit Klartext, Zähler und Fehler-Isolation.
  // Eine werfende Rückmeldung darf den Sender nicht mitnehmen (der Auto-Pilot stirbt sonst an
  // einer HUD-Zeile). Ein Verteiler kommt, wenn ein Ereignis drei Zuhörer hat — die Tabelle sagt es.
  const EV = createEventTable();
  EV.on(skyCards, 'onPass', 'Sky-Karte durchflogen → Klang, HUD-Blitz, Merker',
      (data, n) => {
    audio.sfx('card');
    hud.flash && hud.flash();
    lastPass = { title: data.title, deck: data.deck, n };
  });
  let lastPass = null;

  // ---------------------------------------------------------------- S22d + S31
  // Der Auto-Pilot ist eine EINGABEQUELLE (siehe autopilot.js): er liefert dieselben
  // vier Werte wie die Tastatur. `flight-controller.js` bleibt unangetastet.
  const auto = createAutopilot({ THREE, flight });
  // S32c · Landung in die Karten-Detailansicht. Kein Overlay: das Dock mischt nur die
  // Kamera ein (ein Faktor, kein zweiter Zustand) — die Karte selbst ist der Viewport.
  const dock = createCardDock({ THREE });
  let dockOnArrive = true;
  let flyTime = 6;
  // Die Akademie ist ein ORT, kein Strom: 31 Karten in fünf Farbzonen, fest um den
  // Anker. Deck-Karten (S22/S23) und Academy schließen sich aus — zwei Kartenströme
  // im selben Himmel wären nur Krach.
  const academy = createAcademyCards({ THREE });
  scene.add(academy.group);
  let academyOn = true;
  academy.setVisible(true);
  skyCards.setVisible(false);
  const live = createAcademyLive({ THREE, renderer,
    progress: () => { const f = []; for (const c of academy.cards) f[c.data.route] = c.data.visited; return { flags: f }; } });
  let shownLive = null, sheetT = 0, focusCard = null, lastLesson = null, apNote = '', apNoteT = 0, stripT = 0;
  // S32b · Voxel-Glyph-Titel: dieselben Würfel wie das Terrain, nur klein — EIN Satz für die
  // fokussierte Karte, nie 31. Der lange Titel bleibt in der DOM-Zeile; hier steht das Kurzwort.
  const glyphs = createVoxelGlyphs({ THREE });
  // **Standardmäßig AUS** (Georgs Befund): die Würfel-Glyphen überlagern die Karten, sind auf
  // Entfernung nicht lesbar und stören die Detailansicht. Der Port bleibt samt Regler erhalten —
  // der Ersatz ist eine lesbare, farbkodierte Headline-Schrift (eigener Slice), nicht dieser Titel.
  let glyphCard = null, glyphsOn = false, glyphCube = 0.23;
  // S46 · Der lesbare Titel: Irish Grover, extrudiert, papierfarben nach Zone getönt, schwebend
  // mit Tuschesteg zur Karte. EINER für die fokussierte Karte — dieselbe Regel wie beim Live-Pacer.
  const cardTitle = createCardTitle({ THREE });
  let titleOn = true, titleSubOn = true;
  // S33 · Navi: Eingabe = Live-Suche über alle 31 Lektionen, Doppelklick/Enter = Anflug.
  const search = createLessonSearch({
    mount: stage,
    cards: () => academy.cards,
    cubeSize: () => hud.sizePx,
    onSelect: (card) => { hud.flash && hud.flash(); },
    onFly: (card) => { search.close(); flyToCard(card); },
  });
  const note = (s, secs) => { apNote = s; apNoteT = secs || 4.5; };

  // EINE Zeile Auskunft, unten mittig: welche Lektion im Zugriff ist, was der Pilot
  // gerade tut. Text gehört ins DOM, nicht auf eine Textur — hier ist er scharf.
  const strip = document.createElement('div');
  // Georgs Befund: die Meta-Zeilen stören und brechen um. Also ganz nach unten, EINE Zeile,
  // kein Umbruch — was nicht passt, wird abgeschnitten statt die Bildmitte zu belegen.
  strip.style.cssText = 'position:absolute;left:50%;transform:translateX(-50%);bottom:10px;max-width:94vw;'
    + 'white-space:nowrap;overflow:hidden;text-overflow:ellipsis;'
    + "text-align:center;font-family:'Special Elite',monospace;font-size:12px;line-height:1.45;color:#fff;"
    + 'text-shadow:0 2px 6px rgba(0,0,0,.75);pointer-events:none;opacity:0;transition:opacity .35s ease;';
  (document.getElementById('tv-hud') || stage).appendChild(strip);

  EV.on(academy, 'onFocus', 'Lektionskarte im Zugriff → Glyph-Titel anhängen',
      (c) => { focusCard = c; attachGlyphs(c); attachTitle(c); });
  EV.on(academy, 'onPass', 'Lektionskarte durchflogen → besucht, Klang, Meldung',
      (card, n) => {
    audio.sfx('card');
    hud.flash && hud.flash();
    lastLesson = card.data;
    lastPass = { title: card.data.title, deck: card.data.deck, n };
    auto.arrived(card);                      // Durchflug IST die Ankunft
    note('Durchflogen: ' + card.data.title + '  ·  ' + n + ' von ' + academy.total + ' besucht');
  });
  EV.on(auto, 'onArrive', 'Anflug angekommen → besucht, Karte pinnen, Dock anfordern',
      (card) => {
    // Ankommen IST besuchen. Der Durchflug ist die schönere Ankunft, aber nicht die einzige:
    // gemessen kam der Anflug zweimal von drei Malen neben der Kartenebene heraus (Abstand
    // 5,8 u, kein Vorzeichenwechsel) — ohne diese Zeile bliebe der Stempel dann aus und die
    // Route würde dieselbe Karte ewig erneut anfliegen.
    if (!card || !card.data) return;
    const fresh = !card.data.visited;
    academy.markVisited(card);
    lastLesson = card.data;
    note(fresh ? 'Angekommen: ' + card.data.title + '  ·  ' + academy.visited + ' von ' + academy.total
               : 'Wieder da: ' + card.data.title);
    // Karte SOFORT still stellen, nicht erst bei „gelandet“: das Pinnen ist ein Verlauf (2,2/s),
    // also ist die Ausrichtung fertig, wenn die Kamera ankommt. Vorher setzte es bei k ≥ 0,9 ein
    // und die Karte richtete sich neu aus, während die Kamera schon stand — das letzte Ruckeln.
    if (dockOnArrive && academyOn) { academy.pin(card, true); dock.request(card, camera); }
  });
  EV.on(auto, 'onRoute', 'Route rückt vor → nächstes Ziel melden',
      (card, left) => note('Route: ' + card.data.title + '  ·  ' + left + ' danach'));
  EV.on(dock, 'onDock', 'Detailansicht gelandet → pinnen, Meldung',
      (card) => {
    academy.pin(card, true);   // Sicherheitsnetz: auch bei Handstart gilt „Bild, kein Mobile“
    // Die Interaktions-Auskunft steht in der Strip-Zeile und ist dort live-abhängig — hier nur
    // die Ankunft melden. Vorher versprach diese Meldung „ziehen bedient die Demo" auch auf
    // Karten ohne Live-Lektion (28 von 31).
    note('Gelandet: ' + card.data.title, 3.5);
  });
  EV.on(dock, 'onLeave', 'Detailansicht gelöst → entpinnen, Zoom zurück',
      (card) => { academy.pin(card, false); camRig.setZoom(9); });
  EV.on(auto, 'onWarn', 'Anflug meldet ein Problem (Zeit, Tempo, Ziel entkommen)',
      (w) => {
    // Nicht stillschweigend verfehlen: die Höchstgeschwindigkeit ist eine physikalische
    // Grenze, und S28/S30 rechnen später mit dieser Zahl.
    if (w.reason === 'too-fast') note('Zielzeit ' + Math.round(w.asked) + ' s nicht erfüllbar (' + Math.round(w.dist) + ' u bei '
      + Math.round(flight.params.SPD_MAX) + ' u/s) → ' + w.min.toFixed(1) + ' s', 6);
    else if (w.reason === 'escaped') note('Ziel entkommen — Steuerung zurück bei dir.', 5);
    else note('Zeit verloren: nötig ' + Math.round(w.need) + ' u/s, Grenze ' + Math.round(w.max) + ' u/s', 6);
    console.info('[autopilot]', w);
  });

  const _ray = new THREE.Raycaster(), _ndc = new THREE.Vector2();
  function pickAcademy(clientX, clientY) {
    if (!academyOn) return null;
    const r = renderer.domElement.getBoundingClientRect();
    _ndc.set(((clientX - r.left) / r.width) * 2 - 1, -((clientY - r.top) / r.height) * 2 + 1);
    _ray.setFromCamera(_ndc, camera);
    return academy.pick(_ray);
  }
  function flyToCard(card, seconds) {
    if (!card) return;
    // Ein neuer Anflug verlässt die Detailansicht — IMMER, und zwar hier an der Wurzel statt in
    // jedem Auslöser. Gemessen: `R` startete die Route, während die Kamera vor der ALTEN Karte
    // klebte; 5 s später war der Spieler 28 u weg, die Demo tot, und die ganze Anflug-Regie
    // (Bremsweg, POV-Zoom, Landung) unsichtbar.
    if (dock.owns) dock.release();
    if (isWalk()) requestMode('fly', 'anflug', { climb: 16 });
    auto.flyTo(card, { seconds: seconds != null ? seconds : flyTime });
    note('Anflug: ' + card.data.title + '  ·  ' + card.data.deck);
  }
  function flyRoute() {
    const all = academy.route();
    const open = all.filter((c) => !c.data.visited);
    if (dock.owns) dock.release();
    if (isWalk()) requestMode('fly', 'anflug', { climb: 16 });
    auto.routeTo(open.length ? open : all, { seconds: flyTime });
  }
  // Der Titel hängt AN der Karte (Kind des Halters), also billboardet und pinnt er mit ihr.
  // Größe: das Wort soll ungefähr die Kartenbreite einnehmen, aber ein Würfel nie größer als
  // `glyphCube` werden — sonst werden kurze Wörter wie DRAG zu Klotz-Buchstaben. Terrain-Cubes
  // sind 1,0; bei 0,23 liest man „dieselben Würfel, nur kleiner“.
  // Der Titel hängt am Kartenhalter (billboardet und pinnt also mit), reserviert sein Band EINMAL
  // und animiert nur darin — sonst rahmt das Dock je nach Schwebe-Frame etwas anderes.
  function attachTitle(card) {
    if (!titleOn || !card) { cardTitle.detach(); return; }
    const d = card.data || {};
    // Subline aus dem, was die Karte WIRKLICH weiß: Kapitel und Herkunft. Zwei Zeilen sind das
    // Maximum (Georgs Vorgabe), der Ticker für längere Texte kommt später auf denselben Platz.
    const sub = titleSubOn
      ? String(d.nr || '') + ' · ' + String(d.chapterTitle || '').toUpperCase()
        + (d.tag ? '\n[' + d.tag + '] ' + String(d.chapterSub || '') : '')
      : '';
    cardTitle.attach(card, { text: d.title, sub, tint: d.ink });
  }

  function attachGlyphs(card) {
    if (!glyphsOn || !card) {
      if (glyphCard) glyphCard.padTop = 0;
      glyphCard = null; glyphs.group.visible = false;
      return;
    }
    if (card === glyphCard) return;
    if (glyphCard) glyphCard.padTop = 0;
    glyphCard = card;
    const d = card.data;
    const m = glyphs.measure(d.glyph);
    const scale = Math.min((academy.params.width * 0.94) / Math.max(m.w, 1), glyphCube);
    const gh = m.h * scale;
    glyphs.group.scale.setScalar(scale);
    glyphs.group.position.set(0, card.half.h + gh * 0.5 + 0.55, 0.1);
    glyphs.group.visible = true;
    card.holder.add(glyphs.group);
    // Zonen-Palette: dunkle Tinte → Tinte → Panel. Die Zone ist damit auch am Titel lesbar.
    const ink = new THREE.Color(d.ink), panel = new THREE.Color(d.panel), dark = ink.clone().multiplyScalar(0.42);
    glyphs.setPalette([[dark.r, dark.g, dark.b], [ink.r, ink.g, ink.b], [panel.r, panel.g, panel.b]]);
    glyphs.setText(d.glyph);
    card.padTop = gh + 0.9;   // damit die Detailansicht den Titel mitrahmt
  }

  function updateStrip(dt) {
    apNoteT = Math.max(0, apNoteT - dt);
    if (!academyOn) { strip.style.opacity = '0'; return; }
    const parts = [];
    const s = auto.status;
    if (s.mode === 'fly' && auto.target) {
      parts.push('▶ Anflug: ' + auto.target.data.title + '  ·  ETA ' + s.eta.toFixed(1) + ' s'
        + (s.feasible ? '' : '  ·  Zeit nicht erfüllbar'));
    } else if (dock.docked && dock.card) {
      // Auf „läuft" gaten, nie auf „existiert": nur 3 der 31 Lektionen sind live. Vorher lud die
      // Zeile unbedingt zum Ziehen ein — auf einer Vorschau-Karte war genau diese Geste der
      // Auswurf aus der Detailansicht.
      const liveHere = live.live && live.card === dock.card;
      parts.push('■ Detailansicht: ' + dock.card.data.title
        + (liveHere ? '  ·  LIVE (KFB-Nachbau)  ·  ziehen bedient die Demo  ·  Esc = raus'
                    : '  ·  Vorschaubild von threejs.org  ·  Esc = raus'));
    } else if (s.mode === 'loiter' || s.mode === 'dwell') {
      parts.push('↻ kreist um ' + (auto.target ? auto.target.data.title : 'die Karte')
        + '  ·  W/S/A/D oder ziehen übernimmt');
    } else if (focusCard) {
      const d = focusCard.data;
      parts.push(d.deck + '  —  ' + d.title + '  [' + d.tag + ']'
        + (live.card === focusCard ? '  ·  läuft auf dem Blatt — ziehen'
          : (live.enabled && live.canRun(d.example) ? '  ·  Live-Demo startet …' : '  ·  Doppelklick = anfliegen')));    }
    if (apNoteT > 0 && apNote) parts.push(apNote);
    strip.innerHTML = parts.join('<span style="opacity:.45"> &nbsp;|&nbsp; </span>');
    strip.style.opacity = parts.length ? '1' : '0';
  }
  // Tanz und Blinken sind ZWEI Kanäle (Georgs Befund: bei Tanz aus blinkten die Cubes weiter).
  // 'off' · 'beat' (an der Musik) · 'speed' (am Reisetempo) · 'both'
  let danceMode = 'both', blinkMode = 'both', blinkGain = 1;
  // Ruhezone am Boden (Georgs Befund: idealerweise hüpft nur der Boden, nicht die Kamera).
  // Je näher die Karte dem Boden kommt, desto ruhiger tanzen die Cubes unter ihr — dieselbe
  // Mechanik, die im Walk-Modus schon den Läufer schützt, nur mit weichem Übergang.
  let groundCalm = 0.9, calmAmt = 0;
  const CALM_LO = 3.5, CALM_HI = 15;   // voll ruhig unter 3,5 units über Grund, ab 15 voller Tanz
  let skyWorldMix = 0.4, skyExposure = 1, skySpiral = false;
  let quality = Math.min(devicePixelRatio || 1, 2);
  // Kamera-Zustand steht HIER, nicht in der Input-Schicht: das Overlay liest ihn beim Bauen
  // (die Regler zeigen ihren Wert sofort) — später deklariert wäre es ein TDZ-Fehler.
  // **S41 (V9-A):** Zoom, Gier, POV-Mischung und Dock-Einmischung leben im Rig, nicht mehr hier.
  // `pullIn`, `escapeTerrain` und `groundHeightAt` sind Funktions-Deklarationen (gehoistet), also
  // darf das Rig sie schon jetzt geliefert bekommen.
  const camRig = createCameraRig({ THREE, camera, pullIn, escapeTerrain, groundAt: groundHeightAt });
  let rebakeT = 0;
  const scheduleRebake = () => { clearTimeout(rebakeT); rebakeT = setTimeout(() => applyWorld(false), 130); };
  const wp = () => (wc.params || {});
  const tp = (k, d) => (wp()[k] != null ? wp()[k] : d);
  const setTp = (k, v) => { if (wc.params) { wc.params[k] = v; scheduleRebake(); } };

  // ---------------------------------------------------------------- PANEL-KONTEXT (S44b)
  // Die Regler leben in `settings-schema.js`. Damit sie die veränderlichen Runner-Zustände sehen,
  // werden diese an EIN Objekt gebunden — keine Kopie, ein Fenster auf dieselbe Variable.
  // So bleibt der Frame-Pfad unangetastet (er ist gemessen und läuft).
  const S = {};
  const bindS = (name, get, set) => Object.defineProperty(S, name, { get, set, enumerable: true });
  bindS('academyOn', () => academyOn, (v) => { academyOn = v; });
  bindS('artOn', () => artOn, (v) => { artOn = v; });
  bindS('autoMode', () => autoMode, (v) => { autoMode = v; });
  bindS('beatGain', () => beatGain, (v) => { beatGain = v; });
  bindS('blinkGain', () => blinkGain, (v) => { blinkGain = v; });
  bindS('blinkMode', () => blinkMode, (v) => { blinkMode = v; });
  bindS('bpm', () => bpm, (v) => { bpm = v; });
  bindS('calmAmt', () => calmAmt, (v) => { calmAmt = v; });
  bindS('danceMode', () => danceMode, (v) => { danceMode = v; });
  bindS('dockOnArrive', () => dockOnArrive, (v) => { dockOnArrive = v; });
  bindS('flyTime', () => flyTime, (v) => { flyTime = v; });
  bindS('fxBlur', () => fxBlur, (v) => { fxBlur = v; });
  bindS('glyphCard', () => glyphCard, (v) => { glyphCard = v; });
  bindS('glyphCube', () => glyphCube, (v) => { glyphCube = v; });
  bindS('glyphsOn', () => glyphsOn, (v) => { glyphsOn = v; });
  bindS('titleOn', () => titleOn, (v) => { titleOn = v; });
  bindS('titleSubOn', () => titleSubOn, (v) => { titleSubOn = v; });
  bindS('groundCalm', () => groundCalm, (v) => { groundCalm = v; });
  bindS('lastLesson', () => lastLesson, (v) => { lastLesson = v; });
  bindS('lastPass', () => lastPass, (v) => { lastPass = v; });
  bindS('pet', () => pet, (v) => { pet = v; });
  bindS('petId', () => petId, (v) => { petId = v; });
  bindS('petLib', () => petLib, (v) => { petLib = v; });
  bindS('quality', () => quality, (v) => { quality = v; });
  bindS('shadowGain', () => shadowGain, (v) => { shadowGain = v; });
  bindS('shownLive', () => shownLive, (v) => { shownLive = v; });
  bindS('skyExposure', () => skyExposure, (v) => { skyExposure = v; });
  bindS('skySpiral', () => skySpiral, (v) => { skySpiral = v; });
  bindS('skyWorldMix', () => skyWorldMix, (v) => { skyWorldMix = v; });
  bindS('soundOn', () => soundOn, (v) => { soundOn = v; });
  bindS('story', () => story, (v) => { story = v; });
  bindS('storyMode', () => storyMode, (v) => { storyMode = v; });
  bindS('worldSeed', () => worldSeed, (v) => { worldSeed = v; });
  // **Getter statt Werte.** Das Panel wird gebaut, bevor die Eingabe-Schicht und `resize`
  // deklariert sind — ein Objektliteral hätte sie EAGER gelesen und beim Start einen
  // TDZ-Fehler geworfen (genau so gemessen: „Cannot access 'keys' before initialization“).
  const schemaCtx = { S, get cardTitle() { return cardTitle; }, get attachTitle() { return attachTitle; }, get THREE() { return THREE; }, get MODES() { return MODES; }, get STORY() { return STORY; }, get WORLD_SEED() { return WORLD_SEED; }, get academy() { return academy; }, get applyWorld() { return applyWorld; }, get attachGlyphs() { return attachGlyphs; }, get audio() { return audio; }, get auto() { return auto; }, get camRig() { return camRig; }, get cardReg() { return cardReg; }, get curMode() { return curMode; }, get dock() { return dock; }, get flight() { return flight; }, get flyRoute() { return flyRoute; }, get glyphs() { return glyphs; }, get heat() { return heat; }, get hud() { return hud; }, get isWalk() { return isWalk; }, get keys() { return keys; }, get lighting() { return lighting; }, get lines() { return lines; }, get live() { return live; }, get mountPet() { return mountPet; }, get note() { return note; }, get petFace() { return petFace; }, get petKin() { return petKin; }, get post() { return post; }, get renderer() { return renderer; }, get requestMode() { return requestMode; }, get resize() { return resize; }, get rig() { return rig; }, get search() { return search; }, get setTp() { return setTp; }, get sky() { return sky; }, get skyCards() { return skyCards; }, get terrain() { return terrain; }, get tp() { return tp; }, get trails() { return trails; }, get walk() { return walk; } };

  settings = createSettingsOverlay({
    mount: stage,
    eyebrow: 'KFB Travel v9',   // der Runner kennt seine Version, das Overlay nicht

    accent: '#' + new THREE.Color(storyMode.ink).getHexString(),
    onOpen: () => { hud.setEnabled(false); keys.clear(); },
    onClose: () => hud.setEnabled(true),
    sections: buildSections(schemaCtx),
  });

  // ---------------------------------------------------------------- EINGABE (S44c)
  // Tasten, Zeiger, Rad und die Umrechnung in Fahrzeugwerte liegen in `travel-input.js`.
  // Getter statt Werte, weil die Schicht gebaut wird, bevor alles deklariert ist.
  const inputCtx = { get armAudio() { return armAudio; }, get auto() { return auto; }, get camRig() { return camRig; }, get dock() { return dock; }, get flyRoute() { return flyRoute; }, get flyToCard() { return flyToCard; }, get isWalk() { return isWalk; }, get live() { return live; }, get note() { return note; }, get petKin() { return petKin; }, get pickAcademy() { return pickAcademy; }, get renderer() { return renderer; }, get requestMode() { return requestMode; }, get resize() { return resize; }, get search() { return search; }, get settings() { return settings; }, get takeOff() { return takeOff; }, get walk() { return walk; }, get academyOn() { return academyOn; }, get autoMode() { return autoMode; }, get shownLive() { return shownLive; } };
  const travelInput = createTravelInput(inputCtx);
  const keys = travelInput.keys;
  const readInput = (dt) => travelInput.read(dt);
  // Der `resize`-Listener wohnt im Eingabe-Modul (Fenstergröße ist eine Eingabe wie das Rad).
  // Beim Extrahieren stand er kurz an BEIDEN Stellen — gemessen: 2 × `renderer.setSize` für ein
  // Ereignis, 2,2 ms, doppelt neu angelegte Render-Targets. Ein Ereignis, ein Zuhörer.

  // --- RE-ATTACH-WACHE ---------------------------------------------------------
  // Der DC-Runtime kann `#tv-stage` bei einem Template-Re-Render durch einen NEUEN
  // Knoten ersetzen. Unsere Knoten hängen dann an einem Waisen-Stage: `parentElement`
  // stimmt noch, `document.contains()` ist false — Ergebnis war ein leerer blauer Screen,
  // den nur ein Reload heilte (Boot-Reihenfolge-Glück). Statt Glück: jede halbe Sekunde
  // prüfen und alles Eigene ins aktuelle Stage hängen.
  const owned = () => [renderer.domElement, settings.root].filter(Boolean);
  let liveStage = stage, attachT = 0;
  function resize() {
    const w = liveStage.clientWidth || 1, h2 = liveStage.clientHeight || 1;
    renderer.setSize(w, h2);
    camera.aspect = w / h2; camera.updateProjectionMatrix();
    post.setSize(w, h2, renderer.getPixelRatio());
    lines.setAspect(w / h2);
  }
  function keepAttached(dt) {
    attachT += dt;
    if (attachT < 0.5) return;
    attachT = 0;
    if (document.contains(renderer.domElement)) return;
    const s = document.getElementById('tv-stage');
    if (!s) return;
    liveStage = s;
    for (const n of owned()) s.appendChild(n);
    const hudBox = document.getElementById('tv-hud');
    if (hint && !document.contains(hint)) (hudBox || s).appendChild(hint);
    if (strip && !document.contains(strip)) (hudBox || s).appendChild(strip);
    if (search.root && !document.contains(search.root)) s.appendChild(search.root);
    resize();
    camRig.snap();
  }


  // ---------------------------------------------------------------- LOOP
  const _sunOff = new THREE.Vector3(30, 60, 20);
  // Das Dock darf die Kamera nicht mehr SEHEN, nur ihr Bildfeld lesen — was man nicht hat, kann man
  // nicht schreiben. Ein Objekt, wiederverwendet: der Frame-Pfad bleibt allokationsfrei.
  const _view = { fov: 54, aspect: 1 };
  const view = () => { _view.fov = camera.fov; _view.aspect = camera.aspect; return _view; };
  // S41 · Die Kamera-Zwischenvektoren sind in `camera-rig.js` gewandert — mit ihnen die
  // Follow-/POV-/Pull-in-Zustände. Hier bleibt nur, was die Welt betrifft.
  // Deckkraft-Verlauf des Pets: die Materialliste wird EINMAL gesammelt (kein Traverse pro Frame).
  // **Fremde Materialien werden geliehen, nicht umgeschrieben.** Erster Versuch setzte
  // `transparent`/`depthWrite` auf allen Pet-Materialien und "stellte" danach ERFUNDENE Werte her
  // (transparent=false, depthWrite=true). Der Mund lebt aber von seinem eigenen Alpha — Ergebnis war
  // ein weißer Kasten im Gesicht (Georgs Screenshot). Der Pet-Stack besitzt diese Materialien.
  // Also: Originalzustand EINMAL merken, beim Ausblenden nur die Deckkraft fahren, am Ende **exakt**
  // den gemerkten Zustand zurückgeben.
  // Ein Verlauf pro Wurzel, Zustand daran gemerkt. **Die Materialliste wird neu gesammelt, wenn
  // die Zahl der Meshes sich ändert** — der Pet-Stack baut Teile nachträglich (`initParts`), und
  // genau deshalb blieben die OHREN beim Ausblenden kurz stehen und poppten dann weg (Georgs
  // Befund): sie waren im Schnappschuss nicht enthalten.
  const _fades = new WeakMap();
  function fadeApply(root, f) {
    if (!root) return;
    let st = _fades.get(root);
    let meshes = 0; root.traverse((o) => { if (o.material) meshes++; });
    if (!st || st.meshes !== meshes) {
      st = { mats: [], last: -1, meshes };
      const seen = [];
      root.traverse((o) => { if (!o.material) return;
        for (const m of (Array.isArray(o.material) ? o.material : [o.material])) {
          if (seen.indexOf(m) >= 0) continue; seen.push(m);
          st.mats.push({ m, tr: m.transparent, op: m.opacity, dw: m.depthWrite });
        } });
      _fades.set(root, st);
    }
    const a = Math.max(0, Math.min(1, 1 - f));
    root.visible = a > 0.012;
    if (Math.abs(a - st.last) < 0.004) return;   // nur bei echter Änderung anfassen
    st.last = a;
    for (const e of st.mats) {
      if (a > 0.995) { e.m.transparent = e.tr; e.m.opacity = e.op; e.m.depthWrite = e.dw; }
      else { e.m.transparent = true; e.m.opacity = e.op * a; e.m.depthWrite = e.dw && a > 0.6; }
    }
  }
  // Wie stark verdeckt die Detailansicht das Fahrzeug? Ein FAKTOR über `DOCK_TAKES_OVER` herum,
  // keine Schwelle: die alte Fassung sprang bei k = 0,42 von „ganz da" auf „ganz weg".
  let hideAmt = 0;
  const dockHide = (dt) => {
    const want = dock.owns && dock.progress > DOCK_TAKES_OVER - 0.14 ? 1 : 0;
    hideAmt += (want - hideAmt) * Math.min(1, dt * 2.4);   // ~0,6 s in beide Richtungen
    if (want && hideAmt > 0.995) hideAmt = 1;
    if (!want && hideAmt < 0.004) hideAmt = 0;
    return hideAmt * hideAmt * (3 - 2 * hideAmt);
  };
  let apBrakeV0 = 0;
  // Ab diesem Dock-Fortschritt gehört das Bild der KARTE: Pet weg, Flug-Karte weg, keine Streifen.
  // Eine Zahl, ein Ort — vorher stand sie dreimal im Frame-Pfad (0,25 wirksam, 0,42 als toter
  // Zweig, 0,25 bei den Trails), und der Changelog behauptete die unwirksame.
  const DOCK_TAKES_OVER = 0.42;
  let last = performance.now(), synthPhase = 0, synthBeat = 0, lastChunkX = 1e9, lastChunkZ = 1e9, walkBobT = 0, boostPulse = 0, wasGrounded = true, lastStep = 0, rollWasActive = false, aglNow = 30;
  window.__travelPOC = { renderer, scene, camera, flight, walk, rig, petKin, petFace, terrain, sky, heat, hud, lines, post, trails, lighting, petShadow, audio, skyCards, cardReg, auto, academy, live, dock, glyphs, cardTitle, search, camRig, flyToCard, flyRoute, get focusCard() { return focusCard; }, get lastPass() { return lastPass; }, get wc() { return wc; }, get settings() { return settings; }, get story() { return story; }, get mode() { return curMode(); }, setMode: (m) => requestMode(m, 'debug'), get modeOwner() { return modeOwner; }, get contracts() { return contracts; }, get events() { return EV; }, get mgr() { return mgr; }, get pet() { return pet; }, get boostPulse() { return boostPulse; } };
  resize();   // Rendertarget + Speedline-Aspekt einmal auf die echte Stage-Größe setzen
  // ---------------------------------------------------------------- PIPELINE (S44)
  // Die Frame-Reihenfolge ist eine LISTE, kein Kommentar über einer Schleife. Die Schritte selbst
  // bleiben hier als Closures — sie ins Modul zu ziehen hätte 50 Abhängigkeiten durch ein
  // ctx-Objekt geschleift, also dieselbe Kopplung mit mehr Zeilen. Der Manager besitzt die
  // ORDNUNG, nicht die Arbeit.
  const F = { pos: null, speed: 0, bank: 0, pov: false };   // was mehrere Schritte teilen

  function stepFade(dt) {
    // Uhr und Frame-Werte gehören jetzt dem Manager bzw. `F` — hier bleibt nur das Ausblenden.
    F.pos = null; F.speed = 0; F.bank = 0; F.pov = false;
    // S41 · Das Pet wird beim Zoom in den POV AUSGEBLENDET, nicht geschaltet. Ein Boolean an der
    // Schwelle 0,62 war der sichtbare Ruck (Georgs Befund) — jetzt trägt derselbe POV-Faktor,
    // der die Kamera mischt, auch die Deckkraft. `petFadeApply` kennt die Materialien EINMAL.
    // Pet und Flug-Karte gehen denselben Weg: der größere der beiden Verläufe gewinnt
    // (POV-Zoom oder Detailansicht), und beide sind stetig.
    const hide = dockHide(dt);
    if (pet) fadeApply(pet.object3D, Math.max(camRig.petFade, hide));
    if (rig.group && !isWalk()) fadeApply(rig.group, hide);   // am Boden gehört die Karte dem Modus

  }

  function stepFly(dt) {
      // 1) input → 2) vehicle (ground height at the current pet/vehicle world x,z)
      // S22d: läuft der Auto-Pilot, kommt die Eingabe von ihm — dieselben vier Werte,
      // derselbe Controller. Fällt er aus, greift sofort wieder die Hand.
      const apIn = auto.active ? auto.update(dt) : null;
      const input = apIn || readInput(dt);
      const st0 = flight.state;
      // Ruhezone unter der Karte, bevor die Physik rechnet: näher am Boden = ruhigere Cubes.
      const gTop = safeGroundAt(st0.position.x, st0.position.z, 1.4);
      const agl = st0.position.y - gTop;
      const wantCalm = groundCalm * (1 - Math.max(0, Math.min(1, (agl - CALM_LO) / (CALM_HI - CALM_LO))));
      calmAmt += (wantCalm - calmAmt) * Math.min(1, dt * 3);
      aglNow = agl;   // S21: Bodennähe färbt den Fahrtwind (Rumpeln + dunklerer Bandpass)
      terrain.setCalm(st0.position.x, st0.position.z, 22, calmAmt);
      flight.update(dt, input, cardClearance(st0, dt));
      const st = flight.state; F.pos = st.position; F.speed = st.speed;
      // S32c · Anflug-Regie: der Zoom setzt erst ein, wenn der Pilot BREMST — und nur bis
      // knapp über die POV-Schwelle (1.6), damit die Kamera HINEINGLEITET statt in POV
      // umzuschnappen. Der harte Schnitt war die schlechte Transition (Georgs Befund), und
      // das Pet bleibt sichtbar, bis das Dock übernimmt.
      // **Die Anflug-Regie folgt der Flugdynamik, nicht einem Schalter.** Vorher: `braking` →
      // Zoom 2,4, also fuhr man die letzten 34 u mit dem Pet groß im Anschnitt (Georgs Befund).
      // Jetzt zieht sich die Kamera GENAU SO WEIT heran, wie das Pet schon abgebremst hat:
      //   brems = 1 − v/v_anflug   (der Schwung selbst ist die Kurve)
      //   nah   = 1 − dist/bremsweg (nur die letzte Strecke zählt)
      // Solange das Pet fliegt, bleibt der Follow-Abstand — mit Speedlines, Kinetik und allem.
      // Erst wenn es vor der Karte steht, ist der Faktor 1, und dann übernimmt das Dock.
      if (dockOnArrive && academyOn && auto.braking) {
        if (!apBrakeV0) apBrakeV0 = Math.max(8, st.speed);
        // Der Zoom folgt dem ABBREMSEN selbst — das ist „den Schwung nutzen“: solange das Pet
        // fliegt, bleibt der Follow-Abstand (mit Speedlines und Kinetik), und genau in dem Maße,
        // in dem es Tempo abgibt, kommt die Kamera heran. Im settle-Beat steht es vor der Karte,
        // dann ist der Faktor 1 und das Dock übernimmt einen kurzen Weg.
        const slow = Math.max(0, Math.min(1, 1 - st.speed / apBrakeV0));
        const t = auto.settling ? Math.max(slow, 0.7) : slow;
        // Dringlichkeit: die Bremsphase dauert eine bis zwei Sekunden — mit dem gemütlichen
        // Hand-Zoom (1,6/s) wäre die Kamera erst fertig, wenn das Pet längst steht.
        camRig.setZoom(9 + (2.4 - 9) * (t * t * (3 - 2 * t)), 3.4);
      } else if (!auto.active) apBrakeV0 = 0;
      // S10: Landung. Der Flight-Controller entscheidet (Bodenkontakt + kleine Sinkrate +
      // Sinkwille, gehalten), der Runner führt nur aus — und erst nach der Sperrzeit.
      // **Nicht während eines Anflugs oder in der Detailansicht:** ein Auto-Pilot, der eine
      // tief hängende Karte über steigendem Terrain anfliegt, streift den Boden — und landete
      // dann mitten im Anflug im Walk-Modus vor einem Cube (Georgs Befund). Der Modus folgt der
      // Höhe nur, solange die HAND fliegt.
      // Der Antrag steht hier ohne jede Bedingung: die Höhe SCHLÄGT VOR, der Eigentümer
      // entscheidet. Alles, was früher in dieser Zeile stand, ist jetzt eine benannte Regel.
      modeOwner.tick(dt);
      if (st.landed && modeOwner.request('walk', 'altitude').ok) return false;   // Frame endet hier
      heat.update(dt, { mode: 'fly', speed: st.speed, boosting: st.boosting });
      // S2: der Boost-Impuls — schneller Einsatz (9/s), langsames Auslaufen (2,2/s).
      // Er addiert auf die heat-Kopplung: die Welt weitet sich beim Drücken, nicht erst,
      // wenn das Tempo angekommen ist.
      const bp = st.boosting ? 1 : 0;
      if (bp && boostPulse < 0.2) audio.sfx('boost');   // Einsatz, nicht Dauerton
      boostPulse += (bp - boostPulse) * Math.min(1, dt * (bp ? 9 : 2.2));
      const h = heat.value;
      F.bank = st.bank;
      // 3) **S41 · Kamera.** Der Runner rechnet hier nichts mehr: das Dock liefert seinen
      // Beitrag (Ziel + Gewicht), das Rig mischt Follow, POV und Dock und schreibt EINMAL.
      // Die Reihenfolge ist der Punkt — vorher lief das Dock NACH der Kamera und überschrieb
      // das Blickziel hart, während die Position gemischt wurde.
      dock.update(dt, view());
      camRig.updateFly(dt, st, { heat: h, boostPulse, dock: dock.mix });
      F.pov = camRig.pov;
      // S32c · NACH dem Kamera-Block: das Dock mischt die ideale Karten-Ansicht ein.
      // Distanz kommt jeden Frame aus FOV und Seitenverhältnis — damit sitzt die Karte
      // beim Fenster-Resize von selbst richtig, ohne Resize-Handler.
      if (dock.owns) {
        // Selbstheilung: eine gedockte Kamera auf einer Karte, deren Demo gar nicht mehr laufen
        // kann (zu weit weg), behauptet etwas Falsches. Also löst sich das Dock selbst.
        if (dock.card && dock.card.holder.position.distanceTo(st.position) > academy.params.focusDist * 1.8) {
          dock.release(); note('Zu weit weg — Detailansicht gelöst.', 3);
        }
        // Die Pet-Karte flog durch das Bild: in der Detailansicht sitzt die Kamera vor der
        // Lektionskarte, das Fahrzeug kreist unsichtbar weiter — also muss es aus dem Bild.
        // Erst wenn das Dock deutlich übernommen hat, verschwindet die Flug-Karte. Bei 0,25 war
        // das Pet weg, während die Kamera noch unterwegs war — „das Pet verschwindet vor mir".
        F.pov = true;
      }
      // 4) pet on the card → 5) CardRig transform+clip, then pet-kinetics reacts
      if (pet && pet.update) pet.update(dt);
      if (pet) petKin.update(pet, st, dt);
      // Facing zuletzt: im Stand schaut das Pet zu dir, mit Tempo in die Fahrtrichtung.
      if (pet && pet.object3D.visible) {
        petFace.update(dt, { pet, camera, speed01: Math.min(1, st.speed / Math.max(1, flight.params.SPD_MAX)) });
      }
      // Der Barrel-Roll-Winkel entsteht in der Pet-Kinetik, gehört aber der KARTE:
      // rig.sync rollt Karte + Sitz gemeinsam, also dreht das Pet um die Karten-Mitte.
      rig.setBarrelRoll(petKin.barrelRoll.angle);
      // Die Rolle wird hörbar: ein Swish, der über die Stereobreite wandert (S21)
      const rollNow = petKin.barrelRoll.active;
      if (rollNow && !rollWasActive) audio.sfx('roll', 0.9);
      rollWasActive = rollNow;
      rig.sync(st, dt, pet && pet.character);
      // Streifen NACH rig.sync: die Anker sitzen in der Weltmatrix von rig.lean, also
      // tragen sie Bank, Kippung, Kantencurl und Barrel-Roll ohne eigene Kinematik.
      trails.setActive(!(dock.owns && dock.progress > DOCK_TAKES_OVER));   // keine Bänder im Detailbild
      trails.update(dt, rig.lean, camera, { kmh: heat.kmh });
      // S15 · Schatten: der Terrain-Shader projiziert den Werfer entlang des Lichtstrahls auf
      // die Fläche, die wirklich da ist — kein Quad, also kein Schweben an Kanten und kein
      // Flackern bei tanzenden Cubes. Werfer im Flug = die Karte.
      terrain.setCasterGain(shadowGain);
      terrain.setCasters({ x: st.position.x, y: st.position.y, z: st.position.z, r: 1.9 }, null);
      if (pet) {
        const po = pet.object3D.position, ph = Math.max(0, po.y);
        const ps = 0.62 * (1 + ph * 0.55);
        petShadow.place(rig.seat.position.x + po.x, 0.085, rig.seat.position.z + po.z,
          ps, ps * 0.92, 0, shadowGain * 0.5 * Math.max(0, 1 - ph * 0.6));
      } else petShadow.hide();
  }

  function stepWalk(dt) {
      // WALK: same control scheme as flight — W/S move, A/D turn, Q/E strafe, Shift sprint
      const iy = (keys.has('KeyW') ? 1 : 0) - (keys.has('KeyS') ? 1 : 0);
      const ix = (keys.has('KeyE') ? 1 : 0) - (keys.has('KeyQ') ? 1 : 0);
      walk.setInput(ix, iy);
      const turn = (keys.has('KeyA') ? 1 : 0) - (keys.has('KeyD') ? 1 : 0);
      walk.update(dt, { turn, sprint: keys.has('ShiftLeft') || keys.has('ShiftRight') }, groundHeightAt);
      const ws = walk.state; F.pos = ws.position; F.speed = ws.moving ? 6 : 0;
      aglNow = Math.max(0, ws.position.y - groundHeightAt(ws.position.x, ws.position.z));
      // Rettung: steckt das Pet trotz allem in einer Säule (hüpfender Cube, harter Modus-Wechsel),
      // heben wir es auf die höchste Oberfläche im Körperumkreis — nie stumm darin stehen lassen.
      const safeY = safeGroundAt(ws.position.x, ws.position.z, 0.62);
      if (ws.position.y < safeY - 0.06) walk.lift(safeY);
      heat.update(dt, { mode: 'walk', speed: ws.speed, sprinting: ws.sprinting, airborne: !ws.onGround });
      boostPulse += (0 - boostPulse) * Math.min(1, dt * 2.2);   // kein Boost am Boden
      if (trails.active) trails.setActive(false);                // keine Karte, keine Streifen
      // Am Boden wirft das PET — Körpermitte als Werfer, damit der Schatten am Fuß ansetzt
      // und nicht als runder Fleck daneben liegt.
      terrain.setCasterGain(shadowGain);
      terrain.setCasters({ x: ws.position.x, y: ws.position.y + 0.85, z: ws.position.z, r: 0.95 }, null);
      petShadow.hide();
      const h = heat.value;
      F.bank = ws.turnRate * 0.22;
      // cubes hold still around the walker so they can't swallow or punch through the pet
      terrain.setCalm(ws.position.x, ws.position.z, 26, 1);
      // third-person orbit cam — Zoom bis 0 = POV. **S41:** derselbe Rig, dieselbe eine
      // Schreibstelle; der Orbit-Zustand (Abstand, Pitch, Yaw-Offset) bleibt beim Walk-Controller.
      dock.update(dt, view());
      camRig.updateWalk(dt, ws, { heat: h, eyeUp: walk.eyeUp, recenter: (d) => walk.recenterView(d), dock: dock.mix });
      F.pov = camRig.pov;
      // pet walks on the ground: walk cycle, lean, jump/land squash, facing
      // ORDER IS CANON: motor first (mixer/face/rig), our kinetics last so the
      // lean + world position win over PetMotion's rotation.z damping.
      if (pet) {
        if (pet.update) pet.update(dt);
        petKin.updateWalk(pet, ws, dt);
      }
      // S21 · Schritte, Sprung, Landung als Hörereignisse. Die Schrittzählung kommt aus der
      // Pet-Kinetik (dort läuft der Gehzyklus) — sonst sitzen die Tritte auf einem zweiten Takt.
      if (!ws.onGround && wasGrounded) audio.sfx('jump', 0.9);
      if (ws.onGround && !wasGrounded) audio.sfx('land', Math.min(1.4, 0.5 + (ws.impact || 0) * 0.05));
      wasGrounded = ws.onGround;
      if (petKin.stepCount !== lastStep) {
        lastStep = petKin.stepCount;
        if (ws.onGround) audio.sfx('step', ws.sprinting ? 1.1 : 0.8);
      }
  }

  function stepWorld(dt) {
    // shared: terrain streaming (only on chunk crossing) + colour/beat + sky + sun
    const cx = Math.round(F.pos.x / terrain.CHUNK), cz = Math.round(F.pos.z / terrain.CHUNK);
    if (cx !== lastChunkX || cz !== lastChunkZ) { terrain.recenter(F.pos.x, F.pos.z); lastChunkX = cx; lastChunkZ = cz; }
    synthPhase += dt * (bpm / 60);
    if (synthPhase >= 1) { synthPhase -= 1; synthBeat = 1; }
    synthBeat *= Math.exp(-dt * 5.5);
    // S20: EIN Takt-Ausgang. Läuft Ton, kommt die Eins aus dem Track (plus dessen Bassband);
    // ohne Ton bleibt der synthetische Takt — kein zweites System, nur eine andere Quelle.
    audio.update(dt, { heat: heat.value, rate: heat.rate, mode: curMode(), agl: aglNow, camera });
    // S22: Karten wandern mit der Welt mit und weichen nach vorn, wenn man sie hinter sich lässt
    if (!academyOn) {
      skyCards.setCenter(F.pos.x, F.pos.z);
      skyCards.setForward(!isWalk() ? flight.state.forward.x : Math.sin(walk.state.facing || 0),
                          !isWalk() ? flight.state.forward.z : Math.cos(walk.state.facing || 0));
      skyCards.update(dt, camera, F.pos);
      // Artwork gepaced: ein PDF-Render alle 2,5 s, nur wenn das Bild flott läuft (dt < 40 ms) und
      // die Welt steht. Ein Seitenrender kostet Hunderte Millisekunden auf demselben Thread —
      // ungepaced kostet er die Bildrate.
      if (artOn && (artT += dt) > 2.5 && dt < 0.04) { artT = 0; skyCards.pumpArt(F.pos, 520); }
      skyCards.recycle(F.pos);
    } else {
      // S31 · Die Akademie. Blätter werden gepacet gemalt (zwei pro Auftrag, nächstgelegen
      // zuerst, nur bei flottem Bild) — dieselbe Regel wie der Artwork-Pacer.
      // Die Welt hält still, solange ein Anflug läuft oder die Detailansicht steht — sonst
      // flieht das Ziel mit der eigenen Bewegung mit.
      academy.setFollowEnabled(!auto.active && !dock.owns);
      academy.update(dt, camera, F.pos);
      if (glyphsOn) glyphs.update(dt);
      if (titleOn) cardTitle.update(dt);
      if ((sheetT += dt) > 0.35 && dt < 0.04) { sheetT = 0; if (!academy.pumpSheets(F.pos, 2)) academy.pumpPreviews(F.pos); }
      // Live-Wunsch mit Hysterese: eine laufende Demo darf nicht sterben, weil man einen
      // Meter zu weit driftet — sonst startet und stirbt sie beim Vorbeiflug dreimal.
      const keep = shownLive && shownLive.holder.position.distanceTo(F.pos) < academy.params.focusDist * 1.8;
      const wantCard = academy.focused || (keep ? shownLive : null);
      if (live.enabled && wantCard && live.canRun(wantCard.data.example)) live.want(wantCard);
      else if (!keep) live.want(null);
    }
    // Gate ist „Uhr läuft", nicht „Graph gebaut": sonst ist der synthetische Takt ab dem ersten
    // Ton-Einschalten dauerhaft weg, auch wenn der Context suspendiert oder stumm ist.
    const rawBeat = (audio.running ? Math.max(audio.beat, audio.pulse) : synthBeat) * beatGain;
    const rawEnergy = 0.28 + heat.value * 0.4;
    const chanB = (m) => (m === 'beat' || m === 'both' ? rawBeat : 0);
    // 'steady' ist die Stellung für den reinen Flow: eine KONSTANTE Amplitude, die weder am
    // Takt noch am Reisetempo hängt — das Boden-Animationsmuster für sich, wie in der
    // three.js-Demo. Ohne diese Stellung war Flow ohne Musik nicht einstellbar (Georgs Notiz).
    const chanE = (m) => (m === 'steady' ? 0.55 : (m === 'speed' || m === 'both' ? rawEnergy : 0));
    const drive = {
      beat: chanB(danceMode), energy: chanE(danceMode),
      glowBeat: chanB(blinkMode), glowEnergy: chanE(blinkMode), glowGain: blinkGain,
    };
    terrain.update(dt, drive);
    sky.follow(camera);
    sky.update(dt, { beat: rawBeat, energy: rawEnergy });   // der Himmel hört weiter den ganzen Takt
    sun.position.copy(F.pos).add(_sunOff); sun.target.position.copy(F.pos);
    lighting.follow(F.pos);

    // S31 · Der RTT-Pass läuft VOR dem Post-Pass. Sobald die Szene in einen Puffer geht,
    // ist es zu spät, in einen anderen zu zeichnen — und `renderer.info` wäre danach der
    // Bildschirm-Quad, nicht die Lektion.
    if (academyOn) {
      live.render(dt);
      if (live.card !== shownLive) {
        if (shownLive) academy.clearLive(shownLive);
        shownLive = live.card;
        if (shownLive) academy.setLive(shownLive, live.texture);
      }
    }
    if ((stripT += dt) > 0.2) { updateStrip(stripT); stripT = 0; }

  }

  function stepRender(dt) {
    // S2 · REIHENFOLGE: Szene → Radial-Blur → Speedlines → Würfel.
    // Der Blur ist quadratisch an `heat` gekoppelt (Reisetempo bleibt scharf) plus
    // einem Anteil aus dem Boost-Impuls; bei 0 rendert `post` direkt auf den Schirm.
    const hi = Math.max(0, (heat.value - 0.30) / 0.70);
    post.setStrength(fxBlur * (hi * hi * 0.075 + boostPulse * 0.035), dt);
    post.render(scene, camera);
    lines.update(dt, { heat: heat.value, rate: heat.rate, pulse: boostPulse });
    lines.render(renderer);
    // S7: HUD-Würfel als LETZTER Pass in einem Scissor-Viewport — nie verdeckt, nie geblurrt
    const warpNow = !isWalk() ? (flight.state.warp || 0) : 0;
    hud.update(dt, { kmh: heat.kmh, heat: heat.value, rate: heat.rate, bank: F.bank,
                     mode: warpNow > 0.35 ? 'WARP' : (F.pov ? 'POV' : '') });
    hud.render(renderer);
  }

  const mgr = createTravelManager({
    renderer,
    steps: [
      ['attach', (dt) => keepAttached(dt)],
      ['fade', stepFade],
      // Ein Schritt, zwei Modi — der Eigentümer sagt, welcher gilt. Die Kamera steckt noch im
      // Fahrzeug-Schritt: sie zu lösen heißt, `st`/`h` als Frame-Werte zu führen — eigener Slice.
      ['vehicle', (dt) => (isWalk() ? stepWalk(dt) : stepFly(dt))],
      ['world', stepWorld],
      ['render', stepRender],
    ],
  });
  mgr.start();
}

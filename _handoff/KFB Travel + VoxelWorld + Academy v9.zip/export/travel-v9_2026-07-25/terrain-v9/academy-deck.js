// ============================================================================
// academy-deck.js — KFB Travel · Slice S31/S32a · Würfelakademie als Daten
// ----------------------------------------------------------------------------
// **Echter Lern-Content statt mehr Juice.** Die 30 Lektionen sind nicht erfunden:
// sie sind 1:1 das Curriculum der KFB Cube Academy v1
// (`uploads/KFB Cube Academy v1/KFB Cube Academy v1.html`, const CHAPTERS) —
// fünf Kapitel × sechs Lektionen, jede mit ihrer three.js-Beispiel-Id und dem
// Renderer-Tag (GL = klassisches WebGL, GPU = WebGPU/TSL, KFB = eigenes Stück).
// Die sechste Fläche des Kapitel-Würfels war „Meta"; hier wird sie der HUB.
//
// KANON aus der Academy: Kapitel = Story-Modus = Zonenfarbe, und innerhalb eines
// Kapitels **hell (leicht) → dunkel (schwer)**. Im Himmel wird daraus die HÖHE.
//
// S32a — DIE KARTE IST EINE FLÄCHE, KEIN FORMULAR.
// Vorher trug das Blatt ein Kopfband und ein Fenster; jetzt zeigt es vollflächig,
// was es zu zeigen hat (Live-Demo · three.js-Vorschaubild · Zonenfeld), und
// Titel/Meta schweben daneben (Voxel-Glyphen, S32b). Daraus folgt die Technik:
//  · **Silhouette als `alphaMap`** — die wobbly Kartenkante wird ausgestanzt
//    (`alphaTest`, harte Kante, kein Glow), nicht ins Bild gemalt. Damit ist sie
//    auch über einer Render-Textur unregelmäßig.
//  · **Tusche als DECAL** — ein zweites Quad davor trägt NUR die Linie, sonst
//    transparent. Kanontreu: „Tusche liegt auf der Bildebene, nicht am Objekt."
//  · **Die Linie ist der Kanon, kein Eigenbau:** `kfb-ink.js` (SSOT im
//    Projektwurzel), `inked`-Stil mit den Gewichten aus rollercoaster-v11
//    (baseW = min(w,h)·0.032 · jit = ·0.014 · wob 0.5 · #191410).
//    Der vorige Eigenbau war eine Jitter-Schleife mit konstanter Breite — also
//    ein verrauschtes Rechteck, keine Tusche.
// ============================================================================

import { MODES } from './world-context.js';
import './kfb-ink.js';   // IIFE, registriert window.KFBInk — für CHIPS (Post-it), nicht für Karten
import { brushLoop, inkTail, inkHalfWidth } from './ink-tail.js';

const INKAPI = window.KFBInk;
const INK = '#191410', PAPER = '#efe6d0', CREAM = '#f7f0dd';

export const SHEET_AR = 1.79;
// Vier Kanten-Seeds statt 31: „pro Element ein stabiler Seed" bleibt erfüllt (Reload =
// gleiche Kante), aber Maske und Decal werden geteilt — 8 Texturen für 31 Karten.
const SEEDS = [7, 23, 41, 59];
export const seedFor = (route) => SEEDS[(route | 0) % SEEDS.length];

export const CHAPTERS = [
  { nr: '01', titel: 'Bewegung', sub: 'Animation & Charakter', mode: 'heroic', lekt: [
    ['Keyframe-Animation', 'webgl_animation_keyframes', 'GL', 'KEYFRAME'],
    ['Viele Tänzer', 'webgl_animation_multiple', 'GL', 'CROWD'],
    ['Clips überblenden', 'webgl_animation_skinning_blending', 'GL', 'BLEND'],
    ['Morph-Mimik', 'webgl_animation_skinning_morph', 'GL', 'MORPH'],
    ['Inverse Kinematik', 'webgl_animation_skinning_ik', 'GL', 'IK RIG'],
    ['Physik-Charakter', 'physics_rapier_character_controller', 'GL', 'WALKER'],
  ] },
  { nr: '02', titel: 'Masse, Form & Welt', sub: 'Geometrie & Instancing', mode: 'comic', lekt: [
    ['Instancing', 'webgl_instancing_dynamic', 'GL', 'INSTANCING'],
    ['Formen-Galerie', 'webgl_geometries', 'GL', 'SHAPES'],
    ['Terrain aus Noise', 'webgl_geometry_terrain', 'GL', 'TERRAIN'],
    ['Terrain abtasten', 'webgl_geometry_terrain_raycast', 'GL', 'RAYCAST'],
    ['Log-Tiefenpuffer', 'webgl_camera_logarithmicdepthbuffer', 'GL', 'DEPTH'],
    ['TSL-Nebel', 'webgpu_custom_fog_background', 'GPU', 'FOG'],
  ] },
  { nr: '03', titel: 'Partikel, VFX & Look', sub: 'WebGPU / TSL', mode: 'mystical', lekt: [
    ['Attractor-Partikel', 'webgpu_tsl_compute_attractors_particles', 'GPU', 'ATTRACTOR'],
    ['Linked Particles', 'webgpu_tsl_vfx_linkedparticles', 'GPU', 'LINKED'],
    ['Tornado-VFX', 'webgpu_tsl_vfx_tornado', 'GPU', 'TORNADO'],
    ['TSL-Erde', 'webgpu_tsl_earth', 'GPU', 'EARTH'],
    ['Radial Blur', 'webgpu_postprocessing_radial_blur', 'GPU', 'BLUR'],
    ['Light Probes', 'webgl_lightprobes_complex', 'GL', 'PROBES'],
  ] },
  { nr: '04', titel: 'Interaktion & Steuerung', sub: 'Greifen, Fahren, Einbetten', mode: 'absurd', lekt: [
    ['Drag-Controls', 'misc_controls_drag', 'GL', 'DRAG'],
    ['Fly-Controls', 'misc_controls_fly', 'GL', 'FLY'],
    ['Physik-Basics', 'physics_rapier_basic', 'GL', 'PHYSICS'],
    ['Fahrzeug-Physik', 'physics_rapier_vehicle_controller', 'GL', 'VEHICLE'],
    ['YouTube in 3D', 'css3d_youtube', 'GL', 'VIDEO'],
    ['CSS3D + WebGL', 'css3d_mixed', 'GL', 'CSS3D'],
  ] },
  { nr: '05', titel: 'Klang', sub: 'Audio & Rhythmus', mode: 'tragic', lekt: [
    ['FFT-Visualizer', 'webaudio_visualizer', 'GL', 'FFT'],
    ['Räumlicher Klang', 'webaudio_orientation', 'GL', 'SPATIAL'],
    ['Timing & Rhythmus', 'webaudio_timing', 'GL', 'TIMING'],
    ['Klang-Sandbox', 'webaudio_sandbox', 'GL', 'SANDBOX'],
    ['GPU-Audio', 'webgpu_compute_audio', 'GPU', 'GPU AUDIO'],
    ['KFB Jukebox', 'kfb_jukebox', 'KFB', 'JUKEBOX'],
  ] },
];

export const HUB = { nr: '··', titel: 'Meta', sub: 'Übersicht & Werkstatt', mode: 'forbidden' };

const modeOf = (key) => MODES.find((m) => m.key === key) || MODES[3];
const hex = (n) => '#' + n.toString(16).padStart(6, '0');

// 31 Lektionskarten als flache Liste, in Routen-Reihenfolge (Kapitel-weise, leicht → schwer).
export function academyDeck() {
  const out = [];
  CHAPTERS.forEach((ch, c) => {
    const m = modeOf(ch.mode);
    ch.lekt.forEach((L, i) => {
      out.push({
        kind: 'lesson', chapter: c, index: i, route: c * 6 + i,
        nr: ch.nr, chapterTitle: ch.titel, chapterSub: ch.sub,
        title: L[0], example: L[1], tag: L[2], glyph: L[3],
        deck: 'Kapitel ' + ch.nr + ' · ' + ch.titel,
        mode: ch.mode, ink: m.ink, panel: m.panel, modeName: m.name,
        depth: i / 5, visited: false,
      });
    });
  });
  const hm = modeOf(HUB.mode);
  out.push({ kind: 'hub', chapter: 5, index: 0, route: 30, nr: HUB.nr,
             chapterTitle: HUB.titel, chapterSub: HUB.sub, title: 'Die Akademie', glyph: 'ACADEMY',
             example: 'kfb_academy_hub', tag: 'KFB', deck: 'Meta · Übersicht',
             mode: HUB.mode, ink: hm.ink, panel: hm.panel, modeName: hm.name, depth: 0.5, visited: false });
  return out;
}

// Vorschaubild = der offizielle Screenshot des three.js-Beispiels. Das ist die dritte
// Sprosse der Fallback-Leiter (Zonenfarbe → Feld → Vorschau → LIVE) und stammt aus der
// Cube Academy, wo die Würfelflächen genau diese Bilder trugen. Eigene Stücke (kfb_*)
// haben keins — dort bleibt das Zonenfeld.
export function previewURL(example) {
  if (!example || example.indexOf('kfb_') === 0) return null;
  return 'https://threejs.org/examples/screenshots/' + example + '.jpg';
}

// ---------------------------------------------------------------- Tusche & Silhouette
// **Die Kartenkante ist `inkTail`, nicht `drawInkOutline`.** Das ist der Kern des Fehlers,
// den ich dreimal an den Parametern gesucht habe: `kfb-ink.js` hat ZWEI Familien.
//   · `inkChip`/`drawInkOutline` (`inked`): per-Punkt-Zufallsversatz + gestrichene Polylinie.
//     Richtig für Buttons, HUD-Chips, **Post-its** — und dort sah es auch immer richtig aus.
//   · `inkTail` (ink-tail.js, 1:1 aus rollercoaster-v11): **gefülltes Band** mit variabler
//     Halbbreite, Wobble = zwei langwellige Sinus über den Umfang mit Ecken-Fade, plus
//     diagonaler Taper. **Das ist die Karte.**
// Eine gestrichene Polylinie mit Punktrauschen kann nie wie ein Pinselband aussehen — egal,
// wie man jit und baseW dreht. Deshalb steht das hier so ausführlich.
//
// EINE normalisierte Kontur pro Seed, geteilt von Maske, Decal und Feld-Clip (sonst sieht man
// zwei Kanten und dazwischen Lücken). Die Form ist ohnehin auflösungsunabhängig: die Bandbreite
// ist `0.0069·min(W,H)` und der Wobble hängt am Umfangs-Parameter, nicht an der Punktzahl.
const CONTOUR_REF = 1024;
const INK_WOB = 1.4, INK_BOW = 1.4;   // Kanon aus v11: wobble 1.4
const _contours = {};
function normContour(seed) {
  if (_contours[seed]) return _contours[seed];
  const W = CONTOUR_REF, H = Math.round(W / SHEET_AR), m = 14;
  const pts = brushLoop(m, m, W - m, H - m, seed, INK_WOB, INK_BOW);
  _contours[seed] = pts.map((p) => [p[0] / W, p[1] / H]);
  return _contours[seed];
}
export function contourAt(seed, W, H) { return normContour(seed).map((p) => [p[0] * W, p[1] * H]); }
const pathOf = (g, pts) => { g.beginPath(); g.moveTo(pts[0][0], pts[0][1]); for (let i = 1; i < pts.length; i++) g.lineTo(pts[i][0], pts[i][1]); g.closePath(); };

// Silhouette als alphaMap: weiß innen, schwarz außen. Das Band liegt MITTIG auf der Kontur,
// die Fläche darf also um die kleinste vorkommende Halbbreite nach außen — nicht mehr, sonst
// blitzt sie an den dünnen Stellen über die Tusche.
export function maskTexture(THREE, seed, W) {
  W = W || 512; const H = Math.round(W / SHEET_AR);
  const c = document.createElement('canvas'); c.width = W; c.height = H;
  const g = c.getContext('2d');
  g.fillStyle = '#000'; g.fillRect(0, 0, W, H);
  const pts = contourAt(seed, W, H);
  const half = inkHalfWidth(pts, W, H, seed);
  g.fillStyle = '#fff'; g.strokeStyle = '#fff';
  g.lineJoin = 'round'; g.lineCap = 'round'; g.lineWidth = half.min * 1.6;
  pathOf(g, pts); g.fill(); g.stroke();
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.NoColorSpace; t.anisotropy = 2;
  return t;
}

// Tusche-Decal: NUR das Band auf transparentem Grund, auf DERSELBEN Kontur wie die Maske.
export function decalTexture(THREE, seed, W) {
  W = W || 1536; const H = Math.round(W / SHEET_AR);
  const c = document.createElement('canvas'); c.width = W; c.height = H;
  const g = c.getContext('2d');
  inkTail(g, contourAt(seed, W, H), W, H, seed);
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 8;
  return t;
}

// Post-it: der Besuch als Beweisstück, nicht als Punktestand. Zonenfarbe, kanonischer
// Tusche-Chip (kfb-ink HUD-Rezept: baseW 4 · wob .5 · jit 1.6), und drei blasse Linien —
// dort landen später die Studiennotizen.
export function postitTexture(THREE, d, W) {
  W = W || 256; const H = W;
  const c = document.createElement('canvas'); c.width = W; c.height = H;
  const g = c.getContext('2d');
  const m = 10;
  INKAPI.inkChip(g, m, m, W - m, H - m, 100 + (d.route | 0) * 7,
    { fill: hex(d.panel), uniform: true, baseW: 4, wob: 0.5, jit: 1.6, color: INK });
  g.save();
  g.beginPath(); g.rect(m, m, W - 2 * m, H - 2 * m); g.clip();
  g.fillStyle = hex(d.ink); g.globalAlpha = 0.92;
  g.textAlign = 'center'; g.font = Math.round(H * 0.115) + 'px "Special Elite", monospace';
  g.fillText('BESUCHT', W / 2, H * 0.3);
  g.globalAlpha = 0.26; g.strokeStyle = hex(d.ink); g.lineWidth = Math.max(1, W * 0.006);
  for (let i = 0; i < 3; i++) {
    const y = H * (0.47 + i * 0.14);
    g.beginPath(); g.moveTo(W * 0.16, y); g.lineTo(W * 0.84, y); g.stroke();
  }
  g.globalAlpha = 0.55; g.font = Math.round(H * 0.075) + 'px "Special Elite", monospace';
  g.fillText(d.glyph || '', W / 2, H * 0.91);
  g.restore();
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 8;
  return t;
}

// Zonenfeld: der Wartezustand, jetzt VOLLFLÄCHIG. Kein Kopfband, kein Fenster —
// Zonenfarbe, Kapitelnummer als Wasserzeichen, das Kurzwort (das in S32b zu Würfeln
// wird) und die Beispiel-Id. Auf die Kontur geclippt, damit kein Pixel über die
// Silhouette hinausläuft.
export function fieldTexture(THREE, d, W) {
  W = W || 512; const H = Math.round(W / SHEET_AR);
  const c = document.createElement('canvas'); c.width = W; c.height = H;
  const g = c.getContext('2d');
  const pts = contourAt(seedFor(d.route), W, H);
  const ink = hex(d.ink), panel = hex(d.panel);
  g.save(); pathOf(g, pts); g.clip();
  g.fillStyle = panel; g.fillRect(0, 0, W, H);
  // Diagonale Schraffur in der Zonenfarbe — das Feld ist erkennbar ein Platzhalter
  g.globalAlpha = 0.13; g.strokeStyle = ink; g.lineWidth = W * 0.014;
  for (let x = -H; x < W + H; x += W * 0.055) { g.beginPath(); g.moveTo(x, 0); g.lineTo(x + H, H); g.stroke(); }
  g.globalAlpha = 1;
  // Kapitelnummer als Wasserzeichen
  g.fillStyle = 'rgba(25,20,16,.14)'; g.textAlign = 'left'; g.textBaseline = 'alphabetic';
  g.font = '700 ' + Math.round(H * 0.86) + 'px "Irish Grover", Georgia, serif';
  g.fillText(d.nr, W * 0.035, H * 0.93);
  // Kurzwort groß (wird in S32b zu Voxel-Glyphen über der Karte)
  g.fillStyle = 'rgba(25,20,16,.82)'; g.textAlign = 'center';
  let s = Math.round(H * 0.28);
  for (let i = 0; i < 12; i++) { g.font = '700 ' + s + 'px "Irish Grover", Georgia, serif'; if (g.measureText(d.glyph).width <= W * 0.8) break; s = Math.round(s * 0.92); }
  g.fillText(d.glyph, W / 2, H * 0.52);
  g.fillStyle = 'rgba(25,20,16,.55)';
  g.font = Math.round(H * 0.062) + 'px "Special Elite", monospace';
  g.fillText(d.example, W / 2, H * 0.68);
  g.fillStyle = ink;
  g.font = Math.round(H * 0.06) + 'px "Special Elite", monospace';
  g.fillText('[' + d.tag + ']', W / 2, H * 0.8);
  g.restore();
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 8;
  return t;
}

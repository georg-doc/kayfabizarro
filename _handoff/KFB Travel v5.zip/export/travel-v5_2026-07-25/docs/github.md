repo: georg-doc/kayfabizarro
branch: main
path: media/3D_Assets

## Analysed (not imported)
repo: dannylimanseta/tinyskies
branch: cursor/globefly-multiplayer-globe-flight-game (NICHT main — daher 404 bei naiven Zugriffen)
tree: 2659a5cc987d
note: nur gelesen, kein Code kopiert. Ergebnis in "KFB TinySkies Analyse.dc.html".

## Last sync
date: 2026-07-24T19:43:11Z

### Updated in this project
- Walk-Achsen entdreht: A/D drehen, Q/E straften seitenverkehrt (heading-Vorzeichen + right = cross(forward, up)).
- Auto-Hop läuft nicht mehr in den Cube: Körper-Radius-Kollision, vorausschauender Absprung (v = √(2g·(rise+clear))) mit ~90 ms Anticipation.
- Pet-Kinetik nach cartoon-motion_v1: Anticipation → Launch → Apex-Hang → Fall → Land-Squash → Rebound, volumenerhaltend (Sxz = 1/√Sy), für Fly UND Walk gleich.
- GLB-Clip-Layer aus EMBED_CUBE_PET_FULL_v2 §5 verdrahtet: idle/walk/run mit speed-gematchter timeScale, `static` in der Luft, initParts() für Ohren/Schweif-Follow-Through.

## Screen map
| Screen / file | Built from |
|---|---|
| KFB Travel v4.dc.html → terrain-v4/pet-kinetics.js | media/3D_Assets/build/pet-motion.v2.js, skills/cartoon-motion_v1.md, media/3D_Assets/GLB_cube-pets/EMBED_CUBE_PET_FULL_v2.md |
| terrain-v4/walk-controller.js | EMBED_CUBE_PET_FULL_v2.md §5/§7f (Bundle-Grammatik), cartoon-motion_v1.md |
| terrain-v4/kfb-pets.js (Spiegel) | media/3D_Assets/kfb-pets.js |
| KFB TinySkies Analyse.dc.html | dannylimanseta/tinyskies@2659a5cc (SpeedLines, Trail, Contrails, CarpetDriftSmoke, CarpetWake, CameraRig, FlightControls, Plane, RimLight, GodRays, SkyPresets, TerrainSurface, RingCollectVFX) |

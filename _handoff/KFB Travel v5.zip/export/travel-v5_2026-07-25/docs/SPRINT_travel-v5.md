# SPRINT — KFB Travel v5 · FX & Regie

**Lebendes Dokument.** Status wird HIER gepflegt, nicht im Code. Jede Runde (auch in einem
frischen Chat) trägt ihr Ergebnis ein und schreibt eine Zeile in `docs/CHANGELOG_travel.md`.

- **Entry:** `KFB Travel v5.dc.html` → `terrain-v5/travel-poc.js`
- **Vorgänger:** `KFB Travel v4.dc.html` / `terrain-v4/` — **FROZEN**, nicht mehr anfassen
- **Grundlage:** `KFB TinySkies Analyse.dc.html` (Report, §04 Bausteine, §06 Reihenfolge)
- **Pet-Kanon:** `media/3D_Assets/GLB_cube-pets/EMBED_CUBE_PET_FULL_v2.md` (§7f Bundles, §15 Bloom)
- **Motion-Kanon:** `skills/cartoon-motion_v1.md`

---

## Was ein frischer Chat zuerst lesen muss

1. Diesen Sprintplan (Status-Tabelle + der eine Slice, der dran ist).
2. Den TinySkies-Report, Abschnitt zum jeweiligen Slice — dort stehen die konkreten Zahlen.
3. `terrain-v5/travel-poc.js` (Runner, Frame-Reihenfolge) und das Modul, das der Slice anfasst.

**Nicht** die ganze `terrain-v5/` lesen. Ein Slice pro Runde, additiv, keine Nebenumbauten.

## Unverhandelbare Regeln in diesem Sprint

| Regel | Warum |
|---|---|
| **Frame-Reihenfolge:** `pet.update(dt)` ZUERST, unsere Kinetik DANACH | PetMotion schreibt `inner.scale` und dämpft `rotation.z`; wer vorher schreibt, verliert |
| **Kein additives Weiß.** Effekte tragen die Story-`ink`-Farbe, Bloom-Schwelle respektieren oder eigener Layer | Embed-Doc §15 — genau hier verglühen sonst wieder die Pet-Augen |
| **Keine Allokation im Frame.** Scratch-Vektoren im Modul-Scope | TinySkies' einziger echter Fehler; wir übernehmen ihn nicht |
| **Ein Pool pro Effekt**, feste Größe, Ring-Zeiger, Attribut-Arrays | Kein Nachladen, kein GC-Ruckler |
| **Pfad-Hygiene:** jeder Asset über kanonische RAW-URL | sonst ist der Standalone-Export schwarz |
| **Prime Directive:** jeder Effekt ist Interpunktion und settlet in Ruhe | kein Dauer-Zappeln, kein Casino |
| Jedes neue Modul: `update(dt, …)` · `reset()` · `dispose()` · optional `preWarm()` | Modul-Disziplin wie der Rest von `terrain-v5/` |

---

## Status

**Empfohlene Reihenfolge:** S1 → **S7 → S8** → S2 → S3 → S4 → S5 → S6.
Das Control-Panel (S7/S8) kommt VOR den FX-Slices, weil es die Tuning-Oberfläche für S2–S6 ist —
sonst werden Speedline-Dichte, Rim-Intensität und Staubmenge im Code erraten statt am Bild justiert.
Die IDs bleiben stabil (sie werden referenziert), nur die Reihenfolge ist neu.

| # | Slice | Status | Datei(en) | Runde |
|---|---|---|---|---|
| S0 | v5 angelegt (Fork von v4) | **✅ erledigt** | `KFB Travel v5.dc.html`, `terrain-v5/*` | 2026-07-24 |
| S1 | Regie-Skalar `travelHeat` | **✅ erledigt** | `travel-heat.js` (neu), `travel-poc.js` | 2026-07-24 |
| S7 | HUD-Würfel (Instrument + Menü) | **✅ erledigt** | `hud-cube.js` (neu), `travel-poc.js`, `voxel-terrain.js` | 2026-07-24 |
| S8 | Settings-Overlay + Steuerungs-Legende | **✅ erledigt** | `settings-overlay.js` (neu), `travel-poc.js` | 2026-07-24 |
| S9 | Monitor-Würfel: Embeds (YouTube / Demo / Chat) | **offen (später)** | `hud-cube.js`, DOM-Overlay | — |
| S2 | Speedlines + Boost-Regie | **offen** | `speed-lines.js` (neu), `pet-kinetics.js`, `travel-poc.js` | — |
| S3 | Rim-Light auf Pet, Karte, Cubes | **offen** | `rim-light.js` (neu), `card-carrier.js`, `voxel-terrain.js` | — |
| S4 | Staub- & Splitter-Pool | **offen** | `fx-pool.js` (neu), `pet-kinetics.js`, `walk-controller.js` | — |
| S5 | Story-Presets konsolidieren | **offen** | `world-context.js`, `skydome-shader.js`, `voxel-terrain.js` | — |
| S6 | Portal-Swirl als Modus-Tor | **offen** | `mode-portal.js` (neu), `card-carrier.js` | — |
| S10 | Modus ohne Schalter (WoW-Logik) | **offen → v6** | `travel-poc.js`, `flight-controller.js`, `walk-controller.js` | — |
| S11 | Rahmen: Wortmarke links, Meta rechts | **offen → v6** | `KFB Travel v5.dc.html` → v6, `themes/kfb-med.css` | — |
| S12 | Würfel v2: kleiner, Abnutzung, Pet-Farbe | **offen → v6** | `hud-cube.js`, `kfb-pets.js` (lesen) | — |

Status-Vokabular: `offen` · `in Arbeit` · `✅ erledigt` · `geparkt (Grund)`.

---

## S1 · Ein Regie-Skalar — ✅ erledigt 2026-07-24

**Gebaut.** `terrain-v5/travel-heat.js`. Reisetempo belegt die unteren 17 % der Skala, darüber
`t·(2−t)` bis 1; Boost hebt auf mindestens 0,72, Sprungphase im Walk gibt +0,10. Drei Ausgänge:
`value` (geglättet, 3/s — für Kamera/FOV/Dichten), `rate` (d/dt, 6/s — für Einsätze: Spawn-Bursts,
Squash-Kicks), `kmh` (geeichte Anzeige).

**Eichung, damit der Tacho nicht wieder lügt.** Ein Terrain-Cube ist `CELL = 3` Weltunits und liest
sich als ein Block, den das Pet (≈1,7 units) hüpft → **1 unit ≈ 0,5 m** (`unitMeters`, der einzige
Eich-Regler). Damit: Gehen ≈ 10 km/h · Sprint ≈ 17 km/h · Reiseflug ≈ 16 km/h · Vollgas ≈ 76 km/h.

**Angeschlossen.** Kamera-Dolly (`camDist + h·1.6`), Kamerahöhe (`+ h·1.4`), Look-Ahead (`+ h·3.4`),
FOV (`54 + h·13` im Flug, `56 + h·6` im Walk, POV unberührt), Walk-Chase (`c.dist + h·0.9`),
Terrain-Energie (`0.28 + h·0.4`). Die alten `st.speed`-Formeln sind **ersetzt**, nicht ergänzt.

**Zugriff.** `window.__travelPOC.heat` → `.value` · `.rate` · `.kmh` · `.state`.

## S1-Original (Grundriss, zur Nachvollziehbarkeit)

**Ziel.** Eine normalisierte 0..1-Größe `travelHeat`, an der jeder Effekt hängt — statt sechs
Sonderverdrahtungen. Ohne diesen Slice wird jeder folgende teurer.

**Grundriss.** Ein winziges Modul mit Zustand, gespeist pro Frame aus Speed, Boost-Timer,
Kartennähe und (im Walk) Sprint. Reisetempo belegt bewusst nur die unteren ~17 % der Skala, der
Rest ist Boost — mit `t·(2−t)`-Easing im Boost-Segment, damit der Einsatz knallt und das Ende
ausläuft. Geglättet mit ~3/s, damit Kamera und FOV nicht zappeln. Zusätzlich ein `heatRate`
(d/dt), analog zu `bankRate` in der Pet-Kinetik: Effekte, die auf den *Einsatz* reagieren
(Speedline-Spawn, Squash-Kick), lesen die Rate, nicht den Wert.

**Akzeptanz.** `window.__travelPOC.heat` liefert in beiden Modi eine stetige 0..1-Zahl; Standlauf
= 0, Reisetempo ≈ 0,17, Boost → 1; kein Sprung beim Fly⇄Walk-Wechsel; Kamera-Dolly und FOV hängen
messbar daran (alte Speed-Formeln ersetzt, nicht danebengelegt).

**Quelle.** Report §01 „Die eine Zahl" und §04 D.

## S2 · Speedlines + Boost-Regie

**Ziel.** Der Boost wird ein Ereignis, nicht eine Zahl: vier Dinge gleichzeitig.

**Grundriss.**
1. **Speedlines** als zweiter Render-Pass: eigene `Scene` + `OrthographicCamera(−1,1,1,−1)`,
   24 vorgebaute Quads, nach dem Hauptbild ein `render()` mit `autoClear = false`. Streifen starten
   bei Radius 0,95–1,10 vom Zentrum, wandern 15 % ihrer Lebenszeit nach innen, Länge 0,35–0,84,
   Lebensdauer 0,3–0,7 s, Alpha per `smoothstep` rein und raus, Spawnrate `0.02 + (1−heat)·0.08`.
   Ab `heat > 0.7` wächst die Streifenbreite bis auf das Fünffache. **Farbe = Story-`ink`**, nicht
   Weiß; Deckkraft-Deckel 0,35; unter der Bloom-Schwelle halten oder eigener Layer.
2. **Barrel-Roll** des Pets: genau eine 360°-Rotation um die Flugachse über die Boost-Dauer,
   danach zurück auf 0. Läuft über die bestehende Roll-Feder in `pet-kinetics.js`, nicht daneben.
3. **Kamera fällt zurück:** Distanz +0,6 und Höhe +0,15 skaliert mit `travelHeat`, FOV +20°.
4. **Kurven-Drag fällt weg** während des Boosts (sonst kostet Lenken Tempo) — der Boost fühlt sich
   *freier* an, nicht nur schneller.

**Akzeptanz.** Boost aus dem Stand: Streifen erscheinen innerhalb von 2 Frames, das Pet dreht
genau einmal, die Kamera weitet sichtbar, nach dem Boost ist alles in Ruhe. Keine neuen
Konsolen-Warnungen, Augen glühen nicht (Screenshot im Skydome gegen v4 prüfen).

**Quelle.** Report §03 (die vier Ereignisse) und §04 A.

## S3 · Rim-Light ohne Draw-Call

**Ziel.** Ink-Look in 3D: eine Fresnel-Kante auf Pet, Karte und Cubes, gefüttert aus dem Story-Mode.

**Grundriss.** Vier Zeilen GLSL per `onBeforeCompile` vor `dithering_fragment` ins bestehende
Material: Fresnel aus Normale × Blickrichtung, hoch `rimPower` (Start 2,5), mal `rimIntensity`
(Start 0,6), additiv drauf. **Eine geteilte Farb-Uniform** für alle Objekte — ein Zuweisen färbt
die Szene um. Uniform-Objekte über Compile-Zyklen hinweg wiederverwenden, sonst reißt der
Hot-Reload die Werte weg. Farbe = `MODES[n].ink`.

**Akzeptanz.** Draw-Call-Zahl unverändert (`renderer.info.render.calls` vorher/nachher gleich);
Modus-Wechsel färbt Pet, Karte und Cubes in einem Frame um; im hellen Skydome keine Überstrahlung.

**Quelle.** Report §04 C.

## S4 · Staub- & Splitter-Pool

**Ziel.** Der Boden reagiert: Staub beim Landen, Splitter am gestreiften Cube, ein Karten-Trail.

**Grundriss.** Ein Pool-Modul, drei Anwendungen. `Points` mit `gl_PointSize = aSize·(180/−mvPos.z)`,
Pool 120 für Staub / 400 für Trail, Ring-Zeiger, drei Attribut-Arrays pro Frame beschrieben.
Puffs **wachsen** beim Verblassen (0,06 → 0,24) — das ist der Unterschied zwischen Rauch und
Konfetti. Alpha quadratisch aus. Splitter als `InstancedMesh`, 12 Stück, 0,55 s, Dämpfung
`1/(1+t·0.85)`, Schrumpf auf 45 %. Trigger: Landung (`impact` aus dem Walk-Controller),
Auto-Hop-Absprung, Cube-Kontakt (`blocked`). Dazu ein `preWarm()` pro Effekt: Meshes kurz sichtbar,
`renderer.compile()`, wieder verstecken — sonst ruckelt der erste Sprung.

**Akzeptanz.** Erster Sprung ruckelt nicht; Staub sitzt am Fuß, nicht in der Luft; kein
Allokations-Sägezahn im Speicher-Profil über 60 s.

**Quelle.** Report §04 F und G.

## S5 · Story-Presets konsolidieren

**Ziel.** Ein Modus-Wechsel ist ein Datensatz-Wechsel, keine Sonderbehandlung.

**Grundriss.** Die sechs Modi (Tragic … Forbidden) werden je *ein* flaches Objekt: `ink`, `panel`
(haben wir), plus Nebelfarbe und -distanzen, Hemi/Ambient/Sonne/Fill mit Farbe und Intensität,
Boden-/Wasser-Töne, `rimColor`, Wolken-Deckkraft, Sterne-Flag. Tabelle in `world-context.js`,
Anwendung an einer Stelle. Werte für `ink`/`panel` stehen im Embed-Doc §15.6 — nicht neu erfinden.

**Akzeptanz.** Umschalten aller sechs Modi ohne Sonderfall im Runner; Diff zeigt, dass verstreute
Farbkonstanten verschwinden statt sich zu verdoppeln.

**Quelle.** Report §04 E.

## S6 · Portal-Swirl als Modus-Tor

**Ziel.** Der Story-Wechsel bekommt eine Bühne: die Karte fliegt durch einen Wirbel-Ring.

**Grundriss.** Zwei gegenläufig rotierende Tori (≈ +3,5 und −2,8 rad/s), Radien 0,95 und 0,98 des
Portals, dazu ein Energiefeld `sin(a·3 + φ) · sin(a·5 − 1.5φ)` und ein Atem-Wobble auf der
Skalierung (±3 % bei 12 Hz, ±4 % bei 9 Hz). Farbe aus dem *Ziel*-Modus, damit das Tor ankündigt,
wohin es geht. Teuerster Posten des Sprints, größter Schauwert — erst nach S1–S5 anfassen.

**Akzeptanz.** Durchflug in unter 1,5 s, danach ist die Welt im neuen Modus und alles settlet;
Portal wird korrekt disposed (kein Material-Leak bei zehn Wechseln).

**Quelle.** Report §03 Schluss und §04-Inventar (Portal-Swirl).

---

## S7 · HUD-Würfel — ✅ erledigt 2026-07-24

**Gebaut.** `terrain-v5/hud-cube.js`. Eigene Szene + Kamera, gerendert als zweiter Pass in einem
Scissor-Viewport unten rechts (216 px, responsiv bis 140 px) — kein Terrain-Cube kann ihn verdecken.
Körper: `RoundedBoxGeometry` (dynamisch importiert, Fallback `BoxGeometry`) mit der **geteilten
Kanten-Textur aus `voxel-terrain.js`** und Story-Palette; sechs Flächen als `PlaneGeometry` mit
`CanvasTexture` (512², `anisotropy 8`, `center 0.5`).

**Belegung.** `+Z` = Tacho (Startposition, klickt auf Sektion „Reise“) · `+X` Karten · `−X` Musik ·
`+Y` Welt · `−Y` Himmel · `−Z` Pet. Tacho zeigt `heat.kmh` (geeicht), Modus und den Regie-Skalar als
Balken — nicht als zweite Zahl.

**Gelöst wie geplant.** Klick nur bei < 4 px und < 250 ms, sonst Rotation · Trägheit `0.045^dt`, dann
Rastung auf die vorderste Seite · Rückkehr in die Tacho-Position nach 2,5 s Ruhe · Beschriftung
kontert die Drehung in 90°-Schritten über `texture.rotation` (Totband 0,35 rad gegen Flackern) ·
Float ± 3 % und Neigung **gegen** Bank und `heat.rate` (Feder wie in der Pet-Kinetik) · `spinTo(id)`,
`spin()`, `home()`, `setFaceImage(id, url)`, `setPalette()`, `preWarm()`.

**Zwei Dinge, die beim Bauen aufkamen:**
1. **`stopPropagation()` reicht nicht.** travel-poc hört auf demselben Element — das ist AT_TARGET, da
   laufen alle Listener weiter. Der Würfel nutzt jetzt `stopImmediatePropagation()` **plus** eine
   Marke `e.__hudClaimed`, die travel-poc prüft. Verifiziert: Drag auf dem Würfel → `bank = 0`,
   Drag in der Welt → `bank = −0.045`.
2. **Rast-Positionen brauchen eine 3/4-Neigung.** Frontal gerastet liest sich der Würfel als flaches
   Rechteck. Jede Zielorientierung trägt jetzt dieselbe leichte Neigung (`−0.15 / +0.26 rad`), die
   Beschriftung bleibt trotzdem aufrecht.

**Offen aus diesem Slice.** Die Legende ist nach unten LINKS gewandert (Kollision mit dem Würfel) —
weg kommt sie erst mit S8. Klick quittiert bis dahin nur mit einem Toast. Procreate-PNGs ersetzen die
gemalten Glyphen per `setFaceImage`.

**Nachjustiert nach Messung (gleiche Runde).** Zwei Werte waren zu optimistisch:
1. **Schriftgrößen.** Die Fläche ist auf dem Schirm nur ~90–120 px breit; `0.082·S` ergab 7 px —
   Schlieren, kein Menü. Jetzt Labels `0.15·S`, km/h und Modus `0.105·S`, `minSize` 168.
   Gemessen: Fläche 90,7 px, Label 16,6 px, km/h 12 px.
2. **Silhouette.** Bei `bank 0.6` liefen die Neigungs-Federn in ihre Clamps und die Ecke ragte aus
   dem Scissor-Viewport (NDC 1,03). Jetzt Clamps ±0,16 / ±0,12 und Mini-Kamera auf `z = 3.25`.
   Gemessen im Worst Case: NDC 0,773 / 0,805 — rund 19 % Reserve.

**Merksatz für die nächsten Slices:** Schrift in einer Textur ist nicht DOM-Schrift. Vor dem Malen
ausrechnen, wie viele Bildschirm-Pixel eine Textur-Einheit am Ende wirklich hat.

**Nachtrag 2026-07-24 (Georgs Review).**
- **Kein Rahmen mehr.** Die Flächen sind durchgehend, Schrift und Icon sitzen direkt auf dem Papier
  (Fläche deckt 0,955 der Würfelseite, Korpusfarbe = Flächenfarbe → keine sichtbare Kante).
  Der schwarze Rahmen ist damit frei für seine echte Aufgabe: die **unsichtbare Clip-Maske** für
  Embeds (YouTube, nicht-quadratische Bilder) — gedanklich vorgemerkt für S9.
- **Oberfläche.** Seamless Papier-Relief aus dem Repo (`Textures/Paper003`, das leichteste Set) als
  `normalMap` + `roughnessMap` auf Korpus und Flächen. Die Terrain-Kanten-Textur (`edge3`) ist
  dafür ungeeignet, weil sie eine Rand-Textur ist und nicht kachelt.
- **Texturen sitzen jetzt AUF der Geometrie.** Erst lagen sechs Planes VOR den Würfelseiten — das
  liest sich als aufgeklebte Schilder, und ihre eckigen Ecken ragen über die gerundete Silhouette,
  wodurch die Rundkanten optisch verschwinden. Jetzt trägt die `RoundedBoxGeometry` selbst sechs
  Materialien (sie erbt von `BoxGeometry`, also auch deren sechs Gruppen und UVs), Klick-Erkennung
  über `intersection.face.materialIndex`. **Folge für die Gestaltung:** die UV einer Seite schließt
  die Rundung ein → Inhalt braucht ~12 % Sicherheitszone (`hud.safeZone`), auch in Georgs PNGs.
- **Größen final gemessen:** Würfel-Viewport 196–240 px, Seite 107 px auf dem Schirm, Label 18,2 px,
  km/h 12,3 px; Worst Case (Spin + max. Neigung) NDC 0,825 — 17 % Reserve zum Anschnitt.
- **Tacho mit Nadel.** Halbkreis-Skala mit acht Teilstrichen (die letzten zwei in Ink = Redline),
  Zeiger auf `travelHeat`, Zahl und Einheit darunter, Modus oben. Löst den Rest-Balken bei 0 km/h:
  die Nadel steht auf dem linken Anschlag statt eines Balken-Stummels.

## S7-Original (Grundriss, zur Nachvollziehbarkeit)

**Ziel.** Das HUD wird ein Gegenstand statt einer Textwand: ein Würfel unten rechts, der im Ruhe­
zustand **Instrument** ist (Tacho) und beim Anfassen **Menü** wird (sechs Funktionsseiten). Die
KFB-Ikonografie trägt das ohne Erklärung: sechs Seiten, sechs Story-Modi, der D6 ist die Marke.

**Technik: three.js-Overlay — Entscheidung revidiert (2026-07-24).** Erste Empfehlung war CSS-3D.
Mit Georgs zwei Anforderungen fällt das weg: (1) das Design soll **1:1 die Terrain-Cubes** sein —
Borders und Kanten-Textur sind unser `ShaderMaterial` mit `uEdge`, kein CSS-Effekt; (2) für Quest und
Story-Mode soll der **Ugur-D6** dienen — ein GLB, also ein Mesh-Wechsel, kein Skin-Hack.
Dazu existiert die Mechanik in der **Cube Academy** bereits fertig gebaut.

**Referenz-Implementierung: `uploads/KFB Cube Academy v1/KFB Cube Academy v1.html`.** Vor Baubeginn
lesen — die vier Teile, die wir übernehmen:

| Was | Wie es dort gelöst ist |
|---|---|
| Geometrie | `RoundedBoxGeometry(D, D, D, 6, D*0.07)`, dynamisch importiert, Fallback auf `BoxGeometry` |
| Seiten-Inhalt | pro Seite eine `CanvasTexture` (`colorSpace = SRGBColorSpace`, `anisotropy = 8`) — frei bemalbar, später genauso mit PNG-Decal |
| Ziel-Fläche anfahren | `cube.quaternion.slerp(targetQuat, 1 - 0.0022^dt)`, Ziel gelöscht bei `angleTo < 0.004` |
| Freies Tumbeln | Drag-Geschwindigkeit klingt mit `0.045^dt` aus, dann übernimmt langsames Eigen-Tumbeln |

**Und der wichtigste Trick von dort:** der eigentliche Embed (YouTube, three.js-Demo, Chat) läuft
**nicht auf der Würfelfläche, sondern in einem DOM-Overlay** (`#face` mit `<iframe>`), das beim Klick
auf die Fläche aufgeht — die Würfelseite trägt nur das gemalte Vorschaubild. Damit haben wir scharfe
Schrift und echte iframes, ohne die 3D-Konsistenz zu verlieren. Genau dieses Muster trägt später den
„In-Game-Monitor“ (S9).

**Render-Pfad.** Eigene `Scene` + Kamera, zweiter `render()` mit `autoClear = false` (dasselbe Muster
wie die Speedlines in S2) — so kann kein Terrain-Cube den HUD-Würfel verdecken. Klicks per Raycast
gegen diese Mini-Szene. Kosten: ein Draw-Call plus der Würfel.

**Flächen-Gestaltung.** Material und Kanten-Textur aus `voxel-terrain.js` wiederverwenden (geteilte
`uEdge`-Textur, Story-Palette pro Seite) → der HUD-Würfel ist sichtbar aus derselben Welt geschnitten.
Darauf ein **transparentes PNG als Decal** je Funktion (Georg, Procreate → `media/kfb/hud/`,
quadratisch, gleiche Sicherheitszone). Bis die PNGs liegen: Text plus einfaches Comic-Glyph auf der
Canvas-Textur, gleiche Platzierung — der Tausch ist dann ein URL-Wechsel.

**Die sechs Fallen und ihre Lösung** — das ist der eigentliche Inhalt dieses Slices:

1. **Drehen vs. Klicken.** Jeder Drag, der auf einer Seite endet, liest sich sonst als Klick.
   Regel: Klick feuert nur bei Weg < 4 px UND Dauer < 250 ms; alles andere ist Rotation. Beim
   Loslassen **rastet der Würfel auf die nächste Seite** (nie schräg stehen bleiben) — das macht
   die Seiten gleichzeitig lesbar.
2. **Der Tacho ist die Startposition, nicht eine Seite.** (Georgs Fassung, 2026-07-24 — in der Cube
   Pet Academy als three.js-Embed schon einmal gebaut, Zip folgt.) Default-Ansicht = Tacho-Seite.
   Wer die Musik ändern will, dreht bis das Noten-Icon vorn ist und klickt. **Nach ~2,5 s ohne
   Klick oder Drehung fährt der Würfel langsam in die Tacho-Startposition zurück** — das Instrument
   ist immer der Ruhezustand, ohne dass es eine zweite Anzeige braucht. Der Sockel-Ring bleibt als
   Option, falls sich das Rückdrehen im Test zu langsam anfühlt.
3. **Beschriftung immer richtig herum.** Icons und Text auf den sichtbaren Flächen kontern die
   Würfeldrehung in 90°-Schritten (Smartphone-Logik) — egal wie gedreht, alles Sichtbare ist
   lesbar. In CSS-3D ein Counter-Transform pro Face-Inhalt.
4. **Spin-Flip als eigene Geste.** Ein kurzer Wisch dreht den Würfel schnell durch und lässt ihn
   ausrasten. Brauchen wir später zweimal: **Story-Mode auswürfeln** (Ergebnis = Würfelaugen) und
   **Quest-Fortschritt** anzeigen. Deshalb muss die Rotations-Mechanik von Anfang an eine
   Ziel-Orientierung anfahren können (`spinTo(face)`), nicht nur freies Drag.
5. **Verborgene Affordanz.** Drei Seiten sind immer unsichtbar, und niemand dreht freiwillig. Also:
   ein langsames Idle-Kreisen (±12°) zeigt, dass es mehr gibt; beim ersten Start ein einmaliger
   Hinweis; und **jede Funktion ist auch ohne Würfel erreichbar** (Tastenkürzel + Navigation im
   Overlay selbst). Der Würfel ist die schöne Tür, nicht die einzige.
6. **Trefferflächen und Mobil.** 44 px Minimum pro Seite heißt ~150 px Würfelkante. Unten rechts
   auf Desktop in Ordnung; auf Mobil schrumpft er unter die Schwelle → dort wird er ein einzelner
   Button, der das Overlay auf der letzten Sektion öffnet (Würfel bleibt sichtbar, aber nicht
   drehbar).

**Design des Würfels (offen, Empfehlung).** Drei Kandidaten standen zur Wahl: Sky-D6, Terrain-Voxel,
oder Swap je Funktion. **Empfehlung: Swap — aber als EIN Objekt mit zwei Registern**, und das
Register sagt, was der Würfel gerade IST:

| Register | Skin | Wann |
|---|---|---|
| **Werkzeug** | Terrain-Voxel: Material + Kanten-Textur 1:1 aus `voxel-terrain.js`, Seiten in den Story-Farben, PNG-Decal je Funktion | Default: Tacho + die sechs Funktionsseiten |
| **Orakel** | Ugur-D6 (`dice_ugur_lowpoly.glb`, lädt schon in `dice-sky.js`) mit Würfelaugen, leicht glühend | Story-Mode auswürfeln, Quest-Fortschritt |
| **Monitor** | dunkle Glas-Seite, Vorschaubild auf der Canvas-Textur, Inhalt im DOM-Overlay | CME / Academy / Bloom-Level (→ S9) |

Der **Spin-Flip ist der Übergang** zwischen beiden — er rollt und wechselt das Register in derselben
Bewegung. Praktisch spricht dasselbe dafür: eine Voxel-Fläche ist eine ruhige Farbfläche und damit
ein guter Untergrund für Icons; Würfelaugen und Icons auf derselben Seite streiten sich.
Semantisch: **Voxel = Werkzeug (Welt), D6 = Schicksal (Story).**

**Eine ehrliche Einschränkung.** Der Würfel liegt damit im WebGL-Pfad: Flächen-Beschriftung ist eine
Canvas-Textur, kein DOM-Text. Bei kleinen Schriftgrößen muss die Textur groß genug sein
(512² pro Seite, `anisotropy = 8` wie in der Academy), sonst wird es weich. Deshalb: Beschriftung
groß und kurz, Details gehören ins Overlay, nicht auf die Würfelseite.

**Seiten.** Karten · Musik · Welt (Terrain) · Himmel · Pet · Reise (Kamera/Tempo). Alle sechs
öffnen erstmal dasselbe Overlay und markieren dort ihre Sektion (aufgeklappt + dezenter Highlight).

**Leben.** Der Würfel floatet (±3 px, ~2,8 s) und macht die Reisebewegung dezent mit: Neigung aus
`bank` und `heat.rate` über dieselbe Feder-Funktion wie die Pet-Kinetik — **Gegenbewegung**, nicht
Mitbewegung (Trägheit), sonst wirkt er angeklebt. Beim Boost ein kurzer Squash-Impuls.

**Akzeptanz.** Drehen ohne versehentliche Klicks (10 Drags = 0 Fehlklicks); Rastung immer auf einer
lesbaren Seite; Rückkehr in die Tacho-Position nach ~2,5 s Ruhe; Beschriftung auf allen sichtbaren
Flächen aufrecht; `spinTo(face)` funktioniert programmatisch (Vorbereitung für den Story-Würfel);
Tacho **geeicht** (`heat.kmh`); alle sechs Seiten per Tastatur erreichbar; auf 390 px Breite kein
Element unter 44 px; die Legende ist aus dem HUD verschwunden.

**Vorlage.** Die Mechanik ist in `uploads/KFB Cube Academy v1/KFB Cube Academy v1.html` fertig
gebaut (Slerp-Targeting, Drag-Trägheit, Rastung, DOM-Overlay für Embeds) — vor Baubeginn lesen und
portieren, nicht neu erfinden. Die Screenshots in `uploads/KFB Cube Academy v1/qa/` zeigen den
Zielzustand.

## S10 · Modus ohne Schalter — WoW-Logik (v6)

**Georgs Vorschlag, 2026-07-25.** Doppelte Leertaste = abheben · `X` (oder Pfeil runter) = sinken ·
Bodenkontakt = zurück in Walk.

**Warum das besser ist als `F`.** Der Modus hört auf, ein Schalter zu sein, und wird eine **Folge der
Höhe**. Damit fällt die Frage „in welchem Modus bin ich?" weg — man sieht es. Das ist die
Voraussetzung dafür, dass S11 die Modus-Anzeige überhaupt streichen darf: erst die Mechanik, dann
das Weglassen. Umgekehrt wäre es eine Lücke.

**Der Konflikt, den es zu lösen gilt.** Die Leertaste ist heute dreifach belegt: Boost im Flug, Sprung
am Boden, und neu Abheben. Auflösung nach Kontext, nicht nach Sonderfall:

| Zustand | Leertaste einmal | Leertaste zweimal (< ~280 ms) |
|---|---|---|
| Boden | Sprung (wie heute) | **Abheben** — Sprung geht in Steigflug über |
| Luft | Boost (wie heute) | Boost, kein Sonderfall |

Das Abheben ist damit kein neuer Befehl, sondern ein **verlängerter Sprung** — genau die Lesart, die
die Sprung-Grammatik aus v4 schon hat (Anticipation → Launch), nur ohne Landung. `pet-kinetics.js`
kann den Übergang deshalb ohne neuen Zustand fahren.

**Sinken und Landen.** `X` und Pfeil runter senken die Zielhöhe. Der Wechsel nach Walk feuert bei
**Bodenkontakt mit kleiner Sinkrate** — nicht bei Berührung allein, sonst kippt ein Streifschuss über
einen Cube-Gipfel mitten im Flug in den Laufmodus. Schwellwert und Hysterese gehören in den
Flight-Controller, nicht in den Runner.

**`F` bleibt** als direkter Umschalter. Nicht aus Nostalgie: wer mit Tastatur schlecht zurechtkommt
oder testen will, braucht einen Weg ohne Timing-Fenster.

## S11 · Rahmen: Wortmarke links, Meta rechts (v6)

**Ziel.** Oben links die **KayfaBizarro-Wortmarke** (wie im Rollercoaster-Ride), oben rechts Titel und
Meta klein in der Subline-Schrift. Die Modus-Anzeige verschwindet ganz — aus dem HUD und von der
Tacho-Seite.

**Quelle steht schon.** `themes/kfb-med.css` → `.kfb-wordmark` („Kayfa" in Tinte, „Bizarro" cream auf
Akzent, harter Schatten, leichte Kippung). Kein Nachbau, keine SVG-Zeichnung: Klasse übernehmen.

**Reihenfolge beachten.** Die Modus-Anzeige darf erst fallen, wenn S10 steht — sonst nimmt man dem
Spieler die Auskunft und gibt keine Mechanik zurück, die sie ersetzt.

## S12 · Würfel v2: kleiner, abgenutzt, in Pet-Farbe (v6)

**Vier Änderungen.** Ein Drittel kleiner · kein ALLCAPS, Special Elite für alle Würfel-Texte ·
Abnutzung (Kratzer, abgeriebene Kanten) als Decal · Grundfarbe = **helle Version der Base-Color des
aktiven Pets**.

**Die Pet-Farbe ist bereits abfragbar** — kein neuer Vertrag: `resolvePet(lib, id).color`, für
FrizzleBob `#d3a244`. Aufgehellt (~L 88 %) ergibt das genau das helle Gelb, das Georg erwartet. Der
Würfel wird damit zum Anzeiger, *wessen* Reise das ist, und färbt beim Pet-Wechsel mit — dieselbe
Mechanik wie `setPalette()` heute für den Story-Mode. **Offene Entscheidung:** Pet-Farbe und
Story-Palette wollen beide die Grundfläche. Vorschlag: Pet-Farbe gewinnt die Fläche, Story-Palette
behält Nadel und Akzente — so bleiben beide lesbar.

**Die Spannung, die dabei zu lösen ist — ehrlich vorab.** Ein Drittel kleiner heißt: Seitenbreite
von 107 px auf ~71 px. Nach der Messung aus S7 fällt ein Label von 18 px auf 12 px. Das ist die
Untergrenze und sieht bei Special Elite (schreibmaschinen-dünn) schlechter aus als bei einer
fetteren Schrift. Zwei Wege, und sie schließen sich nicht aus:
1. **Icon zuerst, Text nur vorn.** Auf den fünf Menüseiten trägt das PNG die Bedeutung, Text nur als
   kleine Unterzeile — oder gar nicht. Dann ist 12 px unkritisch, weil niemand darauf angewiesen ist.
2. **Zwei Drittel nur im Ruhezustand.** Beim Anfassen wächst der Würfel auf die alte Größe (eine
   Feder auf `screenFrac`) und schrumpft nach der Rückkehr in die Tacho-Pose wieder. Das ist die
   ehrlichere Lösung: klein, solange er Instrument ist; groß, solange er Menü ist.

Damit hängt S12 an Georgs PNGs — bis die liegen, bleibt der Text tragend und der Würfel sollte im
Menü-Zustand wachsen.

## S9 · Monitor-Würfel: Embeds im Würfel (später)

**Ziel.** Eine Würfelseite wird ein Bildschirm: YouTube-Video, three.js-Demo oder LLM-Chat —
skalierbar wie ein In-Game-Monitor. Trägt später CME/Academy-Inhalte und die Bloom-Level-Leiter.

**Grundriss.** Genau das Academy-Muster: Würfelseite trägt ein gemaltes Vorschaubild, Klick öffnet
ein DOM-Overlay mit `<iframe>` (`allow="autoplay; fullscreen; encrypted-media"`), Flip zeigt die
Rückseite mit Text/Lektionen, Schließen setzt `src = 'about:blank'` (sonst läuft das Video weiter).
Skalierung: das Overlay wächst von der Flächen-Bounding-Box auf Vollbild — in der Academy ohne
Face-Tracking gelöst (bewusst, weil Tracking bei Rotation zittert).

**Voraussetzung.** S7 und S8 stehen; der Inhalts-Katalog (welche Videos/Demos/Chats) ist eine
Daten-Frage, kein Code — Registry-JSON wie `PARTIKEL_MIT_YOUTUBE_Playlist_v1.md`.

## S8 · Settings-Overlay — ✅ erledigt 2026-07-24

**Gebaut.** `terrain-v5/settings-overlay.js` — DOM-Overlay, das seine Sektionen als **Daten** vom
Runner bekommt (der weiß, was echt regelbar ist). Control-Arten: `slider` · `select` (Optionen dürfen
eine Funktion sein, für spät geladene Listen wie die Pets) · `toggle` · `button` · `text` · `info`
(Live-Wert) · `keys` (Legenden-Tabelle). Papier-Panel auf `inset:3vh 2.6vw`, Spiel läuft dahinter
weiter (Blur), Esc und Klick daneben schließen, `Tab` öffnet, Würfelklick öffnet mit markierter
Sektion. Werte aktualisieren sich alle 260 ms, solange offen — nicht pro Frame.

**Sektionen (nur echte Regler, keine Zukunftsversprechen):**

| Sektion | Was wirklich passiert |
|---|---|
| **Karten** | Story-Modus → neuer WorldContext, Terrain rebaked, Himmel + HUD-Würfel in der neuen Palette (Vorgriff auf S5) |
| **Rhythmus** | Tempo (BPM) und Beat-Kopplung des synthetischen Takts, der Cube-Tanz und Himmel treibt |
| **Reise** | Fly⇄Walk, Höchsttempo Flug, Lauftempo, Kamera-Abstand, POV, **Tacho-Eichung** (`unitMeters`), Live-Anzeige km/h + heat |
| **Welt** | Rauheit, Höhenskala, Wasserlinie, Farbversatz, Cube-Tanz — Rebake 130 ms nach dem Loslassen (debounced) |
| **Himmel** | zehn Varianten, Welt-Mischung, Belichtung, Hypno-Spirale |
| **Pet** | alle Pets aus dem Vertrag; Wechsel disposed das alte (Vertrag §12.6: ein Augenpaar) |
| **Steuerung** | konsolidierte Legende beider Modi — dafür ist sie aus dem HUD verschwunden |
| **System** | Seed (Text + neu würfeln), Auflösung, Alles zurücksetzen |

**HUD danach.** Nur noch Titel, Modus-Badge (`FLY`/`WALK`) und Würfel — plus **eine** Hinweiszeile,
die nach 8 s ausblendet und in späteren Sitzungen nicht mehr auftaucht (`localStorage`-Flag).

**Zwei Dinge, die beim Bauen auffielen:**
1. **TDZ statt Bequemlichkeit.** Das Overlay liest beim Bauen alle Werte (damit jeder Regler sofort
   seinen Wert zeigt) — `zoomTarget` war aber erst weiter unten in der Input-Schicht deklariert:
   `ReferenceError: Cannot access 'zoomTarget' before initialization`. Der Kamera-Zustand steht jetzt
   vor dem Overlay. Merksatz: wer Werte beim Bauen liest, muss vor dem Bauen deklariert sein.
2. **Tasten gehören dem Formular.** Solange das Overlay offen ist, schluckt es Key-Events in der
   Capture-Phase und der Runner ignoriert sie — sonst tippt man im Seed-Feld die Karte durchs Bild.
   Der Würfel wird per `setEnabled(false)` stillgelegt.
3. **Akzentfarbe gehört an EINE Stelle.** Erst waren `accent-color` der Slider und die Farbe der
   Live-Werte beim Bauen inline eingebacken — nach einem Story-Wechsel standen orange Regler in
   einem weinroten Panel. Jetzt trägt der Root eine Custom-Property (`--kfb-accent`), die Controls
   lesen `var(--kfb-accent)`, und `setAccent()` zieht mit einem Zuweisen alles nach (verifiziert:
   Slider, Live-Werte, Karten-Rand und Eyebrow wechseln gemeinsam auf `#8f3a5f`).

**Offen.** Deck-Triplet als Weltquelle und echte Jukebox-Tracks bleiben Backlog — eigene Slices,
keine Regler.

## S8-Original (Grundriss, zur Nachvollziehbarkeit)

**Ziel.** Ein fast flächendeckendes Overlay, in dem alle Regler nach **Wichtigkeit und Cluster**
liegen statt nach Entstehungsreihenfolge — und in dem die Steuerungs-Legende für **alle** Travel-Modi
konsolidiert unten steht.

**Vorlage.** Das Tweak-Panel aus `KFB Terrain + Skydome v3` (`terrain-poc.js`) hat die Regler-Menge
schon bewiesen. Übernommen wird die Regler-Mechanik, **nicht** das Layout: ein langes
Schieberegler-Band ist eine Tuning-Konsole, kein Interface.

**Cluster, nach Häufigkeit sortiert** (oben links = am häufigsten angefasst):

| Sektion | Inhalt |
|---|---|
| **Karten** | Deck, Triplet, Story-Modus (der D6) |
| **Musik** | Track, Lautstärke, Beat-Kopplung |
| **Reise** | Tempo, Boost, Kamera-Abstand, POV, Fly⇄Walk |
| **Welt** | Terrain-Roughness, Höhenskala, Wasser, Seed |
| **Himmel** | Sky-Preset, Bloom, Würfel-Himmel |
| **Pet** | Pet-Wahl (sobald S-Backlog), Emote, Clip-Test |
| **Steuerung** | die konsolidierte Legende: Flug UND Boden, eine Tabelle |

**Regeln.** Das Spiel läuft **hinter** dem Overlay weiter (halbtransparent + Blur) — sonst fühlt es
sich an wie Rauswerfen aus der Welt. `Esc` und ein Klick daneben schließen. Jeder Regler zeigt
seinen Wert; geänderte Werte gelten sofort (keine „Anwenden“-Taste). Seltenes und Riskantes (Seed,
Qualität, Reset) sitzt unten. Keine Emoji-Icons, KFB-Typografie (Special Elite / Archivo / Baloo).

**Aus dem HUD entfernt.** Die zwei Legenden-Blöcke (Flug- und Walk-Badge-Text). Ersatz: **eine**
Zeile Hinweis, die nach ~8 s der ersten Sitzung ausblendet, plus die Sektion „Steuerung“ im Overlay.
Ganz weglassen wäre falsch — ohne Legende findet niemand `F`, `J`, `Q`/`E`.

**Akzeptanz.** Alle heute im Code hart verdrahteten Werte, die wir in S2–S6 tunen wollen, sind hier
regelbar; Overlay öffnet/schließt ohne Frame-Einbruch; auf 390 px Breite scrollt es sauber in einer
Spalte; das HUD zeigt danach nur noch Titel, Modus-Badge und den Würfel.

---

## Nicht in diesem Sprint (Travel-Backlog)

| Thema | Notiz |
|---|---|
| Karten-getriebenes Terrain | `world-context.js` kann `CardTriplet → Vektor → Seed`; im Runner steht noch ein fixer Seed + `STORY='heroic'`. **Inhaltlich der wichtigste offene Punkt** — eigener Sprint, weil die SSOT-Logik dranhängt |
| 24-Pet-Auswahl | bisher Bunny hart verdrahtet |
| Anchor-/Landmark-Layer | `world-context.js` erzeugt Anchor-Punkte, nichts rendert sie |
| Echtes Audio | `jukebox-audio.js` liegt bereit, Runner nutzt einen synthetischen Beat |
| Bundle-Matrix an Travel-Events | `greet`/`notice`/`celebrate`/`sleep` an Kartenpassage, Landung, Leerlauf — **nach v5-Export mit Coworker abstimmen** (Georgs Entscheidung 2026-07-24) |
| Reichere Karten-Kinetik | `card-carrier.js`, teilweise vorhanden |
| **Graveyard-Slice übernehmen** | `uploads/KFB Cube Academy v1/Graveyard_Slice1.html` + Kenney-3D-Assets ins Terrain streuen (Scatter-Pfad steht schon, heute Platzhalter-Boxen). Playbook: `uploads/KFB Cube Academy v1/docs/KENNEY_ASSET_PLAYBOOK.md`. **Viel später**, eigener Sprint |

## Bewusst verworfen (nicht wieder vorschlagen)

- **Quaternion-Kugelwelt** — löst ein Problem, das wir nicht haben; unsere Welt ist planar-gechunkt.
- **Partikel-Vortex am Booster** — gibt es in TinySkies gar nicht; der Wirbel-Eindruck kommt aus
  dem Barrel-Roll. Der echte Swirl-Shader gehört ans Modus-Tor (S6).
- **Multiplayer, Upgrades, HP-Balken, Quests** — anderes Spiel. Unsere Karten sind Bedeutung,
  keine Beute.

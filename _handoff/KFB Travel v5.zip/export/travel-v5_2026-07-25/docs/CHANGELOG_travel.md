# CHANGELOG — KFB Travel

Neueste Einträge oben. **Eine Zeile pro Runde, additiv.** Wer einen Slice abschließt, trägt hier
ein und setzt den Status in `docs/SPRINT_travel-v5.md`.

Format: `## YYYY-MM-DD · Version · Titel` → Was · Warum · Dateien · Belege/Offen.

---

## 2026-07-25 · v5 · Session-Cut, Check-in, Übergabe an v6

- **v5 geschlossen** mit S0, S1 (`travelHeat`), S7 (HUD-Würfel), S8 (Settings-Overlay). Dateien:
  `KFB Travel v5.dc.html` + `terrain-v5/` (13 Module).
- **Export:** `export/travel-v5_2026-07-25/` mit `MANIFEST.md`.
- **Neue Slices aus Georgs Review aufgenommen** (alle → v6):
  **S10** Modus ohne Schalter (WoW-Logik: Doppel-Leertaste abheben, `X` sinken, Bodenkontakt → Walk) ·
  **S11** Rahmen (KayfaBizarro-Wortmarke links aus `themes/kfb-med.css`, Meta klein rechts,
  Modus-Anzeige weg) · **S12** Würfel v2 (ein Drittel kleiner, kein ALLCAPS, Special Elite,
  Abnutzungs-Decal, Grundfläche in der aufgehellten Pet-Base-Color).
- **Zwei Abhängigkeiten notiert:** S11 darf die Modus-Anzeige erst streichen, wenn S10 steht (sonst
  fehlt die Auskunft ohne Ersatz). Und S12 senkt die Label-Größe von 18 px auf 12 px — trägt erst mit
  Georgs Icon-PNGs oder mit einem Würfel, der im Menü-Zustand wächst.
- **Nächster Sprint v6:** S2 (Speedlines + Boost) zuerst, dann S10–S12.

## 2026-07-24 · v5 · S8 erledigt: Settings-Overlay + konsolidierte Steuerung

- **Was:** `terrain-v5/settings-overlay.js`. Fast flächendeckendes Papier-Panel, das seine Sektionen
  als Daten vom Runner bekommt; das Spiel läuft dahinter weiter. Acht Cluster nach Häufigkeit:
  Karten (Story-Modus) · Rhythmus (BPM, Beat-Kopplung) · Reise (Fly⇄Walk, Tempi, Kamera, POV,
  Tacho-Eichung, Live-Werte) · Welt (fünf Terrain-Regler, Rebake debounced) · Himmel (zehn Varianten,
  Welt-Mischung, Belichtung, Spirale) · Pet (alle Pets aus dem Vertrag, altes wird disposed) ·
  Steuerung (Legende beider Modi) · System (Seed, Auflösung, Reset).
- **HUD aufgeräumt:** die zwei Legenden-Blöcke sind weg, das Badge zeigt nur noch `FLY`/`WALK`, dazu
  eine Hinweiszeile, die nach 8 s ausblendet und ab der zweiten Sitzung gar nicht mehr erscheint.
- **Story-Modus ist jetzt live schaltbar** — neuer WorldContext, Terrain rebaked, Himmel und Würfel
  in der neuen Palette. Verifiziert mit FORBIDDEN: `storyIdx 5`, Nebel `#503550`, Würfel-Nadel in
  Wein. Capture: `screenshots/v5-forbidden.png`, Overlay: `screenshots/v5-settings.png`.
- **Pet-Wechsel** läuft über denselben Pfad wie der erste Mount (ein Pfad, kein Sonderfall);
  verifiziert mit `fox`.
- **Zwei Fallen:** (1) das Overlay liest beim Bauen alle Werte → `zoomTarget` war weiter unten
  deklariert und riss den Boot mit `ReferenceError: Cannot access 'zoomTarget' before initialization`
  ab; Kamera-Zustand steht jetzt vor dem Overlay. (2) Tasten müssen dem Formular gehören, solange es
  offen ist — sonst fliegt die Karte, während man den Seed tippt.
- **Nachgezogen:** Akzentfarbe läuft jetzt über eine Custom-Property am Root (`--kfb-accent`) statt
  inline eingebacken — vorher blieben Slider-Thumbs und Live-Werte nach einem Story-Wechsel orange in
  einem weinroten Panel. `setAccent()` zieht alles mit einem Zuweisen nach.
- **Dateien:** `settings-overlay.js` (neu), `travel-poc.js`, `flight-controller.js`,
  `walk-controller.js`, `travel-heat.js` (je `setParams`/`params`), `KFB Travel v5.dc.html`.

## 2026-07-24 · v5 · Würfel: Texturen auf der Geometrie statt Planes davor

- **Georgs Befund:** „als wären die Flächen einfach sichtbar davor platziert, dadurch gehen die
  abgerundeten Ecken verloren“. Genau so war es: sechs `PlaneGeometry` vor den Würfelseiten —
  aufgeklebte Schilder, deren eckige Ecken über die gerundete Silhouette ragten (gemessen 2–3 px).
- **Fix:** ein Mesh, sechs Materialien. `RoundedBoxGeometry` erbt von `BoxGeometry` und damit deren
  sechs Material-Gruppen und UVs — die Textur sitzt also direkt auf der gerundeten Fläche. Klick
  läuft jetzt über `intersection.face.materialIndex` statt über Plane-Meshes.
- **Preis, bewusst bezahlt:** die UV einer Seite schließt die Rundkante ein → Inhalt braucht 12 %
  Sicherheitszone (`hud.safeZone`). Steht als Vorgabe für die Procreate-PNGs im Sprintplan.
- **Gemessen nach dem Umbau:** Seite 107 px auf dem Schirm, Label 18,2 px, km/h 12,3 px; Worst Case
  (Spin + maximale Neigung) NDC 0,825 — vorher schnitt der Spin die Silhouette an (1,000).
- **Capture:** `screenshots/v5-hud-cube.png`.

## 2026-07-24 · v5 · Würfel rahmenlos + Tacho-Nadel, drei Walk-Bugs

**Würfel (Georgs Review):**
- Rahmen weg. Flächen sind durchgehend, Schrift und Icon sitzen direkt auf dem Papier (Fläche 0,955
  der Seite, Korpusfarbe = Flächenfarbe). Der schwarze Rahmen ist damit frei für seine echte
  Aufgabe: unsichtbare Clip-Maske für Embeds (S9).
- Oberfläche: `Textures/Paper003` (seamless, leichtestes Set) als `normalMap` + `roughnessMap` —
  der Würfel wirkt nicht mehr wie glattes Plastik. `edge3` wäre falsch: Rand-Textur, kachelt nicht.
- Tacho ist jetzt eine **Nadel-Anzeige** (Halbkreis, acht Teilstriche, letzte zwei als Redline,
  Zeiger auf `travelHeat`). Damit ist auch der Rest-Balken bei 0 km/h weg — die Nadel steht am
  linken Anschlag.

**Bugs:**
1. **Beim Wechsel in den Walk-Mode im Cube gelandet.** Ursache: `walk.reset` bekam EINE
   Höhenprobe aus der Mitte — hüpfende Nachbarsäulen und der Körperradius waren nicht drin. Jetzt
   `safeGroundAt()` (Mitte + 8 Ringproben) plus `terrain.maxLift()` und 0,25 Reserve; die Schwerkraft
   setzt das Pet dann sauber ab. Zusätzlich pro Frame eine **Rettung**: steckt das Pet trotzdem
   tiefer als die Umgebung, hebt `walk.lift()` es auf die Oberfläche.
2. **Pet zeitweise unsichtbar.** Zwei Ursachen, beide behoben: der Kamera-Aufzug
   (`groundHeight + 1`) konnte die Kamera über das Pet heben, sodass sie in den Himmel schaute —
   jetzt gibt es eine Obergrenze, und statt höher wird die Kamera **näher** herangezogen. Und der
   POV-Modus (Zoom bis 0) versteckt das Pet absichtlich, sagte es aber nicht: der Tacho zeigt jetzt
   `WALK·POV` bzw. `FLY·POV`. POV-Blick außerdem weniger steil nach oben.
3. **Roter Rest-Balken bei 0 km/h.** Erledigt mit der Nadel (siehe oben).

- **Dateien:** `terrain-v5/hud-cube.js`, `travel-poc.js`, `walk-controller.js` (`lift()`).
- **Capture:** `screenshots/v5-walk-cube.png`.

## 2026-07-24 · v5 · S7 erledigt: HUD-Würfel

- **Was:** `terrain-v5/hud-cube.js`. Terrain-Würfel unten rechts, zweiter Render-Pass im
  Scissor-Viewport. Ruhezustand = Tacho (geeichte km/h + Modus + Heat-Balken), angefasst = Menü mit
  sechs Funktionsseiten (Karten, Musik, Welt, Himmel, Pet; die Tacho-Seite ist der Reise-Knopf).
  Oberfläche ist die **geteilte Kanten-Textur** aus `voxel-terrain.js` → sichtbar aus derselben Welt.
- **Aus der Academy portiert:** RoundedBox mit Fallback, CanvasTexture pro Seite, Slerp-Targeting,
  Drag-Trägheit. Neu: Rückkehr in die Tacho-Position nach 2,5 s, aufrechte Beschriftung über
  `texture.rotation`, Neigung gegen Bank und `heat.rate`.
- **Zwei Fallen, die beim Bauen auffielen:** `stopPropagation()` reicht nicht, wenn zwei Listener am
  SELBEN Element hängen (AT_TARGET) — jetzt `stopImmediatePropagation()` plus `e.__hudClaimed`-Marke,
  die travel-poc prüft (verifiziert: Würfel-Drag lenkt nicht mehr). Und: frontal gerastet liest sich
  ein Würfel als Rechteck — jede Rast-Position trägt jetzt dieselbe leichte 3/4-Neigung.
- **HUD:** Tastenlegende nach unten links verschoben (Kollision) — sie verschwindet mit S8.
- **Dateien:** `terrain-v5/hud-cube.js` (neu), `travel-poc.js`, `voxel-terrain.js` (`edgeTex`
  exportiert), `KFB Travel v5.dc.html` (Legende links).
- **Nachjustiert nach Messung:** Beschriftung war mit `0.082·S` nur 7 px groß (die Fläche ist auf dem
  Schirm ~90 px breit) → Labels `0.15·S`, km/h und Modus `0.105·S`, `minSize` 168 → gemessen 16,6 px
  bzw. 12 px. Und bei hartem Bank ragte die Würfelecke aus dem Scissor-Viewport (NDC 1,03) →
  Neigungs-Clamps auf ±0,16 / ±0,12, Mini-Kamera auf `z = 3.25` → Worst Case jetzt NDC 0,77 / 0,81.
  **Merksatz:** Textur-Schrift ist keine DOM-Schrift — vorher ausrechnen, wie viele Bildschirm-Pixel
  eine Textur-Einheit hat.

## 2026-07-24 · v5 · S7 revidiert: three.js statt CSS-3D (Cube Academy als Vorlage)

- **Auslöser:** Georg hat die **KFB Cube Academy v1** hochgeladen (`uploads/KFB Cube Academy v1/`) —
  dort ist die Würfel-Mechanik fertig gebaut, und zwei neue Anforderungen kamen dazu: Design 1:1 wie
  die Terrain-Cubes (Borders + Kanten-Textur) und der Ugur-D6 für Quest/Story.
- **Entscheidung gedreht:** CSS-3D scheidet aus — die Terrain-Optik ist ein `ShaderMaterial` mit
  `uEdge`, kein CSS-Effekt, und der D6 ist ein GLB. Also **three.js-Overlay** (eigene Szene, zweiter
  `render()` mit `autoClear=false`, Raycast für Klicks).
- **Aus der Academy übernommen:** `RoundedBoxGeometry(D,D,D,6,D*0.07)` mit `BoxGeometry`-Fallback ·
  `CanvasTexture` pro Seite (`anisotropy = 8`) · `quaternion.slerp(target, 1−0.0022^dt)` mit
  `angleTo < 0.004` als Abbruch · Drag-Trägheit `0.045^dt`, danach Eigen-Tumbeln.
- **Der wichtigste Trick von dort:** Embeds laufen **nicht auf der Würfelfläche**, sondern in einem
  DOM-Overlay mit `<iframe>`; die Fläche trägt nur das gemalte Vorschaubild. Scharfe Schrift, echte
  iframes, keine Textur-Unschärfe. Wird als **S9 (Monitor-Würfel)** eigener Slice: YouTube,
  three.js-Demo, LLM-Chat, skalierbar.
- **Drei Register statt zwei:** Werkzeug (Terrain-Voxel + PNG-Decal) · Orakel (Ugur-D6, Würfelaugen) ·
  Monitor (Glas-Seite + Overlay).
- **Backlog ergänzt:** Graveyard-Slice + Kenney-Assets ins Terrain streuen — viel später, eigener
  Sprint; Playbook liegt in der Academy-Zip.

## 2026-07-24 · v5 · Karte schneidet nicht mehr in hüpfende Cubes

- **Was:** Die Flughöhe war an EINER Höhenprobe in der Fahrzeugmitte geklemmt — die Karte ist aber
  3.0 × 1.68 groß und bankt, und die Cubes hüpfen nach oben. Ergebnis: die Ecken schnitten in
  steigende Würfel. Jetzt tastet `cardClearance()` die ganze Grundfläche ab (Mitte + 4 Ecken),
  einmal an der aktuellen und einmal an der voraus liegenden Position (`1.2 + speed·0.22`), nimmt
  den schlechtesten Fall und rechnet Bob-Reserve (`terrain.maxLift()`) plus den Tiefgang der
  untersten Ecke (`sin(bank)·halfW + sin(pitch)·halfD`) drauf. Steigen schnell (14/s), Sinken
  langsam (2,2/s).
- **Warum keine Physik-Engine:** Wir brauchen keine Kollisionslösung, nur eine ehrliche Bodenhöhe.
  Zehn Noise-Proben pro Frame kosten nichts; eine Engine würde Broadphase, Körper und Solver für
  ein Problem einführen, das eine Höhenfunktion schon beantwortet.
- **Dateien:** `terrain-v5/travel-poc.js`, `terrain-v5/card-carrier.js` (`halfW`/`halfD` exportiert).
- **S7 präzisiert:** Tacho ist die **Startposition** des Würfels (Rückdrehung nach ~2,5 s Ruhe),
  Beschriftung kontert die Drehung (Smartphone-Logik), `spinTo(face)` von Anfang an vorsehen
  (später Story-Mode-Wurf und Quest-Fortschritt). Design-Empfehlung: **ein Objekt, zwei Register** —
  Terrain-Voxel = Werkzeug, Sky-D6 = Orakel, der Spin-Flip ist der Übergang.

## 2026-07-24 · v5 · S1 erledigt: Regie-Skalar `travelHeat`

- **Was:** `terrain-v5/travel-heat.js`. Eine geglättete 0..1-Zahl plus Ableitung plus geeichte
  km/h-Anzeige. Reisetempo belegt die unteren 17 % der Skala, darüber `t·(2−t)`; Boost hebt auf
  mindestens 0,72, Sprungphase im Walk +0,10.
- **Warum:** Ohne diese Zahl bekommt jeder FX-Slice eine eigene Speed-Formel. Kamera-Dolly,
  Kamerahöhe, Look-Ahead, FOV (Flug + Walk), Walk-Chase-Abstand und Terrain-Energie hängen jetzt
  daran — die alten `st.speed`-Formeln sind ersetzt, nicht ergänzt.
- **Tacho-Eichung:** `unitMeters = 0.5` (ein Cube = 3 units ≈ 1,5 m). Gehen ≈ 10 km/h, Sprint
  ≈ 17 km/h, Reiseflug ≈ 16 km/h, Vollgas ≈ 76 km/h. Der alte Ride-Tacho log, weil genau diese
  eine Zahl fehlte.
- **Dateien:** `terrain-v5/travel-heat.js` (neu), `terrain-v5/travel-poc.js`.
- **Neu im Plan:** S7 (HUD-Würfel als Instrument + Menü, CSS-3D) und S8 (Settings-Overlay,
  konsolidierte Steuerungs-Legende). Empfohlene Reihenfolge ist jetzt S1 → S7 → S8 → S2…, weil das
  Panel die Tuning-Oberfläche für die FX-Slices ist.

## 2026-07-24 · v5 · Fork angelegt, Sprintplan persistiert

- **Was:** `KFB Travel v5.dc.html` + `terrain-v5/` als Fork des v4-Session-Cuts. v4 ist FROZEN.
  Sprintplan `docs/SPRINT_travel-v5.md` mit sechs Slices (Regie-Skalar → Speedlines/Boost →
  Rim-Light → FX-Pool → Story-Presets → Modus-Tor), Arbeitsregeln für frische Chats, Backlog und
  einer Liste bewusst verworfener Ideen.
- **Warum:** Die TinySkies-Analyse soll additiv über mehrere Chats abgearbeitet werden, ohne dass
  Kontext verloren geht oder v4 kaputt geht.
- **Dateien:** `KFB Travel v5.dc.html`, `terrain-v5/*` (9 Module + `edge3.jpg`),
  `docs/SPRINT_travel-v5.md`, `docs/CHANGELOG_travel.md`.
- **Nebenbei gefixt:** HUD lag hinter dem Canvas (`#tv-hud` ohne `z-index`) — jetzt `z-index:4`.
- **Offen:** S1 (`travelHeat`) ist der nächste Schritt und Voraussetzung für S2–S4.

## 2026-07-24 · v4 · Analyse TinySkies / GlobeFly

- **Was:** 13 Module aus `dannylimanseta/tinyskies@2659a5cc` im Detail gelesen, Report als
  `KFB TinySkies Analyse.dc.html`: Ampel-Inventar, sieben Übernahme-Bausteine mit konkreten Werten,
  fünf bewusste Nicht-Übernahmen, Sechs-Schritt-Reihenfolge.
- **Befund, der eine Erwartung korrigiert:** Es gibt dort keinen Partikel-Wirbel am Boost. Der
  Boost ist Barrel-Roll + zurückfallende Kamera + FOV-Weitung + verbreiterte Speedlines, alles an
  *einer* normalisierten Speed-Zahl. Der echte Swirl-Shader sitzt im Teppich-Portal.
- **Achtung beim Klonen:** Default-Branch ist `cursor/globefly-multiplayer-globe-flight-game`,
  nicht `main` — naive Repo-Zugriffe laufen ins 404.

## 2026-07-24 · v4 · Session-Cut + Pfad-Hygiene

- **Was:** Teil-Export nach `session-export_v1` (17 Dateien, alles < 2 MB, `MANIFEST.md` dabei).
  Pet-Stack läuft kanonisch über jsdelivr (lokaler Spiegel nur Fallback), Kartenrücken über
  `raw…/media/kfb/`, Kanten-Textur RAW-first.
- **Offen:** `edge3.jpg` (2,5 KB) liegt noch nicht im Repo → gehört nach
  `media/3D_Assets/Textures/edge3.jpg`; bis dahin greift der lokale Fallback und die Datei reist im
  Export mit.
- **Stolperstein für später:** Beim RAW-first-Fallback müssen die Bilddaten im `onLoad` des
  Fallback-Loaders übernommen werden, nicht synchron im `onError` des ersten — sonst ist
  `t.image` noch `undefined` und die Konsole spammt „Texture marked for update but no image data".
- **Altlast, in v5 gefixt:** `#tv-hud` lag ohne `z-index` im gleichen Stacking-Kontext wie das
  `<canvas>` → das HUD (Titel, Tastenblock) war komplett unsichtbar, nur die Mode-Badge mit
  `z-index:5` kam durch. In v4 steht der Fehler noch (FROZEN, bewusst nicht angefasst).

## 2026-07-24 · v4 · Achsen, Auto-Hop, Cartoon-Kinetik

- **Was:** Drei Fehler und ein Feature.
  1. **Achsen entdreht:** `heading += turn` (war `−=`) und `right = cross(forward, up)` — A/D und
     Q/E waren im Walk-Mode seitenverkehrt.
  2. **Auto-Hop:** Körper-Radius 0,55 in der Kollision (das Pet lief vorher in den Cube hinein) und
     ein vorausschauender Absprung: gezündet, solange die Kante eine Steigzeit entfernt ist,
     Absprunggeschwindigkeit auf die nötige Höhe gerechnet (`v = √(2g·(rise+0.55))`), davor ~90 ms
     Windup. Kanten über 4,2 gelten als Wand → sliden statt springen.
  3. **Frame-Reihenfolge:** `pet.update(dt)` lief NACH unserer Kinetik — PetMotion hat den Lean
     jedes Frame weggedämpft. Jetzt Motor zuerst.
  4. **Cartoon-Grammatik für beide Modi:** Anticipation-Duck → Launch-Pop → Stretch beim Steigen →
     Apex-Hang → Fall-Stretch → Land-Squash ∝ Aufprall → Rebound-Overshoot → Ruhe. Squash jetzt
     volumenerhaltend (`Sxz = 1/√Sy`) statt Näherung. Dazu der GLB-Clip-Layer: idle/walk/run mit
     `timeScale` an der echten Bodengeschwindigkeit (keine rutschenden Füße), `static` in der Luft,
     `initParts()` für Ohren- und Schweif-Federn.
- **Dateien:** `terrain-v4/walk-controller.js` (neu), `pet-kinetics.js` (neu), `travel-poc.js`.
- **Kanon:** `cartoon-motion_v1.md`, `EMBED_CUBE_PET_FULL_v2.md` §5/§7f.

## Vorgeschichte (vor diesem Changelog)

Slice 1 Flug · Slice 3 Terrain/Welt (deterministischer v3-Seed, ein Story-Mode) · Slice 4
Walk-Controller + Fly⇄Walk-Switch. Details in `HOUSEKEEPING.md`, Abschnitt „KFB Travel v4".

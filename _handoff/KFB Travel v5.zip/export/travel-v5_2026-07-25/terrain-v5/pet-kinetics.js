// ============================================================================
// pet-kinetics.js — KFB Travel v4 · Pet response: flight, walk, jump
// ----------------------------------------------------------------------------
// The pet's KINETIC reaction to the vehicle / to the ground, ported from
// PetFlight v2's flight-kinetics and extended with a full cartoon jump grammar.
//
// Canon rules (must hold):
//  · Applied AFTER pet.update(dt) — PetMotion writes ch.inner.scale (and damps
//    group.rotation.z) every frame, so we READ its idle-breath (motionSy),
//    MULTIPLY our squash on top and set lean/position LAST so they win.
//  · Volume-preserving squash (cartoon-motion principle 1): Sxz = 1/√Sy.
//  · Jump grammar for BOTH modes, identical timing vocabulary
//    (cartoon-motion §12 principles + §real-time snappiness):
//      anticipation (duck, ~90 ms, cue on frame 1)
//        → launch (stretch pop)
//        → rise (stretch ∝ vy)
//        → apex (hang, brief neutral)
//        → fall (stretch again)
//        → land (squash ∝ impact)
//        → rebound overshoot → settle in Ruhe (Prime Directive).
//  · WALK mode also drives the GLB CLIP LAYER (EMBED_CUBE_PET_FULL_v2 §5):
//    idle · walk · run, timeScale matched to the real ground speed so the feet
//    don't slide; airborne uses `static` and our procedural aerial phases.
//    Ear/tail follow-through comes from PetMotion.initParts() (runner calls it).
//
//   const pk = createPetKinetics({ THREE });
//   pk.update(pet, vehicleState, dt);        // fly:  once/frame, AFTER pet.update(dt)
//   pk.updateWalk(pet, walkState, dt);       // walk: once/frame, AFTER pet.update(dt)
//   pk.jump();                               // fly hop (with anticipation)
//   pk.enterWalk() / pk.leaveWalk(pet)       // mode switch bookkeeping
// ============================================================================

export function createPetKinetics(opts = {}) {
  const clampf = (v, a, b) => Math.max(a, Math.min(b, v));
  const flSq = { s: 1, v: 0 };                 // squash spring (independent of PetMotion)
  // second-order inertia springs (value + velocity) → overshoot & settle, so motion feels weighty
  const roll = { x: 0, v: 0 }, pitch = { x: 0, v: 0 }, swayX = { x: 0, v: 0 }, yaw = { x: 0, v: 0 };
  let bobT = 0, prevBoost = false, prevClimb = 0;
  let bankRate = 0, prevBank = 0;              // d(bank)/dt → the whip of ENTERING a turn
  const jump = { active: false, y: 0, vy: 0, wind: 0 };
  const G = 26, J0 = 5.0;                       // gravity / launch velocity (card-local units)
  let flyCrouch = 0, flyPhase = 1;
  const kick = (a) => { flSq.v += a * 10; };    // + stretch, − duck
  // critically-ish damped spring step toward target
  function sp(s, target, stiff, damp, dt) { s.v += (target - s.x) * stiff * dt; s.v *= Math.pow(damp, dt * 60); s.x += s.v * dt; }
  // volume-preserving squash: one axis up → the other two down
  const applySquash = (ch, bs, sY) => { const s = clampf(sY, 0.66, 1.40), xz = 1 / Math.sqrt(s); ch.inner.scale.set(bs * xz, bs * s, bs * xz); };
  // aerial phase target: rise stretches, apex hangs, fall stretches again
  function aerial(vy, scale) {
    const v = vy * scale;
    if (v > 1.2) return 1 + clampf(v * 0.020, 0, 0.22);
    if (v < -1.2) return 1 + clampf(-v * 0.014, 0, 0.18);
    return 0.98;                                // hang: a beat of neutral at the top
  }
  // asymmetric follow: ducking/loading is fast (frame-1 cue), releasing is softer
  const chase = (cur, tgt, dt) => cur + (tgt - cur) * Math.min(1, dt * (tgt < cur ? 40 : 20));

  function trigger() {
    if (jump.active || jump.wind > 0) return;
    jump.wind = 0.10;                           // anticipation window; the duck IS the cue
  }

  function update(pet, st, dt) {
    if (!pet || !pet.character || !pet.character.inner) return;
    const ch = pet.character, bs = ch._baseS || 1;
    bobT += dt; const bob = Math.sin(bobT * 2.4) * 0.035;

    // --- squash impulse kicks (SOFTENED so climb/dive no longer flattens the pet) ---
    if (st.boosting && !prevBoost) kick(-0.18);
    if (!st.boosting && prevBoost) kick(0.08);
    prevBoost = st.boosting;
    const cs = st.climbIn > 0.10 ? 1 : st.climbIn < -0.10 ? -1 : 0;
    if (cs !== prevClimb) { if (cs > 0) kick(0.09); else if (cs < 0) kick(-0.09); }
    prevClimb = cs;

    // --- turn dynamics: bank + its RATE drive lateral weight ---
    bankRate += (((st.bank - prevBank) / Math.max(dt, 1e-3)) - bankRate) * Math.min(1, dt * 8);
    prevBank = st.bank;
    const turnMag = Math.min(1, Math.abs(st.bank) * 1.6 + Math.abs(bankRate) * 0.25);

    // --- jump: anticipation → ballistic hop → land squash (same grammar as walk) ---
    if (jump.wind > 0) {
      jump.wind -= dt;
      flyCrouch = Math.min(1, flyCrouch + dt * 12);
      if (jump.wind <= 0) {
        jump.wind = 0; flyCrouch = 0; jump.active = true; jump.vy = J0; kick(0.16);
        if (pet.rig && pet.rig.blinkNow) pet.rig.blinkNow();
      }
    } else if (flyCrouch > 0) flyCrouch = Math.max(0, flyCrouch - dt * 8);
    if (jump.active) {
      jump.y += jump.vy * dt; jump.vy -= G * dt;
      if (jump.y <= 0) {
        const hit = Math.abs(jump.vy);
        jump.y = 0; jump.vy = 0; jump.active = false;
        kick(-clampf(0.14 + hit * 0.030, 0.14, 0.38));
        if (pet.face && pet.face.eyePop) pet.face.eyePop(clampf(hit * 0.05, 0.12, 0.45));
      }
    }
    const phaseT = flyCrouch > 0.01 ? 1 - 0.22 * flyCrouch : (jump.active ? aerial(jump.vy, 0.9) : 1);
    flyPhase = chase(flyPhase, phaseT, dt);

    // --- squash spring settles to 1; keep PetMotion idle-breath, multiply ours on top ---
    flSq.v += (1 - flSq.s) * 80 * dt - flSq.v * 11 * dt; flSq.s += flSq.v * dt;
    const motionSy = ch.inner.scale.y / bs;
    applySquash(ch, bs, motionSy * clampf(flSq.s, 0.78, 1.28) * flyPhase * (1 - turnMag * 0.06));

    // --- multi-axis inertia lean (set LAST so it wins over PetMotion) ---
    sp(roll, clampf(st.bank * 1.1 + bankRate * 0.18, -0.5, 0.5), 120, 0.72, dt);
    sp(pitch, clampf((st.boosting ? 0.10 : 0) + st.climbIn * 1.3 + (jump.active ? -jump.vy * 0.012 : 0) - flyCrouch * 0.06, -0.26, 0.26), 90, 0.80, dt);
    sp(swayX, clampf(-st.bank * 0.5 - bankRate * 0.10, -0.42, 0.42), 70, 0.78, dt);
    sp(yaw, clampf(st.bank * 0.28, -0.28, 0.28), 60, 0.80, dt);

    pet.object3D.rotation.set(pitch.x, Math.PI + yaw.x, roll.x);   // Math.PI: pet faces travel (−Z)
    pet.object3D.position.set(swayX.x, bob + jump.y - flyCrouch * 0.05, 0);
  }

  // ---- WALK mode: the pet is on the ground, not on the card ----
  const wSq = { s: 1, v: 0 };
  const wLean = { x: 0, v: 0 }, wPitch = { x: 0, v: 0 };
  let walkT = 0, wFacing = 0, wFacingSet = false, wasAir = false, wPhase = 1;
  let curClip = null, clipAct = null;
  const kickW = (a) => { wSq.v += a * 10; };

  function setClip(pet, name, speed) {
    if (!pet.motion || !pet.motion.playClip) return;
    if (name !== curClip) {
      const a = pet.motion.playClip(name, { speed });
      if (a) { clipAct = a; curClip = name; }
      else { curClip = name; clipAct = null; }    // clip missing in this GLB: stay procedural
    } else if (clipAct && Math.abs(clipAct.timeScale - speed) > 0.06) {
      clipAct.timeScale = speed;                  // retime WITHOUT restarting the cycle
    }
  }

  function updateWalk(pet, ws, dt) {
    if (!pet || !pet.character || !pet.character.inner) return;
    const ch = pet.character, bs = ch._baseS || 1;

    // ---- CLIP LAYER: idle · walk · run, speed-matched so the feet don't slide ----
    const air = !ws.onGround;
    const wantClip = air ? 'static' : (ws.moving && ws.speed > 0.4 ? (ws.sprinting ? 'run' : 'walk') : 'idle');
    const ref = ws.sprinting ? (ws.runRef || 9.4) : (ws.walkRef || 5.4);
    const rate = wantClip === 'walk' || wantClip === 'run' ? clampf((ws.speed || 0) / ref, 0.55, 1.9) : 1;
    setClip(pet, wantClip, rate);

    // ---- jump grammar: launch pop, land squash scaled to the impact ----
    if (air && !wasAir) {
      kickW(0.18);
      if (pet.rig && pet.rig.blinkNow) pet.rig.blinkNow();
    }
    if (!air && wasAir) {
      const hit = ws.impact || 0;
      kickW(-clampf(0.14 + hit * 0.022, 0.14, 0.40));
      if (hit > 11 && pet.face && pet.face.eyePop) pet.face.eyePop(clampf(hit * 0.026, 0.15, 0.5));
    }
    wasAir = air;

    // phase target: anticipation duck (from the controller's windup) → aerial arc
    const phaseT = ws.crouch > 0.01 ? 1 - 0.24 * ws.crouch : (air ? aerial(ws.vy, 0.55) : 1);
    wPhase = chase(wPhase, phaseT, dt);

    // walk cycle: a light step bob + footfall squash ON TOP of the GLB clip
    let bob = 0, stepSq = 1;
    if (ws.moving && !air && ws.speed > 0.4) {
      walkT += dt * (ws.sprinting ? 13 : 8.5) * clampf(ws.speed / ref, 0.6, 1.6);
      bob = Math.abs(Math.sin(walkT)) * (ws.sprinting ? 0.09 : 0.06);
      stepSq = 1 - Math.abs(Math.cos(walkT)) * 0.035;
    } else if (!air) { walkT += dt * 1.2; bob = Math.sin(walkT * 1.6) * 0.012; }

    // squash spring settles to 1, multiplied on top of PetMotion's idle breath
    wSq.v += (1 - wSq.s) * 80 * dt - wSq.v * 11 * dt; wSq.s += wSq.v * dt;
    const motionSy = ch.inner.scale.y / bs;
    applySquash(ch, bs, motionSy * clampf(wSq.s, 0.78, 1.28) * wPhase * stepSq);

    // facing: turn smoothly toward the heading (shortest arc)
    if (!wFacingSet) { wFacing = ws.facing; wFacingSet = true; }
    const d = ((ws.facing - wFacing + Math.PI * 3) % (Math.PI * 2)) - Math.PI;
    wFacing += d * Math.min(1, dt * 10);

    // lean into the turn; forward lean when running, tuck on the anticipation duck,
    // nose up on the rise / down on the fall (arcs, not straight lines)
    sp(wLean, clampf(-ws.turnRate * 0.08, -0.30, 0.30), 90, 0.78, dt);
    const pitchT = air ? clampf(-ws.vy * 0.010, -0.18, 0.18)
      : (ws.crouch > 0.01 ? -0.10 * ws.crouch
        : (ws.moving && ws.speed > 0.4 ? (ws.sprinting ? 0.14 : 0.07) : 0));
    sp(wPitch, pitchT, 70, 0.82, dt);

    pet.object3D.position.set(ws.position.x, ws.position.y + bob - ws.crouch * 0.06, ws.position.z);
    pet.object3D.rotation.set(wPitch.x, wFacing, wLean.x);
  }

  return {
    name: 'pet-kinetics', update, updateWalk, jump: trigger,
    enterWalk() { wFacingSet = false; curClip = null; clipAct = null; wPhase = 1; wasAir = false; },
    leaveWalk(pet) {
      curClip = null; clipAct = null;
      if (pet && pet.motion && pet.motion.stopClip) pet.motion.stopClip();
    },
    get airborne() { return jump.active; },
  };
}

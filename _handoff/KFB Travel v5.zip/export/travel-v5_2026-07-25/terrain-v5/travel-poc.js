// ============================================================================
// travel-poc.js — KFB Travel v5 · Runner (Flug + Boden)
// ----------------------------------------------------------------------------
// Fork von terrain-v4/travel-poc.js (Session-Cut 2026-07-24). v4 bleibt unangetastet.
// Sprintplan für diese Version: docs/SPRINT_travel-v5.md — Status dort pflegen,
// nicht hier. Changelog: docs/CHANGELOG_travel.md.
// ----------------------------------------------------------------------------
// Brief §7.1 — smallest bootable slice: flat WebGL ground + card + default pet
// (bunny) + flight controller. Flies. WebGL three 0.160. Later slices swap the
// flat ground for terrain-v3, add the ground/walk controller, 24-pet select,
// mode switch, and richer card kinetics.
//
// Runtime layers (001): Input → Vehicle(flight) → Camera → Pet → CardRig → Render.
// ============================================================================

import * as THREE from 'three';
import { createFlightController } from './flight-controller.js';
import { createCardCarrier } from './card-carrier.js';
import { createPetKinetics } from './pet-kinetics.js';
import { createVoxelTerrain } from './voxel-terrain.js';
import { createSkydome } from './skydome-shader.js';
import { makeWorldContext, MODES } from './world-context.js';
import { createWalkController } from './walk-controller.js';
import { createTravelHeat } from './travel-heat.js';
import { createHudCube } from './hud-cube.js';
import { createSettingsOverlay } from './settings-overlay.js';

const ASSET = (p) => new URL(p, import.meta.url).href;
// Pfad-Hygiene: der Pet-Stack kommt kanonisch über jsdelivr (Module brauchen application/javascript);
// der lokale Spiegel ist nur Fallback, nie Quelle.
const PETS_CANON = 'https://cdn.jsdelivr.net/gh/georg-doc/kayfabizarro@main/media/3D_Assets/kfb-pets.js';
async function petsModule() {
  try { return await import(/* @vite-ignore */ PETS_CANON); }
  catch (e) { console.warn('[travel-poc] kanonischer Pet-Stack nicht ladbar → lokaler Spiegel', e); return await import('./kfb-pets.js'); }
}

(function boot() {
  const stage = document.getElementById('tv-stage');
  if (!stage) { requestAnimationFrame(boot); return; }
  const probe = document.createElement('canvas');
  if (!(probe.getContext('webgl2') || probe.getContext('webgl'))) {
    stage.innerHTML = '<div style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center;color:#cdd4e6;font-family:monospace;">This needs a WebGL browser.</div>';
    return;
  }
  start(stage).catch((e) => console.error('[travel-poc] start failed', (e && (e.stack || e.message)) || e));
})();

async function start(stage) {
  const renderer = new THREE.WebGLRenderer({ antialias: true });
  renderer.setSize(stage.clientWidth, stage.clientHeight);
  renderer.setPixelRatio(Math.min(devicePixelRatio || 1, 2));
  renderer.shadowMap.enabled = true; renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  renderer.localClippingEnabled = true;   // for the card-carrier feet clip plane
  renderer.toneMapping = THREE.ACESFilmicToneMapping; renderer.toneMappingExposure = 1.0;
  renderer.domElement.style.cssText = 'position:absolute;inset:0;width:100%;height:100%;display:block;';
  stage.appendChild(renderer.domElement);

  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(58, stage.clientWidth / stage.clientHeight, 0.3, 5000);

  // --- WORLD (slice 3): deterministic v3 world from a fixed seed + one story mode.
  // Card-driven terrain (CardTriplet → setWorldContext) is a later slice; the hook is already here.
  const WORLD_SEED = 'kfb-travel-v4-slice3';
  const STORY = 'heroic';
  let worldSeed = WORLD_SEED, story = STORY;
  let wc = makeWorldContext({ storyMode: STORY, seeds: [WORLD_SEED] });
  let pal = wc.palette;
  const fogCol = new THREE.Color(pal[0][0] * 0.6 + 0.02, pal[0][1] * 0.6 + 0.03, pal[0][2] * 0.6 + 0.05);
  scene.background = fogCol.clone();
  scene.fog = new THREE.Fog(fogCol.getHex(), 90, 520);

  // --- lights: warm sun (shadow) + cool hemi so the pet reads from all sides ---
  const sun = new THREE.DirectionalLight(0xfff2e0, 2.6); sun.position.set(30, 60, 20); sun.castShadow = true;
  sun.shadow.mapSize.set(2048, 2048); sun.shadow.camera.near = 1; sun.shadow.camera.far = 200;
  sun.shadow.camera.left = -40; sun.shadow.camera.right = 40; sun.shadow.camera.top = 40; sun.shadow.camera.bottom = -40; sun.shadow.bias = -0.0006; sun.shadow.normalBias = 0.6;
  scene.add(sun, sun.target);
  scene.add(new THREE.HemisphereLight(0xe6f0ff, 0x6a6250, 1.0));

  // --- skydome (v3), coupled to the same story mode/palette ---
  const sky = createSkydome({ THREE, mode: wc.storyModeIndex, variant: 'S', worldMix: 0.4 });
  sky.setPalette(pal);
  scene.add(sky.group);

  // --- voxel terrain (v3), replacing the flat ground. groundHeightAt drives the flight clamp. ---
  const terrain = createVoxelTerrain({ THREE });
  terrain.setWorldContext(wc);
  terrain.setPalette(pal);
  terrain.build(scene);
  const groundHeightAt = (x, z) => terrain.groundHeightAt(x, z);

  // WoW-style camera collision: march from the look-target outward and stop before the camera
  // would enter terrain, so the pet is never hidden behind a cube wall.
  const _probe = new THREE.Vector3();
  function pullIn(from, dir, dist, margin) {
    const N = 8, m = margin != null ? margin : 1.0 + terrain.maxLift() * 0.5;
    for (let i = 1; i <= N; i++) {
      const t = (i / N) * dist;
      _probe.copy(from).addScaledVector(dir, t);
      if (_probe.y < groundHeightAt(_probe.x, _probe.z) + m) return Math.max(1.4, t - dist / N);
    }
    return dist;
  }

  // --- vehicle + rig ---
  const flight = createFlightController({ THREE });
  flight.reset(0, 0);
  const rig = createCardCarrier({ THREE });   // assetBase: kanonische RAW-URL (card-carrier default)
  scene.add(rig.group);
  const petKin = createPetKinetics({ THREE });
  const walk = createWalkController({ THREE });
  const heat = createTravelHeat({});   // S1: der eine Regie-Skalar
  let mode = 'fly';   // 'fly' | 'walk'

  // --- S7: HUD-Würfel unten rechts — Ruhezustand Tacho, angefasst Menü.
  // Oberfläche und Farben kommen aus derselben Welt (Kanten-Textur + Story-Palette).
  let storyMode = MODES.find((m) => m.key === STORY) || MODES[3];
  let settings = null;   // wird nach dem Pet-Mount gebaut; Handler greifen lazy darauf zu
  const hud = createHudCube({
    THREE, dom: renderer.domElement,
    ink: storyMode.ink, panel: storyMode.panel,
    onSelect: (id) => settings.toggle(id),
  });
  hud.preWarm(renderer);   // Shader vorwärmen (Academy-Muster): kein Ruckler im ersten Frame

  // ---------------------------------------------------------------- WELT NEU BAUEN
  // Story-Mode und Seed ändern denselben Weg: neuer WorldContext → Terrain rebaked,
  // Himmel und HUD-Würfel bekommen dieselbe Palette. (Vorgriff auf S5.)
  function applyWorld(rebuildCtx) {
    if (rebuildCtx) {
      wc = makeWorldContext({ storyMode: story, seeds: [worldSeed] });
      pal = wc.palette;
    }
    terrain.setWorldContext(wc);
    terrain.setPalette(pal);
    sky.setMode(wc.storyModeIndex);
    sky.setPalette(pal);
    storyMode = MODES.find((m) => m.key === story) || storyMode;
    hud.setPalette({ ink: storyMode.ink, panel: storyMode.panel });
    fogCol.setRGB(pal[0][0] * 0.6 + 0.02, pal[0][1] * 0.6 + 0.03, pal[0][2] * 0.6 + 0.05);
    scene.background = fogCol.clone();
    if (scene.fog) scene.fog.color.copy(fogCol);
    if (settings) settings.setAccent('#' + new THREE.Color(storyMode.ink).getHexString());
  }

  // ---------------------------------------------------------------- CARD FLOOR
  // Das Fahrzeug ist keine Kugel, sondern eine 3.0 × 1.68 große Karte, die BANKT — und die
  // Cubes hüpfen nach oben. Eine einzige Höhenprobe in der Mitte lässt genau das passieren,
  // was Georg sieht: die Ecken schneiden in einen steigenden Würfel. Statt einer Physik-Engine
  // tastet diese Funktion die ganze Grundfläche ab (Mitte + 4 Ecken), einmal an der aktuellen
  // und einmal an der VORAUS liegenden Position, nimmt den schlechtesten Fall und rechnet die
  // Bob-Reserve (`terrain.maxLift()`) plus den Tiefgang der untersten Ecke drauf.
  // Steigen schnell, Sinken langsam — dieselbe Disziplin wie beim Kamera-Pull-in.
  let cardFloor = 0;
  // Höchste Oberfläche im Umkreis eines Körperradius — EINE Mittenprobe reicht nicht: das
  // Pet steckt sonst in der Nachbarsäule (Georgs Screen 1 beim Wechsel in den Walk-Mode).
  function safeGroundAt(x, z, r) {
    const rad = r != null ? r : 0.7;
    let top = groundHeightAt(x, z);
    for (let i = 0; i < 8; i++) {
      const a = (i / 8) * Math.PI * 2;
      const t = groundHeightAt(x + Math.cos(a) * rad, z + Math.sin(a) * rad);
      if (t > top) top = t;
    }
    return top;
  }
  function cardClearance(st, dt) {
    const hw = rig.halfW + 0.25, hd = rig.halfD + 0.25;   // + Haut-Marge
    const fx = st.forward.x, fz = st.forward.z;
    const rx = -fz, rz = fx;                              // right = forward × up (horizontal)
    const ahead = 1.2 + st.speed * 0.22;                  // dorthin, wo wir gleich sind
    let top = -1e9;
    for (let s = 0; s <= 1; s++) {
      const ox = st.position.x + fx * ahead * s, oz = st.position.z + fz * ahead * s;
      for (let i = 0; i < 5; i++) {
        const sx = i === 0 ? 0 : (i <= 2 ? 1 : -1);
        const sz = i === 0 ? 0 : (i === 1 || i === 3 ? 1 : -1);
        const t = groundHeightAt(ox + rx * hw * sx + fx * hd * sz, oz + rz * hw * sx + fz * hd * sz);
        if (t > top) top = t;
      }
    }
    const tilt = Math.abs(Math.sin(st.bank)) * hw + Math.abs(Math.sin(st.pitchTilt || 0)) * hd;
    const want = top + terrain.maxLift() + tilt;
    cardFloor += (want - cardFloor) * Math.min(1, dt * (want > cardFloor ? 14 : 2.2));
    return cardFloor;
  }

  // mode badge
  const badge = document.createElement('div');
  badge.style.cssText = "position:absolute;top:16px;left:50%;transform:translateX(-50%);z-index:5;font-family:'Special Elite',monospace;font-size:12px;letter-spacing:.14em;color:#fff;background:rgba(10,11,20,.5);padding:6px 14px;border-radius:99px;pointer-events:none;text-shadow:0 1px 3px rgba(0,0,0,.6);";
  stage.appendChild(badge);
  // EINE Hinweiszeile statt zweier Legenden-Blöcke: blendet nach 8 s aus und in späteren
  // Sitzungen gar nicht mehr auf. Die vollständige Steuerung steht im Overlay (S8).
  const hint = document.createElement('div');
  hint.style.cssText = "position:absolute;left:50%;transform:translateX(-50%);bottom:20px;text-align:center;"
    + "font-family:'Special Elite',monospace;font-size:12px;color:#fff;opacity:.9;"
    + 'text-shadow:0 2px 6px rgba(0,0,0,.7);transition:opacity 1.4s ease;pointer-events:none;';
  hint.textContent = 'W/S Schub · A/D lenken · F Fly ⇄ Walk · Tab oder Würfel unten rechts = Einstellungen';
  (document.getElementById('tv-hud') || stage).appendChild(hint);
  try {
    if (localStorage.getItem('kfb-travel-v5-hint') === 'seen') hint.style.display = 'none';
    else setTimeout(() => { hint.style.opacity = '0'; try { localStorage.setItem('kfb-travel-v5-hint', 'seen'); } catch (e) {} }, 8000);
  } catch (e) { setTimeout(() => { hint.style.opacity = '0'; }, 8000); }
  function switchMode(to) {
    if (to === mode) return;
    if (to === 'walk') {
      const p = flight.state.position; const gy = safeGroundAt(p.x, p.z) + terrain.maxLift() + 0.25;
      walk.reset(p.x, p.z, gy, Math.atan2(flight.state.forward.x, flight.state.forward.z));
      walkLookY = gy + walk.eyeUp;
      rig.setVisible(false); rig.setClipEnabled(false);
      petKin.enterWalk();
      if (pet) {
        scene.add(pet.object3D); pet.object3D.scale.setScalar(1.25);
        // no procedural loop in walk mode: those tweens move group.position, which
        // IS the walker's world position here — the clip layer carries the cycle.
        if (pet.motion) { pet.motion.stopLoops(); }
      }
    } else {
      const wp = walk.state.position; flight.reset(wp.x, wp.z);
      cardFloor = terrain.groundHeightAt(wp.x, wp.z) + terrain.maxLift();   // kein Kriechstart
      rig.setVisible(true); rig.setClipEnabled(true);
      petKin.leaveWalk(pet);
      terrain.setCalm(0, 0, 1, 0);   // cubes dance again in flight
      if (pet) { rig.seat.add(pet.object3D); pet.object3D.visible = true; pet.object3D.scale.setScalar(1.15); pet.object3D.position.set(0, 0, 0); }
    }
    mode = to;
    heat.setMode(to);   // Skala behalten, kein Sprung beim Wechsel
    camSnap = true;
    badge.textContent = mode === 'walk' ? 'WALK' : 'FLY';
  }

  // --- pet (canonical stack, default bunny) ---
  let pet = null, petLib = null, petId = 'bunny', petBusy = false;
  // Pet-Wechsel läuft über DIESELBE Funktion wie der erste Mount (ein Pfad, kein Sonderfall).
  // Vertrag §12.6: altes Pet disposen, sonst stapeln sich Augen-Rigs.
  async function mountPet(id) {
    if (petBusy) return;
    petBusy = true;
    try {
      const { loadPets, makePet } = await petsModule();
      if (!petLib) petLib = await loadPets();
      const p = await makePet(petLib, id, { THREE, motion: 'idle' });
      p.object3D.rotation.y = Math.PI;   // face travel direction (-Z)
      p.object3D.traverse((n) => { if (n.isMesh) { n.castShadow = true; } });
      if (pet) { try { pet.object3D.removeFromParent(); pet.dispose && pet.dispose(); } catch (e2) {} }
      pet = p; petId = id; window.__pet = p;
      if (p.motion && p.motion.initParts) p.motion.initParts();
      if (mode === 'walk') {
        petKin.enterWalk();
        scene.add(p.object3D); p.object3D.scale.setScalar(1.25);
        if (p.motion) p.motion.stopLoops();
      } else {
        p.object3D.scale.setScalar(1.15); p.object3D.position.set(0, 0, 0);
        rig.seat.add(p.object3D);
        rig.applyClip(p.object3D);   // clip feet at the card surface
      }
    } catch (e) { console.warn('[travel-poc] pet mount failed', e); }
    petBusy = false;
  }
  mountPet('bunny');

  // ---------------------------------------------------------------- S8: EINSTELLUNGEN
  // Cluster nach Häufigkeit. Es stehen nur Regler drin, die ECHT etwas tun — lieber eine
  // Sektion mit drei ehrlichen Reglern als sechs, die Zukunft versprechen.
  let bpm = 104, beatGain = 1;                       // Rhythmus (noch synthetisch)
  let skyWorldMix = 0.4, skyExposure = 1, skySpiral = false;
  let quality = Math.min(devicePixelRatio || 1, 2);
  // Kamera-Zustand steht HIER, nicht in der Input-Schicht: das Overlay liest ihn beim Bauen
  // (die Regler zeigen ihren Wert sofort) — später deklariert wäre es ein TDZ-Fehler.
  let camDist = 9, zoomTarget = 9, camYaw = 0, camYawTarget = 0, lastZoomAt = 0, lastLookAt = 0;
  let rebakeT = 0;
  const scheduleRebake = () => { clearTimeout(rebakeT); rebakeT = setTimeout(() => applyWorld(false), 130); };
  const wp = () => (wc.params || {});
  const tp = (k, d) => (wp()[k] != null ? wp()[k] : d);
  const setTp = (k, v) => { if (wc.params) { wc.params[k] = v; scheduleRebake(); } };

  settings = createSettingsOverlay({
    mount: stage,
    accent: '#' + new THREE.Color(storyMode.ink).getHexString(),
    onOpen: () => { hud.setEnabled(false); keys.clear(); },
    onClose: () => hud.setEnabled(true),
    sections: [
      { id: 'cards', title: 'Karten', hint: 'Der Story-Modus färbt Welt, Himmel und Würfel. Das Deck-Triplet als Weltquelle kommt eigenständig (Backlog).',
        controls: [
          { kind: 'select', label: 'Story-Modus', options: MODES.map((m) => ({ v: m.key, l: m.n + ' · ' + m.name })),
            get: () => story, set: (v) => { story = v; applyWorld(true); } },
          { kind: 'info', label: 'Palette', get: () => storyMode.name + '  ·  Ink #' + new THREE.Color(storyMode.ink).getHexString() },
        ] },

      { id: 'music', title: 'Rhythmus', hint: 'Noch ein synthetischer Takt: er treibt Cube-Tanz und Himmel. Echte Tracks folgen mit dem Jukebox-Modul.',
        controls: [
          { kind: 'slider', label: 'Tempo', min: 60, max: 170, step: 1, get: () => bpm, set: (v) => { bpm = v; }, fmt: (v) => Math.round(v) + ' BPM' },
          { kind: 'slider', label: 'Beat-Kopplung', min: 0, max: 2, step: 0.05, get: () => beatGain, set: (v) => { beatGain = v; } },
        ] },

      { id: 'travel', title: 'Reise',
        controls: [
          { kind: 'toggle', label: 'Boden-Modus (F)', get: () => mode === 'walk', set: (on) => switchMode(on ? 'walk' : 'fly') },
          { kind: 'slider', label: 'Höchsttempo Flug', min: 18, max: 90, step: 1, get: () => flight.params.SPD_MAX,
            set: (v) => flight.setParams({ SPD_MAX: v }), fmt: (v) => Math.round(v) + ' u/s' },
          { kind: 'slider', label: 'Lauftempo', min: 2, max: 12, step: 0.2, get: () => walk.params.speed,
            set: (v) => walk.setParams({ speed: v }), fmt: (v) => v.toFixed(1) + ' u/s' },
          { kind: 'slider', label: 'Kamera-Abstand', min: 0, max: 17, step: 0.5,
            get: () => (mode === 'walk' ? walk.state.cam.dist : zoomTarget),
            set: (v) => { if (mode === 'walk') walk.zoom(v - walk.state.cam.dist); else zoomTarget = v; } },
          { kind: 'toggle', label: 'POV (Blick des Pets)',
            get: () => (mode === 'walk' ? walk.state.cam.dist <= 1.6 : zoomTarget <= 1.6),
            set: (on) => { if (mode === 'walk') walk.zoom((on ? 0 : 9) - walk.state.cam.dist); else zoomTarget = on ? 0 : 9; } },
          { kind: 'slider', label: 'Tacho-Eichung', min: 0.2, max: 1.5, step: 0.05, get: () => heat.params.unitMeters,
            set: (v) => heat.setParams({ unitMeters: v }), fmt: (v) => '1 Unit = ' + v.toFixed(2) + ' m' },
          { kind: 'info', label: 'Aktuell', get: () => Math.round(heat.kmh) + ' km/h  ·  heat ' + heat.value.toFixed(2) },
        ] },

      { id: 'world', title: 'Welt', hint: 'Alles hier baut das Terrain neu — die Änderung greift kurz nach dem Loslassen.',
        controls: [
          { kind: 'slider', label: 'Rauheit', min: 0, max: 1, step: 0.02, get: () => tp('terrainRoughness', 0.6), set: (v) => setTp('terrainRoughness', v) },
          { kind: 'slider', label: 'Höhenskala', min: 4, max: 40, step: 0.5, get: () => tp('heightScale', 16), set: (v) => setTp('heightScale', v) },
          { kind: 'slider', label: 'Wasserlinie', min: -12, max: 12, step: 0.5, get: () => tp('waterLevel', 0), set: (v) => setTp('waterLevel', v) },
          { kind: 'slider', label: 'Farbversatz', min: 0, max: 1, step: 0.02, get: () => tp('colorShift', 0.5), set: (v) => setTp('colorShift', v) },
          { kind: 'slider', label: 'Cube-Tanz', min: 0, max: 1, step: 0.02, get: () => tp('motionAmplitude', 0.35), set: (v) => setTp('motionAmplitude', v) },
        ] },

      { id: 'sky', title: 'Himmel',
        controls: [
          { kind: 'select', label: 'Variante', options: [
            { v: 'S', l: 'Sphäre (Default)' }, { v: 'A', l: 'Waber-Noise' }, { v: 'space', l: 'Space' },
            { v: 'watercolor', l: 'Aquarell' }, { v: 'watercolor2', l: 'Aquarell II' }, { v: 'starfield', l: 'Sternenfeld' },
            { v: 'night', l: 'Nacht' }, { v: 'morning', l: 'Morgen' }, { v: 'day', l: 'Tag' }, { v: 'alien', l: 'Alien' },
          ], get: () => sky.getVariant(), set: (v) => sky.setVariant(v) },
          { kind: 'slider', label: 'Welt-Mischung', min: 0, max: 1, step: 0.02, get: () => skyWorldMix, set: (v) => { skyWorldMix = v; sky.setWorldMix(v); } },
          { kind: 'slider', label: 'Belichtung', min: 0.4, max: 1.8, step: 0.05, get: () => skyExposure, set: (v) => { skyExposure = v; sky.setExposure(v); } },
          { kind: 'toggle', label: 'Hypno-Spirale', get: () => skySpiral, set: (on) => { skySpiral = on; sky.setSpiral(on); } },
        ] },

      { id: 'pet', title: 'Pet', hint: 'Alle Pets aus dem kanonischen Vertrag. Der Wechsel räumt das alte Pet ab (ein Augenpaar).',
        controls: [
          { kind: 'select', label: 'Cube-Pet',
            options: () => ((petLib && petLib.pets) || []).map((p) => ({ v: p.id, l: p.name || p.id })),
            get: () => petId, set: (v) => mountPet(v) },
          { kind: 'info', label: 'Geladen', get: () => (pet ? (pet.name || petId) : '…') },
        ] },

      { id: 'controls', title: 'Steuerung', wide: true, hint: 'Beide Travel-Modi in einer Tabelle — dafür ist die Legende aus dem Bild verschwunden.',
        controls: [{ kind: 'keys', rows: [
          ['W / S', 'Flug: Schub · langsamer'], ['W / S', 'Boden: laufen · rückwärts'],
          ['A / D', 'lenken (Flug) · drehen (Boden)'], ['Q / E', 'Boden: seitwärts'],
          ['↑ / ↓', 'Flug: steigen · sinken'], ['Shift', 'Boden: rennen'],
          ['Leertaste', 'Flug: Boost'], ['Leertaste', 'Boden: Sprung'],
          ['J', 'Flug: Pet hüpft'], ['F', 'Fly ⇄ Walk'],
          ['Tab', 'Einstellungen'], ['Esc', 'Einstellungen schließen'],
          ['Ziehen', 'lenken (Flug) · umsehen (Boden)'], ['Rad / Pinch', 'Zoom bis POV'],
          ['Würfel unten rechts', 'drehen → Seite klicken → Sektion'],
        ] }] },

      { id: 'system', title: 'System', wide: true, hint: 'Selten gebraucht, deshalb unten.',
        controls: [
          { kind: 'text', label: 'Welt-Seed', get: () => worldSeed, set: (v) => { worldSeed = v || WORLD_SEED; applyWorld(true); } },
          { kind: 'button', label: 'Seed neu würfeln', onClick: () => { worldSeed = 'kfb-' + Math.random().toString(36).slice(2, 9); applyWorld(true); } },
          { kind: 'slider', label: 'Auflösung', min: 0.6, max: 2, step: 0.1, get: () => quality, set: (v) => {
            quality = v; renderer.setPixelRatio(v); renderer.setSize(stage.clientWidth, stage.clientHeight);
          }, fmt: (v) => v.toFixed(1) + '×' },
          { kind: 'button', label: 'Alles zurücksetzen', onClick: () => {
            story = STORY; worldSeed = WORLD_SEED; applyWorld(true);
            flight.setParams({ SPD_MAX: 42 }); walk.setParams({ speed: 5.4 });
            heat.setParams({ unitMeters: 0.5 }); heat.reset(mode);
            bpm = 104; beatGain = 1; zoomTarget = 9;
            sky.setVariant('S'); sky.setWorldMix(0.4); sky.setExposure(1); sky.setSpiral(false);
            skyWorldMix = 0.4; skyExposure = 1; skySpiral = false;
            if (mode === 'walk') switchMode('fly');
          } },
        ] },
    ],
  });

  // ---------------------------------------------------------------- INPUT layer
  const keys = new Set();
  addEventListener('keydown', (e) => {
    if (settings.isOpen()) return;            // Overlay offen: Tasten gehören dem Formular
    keys.add(e.code);
    if (['ArrowUp', 'ArrowDown', 'Space'].includes(e.code)) e.preventDefault();
    if (e.code === 'KeyF' && !e.repeat) switchMode(mode === 'fly' ? 'walk' : 'fly');
    if (e.code === 'KeyJ' && !e.repeat && mode === 'fly') petKin.jump();
    if (e.code === 'Space' && !e.repeat && mode === 'walk') walk.jump();
    if (e.code === 'Tab' && !e.repeat) { e.preventDefault(); settings.toggle('travel'); }
  });
  addEventListener('keyup', (e) => keys.delete(e.code));
  let steer = false, grabX = 0, grabY = 0, sx = 0, sy = 0, lastInputAt = performance.now(), lastPX = 0, lastPY = 0;
  const ptrs = new Map(); let pinch0 = 0, zoom0 = 0;
  const el = renderer.domElement;
  el.addEventListener('pointerdown', (e) => {
    if (e.__hudClaimed) return;   // S7: der HUD-Würfel hat diesen Zeiger
    ptrs.set(e.pointerId, { x: e.clientX, y: e.clientY }); lastInputAt = performance.now(); lastPX = e.clientX; lastPY = e.clientY;
    try { el.setPointerCapture(e.pointerId); } catch (e2) {}
    if (ptrs.size === 1) { steer = true; grabX = e.clientX; grabY = e.clientY; sx = 0; sy = 0; }
    if (ptrs.size === 2) { const p = [...ptrs.values()]; pinch0 = Math.hypot(p[0].x - p[1].x, p[0].y - p[1].y); zoom0 = zoomTarget; }
  });
  el.addEventListener('pointermove', (e) => {
    if (e.__hudClaimed) return;
    if (!ptrs.has(e.pointerId)) return;
    const dxi = e.clientX - lastPX, dyi = e.clientY - lastPY; lastPX = e.clientX; lastPY = e.clientY;
    ptrs.set(e.pointerId, { x: e.clientX, y: e.clientY }); lastInputAt = performance.now();
    if (ptrs.size >= 2) { const p = [...ptrs.values()], d = Math.hypot(p[0].x - p[1].x, p[0].y - p[1].y); if (pinch0 > 0) { zoomTarget = Math.max(0, Math.min(17, zoom0 * (pinch0 / Math.max(d, 1)))); lastZoomAt = performance.now(); } }
    else if (mode === 'walk') { walk.orbit(dxi, dyi); lastLookAt = performance.now(); }
    else { sx = e.clientX - grabX; sy = e.clientY - grabY; }
  });
  const endPtr = (e) => { ptrs.delete(e.pointerId); if (ptrs.size < 2) pinch0 = 0; if (ptrs.size === 1) { const p = [...ptrs.values()][0]; grabX = p.x; grabY = p.y; sx = 0; sy = 0; steer = true; } if (ptrs.size === 0) { steer = false; sx = 0; sy = 0; } };
  el.addEventListener('pointerup', endPtr); el.addEventListener('pointercancel', endPtr);
  el.addEventListener('contextmenu', (e) => e.preventDefault());
  el.addEventListener('wheel', (e) => { e.preventDefault(); if (mode === 'walk') { walk.zoom(Math.sign(e.deltaY) * 1.1); return; } if (Math.abs(e.deltaX) > Math.abs(e.deltaY) * 1.2) { camYawTarget += e.deltaX * 0.004; lastLookAt = performance.now(); } else { zoomTarget = Math.max(0, Math.min(17, zoomTarget + Math.sign(e.deltaY) * 0.9)); lastZoomAt = performance.now(); } }, { passive: false });
  addEventListener('resize', () => { renderer.setSize(stage.clientWidth, stage.clientHeight); camera.aspect = stage.clientWidth / stage.clientHeight; camera.updateProjectionMatrix(); });

  function readInput(dt) {
    let yawIn = 0, climbIn = 0, thrust = 0;
    if (steer) {
      const dz = 12;
      const nx = Math.sign(sx) * Math.min(1, Math.max(0, (Math.abs(sx) - dz) / 170));
      const ny = Math.sign(sy) * Math.min(1, Math.max(0, (Math.abs(sy) - dz) / 150));
      yawIn += -nx * 1.9 * dt; climbIn += -ny * 16 * dt;
      if (nx || ny) lastInputAt = performance.now();
    }
    if (keys.has('KeyA')) yawIn += 1.4 * dt;
    if (keys.has('KeyD')) yawIn -= 1.4 * dt;
    if (keys.has('ArrowUp')) climbIn += 16 * dt;
    if (keys.has('ArrowDown')) climbIn -= 16 * dt;
    if (keys.has('KeyW')) thrust = 1;
    if (keys.has('KeyS')) thrust = -1;
    if (keys.has('KeyW') || keys.has('KeyS') || keys.has('KeyA') || keys.has('KeyD')) lastInputAt = performance.now();
    const idle = performance.now() - lastInputAt > 1600;
    return { yawIn, climbIn, thrust, boost: keys.has('Space'), idle };
  }

  // ---------------------------------------------------------------- LOOP
  const _back = new THREE.Vector3(), _camPos = new THREE.Vector3(), _look = new THREE.Vector3(), _dir = new THREE.Vector3(), _sunOff = new THREE.Vector3(30, 60, 20);
  let last = performance.now(), synthPhase = 0, synthBeat = 0, lastChunkX = 1e9, lastChunkZ = 1e9, walkBobT = 0, camSnap = false, camPullW = 9, camPullF = 9, walkLookY = 0;
  window.__travelPOC = { renderer, scene, camera, flight, walk, rig, petKin, terrain, sky, heat, hud, get wc() { return wc; }, get settings() { return settings; }, get story() { return story; }, get mode() { return mode; }, setMode: (m) => switchMode(m), get pet() { return pet; } };
  badge.textContent = 'FLY';
  renderer.setAnimationLoop(() => {
    try {
      const now = performance.now(); const dt = Math.min(0.05, (now - last) / 1000); last = now;
      let activePos, activeSpeed = 0, activeBank = 0, activePov = false;

      if (mode === 'fly') {
        // 1) input → 2) vehicle (ground height at the current pet/vehicle world x,z)
        const input = readInput(dt);
        const st0 = flight.state;
        flight.update(dt, input, cardClearance(st0, dt));
        const st = flight.state; activePos = st.position; activeSpeed = st.speed;
        heat.update(dt, { mode: 'fly', speed: st.speed, boosting: st.boosting });
        const h = heat.value;
        activeBank = st.bank;
        // 3) follow cam behind forward — zoom sets pet distance; full zoom-in = POV
        camDist += (zoomTarget - camDist) * Math.min(1, dt * 4);
        camYaw += (camYawTarget - camYaw) * Math.min(1, dt * 5);
        if (now - lastLookAt > 1400) camYawTarget += (0 - camYawTarget) * Math.min(1, dt * 1.8);
        const povF = zoomTarget <= 1.6;
        if (povF) {
          if (pet) pet.object3D.visible = false;
          _camPos.copy(st.position).addScaledVector(st.up, 1.15);
          camera.position.lerp(_camPos, Math.min(1, dt * 8));
          _look.copy(camera.position).addScaledVector(st.forward, 6).addScaledVector(st.up, 0.2);
          camera.lookAt(_look);
        } else {
          if (pet) pet.object3D.visible = true;
          _back.copy(st.forward).negate(); if (camYaw) _back.applyAxisAngle(st.up, camYaw);          // S1: Kamera hängt an travelHeat, nicht mehr an der Rohgeschwindigkeit —
          // die Welt weitet sich beim Boost (Dolly zurück + höher + FOV), Report §03.
          const camH = 2.6 + h * 1.4 + camDist * 0.18;
          _look.copy(st.position).addScaledVector(st.forward, 2 + h * 3.4).addScaledVector(st.up, 0.8);
          _dir.copy(_back).addScaledVector(st.up, camH / Math.max(camDist, 0.001)).normalize();
          const dRaw = pullIn(st.position, _dir, Math.hypot(camDist + h * 1.6, camH));
          // fast pull-in, slow push-out — stops the camera bouncing on broken ground
          if (camSnap) camPullF = dRaw;
          else camPullF += (dRaw - camPullF) * Math.min(1, dt * (dRaw < camPullF ? 20 : 2.5));
          _camPos.copy(st.position).addScaledVector(_dir, camPullF);
          camera.position.lerp(_camPos, Math.min(1, dt * 3.5));
          camera.lookAt(_look);
        }
        if (camSnap) { camera.position.copy(_camPos); camSnap = false; }
        const fovT = povF ? 66 : 54 + h * 13;
        activePov = povF;
        camera.fov += (fovT - camera.fov) * Math.min(1, dt * 6); camera.updateProjectionMatrix();
        // 4) pet on the card → 5) CardRig transform+clip, then pet-kinetics reacts
        if (pet && pet.update) pet.update(dt);
        rig.sync(st, dt, pet && pet.character);
        if (pet) petKin.update(pet, st, dt);
      } else {
        // WALK: same control scheme as flight — W/S move, A/D turn, Q/E strafe, Shift sprint
        const iy = (keys.has('KeyW') ? 1 : 0) - (keys.has('KeyS') ? 1 : 0);
        const ix = (keys.has('KeyE') ? 1 : 0) - (keys.has('KeyQ') ? 1 : 0);
        walk.setInput(ix, iy);
        const turn = (keys.has('KeyA') ? 1 : 0) - (keys.has('KeyD') ? 1 : 0);
        walk.update(dt, { turn, sprint: keys.has('ShiftLeft') || keys.has('ShiftRight') }, groundHeightAt);
        const ws = walk.state; activePos = ws.position; activeSpeed = ws.moving ? 6 : 0;
        // Rettung: steckt das Pet trotz allem in einer Säule (hüpfender Cube, harter Modus-Wechsel),
        // heben wir es auf die höchste Oberfläche im Körperumkreis — nie stumm darin stehen lassen.
        const safeY = safeGroundAt(ws.position.x, ws.position.z, 0.62);
        if (ws.position.y < safeY - 0.06) walk.lift(safeY);
        heat.update(dt, { mode: 'walk', speed: ws.speed, sprinting: ws.sprinting, airborne: !ws.onGround });
        const h = heat.value;
        activeBank = ws.turnRate * 0.22;
        // cubes hold still around the walker so they can't swallow or punch through the pet
        terrain.setCalm(ws.position.x, ws.position.z, 26, 1);
        // third-person orbit cam — zoom all the way in for POV
        const c = ws.cam;
        const pov = c.dist <= 1.6;
        activePov = pov;
        if (pov) {
          if (pet) pet.object3D.visible = false;
          const hy = ws.position.y + walk.eyeUp * 1.15;
          camera.position.set(ws.position.x, hy, ws.position.z);
          _look.set(ws.position.x + Math.sin(ws.facing) * 4, hy + (0.32 - c.pitch) * 3.2, ws.position.z + Math.cos(ws.facing) * 4);
          camera.lookAt(_look);
          camera.fov += (66 - camera.fov) * Math.min(1, dt * 6); camera.updateProjectionMatrix();
        } else {
          if (pet) pet.object3D.visible = true;
          // follow cam BEHIND the walker's heading (same feel as flight); drag adds a temporary
          // look-around offset that recentres, and the look target's Y is smoothed so cube
          // steps don't jolt the camera.
          if (now - lastLookAt > 1400) walk.recenterView(dt);
          const yaw = ws.heading + c.yawOff;
          const tgtY = ws.position.y + walk.eyeUp;
          walkLookY += (tgtY - walkLookY) * Math.min(1, dt * 5);
          _look.set(ws.position.x, walkLookY, ws.position.z);
          _dir.set(-Math.sin(yaw) * Math.cos(c.pitch), Math.sin(c.pitch), -Math.cos(yaw) * Math.cos(c.pitch)).normalize();
          const dRaw = pullIn(_look, _dir, c.dist + h * 0.9, 1.2);
          if (camSnap) { camPullW = dRaw; walkLookY = tgtY; }
          else camPullW += (dRaw - camPullW) * Math.min(1, dt * (dRaw < camPullW ? 20 : 2.5));
          _camPos.copy(_look).addScaledVector(_dir, camPullW);
          const cg = groundHeightAt(_camPos.x, _camPos.z) + 1.0;
          if (_camPos.y < cg) _camPos.y = cg;
          // … aber der Aufzug darf die Kamera nicht über das Pet hinaus heben (sonst schaut sie
          // in den Himmel und das Pet fällt aus dem Bild). Statt höher: näher heranziehen.
          const yCap = walkLookY + Math.max(2.4, c.dist * 0.8);
          if (_camPos.y > yCap) {
            _camPos.y = yCap;
            _camPos.x += (_look.x - _camPos.x) * 0.35;
            _camPos.z += (_look.z - _camPos.z) * 0.35;
          }
          camera.position.lerp(_camPos, Math.min(1, dt * 6));
          camera.lookAt(_look);
          camera.fov += (56 + h * 6 - camera.fov) * Math.min(1, dt * 6); camera.updateProjectionMatrix();
        }
        if (camSnap) { camera.position.copy(_camPos); camSnap = false; }
        // pet walks on the ground: walk cycle, lean, jump/land squash, facing
        // ORDER IS CANON: motor first (mixer/face/rig), our kinetics last so the
        // lean + world position win over PetMotion's rotation.z damping.
        if (pet) {
          if (pet.update) pet.update(dt);
          petKin.updateWalk(pet, ws, dt);
        }
      }

      // shared: terrain streaming (only on chunk crossing) + colour/beat + sky + sun
      const cx = Math.round(activePos.x / terrain.CHUNK), cz = Math.round(activePos.z / terrain.CHUNK);
      if (cx !== lastChunkX || cz !== lastChunkZ) { terrain.recenter(activePos.x, activePos.z); lastChunkX = cx; lastChunkZ = cz; }
      synthPhase += dt * (bpm / 60);
      if (synthPhase >= 1) { synthPhase -= 1; synthBeat = 1; }
      synthBeat *= Math.exp(-dt * 5.5);
      const drive = { beat: synthBeat * beatGain, energy: 0.28 + heat.value * 0.4 };
      terrain.update(dt, drive);
      sun.position.copy(activePos).add(_sunOff); sun.target.position.copy(activePos);
      sky.follow(camera); sky.update(dt, drive);

      renderer.render(scene, camera);
      // S7: HUD-Würfel als zweiter Pass in einem Scissor-Viewport — nie von Terrain verdeckt
      hud.update(dt, { kmh: heat.kmh, heat: heat.value, rate: heat.rate, bank: activeBank,
                       mode: (mode === 'walk' ? 'WALK' : 'FLY') + (activePov ? '·POV' : '') });
      hud.render(renderer);
    } catch (e) { if (!window.__loopErr) { window.__loopErr = true; console.error('[travel-poc] frame error', e); } }
  });
}

# MANIFEST — KFB Travel v5 · Session-Cut 2026-07-25

Teil-Export nach `skills/session-export_v1.md`. Nur diese Session plus was zum Booten nötig ist.

## (a) Deliverables

| Datei | Diese Session |
|---|---|
| `KFB Travel v5.dc.html` | **neu** (Fork von v4), HUD auf Titel + Badge + Würfel reduziert, beide Legenden-Blöcke entfernt |
| `terrain-v5/travel-heat.js` | **neu** — Regie-Skalar `travelHeat` 0..1 + geeichte km/h (`unitMeters`), `rate`, `setParams` |
| `terrain-v5/hud-cube.js` | **neu** — HUD-Würfel: Ruhe = Tacho mit Nadel, angefasst = Menü. Texturen auf der `RoundedBoxGeometry` (sechs Material-Gruppen), Slerp-Rastung, Drag-Trägheit, aufrechte Beschriftung, Papier-Relief, `spinTo`/`spin`/`setFaceImage`/`setPalette` |
| `terrain-v5/settings-overlay.js` | **neu** — Overlay, Sektionen als Daten, sieben Control-Arten, Akzent über `--kfb-accent` |
| `terrain-v5/travel-poc.js` | geändert — Heat verdrahtet, Würfel + Overlay eingehängt, Pet-Wechsel über einen Pfad, Story-Mode live schaltbar, Hinweiszeile mit `localStorage`-Flag |
| `terrain-v5/flight-controller.js` · `walk-controller.js` | geändert — je `setParams()` / `params` für die Regler |
| `terrain-v5/voxel-terrain.js` | geändert — `edgeTex` exportiert |
| `terrain-v5/pet-kinetics.js` · `card-carrier.js` · `skydome-shader.js` · `world-context.js` · `kfb-pets.js` | unverändert aus v4, aber importiert |
| `support.js` | Runtime, nötig zum Öffnen |

## (b) Contract- und Daten-Dateien

Keine geändert. `kfb-pets.json` bleibt kanonisch im Repo, `kfb-pets.js` ist nur der Fallback-Pfad.

## (c) Docs

`docs/HANDOVER_travel-v6.md` (**neu** — Onboarding für einen frischen Chat: Module, die fünf teuren
Regeln, Test-Hooks, v6-Reihenfolge) · `docs/SPRINT_travel-v5.md` (S1/S7/S8 abgeschlossen, S10–S12
neu aufgenommen) · `docs/CHANGELOG_travel.md` (sechs Einträge dieser Session) · `docs/github.md`.

## (d) Abnahme-Captures

`qa/v5-hud-cube.png` (Würfel auf der Musik-Seite) · `qa/v5-settings.png` (Overlay, Sektion Welt
markiert) · `qa/v5-forbidden.png` (Story-Wechsel: Welt, Himmel und Würfel in der neuen Palette).

## Erledigt in v5

**S0** v5 angelegt · **S1** Regie-Skalar `travelHeat` · **S7** HUD-Würfel · **S8** Settings-Overlay
mit konsolidierter Steuerungs-Legende.

## Pfad-Hygiene

- Pet-Stack: jsdelivr kanonisch, `terrain-v5/kfb-pets.js` nur Fallback.
- Würfel-Oberfläche: `raw…/media/3D_Assets/Textures/Paper003/` (normal + roughness).
- **Offen:** `edge3.jpg` liegt lokal bei, bis sie unter `media/3D_Assets/Textures/` im Repo ist.

## Bewusst NICHT im Export

`terrain-v4/*` (v4 ist eigenständig exportiert) · `terrain-poc.js`, `dice-sky.js`,
`jukebox-audio.js` (nicht Teil dieses Stands) · `uploads/KFB Cube Academy v1/*` (Referenz, gehört
Georg) · der restliche Projekt-Bestand.

## Nächster Sprint (v6)

**S2** Speedlines + Boost-Regie zuerst · dann **S10** Modus ohne Schalter (WoW-Logik) · **S11** Rahmen
mit Wortmarke · **S12** Würfel v2. Zwei Abhängigkeiten stehen im Sprintplan: S11 darf die
Modus-Anzeige erst streichen, wenn S10 steht; S12 trägt erst mit Georgs Icon-PNGs oder mit einem
Würfel, der im Menü-Zustand wächst.

## Warten auf Georg

PNG-Set für die Würfelseiten → `media/kfb/hud/` · `edge3.jpg` ins Repo · Bundle-Matrix mit dem
Coworker abstimmen.

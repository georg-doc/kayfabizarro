# 10 · Screen-Space-Outlines — Ziel-Spec (Cel-Tusche via Post-Processing)

**Fable-Deliverable · Stand 2026-07-12.** Ziel-Spezifikation *vor* der Implementierung — laut `00_HANDOVER_v4_to_v5.md` Spur-A-Aufgabe #1 und `04` §4. **Nichts freihändig**: der Geometrie-Hull ist nach 4 Anläufen tot (`CHANGELOG_v4`), dies ist der beschlossene Ersatz-Weg. Ein Ding sauber, per Screenshot verifiziert, dann fertig.

## 1. Ziel
Der handgetuschte Cel-Umriss — **„unten dicker", leicht wonky** — über den GANZEN sichtbaren Aufbau (Karten, Würfel, Treppe, Cube-Pet, Requisiten), als **Full-Screen-Post-Pass**, nicht pro Mesh. Fills bleiben die bestehenden Cel-Materialien; der Pass legt nur die Ink-Kante drüber.

## 2. Warum nicht Hull (Abgrenzung)
Inverted-Hull (Normal-Inflate, BackSide) bricht an harten/gerundeten Kanten (Scheren, Tuschefass) → doppelte/aufgerissene Linien; „unten dicker" ist als Vertex-Offset nicht steuerbar. Screen-Space entkoppelt die Linie von der Geometrie → gleichmäßig, breitenmodulierbar, keine Topologie-Artefakte.

## 3. Renderer-Kontext (fix)
**WebGL** (Lead-Entscheid `ADOPTION_MAP`, three ~0.160) — **kein** TSL/WebGPU. Umsetzung mit `EffectComposer` + `ShaderPass` (three/examples). Kein neues Framework.

## 4. Ansatz — Kantenquelle
Kanten aus **Tiefe** (Silhouetten + große Sprünge) plus optional **View-Space-Normalen** (Falten/Kreasen). Reihenfolge bewusst inkrementell:

| Stufe | Quelle | Fängt | Kosten |
|---|---|---|---|
| **10.1 (KISS zuerst)** | nur Tiefe, Sobel/Roberts auf `depthTexture` | Objekt-Silhouetten, Kartenränder, Würfel | 1 Extra-Pass, Depth ist eh da |
| **10.2 (falls Kreasen fehlen)** | + View-Normalen (MRT **oder** separater `MeshNormalMaterial`-Override-Pass) | Innenkanten, Treppen-Stufen, Cube-Pet-Facetten | 2. Pass / MRT |

Start mit **10.1**. Normalen erst nachziehen, wenn im Screenshot Innenkanten fehlen. Depth kcommt aus `WebGLRenderTarget({ depthTexture: new THREE.DepthTexture() })`; linearisieren vor dem Sobel (perspektivische Tiefe ist nichtlinear).

## 5. „Unten dicker" + wonky (die Signatur)
- **Bottom-Bias:** Kantenbreite/-schwelle als Funktion von `screenUV.y` skalieren → Linie am unteren Bildrand breiter (`width = base * (1 + bottomBias * (1 - uv.y))`). Das ist der Kern-Effekt, den der Hull nicht konnte.
- **Boil (wonky):** minimaler, **zeitlich gestufter** UV-Jitter auf dem Sample-Offset (`floor(time*speed)` als Seed, wie Referenz-`Outline.js`), Amplitude klein. **Prime Directive:** Interpunktion, kein Idle-Fidget — der Boil ist dezent und darf die Ruhe nicht stören; abschaltbar.
- **Ink-Farbe:** aus CLAUDE.md — `#1f1a14` (nicht reines Schwarz), als `mix(scene, ink, edgeMask)` bzw. Multiply, nicht additiv.

## 6. Parameter (GUI-Folder „Outline" / Tweak)
`inkColor #1f1a14` · `thickness` (Basis, px) · `bottomBias` (0–2, „unten dicker") · `depthThreshold` · `normalThreshold` (Stufe 10.2) · `boilAmount` · `boilSpeed` (gestuft) · `enabled`. Defaults konservativ, im Screenshot eingestellt.

## 7. Integration (Andockpunkt)
- Szene-Render von `renderer.render(scene, cam)` auf `composer.render()` umstellen; Passes: `RenderPass` → `OutlineShaderPass` (dieser Spec) → (bestehendes Post, falls vorhanden).
- **An das `LOOK`-Setting koppeln:** `cel` = Outline an; `paper` = aus. Kein separater Toggle nötig.
- Resize: RenderTargets + `uResolution`-Uniform bei `sizes.resize` mitziehen (Pixelratio beachten).
- **Teardown:** Composer/Targets `dispose()` beim Szenenabbau (Listener-/Speicher-Hygiene, Diorama-Research §7).

## 8. Performance
Ein zusätzlicher Full-Screen-Pass (10.1) — unkritisch für WebGL/Mobile. Depth wird bereits erzeugt. Erst bei 10.2 ein zweiter Geometrie-Pass; nur wenn nötig. Pixelratio bei schwachen Geräten deckeln.

## 9. Verifikation (Definition of Done)
- Screenshot **genau an den Hull-Bruchstellen**: Scheren-Cut-out und Tuschefass (gerundet) — Linie sauber, keine Doppelung/Risse.
- Karten, Würfel, Quest-Treppe, Cube-Pet: durchgehende Ink-Kante, **unten sichtbar dicker**.
- `paper`-Look: Outline vollständig aus, keine Reste.
- Kein spürbarer FPS-Einbruch mobil.

## 10. Scope-Grenze
**Diese Runde = 10.1** (Tiefe + Bottom-Bias + Ink-Farbe, Boil optional). 10.2 (Normal-Kreasen) ist eine eigene, verifizierte Folge-Runde. Nicht beides auf einmal.

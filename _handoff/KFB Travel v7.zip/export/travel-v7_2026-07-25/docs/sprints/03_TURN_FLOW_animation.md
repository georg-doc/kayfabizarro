# 03 · Turn-Flow als Animation, Transition & Template-Flow

**Für Claude Design / Fable 5.** Ziel: den **kompletten Spielzug** im UI sichtbar machen — jeder Schritt als Ritual-Animation + Transition + Template-Zustand. Scope = **Phase 2** (voller Turn-Loop). Phase 1 (Handover §9) beweist die Einzelteile; dieses Dokument choreografiert sie zum ganzen Zug.

Kern-Doku: `KFB_MED_3D_Table_Handover_v1.md` §5–§7 + §10. Props: `ASSETS.md`. Licht/Schatten/Outline: `04_CEL_SHADING_shadow_lighting.md`.

## Prime Directive (über jeder Animation)

**Social Agency, nicht Object Agency** (§10). Jede Bewegung ist die **Interpunktion einer Rede**, nie Deko. Cartoon-Physics ja — aber **dezent & pleasing**, und jede Bewegung *löst sich auf* (kein Idle-Wackeln, das wäre Fidget). Die Blase auf *deiner* aktiven Karte ist ein **Cue, kein Skript**.

## Der kanonische Turn-Loop (§7)

```
Draw → Roll → Play → Tell → [Social Calls] → Move → (King rotiert → nächster Seat)
```

> Korrektur zur ersten Skizze: **Draw ist vorne** (Hand 3→4; das Ausspielen bringt zurück auf 3, kein separater Refill hinten). **Social Calls lösen sich in den Move auf** (King's Verdict bewegt die Treppe; BLÖDSINN steht → Marker bewegt sich diesen Turn nicht).

---

## Schritt für Schritt — Zustand · Template · Animation · Asset · Kamera

### 0 · Rest-State (zwischen Zügen)
- **Template:** Tisch + Schneidematte; 3 Stage-Slots (aus Vorzügen ggf. gefüllt); Quest-Karte neben der Stage; Quest-Marker auf der Treppe an aktueller Position; beide Würfel liegen; Handfächer (3, Solo face-up); Deck-Cover-Objekt; Mode-Chip (Special-Elite) zeigt letzten Mode; Mood-Wash = letzter Mode.
- **Bewegung:** keine. Alles ruht (kein Bob). Nur der Papier-Grain lebt.

### 1 · Draw (Hand 3 → 4)
- **Zustand:** eine Karte vom Shared-Deck auf die Hand.
- **Animation (Ritual „der Deal"):** Karte hebt vom Deck-Cover ab, **Bogen** zum Handfächer, Fächer öffnet neu. Snappy rein, weich settlen.
- **Asset:** Deck-Cover-Objekt (Quad-Stack), Handkarten (Quads).
- **Kamera:** leichter Nudge Richtung Hand. **Sound:** Papier-Slide.

### 2 · Roll (Story-Mode Die, 3D) — der große Farbmoment
- **Zustand:** Story-Mode für diesen Turn wird gesetzt & committed.
- **Animation:** Der Story-Mode-D6 **taumelt** (3D, physik-nah), **bounct 2×, settlet** (Overshoot ~6 %) auf eine Fläche. **Auf Settle:** Mood-Wash flutet Stage + Quest in `ink/panel` dieses Modes (die 6 kanonischen Farben), Rim-Light wechselt auf Mode-Ink (siehe `04`, „Mode als Licht-Kanal"). Mode-Chip aktualisiert.
- **Asset:** `arunangshubanerjee-dice` (Story-Mode-D6).
- **Kamera:** kurzer Fokus auf den Würfel → Pullback auf die Stage. **Sound:** Würfel-Klack + tiefer „Wash"-Ton.
- **Guardrail:** Frame, nicht Käfig — widerspricht die Story später der Farbe, ist *das* die Story.

### 3 · Play (1 Handkarte: Scene oder Actor)
- **Zustand:** 1 Karte in leeren Stage-Slot (Scene) **oder** als neuer Actor (Actor-Switch). Danach zurück auf 3 Hand.
- **Animation (Card-Ritual „Show it · Spin it · Sell it"):** Karte fliegt zum Slot → **stellt sich auf** (Pop-up, Scharnier vom Tisch, Overshoot) → **Spin/Flip** zeigt die Front → settlet mit kleinem Bounce + **Cue-Blase**. Hand fächert auf 3 zurück. **Placement-Jitter** (leichte seeded Rotation/Offset → handgemacht).
- **Asset:** Karten-Quads (PDF→CanvasTexture, §8).
- **Kamera:** folgt der Karte in den Slot. **Sound:** Aufstell-„tock" + Flip-„fwip".

### 4 · Tell (Kayfabulate — Narrator-Box) — der Kern
- **Zustand:** als dein Actor, First Person, im gerollten Mode. 3 Stage-Panels weben, auf dem Quest landen. Power gewoben → Discard; Power übersprungen → bleibt bis Overwrite.
- **Animation (Finger-Regel als Spotlight-Blase, §5):** Karaoke-Zoom auf die Actor-Karte (~85 % Viewport, Rest dimmt). Die **Spotlight-Blase hüpft**:
  1. **Actor-PoV** (Blase startet an der Actor-Karte),
  2. **Scene 1 → 2 → 3** — **Reihenfolge treibt der Spieler** (die Blase folgt seinem Fokus, nicht einem Skript),
  3. **Quest-Karte** — die letzte, **größere** Blase = der Push/die These des Turns.
- **Cartoon-Physics beim Hüpfen (dezent):** die Karte, auf der die Blase landet, **springt kurz hoch** — Squash/Stretch (scale y ~1.08 / x ~0.96), kleiner Overshoot, kritisch gedämpft settlen. Kein Floaten, kein Nachwackeln.
- **Narrator-Box:** zeigt den **Cue** (nicht den fertigen Satz — Guardrail: auf deiner Karte Cue, nicht Skript). Endzustand mit Voice (Phase 4): deine Worte füllen die Blase.
- **Kamera:** Karaoke-Zoom hält den Fokus, mikro-schwenkt der Blase nach. **Sound:** weicher „pop" pro Hop.

### 5 · Social Calls (nach dem Tell, vor dem Move)
- **Zustand:** jeder Seat darf callen (Phase 2: Buttons; Phase 3: KI-meat-puppets; Phase 4: Voice).
- **Calls:** **KayfaBINGO!** (gelandet/Lob) · **KayfaBOGGLE?** (Frage, aktiver Spieler klärt in 1–2 Sätzen) · **KayfaBONGO!** (Power als Stat statt Story → umformulieren) · **BLÖDSINN!** (Kayfabe gebrochen, Mehrheitsvote).
- **Animation:** Call-Button gedrückt → Comic-Burst-Blase („KayfaBINGO!") ploppt am rufenden Seat (Bangers-Typo, Mode-Ink). Steht **BLÖDSINN** (Mehrheit): der Quest-Marker „schüttelt den Kopf", **bewegt sich diesen Turn nicht**.
- **Kamera:** kurzer Cut/Schwenk zum rufenden Seat. **Sound:** Buzzer je Call-Typ.

### 6 · Move (Quest Die = King's Verdict, Treppe hoch)
- **Zustand:** der **King** (nächster Seat, rotierender Judge) spricht das Verdict → Quest-Marker **+2 / +1 / 0 / −1** (nie unter 1, bei 6 = Finale). **Nicht gerollt — bewegt.**
- **Animation:** Marker **klettert** N Stufen die Papp-Rampe hoch (Cartoon-Bogen pro Stufe, kleiner Bounce beim Landen). Die 6 Positionen aus `ASSETS.md` (Treppen-Bounding-Box). Bei **6:** Finale-Flourish (Treppen-Top glüht in Mode-Ink). Später: FrizzleBob-Hase (`ASSETS`) als King-Avatar spricht das Verdict.
- **Asset:** `pixellabs-stairs` (Quest-Leiter) + Marker.
- **Kamera:** Schwenk auf die Treppe für den Verdict-Beat. **Sound:** Stufen-„tap" ×N + (bei 6) Fanfare.
- **Danach:** King rotiert zum nächsten Seat → zurück zu Rest-State.

---

## Template-Flow (Transitions als Zustandsdiagramm)

```
REST ──Draw(≈0.6s)──▶ HAND+1
     ──Roll(≈1.2s, +wash)──▶ MODE_SET
     ──Play(≈1.0s, +ritual)──▶ STAGE_UPDATED
     ──Tell(karaoke-loop)──▶ actor▸s1▸s2▸s3▸quest   (spieler-getaktet, je Hop ≈0.4s)
     ──Calls(≈offen)──▶ CALLS_RESOLVED
     ──Move(≈0.5s/Stufe)──▶ QUEST_ADVANCED
     ──King rotiert──▶ REST (nächster Seat)
```

Jeder Pfeil = eine Transition-Animation. Dauern sind Richtwerte; der Tell ist **spieler-getaktet** (nicht auto-advancen — die Blase wartet auf den Spieler-Fokus).

## Cartoon-Physics-Vertrag (einmal, für alle Bewegungen)

- Kritisch gedämpfte Feder auf Position **und** Scale. Overshoot klein (~5–8 %).
- Squash/Stretch nur beim „Hochspringen" (Tell-Hop, Card-Aufstellen, Marker-Landen).
- Snappy rein, weich settlen. **Keine** floatigen Ease-Kurven, **kein** Idle-Bob.
- Jede Bewegung endet in Ruhe. Bewegung = Interpunktion der Rede, nicht Dauerzustand.

## In diesem Pass gestubbt

- **Resolver** (Ref→Anzeige): Stub / Beispiel-Pack (§8, `02_OPEN_DECISIONS`).
- **KI-King & KI-Calls:** Phase 3 — hier ist der King ein Script/der Solo-Spieler selbst.
- **Voice:** Phase 4.

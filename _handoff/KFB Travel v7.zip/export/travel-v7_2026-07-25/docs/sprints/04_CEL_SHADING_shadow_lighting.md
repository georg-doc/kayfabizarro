# 04 · Cel-Shading, Schatten & Outlines — das fehlende 3D-Look-Konzept

**Für Claude Design / Fable 5.** Ein **einziges kohärentes** Licht-/Schatten-/Outline-System für den Tisch, damit Props, Karten und Diorama als *eine* handgezeichnete Welt lesen. Verdichtet + auf den Tisch angewandt aus `ART_DIRECTION_benchmark.md`. Reskin-Schritte je Prop: `ASSETS.md`.

## Nordstern in einem Satz

**Animationsfilm auf einem Zeichentisch — flache Farbstufen, Tusche-Linie, gedruckter Schatten. KEINE glatten digitalen Verläufe, kein Plastik-Glanz, kein weicher Casino-Schatten.**

---

## 1 · Die Lichtquellen (diegetisch motiviert)

Drei Lichter, motiviert durch „Künstler an der Zeichenlampe":

- **Key (Schreibtischlampe):** warm, von vorne-oben. Wirft die **Cast-Shadows**. Definiert die Cel-Bänder (Schwelle = N·L).
- **Fill:** kühl, tief, weich (Hemisphere/Ambient). Hebt das dunkelste Band **von reinem Schwarz weg** — Schatten leben, sind nicht tot.
- **Rim/Back = MODE-KANAL:** Farbe = aktueller **Story-Mode-Ink** (die 6 kanonischen Farben). Zeichnet die Silhouetten-Kante nach. **So tintet der Mode-Roll nicht nur den Wash, sondern das Licht** — eine Stimmungsquelle, alles folgt.

## 2 · Cel-Shading (die Oberfläche)

- `MeshToonMaterial` + quantisierte `gradientMap`, **`NearestFilter`** → **2–3 harte Bänder** (Licht / Mitte / Schatten). Niemals smooth.
- Bänder-Schwelle vom Key-N·L. Fill lupft das dunkelste Band an. Rim (Mode-Ink) auf der Silhouette.
- **Papier/Karton-Textur** auch im Licht-Band (Grain/Zahn), damit selbst die helle Fläche nicht Plastik ist.

## 3 · Cast-Shadows — das bisher fehlende Stück

Der Tisch ist eine **Bühne**: stehende Karten und Props werfen **echte Schatten auf die Schneidematte**. Aber im Comic-Vokabular:

- **Hart-kantig, eine Dichte, leicht versetzt, getönt** (nicht schwarz — dunklere Matten-Farbe + Hauch Mode-Ink), wie ein gezeichneter Schlagschatten.
- **Methode:** Shadow-Map, aber **posterisiert/hart** — Toon-Shadow-Shader, der den Schatten auf **einen** flachen Wert + scharfe Kante steppt (statt weichem PCF-Verlauf). Alternativ ein Shadow-Catcher-Material auf der Matte, das den empfangenen Schatten quantisiert.
- **Contact-Shadow (Anker):** kleine dunkle AO-Pfütze **direkt unter** jedem Objekt. Das ist es, was die Pop-up-Karten **auf dem Tisch stehen** lässt statt schweben. Ohne das wirkt das Diorama flach/klebrig.

## 4 · Outlines — gewichtet nach Licht UND Entfernung

Nicht eine uniforme CG-Linie. Zwei Modulationen:

- **Entfernung:** Inverted-Hull-Breite **fällt mit Kamera-Distanz** (Hoyoverse distanz-adaptiv) — ferne Karten dünne Linie, nahe Karten dicke Tusche. Verhindert Zuklumpen.
- **Licht:** die Linie ist **nicht gleich dick** — sie **verdickt auf der schattigen/vom-Key-abgewandten Seite** (Pinsel-Linie sammelt sich, wo kein Licht ist) und **dünnt/bricht auf der Licht-Seite** (Licht „frisst" die Linie). Das ist der Hand-Tusche-Look: Linienstärke folgt Form + Licht. Umsetzung: Hull-Breite über N·L modulieren (abgewandt = dicker).
- **Depth/Normal-Edge (Post-Process):** dünne Linie an inneren Kanten/Falten + wo Objekte sich treffen, damit auch **innere Struktur** (nicht nur Silhouette) liest.

## 5 · Halftone = zweite Schatten-Ebene (aus ART_DIRECTION §4b)

- **Nur im Schatten-Band:** Screen-Space-Halftone-Raster als **Textur im Schatten** (Comic-Modell: Tusche = Schatten-Form, Screentone = feiner Ton darin).
- **Selektiv, nicht global.** Scharfe Punkte, **kein** Verlauf. Dichte = Schatten-Tiefe. Verstärkt „keine Verläufe" und den Print-Look.

## 6 · Was zu vermeiden ist

Glatte Verläufe · Plastik-Specular · weiche/blurrige Schatten (Casino) · rein-schwarzer Schatten (tot) · uniforme Outline (CG-getraced) · globales Halftone (matschig).

---

## 7 · three.js-Rezept (KISS-Stufen)

**Stufe A (80 % des Looks, zuerst):**
1. `MeshToonMaterial` + `gradientMap` (3 Stufen, `NearestFilter`) auf alle Props/Karten.
2. `DirectionalLight` Key (`castShadow`, Shadow-Map) + `HemisphereLight` Fill + `DirectionalLight`/`PointLight` Rim in **Mode-Ink**.
3. Harter Schatten: Shadow-Map mit kleinem/keinem PCF **oder** Shadow-Catcher-Material auf der Matte, das den Wert steppt.
4. **Contact-AO-Pfütze** unter jedem Objekt (einfacher dunkler Radial-Blob-Decal / gebackenes Quad).
5. **Inverted-Hull-Outline**, Breite = `base * distanzFaktor * (1 + schattenFaktor*k)`.

**Stufe B (Politur, später):**
6. Post-Process Depth/Normal-Edge (z. B. `OutlinePass` oder Custom) für innere Kanten.
7. Screen-Space-Halftone-Pass, **maskiert auf Luminanz < Schwelle** (nur Schatten).

## 8 · Kopplung an den Turn-Flow

Beim **Roll** (`03` Schritt 2) wechselt der **Rim/Back-Light auf den neuen Mode-Ink** und der Wash flutet — derselbe Moment, eine Quelle. Beim **Karaoke-Zoom** (Tell) darf der Key leicht enger/kontrastreicher ziehen (Spotlight-Gefühl), ohne die Bänder aufzuweichen.

# 05 · Artist-Studio-Wand — gerahmte PDF-Viewer, Parallax-Bilder, Fenster

**Für Claude Design / Fable 5.** Die **Wand des 3D-Ateliers** als diegetische Navigation (erweitert Handover §3 „Wand", Phase 2). Gerahmte Objekte, leicht schräg, im FoV auf der Wand. Cel-Look/Schatten: `04`. Props/Tisch: `03`, `ASSETS.md`.

## Prime Directive (Guardrail §10)

Diegetische Navigation darf **keine Bedienbarkeit kosten**. Ein **kleiner kanonischer Satz interaktiver Requisiten** (die zwei PDF-Viewer, die Deck-Preview) + eine flache **Fallback-Leiste**, die dasselbe tut. Alles andere an der Wand = **Atmosphäre, nicht klickbar**. Sonst wird die Bühne ein Wimmelbild. „One input = one meaning."

## 1 · Der Raum-Shell (zwei Wege, KISS zuerst)

- **A — KISS (empfohlen für den Start):** eine **Wand-Fläche + Boden** als schlichte Planes, Wand mit **dezenter Tapete** (Image-URL wie die `skydome_a.webp`-Wasserfarb-Grafik, gekachelt/soft). Die Rahmen sind schräge Quads davor. Reicht, um das Konzept zu beweisen.
- **B — Möbliert (später):** `kenney_furniture-kit` (liegt in `3D Assets/`) für Regal/Tisch/Stuhl-Set-Dressing, `kenney_prototype-kit` (Greybox-Wände/Boden/Treppe) fürs Raum-Blocking. Cel-reskinnen wie in `ASSETS.md`. Atmosphäre, kein Gate.

→ Start mit A. Möbel sind Politur (Handover §10 „Unfinished by Design").

## 2 · Die Wand-Objekte (alle leicht schräg, seeded Jitter)

Tiefenordnung von der Wand weg zur Kamera: **Fenster (tief) < Bild-Rahmen (mitte) < PDF-Viewer (wandnah)**.

### a · PDF-Viewer 1 — Anti-Rules (16:9 quer)
Die knappen Anti-Rules zum **Durchblättern im Close-up**. Quelle: `KayfaBizarro — The Anti-Rules · Booklet (A4-quer print).pdf` (A4-quer = passt ins Landscape-Frame). Klick → Kamera dollyt heran, Blätter-Modus.

### b · PDF-Viewer 2 — illustriertes Rule-Book (16:9)
Das illustrierte Comic-Booklet, später **swappbar für Deck-Previews** (URL-basiert). Quelle: `Kayfabizarro_Freestyle_ComicBooklet_WEB_v1.pdf` (liegt schon im `media/kfb`-Spiegel). Deck-Previews: die WEB-PDFs im selben Ordner (Protopia, Reality Redrawn, ShadowPolitics, What Work Was For …).

### c · Bild-Rahmen mit Parallax (jetzt konkret bestückt)
Jedes Bild sitzt auf einer Ebene **leicht HINTER** dem Rahmen-Glas → bewegt sich je nach Blickrichtung minimal hinterm Rahmen (Tiefen-Parallax, §3).

- **Frame 1 — quadratisch, GELBER Rahmen, FB-Story-Mode-Slideshow.** Die quadratischen FB-Avatare (`FrizzleBob_*_01.png`) rotieren als **Slideshow mit passenden Transitions** (Parallax auf dem aktiven Slide). Optionaler Hook: an den **Story-Mode-Die koppeln** — gerollter Mode zeigt den passenden FB (Absurd→AbsurdPsychedelic, Tragic→Sad, Forbidden→Shock, sonst→SmugDefault). **Set noch unvollständig (4/6):** vorhanden Absurd, Sad, Shock, SmugDefault; **Heroic + Mystical fehlen** → Slideshow rotiert nur das Vorhandene, Mode-Sync fällt bei fehlendem Mode auf `SmugDefault` zurück.
- **Frame 2 — FB „Wanted"-Poster.** `FrizzleBob_Wanted_01.png` als gerahmtes Fahndungsplakat (Hochformat-Poster-Anmutung), leicht schräg, Parallax.
- **Frame 3 — offener Slot** (z. B. King Kayfabian, später). Interim leer oder ein weiterer FB.

### d · Fenster (Parallax, weiter weg)
Gerahmte Plane, **tiefer gesetzt als die Bild-Rahmen** → stärkere Parallax, liest als „draußen". Doppelt als **diegetische Lichtquelle** (Tageslicht-Key, `04`).
- **BG:** Wasserfarb-Shader ODER Image-URL (`skydome_a/b.webp`-Anmutung).
- **Eitelsonnenschein-Foto am Rand:** das **Querformat** `George_Eitelsonnenschein_*_ARD_Buffet_SWR-lowres.png` sitzt **am Fenster-Rand** (nicht zentral) und schiebt sich per Parallax leicht ins Bild — als würde draußen jemand vorbeischauen. `crop`-Variante für engeren Ausschnitt.

## 3 · Parallax-Technik (konkret, KISS)

- **Echte Geometrie-Parallax (kein Shader nötig):** Rahmen = äußeres Quad (Rahmen-Rand, opak) + inneres Content-Quad, in **−Z versetzt** um `d`. Bewegt sich die Kamera, verschiebt sich das innere Quad scheinbar hinterm Rahmen. `d` klein für Bild-Rahmen, groß fürs Fenster.
- **Alternativ fürs Fenster:** billiger **UV-Offset-by-View-Shader** (BG scrollt gegen die Blickrichtung).
- **Schräglage:** kleine seeded Rotation pro Rahmen (wie der Placement-Jitter der Karten) → handgehängt, nicht CAD-gerade.
- **Slideshow-Transition (Frame 1):** cel-konsistent, **kein** glänzendes Fade — z. B. Papier-Slide (nächster FB schiebt den alten raus) oder Halftone-Wipe (Punktraster deckt auf/zu). ~4–6 s pro Slide, weiche Ease-out-Rast. Bei Mode-Sync: Wechsel triggert der Roll (`03` Schritt 2), sonst Auto-Rotation.

## 4 · Interaktion & PDF-Pipeline

- **Close-up:** Klick auf Viewer → Kamera dollyt heran, Rest dimmt (wie Karaoke-Zoom). Blättern = Seite vor/zurück (bei Landscape ggf. Doppelseite). Zurück-Geste verlässt.
- **Pipeline = die der Karten wiederverwenden:** `PDF.js` Page-Render → Offscreen-Canvas → `THREE.CanvasTexture` auf das Viewer-Quad. **LRU-Cache**, lazy (nur sichtbare Seite hochauflösend). Kein `<embed>`.
- **Fallback-Leiste:** flache Buttons „Regeln · Rule-Book · Deck wählen" tun dasselbe wie die Rahmen (§10).

## 5 · Quelle-Entscheidung (deine offene Frage — aufgelöst)

**GitHub/URL-basiert, konsistent mit den Decks — jetzt live.** Alles per raw-URL, pdf.js/Texture-Loader ziehen direkt, CORS `*`. Leerzeichen als `%20` encodieren.

**PDF-Viewer:**
- **Anti-Rules (a):** `https://raw.githubusercontent.com/georg-doc/kayfabizarro/main/media/kfb/KayfaBizarro%20-%20The%20Anti-Rules-Booklet%20-%20A4-quer%20print%20v4.pdf` — **hochgeladen ✅**
- **Rule-Book (b):** `https://raw.githubusercontent.com/georg-doc/kayfabizarro/main/media/kfb/Kayfabizarro_Freestyle_ComicBooklet_WEB_v1.pdf`
- **Deck-Previews (b, später):** weitere WEB-PDFs im selben `media/kfb/`-Ordner, swap per URL.

**Bilder — Base:** `https://raw.githubusercontent.com/georg-doc/kayfabizarro/main/FrizzleBob/FrizzleBob%20Avatar/`
- Frame 1 Slideshow (quadratisch): `FrizzleBob_AbsurdPsyhcedelic_01.png` · `FrizzleBob_Sad_01.png` · `FrizzleBob_Shock_01.png` · `FrizzleBob_SmugDefault_01.png` (4/6, Heroic+Mystical folgen)
- Frame 2 Wanted: `FrizzleBob_Wanted_01.png`
- Fenster-Rand (quer): `George_Eitelsonnenschein_ARD_Buffet_SWR-lowres.png` (bzw. `..._crop_...`)

## 6 · Assets — vorhanden vs. zu liefern

| Zweck | Status |
|---|---|
| Raum-Shell (Greybox/Möbel) | ✅ `kenney_prototype-kit` + `kenney_furniture-kit` in `3D Assets/` |
| Tapete / Fenster-BG | ✅ `skydome_a.webp` / `skydome_b.webp` als Referenz (Wasserfarbe) |
| Rule-Book-PDF | ✅ im Repo (URL §5) |
| Anti-Rules-PDF | ✅ hochgeladen (URL §5) |
| Deck-Preview-PDFs | ✅ im `media/kfb` |
| FB-Story-Mode-Avatare (Frame 1) | ✅ 4/6 im Repo; Heroic+Mystical folgen |
| FB-Wanted (Frame 2) | ✅ im Repo |
| Eitelsonnenschein-Foto (Fenster) | ✅ im Repo |
| King Kayfabian (Frame 3) | ❌ offener Slot, später |

## 7 · Cel-Look-Kopplung (`04`)

Wand, Rahmen, Möbel laufen durchs selbe System: Cel-Bänder, **harte getönte Schatten** (Rahmen werfen kleinen Schatten auf die Wand = Tiefe), Outline gewichtet nach Licht & Distanz. Das **Fenster ist Lichtquelle** (Tageslicht-Key) — Rim bleibt Mode-Ink. Ferne Rahmen = dünne Linie (Distanz-Falloff).

## 8 · Phasing

Das ist **Phase 2** (Nav-Wand). **Phase 1 bleibt der Tisch** (`03`). Wand erst, wenn der Tisch-Slice steht. Reihenfolge halten: ein Ding sauber, visuell verifiziert, dann das nächste.

# Handover — KFB Table v2 → Cowork-Lane (Engine/SSOT-Lead)

**Von:** Fable-Design-Lane (Table), 2026-07-12. Schwester-Datei zu `HANDOVER_cowork_lead.md` (Ride-Lane) — dies ist die Table-Lane.

## 1. Stand

`KFB Table v2.dc.html` + `kfb-table.v2.js` eingecheckt (Default cel). Voller Turn-Slice spielbar: Draw→Roll→Play→Tell→Calls→Verdict→King-Rotation; Studio-Wand mit 2 PDF-Viewern (Anti-Rules/Rule-Book direkt von eurem Repo), FB-Menü (Auto-Play/Explain/Select-Stub), Quest-Treppe mit Cartoon-Physics-Resolvement. Changelog v2 hat die volle Liste + **Outline-Post-Mortem** (bitte lesen — „unten dicker" ist als Vertex-Hull nicht lösbar, Phase-3-Empfehlung: Screen-Space).

## 2. Was wir von euch brauchen

1. **Kanonische S.16-Hex** — `MODES` in kfb-table.v2.js trägt Interim-Werte (ink/panel je Mode), Swap = ein Edit.
2. **`page`+`quadrant` pro Karte in den Deck-JSONs** (zugesagt) — ersetzt unsere rechnerische Ableitung `page = COVER_OFFSET + 1 + floor((n-1)/4)`, `cell = (n-1) % 4`. COVER_OFFSET je Deck mitliefern!
3. **Kartenrücken-Artwork** (§11.3) — aktuell generierter Platzhalter.
4. **Deck-Manifest für Multi-Deck:** Für „Select Decks" (FB-Menü, P1 im Backlog) brauchen wir pro Deck: JSON-URL, PDF-URL, COVER_OFFSET, Kartenzahl. GitHub-raw reicht.
5. **FrizzleBob-Voice-Skill-Andockpunkt** für „Explain Rules" (aktuell: Kamera-Dolly auf das PDF).
6. **FB-Avatar-Texturen** (Augen-Glanzlicht, Shirt) falls ihr UV-Maps zum Hasen-GLB habt.

## 3. Nähte / Andockpunkte im Code

| Vertrag | Stub heute | Andockpunkt |
|---|---|---|
| Deck-Quelle | lokal `data/deck_b.json` + `assets/deck_b.pdf` | Konstanten `DECK_JSON`/`DECK_PDF`/`COVER_OFFSET` (Kopf der Datei) |
| Mode-Farben | `MODES` Interim | dito |
| King's Verdict | manuelle Buttons +2/+1/±0/−1 | `_moveQuest(d)` |
| Auto-Play (KI-Zug) | Zufallskarte / phasen-passende Aktion | `_autoPlay()` |
| Voice (Explain Rules) | `_enterViewer(viewers[0])` | FB-Menü-Handler `data-fb="rules"` |
| Flächen-Content | `setSurface(name, url)` Bild/Video | ☰-Modal-Inputs `.kfb-surf` |

## 4. Bekannte Grenzen

- pdf.js-Worker kann in gedrosselten iframes stallen → 15-s-Timeout + Retry-Swap ist eingebaut; Erst-Boot zeigt dann kurz Platzhalter-Karten.
- Outlines: Scheren + Tuschefass bewusst ohne Hull (buggy an Rundungen); Screen-Space-Outlines sind der Phase-3-Weg.
- YouTube auf Flächen geht nicht als WebGL-Textur (iframe) — CSS3D-Overlay nötig.

## 5. Nächste „für v3"-Anweisung

Eine Datei, wie gehabt — Vorschlag: Deck-Manifest-Schema + kanonische Hex zusammen, dann bauen wir den Multi-Deck-Switch in einem Rutsch.

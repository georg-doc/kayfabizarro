# KFB Ink Outline Style — v1

**Status: KANONISCH** · Stand 2026-07-15 · KayfaBizarro

Der hand-geinkte Comic-Kanten-Look von KFB, festgehalten als wiederverwendbares System für Cards, Buttons, Boxen, UI-Chips, HUD und (abgeleitet) 3D-Pets. Ein deterministischer 2D-Canvas-Algorithmus, keine Bilder, keine Abhängigkeiten.

- **Interaktive Doku / QA / Playground:** `KFB Ink Outline Spec.dc.html` (standalone: `export/KFB-Ink-Outline-Spec-v1-standalone.html`)
- **Kanonisches Modul:** `kfb-ink.js` (Repo-Root, Single Source of Truth)
- **Erstmalige Referenz-Implementierung:** `comic-cube.v2.js` (`KFB Diorama Box.dc.html`)

---

## 1 · Die Idee

Tusche liegt **auf der Bildebene, nicht am Objekt**. Eine geschlossene, unregelmäßige Outline wird entlang eines Rechtecks (oder Quads) gelaufen und mit einer wobbly Tusche-Linie nachgezogen. Zwei Eigenschaften machen den Look aus:

1. **Deterministisch** — die Kante ist seeded-zufällig: gleicher `seed` → exakt gleiche Kante. Reproduzierbar für QA, Snapshots, Caching. Nie `Math.random()`.
2. **Größen-ehrlich** — immer bei echter Zielgröße gezeichnet (× `devicePixelRatio`), nie ein skaliertes SVG/Bild, das die Strichbreite verzerrt.

---

## 2 · Die zwei Stile

Ein Perimeter-Generator, zwei Strichbreiten-Regeln.

| Stil | Rolle | Strichbreite | Positions-Jitter |
|---|---|---|---|
| **`inked`** | Default für UI + Raum-Panels | gleichmäßige Grundbreite `baseW` + organischer Wobble; gegenüberliegende Kanten gleich dick → **konsistentes Gutter** | klein (≈4), ruhige/lesbare Kante |
| **`torn`** | Effekt-Look (ausgerissenes Papier) | Licht-Logik: oben dünn (`topW`) → unten dick (`botW`) | groß (≈9), ausgerissener Rand |

> `inked` **nie** mit `topW`/`botW` mischen — die Licht-Logik gehört ausschließlich zu `torn`.

---

## 3 · Mathematik & Logik — vier Bausteine

### 1 · `mulberry(seed)` — seeded PRNG
32-bit Integer-Hash-Generator. Liefert bei gleichem Seed dieselbe `[0,1)`-Folge. Damit ist jede Kante **non-repetitive** (jeder Vertex anders) und trotzdem **stabil** (Reload = identisch).

### 2 · `inkPerimeter(x0,y0,x1,y1,seed,jit)` — die Kante
Läuft die 4 Rechteck-Kanten ab und teilt jede in Segmente von ~34 px Länge:

```
n = max(3, round(len / 34))
```

Jeder Zwischenpunkt wird um `±jit` px in x und y verschoben; die vier Ecken bleiben fix (kein Jitter am Index 0 jeder Kante → geschlossene Form ohne Lücke). Gibt ein Array wobbly Punkte zurück.

- `jit` klein (≈4) → ruhige Kante · `jit` groß (≈9) → ausgerissen
- Segmentlänge 34 px steuert die Wobble-Frequenz (Punktdichte)

### 3 · `drawInkOutline(g,pts,y0,hgt,opts)` — der Strich

```
inked:  lineWidth = baseW · (1 + wob · (smooth(i) − 0.5) · 2)
torn:   lineWidth = topW + (botW − topW) · my        // my = vertikale Position ∈ [0,1]
```

**inked** (`uniform:true`): Grundbreite `baseW`, moduliert durch einen **geglätteten** Low-Freq-Wobble (3-Punkt-Mittel über eine zweite Seed-Folge `wseed`), Amplitude `wob`. Weil der Wobble gleichverteilt über den ganzen Perimeter läuft, sind gegenüberliegende Kanten im Schnitt gleich dick.

**torn**: Breite linear interpoliert `topW → botW` nach vertikaler Position `my`.

### 4 · `inkChip(g,…,opts)` — Fill + Outline in einem
Convenience für UI-Boxen: füllt die wobbly Form (`opts.fill`) und zieht dann dieselbe Outline drüber. Für `background-image` auf einem DOM-Element, gezeichnet bei dessen realer Größe × dpr (siehe `paintChipEl`).

---

## 4 · 3D-Invariante — Fluchtlinien ohne Geschummel

Wenn Panels als Texturen auf gekippte 3D-Quads gemappt werden, verjüngt die **echte Perspektive** den uniformen Strich zum Bildrand hin von selbst — ferne Kanten werden dünner, die Naht zum Held bleibt dick.

Das ist **rotationssicher**: eine in die Textur eingebackene Richtungs-Verjüngung würde brechen, sobald ein Panel durch die Slots rotiert (was in Slot E die ferne Kante ist, ist in Slot W die nahe). Deshalb: **Strich uniform lassen, Perspektive die Flucht machen lassen.**

Zum Ausgleich der perspektivisch gestauchten Naht bekommen Nachbar-Panels eine leicht kräftigere Grundbreite: Faktor **`nbInk`** (1.0 = maximal Flucht/Fokus auf Held · höher = konsistentere Naht).

---

## 5 · Parameter-Referenz

| Param | Einheit | Bedeutung |
|---|---|---|
| `seed` | int | Wählt die Zufallsfolge. Gleicher Seed = gleiche Kante. Pro Element eindeutig aus id/index ableiten. |
| `jit` | px | Positions-Jitter der Kanten-Punkte. ≈4 ruhig (inked) · ≈9 ausgerissen (torn). |
| `baseW` | px | inked-Grundstärke des Strichs. Der visuelle Kern der Kantendicke. |
| `wob` | 0–1 | inked-Wobble-Amplitude der Strichbreite. 0 = konstant · .5 = lebendig · 1 = stark. |
| `topW` / `botW` | px | torn-Breite oben / unten (Licht-Verlauf). Nur im torn-Stil. |
| `nbInk` | × | Grundbreiten-Faktor für Nachbar-Panels im 3D-Raum (Naht-Ausgleich gegen Perspektive). |
| `color` | hex | Tusche-Farbe. Kanonisch `#191410` / `#1f1a14`. |
| `m` (Rand) | px | Sicherheitsrand ≥ halbe max. Strichbreite + jit, sonst Abschnitt am Elementrand. |

---

## 6 · Anwendungsrezepte

```js
// BUTTON — Akzent-Fill, mittlere Breite
inkChip(g, m, m, w-m, h-m, 41, { fill:'#b8361f', uniform:true, baseW:6, wob:.5, jit:1.6 });

// HUD-CHIP — Papier-Fill, dünn
inkChip(g, m, m, w-m, h-m, 11, { fill:'#f7f0da', uniform:true, baseW:4, wob:.5, jit:1.4 });

// CARD / PANEL — geclippt, dann Outline
const pts = inkPerimeter(m, m, w-m, h-m, seed, 4);
// clip(pathOf(pts)) → Papier + Inhalt füllen
drawInkOutline(g, pts, m, h-2*m, { uniform:true, baseW:11, wob:.5, wseed:seed });

// DOM-Chip bequem (nach document.fonts.ready erneut aufrufen)
KFBInk.paintChipEl(el, 29, { fill:'#f7f0da', uniform:true, baseW:4, wob:.5 });
```

---

## 7 · Goldene Regeln — Do & Don't

**✓ Immer**
- Bei echter Zielgröße zeichnen (× dpr), nie ein Bild skalieren.
- Pro Element einen eigenen, stabilen `seed` (aus id/index).
- `lineCap`/`lineJoin = 'round'` (macht das Modul).
- UI nach `document.fonts.ready` neu malen.

**✕ Nie**
- `Math.random()` für die Kante — bricht QA/Reproduzierbarkeit.
- Outline als kleines SVG rendern und per CSS strecken → Strichbreite verzerrt.
- Richtungs-Verjüngung in eine rotierende Textur backen (siehe §4).
- `inked` mit `topW`/`botW` mischen.

---

## 8 · Ableitung — 3D Cel-Ink für Cube-Pets  *(PROPOSAL · v1.1 · nicht implementiert)*

Der 2D-Look lässt sich nicht 1:1 auf ein Mesh übertragen (Textur-Outline verzerrt an Kanten). Die richtige Entsprechung ist die **Inverted-Hull-Silhouette** mit variabler Breite — gleiche Design-Absicht (dicke, wonky, hand-geinkte Kante), im 3D-Raum. Deckt sich mit `docs/research_cel` und dem v6-Hull.

- **A · Inverted Hull pro Objektklasse:** Mesh dupliziert, Normalen invertiert (`BackSide`), entlang Normalen extrudiert. Breite pro Klasse: Figur/Pet stark, Karte dünn, Requisiten nur nah. Skinned Meshes: Hull als `SkinnedMesh` + `bind()`.
- **B · Variable Breite = Wobble-Ersatz:** `w = base · (0.6 + 0.9·shadow)` (Schattenseite dicker) + `downCut` (nach unten gerichtete Normalen dämpfen, gegen Boden-Blobs). Optional statischer Vertex-Noise = 3D-Äquivalent des `jit`.
- **C · Distanz- & N·V-Fade:** Breite skaliert mit Kamera-Distanz (fern = dünner, gleiche Fluchtlinien-Idee wie 2D) und optional `N·V` für saubere Silhouetten. Ink `#1f1a14`, gekoppelt an `LOOK=cel`.
- **⚠ Grenze (v6-Post-Mortem):** „unten dicker" ist als reiner Vertex-Offset nicht sauber erreichbar (Boden-Blobs). Für exakte licht-variable Breite bleibt Screen-Space-Outline (Depth/Normal-Sobel) der Kandidat. Kontakt-Schatten separat als harte, posterisierte Ink-Blobs (kein Blur).

---

## 9 · Caveats

- **Eingebackene Verjüngung × Rotation** — Taper in der Textur überlebt keine Panel-Rotation. Lösung: Perspektive + `nbInk`.
- **CSS-Skalierung der Outline** — `background-size:100% 100%` auf falsch dimensioniertem Canvas streckt die Linie ungleichmäßig. Immer Ist-Größe × dpr.
- **Font-Timing bei UI-Chips** — `offsetWidth/Height` ist vor Font-Load falsch → nach `document.fonts.ready` neu malen.
- **Marge zu klein** — `m ≥ halbe max. Strichbreite + jit`. Faustregel: `m = botW + 1.5` bzw. `baseW·1.5 + jit`.

---

## 10 · QA-Checkliste

- [ ] Reload → identische Kante (Seed-Stabilität)?
- [ ] Gegenüberliegende inked-Kanten optisch gleich dick?
- [ ] Gutter zwischen Panels konsistent?
- [ ] Keine abgeschnittene Tusche am Element-Rand?
- [ ] HiDPI (dpr 2): Linie scharf, nicht doppelt?
- [ ] Nach Rotation (3D): dieselbe Komposition, Naht dick?

---

## 11 · Next Steps / TODO

- [x] `kfb-ink.js` als geteiltes Modul in den Repo-Root (Single Source).
- [ ] Optional: exakter Screen-Space-Taper als Shader-Pass (falls Flucht > Perspektive gewünscht).
- [ ] 3D-Pet-Hull (§8) als POC an einem Cube-Pet gegen den v6-Hull testen.
- [ ] Corner-Weighting: Ecken minimal verstärken (Tusche staut an Richtungswechseln)?
- [ ] Farb-Token `#1f1a14` + Papier-Töne in ein KFB-Palette-Modul.

---

*Layer Zero gilt · kein Papier-Chrome · wonky bleibt.*

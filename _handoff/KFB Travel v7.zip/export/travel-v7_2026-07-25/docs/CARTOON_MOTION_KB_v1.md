# CARTOON_MOTION_KB — SUPERSEDED

Diese Datei ist abgelöst. Kanonische Quelle ist jetzt die **KFB Cartoon Motion Bible**:

→ `docs/CARTOON_MOTION_BIBLE.md` (Index + verbindliche Kurzfassung)
→ `docs/motion_bible/` (Langquellen: Prinzipien/Research, Library-Matrix, WebGL-Implementierung)

Nichts hier pflegen — alles in der Bible.

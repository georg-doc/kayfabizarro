# HANDOVER — Claude Coworker (v3, Full-Doku + Backlog)

Projekt: **Georg's Infinite Canvas**. Stand: 2026-07-24. Stack: **three.js 0.160, WebGL** (WebGLRenderer, GLSL ShaderMaterial), Design-Component (`.dc.html`).

---

## 1 Architektur
```
KFB Terrain + Skydome v3.dc.html   ── entrypoint (importmap three 0.160 via jsdelivr + <div#rc2-stage>)
  └─ terrain-v3/terrain-poc.js     ── runner: renderer, scene, camera, flight, UI-panel, makeHorizonBlur, dice overlay
       ├─ voxel-terrain.js         ── InstancedMesh chunks, seeded heightfield, GLSL colour ShaderMaterial
       ├─ skydome-shader.js        ── animated dome (S/A/space) + static equirect dome (watercolor/Kenney) + spiral + stars
       ├─ dice-sky.js              ── 6 colour-coded D6 (glowOf), GLB via RAW + procedural fallback, overlay scene
       ├─ world-context.js         ── cards → vector → seed → params + palette  (SHARED, 1:1 v2)
       └─ jukebox-audio.js         ── WebAudio → {beat, energy}  (SHARED, 1:1 v2)
       + palettes.json, decks/*.json, edge3.jpg
```

## 2 Datenfluss (unverändert seit v2)
Card-Triplet → `cardSemanticVector()` → `makeWorldContext()` → Seed + params + biome + palette → `voxel-terrain` bäckt Chunks (fbm + domain-warp + biome-shaping), Farb-Inputs in 2 vec4-Attribute; Farbe live im GLSL-Fragment aufgelöst.

## 3 Rendering-Pipeline (v3-spezifisch)
1. `horizonBlur.render(scene, camera)`: Szene → Offscreen-RT (mit DepthTexture) → Fullscreen-Quad mischt gaußweichen Wert per linearisierter Distanz ein. Maske = `smoothstep(start,end,dist) * (1-smoothstep(cutoff,cutoff*1.35,dist)) * amt` → **nur Terrain-Band weich, Dome (r=700) jenseits Cutoff scharf**.
2. Falls Dice an: `renderer.autoClear=false; clearDepth(); render(overlayScene)` → Dice scharf über dem Blur, mit eigenen Lichtern (MeshBasic/Terrain-Shader ignorieren sie).
3. In-Shader `exp2`-Fog (Terrain) dissolves in `sky.horizonColor()`.

## 4 Wichtige Notizen / Fallen
- **WebGL, kein WebGPU** — three 0.160. Kein TSL, kein NodeMaterial, kein PostProcessing-Node-Graph.
- **Vertex-Attribute** in 2 vec4 gepackt (`aPack1/aPack2`) — historisch WebGPU-8-Buffer-Limit, unter WebGL beibehalten (kompakt).
- **Loop-try/catch** überlebt einen Frame-Fehler (`window.__loopErr`).
- **Dice-Farbe:** MeshLambert, `color=glow` + `emissive=glow×0.5` (Farb-Boden, keine schwarzen Schattenseiten), `toneMapped=false`. glow = `glowOf(ink)` zusätzlich per HSL auf Neon gesättigt (l≈0.55). MeshBasic wäre flach → Lambert für Form. Kein Bloom (v3 ohne Post), daher kein additiver Aura-Halo (wirkte als Bubble).
- **Skydome Bild-Dome = RC-v11 exakt:** MeshBasic, SRGB, `SphereGeometry(700,60,40)`, `y+40`, `repeat.set(2,1)` Aquarell / `(1,1)` Kenney, `rotation.y=π/2` (Nähte seitlich).
- **Screenshot-Werkzeug** liest WebGL bei totem Loop schwarz zurück; per `readPixels` im selben JS-Task verifizieren, oder Live-Loop laufen lassen.

## 5 Backlog
### v3 offen (klein)
- Firefox: Space-**Sternfeld unsichtbar** (`gl_PointSize`/Points-Rendering, bekanntes RC-Problem). Vor Standalone-Export prüfen; ggf. Sterne als instanzierte Quads statt Points.
- Watercolor ×2-Naht inhärent (Halb-Panorama). Optional: Nähte exakt hinter Startblick rotieren, oder tileable Aquarell.
- „Bild-Helligkeit"-Slider sitzt UI-technisch unter „Würfel" — kosmetisch in eigene Skydome-Sektion verschieben.

### v3+ (groß)
- **Dice einzeln steuerbar** in der Engine (Array + Seats liegen offen: `__terrainPOC.diceSky.dice`).
- Echtes tiefenbasiertes DOF statt Vollbild-Blur; LOD/Fade-in beim Chunk-Streaming (Horizont weiter ohne Vernebelung).
- Rainbow-Palette an Beat koppeln; „Aus Karten" + Ausbreitung als Live-Story-Übergang.
- Voxel-Glyphen (v2-PoC) nach WebGL portieren + integrieren.

## 6 Pfad-Hygiene / Export
- `edge3.jpg` lokal (`import.meta.url`). Für Standalone-Bundle auf RAW-URL ziehen, sonst untexturiert. Diese Session auf Georgs Wunsch belassen.
- Dice-glb, Skydome-WebP/PNG, Musik: RAW-URL (`raw.githubusercontent.com/georg-doc/kayfabizarro`). Decks/palettes relativ. jukebox = RAW-first + lokaler Fallback (Muster).

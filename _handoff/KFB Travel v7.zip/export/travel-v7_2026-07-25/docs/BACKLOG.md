# BACKLOG — Georg's Infinite Canvas

Priorisierte Roadmap + **Umsetzungsplan und Fallback-Strategie pro Komponente**.
Quelle der Wahrheit für „was als Nächstes". Zwei Abschnitte: der **Rollercoaster-
Strang (B)** ist gerade aktiv (v3 eingefroren); der **Table-Strang (C)** darunter
ist der ältere Backlog, unverändert erhalten.

Stand: 2026-07-17, nach dem Rollercoaster-v3-Check-in (v3 ❄️ eingefroren, inkl. Voice-POC).

---

# STRANG B — Rollercoaster Ride

## v4-Sprint (nächster Bau) — die drei Briefs liegen im Projekt

Kopie von v3 als `Rollercoaster Ride v4.dc.html` + `rollercoaster-ride.v4.js`, dann:

### B-v4.1 · Pet-Auswahl-Ring (`uploads/BRIEF_pet_auswahl.md`)
Waagerechter Ring um den Spieler, Pets nach außen gedreht, Scrollen dreht den Ring
(`turn`, overshoot 0.2 — rastet nicht ein, schwingt über). Vorderes Pet im Fokus auf
KFB-Kartenrückseite als schwebendem Podest, Sprechblase (KFB-Tuschelinie aus `kfb-ink.js`
kopieren, keine zweite erfinden). Drei Zustände: Hover = `reactPos` (Pet reagiert, nicht
die UI), Fokus = `turn` + Podest hoch + Blase NACH der Bewegung, Select = `celebrate` →
`transition`. Danach Deck-Cover als erster Vorhang (langsame Onboarding-Durchfahrt).
- **Plan:** eigener Screen VOR der Fahrt (kein Track), Motion-Werte aus `pet-motion.v1.js`
  (nicht neu tunen), Idle-Clip aus dem GLB. Kein „Wähle dein Pet"-Text — der Ring erklärt sich.
- **Fallback (WebGPU fehlt):** derselbe Boot-Guard wie die Fahrt; wenn kein `navigator.gpu`,
  Auswahl als **2D-Fallback-Grid** aus den Pet-`color`+`name` (Contract) ohne 3D-Ring —
  Auswahl funktioniert, nur ohne Karussell-Feel. Siehe „WebGPU-Fallback" unten.

### B-v4.2 · ✅ FrizzleBob-Voice POC — GEBAUT (in v3, `frizzlebob-voice.v3.js`)
**Erledigt 2026-07-17 als MVP-Abschluss vor dem Check-in.** Browser-TTS, Englisch, kein LLM, **Nur Ebene 0 (Phrase-Pool, hart im Code) + Ebene 1
(`power`/`lore` aus dem Deck-JSON)**. Trigger aus dem Drive-Bus (Kurve/Drop/Karte/
Mode-Wechsel/Ankunft). Stille bei Stillstand ist erlaubt (Prime Directive).
- **Plan:** `SpeechSynthesisUtterance`, Pausen über `onend`+`setTimeout` (kein SSML!),
  Pool-Regel „nie zweimal dieselbe Zeile hintereinander". `rate`/`pitch` pro Utterance
  leicht variieren. Passierte Karten → Session-NDJSON (Format existiert, nicht erfinden).
- **Fallback (keine Stimme / Event fehlt):** erste `en`-Stimme nehmen, sonst **stumm
  weiterfahren** — der Ride hängt NIE an der Stimme. `getVoices()` erst leer → `onvoiceschanged`;
  Firefox/Safari kennen das Event teils nicht → Timeout-Fallback (nach 1 s einmal neu prüfen,
  dann aufgeben). NIE auf eine benannte Stimme bauen.

### B-v4.3 · Sechs Narrator-Kadenzen (`uploads/NARRATOR_PACK_2_aus_der_NIE.md`)
Ein Wurf bringt seinen Erzähler mit: Mode → Pet → Tradition → rate/pitch → Kadenz.
Prompts liegen lokal in `data/narrator/`. **Der einzige plattformfeste Hebel ist der
Rhythmus des Textes** (rate/pitch sind nur Feinschliff). Ma-Regel: vor dem Höhepunkt
aufhören, nicht auflösen.
- **Plan:** die 6 Kadenz-Tabellen (rate/pitch aus dem Pack) als Datentabelle oben in der
  Engine, analog zu `AUDIO_MOODS`/`MOOD_SKY`. Ebene 2 (LLM-Closure) ist Kür, nicht POC.

### B-v4.4 · Bremse, Vollhalt, Rückwärts (`uploads/HANDOVER_cards_und_bremse.md` §4)
Fahrer-Kontrolle über die Fahrt. Bewegungen existieren in `motion-LIBRARY.json` v1.2.0
(nicht neu tunen): Bremsen = `reactNeg` (dur 0.58, squash 0.46, **sink 0.12** = sichtbares
Einsacken), Stand = `loading`, Anfahren = `transition` (anticip 0.3).
- **Plan (Physik, kein UI-Flag):** Der Bremsknopf **setzt `a` negativ** auf dem Drive-Bus —
  alle vier Abnehmer folgen von selbst (Pet sackt via `reactNeg`, Vorhang erschlafft, Himmel
  wird ruhig, Würfel driften statt zu drehen, FrizzleBob schweigt). *Der Lackmustest:* wenn
  der Knopf nur die Kamera anhält und das Pet weiterhüpft, wurde ein Flag statt einer Kraft
  gesetzt.
- **Rückwärts bricht genau eine Regel richtig:** die Karte kommt zurück, **die Stimme nicht**
  (nie eine Zeile aus den letzten 2 min wiederholen). Der zweite Blick gehört dem Leser —
  das ist Ma, kein Verzicht. Rückwärts: langsam, `loading` statt `locomotion`, still.
- **Offen (Georgs Entscheidung, nicht technisch):** zählt eine zweimal gelesene Karte als ein
  Ereignis oder zwei (Session-NDJSON)? Und: der Seiten-Cache hält 6 Seiten (`kfb-table.v6.js:1133`)
  — weit genug zurück = Neu-Render-Ruckler (1500 px/Seite). Fällt evtl. nie auf.

### B-v4.5 · Konsole = eine Hand voll Karten + ein Hebel (`uploads/BRIEF_konsole_kartenhand.md`)
**⚠ Der Kontroll-Würfel ist zurückgezogen** (Begründung im Brief: der Würfel ist ein Ereignis,
die Hand ein Zustand — und sechs Würfel hängen schon als Story-Modes im Himmel). Ersetzt den
früheren „3D-Schalter-Panel"-Vorschlag. Stattdessen: **drei Steuerkarten, gesteckt wie eine
Pokerhand unten rechts** (nur Laschen schauen heraus, Drüberfahren klappt eine auf) + **ein
senkrechter Holz-Hebel rechts außen** (Gas oben / Halt Mitte / Rückwärts unten).
- **Die drei Karten:** *Pet* (Auswahl aus den 12 + Abstands-Regler, siehe B-v4.6), *Deck*
  (aus `index.json`), *Umgebung* (Skydome / Licht / Ton).
- **Kartenformat aus dem PDF lesen, nicht hart codieren:** `cardAspect` aus der gerenderten
  Seite (`kfb-table.v6.js:1174`), `0.72` ist NUR Fallback — sonst bricht ein Deck mit anderem
  Format. Kontur = bestehende KFB-Tuschelinie (`inkChip2D`/`inkRibbon2D`), **keine zweite
  erfinden** (dünn oben-links, dick unten-rechts).
- **Gefahr (gelöst):** Steuerkarten haben dasselbe Seitenverhältnis wie Spielkarten →
  **Laschen durchscheinend/transparent**, damit niemand seine Einstellungen „ausspielt".
- **Der Hebel ist das einzige 3D-Objekt zwischen flachen Karten** (Materialunterschied =
  Funktionsunterschied). Holz mit Tuschekontur, **keine Verläufe, kein Glanzlicht** (der Fehler
  am `wooden-gold-buttons`-Kit). Setzt `a` auf dem Drive-Bus (nicht ein Flag) → speist direkt
  B-v4.4 (ein Wert, fünf Reaktionen).
- **Offen (Bildfragen):** wie die Karten sich öffnen (aufklappen/hochschieben/vorziehen);
  ob der Hebel rechts-außen oder rechts-unten sitzt (kollidiert evtl. mit Pet auf Regler-0).

### B-v4.6 · Mienenspiel + Abstands-Regler (`uploads/SPRINT_mienenspiel.md`)
Das Mienenspiel bleibt (nur der Kontroll-Würfel als Träger ist weg — es lebt jetzt auf der
Pet-Karte der Konsole).
- **Abstands-Regler (auf der Pet-Karte):** `0` = Pet unten links, blickt den Spieler an
  (kayfabuliert, Augen lesbar); `>0` = stufenlos hinaus auf die Strecke. Die Achse zwischen
  **Begleiter und Vehikel**, vom Spieler gestellt. Beantwortet „zurückkehren oder liegen
  bleiben?": keins von beidem, ein Regler. Mimik ist nur bei ~0 überhaupt lesbar.
- **Mienenspiel = Werte, keine Clips:** sechs Emotes aus dem Contract (neutral/happy/angry/
  sad/surprised/thinking) mit `lidUpper`/`lidLower`/`slant`/`gaze` + `blink`. **Nicht auswählen,
  sondern dazwischen wandern und zittern** — der Zielpunkt im (lidUpper,lidLower,slant)-Raum
  springt nie, wandert, mit feinem Dauer-Zittern. Sonst liest es sich nach einer Minute als
  „sechs Gesichter" (Bildschirmschoner).
- **Reagieren, nicht zyklen:** Auslöser aus dem Drive-Bus — Drop/`j` → surprised (hart+sofort),
  Kurve/`c` → Blick nach außen, Bremse/`a`neg → Richtung sad + `reactNeg`, lange geradeaus →
  thinking/`gaze:away`, Karte → kurz `front`, Stillstand → neutral + driften. **Erst wenn nichts
  passiert, klein würfeln** (Drift neutral↔thinking mit Zittern).
- **Zwei Kanäle:** Körper reagiert auf Physik (`reactPos/reactNeg` — laut), Gesicht auf alles
  andere (Augen/Lider — leise). Nicht koppeln, sonst wird's Zappeln. Augen reagieren schneller
  als der Körper (Abnahme-Punkt 4).
- **Baut auf:** Eye-Rig ist da (`pet-eye-rig.v3.js`, converge+Follow-Gaze in v3 gefixt); fehlt
  der Emote-Wander-Layer + Anbindung an den Drive-Bus (`rig.applyEmote`).

### B-v4.7 · Der Ride läuft im Takt — Schlagzeug statt Soundteppich (`uploads/BRIEF_takt_und_trommeln.md`)
Vorbild *Sound of Noise*: der Wagen **spielt mit**, statt sich zur Musik zu synchronisieren.
- **Die eine Regel:** Tempo ändert nicht die Uhr. Schneller-Fahren macht den Takt **voller
  (mehr Dichte: Viertel → Achtel → Sechzehntel + Fill/Becken)**, nicht schneller. BPM darf
  langsam wandern (~90–115), die Dichte macht die Arbeit. *Wird es schneller = Sirene (falsch);
  wird es voller = Trommler (richtig).*
- **Timing = Lookahead-Scheduler** (Chris Wilson, *A Tale of Two Clocks*): `setInterval` ~25 ms
  plant alles Fällige der nächsten ~100 ms fest auf die **Audio-Uhr** (eigener Thread). NIE
  `setTimeout` für Noten (driftet beim Rendern). Bei 100 BPM großzügig genug.
- **Der Wagen spielt mit:** Drop = Beckenschlag, Kurve = Tom (links/rechts im Bild), Bremse =
  Abstopper — alles aus `j`/`c`/`a`, die es schon gibt. **Kein Loop** (erzeugen, nicht abspielen),
  **kein Ducking der Stimme** (die Trommel spielt *weniger*, wird nicht leiser gedreht), **keine
  Musik im Stillstand**, **kein Takt vor der ersten Fahrt**.
- **Bindet alles zusammen:** eine Seite = ein Takt (4 Karten = 4 Schläge, 14 Seiten = 14 Takte;
  Kishōtenketsu-Wendung auf Schlag 3). Der spätere LLM-Call (Ebene 2) bekommt **Takte statt
  Sekunden**: Antwort kommt, FrizzleBob spricht **auf der nächsten Eins** → Latenz wird
  musikalisch statt versteckt. *Zum Ausprobieren, nicht Anweisung:* Betonung/Ghost-Note auf
  Schlag 3.
- **Reihenfolge:** baut auf B-v4.2 (Voice läuft, ✅) auf; Ebene 2 (LLM) kommt sinnvoll NACH dem Takt.

## P1 — Breitentauglichkeit / Robustheit

1. **⚠ WebGPU-Fallback (Firefox / Safari).** Der Coaster ist WebGPU-only; Firefox liefert
   `navigator.gpu` nur hinter `dom.webgpu.enabled`, Safari erst ab sehr neuen Versionen.
   Aktuell nur ein Klartext-Guard. **Optionen, in Reihenfolge des Aufwands:**
   - **a) Ehrlicher Guard (ist gebaut):** „needs WebGPU, open in Chrome/Edge" — kein Absturz.
   - **b) WebGL2-Renderer-Pfad:** three r178 hat `WebGPURenderer` mit WebGL2-Backend-Fallback
     (`forceWebGL:true`), aber TSL-Node-Materialien (Streams, Shader-Dome) müssen dann als
     WebGL-taugliche Varianten vorliegen. Realistisch: Streams + Dome auf einfachere Shader
     downgraden, Rest (Track, Pet, Karten, Sound) läuft. Mittlerer Aufwand.
   - **c) Reduzierter 2D/CSS-Fallback** für die Pet-Auswahl (siehe B-v4.1), damit wenigstens
     der Einstieg überall geht.
   - **Empfehlung:** (a) bleibt Standard, (b) als eigener v4-Feature-Zweig prüfen, wenn
     Firefox-Reichweite gebraucht wird. Nicht nebenbei — TSL→WebGL ist eigener Testaufwand.
2. **Audio-Autoplay-Policy:** WebAudio startet erst nach User-Geste (ist über den Enter-Klick
   abgedeckt). Fallback: wenn `AudioContext` `suspended` bleibt, Ride läuft stumm weiter,
   ein dezenter „tap for sound"-Hinweis. NIE blockieren.
3. **GLB/Contract-Ladefehler:** Pet/Würfel kommen per GitHub-raw. Bei Fetch-Fehler
   (`catch` existiert) fährt der Ride ohne Pet/Würfel weiter statt zu crashen — beibehalten,
   und einen sichtbaren Mini-Hinweis ergänzen (aktuell nur `console.warn`).
4. **Reduced-Motion:** `prefers-reduced-motion` respektieren — Squash/Fling/FOV-Puls dämpfen,
   Shader-Dome-Flow drosseln. Noch offen.

## P2 — Politur

5. **Pet-Look:** Augen-Fix ist drin (converge + Follow-Gaze). Offen: Emote-Reaktionen an
   Ride-Events (Schreck bei Drop, Freude an Karte) über `rig.applyEmote` aus dem Drive-Bus.
6. **Karten-Lesbarkeit im Flug:** Karten drehen sich zum Rider; bei Tempo prüfen, ob `power`
   lesbar bleibt oder erst bei Annäherung eingeblendet werden soll.
7. **Standalone-Offline:** aktuell braucht das Bündel noch Netz für three.js (CDN) + GitHub-
   Assets. Voll-offline = three.webgpu lokal bündeln (groß) + Assets einbetten — nur wenn nötig.

---

# STRANG C — KFB Table (älterer Backlog, unverändert)

## P1 — Gameplay-Vertiefung
1. **Deck-Switch / Multi-Deck-Pile:** FB-Menü „Select Decks" funktional machen — Decks A/B/C
   (GitHub raw: JSON + PDF) laden, Draw-Pile aus 1–n Decks mischen, Texture-Pipeline pro Deck
   (COVER_OFFSET beachten). UI existiert (Stub).
2. **Voller State-Loop-Feinschliff:** Verdict-Gewichtung, Turn-Ende-Choreo, King-Rotation sichtbar.
3. **Kanonische Mode-Farben:** ✅ eingepflegt (S.16-Hex, jetzt auch in Rollercoaster `MODES`).

## P2 — Präsenz & Politur
4. **Outline-System Phase 3:** Screen-Space-Outlines (Post-Processing) mit variabler Strichbreite.
5. **FrizzleBob-Ausbau:** Augen-Glanzlicht + Shirt via Textur/UV; Idle-Pose (kein Fidget); Voice-Guide.
6. **Kartenrückseite:** echtes Artwork statt Platzhalter (§11.3).
7. **Griffe der Scheren färben:** Mesh-Split oder Textur prüfen.
8. **Sound:** Papier-Rascheln, Würfel-Klackern, Mode-Wash — Ritual-gebunden, nie ambient-fidget.

## P3 — Infrastruktur
9. **YouTube auf Flächen:** iframe geht nicht in WebGL — CSS3D-Overlay für `setSurface` mit youtube:-URLs.
10. **Deck-JSONs mit `page`+`quadrant` pro Karte** (Engine-Lane) — ersetzt die rechnerische Ableitung.
11. **Persistenz:** Spielstand (Pile, Slots, Quest-Pos, Mode) in localStorage.
12. **Treppen-GLB (pixellabs):** verworfen für die Rampe; ggf. Deko-Prop mit eigenem Orientierungs-Pass.

## Bewusste Nicht-Ziele (Prime Directive)
- Keine Fidget-Animationen, kein Idle-Bobbing — jede Bewegung ist ein Ritual/Interpunktion.
- Blase = Cue, kein Skript. Keine automatischen Erzähltexte über den Cue hinaus.
- Der Ride darf NIE an Stimme, Sound, GLB-Fetch oder LLM-Call hängen — alles degradiert weich.


## Meta-Narrativ (WICHTIG für Coworker — groß im Handover!)
**Human = Pet-Avatar-Ebene:** Alle Cards sind FrizzleBobs **Time-Capsule-Artefakte**, die er wie
Akashic Records im fraktalen Raum sammelt. Das Pet ist der Avatar des Spielers — es erlebt die
Artefakte stellvertretend und liefert **Closure & Storytelling** ("storytelling animals").
Konsequenz im Code: Cards/Cover haben KEINE Rückseite und werden **nie falsch herum** angezeigt
(Billboard immer zum Rider; Snap statt Slerp wenn >90° off — Curtain.render()).

## Geisterbahn-Modus (Backlog)
Nur die KFB/MED-**Rückseiten** sichtbar; **Reveal erst bei Passage** — rechtzeitig genug, um Karte
+ Storytelling-Kontext trotz rasanter Fahrt lesen/mitnehmen zu können (Reveal-Distanz an Speed
koppeln, z.B. Flip bei d < 35 m skaliert mit speed01).

## „I feel fluffy" Deck-Die (Backlog, Todo 39)
Kleiner 3D-Default-Die neben dem Deck-Selector: 1–6 Augen = Deck-Select per Drehen; Klick auf
Zufall = Spin/Roll-Animation → Result → Pet: „Let's roll!".


---

## v4-Freeze 2026-07-17 — offene Punkte mit Plan/Fallbacks

| # | Punkt | Plan | Fallback/Risiko |
|---|---|---|---|
| H | **Die Hand** (v5-Kern) | Karten-Einsammeln, untere Reihe Pad·Hand·Tacho, Overlay ohne Pause | Übelkeits-Test (2 min + Magen); Hand ggf. nur beim Sammeln aufklappen |
| 50 | Beat-Meter | an audio.bpm/beat0 (steht) — 1 Takt = 2.3077 s | — |
| 49 | Tacho-Eichung | Nadel zittert am roten Rand; Pad spiegelt Kinetik | — |
| 48 | Explore-Mode | Kamera vom Rig lösen (kontrolliert!), WASD+Booster | Kamera-Reparent-Falle (Handover) |
| 45 | Outline-Hull Pet | inverted hull aus kfb-table.v6 portieren | Vertex-Buffer-Limit beachten |
| 46 | 3D-Fluffy-Die | Roll-Anim Spin→Result | aktuell „?"-Chip ok |
| 41 | Pet-Ride-Slider | Track-Abstand stufenlos / Cockpit-Snap | — |
| 40 | Geisterbahn | nur Rücksseiten, Reveal bei Passage | — |
| FF | **Firefox** | WebGPU fehlt → Renderer-Fallback (three.webgpu.js fällt auf WebGL2 zurück); Partikel-Dichte/Bloom drosseln, MultiplyBlending prüfen | ggf. eigener „lite"-Pfad; Chrome bleibt Referenz |
| TTS | Voice matscht unterm Track | Zweit-Generat „drums and bass only" | Duck steht schon |

# HANDOVER — KFB Travel, Stand v5 → Start v6

Für einen frischen Chat. Lies diese Datei, dann `docs/SPRINT_travel-v5.md` (die Slice-Tabelle steht
oben) und die letzten drei Einträge in `docs/CHANGELOG_travel.md`. Mehr brauchst du nicht.

## Was v5 ist

Ein fliegendes Karten-Fahrzeug mit einem Cube-Pet obendrauf, über einem Voxel-Terrain unter einem
Shader-Himmel. Zwei Reise-Modi: **Fly** (Karte trägt das Pet) und **Walk** (Pet läuft, Karte folgt).

Entry: `KFB Travel v5.dc.html` → lädt `terrain-v5/travel-poc.js`.

## Module (`terrain-v5/`, 13 Dateien)

| Datei | Rolle |
|---|---|
| `travel-poc.js` | Runner: Szene, Kamera, Input, Frame-Schleife, verdrahtet alles andere |
| `travel-heat.js` | **Regie-Skalar** `travelHeat` 0..1 + geeichte km/h. Jeder Effekt hängt hier dran, nicht an eigenen Schwellwerten |
| `flight-controller.js` | Flug: Höhe, Tempo, Bank, Boost |
| `walk-controller.js` | Boden: Laufen, Drehen, vorausschauender Auto-Hop, Kamera bis POV |
| `pet-kinetics.js` | Sprung-Grammatik (Anticipation → Launch → Apex → Fall → Squash → Rebound), volumenerhaltendes Squash, GLB-Clips idle/walk/run |
| `card-carrier.js` | die Karte als Fahrzeug (Rig, Sitz, Fuß-Clip) |
| `voxel-terrain.js` | Chunk-Terrain, Kanten-Shader, exportiert `edgeTex` |
| `skydome-shader.js` | zehn Himmel-Varianten, Welt-Mischung, Belichtung, Spirale |
| `world-context.js` | Story-Mode → Palette + Terrain-Parameter (Seed-getrieben) |
| `hud-cube.js` | **HUD-Würfel** unten rechts: Ruhe = Tacho, angefasst = Menü |
| `settings-overlay.js` | Einstellungs-Overlay, acht Cluster, Sektionen kommen als Daten vom Runner |
| `kfb-pets.js` | Pet-Vertrag (Fallback; kanonisch liegt er im Repo) |
| `edge3.jpg` | Kanten-Textur, lokal bis sie im Repo liegt |

## Die fünf Regeln, die in v5 teuer gelernt wurden
1. **Ein Regie-Skalar.** Effekte lesen `heat.value` / `heat.rate`, nie eigene Tempo-Schwellwerte.
   Sonst driften sie auseinander, sobald sich das Höchsttempo ändert.
2. **Textur-Schrift ist keine DOM-Schrift.** Vor dem Malen ausrechnen, wie viele Bildschirm-Pixel
   eine Textur-Einheit hat. Der Würfel ist ~107 px breit; `0.08·S` ergab 7 px Schlieren.
3. **Texturen sitzen auf der Geometrie, nicht auf Platten davor.** `RoundedBoxGeometry` erbt die
   sechs Material-Gruppen von `BoxGeometry`. Preis: die UV schließt die Rundkante ein →
   12 % Sicherheitszone (`hud.safeZone`), gilt auch für Georgs PNGs.
4. **Wer Werte beim Bauen liest, muss vor dem Bauen deklariert sein.** Das Overlay liest beim
   Aufbau jeden Regler-Wert; eine später deklarierte Variable reißt den ganzen Boot (TDZ).
5. **Farbe an EINE Stelle.** Akzent läuft über `--kfb-accent` am Overlay-Root. Inline eingebackene
   Farben ziehen bei einem Palette-Wechsel nicht mit.
6. **Der Canvas muss ein Template-Re-Render überleben.** Der DC-Runtime ersetzt `#tv-stage`; unsere
   Knoten hängen danach an einem Waisen-Knoten (`parentElement` stimmt, `document.contains` nicht)
   → leerer blauer Screen. `travel-poc.js` hat dafür eine Re-Attach-Wache. Wer neue eigene
   DOM-Knoten anlegt, muss sie in `owned()` eintragen.
7. **Post-Pass vor dem Würfel.** Sobald S2 einen Fullscreen-Pass einführt: erst Szene, dann Post,
   dann `hud.render()` — sonst wird der Tacho mitgeweichzeichnet.

## Test-Hooks

`window.__travelPOC` → `renderer` `scene` `camera` `flight` `walk` `rig` `petKin` `terrain` `sky`
`heat` `hud` `settings` `wc` `story` `mode` `pet`, dazu `setMode('walk'|'fly')`.
`window.__pet` ist das aktive Pet. Der Würfel: `hud.spinTo('music')` · `hud.home()` · `hud.spin(3)` ·
`hud.setFaceImage(id, url)` · `hud.sizePx` / `hud.growth` (Ruhe 131 px, angefasst 196 px).
Das Overlay: `settings.open('welt')` · `settings.close()`.

## Steuerung

`W`/`S` Schub bzw. laufen · `A`/`D` lenken/drehen · `Q`/`E` seitwärts (Boden) · `↑`/`↓` steigen/sinken
· `Shift` rennen · `Leertaste` Boost (Luft) / Sprung (Boden) · `J` Pet hüpft · `F` Fly ⇄ Walk ·
`Tab` Einstellungen · Ziehen lenken/umsehen · Rad Zoom bis POV. Vollständig im Overlay, Sektion
„Steuerung".

## Was als Nächstes ansteht (v6)

Reihenfolge wie mit Georg abgestimmt:

1. **S2 · Speedlines + Boost-Regie** — der Boost wird ein Ereignis: Speedlines, Barrel-Roll mit
   Kamera, FX. Aus dem TinySkies-Report, §04 A. Hängt an `travelHeat` (steht).
2. **S10 · Modus ohne Schalter** — Doppel-Leertaste abheben, `X` sinken, Bodenkontakt → Walk.
   Muss **vor** S11 kommen.
3. **S11 · Rahmen** — Wortmarke links (`themes/kfb-med.css` → `.kfb-wordmark`), Meta klein rechts,
   Modus-Anzeige weg.
4. **S12 · Würfel v2** — ein Drittel kleiner (**Teil 1 steht**: wächst beim Anfassen, kompakter Tacho
   im Ruhezustand), noch offen: Special Elite ohne ALLCAPS, Abnutzungs-Decal, Grundfläche in der
   aufgehellten Pet-Base-Color (`resolvePet(lib,id).color`).

Danach S3 (Rim-Light), S4 (Staub/Splitter), S5 (Story-Presets), S6 (Portal-Swirl), S9 (Monitor-Würfel).
Details je Slice im Sprintplan.

## Warten auf Georg

- **PNG-Set für die Würfelseiten** (Procreate, transparent, quadratisch, 12 % Sicherheitszone) →
  `media/kfb/hud/`. Erst damit trägt der kleinere Würfel (S12).
- **`edge3.jpg` ins Repo** (`media/3D_Assets/Textures/`) → dann kann die lokale Kopie raus.
- **Bundle-Matrix** (greet/notice/celebrate/sleep an Travel-Events) mit dem Coworker abstimmen.

## Arbeitsweise in diesem Projekt

Ein Slice pro Runde, danach `docs/CHANGELOG_travel.md` und den Sprintplan nachziehen — additiv, alte
Einträge bleiben stehen. Zahlen messen statt schätzen (`eval_js` gegen die laufende Szene), und was
schiefging in den Changelog schreiben, nicht nur was klappte.

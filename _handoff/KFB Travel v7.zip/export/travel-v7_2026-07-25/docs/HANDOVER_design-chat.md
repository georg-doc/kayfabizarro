# HANDOVER — Frischer Design-Chat (v3)

Projekt: **Georg's Infinite Canvas**. Aktuelles Stück: **`KFB Terrain + Skydome v3.dc.html`**.

## Was ist das
Endloser, prozeduraler Voxel-Flug (Cubes, keine Meshes) mit Skydome, musik-/beat-reaktiv. Aus Karten-Triplets → semantischer Vektor → Seed → Landschaft. **v3 läuft auf reinem WebGL (three 0.160)** — dieselbe Engine wie das Pet, ein Build, kein WebGPU. Rendert direkt in der Vorschau (kein spezieller Browser nötig).

## v3 gegenüber v2 (WebGPU) — was sich änderte
- **Engine:** WebGL `WebGLRenderer`, GLSL-`ShaderMaterial` statt TSL/NodeMaterial. Kein EffectComposer.
- **Farbmodell erhalten:** 3-Stop-Ramp × Palette × Helligkeits-Range × Sättigung + Wasser + Regenbogen + radiale Ausbreitung — jetzt in GLSL, über instancierte vec4-Attribute + Uniforms.
- **Wasser = Farbzone**, kein Pegel: Terrain-Höhe wird nicht mehr geclamped; tiefe Zellen nur getönt.
- **Skydome (Dropdown, 10):** Nebel (Sphere-Shader), Waber (gefaltet), Space (Gradient+Sterne) — alle animiert; Watercolor A/B + 5 Kenney (Starfield/Night/Morning/Day/Alien) als Bild-Domes, **1:1 RC-v11-Rezeptur** (MeshBasic, SRGB, SphereGeometry(700,60,40), repeat×2 Aquarell / ×1 Kenney).
- **Horizont-Weichzeichner:** Depth-Blur im Post (Offscreen-RT + Tiefe), **mit Cutoff** → nur Terrain-Band weich, Himmel scharf.
- **Dice:** 6 farb-codierte D6 (`glowOf(MODES[i].ink)`), Lambert + Key/Fülllicht (Form), Emissive-Boden (satte Farbe), eigene Overlay-Szene nach dem Blur (scharf). Leader = aktueller Modus loomt. Toggle + Größen-Slider.
- **Fractal-Raymarch B/L gestrichen** (WebGL-Kern).

## Panel-Landkarte
Palette · Farbe·Look · Card-Triplet→Seed · Terrain-Seed-Variante · Flight · Terrain-Params · Skydome (Dropdown + Kosmisch↔Landschaft, Belichtung, Auto-waver, Spirale) · Würfel (on/off, Größe) · Bild-Helligkeit · Horizont·Weichzeichner (Stärke/Beginn/Voll ab/Radius) · Music · Render-Scale.

## Ästhetik-Leitplanken
Fonts **Irish Grover** (Titel) + **Special Elite** (UI). Akzent-Gold `#e9c34a`. Cartoony, max 1–2 BG-Farben. Cubes bewusst „vergebend". Keine SVG-Bildchen, kein Emoji, keine Gradient-Slop-BGs.

## Weiterbauen
v1/v2 nicht anfassen (FROZEN/SUPERSEDED). Neue große Richtung = v4 als Kopie von v3. Details + Backlog: `docs/HANDOVER_claude-coworker.md`, Status je Datei: `docs/HOUSEKEEPING.md`.

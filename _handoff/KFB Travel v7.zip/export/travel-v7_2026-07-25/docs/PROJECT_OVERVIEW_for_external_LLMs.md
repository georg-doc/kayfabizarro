# KayfaBizarro — Projekt-Landkarte für externe LLMs

**Zweck dieses Dokuments.** Ein fremdes Sprachmodell (oder ein frischer Chat) soll nach dem Lesen verstehen, *was* dieses Projekt ist, *wie* es aufgebaut ist, *welche Regeln* unverhandelbar sind und *wo* man für Details weiterliest — ohne den alten Chat-Verlauf zu kennen. Es ist eine **Landkarte, kein Sprint-Brief**. Stand: 2026-07-15.

Sprache: Deutsch (das gesamte Korpus ist deutsch). Alle Datei-Pfade sind relativ zum Projekt-Root.

---

## 1 · Das Projekt in einem Absatz

**KayfaBizarro (KFB)** ist ein „Cut & Play" Story-Wrestling-Comic-Kartenspiel für 1–6 Spieler. Motto: *„Not a game you play. A game you use."* Es gibt viele **Decks**, jedes als druckfertige PDF plus eine Analyse-**JSON** (Karten mit `cardNumber`/`cardName`/`power`/`lore`/`grade`). Diese JSONs sind die **eine Wahrheitsquelle (SSOT)**, aus der jede Oberfläche liest. Rund um dieses Spiel entsteht in diesem Claude-Design-Projekt eine Reihe **immersiver 3D-Oberflächen** (Reader, Tisch-Diorama, begehbares „Sinnfeld", Card-Viewer) und langfristig eine **Transmedia-Plattform**, die Decks, Touren, Songs, Videos und Lernpfade über ein portables Manifest verknüpft.

---

## 2 · Die tragende Architektur (die Invariante)

Vier Sätze, die alles zusammenhalten. Wer gegen sie baut, forkt das Projekt.

1. **EINE Engine, EIN Korpus, geteilte Nähte.** Es gibt mehrere Oberflächen (QA-Blindtest, Solo-Simulator, Gameplay-Stage, immersive Viewer), aber alle **konsumieren** denselben SSOT, dieselben Regeln, denselben Stilboden. **Nicht forken.** Braucht eine Oberfläche etwas am Korpus/an Grades/Personas/Engine, geht das zurück in die Cowork-Lane, nicht als zweite Kopie.
2. **PDF = das Bild, JSON + Skript = die Worte und das Spiel.** Keine Bild-Pipeline: das Deck-PDF wird per **pdf.js** on-demand gerendert und in Quadranten (2×2-Grid) geschnitten. Karten-Mapping: `page = coverOffset + 1 + floor((cardNumber-1)/4)`, `quadrant = (cardNumber-1) % 4`.
3. **Alles, was eine Oberfläche konsumiert, ist portable JSON** — Deck-JSON, Paket-Manifest, Tour-Skript, Spielverlauf (NDJSON-Log). Hält man diese Disziplin, fallen Import/Export, Replay, Verzweigung, Kuratierung und Cross-Domain fast gratis heraus. Das ist die Invariante, an der die ganze Plattform-Vision hängt.
4. **Alles Sichtbare ist parametrisch.** `skin` (KFB / MedKayfab / FrizzleCrits) und `content_type` (deck-tour / learning-path / virtual-patient) sind Schalter, keine Neubauten. Story-Modes, Themes und Paletten liegen als Datenobjekte, nichts ist hardcoded.

### Die Nähte (Integrations-Verträge)
- **Tisch/State lesen:** `window.KFBStageContext` (updatet bei jedem Zug).
- **Avatar steuern:** `window.fb.*` — `performLine` / `setExpression` / `setCostume` / `setPole` / `trigger` (der lange Zeige-Arm = die *finger-rule*).
- **Würfel/Karten:** `window.KFBDie.roll()` → Mode-Index, `window.KFBDeal.draw()`.
- **Story erzeugen:** `kfb_beat_engine.js` → Beats mit `focus` (welche Karte); der Live-Erzähl-Call läuft über `window.claude.complete` (claude.ai, nicht über eingebetteten Schlüssel).
- **Contracts** liegen als `deep_specs`: `06` = LLM-Call-I/O, `07` = NDJSON-Session-Log, `08` = TurnState-Event-Bus, `09` = kanonische Mode-Farben, `10` = Screen-Space-/Hybrid-Outlines.

---

## 3 · Kanon & Regeln (unverhandelbar)

### Layer Zero — der Anti-Slop-Stilboden
Gilt für **jeden** Text, den eine App erzeugt (Erzählung, Beats, Verdicts, Ladesprüche) *und* für die Prompt-Instruktionen selbst. Voll: `uploads/01_LAYER_ZERO_canon.md`.
- **Keine Gedankenstriche** (kein `—`, `–`, ` - `, `--`) — Komma/Punkt oder Satz umbauen. (Häufigster Verstoß in QA-Läufen.)
- Keine Emojis (außer explizit gewünscht), keine sycophantischen Öffner / generischen AI-Closer, kein Corporate-Sprech, kein Moral-Fazit.
- Keine Appliance-/Glitch-/AI-Meta-Gags („buffering", „404", „as an AI"). Kein Objekt-Anthropomorphismus-Slop — **Ausnahme:** Karte-als-Kreatur ist im KFB-Frame erlaubt.
- **Rent-Rule:** jeder Satz trägt Mechanismus **oder** Kosten **oder** ein konkretes Bild **oder** Rhythmus. Sonst streichen.
- „Discard the first three gags." · „players/readers", nie „the audience/users" · Kausalität über *therefore/but*, nicht über Dashes · echte Umlaute (ä/ö/ü) im Prompt.

### Spielregeln (Stand v3, kanonisch)
- Karten-Ritual = **Show it · Spin it · Sell it** (NICHT der alte „Name it · Claim it · Power it"-Stand).
- Zug = 5 Beats: **Roll → Play → Tell → Draw (am Ende) → Verdict.**
- **finger-rule ist Kernregel:** beim Erzählen auf jede Karte zeigen, während man sie einwebt. Genau das automatisiert jede Oberfläche (Karte hervorheben + Avatar-Zeige-Arm).
- **6 Story-Modes** (feste Palette aus Rules S.16, D6-Pip-Faces): 1 Tragic, 2 Comic, 3 Absurd, 4 Heroic, 5 Mystical, 6 Forbidden. FrizzleBob-Solo rotiert diese sechs Stimmen (bedside / mensch / rapgod / carny / fixer / analyst) — **nicht** Snark (Snark ist King-intern, gehört nur auf die Urteilsstimme).
- **Quest-Würfel** 1→6 (Setup→Finale); nur der King bewegt ihn (+2/+1/0/−1).

### IP-Grenzen (wichtig fürs Hosting)
Nie die **druckfertigen** PDFs öffentlich hosten oder einbetten (das ist das Gumroad-Produkt). Öffentlich nur **web-aufgelöste** PDFs + schlanke JSON, pro Zielgruppe ein kostenloser Sampler. HQ-Druck hinter Gumroad. Keine DRM jagen.

---

## 4 · Die Arbeitsstränge (Workstreams) und ihr Stand

Das Projekt ist über mehrere parallele Bau-Linien gewachsen. Alle teilen SSOT + Regeln + Nähte.

### A · KFB Table (Tisch-Diorama) — der reifste 3D-Strang
Ein 3D-Story-Tisch: PDF→Textur-Pipeline, Turn-State-Machine (REST → ROLL → PLAY → TELL → CALLS → MOVE), Studio-Wand mit Fenster/Galerie/PDF-Viewern, GLB-Requisiten (Tisch, Scheren, Tuschefass, FrizzleBob), Quest-Treppe, Sprechblasen-System, Themes paper/dark, zwei Looks (`papier` / `cel`).
- Versionen v1 → v6, eingefroren pro Version. **v6 ist der aktuelle Stand** (`v6/KFB Table v6.dc.html` + `v6/kfb-table.v6.js`).
- **Das große ungelöste Thema war die Cel-Outline** („unten dicker" als Vertex-Offset nicht sauber erreichbar). Gelöst in v6 über einen **Comic-Ink-Hull** (Lichtseite dünn, Schattenseite dick) plus **Hybrid-Ansatz**: Inverted-Hull-Silhouetten pro Objektklasse; Screen-Space-Sobel verworfen (Kontaktkanten blieben leer). Contact-Shadow-Blobs freigegeben als harte posterisierte Ink-Blobs (kein Blur).
- Changelog: `docs/CHANGELOG.md`. Backlog: `docs/BACKLOG.md`. Onboarding v6: `v6/docs/START_HERE_v6.md`.

### B · Time Capsule Ride — immersiver Almanac-Viewer
Ein **zustandsbehafteter PDF-Viewer**: Seite/Quadrant/Zoomstufe sind die States, Rotationen/Fahrt/Portale sind animierte Wechsel. Kernobjekt ist die **Kapsel** (Quader, 4 Längsseiten = Actor + 3 Szenen, 2 Deckel = Story-Mode + Quest-Die). Die **Fahrt** ist eine Catmull-Rom-Spline (Iris → Accel → Hyperraum → Decel → Docking).
- Versionen v1 → v8; **v5 war lange der Referenzstand** (lesbare Collage + Aufzug-Navigation), v6–v8 danach.
- Onboarding: `docs/ONBOARDING_fresh_claude.md`. Konzept v7 („Das begehbare Sinnfeld" — Galaxie als Sinnfeld, Kante als Schiene, alles gezeichnet statt gerendert): `docs/DESIGN_CONCEPT_v7_sinnfeld.md`. Vorgänger-Konzept: `docs/DESIGN_CONCEPT_der_lebende_druckbogen.md`.
- Starter-Deck: `assets/sonic_slaughterhouse.pdf` + `data/sonic_slaughterhouse.json`.

### C · Card-Viewer POC / „Infinite Canvas" — der jüngste Strang
Immersiver **Card-First-Reader**: die Karte ist der Held, kein gebauter Raum. Kern-Loop: Decks wählen → Mode würfeln → Box-Raum (6 Karten = 6 D6-Flächen inkl. Decken- und Boden-Karte) → umblicken → Fokus-Karte lesen (**Zoom/Pan INNERHALB des Rahmens**, geclippt) → Karte klicken → **ein `window.claude.complete`** (Contract 06) → nächster Raum. Karten-Pool-Ökonomie macht es „unendlich durch Inhalt, nicht Geometrie": besuchte Karten kommen nie wieder, unbesuchte nach ≥4 Räumen, Nachschub cross-deck.
- **v1 ist FEHLGESCHLAGEN / eingefroren.** Ehrlicher Nachruf: `docs/CARD_VIEWER_POC_v1_POSTMORTEM.md`. Root-Cause: **falsches Raum-Grundmodell** (Ring aus schwebenden Panels statt geschlossener Box aus Karten-Wänden), zu spät korrigiert; auf Symptome statt Konzept iteriert; Bewegung ohne Boden; Verifikation prüfte End-Zustände statt Bewegung. Lehre: **erst ein 1-seitiger Raum-/Navigations-Contract mit Skizze, dann bauen.**
- **Wiederverwendbar aus v1** (nicht wegwerfen): PDF-Pipeline, Deck-Registry/Pool-Ökonomie, Clay-Pet + Sphere-Eyes, Zoom/Pan-Clipping, Mode-Farben, 06-Call, LRU-Budget. **Wegwerfen:** Ring-Geometrie, Kamera-/Snap-Navigation, Transition, Pet-Traversal-Keyframes.
- Neu-Plan für v2: `docs/CARD_VIEWER_HANDOVER_coworker.md`. Einstieg: `uploads/00_START_HERE.md`.

### D · FrizzleBob — der Avatar/Companion
Prozeduraler Charakter, zugleich Erzähler, Würfel und diegetischer Controller. Steuer-Vertrag: `window.fb.*`. Aktueller Look: **Clay-Material** (object-space Triplanar Cardboard + Studio-HDRI) + **Sphere-Eye-Rig** (v3), Anchor-Werte aus `pet-LIBRARY.json`. Assets: Cube-Pets als GLB (`media/3D_Assets/GLB_cube-pets/animal-<name>.glb`, bunny = FrizzleBob).

### E · Chamber / Trilogie-Experimente (Kontext, keine Baustelle)
`Fractal Almanac.dc.html`, `Three Weathers.dc.html`, `Canvas.dc.html`, `Canvas-2.dc.html` — frühere/parallele Experimente derselben Linie (Utopia/Dystopia/Protopia-Trilogie: `assets/deck_a|b|c.pdf`, `data/deck_a|b|c.json`, `ontology/trilogy_v1.json`, `themes/`).

---

## 5 · Die Transmedia-Vision (Nordstern, gestaffelt — NICHT der nächste Sprint)

Voll: `uploads/02_TRANSMEDIA_PLATFORM_vision.md`. Keystone ist das **Paket-Manifest**: eine JSON pro Deck/Erlebnis, zeigt auf `pdf_web`, `pdf_hq` (Gumroad), `tour_script`, `audio[]`, `song`, `video`, `blog`, `cover`, `avatar_directions`; adressierbar per URL (`viewer?pkg=sonic`), QR-verlinkbar. Schichten in Reihenfolge, nicht auf einmal:

- **L0 · Viewer (jetzt):** Kapsel + Fahrt auf einem Deck.
- **L1 · Paket-Manifest + `?pkg=`:** Viewer lädt ein Paket per URL.
- **L2 · Tour + Audio + Avatar:** kuratierte FrizzleBob-Tour, ElevenLabs-mp3 taktet Fahrt + Lippen. Erst 3–4 Flaggschiff-Decks.
- **L3 · Community & Builder:** Import/Export von Touren/Stories/Lernpfaden als JSON; FrizzleBob-als-Builder (LLM-Agent, BYOK).
- **L4 · Aufgezeichnete Partien:** Playthrough = NDJSON-Log → replayen, teilen, verzweigen (= „build your own adventure").
- **L5 · Cross-Domain:** gleiche Shell, `content_type` + `skin` getauscht. **MedKayfab** (Med/Blended-Learning: Video-Kacheln, virtueller Patient, CME-Lernpfade) ist der wichtigste Cross-Domain-Zweig; Style-System: `docs/KFB_MED_STYLE.md` + `themes/kfb-med.css`.

**Verbindung zum QA-Strang:** ein aufgezeichneter Playthrough IST ein NDJSON-Run-Log — genau, was die Blind-QA-Engine schon produziert. QA-Läufe = aufgezeichnete Partien; die besten Beats Human-in-the-Loop kuratieren = Appetizer.

---

## 6 · Datei- & Verzeichnis-Landkarte

- **`*.dc.html` (Root)** — Design Components, je ein Bau (Viewer/Tisch/Canvas). Öffnen direkt im Browser. Versioniert per Dateiname; eingefrorene Versionen nicht anfassen.
- **`*.js` (Root)** — die Engines zu den DCs (`kfb-table.js`, `comic-viewer.v1.js`, `comic-cube.v2.js`, `cube-pet.js`). `support.js` ist die DC-Laufzeit, **nie editieren**.
- **`v6/`** — sauberes Rehome-Bundle für den aktuellen KFB-Table-Build (v6). Eigene `docs/`, `themes/`, `export/`, `verify/`, eigenes `CLAUDE.md` (autoritatives UI-Kit).
- **`docs/`** — Changelog, Backlog, Onboarding, Handovers, Design-Konzepte, `deep_specs/` (Contracts), `sprints/`.
- **`uploads/`** — Briefs, Kanon, Research, Screenshots (`Bildschirmfoto …png` = Georgs Feedback-/Skizzen-Bilder). Einstiegs-Briefs sind durchnummeriert (`00_…`, `01_…`).
- **`assets/`** — Deck-PDFs (web-Auflösung) + Skydome-webp. **`data/`** — Deck-JSONs (SSOT-Texte). **`ontology/`** — Trilogie-Struktur. **`themes/`** — kayfabe.json, kfb-med.css. **`media/3D_Assets/`** — GLB-Modelle. **`export/`** — Standalone-HTML-Exporte + Verifikations-Screenshots. **`FrizzleBob/`** — Avatar-Material.
- **`v6/docs/index.json`** — die **Multi-Deck-Registry** (`baseUrl` = GitHub-raw, 4 Decks: Forget Utopia / Anatomy of a Trap / Protopia Sketchbook / Sonic Slaughterhouse, + Rules-PDFs). Assets IMMER per GitHub-raw laden, nichts Schweres kopieren. URLs: `uploads/ASSET_URLS.md`.

---

## 7 · Konventionen für jeden, der hier baut

- **Prime Directive: schlank halten & Fundament vor Feature.** Der Vorgänger-Anlauf kippte in Komplexität und wurde unspielbar. Erst das Gefühl beweisen, dann skalieren. **Social Agency, nicht Object Agency:** Animation = Interpunktion, löst sich in Ruhe auf, kein Idle-Fidget. Casino-Politur = Marke verloren; **wonky bleibt.**
- **Verifizieren, nicht vertrauen:** Face-Orientierung, Karten-Mapping, Bewegung IMMER per Screenshot prüfen (nicht der Logik glauben) — der teuerste wiederkehrende Fehler war, End-Zustände statt Bewegung zu prüfen. **Ein Ding sauber, per Screenshot verifiziert, dann fertig.**
- **Versionierung:** eingecheckte Versionen einfrieren; Weiterentwicklung als neue Datei (v3, v4 …); Changelog-Eintrag pro Version.
- **Renderer = WebGL2, nicht WebGPU/TSL** (Lead-Entscheid). Wenige billige Effekte reichen (Halftone, Sky-Shader, Partikel). `THREE.Points`/`LineSegments` mit Laufzeit-Positionen: `frustumCulled = false`.
- **Modell-Rollen:** schwerer UI/Code-Bau = **Opus**; kreative Voice-/Prompt-Arbeit = ein **Fable**-Pass; Live-Erzählung zur Laufzeit = **claude.ai / Sonnet** via `window.claude.complete`.
- **Arbeitsteilung der Chats:** der Design-Chat (dieser) = three.js/visuell/Oberfläche. Die **Cowork-Lane (Opus)** = Daten/Engine/Korpus/SSOT-Lead. Änderungen am Korpus gehen dorthin zurück, nicht als lokale Kopie.

---

## 8 · Glossar

- **KFB** — KayfaBizarro, das Spiel/die Marke.
- **SSOT** — Single Source of Truth; hier die Deck-JSONs.
- **Deck** — ein Karten-Set: druckfertige PDF + Analyse-JSON.
- **Story-Mode** — eine von 6 Erzählfarben/-stimmen (Tragic … Forbidden), per D6 gewürfelt.
- **finger-rule** — beim Erzählen physisch auf die eingewebte Karte zeigen; Kernregel.
- **Kapsel** — der Quader in Time Capsule Ride, trägt einen ganzen Zug auf seinen Flächen.
- **Skin** — parametrische Haut: KFB / MedKayfab / FrizzleCrits.
- **content_type** — deck-tour / learning-path / virtual-patient (Cross-Domain-Schalter).
- **Layer Zero** — der Anti-Slop-Stilboden für allen erzeugten Text.
- **finger-rule / Show it · Spin it · Sell it** — Karten-Ritual pro Karte, jedes Mal.
- **NDJSON-Log** — zeilenweiser Spielverlauf; zugleich QA-Run und Replay-Quelle.
- **Cel / papier** — die zwei visuellen Looks (Toon-Outline vs. naturalistisch).
- **DC** — Design Component (`*.dc.html`), das Oberflächen-Dateiformat dieses Projekts.

---

## 9 · Zum Weiterlesen (Reihenfolge nach Fokus)

- **Gesamt-Andockpunkt:** `uploads/00_EXPLORER_VIEWER_context_briefing.md`
- **Time Capsule Ride:** `docs/ONBOARDING_fresh_claude.md` → `docs/CHANGELOG.md` → `docs/DESIGN_CONCEPT_v7_sinnfeld.md`
- **KFB Table v6:** `v6/docs/START_HERE_v6.md` → `v6/CLAUDE.md` → `docs/deep_specs/10_SCREEN_SPACE_OUTLINES.md`
- **Card-Viewer / Infinite Canvas:** `docs/CARD_VIEWER_POC_v1_POSTMORTEM.md` → `docs/CARD_VIEWER_HANDOVER_coworker.md`
- **Kanon (immer):** `uploads/01_LAYER_ZERO_canon.md`
- **Vision (Nordstern):** `uploads/02_TRANSMEDIA_PLATFORM_vision.md`
- **Med-Cross-Domain:** `docs/KFB_MED_STYLE.md`
- **Deck-Registry / Assets:** `v6/docs/index.json`, `uploads/ASSET_URLS.md`

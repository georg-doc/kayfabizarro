# SPRINT-STATUS v8 — Abgleich mit Coworker-Backlog

**Stand:** 2026-07-19 · Session v8-Cut. Ein Blatt zum Sync mit dem Coworker-Backlog.
Status: ✅ erledigt · 🟡 offen/einstreubar · ⛔ blockiert · 🔭 eigener Sprint/Ausblick.

---

## Sprint 5 — Reproduzierbarkeit & Regressions-Sichtbarkeit
- ✅ **5.1 Deterministische Test-Hooks** — `window.__rideTest = {seek, play, setMode, setSeed, snapshot}`. Doku `docs/HANDOVER_v7_test-hooks.md`.
- ✅ **5.2 DEV-Perf-Readout** — `?dev` (o. `localStorage rc2-dev=1`) → FPS(EMA)/DRAWS/TRIS im Dashboard-Grid. Ohne Flag ganz aus.

## Sprint 6 — Echte SFX (optional)
- ⛔ **Audio-Manifest** `Sounds/fx.json` (Trigger→Datei, Loader wie Jukebox, RAW-first). **Blocker:** echte one-shot-Dateien fehlen noch im Repo (`media/3D_Assets/Sounds/fx/`). Trigger (`triggerTurnFx`/`triggerJerkFx`/`triggerCardSfx`) hängen bereit.

## Partikel-Strang (v7 → v8)
- ✅ **Tacho** arc-length-kompensiert (`_arcCompAt`) — echte, stetige km/h.
- ✅ **Pet-Lookahead** = fester WELT-Abstand → Hügel-Crest in Phase mit gefühltem Tempo.
- ✅ **Beat-Aura** als radialer Partikel-Burst (`_emitBeatBurst`) statt Sprite-Halo.
- ✅ **Rad-Funken** emittieren immer vom Schienenkontakt (unabhängig von Beifahrer-Pos).
- ✅ **Partikel-Immersion** (BRIEF-Benchmarks): Track-Flows aufgeweitet, Funken größer+dichter.
- 🟡 **„Liga"-Sprung / Bloom** — v8-Versuch: Test-v1-Config (2.1/0.5) lässt sich per **Global-Bloom NICHT** in die Ride heben ohne Karte/Augen/Würfel zu verbrennen. v8 auf v7-Bloom stabilisiert. **Echter Glow braucht Selective/Emissive-Bloom (MRT) → Sprint 7.**
- 🔭 **Sprint 7 — Selective/Emissive Bloom (MRT):** Fundament-Sprint. Nur FX schreiben in `emissive`, Bloom liest nur diesen Kanal → Pet/Karte/Rails brennen nie mit. Entblockt Partikel-Glow UND Audio-Terrain. Kickoff `docs/SPRINT_KICKOFF_selective-bloom.md`.
- 🔭 **Sprint 8 — Audio-Terrain (Voxel):** GPU-instanziertes, beat-reaktives Boden-Feld (KISS, `HANDOVER_audio_terrain_KISS.md`). Beat-Puls 104 first, dann Stems-reaktiv. Sitzt auf dem Emissive-Fundament — sonst dieselbe Bloom-Falle.
- 🟡 **COSMIC-Tint auch auf Rad-Funken-Duo** (aktuell Pet↔Mode-Farbe).

## Offen / geparkt
- ⛔ **three.js-Port** (linkedparticles/attractors als Vergleichs-Tabs) — Compute-Spawn rendert im Preview nur BG. Plan in `docs/HANDOVER_v7_particles.md §3`. Teil-Port `particle-test/linkedparticles.html`.
- 🔭 **Skydome Hypno-Spiral** (Georg) — Sky-Mode `spiral`, Rotationsrate ∝ speed01 + Beat-Puls. Eigener Sprint.
- 🟡 **Reading-Tour** Ten-Durchschlag ggf. weicher (nach Arc-Fix prüfen).
- 🟡 **Pfad-Hygiene Standalone** — `SKY_URL`/`SKY_URL_B`/`DECKS[].file` auf RAW umstellen (gilt weiter, jetzt in v8.js).

---

## 🔭 AUSBLICK — Pet Claymation Lip-Sync (aus KFB Pet Editor v9)

Neu drüben im Pet-Editor: **zwei claymation-artige, pseudo-lip-sync-triggerbare Münder**.
Für die Ride-Integration relevant — Contract & Verhalten sauber getrennt halten:

- **Aussehen** wohnt im **Pet-Contract** (`pet.mouth`): Character-Animator-PNGs (z. B. `FrizzleBob-Mouth_01`, GitHub RAW) als Surface-Fit-Plane auf dem Body. Platzierung pro Pet (Größe/Höhe/Breite/Kippung/Bogen). Export schreibt `pet.mouth` in die kanonische `pet-LIBRARY.json`.
- **Verhalten** (Tempo, Shuffle) wohnt in der **Motion-Library** — nicht im Contract.
- **13 Viseme** als Vorschau-Set; **Talk-Test = Visem-Shuffle (noch kein echtes Lip-Sync)**.
- **Zwei Münder** = zwei Claymation-Sets, per Trigger umschaltbar → Basis für späteres echtes Lip-Sync (Amplitude/Phonem → Visem-Index).
- **Roadmap Ride:** wenn `pet.mouth` in der Library steht, Mund-Plane im Ride-Pet-Rig mounten und an vorhandene Talk-Trigger (Voice/Beat) koppeln — pseudo-Sync via Amplitude-Hüllkurve zuerst, echtes Phonem-Mapping später.

### Coworker-Tickets (Pet Studio v9+), zur Aufnahme ins Backlog
- 🐛 **Lion Doppel-Augen:** Lion trägt noch die flachen, aufgemalten Kenney-Augen UNTER den 3D-Eyeballs → Check & Fix. Auch in `media/3D_Assets/GLB_cube-pets/EMBED_CUBE_PETS_v1.md` als Issue notieren.
- 🧹 **Bunny Schnauze:** störende `stripSnout` im Gesicht-Tab löschen (Knubbelnasen-Ersatz) — Backlog.
- 📦 **pet-LIBRARY.json** kanonisch v0.2.0 → v0.4.4 publizieren (nach v9-Mund-Export).

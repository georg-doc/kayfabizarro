# DER LEBENDE DRUCKBOGEN
## Design-Konzept — Time Capsule Ride · Antwort auf `DESIGN_CONCEPT_COMMISSION.md`

**Von:** Fable-Five-Chat (mit High-Level-Mandat) · 2026-07-10.
**Art:** Konzept, keine Umsetzungs-Spec. Details gehen danach an günstigere Modelle.
**Nicht vorliegend:** `NEXT_REBRIEF_feedback.md`, `IMMERSIVE_FLIGHT_research.md`, `03_GALAXY_NAVIGATION_northstar.md` — gearbeitet mit Commission §6, `SKYDOME_research.md`, `NAVIGATION_CONCEPT.md`, `02_TRANSMEDIA_PLATFORM_vision.md` und dem v6-Ist-Stand.

---

## 0 · Die eine Idee

**Die Welt ist ein einziger, endloser Druckbogen. Du bist das Auge des Lesers.**

Alles Sichtbare ist auf diesen Bogen gedruckt oder gemalt: Tusche, Wasserfarbe, Halftone, Papierweiß. Alles, was geschieht, ist die Bewegung eines physischen Auges über und durch den Bogen — nie ein Schnitt, nie eine Blende. Alles, was man anfassen kann, ist Druckerzeugnis: Marginalien, Griffregister, Passermarken — nie Interface.

Daraus folgen drei Gesetze. Jedes System des Rides ist eine Anwendung dieser Gesetze, nichts weiter. Wo ein Detail nicht aus einem Gesetz ableitbar ist, fliegt das Detail, nicht das Gesetz.

**Gesetz 1 — Papier (Materie).** Es gibt genau ein Material-Vokabular: Papierweiß (Gutter), Tusche-Linie mit Hand-Wobble, Wasserfarb-Wash, Halftone-Schatten, Schreibmaschinen-Type. Jedes Objekt der Welt — Kapsel, Himmel, Tür, Staub, Knopf — ist aus diesem Vokabular gebaut. Ein Element, das nach „Screen" aussieht, existiert nicht.

**Gesetz 2 — Auge (Bewegung).** Die Kamera ist ein physischer Körper: Masse, Dämpfung, Impuls. Jeder Zustandswechsel ist kontinuierliche Bewegung in Echtzeit — der Kamera oder eines Objekts. Geschwindigkeit wird über die UMGEBUNG wahrgenommen (Parallaxe, Pigment-Advektion, FOV-Atmung), nie über gemalte Symbole. Kein Crossfade, kein Teleport, kein per-Frame-Keyframing.

**Gesetz 3 — Rand (Interface).** Interaktion und Meta leben in den Marginalien des Gedruckten: Caption-Boxen, Griffregister, Kolumnentitel, Passermarken. Legitimationstest für jedes UI-Element: *Würde ein Drucker oder Comic-Zeichner das auf den Bogen setzen?* Wenn nein, existiert es nicht. Der Viewport selbst ist eine Seite — sein äußerster Rand ist der Satzspiegel-Rand und gehört damit zum Bogen (das legitimiert die flüsterdünne Randzeile strukturell, nicht als Ausnahme).

---

## 1 · Warum die Fehler-Klassen damit strukturell ausscheiden

| Fehler-Klasse (Commission §6) | Gesetz, das sie verbietet | Strukturelle Konsequenz |
|---|---|---|
| Ruckeln, Crossfade-Sprünge, „Rubrik-Sprungfahrt" | Gesetz 2 | Fixed-Timestep-Physik + Feder-Ziele (§3). Es GIBT keinen Codepfad für Schnitte. |
| Gemalte Punkte/Speed-Lines | Gesetz 2 | Tempo = Umgebungsantwort. Die Hyperraum-Streaks aus v2–v6 werden ersatzlos gestrichen (§9). |
| UI auf undesignte Flächen geklebt | Gesetz 3 | Jedes Element muss eine Marginalie sein; das Inventar (§5) ist abschließend. |
| Caption/Meta statisch über der Kunst | Gesetz 1+3 | Captions sind Comic-Panels IM Druck (v6-Errungenschaft, wird Gesetz). |
| Ein Outline-Element stumpf skaliert | Gesetz 1 | Linien-Regel: Tusche-Linienstärke ist optisch konstant, Ränder werden pro Zielauflösung neu GEZEICHNET (seeded Wobble), nie skaliert. |
| Rotation kontra-intuitiv | Gesetz 2 | Grab-follows-finger: der gegriffene Punkt folgt dem Zeiger (§4). Physik, nicht Mapping-Konvention. |

---

## 2 · Die drei Systeme — ein Guss

Die Systeme sind keine Module nebeneinander; sie sind dieselben drei Gesetze auf drei Maßstäben: **Welt** (Reise), **Objekt** (Kapsel), **Zeichen** (Marginalien). Eine Stimmungsquelle färbt alle drei: die Mode-Palette (Rules S.16) liefert pro Station `{ink, panel}`, daraus leiten sich Himmel-Wash, Staub-Tint, Glow, Caption-Eyebrow und (später) Klang ab — EINE Funktion `mood(mode, theme)`, kein zweiter Farbentscheid irgendwo. Theme paper/dark bleibt orthogonal: paper = Tusche auf Weiß (Marken-Primär), dark = Weiß auf Tusche.

---

## 3 · System Welt: DER BLICK DES LESERS (Bewegungs-/Reise-System)

### 3.1 Physik-Spine (Pflicht-Spezifikation, kein Hand-Waving)

Der Kern ist ein Kamera-Rigid-Body, der ALLE Bewegungen fährt — Fahrt, Docking, Free-Fly, Lese-Einrasten, sogar den Sky-Drag. Es gibt nur diesen einen Bewegungs-Codepfad.

- **Integration:** Fixed Timestep 1/120 s mit Akkumulator, Render-Interpolation zwischen den letzten zwei Physik-Zuständen (Gaffer-on-Games-Standard „Fix Your Timestep"). Damit ist Ruckeln durch variable Frame-Zeiten konstruktiv ausgeschlossen.
- **Zustand:** `P` (Position), `V` (Geschwindigkeit), `Q` (Orientierung, Quaternion), `Ω` (Winkelgeschwindigkeit), `f` (FOV). Nichts davon wird je direkt gesetzt (einzige Ausnahme: Session-Start).
- **Feder-Ziele statt Lerp:** jede Zielgröße wird über kritisch gedämpfte Federn erreicht: `a = ω_n²·(ziel − x) − 2·ω_n·v`. Pro Anwendungsfall ein ω_n (Tunables): Lese-Einrasten ≈ 4 rad/s, Docking ≈ 3, Blick-Drag ≈ 8, FOV ≈ 2.5. Kein Overshoot-Skript — die Feder MACHT das Settling.
- **Fahrt = Kraftmodell auf Leitkurve, nicht Keyframes:** zwischen Stationen liegt eine arc-length-parametrisierte Leitkurve (Catmull-Rom, LUT mit 256 Samples). Ein Autopilot fährt darauf ein **jerk-limitiertes S-Kurven-Geschwindigkeitsprofil** (`v_max`, `a_max`, `j_max` — Coaster-/Robotik-Standard); die Kamera wird per Feder an den Profilpunkt + Lookahead (`s + k·|V|`) gebunden. Ergebnis: Anfahren, Reisen, Ankommen sind EINE stetige C²-Bewegung.
- **Banking:** Rollwinkel aus der Querbeschleunigung, `φ = atan(a_lat / g_eff)`, gekappt (~12°), gefedert. Die Kamera legt sich in Kurven wie ein Fahrgeschäft, nicht wie ein Skript.
- **FOV-Atmung:** `f = f_lese + (f_fahrt − f_lese) · s(|V|)` — Lesen bei 24–26° (quasi-orthografisch, v6-Errungenschaft wird Gesetz), Fahrt bis 50–55°. Speed-Gefühl über Optik, nicht über Striche.
- **Uniform-Vertrag:** die Physik exportiert pro Frame `uTime`, `uSpeed` (Skalar), `uVel` (vec3, Welt) — konsumiert von Himmel, Staub, Pigment-Smear, später Audio. Das ist die Naht zum Shader-Track; der v6-Sky hört schon auf `uDrift`(= integriertes uSpeed).

### 3.2 Tiefe: der Bogen hat drei Lagen

Geschwindigkeit ist Parallaxe. Drei Lagen, alle aus dem Papier-Vokabular:

1. **Fern:** der prozedurale Wasserfarb-Himmel (v6, BackSide-Sphere, domain-warped fBm + Granulation + Edge-Darkening). Bei Fahrt wird der Warp entlang `uVel` advektiert — das Pigment SELBST strömt am Auge vorbei („nasse Farbe im Wind"), das ist der legitime Erbe der Speed-Lines.
2. **Mittel:** treibende Druckfragmente — instanzierte Papier-Schnipsel/Seitengeister (Instancing, ein Atlas aus dem Deck-PDF, sehr niedrige Alpha), quasi-statisch im Raum verteilt (seeded). Sie geben der Fahrt echte Vorbeizieh-Tiefe. (Die Karten-Collage aus v4/v5 wandert hierher: nicht als Himmel, sondern als dünn gestreute Raum-Schicht.)
3. **Nah:** Pigment-Staub (vorhanden), Größe/Dichte seeded, Tint aus `mood()`.

### 3.3 Bewegungs-Grammatik (aus `NAVIGATION_CONCEPT` §2, bestätigt)

Drei Verben, die sich nie überschneiden: **Drehen** (Objekt, Geschwister eines Turns) · **Zoomen** (Ebene: Karte↔Seite↔Cover↔Regal) · **Fliegen** (Welt, Station↔Station↔Galaxie). Tour/Journey = dieselben Verben, aufgezeichnet abgespielt (deckt L2/L4 der Vision ohne Sondercode).

---

## 4 · System Objekt: DAS LEBENDE DRUCKOBJEKT (die Kapsel)

### 4.1 Was die Kapsel IST

Eine **gebundene Signatur**: vier bedruckte Panels (Längsseiten) um eine Achse gebunden, zwei quadratische Deckel als Funktionsseiten — Wetter-Würfel und Tür. Sie ist kein UI-Träger, sie ist ein Druckerzeugnis mit Mechanik, wie ein Popup-Buch: Papier, das etwas KANN.

### 4.2 Drehung ist Physik (Beat = Drehung, finger-rule bleibt)

- Die Kapsel hat Trägheit. Drag erteilt Drehimpuls; **der gegriffene Punkt folgt dem Finger** (Arcball auf der Kapsel-Silhouette) — damit ist die Drehrichtung nie wieder Konvention, sondern Haptik.
- Loslassen: Detent-Federn. Ziel-Raste = Projektion `θ + Ω/(2ζω_n)` auf die nächste **aufrechte** Raste (Orientierungs-Invariante aus `NAVIGATION_CONCEPT` §4, in v6 bewiesen, hier Gesetz). Fühlt sich an wie eine gut geölte Drucktrommel: schnipsen, klacken, steht.
- Skript-Beats benutzen DENSELBEN Detent-Mechanismus (Autopilot erteilt den Impuls). Ein Codepfad, ein Gefühl.

### 4.3 Präsentation einer Fläche (Lese-Zustand)

Kamera auf der Flächen-Normale in Plattenhöhe, enges FOV, Distanz aus FOV+Viewport+Flächen-Ebene hergeleitet (v6). Aufrecht, rechtwinklig, unverzerrt — der Lese-Zustand ist der Ruhepunkt aller Federn, kein Modus.

### 4.4 Die Tür ist eine echte Öffnung (kein Flash, kein Schnitt)

Der Quest-Deckel öffnet **materiell**: die Tusche-Umrandung des Deckels „entbindet" sich, das Deckel-Papier fächert als 6 Papier-Lamellen-Iris nach außen (6 planare Meshes, geteilte Textur, federgetrieben — billig). Dahinter liegt ein **kurzer Kehlraum** (8–12 Einheiten Papier-Tube, innen mit demselben Wash-Shader bemalt, `uVel`-advektiert), dessen Ende nahtlos in den offenen Himmel übergeht. Die Kamera fliegt DURCH das Loch, das Profil (§3.1) beschleunigt im Kehlraum. Kein Blend, kein weißer Flash — Licht fällt als warmer Wash-Schein durch die sich öffnenden Lamellen (additives Sprite genügt).

Türblatt-STILE (Vorhang / Schleuse / surreale Tür, HANDOVER_RESPONSE) bleiben spätere Skins DIESES einen Mechanismus: gleicher Slot, gleiche Timeline, anderes Papier.

### 4.5 Galaxie aus Daten gestempelt

Ein Deck-Manifest instanziert die Galaxie deterministisch: `seed = hash(deck_id)`. ~15 Knoten (Karten-Stationen, Cover, Regeln, FAQ, Jump-Points) liegen auf einer verdrifteten Leitkurve (low-discrepancy verteilt, nach Phasen-Seiten geclustert); Jump-Points an den Enden führen zur Nachbar-Galaxie (Regal-Ebene). Jedes Deck stempelt dieselbe Welt mit anderem Inhalt — Invariante „portables JSON" erfüllt, kein Level-Design pro Deck.

---

## 5 · System Zeichen: MARGINALIEN (diegetisches UI)

Das abschließende Inventar. Jedes Element besteht den Drucker-Test (Gesetz 3):

| Element | Druck-Metapher | Funktion | Ort |
|---|---|---|---|
| **Caption-Box** | Comic-Caption im Panel | Erzähl-Beat, Meta (Power/Lore) | auf der Fläche/dem Deckel gebacken (v6) |
| **Der Lift** | gedrucktes Bedienpanel des Popup-Objekts | Ebenen + Geschwister | auf dem Tür-Deckel (v6) |
| **Griffregister** | Daumenregister-Tabs am Buchschnitt | Ebenen-Anzeige + Direktsprung, IMMER sichtbar | schmale Papier-Tabs an der Kapsel-Kante (3D, neu — löst „Lift nur auf dem Deckel sichtbar") |
| **Kolumnentitel** | Kopfzeile des Satzspiegels | Station / Quest | Viewport-Rand oben, Special Elite |
| **Passermarke + Mode-Farbfeld** | Druckerei-Farbkontrollstreifen | Mode-Chip-Nachfolger: kleines Farbfeld + Registerkreuz | Viewport-Rand unten rechts |
| **Beat-Punzen** | Seitenzähl-Punkte | 4 Beats, aktiver in Mode-Ink | Viewport-Rand unten Mitte |
| **Hover-Affordanz** | Anlösen der Tusche | klickbare Fläche: Kante „verläuft" minimal (2px Wash-Bloom), Cursor | auf dem Objekt |
| **FrizzleBob** | Randglosse | Erzähler-Präsenz (Text; Avatar = L2) | Caption-Eyebrow, Zitate in Special Elite |

Gestrichen und durch Obiges ersetzt: freischwebende Panels jeder Art, Icon-Buttons, das v5-Eck-Widget (bereits raus), der Mode-Chip als Text-Kasten (wird Farbkontrollstreifen).

**Steuerung (unverändert bestätigt, jetzt physikalisch):** Drag Kapsel = greifen/drehen · Drag Himmel = umschauen (Feder) · Wheel/Lift/Register = Ebene · A/D = Geschwister · Klick Fläche = Lese-Zustand · W = Tür/Fahrt · Space = Beat. Touch: gleiche Verben, Regionen ≥ 44 px.

---

## 6 · Standards-Latte (woran wir uns messen)

- **Kamera:** kritisch gedämpfte Federn (Standard-Game-Camera-Technik, „juice it with springs"), Fixed Timestep + Interpolation (Gaffer on Games), Lookahead-Following (Third-Person-/Rail-Cams).
- **Fahrprofil:** jerk-limitierte S-Kurven (Achterbahn-/Robotik-Motion-Profiles), arc-length-LUT-Splines (Standard bei Rail-Shootern/Coastern).
- **Speed-Wahrnehmung:** FOV-Kopplung + Umgebungs-Parallaxe (Racing-Genre-Standard), Advektion im Hintergrund-Shader statt Partikel-Streaks.
- **Himmel:** domain-warped fBm + NPR-Watercolor (Edge-Darkening/Granulation nach Luft & Deussen; Quilez-Warp) — steht in v6, wird `uVel`-reaktiv.
- **Diegetisches UI:** Genre-Referenz „UI lebt im Weltobjekt" (bekannt aus Games mit In-World-Interfaces und aus dem Print-Design: Marginalie, Griffregister, Passermarke). Unser Vokabular ist Print, nicht SciFi — das unterscheidet uns.
- **Lebendige Objekte:** Popup-/Papiermechanik als Animationelogik (Lamellen-Iris, Falt-Flaps) statt Partikel-Magie.

---

## 7 · Nähte (Invarianten bestätigt)

- `window.KFBDie.roll()` → Detent-Ziel des Wetter-Würfels (statt Chip-Cycling).
- `kfb_beat_engine.js` → `focus` mappt auf Drehimpulse + Captions (Format `{face|lid, kicker, line, verdict?}` bleibt).
- `window.fb.*` → L2; bis dahin Randglosse.
- NDJSON-Log unverändert; Playthrough = aufgezeichnete Verben (§3.3) → Replay fällt gratis aus der Grammatik.
- PDF-Pipeline (pdf.js + Quadranten-Crop) unangetastet; FACE_MAT/FACE_ROT bleiben die Geometrie-Wahrheit.
- NEU vorgeschlagen: der Uniform-Vertrag `uTime/uSpeed/uVel` als offizielle Naht zwischen Motion-Kern und allen Shadern/Audio.

## 8 · Widersprüche zu früheren Vorgaben (erwünscht, hiermit begründet)

1. **Hyperraum-Streaks (v2–v6) fliegen raus.** Velocity-gestreckte Linien SIND gemalte Speed-Lines — sie widersprechen Gesetz 2. Ersatz: Pigment-Advektion + Parallaxe-Lagen + FOV.
2. **Portal-Flash fliegt raus.** Der weiße Radial-Flash ist ein kaschierter Schnitt. Ersatz: materielle Tür + Kehlraum (§4.4).
3. **Iris als gemalte Textur fliegt raus.** Die Aperture auf dem Deckel-Canvas wird durch die Lamellen-Geometrie ersetzt — eine Öffnung, durch die man wirklich fliegt.
4. **„Meta im Screen-Space" (V5 §6) bleibt gekippt** — v6 hat es korrigiert; dieses Konzept macht die Marginalien-Regel zum Gesetz mit abschließendem Inventar.
5. **Getrennte Bewegungs-Codepfade (camMove / Ride-Ease / Dock-Formel / Orbit) werden zu EINEM Rigid-Body konsolidiert.** Das gescriptete `ez()`-Easing über die Spline war die Wurzel der „Rubrik-Sprungfahrt".

## 9 · Staffelung (Vorschlag, schlank)

- **M0 · Motion-Kern-Prototyp** (code-starker Track, isoliert): Rigid-Body-Kamera, S-Kurven-Autopilot auf Leitkurve, Banking, FOV-Atmung, Uniform-Vertrag, 2 Dummy-Stationen. Abnahme: 60 s Dauerfahrt ohne einen einzigen Schnitt oder Ruck.
- **M1 · Integration:** v6-Inhalt (Kapsel, Captions, Lift, Himmel) auf den Kern; Streaks/Flash raus; Kapsel-Drehung auf Detent-Physik; Grab-follows-finger.
- **M2 · Die Tür:** Lamellen-Iris + Kehlraum; Verdict-Choreo andocken.
- **M3 · Galaxie:** ~15 Knoten aus Manifest gestempelt, Griffregister-Tabs, Jump-Points. (Danach: Türblatt-Skins, Tour/L2.)

## 10 · Für Georgs Prüfung (Konzept-Abnahme)

- [ ] Trägt EINE Designsprache alle drei Systeme? (Gegenprobe: jedes Element auf Gesetz 1–3 zurückführbar.)
- [ ] Schließt der Physik-Spine die Fehler-Klassen konstruktiv aus (nicht kuriert)?
- [ ] Ist die Tür eine Öffnung, keine Blende?
- [ ] Ist das UI-Inventar abschließend und drucker-legitimiert?
- [ ] Stempelt ein Manifest die Galaxie ohne Handarbeit?

# Card-Viewer POC — v1 (Fable / Design-Chat)

Immersiver **Card-First-Reader** für den Infinite Canvas. Umsetzung des `uploads/POC_BRIEF_card_viewer.md`.
Der Pivot ggü. dem Greybox `comic-cube.v1.js`: **kein gebauter Raum** mehr — die Karte ist der Held,
sechs 16:9-Comic-Panels stehen als **D6-Rundum** vor einem **Skydome**, das Pet ist der diegetische Controller.

## Dateien
- **`KFB Card Viewer.dc.html`** — Wrapper-DC (mountet die Engine, Tweaks: `pet`, `wash`, `tilt`).
- **`comic-viewer.v1.js`** — die Engine (Web-Component `<comic-viewer>`). Neu für v1, adaptiert die bewährten
  Subsysteme aus `uploads/comic-cube.v1.js`.
- **`cube-pet.js`** (Projekt-Root) — Companion/Character + **Sphere-Eye-Rig** (v3-Look). Kopie aus `v6/cube-pet.js`,
  Augen-Rig auf v3-Sphere-Eyes umgebaut, Augen-Materialien vom Clay-Shader entkoppelt (glatte Sclera/Lider fangen Studio-Highlights).
- **`comic-viewer.v1.js` · v3-Clay-Material**: der echte v3-Surface-Shader (`_clayMat`) — object-space Triplanar
  Cardboard001 + Knet-Relief + weiche AO über MeshStandard, Studio-HDRI via `RoomEnvironment`/PMREM, surf-Params
  aus `pet-LIBRARY.json` `material.live`. FrizzleBob sieht sofort aus wie im Pet-Editor v3 (kein Kenney-Toon mehr).

## Kern-Loop
Decks wählen (1–3) → **Mode würfeln** → **Box-Raum** (6 Karten = D6-Flächen: Front/Rechts/Links-Wand, **Decken-Karte**,
**Boden-Karte**, Rück-Wand = Spur) → umblicken (A/D dreht zwischen den Wänden, ↑/↓ = Decke/Boden; Skydome parallaxt) → Fokus-Karte lesen (**Scroll = Zoom, Ziehen = Pan — im Rahmen geclippt**) → Karte klicken →
**Enter/Back** → Enter = **EIN `window.claude.complete`** (Contract 06, but/therefore) → nächster Raum.
Pet-Klick → **Radial-Cube-Menü** (Roll · Skydome · Read · Sprache).

## Umgesetzt (v1)
- **D6-Ring** (RING_R 6.9) mit **Gutter** zwischen den Panels (Kartenbreite < 60°/Slot → sie stecken NICHT ineinander).
- **Emissive Karten** (MeshBasic, nie fehl-belichtet) + **irregulärer Tusche-Rahmen** (ExtrudeGeometry, wonky,
  Licht-Logik: Strich unten/links dicker). Rahmen = Konstante, Kunst = explorierbar.
- **Zoom/Pan INNERHALB des Rahmens** via world-space **Clipping-Planes** (EINMAL pro Zoom-Sitzung berechnet → kein Ruckeln).
  Zoom **um den Cursor** (nicht mittig), weich ziel-gelerpt. Bedienung: Doppelklick = Zoom-Toggle · `+`/`−` · Ziehen = Pan ·
  Pfeile/WASD = hoch/runter/seitlich rollen · Wheel (falls Host es nicht abfängt). Karte **füllt** das Fenster sauber (kein Spalt),
  ist dezent zurückgesetzt → 3D-Tiefe; Kamera hinter dem Zentrum → große Fokus-Karte + Nachbarn im **Anschnitt** mit Gutter.
- **Bewegung = räumliches Kontinuum (infinite canvas), KEIN Fade:** jeder Raum ist ein Karten-Ring an einem eigenen
  Welt-Zentrum; beim Durchtreten wird der nächste Ring **voraus** entlang deiner Blickachse gebaut (die gewählte Karte
  wird sein Rück-Slot am selben Ort) und die Kamera **reist kontinuierlich vorwärts DURCH die Karte** in den neuen Ring.
  Skydome + Fill-Licht reisen mit; der alte Ring wird nach dem Passieren entfernt. Der Pfad knickt entlang deiner Wahl = Story-Korridor.
  Pet läuft kamera-lokal voraus (dreht sich zur Karte) und kommt im neuen Raum zurück zum Spieler.
- **Skydome** band-getönt (mode-/dusk-/void-Preset + **equirect-URL-Input**), parallaxt beim Umblicken. Nicht auf Schwarz.
- **„still inking …"** = Karten-Ankunft (Wipe/Reveal scaleX + Fade), kein Spinner; Lade-Text im gleichen Beat.
- **Karten-Pool-Ökonomie:** besucht (`visited`, key `deck|n`) → nie wieder · angeboten-nicht-gewählt → **Cooldown ≥4 Räume**
  (`offeredAt`) · **cross-deck** Round-Robin-Nachschub aus allen gewählten Decks. Unendlich durch Inhalt.
- **2-Res-/LRU-Budget:** Voll-Res-Textur-LRU ~10/Deck; **Deck-PDF-LRU max 3** geparst; Peek = spekulativer Prefetch.
- **PDF-Pipeline** (pdf.js): `page = coverOffset+1+floor((n-1)/4)`, `quadrant = (n-1)%4` (index.json cardMapping).
- **Pet = Controller unten rechts** (ans Kamera-Rig geheftet, immer im Blick, **Sphere-Eyes** sichtbar).
- **Pet-Flight beim Enter** mit Cartoon-Physics (Prime Directive: Animation = Interpunktion):
  Anticipation (Crouch-Squash) → Take-off-**Stretch** → Sprung**bogen** durchs Panel, **wird größer** → Impact-**Squash**
  am Panel (+ Gutter-Weiß) → im neuen Raum **Return-Hop** mit zwei Landehüpfern zurück in die Control-Ecke, Landing-Squash.
- **06-Call** (narrate: `gutter`+`arrive`, but/therefore) mit Cache (`seed:room:deck:n`), 25 s-Timeout, **Offline-Stub**.
- **Session-Export** (07-lite NDJSON-artig), i18n DE/EN, kanonische **Mode-Farben** (deep_specs/09).

## Design-Entscheidungen (bewusst vom Brief adaptiert)
- **Tusche-Rahmen statt `_shaderHull` (KFB Table v6).** `_shaderHull` ist ein Inverted-Hull für 3D-Clay-Meshes; für
  flache Panels liefert ein purpose-built wonky Extrude-Rahmen die handgezeichnete Kante sauberer. Die **Licht-Logik**
  (Strichdicke unten/links) ist übernommen. → Kandidat: echtes `_shaderHull` gegentesten (Backlog).
- **Skydome = band-getönter Painter** statt `skydome_a/b.webp` (Ort im Repo unbestätigt, ⚠️ in ASSET_URLS). URL-Input
  liefert echte Equirect-Bilder on demand.
- **Narration** = minimale, randlose Auto-Fade-Zeile (kein Papier-Chrome, kein Portrait) — der Companion spricht, die
  Karte bleibt der Held.
- **Pet-Augen = v3-Sphere-Eye-Rig** (kugelig + Lider), getunte Anchor aus `pet-LIBRARY.json` (bunny: dx .32 · dy −.205 ·
  ring .22 · pupilSize .07 · inset .2 · converge −.34). **Nicht** die alten flachen Googly-Disc-Augen aus `v6/cube-pet.js`.

## Backlog / offen (NICHT in v1)
- **Detail-/Lese-View** (power/lore groß) — für später aufgehoben, Auslösung z.B. via **Info-„i"-Icon** (Sehschwäche/A11y). Out-of-scope.
- **Body-Surface-Shader** (Cardboard001 + Ink-Mod, object-space Triplanar aus `KFB Pet Editor v3`) — v1 nutzt das
  Toon-Material + selektive Gelb-Umfärbung. Angleichen an `material.live` aus `pet-LIBRARY.json`.
- **Pet→Würfel-Transform** (6 Flächen = 6 Modes) statt separater Würfel-GLB.
- **Synapsen-Feld** als Skydome-Alternative (A/B gegen den flachen Skydome, `Synapse Sphere v1`).
- Echtes `_shaderHull` für die Rahmen; Ken-Burns-Ankunfts-Settle; Deck-Wechsel als erzählter Zonen-Transit; Import/Replay.

## Assets (per GitHub-raw, nichts Schweres kopiert)
Cube-Pets `media/3D_Assets/GLB_cube-pets/animal-<name>.glb` (bunny = FrizzleBob) · Würfel `dice_ugur_lowpoly.glb` ·
Card-Back + Deck-PDFs/JSONs via `media/kfb/` + `index.json`. Details: `uploads/ASSET_URLS.md`.

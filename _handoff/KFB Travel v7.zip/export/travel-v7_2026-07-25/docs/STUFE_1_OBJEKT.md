# Stufe 1 + 2 — Kapsel-Objekt & Datenströme (`Time Capsule Object.dc.html`)

**Stand 2026-07-10.** Frischstart nach `00_POSTMORTEM_GOLD_SETTING.md`. Nur Stufe 1: das Objekt, nichts drumherum. v2–v8 unangetastet (Referenz).

## Entwurfsentscheidungen (ergebnisoffen getroffen, hier zurückgespielt)

1. **Aufrecht per Konstruktion, nicht per Patch.** Die Kapsel rotiert ausschließlich um die Hochachse (Yaw); Kamera-Höhe eng geklemmt (−0.2…2.7). Es existiert kein Codepfad, der eine Fläche kippen kann. Verifiziert über 5 Yaws + Ober-/Untersicht.
2. **Form folgt der Karte.** Die Trommel-Proportion wird zur Laufzeit aus dem echten PDF-Quadranten-Seitenverhältnis abgeleitet (Karten sind Querformat → flache Zoetrop-Trommel). Achteckige Papier-Dose: 4 getuschte Panels, dazwischen erhabene weiße Gutter-Kanäle (Ecken), Papier-Kragen oben/unten, Deckel mit symmetrischem Mode-Siegel (bewusst KEIN Text auf horizontalen Flächen — Text dort kann bei Yaw kopfstehen; ein Siegel nicht).
3. **Gutter UND Tusche:** weißer Gutter = Objektgeometrie (Ecken, Kragen, Panelränder); Tusche-Kante = gebakte wobbelige Ink-Rahmen, die die Art umschließen. Keine Inverted-Hull-Outlines auf Gutter-Teilen — genau die haben in v8 den Gutter gefressen.
4. **Tür-Mechanik, eine kontinuierliche Timeline:** Klick → Yaw eased zur nächsten Panel-Front (Ziel immer voraus) → Panel schwingt als Papiertür auf (Papier-Dicke, Papier-Rückseite) → Karte gleitet heraus und stellt sich aufrecht vor die Kamera. Rückweg = dieselbe Timeline rückwärts. Kein View-Umschalten.
5. **Look:** MeshToon + quantisierte 3-Band-gradientMap auf allen Papierteilen (Bänder wandern mit der Drehung); Karten-Flächen print-hell (Basic) — Lesbarkeit schlägt Shading auf der Art. Halftone als gebakte Screentone-Punkte in den Panel-Schattenzonen. Warmes Key + kühles Rim (accentCool). Flacher Hintergrund, null Verläufe.
6. **PDF-Engine wiederverwendet** (pdf.js + Quadranten-Crop): `page = 2 + floor((n−1)/4)`, `quadrant = (n−1) % 4`. Kapsel 01 = Seite 2 = Karten 1–4. Contain-Fit statt Cover — nie einen Kartentitel abschneiden.

## Tweaks (Props)
`deck` (utopia/dystopia/protopia) · `autoRotate` · `spinSpeed`. Debug-Hooks: `window.__capsule.setYaw(rad)`, `.toggleOpen()`.

## Abnahme (visuell verifiziert per Screenshot, 2026-07-10)
- [x] Kein Text/keine Fläche kopfstehend — 5 Yaws + Ober- und Untersicht
- [x] Weißer Gutter + wobbelige Tusche-Kante gleichzeitig
- [x] Kontinuierliche Öffnen-/Schließ-Transition, orientiert
- [x] Echte PDF-Karten-Crops, voll lesbar
- [x] Cel-Bänder sichtbar, keine Verläufe

## Stufe 2 — Datenströme (Synapsen-Kanten), abgenommen 2026-07-10

1. **Narrative Semantik:** Der Strom des eigenen Decks (Mode-Farbe) taucht von fern kommend ins Deckel-Siegel ein und tritt unten wieder aus — die Kapsel ist ein KNOTEN in ihrem Erzählfluss. Die zwei Geschwister-Ströme (Farben der anderen beiden Trilogie-Decks) bündeln sich magnetisch hinter der Kapsel und ziehen vorbei — Vorgriff auf Stufe 4, ohne sie zu bauen.
2. **Anker auf der Drehachse** (Siegel-Zentrum oben, Boden-Zentrum unten): Yaw kann die Verbindungen prinzipiell nicht bewegen — Aufrecht/Stabilität wieder per Konstruktion.
3. **Synapsen-Bündel, nicht Einzellinie:** Jeder Strom = 5 dünne Filamente, die spiralig um eine gemeinsame Seele rotieren (Parallel-Transport-Frames gegen Basis-Flips an steilen Tauchstrecken), magnetisch gepincht Richtung Kapsel (eng am Siegel, weit in der Ferne). Dazu: Partikel-Funken, die die Spiralen entlangfließen, wandernde Puls-Segmente, sparsamer additiver Glow, Puls-LFO + schnelles Flacker-Schimmern pro Strang. Tiefen-sensible Breite. Kein Tron-Neon.
4. **Datenbälle + Richtungs-Semantik:** Statt Puls-Rechtecken laufen kugelige Datenbälle (Instanced-Sphären, variable Größe, Größen-LFO) wie Perlen durch die Spiralfäden. Kanten-Logik nach Graph-Semantik: eigene Deck-Kanten GERICHTET (rein ins Siegel oben, raus unten), Geschwister-Trunks BIDIREKTIONAL — `dirMode` pro Kante, später vom semantischen Triplet gesetzt. Aktivierung entlang des Flusses: Draw-on vom Ursprung zur Mündung (gestaffelt, ~3s), kein plötzlicher Effekt. Deck-Wechsel startet den Einlauf neu.
5. **Betonungs-Bruch:** Beim Öffnen dimmen die Ströme auf ~28 % — die Umgebung tritt hinter die Karte zurück (Art-Direction §1.4).
6. Tweak: `streams` (an/aus).

**Debug-Lektion (Runtime):** Die Logik-Klasse wird in diesem Projekt NICHT hot-reloadet (älteres support.js) — nach JS-Änderungen immer voll neu laden, sonst verifiziert man alten Code. Zwei gefixte Fallen: Frustum-Culling bei dynamischen BufferGeometries (boundingSphere setzen + frustumCulled=false) und NaN-Propagation beim Opacity-Lerp.

## Offen (bewusst noch nicht gebaut)
Skydome (Stufe 3), Galaxie/Nav (Stufe 4, explorativ). Ideen-Notiz: Papier-Volvelle auf dem Deckel; Screen-Space-Halftone-Pass als zweite Schatten-Ebene; Strom-Aktivierung könnte später Kapsel-Ankunft/Abflug orchestrieren.

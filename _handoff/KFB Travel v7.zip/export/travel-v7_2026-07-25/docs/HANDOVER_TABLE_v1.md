# KFB Table — Handover für Coworker (Stand v1)

**Kontext-Regeln:** https://kayfabizarro.pages.dev/#kfb · Original-Briefing: `uploads/START_HERE_table.md`, `uploads/KFB_MED_3D_Table_Handover_v1.md` (§-Referenzen unten), `uploads/02_OPEN_DECISIONS_resolved.md`.

## Leitfrage
„Wie fühlt sich KayfaBizarro an, wenn es physisch existieren würde?" — Cut-up-Pop-up-Diorama auf einer Schneidematte. **Social Agency, nicht Object Agency** (§10): jede Bewegung ist Interpunktion einer Rede, löst sich auf, kein Fidget. Cue, kein Skript.

## Dateien
- **`KFB Table.dc.html`** — Arbeitsstand (DC-Shell, Tweaks: look/wash/lean/jitter)
- **`kfb-table.js`** — die gesamte Logik: Web-Komponente `<kfb-table>`, three.js 0.160 + pdf.js via CDN (jsdelivr `+esm`)
- **`KFB Table v1.dc.html` + `kfb-table.v1.js`** — eingefrorener v1-Check-in (nicht anfassen)
- **`data/deck_b.json` + `assets/deck_b.pdf`** — Deck B (Dystopia); A/C liegen parallel
- **`assets/models/*.glb`** — CC0/CC-BY-Props (siehe `uploads/ASSETS.md`; Lizenz: pixellabs/plaggy/tilixia/arunangshubanerjee auf CC-BY prüfen)
- **`docs/CHANGELOG.md`** — was v1 kann · **`docs/sprints/03|04|05_*.md`** — die nächsten drei Sprints

## Architektur (kfb-table.js, ~1200 Zeilen, eine Klasse)
- **Boot:** Deck-JSON laden → seeded Shuffle (mulberry32, seed 1207) → actorN/questN/3 Hand → Szene → PDF-Pipeline → Tisch bauen
- **PDF→Textur (§8):** Seite = `coverOffset(1) + 1 + floor((n−1)/4)`, Zelle `(n−1)%4` im 2×2-Grid, weißer Schnittrand 4.5%, Page- und Textur-LRU
- **Karten:** ShapeGeometry mit welligen Kanten/exakten Ecken (wie Ink-Blasen), Front/Back/Ink-Border(cel)/Edges-Outline(Highlight); `_makeCard`/`_stand`/`_layFlat`/`_handPose`
- **Looks:** `_surfMat` liefert Standard (papier) oder Toon+gradientMap (cel); `_applyLookSwap` traversiert live. Cel = keine echten Schatten, stattdessen `_blob`-Kontaktschatten + `_hull`-Inverted-Hull-Outlines (Box: unten bündig; skinned Meshes: kein Hull!)
- **Rituale:** `_drawToHand` `_playFromHand` (Show/Spin/Sell + Overwrite) `_rollStory` (→`_applyWash`, eine mood-Quelle) `_moveQuest` `_questReward` `_questFail` `_enterKaraoke`/`_exitKaraoke`
- **UI-Layer (DOM):** Hover-Tooltip + Karaoke-Blase (Ink-SVG via `_inkify`, Breite nach Messung fixiert — sonst Rand-Rewrap!), Narrator-Box (5 Beats, `_setBeat` = Finger-Rule), HUD-Chips + Verdict-Buttons
- **Nav (§4):** Orbit geclampt (az ±1.1, pol 0.3–1.3, dist 4.2–11), Pan geclampt (±3/±2.2), WASD/Pfeile/QE/Space/Wheel/Touchpad in `_initScene` + `_animate`

## Stolpersteine (gelernt, nicht wiederholen)
1. **Blasen-Breite fixieren** nach Messung (`width = offsetWidth`), sonst rewrappt Text am Viewport-Rand
2. **Hull nie während `traverse` anhängen** (Endlos-Rekursion) und **nie an skinned Meshes** (rendert Bind-Pose = „Flügel")
3. **Würfel-Endlage als Quaternion** komponieren (`_dieQuat` = Welt-Yaw × Face-Euler), nie Euler-Addition
4. **Additive Glow-Planes vermeiden** — maskieren Schatten / wirken buggy; Belohnung = Bewegung + Konfetti + Emissive
5. GLB-Loads **parallel + unabhängig** (`Promise.all` mit catch je Prop), Loader-Promise geteilt

## Offen / Interim
- **Mode-Farben:** 6× ink/panel in `MODES` = Interim aus Rules S.16 → kanonische Hex von der Rules-Seite verifizieren
- **§11.3 Kartenrückseite:** generierter Platzhalter (`backTexture`)
- Hase (FrizzleBob): Ausrichtung geraten, kein Hull; später King-Avatar (Sprint 03 §6)
- Nur Deck B verdrahtet (`DECK_JSON`/`DECK_PDF` Konstanten); Instanz-Test 3 Decks ausstehend
- Kein Sound (Sprint 03 nennt je Ritual einen)

## Nächste Sprints (docs/sprints/)
- **03 Turn-Flow:** kompletter Zug als Choreografie: Draw→Roll→Play→Tell (spieler-getaktete Spotlight-Blase actor▸s1▸s2▸s3▸quest)→Calls→Move; Cartoon-Physics-Vertrag beachten
- **04 Cel-Shading Stufe B:** posterisierte Schatten, licht-gewichtete Outlines (N·L-moduliert), Halftone nur im Schatten-Band, Rim = Mode-Ink
- **05 Studio-Wand:** diegetische Nav — 2 PDF-Viewer (Anti-Rules, Rule-Book; URLs im Doc, Pipeline = Karten-Pipeline wiederverwenden), Parallax-Rahmen (FB-Slideshow, Wanted, Fenster), Fallback-Leiste. Wand erst, wenn der Tisch sauber steht (§8 Phasing)

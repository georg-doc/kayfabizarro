# Design-Brief: v4 — Travel-Modi auf dem WebGL-Terrain (Flug + Boden)

**Ziel:** Auf dem WebGL-Terrain (v3) zwei Reise-Modi, getestet mit dem echten Terrain: **Flug** und
**Boden/Walk**. Der Pet reitet auf einer Karte als Standard-Flugobjekt, alle **24 Pets** wählbar. Später
sollen statt der Karte auch andere 3D-Objekte gehen — das Carrier-Interface bleibt offen.

**Voraussetzung:** v3 (WebGL-Terrain + Skydome) läuft. Travel baut darauf. Die Travel-Module lassen sich
gegen einen einfachen flachen WebGL-Boden **parallel** entwickeln und dann auf v3 setzen.

## 0. Harte Regel (unverändert)
**WebGL, three 0.160** (wie Pet + Terrain-v3). Ein Build, Module über jsdelivr, Daten über raw. Kein
WebGPU/TSL. **Gute Folge:** Pet, Terrain und Reise laufen jetzt im **selben** Motor — der alte
Zwei-Motoren-Konflikt (unsichtbarer Mund/Textur) ist damit erledigt.

## 1. Reuse, NICHT neu erfinden (das Wichtigste)
Die Steuerungen sind bei uns **schon gebaut und ausdefiniert**. Nicht neu schreiben, sondern extrahieren:

- **Flug-Controller** aus **PetFlight v2** (`petflight.v2.js`) — bereits WebGL 0.160. Dragonriding-Modell:
  Maus/Finger gedrückt halten = Dreh-Rate; W/S Schub, A/D Yaw, ↑/↓ Höhe, Space Boost; Pinch/Rad Zoom;
  Follow-Cam mit Pet-POV; Leerlauf gleitet aus. Das ist der Flug.
- **Boden/Walk-Controller** aus **PolyGarden v2** (START_HERE §5): WASD/Pfeile laufen, Maus zieht Kamera,
  Rad zoomt, Space springt, Shift sprintet, Q/E drehen; Touch-Joystick links/Aktionen rechts; Gamepad.
  Das ist der Boden-Modus.

Beide existieren, beide WebGL. Aufgabe = extrahieren, an den Card-Carrier + Pet hängen, auf dem Terrain
laufen lassen.

## 2. Als Module bauen, im Terrain-v4 hosten
Nicht fest in die Terrain-Datei verdrahten. Drei **importierbare** Module, Host = die v4-Szene:

- `flight-controller.js` — Flug-Zustand/Dynamik (aus PetFlight extrahiert).
- `ground-controller.js` — Laufen + Terrain-Follow (Höhe/Normale aus dem Terrain).
- `card-carrier.js` — Pet-auf-Karte samt Kinetik (siehe §4).

So testen wir jetzt auf dem echten Terrain **und** PetFlight/Rollercoaster importieren später dieselben
Module. Kein Doppelbau.

## 3. Die 24 Pets + der Pet
- Pet-Auswahl (Dropdown/Switch), Standard = Uncle FrizzleBob (`bunny`). Pet ausschließlich über den
  kanonischen Stack (`kfb-pets.js`, `makePet`, `attend()`, `pet.update(dt)` einmal/Frame). Keine eigene
  Augen-/Mund-Implementierung.
- Der Pet besitzt **nur** Animation/Ausdruck, **keine** Bewegung (die gehört dem Carrier/Controller).

## 4. Die Karte — Empfehlung: leichtes 3D, kein flaches 2D
Deine drei Optionen, meine klare Empfehlung ist Nummer 3, aber in der **billigen** Form:

- ~~2D-Karte flach~~ → Füßchen stippen durch. Nein.
- ~~Pet über der 2D-Karte schweben~~ → geht, aber unelegant. Nur Notnagel.
- **Leichtes 3D-Objekt (empfohlen):** eine **subdividierte, dünne Platte** — `PlaneGeometry` mit
  Segmenten (z. B. ~10×14) und minimaler Dicke, Karten-Rücken-Textur oben. Der Pet sitzt **auf** der
  Oberseite (kein Durchstippen), und die Segmente erlauben **Teppich-Wabern + Squash/Stretch**, gespiegelt
  vom Pet. Billig, elegant, kinetik-fähig. **Kein über-modelliertes Mesh nötig.**
- Vorhandene Assets: Karten-Rücken-Textur `KayfaBizarro_Card_Backside_01_lowrez.png` (aus PetFlight v2)
  und `KFB_PaperCard_01.glb` (auf GitHub) — den GLB als statischen Look-Kandidaten prüfen; für die
  **Flug-Kinetik** ist die subdividierte Platte aber der kontrollierbare Weg.
- **Karte fährt/fliegt ÜBER Boden bzw. Bahn**, nie mittendrin.

## 5. Steuerung (schon definiert, hier nur zusammengeführt)
- **Tastatur:** Flug W/S·A/D·↑/↓·Space · Boden WASD/Pfeile·Space·Shift·Q/E.
- **Maus/Touchpad:** Flug = Drag-Halten als Dreh-Rate (Dragonriding); Boden = Maus zieht Kamera; Rad/Pinch Zoom.
- **Touch:** Joystick links, Aktionen rechts. **Gamepad:** Stick läuft/dreht, A springt.
- **Modus-Umschalter** Boden ↔ Flug (ein Knopf/Taste). Boden = Pet+Karte folgen der Terrain-Höhe; Flug =
  freier Flug darüber.

## 6. Architektur-Rahmen — vier Docs, nicht fünfzehn
Vom Travel-Konzept nur die **vier** relevanten als Ownership-Vokabular mitgeben: **001 Travel, 002
Vehicle, 003 CardRig, 005 Flight Controller**. Die Kernregeln daraus, die wir übernehmen: *Vehicle besitzt
die Bewegung · Pet nur Animation (nur-lesend, reagiert auf den Zustand, ändert ihn nie) · CardRig ist
visuell · Ground und Flight teilen ein Runtime.*

Die **anderen elf Docs = Referenz/Kontext, kein Bau-Auftrag.** Ausdrücklich: eine **lauffähige Scheibe**
bauen, nicht das ganze Framework abarbeiten. (Sonst entsteht Architektur statt eines fliegenden Prototyps.)

## 7. Reihenfolge (kleinste Scheibe zuerst, jederzeit bootbar)
1. Flacher WebGL-Boden + **Karte + Pet** + **Flug-Controller** (Flug zuerst, wie gewünscht). Fliegt.
2. **Boden/Walk-Controller** + Terrain-Follow. Läuft.
3. Auf **Terrain v3** setzen (echtes Terrain statt flacher Boden).
4. **24-Pet-Auswahl** + Modus-Umschalter Boden↔Flug.
5. **Karten-Kinetik** fein: Wabern + Squash/Stretch gespiegelt vom Pet.

## 8. Verifikation
WebGL rendert in der normalen Vorschau (direkt sichtbar). Jede Scheibe in **Chrome UND Firefox** am Pixel
prüfen, bootbar halten; bricht ein Schritt den Boot, sofort zurück. Anmutung entscheidet Georgs Auge.

## 9. Sparring (erwünscht, in den Regeln)
Eigene Verbesserungen/Red-Team willkommen (z. B. sanftere Modus-Übergänge, bessere Kamera beim Wechsel).
**Nicht verhandelbar:** WebGL 0.160, ein Build, Pet nur über den kanonischen Stack, Reuse der vorhandenen
Controller statt Neubau.

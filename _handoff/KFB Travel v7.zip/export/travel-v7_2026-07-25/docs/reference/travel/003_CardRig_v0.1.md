# 003_CardRig

Version: v0.1 (Living Document)

> Depends on:
>
> -   001_Travel_Architecture
> -   002_Vehicle_Contract

------------------------------------------------------------------------

# Purpose

CardRig is the canonical visual embodiment of a Vehicle.

It defines how a Pet is spatially attached to a Vehicle while remaining
architecturally independent.

CardRig owns presentation only.

It never owns gameplay.

------------------------------------------------------------------------

# Design Philosophy

Travel moves.

Vehicle simulates.

CardRig visualizes.

Pet performs.

Animation reacts.

Every responsibility has exactly one owner.

------------------------------------------------------------------------

# CardRig Position

Travel Runtime

↓

Vehicle

↓

CardRig

↓

Pet

↓

Animation

CardRig is a bridge between Vehicle and Pet.

It is not a gameplay object.

------------------------------------------------------------------------

# Responsibilities

CardRig owns:

-   Seat Transform
-   Attachment Points
-   Visual Pivot
-   Lean Pivot
-   Hover Offset
-   Banking Offset
-   Visual Effects Anchors

CardRig never owns:

-   Physics
-   Movement
-   Input
-   Camera
-   Navigation
-   AI

------------------------------------------------------------------------

# Attachment Model

A Vehicle exposes one or more attachment sockets.

Examples:

-   Driver Seat
-   Passenger Seat
-   Cargo Socket
-   Companion Socket

CardRig maps these sockets to visual transforms.

------------------------------------------------------------------------

# Pet Integration

The Pet attaches to a Seat Transform.

The Pet never queries world position directly.

Instead:

Vehicle

↓

CardRig

↓

Seat Transform

↓

Pet

This guarantees that every vehicle can transport the same Pet runtime.

------------------------------------------------------------------------

# Transform Hierarchy

World

↓

Vehicle Root

↓

CardRig Root

↓

Seat

↓

Pet Root

↓

Pet Skeleton

Vehicle controls the world transform.

CardRig applies visual offsets only.

------------------------------------------------------------------------

# Visual Layers

CardRig may animate:

-   Hover bob
-   Suspension
-   Banking
-   Compression
-   Idle sway
-   Landing reaction

These animations never modify Vehicle physics.

------------------------------------------------------------------------

# Camera Anchor

Camera follows Vehicle.

Optionally CardRig may expose helper anchors:

-   Cockpit
-   Chase
-   Cinematic
-   Dialogue

These are suggestions only.

Camera remains independent.

------------------------------------------------------------------------

# Animation Data

CardRig consumes:

-   Velocity
-   Acceleration
-   Angular Velocity
-   Ground Contact
-   Flight State

CardRig produces:

-   Seat Transform
-   Lean Transform
-   FX Anchors

Pet animation consumes these outputs.

------------------------------------------------------------------------

# Multi-Passenger Support

A Vehicle may expose multiple seats.

Example:

Vehicle

├── Driver

├── Passenger A

├── Passenger B

└── Cargo

Every seat follows the same attachment contract.

------------------------------------------------------------------------

# Future Compatibility

Examples:

-   Skateboard
-   Balloon
-   Spaceship
-   Dragon
-   Minecart
-   Elevator

Each provides attachment sockets.

CardRig remains unchanged.

------------------------------------------------------------------------

# Rules

Rule 1

Movement belongs to Vehicle.

Rule 2

CardRig never owns gameplay.

Rule 3

Pet never owns movement.

Rule 4

Animation never modifies runtime.

Rule 5

Visual offsets never affect simulation.

------------------------------------------------------------------------

# Acceptance Criteria

A CardRig implementation:

✓ transports any Pet

✓ supports arbitrary Vehicles

✓ allows multiple seats

✓ exposes camera anchors

✓ contains no gameplay logic

✓ contains no physics

------------------------------------------------------------------------

# Notes for Sprint 004

Ground Controller will consume Vehicle state only.

CardRig will remain completely unchanged.

This validates the separation between simulation and presentation.

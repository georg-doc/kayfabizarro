# 004_Motion_Controller

Version: v0.1 (Living Document)

> Depends on: - 001_Travel_Architecture - 002_Vehicle_Contract -
> 003_CardRig

------------------------------------------------------------------------

# Purpose

The Motion Controller is the strategy responsible for producing movement
for a Vehicle.

Travel never contains movement logic.

Vehicles delegate movement behaviour to interchangeable Motion
Controllers.

------------------------------------------------------------------------

# Design Principle

Travel coordinates.

Vehicle owns runtime state.

Motion Controller computes movement.

CardRig visualizes.

Pet performs.

------------------------------------------------------------------------

# Why "Motion" instead of "Ground"

Ground movement is only one specialization.

Future implementations include:

-   Ground
-   Flight
-   Rail
-   Boat
-   Climbing
-   Swimming
-   Hover
-   Mounted Animal
-   Car
-   Motorcycle
-   Spaceship

All implement the same controller contract.

------------------------------------------------------------------------

# Runtime Hierarchy

Travel Runtime

↓

Vehicle

↓

Motion Controller

↓

Vehicle State

↓

CardRig

↓

Pet

------------------------------------------------------------------------

# Responsibilities

A Motion Controller owns:

-   acceleration model
-   steering model
-   braking
-   movement constraints
-   terrain response
-   locomotion state

It never owns:

-   camera
-   animation
-   pet
-   rendering
-   UI

------------------------------------------------------------------------

# Controller Contract

Every Motion Controller exposes:

-   initialize()
-   activate()
-   deactivate()
-   update(dt)
-   reset()
-   dispose()

Travel interacts only with this contract.

------------------------------------------------------------------------

# Inputs

Normalized Input

Vehicle State

Surface Data

Runtime Settings

Environmental Triggers

------------------------------------------------------------------------

# Outputs

Updated Vehicle Transform

Velocity

Acceleration

Motion State

Controller Flags

No visual output.

------------------------------------------------------------------------

# Ground Controller

Characteristics:

-   walking
-   running
-   slopes
-   gravity
-   friction
-   steps
-   jumping (optional)

------------------------------------------------------------------------

# Flight Controller

Characteristics:

-   free movement
-   climb
-   descend
-   banking
-   boost
-   glide

No ground assumptions.

------------------------------------------------------------------------

# Mounted Controller

Examples:

-   horse
-   dinosaur
-   giant bird
-   alien creature

Adds gait behaviour while preserving the same interface.

------------------------------------------------------------------------

# Vehicle Controller

Examples:

-   kart
-   car
-   truck
-   motorcycle

Implements traction and steering without changing Travel Runtime.

------------------------------------------------------------------------

# Rail Controller

Examples:

-   minecart
-   train
-   rollercoaster

Movement constrained to a spline or track.

------------------------------------------------------------------------

# Switching Controllers

A Vehicle may switch controllers at runtime.

Examples:

Ground

↓

Flight

↓

Ground

or

Ground

↓

Boat

↓

Ground

State transitions are owned by Vehicle.

------------------------------------------------------------------------

# Rules

Rule 1

Controllers are interchangeable.

Rule 2

Travel knows only the interface.

Rule 3

Vehicles own the active controller.

Rule 4

Controllers never know about Pet.

Rule 5

Controllers never render.

------------------------------------------------------------------------

# Acceptance Criteria

A Motion Controller:

-   can replace another controller
-   updates Vehicle state
-   consumes normalized input
-   exposes no rendering logic
-   supports future locomotion types

------------------------------------------------------------------------

# Sprint 005 Preview

The next document defines the Flight Controller as the first advanced
implementation of the Motion Controller contract.

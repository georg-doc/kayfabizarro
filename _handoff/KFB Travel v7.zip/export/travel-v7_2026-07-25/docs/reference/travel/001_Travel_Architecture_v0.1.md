# 001_Travel_Architecture

Version: v0.1 (Living Document)

> Status: Canonical Architecture Specification Project: KayfaBizarro
> Runtime

------------------------------------------------------------------------

# Purpose

Travel is the universal movement runtime of KayfaBizarro.

It coordinates runtime systems and defines ownership, contracts and
update order. Travel does **not** implement individual vehicles.

------------------------------------------------------------------------

# Working Principles

-   Architecture before implementation.
-   Contracts before code.
-   One runtime for all movement modes.
-   Vehicles encapsulate movement.
-   Pet is transported by vehicles.
-   Animation reacts to runtime state only.

------------------------------------------------------------------------

# Supported Travel Modes

-   Walking
-   Hover
-   Flight
-   Rail
-   Boat
-   Elevator
-   Rollercoaster
-   Future vehicles

Travel does not distinguish these internally. Everything is represented
as a Vehicle.

------------------------------------------------------------------------

# Runtime Layers

Travel Runtime

-   Input
-   Vehicle
-   Surface
-   Camera
-   Pet
-   Animation
-   Rendering

Travel coordinates these systems.

------------------------------------------------------------------------

# Ownership

## Vehicle

Owns:

-   Position
-   Orientation
-   Velocity
-   Steering
-   Collision
-   Physics
-   Ground / Flight behaviour

**Movement belongs exclusively to Vehicle.**

## Pet

Owns:

-   Expressions
-   Bundles
-   Animation
-   Face
-   Idle
-   Dialogue

Pet owns no movement.

## Camera

Observes Vehicle.

## Animation

Consumes runtime state.

Never modifies runtime.

------------------------------------------------------------------------

# Runtime Update Order

1.  Input
2.  Vehicle Simulation
3.  Travel Runtime
4.  Camera
5.  Pet Runtime
6.  Animation Runtime
7.  Rendering

------------------------------------------------------------------------

# Data Flow

Input

↓

Vehicle Intent

↓

Vehicle State

↓

Travel State

↓

Animation State

↓

Pet Animation

One-way only.

------------------------------------------------------------------------

# Runtime States

-   Grounded
-   Hover
-   Flight
-   Docked
-   Locked
-   Disabled

------------------------------------------------------------------------

# Vehicle Contract

Every vehicle implements:

-   initialize()
-   dispose()
-   enter()
-   exit()
-   enable()
-   disable()
-   update(dt)

Travel depends only on this contract.

------------------------------------------------------------------------

# Pet Contract

Pet exposes only:

-   update(dt)
-   attend()
-   bundle()
-   expression()
-   talk()

------------------------------------------------------------------------

# Surface Runtime

Provides:

-   Height
-   Normal
-   Material
-   Water
-   Friction
-   Zone
-   Trigger

Surface never moves entities.

------------------------------------------------------------------------

# Controller Strategy

Controllers are replaceable.

Examples:

-   Ground Controller
-   Flight Controller
-   Hover Controller
-   Rail Controller
-   Boat Controller

Travel owns none of them.

------------------------------------------------------------------------

# Accepted Decisions

D-001 Pet owns no movement.

D-002 Vehicle and Pet are separate runtime objects.

D-003 Animation is read-only.

D-004 Ground and Flight share one runtime.

D-005 CardRig is purely visual.

------------------------------------------------------------------------

# Sprint Result

Sprint 001 establishes the architectural foundation.

Next document:

**002_Vehicle_Contract**

------------------------------------------------------------------------

# Living Document Notes

Future revisions extend this document. Decisions are append-only where
possible. Earlier architectural decisions remain stable unless
explicitly superseded.

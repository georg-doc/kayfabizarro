# 005_Flight_Controller

Version: v0.1 (Living Document)

> Depends on: - 001_Travel_Architecture - 002_Vehicle_Contract -
> 003_CardRig - 004_Motion_Controller

------------------------------------------------------------------------

# Purpose

The Flight Controller is the reference implementation of the Motion
Controller.

It demonstrates how an advanced locomotion mode can be implemented
without modifying the Travel Runtime.

The Flight Controller is intentionally vehicle-agnostic.

The same controller can power:

-   Flying Card
-   UFO
-   Balloon
-   Dragon
-   Jetpack
-   Spaceship
-   Giant Bird

Only the vehicle visuals change.

------------------------------------------------------------------------

# Core Philosophy

Flight is not a special case.

Flight is simply another Motion Controller.

Travel remains unaware of this distinction.

------------------------------------------------------------------------

# Runtime Position

Travel Runtime

↓

Vehicle

↓

Motion Controller

↓

Flight Controller

↓

Vehicle State

↓

CardRig

↓

Pet

↓

Animation

------------------------------------------------------------------------

# Responsibilities

The Flight Controller owns:

-   lift
-   thrust
-   drag
-   banking
-   climb
-   descent
-   boost
-   air steering

It never owns:

-   rendering
-   camera
-   pet
-   animation
-   UI

------------------------------------------------------------------------

# Flight State Machine

Primary states:

Grounded

↓

Takeoff

↓

Flight

↓

Landing

↓

Grounded

Optional states:

Hover

Boost

Glide

Stall

Disabled

Emergency

Each state modifies controller behaviour without affecting Travel.

------------------------------------------------------------------------

# Inputs

Normalized Input:

-   Move
-   Look
-   Ascend
-   Descend
-   Boost
-   Brake

Environment:

-   Wind (optional)
-   Gravity
-   Flight Zones
-   Collision

------------------------------------------------------------------------

# Outputs

Vehicle publishes:

-   Position
-   Orientation
-   Velocity
-   Acceleration
-   Flight State

CardRig and Animation consume these outputs.

------------------------------------------------------------------------

# Flight Characteristics

Vehicle-specific parameters include:

-   Max Speed
-   Cruise Speed
-   Turn Rate
-   Lift
-   Drag
-   Boost Force
-   Hover Stability
-   Vertical Speed

Travel never references these values.

------------------------------------------------------------------------

# Banking

Banking is treated as presentation.

Simulation computes the intended turn.

CardRig visualizes roll.

Pet reacts through animation.

No gameplay depends on visual banking.

------------------------------------------------------------------------

# Hover Behaviour

Hover is implemented as a Flight sub-state.

Characteristics:

-   maintain altitude
-   precise positioning
-   reduced forward velocity

The same implementation works for:

-   Magic Carpet
-   UFO
-   Hover Bike
-   Floating Card

------------------------------------------------------------------------

# Landing

Landing is a transition.

Vehicle requests Ground Controller ownership.

Travel performs no movement logic.

Vehicle remains responsible for state transfer.

------------------------------------------------------------------------

# Controller Transition

Ground Controller

↓

Flight Controller

↓

Ground Controller

or

Ground

↓

Hover

↓

Flight

↓

Landing

↓

Ground

Transitions are explicit and deterministic.

------------------------------------------------------------------------

# Failure Modes

Possible controller events:

-   Collision
-   Stall
-   Out of Fuel (optional)
-   Forced Landing
-   Disabled

These remain controller-level concerns.

Travel remains unchanged.

------------------------------------------------------------------------

# Future Compatibility

The same architecture supports:

-   Space flight
-   Zero gravity
-   Underwater flight
-   Fantasy creatures
-   Multi-engine aircraft
-   Cinematic rails

Only controller implementations differ.

------------------------------------------------------------------------

# Architectural Rules

Rule 1

Travel never contains flight logic.

Rule 2

Vehicle owns the active Motion Controller.

Rule 3

Flight Controller owns movement.

Rule 4

CardRig owns presentation.

Rule 5

Pet owns performance.

------------------------------------------------------------------------

# Acceptance Criteria

A valid Flight Controller:

✓ can replace Ground Controller

✓ supports runtime transitions

✓ exposes standardized vehicle state

✓ contains no rendering

✓ requires no Travel Runtime changes

------------------------------------------------------------------------

# Next Architecture Phase

The movement architecture is now complete.

Recommended next sprint:

006_Runtime_State_Graph

This document should formalize all runtime transitions between Motion
Controllers and define the canonical locomotion state graph for every
future vehicle.

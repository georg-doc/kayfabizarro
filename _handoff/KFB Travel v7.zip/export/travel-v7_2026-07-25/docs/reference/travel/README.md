# Reference — Travel Runtime (v4)

Ownership-Vokabular für den v4-Travel-Bau. **Referenz/Kontext, kein Bau-Auftrag** — es wird eine
lauffähige Scheibe gebaut (Brief §7), nicht das ganze Framework.

## Bau-Auftrag
- `BRIEF_v4_TravelModes.md` — der eigentliche Auftrag (Slice-Reihenfolge, Reuse-Regeln, harte Regeln).

## Kanonisches Ownership-Vokabular (übernommen)
- `001_Travel_Architecture_v0.1.md` — Runtime-Layer, Update-Order, Ownership.
- `002_Vehicle_Contract_v0.1.md` — Vehicle-Lifecycle (initialize/enter/update/exit/dispose), State/Output.
- `003_CardRig_v0.1.md` — CardRig = rein visuell (Seat/Lean/Hover-Offsets), transportiert jeden Pet.
- `004_Motion_Controller_v0.1.md` — Controller-Kontrakt (austauschbar; Ground/Flight teilen Interface).
- `005_Flight_Controller_v0.1.md` — Flug als erste Motion-Controller-Referenz.

## Kernregeln (nicht verhandelbar)
1. **WebGL, three 0.160.** Ein Build, Module über jsdelivr, Daten über raw. Kein WebGPU/TSL.
2. **Vehicle besitzt Bewegung.** Pet nur Animation (read-only, ändert Runtime nie).
3. **CardRig rein visuell.** Keine Physik/Gameplay.
4. **Ground + Flight teilen ein Runtime.**
5. **Reuse statt Neubau:** Flug aus PetFlight v2, Boden aus PolyGarden v2, Pet über kanonischen Stack.

## Die anderen ~11 Travel-Docs
Referenz/Kontext, ausdrücklich KEIN Bau-Auftrag. Nicht hier abgelegt, bis konkret gebraucht.

# 002_Vehicle_Contract

Version: v0.1 (Living Document)

> Depends on: 001_Travel_Architecture

------------------------------------------------------------------------

# Purpose

This document specifies the runtime contract that every vehicle in the
KayfaBizarro Travel Runtime must implement.

Travel never depends on concrete vehicle implementations. It depends
only on this interface.

------------------------------------------------------------------------

# Design Goals

A Vehicle must:

-   encapsulate movement
-   expose a stable lifecycle
-   hide implementation details
-   be replaceable at runtime

------------------------------------------------------------------------

# Responsibilities

A Vehicle owns:

-   Position
-   Orientation
-   Velocity
-   Steering
-   Collision
-   Physics
-   Runtime state

A Vehicle never owns:

-   Pet animation
-   Camera logic
-   Rendering
-   UI

------------------------------------------------------------------------

# Lifecycle

initialize()

Creates internal runtime resources.

------------------------------------------------------------------------

enter()

Vehicle becomes active.

Acquire input if required.

------------------------------------------------------------------------

update(dt)

Runs one simulation step.

Called once per frame.

------------------------------------------------------------------------

exit()

Releases runtime ownership.

------------------------------------------------------------------------

dispose()

Destroys runtime resources.

------------------------------------------------------------------------

# Runtime State

Every vehicle exposes:

-   enabled
-   active
-   grounded
-   hovering
-   flying
-   locked
-   velocity
-   orientation
-   position

State should be readable but modified only by the vehicle itself.

------------------------------------------------------------------------

# Commands

Supported commands include:

-   enable()
-   disable()
-   stop()
-   reset()

Travel may invoke commands but does not implement them.

------------------------------------------------------------------------

# Input Contract

Vehicles receive normalized input.

Examples:

-   Move Vector
-   Look Vector
-   Action Buttons
-   Boost
-   Brake

Input devices are abstracted away before reaching the vehicle.

------------------------------------------------------------------------

# Output Contract

Vehicles publish:

-   Transform
-   Motion State
-   Runtime State
-   Surface Contact

These outputs drive camera, pet and animation.

------------------------------------------------------------------------

# Interaction with Pet

Vehicle transports Pet.

Pet never modifies Vehicle state.

Communication is one-way.

Vehicle → Pet

------------------------------------------------------------------------

# Interaction with Camera

Camera observes:

-   Position
-   Orientation
-   Velocity

Camera never owns movement.

------------------------------------------------------------------------

# Interaction with Surface

Vehicle queries Surface for:

-   Height
-   Material
-   Normal
-   Trigger
-   Zone

Surface provides information only.

------------------------------------------------------------------------

# Extensibility Rules

New vehicle types must not require changes to Travel Runtime.

Examples:

-   Card
-   Balloon
-   Boat
-   Train
-   Spaceship
-   Rollercoaster

Each is a Vehicle implementation.

------------------------------------------------------------------------

# Acceptance Criteria

A valid vehicle:

-   can be activated
-   can be updated
-   can be disabled
-   publishes runtime state
-   does not expose implementation details
-   transports Pet without coupling

------------------------------------------------------------------------

# Open Questions (Sprint 003)

-   CardRig attachment model
-   Seat definition
-   Multiple passengers
-   Vehicle transitions
-   Animation event hooks

# HANDOVER — KFB Comic Cube v3+ („Die Reise", MVP 1)

> Übergabe an einen frischen Design-Chat, 2026-07-15. Diese Datei ist **nur ein Verweis-Blatt**,
> kein neues Briefing. Sie zählt bewusst NICHT als Modell- oder Plan-Dokument (Briefing-Disziplin
> LEAD_PLAN §4: EIN MASTER + EIN Plan, sonst nichts). Lies die verlinkten SSOTs, nicht diese Prosa.

---

## 0 · Was gebaut wird (ein Satz)

Die **Diorama-Box (Infinite Comic)** mit **sauber animiertem FrizzleBob-Pet-Cube** — die nächste
Version des Comic-Cube-Strangs, entlang der bereits beschlossenen Stufen bis MVP 1.

---

## 1 · Pflicht-Kontext — GENAU diese Dateien, nicht mehr (LEAD_PLAN §4)

1. **`uploads/MASTER_infinite_comic.md`** — SSOT fürs Modell (Raumform, Slots, Gutter, §5 Karten-Mapping, §6 Timeline, §9 LRU, §10 Abnahme-Kriterien).
2. **`uploads/LEAD_PLAN_MVP1.md`** — SSOT für den Fahrplan (Stufen 2b–6, MVP-1-Definition, Nicht-Ziele, Delegation). Bei Konflikt mit MASTER gilt der Plan.
3. **`CLAUDE.md`** — SSOT für Datei-Status + autoritatives UI-Kit (Palette/Fonts/Schatten/Buttons).
4. **die aktuelle Engine-Datei des Strangs** — siehe §2 (LINEAGE unbedingt zuerst klären).

> Alles andere unten ist **Referenz** (bei Bedarf ziehen), nicht Pflicht-Kontext.

---

## 2 · ⚠ ZUERST KLÄREN — Datei-Lineage (blockierend)

Der LEAD_PLAN ist gegen **`infinite-journey.v1.js`** + **`MASTER_infinite_comic.md`** geschrieben.
**Beide liegen in diesem Projekt („Georg's Infinite Canvas") aktuell NICHT.** Hier existiert der
Diorama-Strang als **`comic-cube.v2.js`** + **`KFB Diorama Box.dc.html`**.

Bevor ein Pixel gebaut wird, EINE Frage an Georg beantworten:

- Ist **`comic-cube.v2.js` dieselbe Linie wie `infinite-journey.v1.js`** (umbenannt/kopiert), oder
  zwei parallele Stränge?
- Falls der Plan-Strang (`infinite-journey.v1.js` + `MASTER`) der gültige ist: **diese Dateien in
  den neuen Chat hochladen**, dann darauf bauen.
- Falls `comic-cube.v2.js` gültig ist: LEAD_PLAN-Referenzen mental auf diese Datei mappen und im
  Plan die Datei-Namen korrigieren (Version hochzählen, §4).

**Nicht auf einer Vermutung losbauen.** Parallel-Datei-Verwirrung war die Wurzel des
Card-Viewer-v1-Desasters (siehe `docs/CARD_VIEWER_POC_v1_POSTMORTEM.md`, RC-1/RC-5).

---

## 3 · Stand & nächster Schritt (aus LEAD_PLAN §1/§3)

- Stufe 1 (Strich) + Stufe 2 (Pet-Idle) **gebaut**, Pixel-Frames geliefert.
- **Erste Handlung: Georg bestätigt 1+2 formal (Sign-off) oder nennt Mängel.**
- **Nächster Bauschritt: Stufe 2b — Rotations-Reaktion des Pets** (Kachel dreht unter dem Pet weg →
  Antizipation, Sprung mit Stretch/Squash/Overshoot/Landung; horizontal & vertikal; kein Input
  bleibt stumm). Abnahme: 3 Frames.
- Dann 3 (Zugbrücke/Durchtritt/Gummileinen-Kamera) → 4 (Rückklappen/180°/Ankunft) → **Freeze,
  Weiterbau als v2** → 5 (echte Karten, PDF-Pipeline) → 6 (Erzähl-Naht, ein `claude.complete`).

---

## 4 · Regeln, die Regressionen verhindern (LEAD_PLAN §5)

1. **Pixel-Capture-Abnahme je Stufe**, Frame-Sequenzen bei Bewegung (`captures/stufeN/`), Sign-off abwarten. Nie Scene-Graph-Zahlen.
2. Ein Modell, kein Kompromiss-Patchen. Widersprüche in Runde 1 eskalieren, nicht flicken.
3. Pet per **Contract-URL** (`pet-LIBRARY.json` v0.2.0), nie hardcoden. v3-Look (Clay + Sphere-Eyes).
4. Eingecheckte Versionen einfrieren, Weiterbau als neue Datei.
5. Assets per **GitHub-raw**, nichts Schweres ins Projekt.
6. **Social Agency, kein Idle-Fidget. Wonky, nicht Casino.** Animation = Interpunktion, löst sich in Ruhe auf.
7. WebGL2 (kein WebGPU/TSL). Verifikation prüft Bewegung, nicht Endzustände (RC-4).

---

## 5 · Referenz (bei Bedarf, KEIN Pflicht-Kontext)

- **Ink-Kanten-Look:** `kfb-ink.js` (Repo-Root, dependency-free Modul) + `docs/KFB_INK_OUTLINE_STYLE_v1.md`
  (volle Spec) + interaktiv `KFB Ink Outline Spec.dc.html`. → Die Cube-Panels sollten aus `kfb-ink.js`
  inken statt einer eigenen Kopie im Engine-File. **§8 der Spec = Proposal für 3D-Cel-Ink am Pet**
  (Inverted-Hull pro Objektklasse, Breite = N·V + Distanz) — Kandidat für den Pet-Look, nicht Pflicht.
- **Karten-Bergung für Stufe 5/6** (Pipeline, Pool-Regeln, Registry): `comic-viewer.v1.js` /
  `card-viewer.v1.js` + `v6/docs/index.json` (Multi-Deck-Registry, GitHub-raw). Nichts neu erfinden.
- **Warum-nicht-so:** `docs/CARD_VIEWER_POC_v1_POSTMORTEM.md` (die teuren Fehler, damit sie sich nicht wiederholen).
- **Layer Zero** für jeden erzeugten Text (Stufe 6): `uploads/01_LAYER_ZERO_canon.md`.

---

## 6 · Delegation (LEAD_PLAN §4)

- **Stufe 2b–4 im sorgfältigen Chat bauen** (Animations-Handwerk, viele Geschmacks-Entscheidungen — daran sind zwei billigere Anläufe gescheitert).
- **Stufe 5–6 delegierbar** (mechanisch, klare Contracts, Bergungs-Code existiert): frischer Chat oder Opus, mit exakt den vier Pflicht-Dateien aus §1.

---

## 7 · Upload-Liste für den neuen Chat (falls Dateien fehlen)

Wenn im Ziel-Chat/Projekt nicht vorhanden, diese hochladen — **in dieser Reihenfolge**:

1. `uploads/MASTER_infinite_comic.md`  ← **Pflicht, prüfen ob vorhanden**
2. `uploads/LEAD_PLAN_MVP1.md`  ← vorhanden
3. `CLAUDE.md`  ← **Pflicht, prüfen ob vorhanden**
4. die gültige Engine-Datei: `infinite-journey.v1.js` **oder** `comic-cube.v2.js` (+ zugehörige `.dc.html`) ← nach §2-Klärung
5. `pet-LIBRARY.json` (v0.2.0) + zugehörige Pet-Assets-URLs ← für den Pet-Contract
6. (Referenz) `kfb-ink.js` + `docs/KFB_INK_OUTLINE_STYLE_v1.md`
7. (Referenz, für Stufe 5+) `comic-viewer.v1.js` / `card-viewer.v1.js` + `v6/docs/index.json`

Punkte 1 und 3 sind die wahrscheinlichsten Lücken — bitte zuerst prüfen.

# Cartoon Motion Bible · 03 · Browser/WebGL-Implementierung

> Kanonische Quelle (bereinigt). Prinzipien -> Three.js/WebGL-Mechanik, State-Machine, Layering, Performance. Index: `docs/CARTOON_MOTION_BIBLE.md`.
> NB: Einige Formeln waren im Export zeilenweise zerbrochen; die kanonische Kurzform steht im Bible-Index (§Formeln).

**Computational Mechanics of Browser-Based 3D Cartoon Animation: An Architecture for Performant WebGL Motion Libraries**  
Developing expressive, non-photorealistic 3D motion for browser-based applications requires a rigorous synthesis of classical Disney animation principles, digital interface motion design, game-engine state mechanics, and the technical constraints of WebGL and WebGPU rendering pipelines. While film-based pipelines compute motion offline with virtually unlimited geometric and rendering budgets, interactive browser experiences must execute complex skeletal deformations, facial morphing, and procedural physics within a highly constrained frame budget of 16.67 milliseconds (for 60Hz displays) or 6.94 milliseconds (for 144Hz displays) across a vast spectrum of consumer hardware.  
This research report establishes an authoritative, production-ready framework for implementing a reusable 3D cartoon motion library. It details how to translate stylized kinematics into high-performance WebGL code, resolve the technical conflicts inherent in browser-based animation engines, and construct robust, lightweight assets that bypass the uncanny valley.  
--------------------------------------------------------------------------------  
**The Physics of Organic Motion vs. Robotic Interpolation**  
The primary differentiator between organic, expressive animation and robotic, mechanical movement is the behavior of velocity and structure during transitions. Robotic motion is characterized by linear mathematical interpolation (LERP), which maintains a constant velocity between keyframes and ignores the physical implications of mass, gravity, momentum, and material elasticity. Living tissues and stylized cartoon bodies do not move at constant velocities; instead, they continuously deform, anticipate actions, display internal structural delays, and follow curved spatial trajectories to communicate weight and physical presence.  
To systematize these characteristics for real-time WebGL engines, classical animation principles must be translated into explicit mathematical transformations and programmatic instructions.  
--------------------------------------------------------------------------------  
**Core Animation Principles Translated to 3D WebGL**  
Implementing cartoon physics inside a 3D browser scene requires mapping the twelve classical animation principles directly onto skeletal bone matrices, morph targets, and GPU vertex shaders. Below is an exhaustive breakdown of the primary principles required for a functional motion library.  
**Squash and Stretch (Volume Preservation)**

* **Plain-Language Explanation**: Squash and stretch is the deformation of an object's structure in response to external forces or self-propelled acceleration while maintaining its original volume. When an object compresses vertically, it must bulge outward horizontally; when it stretches vertically, it must contract horizontally, demonstrating that the object possesses a constant mass that cannot be created or destroyed.  
* **Practical WebGL Implication**: If a 3D mesh is scaled along its vertical local *Y*-axis without corresponding scale alterations along the *X*- and *Z*-axes, it appears to unnaturally gain or lose mass, breaking physical believability. The system must dynamically compute inverse scaling transformations on the transverse axes. For bone-driven rigs, scaling must be applied to the local joint matrices. For high-performance, GPU-driven installations, the volume-preserving scale can be computed directly in the vertex shader.  
* **Checklist of Best Practices**:  
  * [ ] Calculate transverse scaling factors using the volume-preservation formula: *S*  
  * *x*  
  * ​  
  * =*S*  
  * *z*  
  * ​  
  * =1/  
  * *S*  
  * *y*  
  * ​  
  *   
  * ​  
  *.  
  * [ ] Ensure the rig's root bone or deformation controllers scale relative to a ground contact pivot rather than the geometric center of the mesh to prevent the character from floating off the ground.  
  * [ ] Ensure the modeling pipeline produces a clean, manifold topology with duplicate vertices removed to prevent splitting or tearing during extreme deformation.  
* **Common Mistakes**:  
  * Scaling only one axis (e.g., *S*  
  * *y*  
  * ​  
  * =1.0, while *S*  
  * *x*  
  * ​  
  * =*S*  
  * *z*  
  * ​  
  * =1.0), which makes the mesh look like paper or an expanding balloon.  
  * Allowing bone scaling to inherit down the hierarchy without clamping, causing distal joints like fingers and toes to deform into needle-like shapes.  
* **Example States/Loops**: The contact impact of a **bounce** loop, or the liftoff frame of a **hop** action.

**Anticipation**

* **Plain-Language Explanation**: Anticipation is the preparation for an action. It involves a physical movement in the direction opposite to the intended main vector, which serves to accumulate energy and visually signal to the audience that a major action is about to occur.  
* **Practical WebGL Implication**: Anticipation must be coded into the transition mechanics of the state machine. Before executing a fast, one-shot programmatic action (like a jump), the system must play a brief, high-velocity preparatory animation (such as crouching down). The timing of this transition is controlled by non-linear easing functions that compress the time step before launching the main action.  
* **Checklist of Best Practices**:  
  * [ ] Use ease-in-out cubic or back-easing functions (which overshoot the initial boundary) to programmatically transition bone angles.  
  * [ ] Scale the duration of the anticipation phase inversely to the speed of the main action to keep the overall motion snappy.  
  * [ ] Pair skeletal contraction with a subtle volume-preserving squash during the lowest point of the anticipation phase.  
* **Common Mistakes**:  
  * Transitioning directly from an idle state to a high-velocity action state with a zero-length blend time, which makes the character appear to teleport or jerk mechanically.  
  * Over-lengthening the anticipation phase, which introduces lag into interactive input responses.  
* **Example States/Loops**: The downward crouch preceding a **hop** or a **jump**, or the winding back of the shoulders before a **hit-react**.

**Arcs**

* **Plain-Language Explanation**: Natural organic movements follow curved trajectories, or arcs, rather than straight, linear pathways. Mechanical components move along straight lines, whereas joints, muscles, and limbs rotate around skeletal pivots, creating curvilinear motion paths.  
* **Practical WebGL Implication**: Spatial translations of characters and props must be calculated using curved paths. Instead of translating vectors linearly over time, the coordinate updates must be interpolated using quadratic or cubic Bézier curves, or Hermite/Carmull-Rom splines. For bone rotations, spherical linear interpolation (SLERP) must be enforced over linear Euler transitions to prevent mechanical rotational artifacts and maintain smooth arcs.  
* **Checklist of Best Practices**:  
  * [ ] Store bone rotations as Quaternions and perform transitions using *SLERP* calculations.  
  * [ ] Track translational movement paths using multi-point splines inside the coordinate update loop.  
  * [ ] Calculate the trajectory height of a jump or throw using parabolic gravitational equations to ensure natural physical deceleration at the apex of the arc.  
* **Common Mistakes**:  
  * Animating spatial translations (*X*,*Y*,*Z*) using linear keyframe tracks, which creates sharp, angular corner transitions.  
  * Using Euler angles to interpolate rapid rotations, resulting in gimbal lock or visual snapping.  
* **Example States/Loops**: The flight phase of a **hop** or **jump**, or the looping swing trajectory of a **floating** object.

**Timing and Spacing**

* **Plain-Language Explanation**: Timing is the duration of an action (the number of seconds or frames it takes), while spacing is the positioning of the object within those frames. Spacing defines the acceleration and deceleration profile of the motion, communicating the weight, scale, and resistance of the moving object.  
* **Practical WebGL Implication**: Timing must be completely detached from the rendering frame rate. Spacing must be implemented using mathematical easing curves that map linear time increments to non-linear physical positions, ensuring that characters slow down as they approach a pose (ease-out) and accelerate as they leave it (ease-in).  
* **Checklist of Best Practices**:  
  * [ ] Normalize the animation progress variable (*t*=elapsedTime/totalDuration) and clamp it strictly between 0.0 and 1.0.  
  * [ ] Pass the normalized *t* variable through an easing function, such as a quadratic ease-in-out:  
  * *f*(*t*)={  
  * 2*t*  
  * 2  
  * −1+(4−2*t*)*t*  
  * ​  
  * if *t*<0.5  
  * if *t*≥0.5  
  * ​  
  *  
  * [ ] Scale all procedural velocity variables by the high-precision delta time (Δ*t*) calculated per frame.  
* **Common Mistakes**:  
  * Hardcoding movement increments per frame (e.g., *x*+=0.1), which causes animations to run at double speed on 120Hz displays and half speed on laggy mobile screens.  
  * Overusing linear spacing, which deprives the character of a sense of physical weight and mass.  
* **Example States/Loops**: The slow-down phase of a **landing** state, or the rapid acceleration phase of a **turn** transition.

**Follow-Through and Overlapping Action**

* **Plain-Language Explanation**: Follow-through is the principle that loosely connected parts of a body continue moving along the original vector even after the main body has stopped. Overlapping action represents the offset timing of different skeletal zones: the pelvis moves first, followed by the torso, head, limbs, and finally secondary attachments like ears, tails, and hair.  
* **Practical WebGL Implication**: To prevent a character rig from stopping in a single, rigid frame, developers must programmatically apply rotational and positional offsets to secondary bones. This can be implemented using second-order spring equations or by structuring skeletal chains with explicit phase delays down the bone hierarchy.  
* **Checklist of Best Practices**:  
  * [ ] Structure the skeleton so that appendages (ears, tails, clothing) are deep child nodes of the primary kinetic joints (hips, chest, head).  
  * [ ] Apply a phase delay factor (*ϕ*=0.15 seconds) to the rotation tracks of distal joints in a tail or ear chain.  
  * [ ] Implement a dynamic spring-damping algorithm to drive the secondary bones in real time, referencing the acceleration vectors of their parent nodes.  
* **Common Mistakes**:  
  * Keyframing all bones to stop moving on the exact same frame, resulting in a sudden freeze-frame effect.  
  * Omitting overlapping delays on large appendages, which makes them look rigid and metallic rather than soft and organic.  
* **Example States/Loops**: The settling ears during a **landing** transition, or the undulating wave of a tail during an **idle** loop.

**Exaggeration**

* **Plain-Language Explanation**: Exaggeration is the intentional distortion of physical reality (such as proportions, velocities, and expressions) to amplify the emotional clarity, dramatic impact, or comedic effect of a performance. It does not mean making the motion random; rather, it means amplifying the essential physical forces acting on an object.  
* **Practical WebGL Implication**: Programmatic variables controlling skeletal scale, rotation limits, or morph target intensities must be configured to overshoot physical boundaries during peak transitions before settling into stable resting values. This overshoot must be carefully clamped in WebGL to prevent vertex skinning values from exceeding standard device floating-point precisions or causing self-penetration of the mesh.  
* **Checklist of Best Practices**:  
  * [ ] Define explicit maximum and minimum boundary envelopes for skeletal scaling and rotational limits to prevent mesh clipping.  
  * [ ] Implement an overshoot elasticity parameter in the blending interpolant to allow the mesh to briefly snap past its destination pose before returning.  
  * [ ] Keep the duration of exaggerated poses extremely short (1 to 3 frames at 60fps) so that the extreme distortion is "felt" as kinetic energy rather than viewed as a deformed model.  
* **Common Mistakes**:  
  * Maintaining an exaggerated, deformed state for too long, which results in the model appearing broken or poorly modeled.  
  * Allowing uncontrolled procedural transformations to drive bone coordinates, which can lead to floating-point overflow or mesh self-penetration.  
* **Example States/Loops**: The extreme stretch during a fast **movement** dash, or the facial expansion of a **celebration** pose.

**Legibility at Small Scale**

* **Plain-Language Explanation**: Legibility is the ease with which a viewer can immediately read and comprehend a character's pose, direction, and action. In digital design, this is critical when a character is rendered at a very small resolution on a screen, such as a mobile device or a zoomed-out isometric game viewport.  
* **Practical WebGL Implication**: Minor skeletal details or micro-scale animations become completely invisible and turn into low-frequency visual noise when rendered at small scales. Motion must be simplified and exaggerated, with a heavy emphasis on clear, readable silhouettes. Unnecessary bones (like fingers or individual hair strands) should be culled or locked, and primary joint movements must be projected along wide spatial angles.  
* **Checklist of Best Practices**:  
  * [ ] Evaluate the character's silhouette by rendering the model with a flat, unlit black material against a high-contrast background to verify that the pose remains understandable.  
  * [ ] Amplify joint rotation amplitudes by 15% to 30% when the camera's field of view is wide or distance is high.  
  * [ ] Implement distance-based Level of Detail (LOD) systems that swap complex, multi-joint skeletons for simplified, low-bone-count rigs at high distances.  
* **Common Mistakes**:  
  * Incorporating micro-movements (such as individual finger curls or subtle eye twitches) on characters that occupy less than 200 pixels of screen space.  
  * Overlapping limbs directly in front of the character's torso, which destroys the legibility of the silhouette.  
* **Example States/Loops**: The wide, clear silhouette of a **celebrate** loop or a **hit-react** animation.

--------------------------------------------------------------------------------  
**Interactive Motion Design: Film vs. Real-Time Web**  
When targeting the web browser as the primary rendering engine, the animator and developer must discard the linear, frame-locked assumptions of traditional filmmaking. The core challenges of browser-based animation stem from interactive latency, screen real estate, variable hardware rendering capacities, and the danger of "over-animating".  
**Performance vs. Aesthetics: Snappiness and Over-Animating**  
In a WebGL game or interactive interface, responsiveness is the single most critical UX metric. If a user clicks a button to make a character jump, they expect immediate physical feedback. In film, a jump transition can afford 10 to 15 frames of slow, anticipatory build-up. In an interactive application, a 15-frame delay between input and action creates a sluggish, unresponsive experience.  
To keep motion snappy and performant, developers must implement the "Action-Reaction" delay curve:  
[User Input Triggered]  
  │  
  ├─► Frame 1-2: Instant Visual Cue (Squash, Particle, or Scale Shift)  
  │     └─► Immediate interactive confirmation  
  │  
  ├─► Frame 3-8: Fast, Compressed Anticipation Phase  
  │     └─► Built-in energy accumulation  
  │  
  └─► Frame 9+: Main Action Released (Extreme Velocity Arc)

This structural timing provides immediate responsive feedback (Frame 1\) while still preserving the physical logic of anticipation (Frames 3-8).  
Over-animating is the common mistake of adding excessive keyframes or continuous skeletal updates to every bone on every frame. This clutters the CPU with redundant interpolation calculations and bloats asset sizes, leading to long initial loading times and performance degradation. The animation engine should only update bones that are actively contributing to the immediate silhouette of the character.  
--------------------------------------------------------------------------------  
**Loopable States, One-Shot Clips, and Transitions**  
Managing the transitions between looping states (e.g., *idle*, *walk*, *run*) and dynamic, one-shot action clips (e.g., *hit-react*, *celebrate*) is the responsibility of the runtime animation state machine.  
**Loop Blending and Transition Mathematics**  
When transitioning from a *walk* to an *idle* loop, the animation engine must blend the bone coordinates smoothly over a defined time interval to prevent physical snaps. The standard approach in WebGL engines is linear weight blending, where the influence weight of the active state (*W*  
*A*  
​  
) decreases linearly from 1.0 to 0.0, while the target state's weight (*W*  
*B*  
​  
) increases from 0.0 to 1.0.  
However, linear blending causes a physical flat spot during the middle of the transition, where both animations contribute only half of their rotational force, making the character look limp or floaty. To resolve this, developers must implement a custom non-linear weighting system using sinusoidal or ease-in-out interpolation curves:

*W*

*B*

​

(*t*)=3*t*

2

−2*t*

3

*W*

*A*

​

(*t*)=1−*W*

*B*

​

(*t*)

This curve ensures that the transition begins and ends gently, maintaining a high total rotational tension throughout the blend period.  
**Turn Transitions and Coordinate Isolation**  
One of the most complex transitions in interactive 3D is the *turn* state. If a character transitions from a forward-facing run to a reverse-facing run, simply blending the bone rotations will cause the model to rotate in place like a spinning top, producing unnatural foot sliding.  
To resolve this conflict, the system must isolate the character's root gameplay coordinates from the internal animation tracks. Root Joint Translation—the physical forward movement baked into an animation clip—must be stripped or neutralized upon import to prevent the model from drifting away from its actual logical collision boundaries. The technical artist can strip the global translation track programmatically on load:  
// Neutralize root translation to isolate coordinate space  
function stripRootTranslation(gltfModel) {  
    gltfModel.animations.forEach(clip => {  
        // Find and remove translation tracks targeting the Root or Hips bone  
        clip.tracks = clip.tracks.filter(track => {  
            const isRootTranslation = track.name.includes("Root.position") ||   
                                      track.name.includes("Hips.position");  
            return !isRootTranslation;  
        });  
        clip.resetDuration();  
    });  
}

Stripping root translation isolates coordinate space, allowing the engine controller to drive the model's container position programmatically via physical equations while the animation system handles the skeletal leg-swing animations.  
--------------------------------------------------------------------------------  
**Multi-Layer Animation Rig & Layering Architecture**  
To support a complex, highly expressive cartoon character without generating hundreds of unique, high-weight file assets, developers must design a modular, multi-layer skeletal and morph target rig.  
                [ SkinnedMesh / Rig Root ]  
                             │  
     ┌───────────────────────┼───────────────────────┐  
     ▼                       ▼                       ▼  
[Layer 0: Locomotion]   [Layer 1: Action]      [Layer 2: Procedural]  
 - Idle Loop             - Wave Gesture         - Eye Tracking (lookAt)  
 - Run Cycle             - Tool Strike          - Blink/Saccades  
 - Walk Cycle            - Hit Reaction         - Dynamic Hair Jiggle  
 (Full Body Bones)       (Upper Body Mask)      (Head/Eye/Appendage Bones)

**Direct Bone Masking via blender-to-GLTF Pipeline**  
By default, playing an animation action in Three.js affects the entire skeleton, overwriting all bone states. To run a locomotion cycle on the legs while playing a localized action on the chest and arms, the system must filter which bones are influenced by specific animation tracks.

1. **Blender Export Constraints**: During export from Blender to GLB, the technical artist must uncheck "optimize animation -> force keeping channels for bones". When checked, this setting bakes redundant static transform channels into every bone for every action, preventing the WebGL engine from separating them. Unchecking this ensures that only actively animated bones are exported with keyframes.  
2. **Runtime Track Splicing**: Once the asset is loaded in WebGL, the system can clone the animation clip and filter out tracks that do not belong to the target bone mask, preventing conflicts:

// Filter tracks to isolate lower body from upper body  
const upperBodyBones = ["Spine", "Neck", "Clavicle_L", "Shoulder_L", "Hand_L", "Clavicle_R", "Shoulder_R", "Hand_R"];  
const lowerBodyBones = ["Hips", "Thigh_L", "Calf_L", "Foot_L", "Thigh_R", "Calf_R", "Foot_R"];

function applyBoneMask(clip, allowedBones) {  
    const maskedClip = clip.clone();  
    maskedClip.tracks = maskedClip.tracks.filter(track => {  
        const parsed = THREE.PropertyBinding.parseTrackName(track.name);  
        return allowedBones.includes(parsed.nodeName);  
    });  
    maskedClip.resetDuration();  
    return maskedClip;  
}

**Morph Target Hierarchies and Weight Clamping**  
For facial expressions and dialogue, morph targets (blendshapes) are highly effective because they deform the mesh at the vertex level without requiring high skeletal density. However, because morph target translations are linear, combining multiple high-intensity shapes can result in unnatural additive stretching.  
To prevent structural clipping, morph targets must be grouped into a priority hierarchy. Eyelid blinks must take precedence over emotional expressions; when a full blink is triggered, the engine must temporarily clamp or suppress the weighting of surrounding eyebrow or cheek morphs to prevent the skin from clipping through the eyeball geometry.  
--------------------------------------------------------------------------------  
**Procedural Control & Avoiding the Uncanny Valley**  
The uncanny valley represents a severe dip in a viewer's emotional connection to a character, triggered by mechanical imperfections in an otherwise human-like or expressive asset. To keep stylized web avatars feeling alive and appealing, developers must focus on three primary procedural vectors: micro-motions, natural eye behaviors, and proportional neoteny.  
**Dynamic Eye Saccades and Gaze Clamping**

* **Saccades**: Human eyes do not pivot smoothly when observing their surroundings. Instead, they execute quick, jerky, high-frequency adjustments (saccades) to continuously center their gaze on target features. A character whose eyes remain perfectly static during fixation looks mechanical or dead. To implement procedural saccades, developers should apply minor, randomized quaternion offsets to the eye bones at randomized intervals (every 0.8 to 2.4 seconds):

// Procedural eye saccade generator  
function generateSaccade(leftEyeBone, rightEyeBone) {  
    const amplitude = 0.04; // Radians  
    const randomAngleX = (Math.random() - 0.5) \* amplitude;  
    const randomAngleY = (Math.random() - 0.5) \* amplitude;

    // Apply synchronized rotations to both eyes to maintain binocular alignment  
    leftEyeBone.rotation.set(randomAngleX, randomAngleY, 0);  
    rightEyeBone.rotation.set(randomAngleX, randomAngleY, 0);  
}

* **Gaze Clamping**: When tracking an interactive target (such as the mouse pointer), the rotation of the neck and eyes must be physically clamped to prevent unnatural, disjointed joint configurations. The eyes must be clamped to ±30  
* ∘  
*  horizontally and ±20  
* ∘  
*  vertically. If the target coordinates exceed this visual envelope, the system must blend the tracking target into the head and neck bones to turn the entire head, maintaining natural skeletal coordination.

**The "Unscalable Uncanny Wall" and Atypical Realism**  
The "unscalable uncanny wall" is a phenomenon where our capacity to detect geometric and behavioral flaws accelerates rapidly alongside graphical fidelity. If a character features hyper-realistic skin textures, subsurface scattering, or detailed hair, the viewer's brain switches from "cartoon mode" to "human identification mode". Under human identification mode, even a single-frame delay in lip-sync or a minor physical slip in bone weighting triggers discomfort and revulsion.  
To safely bypass the uncanny valley in WebGL, developers must enforce the following guidelines:

* **Consistently Abstract Realism**: Match low-poly, stylized geometry with flat, illustrative, or cel-shaded materials rather than realistic, physically-based shaders. A stylized biped rendered with a flat `MeshToonMaterial` is highly appealing, whereas the same geometry combined with a highly detailed PBR skin texture looks unsettling.  
* **Leverage Neoteny**: Emphasize neotenous, childlike physical proportions—such as large, widely spaced eyes, a round head shape, a small chin, and simplified facial features (such as omitting nostrils and highly defined eyelids). These shapes naturally tap into caretaking and protective psychological instincts, completely bypassing the cognitive filters that detect the uncanny valley.

--------------------------------------------------------------------------------  
**Technical WebGL Execution & Performance Engineering**  
Browser-based execution environments demand strict performance boundaries to prevent thermal throttling, battery drain on mobile devices, and garbage collection stuttering.  
**Frame-Rate Independence and Delta-Time Accumulation**  
Because browser frame rates fluctuate wildly depending on CPU load, GPU power, and display refresh rates (60Hz to 144Hz), physical movement and state transitions must be calculated independently of the frame rate.  
The system must track the high-precision delta time (Δ*t*) elapsed between frames. However, simply multiplying physical forces by raw delta time can lead to physics breakdown if the frame rate drops suddenly (the "bullet-through-paper" collision error). To prevent this, the engine must use a fixed-timestep accumulator loop for physics and bone-scaling calculations:  
let accumulator = 0.0;  
const fixedTimeStep = 1 / 60; // Step at a locked 60Hz rate

function tick(currentTime) {  
    requestAnimationFrame(tick);

    const deltaTime = Math.min((currentTime - lastTime) / 1000, 0.1); // Clamp maximum lag step  
    lastTime = currentTime;  
    accumulator += deltaTime;

    while (accumulator >= fixedTimeStep) {  
        // Compute physics, gravity, and scale deformations at a stable, locked interval  
        updateProceduralPhysics(fixedTimeStep);  
        accumulator -= fixedTimeStep;  
    }

    // Update Three.js AnimationMixer with raw delta for smooth visual interpolation  
    mixer.update(deltaTime);  
    renderer.render(scene, camera);  
}

**Skeletal Skinning Limitations**  
WebGL devices impose uniform buffer limitations on vertex attributes. In Three.js, a standard skinned mesh allows a maximum of 4 bone influences per vertex.

* **The Uniform Limit Trap**: Humanoid models exported with auto-rigging systems often assign up to 8 bone influences per vertex to achieve smooth organic transitions around complex muscle zones. If a model exceeding 4 influences is loaded into Three.js, the engine must discard the weakest bone influences or fallback to CPU-based skinning.  
* **The Performance Cost**: CPU-based skinning requires recalculating vertex positions inside main-thread JavaScript on every single frame, which easily balloons execution times to over 26ms, destroying the frame rate. The technical artist must explicitly prune vertex weight allocations to a maximum of 4 bones during the rigging phase in Blender, ensuring that skinning remains 100% hardware-accelerated on the GPU.

**Draw-Call Minimization via BatchedMesh and InstancedMesh**  
The primary performance bottleneck in WebGL is the draw call. Minimizing draw calls is the single highest-impact optimization for browser scenes.

* **InstancedMesh**: If a scene features hundreds of identical cartoon props (such as grass tufts, trees, or floating debris), rendering them as individual meshes generates hundreds of draw calls. An `InstancedMesh` collapses all copies of the same geometry and material into a single draw call, managing individual positions, scales, and colors using a persistent array buffer.  
* **BatchedMesh**: When the scene contains varied geometries that cannot use instancing because their physical shapes differ (such as ten different stylized houses or various species of rocks) but they all share a single texture atlas and material shader, `BatchedMesh` (available in modern Three.js versions) combines them into a single, high-performance draw call while keeping each prop individually addressable for visibility toggling and transform updates.

--------------------------------------------------------------------------------  
**Cross-Domain Animation Taxonomy & Reference Map**  
To organize the pipeline of an interactive 3D web project, developers must understand how different conceptual layers interact. The table below separates theory, design, practice, implementation, and technical constraints into a functional reference map.

| Conceptual Layer | Domain Focus | Structural Mechanics | Practical Browser WebGL Implementation |
| ----- | ----- | ----- | ----- |
| **Animation Theory** | Kinetic personality and expressive appeal. | Squash/Stretch, Anticipation, Overlapping Action, Arcs. | Pre-baked keyframes mapped to bone translation/rotation tracks. |
| **Motion Design Theory** | Responsive UI feedback and visual scale. | Ease-in/out spacing, snapping elastic transitions, silhouette clarity. | Normalized progress variables mapped to cubic-bezier curves. |
| **Game Animation Practice** | Low-latency responsiveness. | Crossfading, additive bone weights, branching state machines. | Programmable mixers controlling weight balances on bone hierarchies. |
| **Browser WebGL Engine** | Dynamic rendering and matrix execution. | Joint matrix transforms, vertex shaders, morph targets, skinning attributes. | WebGL API calls, Data textures for bones, uniform matrices. |
| **Technical Constraints** | Performance budgeting and cross-device safety. | Draw call boundaries, skin weight pruning, uniform limits. | InstancedMesh, BatchedMesh, GPU skinning clamp (≤ 4 bones/vertex). |

--------------------------------------------------------------------------------  
**Compact Motion-Library Matrix**  
The following structural matrix establishes a production-ready framework for a reusable, lightweight cartoon character motion library. This compact, performant system supports all 13 essential animation states required for interactive browser-based projects.

| State Name | Purpose | Duration (s) | Loop | Skeleton Mask Layer | Eye Behavior | WebGL / Three.js Implementation Note | Reference Type |
| ----- | ----- | ----- | ----- | ----- | ----- | ----- | ----- |
| **idle** | Core breathing resting state. | 3.5 | Yes | Full Skeleton | Continuous micro-saccades (±1 ∘ ). | High-frequency breathing driven by sine wave on spine scale. | Pre-baked Skeletal Loop |
| **blink** | Micro-motion to maintain visual life. | 0.15 | No | Face Mesh | Interrupted tracking | Fast float interpolation on morph targets; clamped to prioritize eyes. | Morph Target State |
| **breathe** | Exaggerated lung expansion. | 4.0 | Yes | Chest & Ribs | Unaffected | Apply *S y* ​  stretch to upper spine and inverse *S x* ​ ,*S z* ​  to ribs for volume. | Pre-baked Skeletal Loop |
| **look** | Dynamic target tracking. | Dynamic | Yes | Head & Neck | Saccadic focus on target coordinates. | Execute dynamic bone `lookAt` with rotational angle clamping to prevent clipping. | Procedural Engine Control |
| **turn** | Dynamic angular orientation swap. | 0.3 | No | Hips & Legs | Anticipates turn direction. | Use custom sinusoidal weight transitions in mixer to prevent feet sliding. | Dynamic Blend State |
| **hop** | Responsive vertical displacement. | 0.7 | No | Full Skeleton | Fixed upward | Root translation driven by cubic Bezier curves; apply leg compression on start. | Procedural + Skeletal |
| **bounce** | Elastic ground impact squash. | 0.45 | Yes | Root & Spine | Unaffected | Apply squash factor *S y* ​ =0.75 and horizontal stretch *S x* ​ ,*S z* ​ =1.15 on landing. | Vertex Shader / Procedural |
| **land** | Absorbing jump fall impact. | 0.4 | No | Lower Body | Fixed downward | Deep knee flexion with follow-through delay on arms and ears. | Pre-baked Action Clip |
| **celebrate** | Victory animation loop. | 2.0 | Yes | Upper Body | Joyful upward squints | Additive wave logic applied to arms; strip translation coordinate tracks. | Skeletal Additive Loop |
| **hit-react** | Hurt response action clip. | 0.35 | No | Spine & Head | Rapid squint | Interrupts idle; blend target weight immediately over 0.05 seconds. | One-Shot Action Clip |
| **sleep** | Low-frequency dormant state. | 6.0 | Yes | Spine & Head | Closed eyelids (Morph Target) | Slow, exaggerated chest scaling combined with gentle head nod. | Skeletal + Morph Blending |
| **float** | Suspended atmospheric idle. | 3.0 | Yes | Root Bone | Sweeping focus | Translate root position vertically using a cosine wave: *y*=cos(*t*)⋅*A*. | Procedural Engine Control |
| **walk** | Primary locomotion loop. | 1.0 | Yes | Lower Body | Tracking horizon | Blend step cycle frequency dynamically based on forward speed. | Pre-baked Locomotion Loop |

--------------------------------------------------------------------------------

1. I built a Tiny Glade–inspired stylized renderer in Three.js (120 FPS in browser) - Reddit, [https://www.reddit.com/r/IndieGaming/comments/1sdxmxt/i_built_a_tiny_gladeinspired_stylized_renderer_in/](https://www.reddit.com/r/IndieGaming/comments/1sdxmxt/i_built_a_tiny_gladeinspired_stylized_renderer_in/)  
2. Wasteland Run A Post-Apocalyptic Endless Runner: Full-Stack Web Game with Flask Backend, Procedural Canvas - IJETRM, [https://ijetrm.com/issues/files/May-2026-05-1778001915-Wasteland-MAY2026-48.pdf](https://ijetrm.com/issues/files/May-2026-05-1778001915-Wasteland-MAY2026-48.pdf)  
3. Three.js Performance Optimisation: 60fps Patterns | IGC - Intelligent Graphic & Code, [https://www.intelligentgraphicandcode.com/development/threejs-interfaces/performance](https://www.intelligentgraphicandcode.com/development/threejs-interfaces/performance)  
4. Squash And Stretch In Animation: The Essential Principle For Lifelike Motion, [https://rebusfarm.net/blog/squash-and-stretch-in-animation-the-essential-principle-for-lifelike-motion](https://rebusfarm.net/blog/squash-and-stretch-in-animation-the-essential-principle-for-lifelike-motion)  
5. Three.js Visual & Interactive Encyclopedia - A Complete Guide, [https://neuralpixelgames.github.io/threejs-visual-guide/](https://neuralpixelgames.github.io/threejs-visual-guide/)  
6. Morph target animation - Wikipedia, [https://en.wikipedia.org/wiki/Morph_target_animation](https://en.wikipedia.org/wiki/Morph_target_animation)  
7. requestAnimationFrame Guide - 33 JavaScript Concepts, [https://33jsconcepts.com/beyond/concepts/requestanimationframe](https://33jsconcepts.com/beyond/concepts/requestanimationframe)  
8. Build Browser-Based Low-Latency Conversational AI Avatars with Three.js and React, [https://convai.com/blog/ai-avatars-inside-browser-threejs-react-convai-web-sdk-tutorial](https://convai.com/blog/ai-avatars-inside-browser-threejs-react-convai-web-sdk-tutorial)  
9. How to Avoid the 'Uncanny Valley' in Animation and VFX - Frameboxx Ahmedabad, [https://frameboxxanimation.com/how-to-avoid-the-uncanny-valley-in-animation-and-vfx/](https://frameboxxanimation.com/how-to-avoid-the-uncanny-valley-in-animation-and-vfx/)  
10. CC4 Character Bone Stretching Issue in Three.js - Reallusion Forum, [https://discussions.reallusion.com/t/cc4-character-bone-stretching-issue-in-three-js/16871](https://discussions.reallusion.com/t/cc4-character-bone-stretching-issue-in-three-js/16871)  
11. The Uncanny Valley Effect in Animation - Cascadeur, [https://cascadeur.com/blog/general/the-uncanny-valley-effect-in-animation](https://cascadeur.com/blog/general/the-uncanny-valley-effect-in-animation)  
12. Three.js Guide: Complete Reference for Builders (2026), [https://learnwithhasan.com/threejs-guide/](https://learnwithhasan.com/threejs-guide/)  
13. Smooth fading between animation clips - Questions - three.js forum, [https://discourse.threejs.org/t/smooth-fading-between-animation-clips/10189](https://discourse.threejs.org/t/smooth-fading-between-animation-clips/10189)  
14. On skeletal animation weights · Issue #6178 · mrdoob/three.js - GitHub, [https://github.com/mrdoob/three.js/issues/6178](https://github.com/mrdoob/three.js/issues/6178)  
15. Procedural Squash and Stretch - Converting Code from ActionScript to Unity, [https://discussions.unity.com/t/procedural-squash-and-stretch-converting-code-from-actionscript-to-unity/578612](https://discussions.unity.com/t/procedural-squash-and-stretch-converting-code-from-actionscript-to-unity/578612)  
16. Squash/Stretch 3D shader? : r/godot - Reddit, [https://www.reddit.com/r/godot/comments/r3751d/squashstretch_3d_shader/](https://www.reddit.com/r/godot/comments/r3751d/squashstretch_3d_shader/)  
17. Workflow: Animation from Blender to three.js - Unboring.net, [https://unboring.net/workflows/animation](https://unboring.net/workflows/animation)  
18. What is the simplest way to do a squash and stretch rig on an object? : r/Maya - Reddit, [https://www.reddit.com/r/Maya/comments/qelyqh/what_is_the_simplest_way_to_do_a_squash_and/](https://www.reddit.com/r/Maya/comments/qelyqh/what_is_the_simplest_way_to_do_a_squash_and/)  
19. Realtime rigging – Squash and stretch - Adding volume preservation to the arms - Autodesk, [https://www.autodesk.com/learn/ondemand/curated/realtime-rigging-squash-and-stretch/1sVkhjh3LPSpOc4yKpioto](https://www.autodesk.com/learn/ondemand/curated/realtime-rigging-squash-and-stretch/1sVkhjh3LPSpOc4yKpioto)  
20. How to make squash and stretch a ball at runtime - Epic Developer Community Forums, [https://forums.unrealengine.com/t/how-to-make-squash-and-stretch-a-ball-at-runtime/469483](https://forums.unrealengine.com/t/how-to-make-squash-and-stretch-a-ball-at-runtime/469483)  
21. How To Rig 3D Models Generated From Images - Threedium, [https://threedium.io/create/3d-models/rigging](https://threedium.io/create/3d-models/rigging)  
22. increase the skinning weight limit per vertex from 4 to 8 · Issue #12127 · mrdoob/three.js, [https://github.com/mrdoob/three.js/issues/12127](https://github.com/mrdoob/three.js/issues/12127)  
23. How to use requestAnimationFrame in JavaScript - CoreUI, [https://coreui.io/answers/how-to-use-requestanimationframe-in-javascript/](https://coreui.io/answers/how-to-use-requestanimationframe-in-javascript/)  
24. Animation Blueprint Head Look At in Unreal Engine - Epic Games Developers, [https://dev.epicgames.com/documentation/unreal-engine/animation-blueprint-head-look-at-in-unreal-engine](https://dev.epicgames.com/documentation/unreal-engine/animation-blueprint-head-look-at-in-unreal-engine)  
25. Maintaining mesh volume for squash and stretch - Autodesk, [https://www.autodesk.com/learn/ondemand/curated/realtime-rigging-squash-and-stretch/6iCxepDiuzZ2RxsSEWv2lA](https://www.autodesk.com/learn/ondemand/curated/realtime-rigging-squash-and-stretch/6iCxepDiuzZ2RxsSEWv2lA)  
26. Three.js - skinned skeletal mesh instances, animations and blending - Stack Overflow, [https://stackoverflow.com/questions/20465257/three-js-skinned-skeletal-mesh-instances-animations-and-blending](https://stackoverflow.com/questions/20465257/three-js-skinned-skeletal-mesh-instances-animations-and-blending)  
27. Skeletal animation in glTF | lisyarus blog, [https://lisyarus.github.io/blog/posts/gltf-animation.html](https://lisyarus.github.io/blog/posts/gltf-animation.html)  
28. Building an Endless Procedural Snake with Three.js and WebGL - Codrops, [https://tympanus.net/codrops/2026/02/10/building-an-endless-procedural-snake-with-three-js-and-webgl/](https://tympanus.net/codrops/2026/02/10/building-an-endless-procedural-snake-with-three-js-and-webgl/)  
29. How to play QuaternionKeyframeTrack in three.js - Questions, [https://discourse.threejs.org/t/how-to-play-quaternionkeyframetrack-in-three-js/88269](https://discourse.threejs.org/t/how-to-play-quaternionkeyframetrack-in-three-js/88269)  
30. Dynamic bones animation in Three.js - javascript - Stack Overflow, [https://stackoverflow.com/questions/20433474/dynamic-bones-animation-in-three-js](https://stackoverflow.com/questions/20433474/dynamic-bones-animation-in-three-js)  
31. Three.js Animation — Skills Registry - Truefoundry, [https://www.truefoundry.com/skills-registry/skill/CloudAI-X-threejs-skills-threejs-animation](https://www.truefoundry.com/skills-registry/skill/CloudAI-X-threejs-skills-threejs-animation)  
32. The three.js Animation System, [https://discoverthreejs.com/book/first-steps/animation-system/](https://discoverthreejs.com/book/first-steps/animation-system/)  
33. Controlling fps with requestAnimationFrame? - Stack Overflow, [https://stackoverflow.com/questions/19764018/controlling-fps-with-requestanimationframe](https://stackoverflow.com/questions/19764018/controlling-fps-with-requestanimationframe)  
34. How to Create Realistic Eye Movements in 3D Characters | Blog - Whizzy Studios, [https://www.whizzystudios.com/post/how-to-create-realistic-eye-movements-in-3d-characters](https://www.whizzystudios.com/post/how-to-create-realistic-eye-movements-in-3d-characters)  
35. Dynamic bones animation - Questions - three.js forum, [https://discourse.threejs.org/t/dynamic-bones-animation/52718](https://discourse.threejs.org/t/dynamic-bones-animation/52718)  
36. Adventures With WebGL & Three.js - Sebastian Lenton, [https://www.sebastianlenton.com/2020/07/adventures-with-webgl-three-js/](https://www.sebastianlenton.com/2020/07/adventures-with-webgl-three-js/)  
37. GLTF Split animations and CrossFade them - Questions - three.js forum, [https://discourse.threejs.org/t/gltf-split-animations-and-crossfade-them/2815](https://discourse.threejs.org/t/gltf-split-animations-and-crossfade-them/2815)  
38. 10+ JavaScript Kinetic Effects - FreeFrontend, [https://freefrontend.com/javascript-kinetic-effect/](https://freefrontend.com/javascript-kinetic-effect/)  
39. Avoiding the uncanny valley in virtual character design - ACM Interactions, [https://interactions.acm.org/archive/view/september-october-2018/avoiding-the-uncanny-valley-in-virtual-character-design](https://interactions.acm.org/archive/view/september-october-2018/avoiding-the-uncanny-valley-in-virtual-character-design)  
40. Draw Calls: The Silent Killer | Three.js Roadmap, [https://threejsroadmap.com/blog/draw-calls-the-silent-killer](https://threejsroadmap.com/blog/draw-calls-the-silent-killer)  
41. One Draw Call, Massive Crowd - Performance Engineering in Three.js - Showcase, [https://discourse.threejs.org/t/one-draw-call-massive-crowd-performance-engineering-in-three-js/89928](https://discourse.threejs.org/t/one-draw-call-massive-crowd-performance-engineering-in-three-js/89928)  
42. Procedural Instanced Forest - High Performance "Real" Trees - Resources - three.js forum, [https://discourse.threejs.org/t/procedural-instanced-forest-high-performance-real-trees/88610](https://discourse.threejs.org/t/procedural-instanced-forest-high-performance-real-trees/88610)  
43. 100 Three.js Tips That Actually Improve Performance (2026) - Utsubo, [https://www.utsubo.com/blog/threejs-best-practices-100-tips](https://www.utsubo.com/blog/threejs-best-practices-100-tips)  
44. PSA/SOLVED: Blending multiple animations for specific bones (running and shooting), [https://discourse.threejs.org/t/psa-solved-blending-multiple-animations-for-specific-bones-running-and-shooting/66154](https://discourse.threejs.org/t/psa-solved-blending-multiple-animations-for-specific-bones-running-and-shooting/66154)  
45. How to properly rotate an AnimationClip? - three.js forum, [https://discourse.threejs.org/t/how-to-properly-rotate-an-animationclip/35847](https://discourse.threejs.org/t/how-to-properly-rotate-an-animationclip/35847)  
46. Issue with Specific Animation Root in Three.js, [https://discourse.threejs.org/t/issue-with-specific-animation-root-in-three-js/65475](https://discourse.threejs.org/t/issue-with-specific-animation-root-in-three-js/65475)  
47. Anim Layer Masks and Blending - PlayCanvas Blog, [https://blog.playcanvas.com/anim-layer-masks-and-blending/](https://blog.playcanvas.com/anim-layer-masks-and-blending/)  
48. How to Implement Bone-Specific Animation Weighting in Three.js?, [https://discourse.threejs.org/t/how-to-implement-bone-specific-animation-weighting-in-three-js/65329](https://discourse.threejs.org/t/how-to-implement-bone-specific-animation-weighting-in-three-js/65329)  
49. Morph target performance question. - Character & Animation - Epic Developer Community Forums, [https://forums.unrealengine.com/t/morph-target-performance-question/29848](https://forums.unrealengine.com/t/morph-target-performance-question/29848)  
50. When to use Morph Targets vs. Animations - Epic Developer Community Forums, [https://forums.unrealengine.com/t/when-to-use-morph-targets-vs-animations/258992](https://forums.unrealengine.com/t/when-to-use-morph-targets-vs-animations/258992)  
51. Uncanny Valley | Aesthetics Wiki - Fandom, [https://aesthetics.fandom.com/wiki/Uncanny_Valley](https://aesthetics.fandom.com/wiki/Uncanny_Valley)  
52. The Uncanny Valley and Character Design | The Psychology of Games, [https://www.psychologyofgames.com/2013/05/the-uncanny-valley-and-character-design/](https://www.psychologyofgames.com/2013/05/the-uncanny-valley-and-character-design/)  
53. The Uncanny Valley - Sam's Concepts, [http://www.samnielson.com/artsammich/2012/06/uncanny-valley.html](http://www.samnielson.com/artsammich/2012/06/uncanny-valley.html)  
54. Is GPU skinning depreciated? - Questions - three.js forum, [https://discourse.threejs.org/t/is-gpu-skinning-depreciated/86826](https://discourse.threejs.org/t/is-gpu-skinning-depreciated/86826)  
55. Is the limit of 4 skinning weights per vertex a hard limit of WebGL? - three.js forum, [https://discourse.threejs.org/t/is-the-limit-of-4-skinning-weights-per-vertex-a-hard-limit-of-webgl/801](https://discourse.threejs.org/t/is-the-limit-of-4-skinning-weights-per-vertex-a-hard-limit-of-webgl/801)  
56. BatchedMesh – three.js docs, [https://threejs.org/docs/pages/BatchedMesh.html](https://threejs.org/docs/pages/BatchedMesh.html)  
57. lqq-code/Threejs-3d: Naked-eye 3D Effect with tracking.js + three.js - GitHub, [https://github.com/lqq-code/threejs-3d](https://github.com/lqq-code/threejs-3d)  
58. A vertex shader's job is to compute vertex positions. Based on the positions the function outputs WebGL can then rasterize various kinds of primitives including points, lines, or triangles. When rasterizing these primitives it calls a second user supplied function called a fragment shader. A fragment shader's job is to compute a color for each pixel of the primitive currently being drawn. - WebGL Fundamentals, [https://webglfundamentals.org/webgl/lessons/webgl-fundamentals.html](https://webglfundamentals.org/webgl/lessons/webgl-fundamentals.html)  
59. Skeleton – three.js docs, [https://threejs.org/docs/pages/Skeleton.html](https://threejs.org/docs/pages/Skeleton.html)  
60. Procedural generation of 3d objects with three.js | by Alexey Degtyarik | Medium, [https://medium.com/@LEM_ing/procedural-generation-of-3d-objects-with-three-js-9874806da449](https://medium.com/@LEM_ing/procedural-generation-of-3d-objects-with-three-js-9874806da449)  
61. Building a realtime eye tracking experience with Supabase and WebGazer.js, [https://dev.to/laznic/building-a-realtime-eye-tracking-experience-with-supabase-and-webgazerjs-3llj](https://dev.to/laznic/building-a-realtime-eye-tracking-experience-with-supabase-and-webgazerjs-3llj)  
62. Hands-on ThreeJS - Blending animations - YouTube, [https://www.youtube.com/watch?v=O6HMk9akpXw](https://www.youtube.com/watch?v=O6HMk9akpXw)  
63. three.js webgl - additive animation - skinning, [https://graphics.cs.wisc.edu/Courses/559-sp21-three/three.js/examples/webgl_animation_skinning_additive_blending.html](https://graphics.cs.wisc.edu/Courses/559-sp21-three/three.js/examples/webgl_animation_skinning_additive_blending.html)


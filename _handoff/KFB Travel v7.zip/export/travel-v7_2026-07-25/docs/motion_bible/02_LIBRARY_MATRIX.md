# Cartoon Motion Bible · 02 · Motion-Library-Matrix

> Kanonische Quelle (bereinigt). Die 37-Motion-Matrix + Produktionsregeln + eye_policy. Index: `docs/CARTOON_MOTION_BIBLE.md`.

Sehr gern — hier ist eine **konkrete Motion-Library-Matrix** für eure Cube-Pets-Animationen, mit Fokus auf cartoon physics, Gameplay-Lesbarkeit und eure zusätzlichen Augen-Rigs. Die Zuordnung orientiert sich an den klassischen Animationsprinzipien wie squash \& stretch, anticipation, follow-through, arcs, timing und exaggeration, die in moderner Cartoon-Animation weiterhin als Basis gelten.[^1][^2][^3][^4]

## Motion-Library-Matrix

| Animation | Zweck | Dauer | Loop | Layer | Augenverhalten | Implementations-Notiz | Referenztyp |
| :-- | :-- | --: | :-- | :-- | :-- | :-- | :-- |
| `idle_breathe` | Lebendigkeit im Stillstand | 2–4 s | Ja | Base + micro | langsames Blinken, minimaler gaze drift | nur Brust/Körper + very small root bob | Classic idle, modern game idle |
| `look_at` | Aufmerksamkeit / Zielausrichtung | 0.2–0.4 s | Nein | Expression | Augen führen, Kopf folgt leicht verzögert | gaze target zuerst, head lag 2–4 frames | Eye acting, character reaction |
| `blink` | Leben, Ruhe, Emphase | 0.08–0.18 s | Nein | Expression | Augen schließen schnell, reopen softer | randomize per character, avoid sync | Classic facial timing |
| `hop` | Kleine Fortbewegung | 0.4–0.7 s | Nein | Base | kurzer eye-stabil hold, dann settle | one anticipation frame, compress on takeoff | Game locomotion, rubber toy |
| `jump` | Vertikale Aktion / Reaction | 0.5–0.9 s | Nein | Base + physics | eyes slightly lag on takeoff, then lock midair | squash on prep, stretch on ascent | Classic squash/stretch |
| `land` | Impact / Kontakt | 0.2–0.4 s | Nein | Base + physics | eyes compress minimally, quick recover | strongest squash at contact, then rebound | Impact timing, ball bounce |
| `bounce` | Gummiball-Live-Feel | 0.6–1.2 s | Ja/No | Physics | eyes stay readable, tiny secondary bob | arc-based bounce, diminishing amplitude | Rubber ball, cartoon physics |
| `turn_90` | Richtungswechsel | 0.3–0.5 s | Nein | Base | eyes track new direction before body settles | turn on Y, slight counter-rotation | Staging, pose-to-pose |
| `turn_180` | Voller Richtungswechsel | 0.45–0.7 s | Nein | Base | eyes lead 1st half, head/body snap second half | use anticipation + overshoot | Classic turn, anticipation |
| `celebrate` | Sieg / Freude | 0.8–1.4 s | No/Maybe | Base + expression | eyes open wider, occasional blink on hold | alternating arm/ear hits, held extreme pose | Disney appeal, game victory |
| `hit_react` | Schaden / Schreck | 0.15–0.35 s | Nein | Physics + expression | eyes widen, then quick blink or recoil | fast in, slightly slower out | Exaggeration, shock pose |
| `sleep` | Ruhe / downtime | 2–6 s | Ja | Expression | eyelids droop, slow blink, gaze dead center | breathing loop separate from face | Idle loop, relaxation |
| `emote_yes` | Zustimmung / answer | 0.25–0.5 s | Nein | Expression | eyes nod with head, no independent drift | one clear accent, no overacting | Snappy TV cartoon beat |
| `emote_no` | Ablehnung / refusal | 0.25–0.5 s | Nein | Expression | eyes narrow, head leads side-to-side | keep amplitude small, readable | Classic negation beat |
| `spring_up` | elastischer Auftrieb | 0.45–0.8 s | Nein | Base + physics | eyes lag slightly on launch | use extreme squash at bottom, stretch upward | Rubber toy, spring action |
| `rubber_band_return` | Rückfederung | 0.35–0.7 s | Nein | Physics | eyes follow after body, settle last | overshoot/return, preserve volume feel | Cartoon elasticity |
| `gumball_roll` | Rundes, toyhaftes Rollen | 0.8–2.0 s | Ja/No | Base | eyes stay mostly upright relative to world or target | rotate body, keep facial orientation intentionally cheated | Modern 3D toy motion |
| `float_hover` | Magischer / leichter Zustand | 1.5–3.0 s | Ja | Base + micro | eyes drift softly, blink sparse | tiny sine bob, zero hard impact | Plush / floating toy |
| `stagger` | Benommenheit / Ausgleich | 0.5–1.0 s | Nein | Base + physics | eyes wobble, then re-center | asymmetry, delayed recovery | Classic stumble |
| `stomp` | Energie / Wut / Landepunkt | 0.35–0.6 s | Nein | Base + physics | eyes lock, then bounce once | strong downbeat, clear silhouette | Impact stomp, TV cartoon |
| `spin_stop` | Dynamischer Stopp | 0.5–0.9 s | Nein | Base + physics | eyes counterspin less than body | overshoot then quick brake | Action cartoon stop |
| `pose_hold` | Hero pose / readability | 0.5–2.0 s | Maybe | All | eyes hold on target, minimal movement | hold for staging, let camera read pose | Staging, appeal |
| `tiptoe` | vorsichtiges Schleichen | 0.7–1.4 s | Ja/No | Base | eyes scan, short darts, cautious blink | soft contact, quiet rhythm | Sneak / tension |
| `peek` | Neugier / vorsichtiger Blick | 0.3–0.7 s | Nein | Expression + base | one eye lead, subtle gaze lock | partial reveal pose, strong staging | Cute surprise beat |
| `double_take` | Überraschung / Komik | 0.5–1.0 s | Nein | Expression | first eye reaction, second eye re-check | snap + rebound + micro-hold | Comedy timing |
| `fear_shiver` | Angst / Kälte / Alarm | 0.6–1.5 s | Ja | Physics + expression | eyes jitter very lightly, not chaotic | small repeated quiver, avoid nausea | Fear beat, cartoon tremble |
| `launch` | Start einer Reise | 0.6–1.0 s | Nein | Base + physics | eyes lock forward, blink off before launch | strong anticipation, clean takeoff arc | Action launch |
| `air_drift` | Luftphase / Schweben | 0.5–1.5 s | Maybe | Base | eyes stable, micro-blink possible | minimize rotation, keep silhouette clear | Airborne readability |
| `midair_flip` | Verspielter Lufttrick | 0.4–0.8 s | Nein | Base + physics | eyes follow target or cheat to camera | preserve face readability as long as possible | Cartoon stunt |
| `impact_crash` | schwere Landung / Wipeout | 0.25–0.6 s | Nein | Physics | eyes squish after body impact, then pop back | strongest deformation in library | Slapstick impact |
| `slide_stop` | Rutschen und hartes Abbremsen | 0.4–0.9 s | Nein | Base + physics | eyes counterbalance, then settle | friction feel, dust puff optional | Modern game stop |
| `panic_run` | Flucht / Alarm | 0.8–1.5 s | Ja | Base + expression | eyes dart forward, occasional side flicks | fast cycle, compact silhouette | TV cartoon chase |
| `victory_loop` | Sieg im Idle | 1.5–3.0 s | Ja | All | eyes open, small proud blinks | loopable but not overly busy | Game victory loop |
| `taunt` | Provokation / Streit | 0.5–1.2 s | No/Maybe | Expression | eye contact locked, eyebrow equivalent via face tilt | readable attitude, avoid overmotion | Cartoon rivalry |
| `complain` | Protest / Grumble | 0.6–1.0 s | Maybe | Expression | eyes half-lid, look away then back | small repetitive loop OK | TV gag reaction |
| `shrug` | Unsicherheit / Humor | 0.4–0.8 s | Nein | Expression + base | eyes blink on the shrug apex | quick up-down, clear punctuation | Comedy punctuation |
| `heavy_fall` | großer Sturz | 0.6–1.0 s | Nein | Physics | eyes lag behind body, then flatten/recover | stretch in air, squash on impact | Classic slapstick |
| `soft_fall` | sanftes Fallen / Hinlegen | 0.8–1.5 s | Nein | Physics | eyes relax, slow settle | lower intensity, smoother easing | Plush toy motion |

## Produktionsregeln

Für eure Library würde ich diese Regeln direkt als SOP festschreiben: Jedes Animation-Asset braucht eine klare **Motion ID**, einen Zweck, einen erwarteten Gameplay-Trigger, eine Layer-Zuordnung und eine Augenregel. Das ist wichtig, weil die Animationssprache sonst schnell inkonsistent wird, gerade wenn Körper- und Eye-Rig getrennt behandelt werden.[^2][^3][^4]

### Pflichtfelder pro Motion

- Name.
- Trigger.
- Dauer.
- Loop-Flag.
- Layer.
- Eye behavior.
- Camera readability note.
- Secondary motion note.
- Export note.[^3][^4][^2]


## Augen-Spezifik für Cube Pets

Bei euch würde ich zusätzlich ein `eye_policy`-Tag pro Motion vergeben, zum Beispiel `lead`, `lag`, `lock`, `float`, `blink`, `wide`, `narrow`. Das ist sinnvoll, weil die augenförmigen Deko-Elemente über statischen Eyeball-Ebenen sonst schnell unnatürlich wirken, wenn sie immer vollständig mit dem Körper synchron laufen.[^5]

### Empfohlene Policies

- `lead`: Augen reagieren vor dem Kopf.
- `lag`: Augen folgen leicht verzögert.
- `lock`: Augen bleiben auf Ziel.
- `float`: Augen wirken minimal losgelöst.
- `blink`: vor oder nach einem Impact.
- `wide`: Überraschung.
- `narrow`: Skepsis oder Trotz.[^5]


## Nächster sinnvoller Schritt

Der beste nächste Schritt ist, diese Matrix direkt in ein **Motion-Spec-JSON** oder **Google-Sheet-Template** zu übersetzen, damit ihr sie in eurer Editor-Pipeline und im Rigging sauber nutzen könnt. Ich kann dir als Nächstes entweder

1. ein **JSON-Schema für die Motion Library**, oder
2. eine **erweiterte Tabelle mit Priorität, Blend-In/Out, FPS-Range und Rig-Affected Bones** bauen.




[^1]: https://en.wikipedia.org/wiki/Twelve_basic_principles_of_animation

[^2]: https://www.dgp.toronto.edu/~karan/courses/csc2529/principles.pdf

[^3]: https://www.nyfa.edu/student-resources/12-principles-of-animation/

[^4]: https://www.animationmentor.com/blog/squash-and-stretch-the-12-basic-principles-of-animation/

[^5]: Bildschirmfoto-2026-07-16-um-00.21.56.jpg

[^6]: https://www.openculture.com/2014/05/disneys-12-timeless-principles-of-animation.html

[^7]: https://www.youtube.com/watch?v=uXHnudwQde0

[^8]: https://www.cgtarian.com/animation-tutorials/disney-animation-principles.html

[^9]: https://abc7ny.com/post/the-12-principles-of-animation-as-illustrated-through-disney-and-disney-pixar-films/1437293/

[^10]: https://tips.clip-studio.com/en-us/articles/11810

[^11]: https://www.scribd.com/document/521201925/Disney-Flashcard


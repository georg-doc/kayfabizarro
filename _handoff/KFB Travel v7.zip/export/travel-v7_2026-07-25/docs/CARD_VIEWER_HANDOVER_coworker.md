# Card-Viewer — HANDOVER an Cowork-Lead (Opus) · sauberer Konzept- & Bau-Plan für v2

**Von:** Fable (Design-Chat) · **Datum:** 2026-07-15
**Begleitdokument:** `CARD_VIEWER_POC_v1_POSTMORTEM.md` (warum v1 scheiterte — bitte zuerst lesen).

Ziel dieses Dokuments: den **Raum + die Navigation als verbindlichen Contract** festnageln, damit v2 EINMAL
richtig gebaut wird. Kein Code hier — nur das Modell, die offenen Entscheidungen für den Lead, und die Bau-Reihenfolge.

---

## A · Das räumliche Grundmodell (der Contract, der v1 gefehlt hat)

**Eine ZELLE = ein Würfel-Raum, dessen 6 Innenflächen 6 Karten SIND.** Es gibt keinen separat „gebauten Raum" —
die Karten sind die Wände. Das ist die Auflösung des D6/Box-Widerspruchs aus dem alten Brief.

```
        [4 DECKE]
   ┌───────────────┐
   │               │
[3]│   [0 FRONT]   │[1]      Spieler steht MITTIG in der Zelle.
LINKS│  (Fokus)    │RECHTS   Blick: Yaw (umschauen) + Pitch (Decke/Boden).
   │               │
   └───────────────┘
        [5 BODEN]         (hinter dir: [2 RÜCK] = zuletzt betretene Karte = Spur)
```

- **6 Flächen / Slots:** `0 FRONT · 1 RECHTS · 2 RÜCK(=Spur/bekannt) · 3 LINKS · 4 DECKE · 5 BODEN`.
- **Jede Fläche = ein Comic-Panel:** 16:9-Kunst, emissiv, gerahmt von der irregulären Tusche-Outline. Kunst füllt die
  Fläche bündig (Outline überlappt die Kante → kein BG-Durchblitzen). Zoom/Pan passieren INNERHALB der Outline (McCloud-Fenster, in v1 gelöst).
- **Türen = die 4 WÄNDE** (Front/Rechts/Links + optional Rück). Decke/Boden sind (POC) **read-only Flavor-Karten**;
  später Level hoch/runter.

## B · Navigation (muss VOR jeder Animation stehen)
- **Umschauen:** Kamera sitzt im Zellen-Zentrum. **Yaw** dreht zwischen den 4 Wänden (A/D bzw. Drag-Look),
  **Pitch** kippt zu Decke/Boden (↑/↓). Sanfte Feder, kein Free-Orbit (Snap-to-Face ODER weiches Free-Look — *Entscheidung nötig, s. E*).
- **Durchtreten (Zelle → Zelle):** Die gewählte Wand ist eine Tür. Betreten = **die Kamera bewegt sich vorwärts durch
  die Wand-Ebene in die ANGRENZENDE Zelle.** Zellen liegen als **Graph im Weltraum** entlang deines Pfades
  (jede Wahl knickt den Korridor) → das IST das „infinite canvas". Die gewählte Karte wird die **RÜCK-Wand der neuen
  Zelle am selben Ort** (nahtlos, kein Fade, kein Rebuild-Flackern). ← v1 hatte das Prinzip zuletzt fast richtig; es
  muss nur auf dem sauberen Box-Gerüst + mit echter Kamera-Fahrt (nicht kaschiert) sitzen.
- **Boden ist real:** Es gibt eine **Bodenebene (y=0)** in jeder Zelle. Pet + Würfel stehen darauf. Alle Pet-Bewegung
  wird gegen diesen Boden keyframed — NICHT kamera-lokal (das war der v1-Fehler „fliegt im Raum").

## C · Der Loop (unverändert gültig, jetzt auf sauberem Raum)
Decks (1–3) → Mode würfeln → **Zelle** mit 6 Karten → umschauen → Fokus-Karte lesen (Zoom/Pan im Rahmen) →
Wand wählen → **Enter** = EIN `window.claude.complete` (Contract 06) → **Kamera fährt durch die Wand in die nächste Zelle**
→ neue Karten tuschen ein („still inking"). Pool: visited nie wieder · Cooldown ≥4 · cross-deck.

## D · Pet-Animation als STATE-MACHINE (statt handgetunter Keyframes)
Zustände: `IDLE (Control-Ecke) → SUMMONED (hüpft auf den Zellen-Boden) → LEAD (läuft zur gewählten Wand, dreht sich dazu)
→ THROUGH (hüpft durch die Wand-Ebene, synchron zur Kamera-Fahrt) → ARRIVE (im neuen Raum, schaut sich um) → RETURN (zurück
zum Spieler blickend in die Control-Ecke).`
- Jede Transition mit **Anticipation → Action → Settle** (echte Easing-Kurven, benannte Clips), **Bodenkontakt** (y=0 +
  Squash bei Landung), Stretch entlang der Sprungrichtung.
- Pet ist Companion + Würfel + Controller: Klick → **Radial-Würfel-Menü** (Roll · Skydome · Read · Sprache) — 3D-Cubes,
  fächern aus dem Pet (v1-Ansatz behalten, sauberer platzieren).
- **QA-Regel:** Animation IMMER als Frame-Sequenz verifizieren (mehrere Captures über die Dauer), nie nur End-Zustand (RC-4).

## E · Offene Entscheidungen für den Lead (bitte VOR v2-Bau beantworten)
1. **Kamera-Navigation:** reines **Snap-to-Face** (klare Lesbarkeit) ODER weiches **Free-Look** (Drag dreht frei, rastet nur beim Lesen)? *(Empfehlung: Free-Look mit Sanft-Rastung.)*
2. **Zellen sichtbar verbunden?** Sieht man beim Durchtreten kurz die nächste Zelle „durch die Tür" (echte Tiefe) oder ist die Wand opak bis zum Durchtritt? *(Empfehlung: Tür wird beim Peek leicht transparent → Tiefe.)*
3. **Ecken/Kanten der Box:** vollständig geschlossen (Karten stoßen zusammen) ODER bewusste schmale Gutter-Spalte mit Skydome-Durchblick dazwischen? *(Empfehlung: schmale Gutter — McCloud + Raumgefühl.)*
4. **Decke/Boden:** im POC read-only, ODER direkt als Level-hoch/-runter-Türen (Aufzug-Achse)? *(Empfehlung: POC read-only, Backlog Level.)*
5. **Skydome vs. Synapsen-Feld** als Hintergrund hinter den Gutter-Spalten (A/B, s. Brief-Backlog).
6. **Karten-Format auf Decke/Boden:** 16:9-Karte letterboxed auf quadratischer Fläche, oder Fläche = 16:9 (flacher Raum)?

## F · Bau-Reihenfolge für v2 (Fundament vor Feature — jede Stufe screenshot-verifiziert)
1. **Statische Zelle**: 6 Karten-Flächen als Box mit Tusche-Outlines, korrekt bündig, Kamera mittig. → Screenshot-Abnahme.
2. **Navigation**: Yaw/Pitch-Look + Snap/Free-Look zwischen den 6 Flächen. → Abnahme (fühlt sich der Raum an?).
3. **Zelle→Zelle-Traversal**: Kamera-Fahrt durch die gewählte Wand in die angrenzende Zelle (Graph im Weltraum, gewählte
   Karte = neue Rück-Wand). → **Bewegung per Frame-Sequenz** abnehmen.
4. **Pet** (zuletzt): State-Machine gegen den echten Boden, Radial-Menü, Würfel-Roll. → Frame-Sequenz-Abnahme.
5. **Inhalt/Polish**: Pool + 06-Call + „still inking" + Skydome/Settings + Session-Export (alles aus v1 portierbar).

## G · Was aus v1 1:1 übernommen wird (nicht neu bauen)
PDF-Pipeline · Deck-Registry + Pool-Ökonomie · Clay-Pet-Shader (v3) + Sphere-Eye-Rig · Zoom/Pan-Clipping ·
Mode-Farben (09) · 06-Call + Stub + Cache · 2-Res-LRU · Session-Export · i18n. Details + Asset-URLs: `CARD_VIEWER_POC_v1.md`, `uploads/ASSET_URLS.md`.

## H · Die EINE Frage, die v2 vor Runde 1 stellen muss
> „Bestätige das Raum-Modell (Abschnitt A/B) und beantworte E-1…E-6, bevor ich baue." — kein Pixel vor diesem Sign-off.

# Post-Mortem v6: Pet/Board-Cockpit — Overengineering-Runde

**Datum:** 2026-07-18 · **File:** `rollercoaster-ride.v6.js` (Cockpit-Pet auf HUD-Leinwand)

## Was funktioniert (KNOWN-GOOD STAND — nicht anfassen ohne Messung)
Nach dem Rückbau ist dies der saubere, stabile Zustand:

- **Zweite Leinwand (WebGL-Overlay über WebGPU):** Cockpit-Pet + Board leben in der HUD-Szene
  als Kind der **HUD-Kamera**. Feste kamera-lokale Pose → kein Welt-Anker, kein `aSm`, kein
  Smoothing-vs-Raw-Versatz. **Zittern strukturell weg** (gemessen: Schirm-Jitter 0).
- **Pet vor UND auf der Karte:** `_setPetScene(hud)` hängt es im Cockpit an die HUD-Kamera
  (immer vorn), auf der Schiene (mixK ≥ 0.4) zurück in die Welt-Szene.
- **Board-Sitz:** einmalig beim Bau in `buildPetBoard` gemessen — Foot-BBox in petHolder-lokal
  (`invH · meshWorld`, schließt alle Skalen ein), `mesh.position.y = bb.min.y − 0.006`.
- **Board-Depth:** `depthTest:true`, normale renderOrder → Pet-Körper verdeckt das Board korrekt.
- **Bewegung ruhig:** Kenney-Idle-Clip mit `mixer.timeScale = 0.5` gebändigt (ohne pet-motion lief
  er im Ride voll → „zitternd schnell").
- **Blinzeln:** `dur 0.30`, Gap 4–9 s.
- **Lean subtil:** Cockpit `leanDamp 0.24`, `maxTilt 0.12` (~7°); Feder läuft ungeklemmt, nur der
  sichtbare Winkel gedeckelt.
- **Float dezent:** bob 0.012 / sway 0.008 auf Track-Takt (2.72 rad/s), Amplitude sinkt mit Tempo.
  Pet und Board (beide in petHolder) floaten gemeinsam → keine Trennung.
- **Licht:** eigenes 4-Punkt-Studio in der HUD-Szene (key/fill/rim/amb), Pet nie dunkel.
- **Ink:** `hb` in `inkTail` relativ (`min(W,H)·0.0069`) statt absolut 5px → gleiche Strichbreite.

## Was ich versucht und WIEDER RAUSGEWORFEN habe (machte es schlechter)
Alle vier waren „billige" Fixes auf Verdacht, ohne dass die Messung sie stützte:

1. **Squash-Pivot** (`petScaler.position.y = soleY·(1−sq.s)`): `_petSoleY` maß als 0 (Pet-Origin
   liegt ohnehin auf den Füßen) → Kompensation war wirkungslos, aber Rausch-Quelle.
2. **Laufendes Foot-Min** für den Board-Sitz: pro Frame die tiefste animierte Sohle suchen und das
   Board nachführen → das Board wanderte, Pet verlor die Verbindung zur Karte.
3. **Clip-Ebene an der Board-Deckfläche** (`localClippingEnabled` + `material.clippingPlanes`):
   die Ebene aus dem gekippten, sich biegenden Board pro Frame zu setzen war instabil → Pet wurde
   **willkürlich gekappt, verschwand teils ganz**. Georgs Flat-Mesh-Clip-Idee ist gut, aber nicht
   auf einem tanzenden Board — bräuchte ein separates, flach-fixes Clip-Mesh.
4. **Launch-Ramp + größerer Lean/Float:** löste einen „45°-Snap", der real das Board-Deck (fixe
   30°) + zu großer Lean war → durch Rückbau auf subtile Werte gegenstandslos.

## Lektion (dieselbe wie v5)
Vier Änderungen gleichzeitig auf Verdacht gestapelt → Zustand wurde monoton schlechter, Ursache
nicht mehr isolierbar. **Regel:** eine Änderung, dann messen; bei Regress zuerst zurückbauen, nicht
weiterstapeln. Der Rückbau hier war ein sauberer str_replace-Reverse jeder einzelnen Änderung.

## Offen (bewusst NICHT angefasst)
- Füße können im tiefsten Idle-Frame minimal durchs Board schwingen (Bind-Pose-Sitz trifft den
  Clip nicht ganz). Akzeptabel im aktuellen Stand. Saubere Lösung, falls je gewünscht: ein
  flaches, mit dem Board fix mitrotierendes Clip-Mesh (nicht die tanzende Deckfläche).
- Story-Mode-Tönung des Pets (offen aus Georgs Liste).
- Float-Animation für die Karte im Pet-Select-Screen (offen aus Georgs Liste).

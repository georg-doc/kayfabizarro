# SPRINT-KICKOFF — Selective Bloom (Emissive/MRT) + Audio-Terrain

**Stand:** 2026-07-19 · Antwort auf Georgs Frage „Mehrwert-Zwischen-Sprint?" (+ `HANDOVER_audio_terrain_KISS.md`).

---

## Das Kern-Problem, kurz

Global-Bloom greift **alles** über der Schwelle: Partikel-Kerne, aber genauso Pet-Specular
(glossy-googly Augen), belichtete Würfelflächen, Karten-Highlights. Man kann die Partikel nicht
heiß genug für den gewünschten Nebula-Glow machen, ohne das Pet mitzuverbrennen. Zwei Fehlversuche
in v8 belegen das (Threshold 0.42 → Karte aus; 1.0 → Augen/Würfel aus). **Tuning löst das nicht.**

**Der Clou:** Das beiliegende Audio-Terrain-Konzept läuft in **exakt dieselbe Falle** — steht sogar
drin: *„Terrain und Rails teilen sich die Bloom-Schwelle … sonst brennen die Kacheln wieder (v7-Lehre)."*
Heiße Voxel + heiße Partikel + heißes Pet auf EINER globalen Schwelle → alle kämpfen gegeneinander.

## ✅ POC-Ergebnis (gemessen, 2026-07-19, Georgs Firefox-WebGPU)

Coworkers Bedingung erfüllt: erst beweisen, dann bauen. POC = `particle-test/mrt-bloom-poc.html`
(emissiver Würfel links, belichtetes Metall-Pet mit heißem Specular rechts), gemessen via
`eval_js_user_view` (Halo-Luminanz neben jedem Objekt):

| Modus | Halo EMISSIVE | Halo LIT PET | Ratio E/P | Urteil |
|---|---|---|---|---|
| **MRT-Selektiv** | 134.5 | **0.1** | **1693** | ✅ Pet bloomt NICHT, Emissive glüht |
| Global-Bloom | 134.8 | 30.9 | 4.4 | ❌ Pet bloomt mit (das Problem, reproduziert) |

- **`mrt()` wird vom gepinnten Build 0.178 akzeptiert** (`sp.setMRT(mrt({ output, emissive }))`, `sp.getTextureNode('emissive')`, `bloom(emisNode, 1.6, 0.6, 0.0)`).
- Ein Pass, kein Zweit-Renderer → v5-Freeze-Falle umgangen (bestätigt).
- **Weg ist frei.** Rest von Sprint 7 = Ausbau: Emissive-Routing in die echten FX-Materialien der Ride (Partikel-Kerne, Beat-Aura), Beauty-Pass unberührt.

---

## Meine Empfehlung: ein kleiner Fundament-Sprint ZUERST

**Sprint 7 — Selective/Emissive Bloom (MRT).** Statt Full-Screen-Bloom bekommt die Szene einen
zweiten Render-Target-Kanal (`mrt({ output, emissive })`). Nur FX (Partikel, später Voxel) schreiben
in `emissive`; Bloom liest **ausschließlich** diesen Kanal und wird über die Beauty-Pass kompositet.

Ergebnis: Pet/Karte/Rails können beliebig belichtet sein — **nur** was wir bewusst als emissiv
markieren, glüht. Danach dürfen Partikel-Kerne auf HDR 6 und COSMIC endlich richtig leuchten,
ohne Kollateral.

- **Aufwand:** überschaubar, aber ein echter Pipeline-Umbau (kein Value-Tweak). WebGPU/TSL kann MRT nativ.
- **Risiko:** die v5-Postmortem-Warnung galt dem naiven Zwei-Pass-Freeze — MRT ist EIN Pass, kein Zweit-Renderer. Prewarm-Muster wie beim jetzigen Bloom übernehmen.
- **Zahlt sich doppelt aus:** entkoppelt Partikel UND Audio-Terrain vom Rest.

## Danach: Audio-Terrain (der eigentliche Mehrwert-Sprint)

Sitzt dann sauber auf dem Emissive-Fundament. Bewertung des Konzepts: **stark, KISS, billig** (GPU-
Instancing wie `webgl_instancing_dynamic`). Die vorgeschlagene Disziplin („erst Beat-Puls 104,
dann reaktiv per AnalyserNode/Stems, eine Änderung pro Schritt") ist genau richtig. Der `viz`-Hint
in `jukebox.json` mit sinnvollem Default (Beat 104) ist sauber optional. 3D-Retro-Jukebox = geparkt, korrekt.

## Sequencing-Vorschlag

1. **Sprint 7 (Fundament):** Selective/Emissive Bloom (MRT). Klein, entblockt alles Heiße.
2. **Partikel-Payoff:** COSMIC/HDR-Kerne + Beat-Aura auf den Emissive-Kanal → der Glow, den wir wollten. Werte stehen schon in Test v1.
3. **Sprint 8 (Mehrwert):** Audio-Terrain, Beat-Puls-first, dann Stems-reaktiv.

## Alternative, falls kein Pipeline-Umbau gewünscht

v8 bleibt wie jetzt (v7-sicher, kein Ausbrennen) und wir akzeptieren, dass „großer Partikel-Nebula
in-Ride" mit Global-Bloom nicht geht. Ehrlich, aber lässt den gewünschten Effekt liegen.
Meine Stimme: **Sprint 7 lohnt**, weil er Partikel UND Terrain freischaltet — ein Fundament, zwei Auszahlungen.

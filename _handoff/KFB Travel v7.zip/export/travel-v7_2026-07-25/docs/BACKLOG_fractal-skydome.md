# BACKLOG — Immersive Fractal Skydome (KFB Terrain + Skydome v1)

**Status:** PARKED (2026-07-23). Default shipped instead: variant **A** (warm organic
waber-noise nebula, music-reactive, performant). The raymarched fractal variants **B**
(Mandelbox) and **L** (immersive Mandelbox) remain in the picker as *experimental*.

## Ziel
Ein Skydome im Stil von fractalworlds.io (WebGPU + three.js Raymarch): organische,
tiefe Fraktal-„Welt", die den ganzen Himmel umhüllt, farbgekoppelt an die Terrain-Palette,
im Takt der Musik animiert.

## Was probiert wurde (v1)
- **B — Mandelbox von außen:** Kamera außerhalb der begrenzten Struktur → das Fraktal
  erscheint als *abgeschnittene Scheibe/Objekt am Horizont* in nur einer Richtung, Rest = Dunst.
- **L — Mandelbox immersiv (innen):** Kamera *im* Gitter. Näher am Ziel, aber:
  - starkes **Rauschen** (Salz-und-Pfeffer), verstärkt durch das Half-Res-Upscaling des Runners;
  - **Wand-Clipping** — die driftende Kamera fährt durch solide Formen („angeschnitten durchfahren").
- **Mandelbulb** (Zwischenstand): organisch, aber ein *solider Klumpen* ohne Tunnel → innen
  komplett zu, als Umhüllung ungeeignet.

## Bekannte Probleme
1. **Außen-Framing** = begrenztes Objekt füllt nur einen Sichtkegel.
2. **Innen-Framing** = Kamera clippt durch Wände + hochfrequentes Rauschen.
3. **Mandelbox-Gitter zu regelmäßig** → „SciFi-Panel"-Look statt organisch.
4. **Umschalt-Bug:** Variantenwechsel greift teils erst beim 2. Klick (vermutlich async
   Shader-Compile nach dem Dome-Rebuild; erster Frame zeigt noch alt).

## Lösungsvorschläge (für die Wiederaufnahme)
- **Kamerapfad mit Kollisionsvermeidung:** Eye entlang DE-sicherer Voids führen (Schrittweite =
  DE-Wert), statt blind zu driften → kein Wand-Clipping. Oder SDF-geführter Fly-Through.
- **Rauschen bekämpfen:** temporale Akkumulation/Reprojection; den Dome-Pass in höherer
  Auflösung als das Terrain rendern; Soft-Min-AO / Cone-Tracing; gedithertes Stepping.
- **Volle Kuppel-Abdeckung ohne Translation:** Domain-Repetition (mod-Space) → Struktur in
  allen Richtungen, Kamera bleibt in derselben Void-Zelle (kein Clipping). Repetition mit
  Per-Zellen-Variation + Warp kuratieren, damit es nicht „gekachelt" wirkt.
- **Organischere DEs:** Apollonian Gasket / Kleinian / KIFS-mit-Rotation statt reiner Mandelbox;
  Fold-Rotationen animieren.
- **Env-Cubemap-Cache:** Fraktal alle N Frames in eine PMREM-Cubemap backen → billig, kein
  Per-Frame-Rauschen; langsam updaten für Animation.
- **Umschalt-Fix:** Materialien vorab `renderer.compileAsync` compilen; ODER beide Domes
  behalten und nur `visible` togglen statt neu zu bauen.

## Referenz
- fractalworlds.io (Formel „Aestrethra"), Thread: discourse.threejs.org/t/…/87098
- WebGPU + three.js, echtzeit-raymarchte Fraktale.

## Aktueller Default (funktioniert)
`FractalSkydome` **variant A** — kaleidoskopisch gefaltetes, domain-gewarptes Noise-Volumen,
weich/organisch getunt (ein sanfter Fold statt Kaleidoskop, warmer Boden, Energie treibt die
Wolkendichte, Beat-Puls). Farbe = Terrain-Palette (`setPalette`). Performant, kein Clipping.
Default ist inzwischen **variant S** (Sphere-Shader, 1:1 aus Ride v8) — der verlässliche Look.

## Hypno-Spiral-Overlay (v1, „gut genug" — später optimieren)
Welt-verankertes, transparentes Spiral-Overlay über JEDEM Dome (`_buildSpiralOverlay`,
`setSpiral`/`setSpiralAmt`/`setSpiralSpeed`), dreht auf `spiralRot` (Basis + Beat/Energy).
Multi-Arm Archimedes über Azimut/Elevation. **Noch nicht ganz überzeugend** — am Horizont
wirken die Arme eher wie sweepende Bänder als eine ikonische Swirl-Spirale (Zenit-zentriert →
Swirl nur beim Hochschauen sichtbar). Optimierungs-Ideen für später: logarithmische Spirale
(stereografische Projektion für echte Log-Spirale), Zentrum leicht nach vorn kippen statt
Zenit, Doppel-Layer mit Gegenrotation, weiche Kanten-AA gegen Moiré bei Half-Res.

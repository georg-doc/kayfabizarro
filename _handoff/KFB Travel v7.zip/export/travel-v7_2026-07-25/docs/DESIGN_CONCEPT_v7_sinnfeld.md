# Das begehbare Sinnfeld — v7-Konzept & Doku-Rückspiel

**Stand 2026-07-10.** Antwort auf `01_GLOBAL_INTENT_open_brief.md` (Brief-Vertrag §0/§4). Baut auf „Der lebende Druckbogen" auf. Führende Docs: 01 (Intent) + 03_ART_DIRECTION (Look). 03 ersetzt 07_SKYDOME (Wash → Cel-Bänder); 05_M0 liefert NUR den Bewegungs-Kern, seine Platzhalter-Optik wurde verworfen.

Datei: `Time Capsule Ride v7.dc.html` · v6 eingefroren.

---

## 0 · Die eine Idee

**Die Galaxie ist ein Sinnfeld, die Kante ist die Schiene, und alles ist gezeichnet, nicht gerendert.**

v7 baut die drei Baustellen aus dem offenen Brief als EIN Stück: der 3D-Raum bekommt sein Bindegewebe (Synapsen-Kanten, farbcodiert, pulsierend), die Kapsel wird ein Cel-shaded Weltraum-Container mit Tusche-Silhouette, und die Fahrt läuft als echte Physik (M0) exakt auf der gezeichneten Sequenz-Kante. Kein Element ist Deko: jede Linie ist eine Beziehung aus dem Deck, jeder Puls ist „jetzt".

## 1 · Die Galaxie (gestempelt aus dem Deck, 19 Knoten)

- **Zentrum:** Cover-Kapsel.
- **Innerer Orbit (r≈112):** die drei **Turn-Kapseln** — die Lese-Stationen der Fahrt.
- **Lesering (r≈56):** **12 Karten-Satelliten** im Lesesinn (Uhrzeigersinn), kleine Kapseln mit dem echten PDF-Crop (rezessiv behandelt: entsättigt, dünnere Linie — Betonungs-Bruch, die Umgebung tritt zurück).
- **Äußere Orbits:** Quick-Rules-Kapsel, FAQ-Kapsel (Panel-Grundierung), **Meta-Note** (Papier-Grundierung, Kommentar-Schicht), **2 Jump-Points** (gestrichelte Rahmen + gestrichelte Brücken nach draußen, „unsurveyed").

### Rückspiel-Entscheidung 1: 15-Knoten-Nordstern × Turn-Kapsel-Invariante

`03_GALAXY §1` denkt die 12–15 Karten als Satelliten; der Build-Brief (und v1–v6) trägt den ganzen Turn auf EINER Kapsel (4 Längsseiten = Actor + 3 Szenen). v7 versöhnt beides statt zu wählen: **die Turn-Kapseln bleiben die Erzählmaschine, die 12 Karten stehen ZUSÄTZLICH als einzeln adressierbare Satelliten im Feld.** Der §4-Puls verbindet beide: die erzählte Karte glüht auf der Kapselfläche UND ihr Satellit + dessen Kanten pulsieren in Mode-Ink. So bleibt die validierte v6-Maschine unangetastet und das Sinnfeld ist trotzdem voll gestempelt. Kosten: 12 kleine Canvas-Texturen, vernachlässigbar (Seiten sind ohnehin im LRU-Cache).

## 2 · Synapsen-Kanten (Kern, nicht später) — das EINE Farbsystem

Implementiert exakt nach `03_GALAXY §4`:

- **Farbton = Story-Mode**, nur auf den LIVE-Elementen (Puls). Ruhende Kanten tragen rezessives Gutter-Ink.
- **Grundierung = Knotentyp** (Karte volle Kunst / Rules+FAQ Panel / Meta-Note Papier / Jump gestrichelt). Kein zweiter Farbton.
- **Linienstil = Beziehung:** durchgezogen = Sequenz (Rail + Turn→Karte-Zugehörigkeit), gestrichelt = Querlink (3 kuratierte Paare: Payola↔Fine Print, Autotune↔Hologram, Garage Demo↔Unreleased Masterpiece), fein gewoben = semantische Nähe (4 kuratierte Paare, leichte Sinus-Webung). Handkuratiert — bei 15 Knoten ist das der Weg (§3).
- **Puls = jetzt:** erzählter Satellit, seine Kanten und das aktive Rail-Leg atmen in Mode-Ink (LFO), identische Logik wie das Flächen-Glühen.

**Rendering:** Die tragende Sequenz-Schiene ist eine gezeichnete Tube (Linienbreite fällt perspektivisch mit der Distanz = tiefen-sensible Linie umsonst) + sparsamer Mode-Glow (zweite, weiche Tube — kein Neon-Tron). Zugehörigkeit/Querlink/Semantik sind 1px-Linien: bewusster Kompromiss (WebGL-linewidth), die feinen Beziehungen SOLLEN fein sein; nur die geritten Kante trägt Körper.

### Rückspiel-Entscheidung 2: Die Kante IST die Schiene — wörtlich

Die vier Rail-Legs werden EINMAL gebaut (Austritt durch den Quest-Deckel in Ready-Orientierung, Bogen über den Lesering, Ankunft am nächsten Viewpoint); **die Fahrt läuft exakt auf dieser Kurve.** Gezeichnet wird die Tube nur vom Kapsel-Austritt bis kurz vor den nächsten Viewpoint, damit sie der Ruhe-Kamera nie durch die Linse läuft.

## 3 · Flug-Kern (M0 übernommen, Deko verworfen)

- Fixed Timestep 1/120 s + Akkumulator im Riding-Zustand — Ruckeln aus variabler Frame-Zeit konstruktiv ausgeschlossen.
- **Jerk-limitiertes Cosinus-S-Profil** auf der Bogenlänge (kein `ez()`-Easing, keine Keyframes). `rideSeconds` skaliert jetzt v_max, die Dauer EMERGIERT aus dem Profil.
- Orientierung = kritisch gedämpfte Quaternion-Feder auf ein **Lookahead-Ziel** (s + k·|V|); **Banking** aus der Querbeschleunigung; **FOV atmet mit der Geschwindigkeit** (nicht mit der Phase).
- **Docking = dieselbe Feder rastet ein** — das gescriptete Overshoot-Skript (v2) ist raus.
- **Uniform-Vertrag erfüllt:** ein Speed-Skalar pro Frame treibt Sky-Advektion + Warp-Stretch (`uSpeed`/`uDrift`), Staub-Parallaxe und FOV. Tempo wird über die UMGEBUNG wahrgenommen.
- **Gestrichen (M0-Lektion „die Deko war unser Fehler"):** Hyperraum-Streaks, Portal-Punktwolke, weiche additive Sprites. Der Portal-Moment ist jetzt ein flacher Mode-Ink-Impact-Frame (Cel-Vokabular), die Iris auf dem Deckel bleibt (diegetische Tür, keine Deko).
- Naher Staub = harte Tusche-Sprenkel (alphaTest, kein Glow), recycelt in einer Box um die Kamera — die viszerale Parallaxe-Lage aus der Flug-Recherche.

## 4 · Cel-Look (03_ART als Latte)

- **Himmel:** der domain-warped fBm-FELD bleibt (er ist gute Organik), aber er wird **quantisiert**: 4 flache Farbbänder zwischen Horizont- und Top-Ton (beide Mode-getintet über `skyFor()`), an jeder Bandgrenze eine Ink-Kante (Edge-Darkening als Linie, nicht als Blur), Papier-Granulation multiplikativ, Sonne = harte Scheibe + EIN Halo-Band. Kein Smoothstep-Verlauf mehr im Farbraum.
- **Halftone = zweite Schatten-Ebene (§4b):** Screen-Space-Punktraster (`gl_FragCoord`), Schwelle aus der Band-Dunkelheit — Dichte lebt im Punkt, jeder Punkt bleibt scharf, nur in den dunkleren Bändern. Das ist die im Benchmark markierte Entscheidung **Screen-Space** (Print-DNA: das Raster liegt im Bild, der Schatten kommt aus dem Raum). Die CSS-Rand-Vignette (Tweak `halftone`) bleibt als Print-Rahmen.
- **Kapseln:** alle Knoten sind `MeshToonMaterial` + 3-Stufen-GradientMap (NearestFilter → harte Bänder, die mit Drehung und Licht wandern). Licht-Rig diszipliniert: warmes Key (Form), **Rim in Mode-Ink** (Lichtfarbe = weiterer Kanal der einen Stimmungsquelle), hohes warmes Ambient, damit die Karten-Kunst lesbar bleibt.
- **Silhouette:** Inverted-Hull-Tusche-Linie an jeder Kapsel; Schirmbreite fällt mit der Distanz — Prinzip 2 (tiefen-sensible Linie) strukturell. Satelliten tragen relativ dünnere Linien und entsättigte Kunst (Detail tritt hinten zurück).
- Die v6-Flächen-Pipeline (Gutter, Wobble-Ink, Captions als Comic-Panels) bleibt unverändert — sie war schon Cel.

### Rückspiel-Entscheidung 3: Was bewusst NICHT in v7 ist

- **Sobel-Innenlinien auf Depth+Normal** (03_ART §4 Outline-Stufe b): braucht eine Post-Pipeline (Render-Targets). Die Inverted-Hull + gebackene Ink-Ränder tragen den Look schon; Post-Kanten + licht-geschwellte Objekt-Halftone = ein eigener v8-Track.
- **Satellit-Klick-Navigation** („flieg mich zur Karte") — gehört zum §10-Nav-Interface, nicht nebenbei.
- **Diegetisches Survey-Laden (§8)** nur im Wording („surveying the galaxy"); die Vermessungs-Animation an echte Ladeereignisse koppeln = eigener Schritt.
- Voice/Audio/Micro-Onboarding (§10–§12), Cockpit, Türblätter: reserviert wie geplant.

## 5 · Abnahme gegen 03_ART §7

- [x] Keine glatten digitalen Verläufe: Himmel posterisiert, Sonne hart, Flash flach, Streaks/Sprites raus. (Geparkte Ausnahme: `skydomeSource: watercolor/collage` als bewusste Tweak-Optionen — Default ist Cel.)
- [x] Linienbreite fällt mit der Tiefe (Inverted-Hull + Tube perspektivisch; Detail-Abstufung Satellit vs. Station).
- [x] Umgebung tritt zurück: Satelliten entsättigt, Kanten in Gutter-Ink, nur LIVE pulsiert in Mode-Farbe.
- [x] Halftone: scharfe Punkte, Dichte = Dunkelheit, nur in dunklen Bändern, Screen-Space.
- [x] 2–3 farbige Lichter: warmes Key + Mode-Rim + Ambient; kein Drei-Lichter-Matsch.
- [x] Synapsen-Kanten: gekrümmt, beziehungs-codiert (Linienstil), story-mode-sensitiv (Puls-Farbe), lesbar.
- [~] „Animationsfilm im Weltraum": die Bänder auf den Kapseln sind bei hohem Ambient subtil — bewusst zugunsten der Karten-Lesbarkeit. Nachschärfen (Ambient runter, Key rauf) ist ein Ein-Zeilen-Tuning, sobald Georg die Latte anlegt.

## 6 · Offene Punkte

- Kanonische S.16-Hex ersetzen die Interim-`MODES` (ein Edit).
- Kuratierte Quer-/Semantik-Paare sind meine Lesart des Decks — Cowork-Lane sollte sie absegnen oder ins Deck-JSON heben (`links: []`), dann stempelt die Galaxie auch die Kanten aus Daten.
- Jump-Points sind verschlossen (kein zweites Deck geladen); der Galaxie-Wechsel (§5/§8, Korridor = Ladepuffer) ist der natürliche nächste Bau.
- v8-Track „Post-Pipeline": Sobel-Innenlinien + licht-geschwellte Halftone auf Objekten.

# CHANGELOG — KFB Travel

Neueste Einträge oben. **Eine Zeile pro Runde, additiv.** Wer einen Slice abschließt, trägt hier
ein und setzt den Status in `docs/SPRINT_travel-v5.md`.

Format: `## YYYY-MM-DD · Version · Titel` → Was · Warum · Dateien · Belege/Offen.

---

## 2026-07-25 · v7 · S23: echte Karten auf den Sky-Karten (Deck-PDF + JSON)

`terrain-v7/card-registry.js` (neu) + `sky-cards.js`. **Der Vertrag ist Kanon und wurde nicht neu
erfunden** — er steht im Repo-Manifest `media/kfb/index.json` (`kfb-deck-registry/v2`):
2×2 Zellen pro Seite, Reihenfolge TL · TR · BL · BR, Seite = `coverOffset + 1 + floor((n−1)/4)`,
Quadrant = `(n−1) % 4`, URL = `baseUrl + '/' + encodeURIComponent(datei)`. Portiert aus
`rollercoaster-v11` (`loadRegistry` · `renderPdfPage` · `ensureCardArt`).

- **Text zuerst, Bild später.** Die Karten-JSON ist in Millisekunden da: Titel, Deck und zwei Zeilen
  Lore tragen das Blatt sofort. Das Artwork (2×2-Quadrant, 1:1 aus dem gerenderten PDF, auf die
  gejitterte Silhouette geclippt, kanonische Tuschekante drauf) kommt nach. **Nie ein leeres Blatt,
  nie ein Ladebalken.**
- **Gemessen:** vier Decks aus der Registry, Kartenpool über alle Decks gemischt (der Almanach ist da
  eindeutig — der Funke springt zwischen zwei Stimmungen), `cellAspect` **0,5573** aus der
  gerenderten Zelle — das ist 1/1,794 und bestätigt `KFB_CARD_AR = 1.79` unabhängig. Nach ~8 s
  trugen 4 von 7 Blättern echtes Artwork, Warteschlange leer.
- **Und die Lehre des Abends: ungepaced kostet das die Bildrate.** Erster Anlauf warf beim Erscheinen
  alle sieben Blätter in die Warteschlange — vier große Deck-PDFs gleichzeitig, dazu ein
  1500-px-Seitenrender pro Karte, alles auf dem Thread, auf dem der Flug läuft. Jetzt: Deck-JSON erst
  nach 4 s (die ersten Sekunden gehören dem Terrain-Aufbau), **ein** Render alle 2,5 s, nur wenn das
  Bild flott läuft (`dt < 40 ms`), und immer für die **nächste** Karte — die sieht man als erste.
  Schalter „Echtes Artwork laden" zum Abstellen.
- **Vorwärts-Bias bei der Verteilung:** neue Karten erscheinen ±75° um die Flugrichtung (10 % dahinter,
  damit es kein starres Tor wird). Vorher war der Himmel in Flugrichtung oft leer.
- **Zwei Robustheitslücken direkt nachgezogen** (Review), beide an derselben Wurzel — ein Auftrag,
  der nie zurückkommt: (1) `card.art = 'pending'` wurde nie freigegeben, wenn die Registry aufgab;
  das Blatt bekam dann in der ganzen Sitzung kein Artwork mehr, auch nicht direkt vor der Nase.
  `requestArt` hat jetzt einen **fail-Callback**, der die Karte freigibt. (2) **Watchdog, 20 s:**
  pdf.js treibt seinen Canvas-Render intern über `requestAnimationFrame` — wechselt man während eines
  Renders den Tab, settelt das Promise NIE, und `busy` wäre für immer belegt. Der Timer gibt frei,
  reiht neu ein und meldet. Dazu pumpt die Warteschlange gar nicht mehr, solange `document.hidden`
  gilt, und läuft bei `visibilitychange` weiter. **Ein Tab-Wechsel darf keinen Slice abschalten.**
- **Messfalle, die mich zwanzig Minuten gekostet hat:** in einem *hidden* Preview feuert
  `requestAnimationFrame` nicht — der Frame-Zähler stand, und das sah exakt wie ein toter Loop aus.
  Dazu liest `renderer.info.render` **nur den letzten Pass**: mit Post-Processing sind das 6 Calls für
  den Bildschirm-Quad, nicht die Welt. Beides notiert; ab jetzt wird in der sichtbaren Ansicht
  gemessen.

## 2026-07-25 · v7 · S22 Kern: Sky-Karten als Flugziele

`terrain-v7/sky-cards.js`. Vier Dinge, die zusammen ein Flugziel machen:

**1. Zero-G ohne Wiederholung.** Drift, Neigung und Rollen kommen aus **drei Sinus-Termen pro Achse
mit inkommensurablen Frequenzen** (√2, √3, √5, goldener Schnitt). Die Summe hat keine gemeinsame
Periode — es gibt also kein „jetzt wackelt es wieder genauso". Genau Georgs Anforderung, und billiger
als jede Rausch-Textur.

**2. Lesbarkeit schlägt Physik.** Die Karte dreht sich zur Kamera (Karten haben keine Rückseite,
Kanon aus v11), aber **gedämpft per Slerp**: sie folgt der Blickrichtung, ohne zu schnappen, und
behält ihre Eigen-Neigung obendrauf. Ergebnis: immer ein guter Lesewinkel UND ein guter
Durchflugwinkel — beides war die Vorgabe.

**3. Durchflug statt Kollision.** Kein Solver, keine Broadphase: Abstand zur Kartenebene
(Skalarprodukt mit der Normale), und der **Vorzeichenwechsel IST das Ereignis** — gültig nur, wenn
der Punkt innerhalb der halben Kantenlängen liegt. **Gemessen: Durchflug erkannt, „The Held Breath"
gesammelt.**

**4. Portal-Auflösung, portiert aus v11:** geteilte AlphaMap (radial-ovaler Gradient + Value-Noise)
und ein **steigender `alphaTest`**. Der frisst die Mitte zuerst und lässt eine irreguläre Kante
stehen. Null CPU, eine Textur für alle Karten. Danach Respawn an neuer Stelle.

**Karteninhalt:** echte Titel aus den Cut-&-Play-Decks (*The Finished City*, *The Doomsday Clock*,
*The Held Breath* …) mit Deck-Zeile — Platzhalter wären hier falsch, die Karten sind Beweisstücke.
Blatt ist Papier + gejitterte Ink-Outline, gemalt auf Canvas. **Und eine Lehre aus v11 gleich
mitgenommen:** nach `document.fonts.ready` werden die Texturen EINMAL neu gemalt — läuft der Webfont
noch, malt der Browser still Georgia, und die Typografie hängt am Zufall der Ladereihenfolge.

- **Regler** in der neuen Sektion „Sky-Karten": sichtbar · Größe · Ring-Abstand · Höhenband ·
  Zero-G-Drift · Eigen-Neigung · Ausrichtung folgt (träge → flink) · Trefferfenster · Zähler.
- **Bewusst NICHT drin:** KISS-Strahlen (S22b), Wind und Turbulenz (S22c), Deck-UI (S26). Nach dem
  Durchflug ist das Ding spielbar — da soll ein Zwischenstand stehen.
- **Captures:** `screenshots/01-v7-skycards.png`, `02-v7-skycards.png`.
- **Drei Nachbesserungen noch am selben Abend** (Review): `nearest` maß den Abstand zum
  **Weltursprung** statt zum Spieler — heute unbenutzt, aber genau die API, an der S22b und S22c
  hängen würden, und dort wäre der Fehler still. Jetzt `nearest(player)`; gemessen: liefert die
  Karte bei 94 Einheiten, und 94 ist auch das Minimum über alle sieben. Zweitens ein **Texturleck**
  beim Respawn (alte `CanvasTexture` wurde ersetzt statt disposed — pro gesammelter Karte blieb eine
  720×402-Textur auf der GPU). Drittens zwei Allokationen pro Karte und Frame (≈ 840/s) durch ein
  frisches Quaternion für die Eigen-Neigung — jetzt vorallokiert wie der Rest des Moduls.

## 2026-07-25 · v7 · S21 erledigt: Flug-Sounddesign, Schritte, Sample-Registry — plus Flow ohne Musik

**Die Luft hat jetzt zwei Schichten und atmet.**
- **Böen** (`gust`): ein langsamer Zufallsgang (alle ~0,9 s ein neues Ziel, mit 1,6/s angefahren)
  moduliert den Fahrtwind. Ohne das steht er als Rauschteppich; damit atmet er.
- **Rumpeln** (`rumble`): eine zweite, tiefpassgefilterte Rauschschicht aus demselben Puffer, die
  **nah am Boden lauter wird** (`agl` in Weltunits → `low`), zusammen mit einem dunkleren Bandpass.
  Das ist der Unterschied zwischen „schnell" und „knapp über dem Boden schnell".
- Im Walk-Modus läuft die ganze Motion-Ebene auf 35 % — zu Fuß gibt es keinen Fahrtwind.

**Schritte, Rolle, Aufprall als Ereignisse.**
- **Schritte** hängen am Gehzyklus der Pet-Kinetik: `pet-kinetics.js` zählt Fußaufsätze
  (Nulldurchgang von `sin(walkT)`) und der Runner hängt die SFX an den Zähler — kein zweiter,
  eigener Takt. Synthetisch ist es ein kurzer gefilterter Rauschklick mit Tonhöhen-Jitter; zwei
  identische Schritte klingen sofort mechanisch. **Gemessen: 5 Tritte in 1,8 s Gehen.**
- **Barrel-Roll** bekommt einen Swish, der über die Stereobreite wandert — die Drehung wird hörbar.
- Landung skaliert weiter am `impact`, Absprung ist ein Pop.

**Sample-erst-dann-Synthese (das Wichtigste an diesem Slice).** `sfx(id)` spielt eine echte Datei,
wenn für die Id eine im Manifest steht — `media/3D_Assets/Audio/sfx.json` im Repo (RAW-first),
lokaler Fallback `terrain-v7/sfx.json`. Sonst der synthetische Einsatz, also **nie Stille**.
Manifest-Form pro Id: `{ file | variants[], gain, rate, jitter }`; `variants` rotiert gegen
Wiederholung, `jitter` streut die Tonhöhe. Alles im Manifest wird beim Ton-Start vorgeladen (ein
Einsatz darf nicht erst beim zweiten Mal klingen). **Georgs ElevenLabs- und Kenney-Dateien sind damit
eine Datenänderung, kein Code.** Ids, die schon abgefragt werden: `boost` · `land` · `jump` ·
`step` · `roll` · `card` (für S22).
Zweiter Trim `sfx` nur für Samples, weil ElevenLabs-Dateien mit sehr unterschiedlichen Pegeln kommen.

**Nebenbei, aus Georgs Notiz: Flow ohne Musik war nicht einstellbar.** Der Flow-Regler bestimmt die
PHASE, die Amplitude hing aber weiter an Beat und/oder Reisetempo — ohne Musik also entweder still
oder tempoabhängig. Neue Stellung **„gleichmäßig (Flow ohne Musik)"** in beiden Kopplungs-Selects:
konstante Amplitude 0,55, weder Takt noch Tempo. Damit ist das Boden-Animationsmuster für sich
einstellbar, wie in der three.js-Demo.

- **Dateien:** `terrain-v7/travel-audio.js`, `terrain-v7/pet-kinetics.js` (`stepCount`),
  `terrain-v7/travel-poc.js`, `terrain-v7/sfx.json` (neu, leerer Fallback).
- **Regler** in „Klang & Rhythmus": Rumpeln (Bodennähe) · Böen · Sample-Trim, dazu die bestehenden.

## 2026-07-25 · v7 · S20 erledigt: Jukebox + Drone — der Takt kommt jetzt aus der Musik

- **Was:** `terrain-v7/travel-audio.js`. Der 4-Ebenen-Soundscape aus Rollercoaster v11, portiert und
  auf Travel-Kontrakte gelegt: **bed** (Drone: der Story-Mode IST eine spektrale Identität,
  `AUDIO_MOODS` 1:1 übernommen) · **motion** (Fahrtwind ∝ heat², Bandpass öffnet mit dem Tempo, im
  Walk-Modus auf 35 % gedämpft — zu Fuß gibt es keinen Fahrtwind) · **event** (Boost-Whoosh,
  Landungs-Thump skaliert am Impact, Absprung-Pop) · **space** (geteilter Feedback-Delay-Hall,
  Wet aus dem Mood).
- **Der eigentliche Gewinn:** unser Takt war eine Zahl im Runner (`synthPhase`, `bpm 104`). Jetzt
  kommt die Eins aus dem Track — Cube-Tanz und Blinken hängen an Musik, die man hört. **Ein
  Takt-Ausgang** (Regel aus S1): läuft Ton, liefert `audio` den Beat; ohne Ton bleibt der
  synthetische Takt. Kein zweites System, nur eine andere Quelle.
- **Jukebox:** RAW-first aus dem Repo (`media/3D_Assets/Sounds/jukebox.json`), lokaler Fallback
  (`terrain-v7/jukebox.json`), hartkodierter Default als letzte Reserve. **Gemessen: zehn Tracks
  geladen**, Van Metronome (104 BPM) spielt, Bassband-Pegel 0,68.
- **Der rohe Pegel taugt nicht als Beat.** Erste Fassung koppelte `level·0.7` — bei einem gemasterten
  Track steht der Bass dauerhaft bei 0,7, die Cubes hätten also durchgetanzt statt gepulst. Jetzt
  zählt der **Ausschlag über dem langsamen Mittel** (`(level − levelAvg)·4`, Mittel mit 0,6/s) — das
  ist ein Onset.
- **Zwei Fehler, die den ganzen Slice im ausgelieferten Weg tot aussehen ließen** — gefunden, weil
  über den echten Overlay-Schalter gemessen wurde und nicht über einen direkten `start()`-Aufruf:
  1. **`ctx.resume()` fehlte beim ersten Start.** Ein frisch angelegter AudioContext kommt in vielen
     Browsern SUSPENDIERT hoch; `ctx.currentTime` läuft dann nicht, der Phasenvergleich feuert nie und
     der Analyser liest Stille. Jetzt resumt `start()` sofort, und **jede** Nutzergeste resumt erneut
     (ein Context kann auch später suspendieren, z. B. beim Tab-Wechsel).
  2. **Das Gate war `ready` statt „Uhr läuft".** `ready` heißt nur „Graph gebaut" — damit war der
     funktionierende synthetische Takt ab dem ersten Ton-Einschalten dauerhaft verworfen, auch wenn
     danach nichts spielte. Neuer Ausgang `running` (Graph UND `state === 'running'` UND nicht
     stumm); der Runner gated darauf.
- **Nachgemessen über den echten Weg** (Klick auf „Ton an" im Overlay): `state 'running'`, Pegel 0,72,
  und `uBeat` am Terrain-Material pulst **0,47 … 0,66** im Takt. Ton wieder aus → `running false`,
  synthetischer Takt ist zurück (`uBeat` 0,16 … 0,48). Die Live-Zeile zeigt jetzt auch ehrlich
  „Ton aus" statt „BPM aus dem Track".
- **Drei v11-Lehren von Anfang an eingebaut:** Audio braucht eine Nutzergeste (der Runner ruft
  `armAudio()` in keydown und pointerdown; ohne Klick existiert kein AudioContext) · Reverb-Send
  **post** Fader (FX auf 0 = auch Hall aus) · beim Track-Wechsel zuerst `onended = null`, dann
  `stop()` — sonst legt der Restart-Timer eine zweite Quelle drüber (Flamming).
- **Mood-Wechsel ohne Rebuild:** `setMood()` stellt Wellenform, Partialfrequenzen und Filter live um
  (v11 baute den Graph neu). Ein Story-Wechsel ist bei uns ein Regler — der darf nicht knacken.
- **Regler** in der umbenannten Sektion **„Klang & Rhythmus"**: Ton an · Track (zehn Titel mit BPM) ·
  Musik · Drone · Fahrtwind · Effekte · Tempo (nur ohne Ton) · Beat-Kopplung · Live-Anzeige
  (BPM aus dem Track + Puls in %).
- **Dateien:** `terrain-v7/travel-audio.js` (neu), `terrain-v7/jukebox.json` (neu, Fallback),
  `terrain-v7/travel-poc.js`.
- **Offen für S21:** echte SFX-Dateien (ElevenLabs) statt synthetischer Einsätze, Karten-Durchflug
  (kommt mit S22), und die sechs Würfel als gerichtete Quellen — der Hörer folgt schon der Kamera,
  die Panner kommen mit den Sky-Karten.

## 2026-07-25 · v7 · Schatten neu gedacht (projiziert statt Quad) + Kamera kann nicht mehr im Cube stecken

Drei Befunde von Georg, alle drei am selben Abend. **Nur in `terrain-v7/` behoben — v6 bleibt FROZEN.**

**1 + 2. Der Blob-Schatten war im Ansatz falsch, nicht falsch parametriert.** „Wirkt unecht und
flackerig, va bei dancing cubes und wechselnden Höhen" und „im Walk-Modus ist der Übergang zum Body
nicht plausibel" haben dieselbe Ursache: ein Schatten-**Quad** liegt auf EINER Höhe. Auf einem
Voxel-Boden heißt das: an Kanten schwebt es über dem Abgrund, an Wänden steckt es in der Geometrie,
und sobald die Höhenprobe zwischen zwei Nachbarsäulen springt (oder ein Cube hüpft), springt der
ganze Fleck. Dazu lag er als runde Scheibe **neben** dem Pet statt an seinem Fuß.

**Neu: der Terrain-Shader projiziert den Schatten selbst.** Jedes Terrain-Fragment kennt seit dieser
Runde seine Weltposition (`vWorld`); damit lässt sich der Werfer entlang des Lichtstrahls auf genau
diese Höhe projizieren:
```glsl
float dy = caster.y - vWorld.y;                       // Werfer unter der Fläche → kein Schatten
vec2 p = caster.xz + (L.xz / max(L.y, 0.25)) * dy;    // Projektion entlang des Lichtstrahls
float d = length(vWorld.xz - p) / (caster.w * (1.0 + dy * 0.045));
```
Das Ergebnis dimmt die belichtete Farbe multiplikativ (`lit *= 1 − 0.52·sh`). Vorteile, die alle drei
Beschwerden erledigen: der Schatten sitzt immer auf der Fläche, **die wirklich da ist** — auch auf
Cube-Wänden, wo er als Schmier hochläuft, wie es ein echter Schatten tut; er bewegt sich mit den
tanzenden Cubes mit (weil er dort ausgewertet wird, wo die Geometrie steht); er kann nicht z-fighten;
und im Walk-Modus setzt er am Fuß an, weil der Werfer die **Körpermitte** ist (`y + 0.85`, r 0,95) und
die Projektion kontinuierlich ist. Kosten: zwei Distanzen pro Fragment, keine Geometrie, kein
Draw-Call. API: `terrain.setCasters(a, b)` (zwei Werfer, `{x,y,z,r}`) und `terrain.setCasterGain()`.
**Das Quad bleibt genau dort, wo es richtig ist:** der Pet-Schatten AUF der Karte — durchgehende
Fläche, und er soll mit Bank und Wellung mitgehen.

**3. Kamera steckte an Eck-Positionen im Cube** (Georgs Screenshot: Artefakte, dann Flackern).
Zwei Ursachen: der Pull-in tastete nur 8 Proben ab (eine dünne Wand dazwischen wird übersehen), und
der Höhen-Deckel im Walk-Modus schob die Kamera horizontal Richtung Pet — direkt in die Nachbarsäule.
Jetzt 14 Proben, und **als letzte Instanz `escapeTerrain()`**: unsere Welt ist ein Höhenfeld aus
VOLLEN Säulen, wer über der Säulenoberkante ist, ist garantiert draußen. Die Funktion kriecht notfalls
in bis zu sechs Schritten Richtung Blickziel, bis das gilt. Lieber sehr nah am Pet als in einer Wand —
und mathematisch kann die Kamera damit nicht mehr in Geometrie stehen. Läuft in beiden Modi (Flug mit
Marge 0,9 / vier Schritten, Boden 0,8 / sechs).

- **Dateien:** `terrain-v7/voxel-terrain.js` (`vWorld`, `castShadow()`, `setCasters`),
  `terrain-v7/travel-poc.js` (Werfer pro Frame, `escapeTerrain`, Pull-in 14 Proben).
  `ground-shadow.js` bleibt — jetzt nur noch für die Karte.
- **Captures:** `screenshots/02-v7-shadow.png` (Schatten am Fuß, auf Kante und Wand),
  `03-v7-shadow.png` (laufend), `01-v7-shadow.png` (Flug).
- **Regel dazu:** *Ein Schatten auf einer nicht-durchgehenden Fläche gehört in den Shader der Fläche,
  nicht auf ein Quad davor.* Dasselbe Muster wie beim Radial-Blur: die Frage war nicht der Parameter,
  sondern wo der Effekt hingehört.

## 2026-07-25 · v6 · S18 Flow-Modus + S15 Blob-Schatten — und v6 ist FROZEN

**S18 · Flow.** Der Hub hat jetzt zwei Muster, gemischt über einen Regler (`terrain.setFlow(0…1)`,
Sektion Rhythmus, Default 0):
- **Dancefloor** (0): jede Säule hat ihre eigene Phase aus dem Seed — richtig für den Beat, und für
  Edge-Case-Tests weiter der bessere Zustand, weil Nachbarsäulen unabhängig arbeiten.
- **Flow** (1): die Phase kommt aus dem ORT. Drei überlagerte Terme — schräg laufende Welle,
  quer modulierende zweite Welle, langsam radiale dritte — ergeben ein Interferenzmuster, das sich
  nie exakt wiederholt und trotzdem nicht zufällig aussieht. Georgs three.js-Verweis
  (`webgl_instancing_dynamic`) beschreibt genau diesen Unterschied: räumlich zusammenhängende
  Bewegung statt zehntausend unabhängiger Zappler.
Amplituden-Kopplung (Musik / Tempo / beides / aus) und die Ruhezonen greifen unverändert — sie
dämpfen die Amplitude, nicht die Phase.

**S15 · Blob-Schatten** (`ground-shadow.js`). Kein echter Schattenwurf: das Pet WIRFT längst
Schatten, aber die Terrain-Cubes sind ein eigenes `ShaderMaterial` ohne Shadowmap-Chunks — und
tanzende Cubes würden eine echte Schattenkante zappeln lassen. Also die cartoongerechte Lösung:
ein flaches Quad, radial ausgefadet, unbeleuchtet, `depthWrite: false` — aber MIT Tiefentest, damit
ein höherer Cube den Schatten korrekt verdeckt. **Zwei Anwendungen, eine Klasse:**
- **auf dem Terrain** — im Flug unter der Karte (wächst und verblasst mit der Höhe: das ist die
  Höhenauskunft am Boden), am Boden unter dem Läufer.
- **auf der Karte** — der Pet-Schatten hängt IM Karten-Rig (`rig.lean`), bankt und wellt also mit,
  und wächst beim Sprung: der Kontakt, der einem Cartoon-Sprung Gewicht gibt.

**Zwei Dinge, die erst nach dem ersten Blick stimmten:**
1. **Ein Exponent-Abfall (`pow(1−d, 1.6)`) ist zu blass**, um auf einem gemusterten Boden gelesen zu
   werden. Jetzt voller Kern bis `core 0.34`, danach weich aus.
2. **Das Objekt stand auf seinem eigenen Schatten.** Der Versatz rechnet jetzt mit Höhe **plus halber
   Körperhöhe** in Sonnenrichtung (Sonne bei 30/60/20) — vorher lag der Fleck exakt unter dem Pet und
   war nie zu sehen. Nebeneffekt, der stimmt: die Szene liest sich nicht mehr als Mittagslicht.

**v6 ist damit FROZEN.** Snapshot aktualisiert: `export/travel-v6_2026-07-25/` (Entry, `support.js`,
`themes/kfb-med.css`, 18 Module, docs, sieben QA-Bilder, `MANIFEST.md`).
**Erledigt in v6:** S2 (Speedlines + Radial-Blur + Barrel-Roll, drei Korrekturrunden) · S14
(Pet-Beleuchtung) · Ink-Outline-Regler · Ruhezonen (vier statt einer) · S10 (Modus folgt der Höhe) ·
S11 (Rahmen mit Wortmarke) · S18 (Flow) · S15 (Blob-Schatten).
**v7 angelegt:** `KFB Travel v7.dc.html` → `terrain-v7/`, Plan in `docs/SPRINT_travel-v7.md`.

**Beim ersten Fork sofort aufgefallen — dieselbe Lüge wie v5→v6:** das Overlay sagte „KFB Travel v6".
Der Fix von damals hatte die Zeile zwar als `opts.eyebrow` herausgezogen, aber mit
`|| 'KFB Travel v6'` als **hartkodiertem Default** — der Fork erbt ihn. Jetzt gibt der **Runner**
seine Version mit (`eyebrow: 'KFB Travel v7'`), und der Default im Overlay ist neutral
(`'KFB Travel'`). **Regel: die Versionsnummer gehört dem Runner, nicht einem Modul** — ein Modul,
das seine eigene Version kennt, lügt beim nächsten Fork.
Ebenfalls nachgezogen: die Modul-Header der acht v7-Kopien.

**Kleine Korrektur an der Behauptung von vorhin:** der Karten-Blob-Schatten ist im Reiseflug (alt ~16
über Boden ~3) durch den Sonnenversatz UNTER dem Bildrand — geometrisch richtig, aber die
„Höhenauskunft am Boden" trägt erst im niedrigen Flug und im Walk-Modus. Wenn sie im Reiseflug tragen
soll, muss der Versatz mit der Höhe gedeckelt werden (offener Punkt, kein Bug).

- **Dateien:** `terrain-v6/ground-shadow.js` (neu), `terrain-v6/voxel-terrain.js`,
  `terrain-v6/travel-poc.js`.
- **Captures:** `screenshots/02-v6-s15-s18.png` (Flow), `screenshots/01-v6-s15-shadow3.png` (Schatten
  am Boden), `screenshots/02-v6-s15-shadow3.png` (Schatten im Sprung).

## 2026-07-25 · v6 · S10 + S11 erledigt: Modus folgt der Höhe, Rahmen mit Wortmarke

**S10 — der Modus ist kein Schalter mehr, sondern eine Folge der Höhe.**
- **Abheben:** Leertaste zweimal (< 280 ms) am Boden. Kein neuer Zustand in der Sprung-Grammatik —
  der erste Druck hat schon gesprungen, der zweite verlängert ihn: die Karte setzt DORT ein, wo das
  Pet stand (`alt = y + 0.8`), in seiner Blickrichtung, und bekommt ein Steigziel `+12`.
  Vorher setzte `flight.reset()` immer auf Reiseflughöhe 9 — beim Umschalten sprang das Fahrzeug.
  `reset(x, z, alt, heading)` nimmt jetzt beides.
- **Landen:** `X` (oder Pfeil-runter) senkt. Der Wechsel feuert NICHT bei Berührung allein, sondern
  bei **Bodenkontakt + kleiner Sinkrate + Sinkwille, gehalten über `landHold` 0,22 s** — sonst kippt
  ein Streifschuss über einen Cube-Gipfel mitten im Flug in den Laufmodus. Die Hysterese sitzt im
  Flight-Controller (`landSink 7`, `landHold 0.22`, `sinkRate` geglättet mit 8/s), der Runner führt
  nur aus — und erst nach einer Sperrzeit von 0,9 s nach jedem Moduswechsel, sonst pendelt es.
- **`F` bleibt** als direkter Umschalter, dazu ein Schalter „Modus folgt der Höhe" im Overlay: wer
  mit Timing-Fenstern nicht zurechtkommt, braucht einen Weg ohne.
- **Gemessen:** `X` halten → nach **0,7 s** in Walk auf y 5,59 · einzelner Sprung bleibt in Walk ·
  Doppel-Leertaste → Fly, und 0,7 s später ist die Karte bei alt 14,4 auf dem Weg zu Ziel 16,3
  (steigt also, springt nicht).

**S11 — Rahmen.** Oben links die **KayfaBizarro-Wortmarke** direkt aus `themes/kfb-med.css`
(`.kfb-wordmark`: Irish Grover, „Kayfa" in Tinte, „Bizarro" cream auf Akzent, harter Schatten,
leichte Kippung) — kein Nachbau, kein SVG. Oben rechts Titel und Untertitel klein in Special Elite.
Weil die Marke hier über einer bewegten Welt statt auf Papier sitzt, bekommt „Kayfa" einen harten
Cream-Schatten als Kontrastkante; das bleibt im Idiom (Offset, kein Blur).
**Die Modus-Anzeige ist ganz weg** — Badge gelöscht, und der Tacho zeigt nur noch `POV`, wenn die
Kamera im Kopf des Pets sitzt. Das war erst erlaubt, nachdem S10 die Auskunft durch Mechanik
ersetzt hat: man sieht an der Höhe, wo man ist.

- **Dateien:** `terrain-v6/flight-controller.js`, `terrain-v6/travel-poc.js`, `KFB Travel v6.dc.html`.
- **Capture:** `screenshots/v6-s11-frame.png`.

## 2026-07-25 · v6 · Ruhezonen: vier statt einer, und der Boden beruhigt sich beim Sinken

- **Georgs Befund:** idealerweise hüpft der Boden, nicht die Kamera. Die Bob-Reserve war schon vom
  Live-Beat befreit; jetzt kommt die eigentliche Lösung dazu — **die Cubes selbst werden ruhig, je
  näher die Karte kommt**. `groundCalm 0.9`, voller Tanz ab 15 units über Grund, ab 3,5 units still,
  Übergang mit 3/s geglättet, Radius 22.
- **Vier Ruhezonen statt einer.** Der Shader nimmt jetzt `uniform vec4 uZone[4]` (x, z, Radius,
  Stärke) und mischt das Minimum: **Zone 0 folgt dem Fahrzeug** (im Walk der Läufer wie bisher, im
  Flug die sinkende Karte), **Zone 1–3 sind gesetzte Orte** — genau das, was der KFB-Hex-Turm, der
  Graveyard und künftige Landeplätze brauchen, damit große Modelle sauber auf ruhigen Nachbarcubes
  stehen. API: `terrain.setZones([{x,z,r,amt}])`, `terrain.zones`, `terrain.calmAt(x,z)`.
- **Die Bodenfreiheit rechnet jetzt mit der Zone.** `cardClearance` nimmt die Bob-Reserve mal
  `(1 − calmAt)` plus einen festen Sicherheitsabstand von 0,3 — wo die Cubes stehen, braucht die
  Karte keine Höhe für Hübe, die nicht stattfinden. Sie kann also tiefer und ruhiger fliegen, ohne
  dass eine Kartenecke in einen steigenden Würfel schneidet.
- **Gemessen:** Höhe 47 units → Zone 0 bei 0,000 (voller Tanz) · Höhe 9,5 units → 0,897 · gesetzte
  Zone (r 30) liest 1,00 im Zentrum und 0,00 bei 40 units Abstand.
- **Dateien:** `terrain-v6/voxel-terrain.js`, `terrain-v6/travel-poc.js`.
- **Regler:** Sektion „Welt" → „Ruhezone am Boden" (0 = aus … 100 %) plus Live-Anzeige, wie ruhig es
  unter der Karte gerade ist.
- **Zwei Fallen aus dieser Runde, beide teuer, beide billig zu vermeiden:**
  1. **Ein Kommentar hat die nächste Deklaration gefressen.** Beim Edit ging der Zeilenumbruch nach
     dem `uZone`-Kommentar verloren, `varying vec2 vUv;` stand damit hinter `//` — der
     Cube-Vertex-Shader kompilierte nicht mehr und das **ganze Terrain war unsichtbar**
     (Skydome, Karte, Pet und Würfel rendern weiter, es sieht also nicht wie ein Absturz aus).
     Merksatz: in GLSL-Template-Literalen sind Zeilenenden Semantik; nach jedem Edit an einer
     Shader-Deklaration einmal die Konsole lesen.
  2. **`renderer.info.render.triangles` taugt nicht als „rendert das Terrain?"-Test.** Der Zähler
     gilt für den LETZTEN Renderaufruf — bei uns der HUD-Würfel-Pass. Er zeigte 2028 Dreiecke, mit
     und ohne Terrain. Richtig ist: direkt nach `renderer.render(scene, camera)` ablesen.
- **Nach dem Fix visuell nachgemessen** (dieselbe Szene, gleiche `uTime`, nur Zonenstärke 0 vs. 1):
  **36,4 % der Bildpixel ändern sich** — die Zone dämpft also wirklich die Geometrie und nicht nur
  eine Uniform.

## 2026-07-25 · v6 · Ink-Outline der Karte zur Laufzeit regelbar (+ Stil-Hook für Torn/Bend)

- **Was:** Die Outline wurde bisher EINMAL beim Laden in die Kartentextur gemalt (`baseW 6`, hart
  verdrahtet). Jetzt malt `createCardSurface` sie in ein Canvas, das das geladene Kartenbild
  **festhält** — `rig.setInk({ width, wobble, jitter, style })` übermalt nur neu, ein Regler löst
  also keinen zweiten Netzabruf aus. Drei Regler in Sektion „Karten": **Ink-Outline der Pet-Karte**
  (0 = aus … 18 px), **Strich-Unruhe** (der Wobble aus dem v1-Kanon) und **Kanten-Zittern** (der
  Jitter der Perimeter-Punkte).
- **Gemessen:** dunkle Randpixel in den oberen 40 Canvas-Zeilen — 1248 bei Breite 0 (nur das
  Kartenmotiv selbst), 6142 bei 6 px, 12536 bei 14 px. Textur bleibt 800×447 und wird von Ober- und
  Unterseite geteilt (ein Objekt, ein Bild).
- **Stil-Hook für Georgs weitere Outline-Stile:** zwei Tabellen `PERIMETER[style]` und
  `STROKE[style]` — genau die zwei Funktionen, aus denen der v1-Kanon besteht (Punktpfad + Strich).
  `inked` ist belegt; **Torn** (zackig) wäre ein anderer Punktpfad, **Bend** (flaggenartig) eine
  niederfrequente Welle auf demselben Pfad. Sobald die Kanon-Dateien vorliegen, ist das ein
  Tabelleneintrag, kein Umbau. Sky-Karten bekommen eigene Regler, wenn sie eigene Stile tragen.
- **Dateien:** `terrain-v6/card-carrier.js`, `terrain-v6/travel-poc.js`.
- **Capture:** `screenshots/01-v6-ink.png` (2 px) vs. `02-v6-ink.png` (14 px).

## 2026-07-25 · v6 · S14 erledigt: Pet-Beleuchtung (Sky-Environment, Fill, Story-Tint) + Session-Cut

- **Was:** `terrain-v6/pet-lighting.js`. Drei unabhängig schaltbare Bausteine gegen die flache
  Schattenseite: (1) **Sky-Environment** — der Skydome wird pro Story-/Varianten-Wechsel in eine
  PMREM-Map gebacken und als `scene.environment` gesetzt, jedes PBR-Material nimmt die
  Himmelsfarbe auf; (2) **Fill-Light**, kalt (`#bcd4ff`, 0,55) gegen die Sonne, ohne Schatten,
  folgt dem Fahrzeug; (3) **Story-Tint** nach dem Muster aus Rollercoaster v11:
  `mix(base, base·ink, 0.18)` hinter `map_fragment`, also NACH der Textur — die Base-Color bleibt
  erkennbar, das Pet gehört sichtbar zur Welt.
- **Warum vorher flach:** es liefen genau zwei Lampen (Sonne 2,6 + Hemisphere 1,0). Auf der
  Schattenseite arbeitete also nur die Hemisphere, und die hat keine Richtung.
- **Zwei Details, die den Slice tragen:** der Skydome hängt am Kamera-Follow — für den Bake wird er
  auf den Ursprung gesetzt und danach zurückgehängt, sonst backt man eine Kugel mit falschem
  Mittelpunkt. Und der Tint fasst nur `MeshStandard`/`MeshPhysical` an: Augen und Kartenfläche sind
  `MeshBasic` und würden davon nur schmutzig. **Gemessen: 28 von 31 Materialien gepatcht**, die drei
  übrigen sind genau diese Basic-Materialien.
- **Regler** in Sektion „Pet": Himmels-Licht (0–2×), Fill-Licht (0–1,5), Story-Tint (0–50 %).
- **Session-Cut:** `export/travel-v6_2026-07-25/` (Entry + `support.js` + 17 Module + docs + vier
  QA-Bilder + `MANIFEST.md`). **Snapshot, kein Fork** — weitergearbeitet wird in `terrain-v6/`;
  ein v7 lohnt erst, wenn S10–S12 stehen.
- **Dateien:** `terrain-v6/pet-lighting.js` (neu), `terrain-v6/travel-poc.js`.
- **Capture:** `screenshots/01-v6-s14.png` (alles aus) vs. `02-v6-s14.png` (an).

## 2026-07-25 · v6 · Post-Pass ohne Rendertarget, Tanz und Blinken getrennt, weichere Cube-Bewegung

**1. Pet und Karte sahen dauerhaft „ausgeknipst" aus — Ursache war der Umweg über den Puffer selbst.**
Die Farbraum-Korrekturen davor waren nötig, aber nicht ausreichend. Messung (Differenzbild
direkt vs. durch das Rendertarget, 1848×1080): **99 % des Bildes identisch, aber im Kartenbereich
−22/255**, schlechtester Pixel 163 → 74. Eingegrenzt durch Ausblenden: Pet aus → Rest bleibt, Karte
aus → Differenz **0**. Es ist die Karte, genauer ihre `CanvasTexture` (Mips, Aniso 8) auf einem
`MeshStandardMaterial`; im Offscreen-Pfad filtert/kompiliert sie messbar anders, unabhängig von
Farbraum, MSAA-Zahl und Target-Format (alle drei durchprobiert und gemessen).

**Lösung: der Blur braucht kein Rendertarget.** Die Szene rendert wieder **direkt auf den Schirm**,
pixelgleich zu v5. Danach kopiert `copyFramebufferToTexture` das fertige Bild in eine
`FramebufferTexture`, und der Blur liegt als **Overlay** darüber, dessen **Alpha die radiale Maske
ist**: Mitte 0, Rand 1. Verifiziert im Kartenbereich: ohne Pass **107,46**, mit Pass bei Stärke 0
**107,46**, mit Blur 0,09 **107,46** — Δ 0,00. Der Effekt ist damit konstruktiv unfähig, Pet, Karte
oder Tacho anzufassen. **Regel: ein Bildeffekt, der nur den Rand betrifft, gehört als Overlay über
das Bild — nicht als Umleitung des ganzen Bildes.**

**2. Tanz und Blinken sind jetzt zwei Kanäle.** Bisher hing das Leuchten der Cubes an `uBeat`/
`uEnergy`, also am selben Paar wie die Hübe — deshalb blinkten die Cubes weiter, wenn „Cube-Tanz"
auf 0 stand. Neu: eigene Uniforms `uGlowB`/`uGlowE`/`uGlowGain`, und im Overlay (Sektion Rhythmus)
zwei Selects **„Cube-Tanz koppeln an"** und **„Cube-Blinken koppeln an"** mit je vier Stellungen:
Musik + Tempo · **nur Musik (Dancefloor)** · nur Reisetempo · aus. Dazu ein Regler „Blink-Stärke".
Der Himmel hört weiterhin den ganzen Takt, unabhängig von diesen zwei Schaltern.

**3. Weichere Auf/Ab-Bewegung der Cubes** (Georgs Verweis auf three.js `webgl_instancing_dynamic`).
Der Hub lief auf `abs(sin(x))` — am unteren Umkehrpunkt springt dort die Ableitung, das liest sich
als Zucken. Jetzt eine erhobene Kosinuswelle mit Smoothstep-Easing (`rawB²(3−2·rawB)`): stetig in
Wert und Steigung, mit Hänger oben und unten.

**4. Nebenbefund, gleich mitgefixt: die Kamera hüpfte tatsächlich im Takt.** Nicht durch die Cubes
selbst — `groundHeightAt` liefert die statische Säulenhöhe — sondern über `terrain.maxLift()`, das
den LIVE-Beat enthält und in Flughöhen-Reserve und Kamera-Marge einging. Beide lesen jetzt
`maxLift(true)`, das den Beat-Anteil als Mittelwert rechnet. Gemessen: live 2,33 vs. steady 2,43 —
die Reserve atmet nicht mehr mit.

- **Dateien:** `terrain-v6/post-radial.js` (neu geschrieben), `terrain-v6/voxel-terrain.js`,
  `terrain-v6/travel-poc.js`.
- **Capture:** `screenshots/v6-postfix.png`.

## 2026-07-25 · v6 · S2 Runde 3: dünnere Streifen mit weißem Kern, Kondensstreifen an den Kartenecken, Post-Pass-Schalter beseitigt

Drei Punkte aus Georgs Review, mit den TinySkies-Screenshots als Maßstab.

1. **Speedlines dünner, und bei Vollgas heller statt dicker.** Breite jetzt 0,0035–0,0075 (vorher
   0,008–0,018), Breitenwachstum im Boost von ×5 auf ×1,35 zurück. Stattdessen weißt der **Kern**
   aus (`core = 1 − smoothstep(0, halfW·0.55, d)`, gemischt nach Weiß ab `whiteFrom 0.40`) und die
   Deckkraft wächst überproportional (`0.35 + 0.65·f`) — unten ein Hauch, oben ein heißer Strich.
2. **Neu: Kondensstreifen an den hinteren Kartenecken** (`card-contrails.js`, portiert aus
   TinySkies `Contrails.ts`). Zwei Ribbon-Meshes, 72 Segmente, Querachse =
   `cross(Bewegungsrichtung, Blickrichtung zur Kamera)` — das Band bleibt sichtbar, egal wie man
   drumherum fliegt. Ab **20 km/h** (`kmhOn`) fadet es ein, wird mit dem Tempo heller, der dünne
   Kern weiß. Die Anker sitzen in der **Weltmatrix von `rig.lean`**, deshalb zeichnen die Streifen
   Bank, Kippung, Kantencurl und den Barrel-Roll mit — ohne eine eigene Zeile Kinematik.
   Zwei Abweichungen vom Original, beide gemessen nötig: Bandbreite 0,055 statt 0,005 (ihr Flugzeug
   hat 0,22 Spannweite, unsere Karte 3,0), und Punkte werden **strecken-** statt frame-getaktet
   (`minStep 0.10`) — bei 20 km/h lägen sonst 72 Punkte auf zwei Metern, das ist ein Klumpen, kein Band.
3. **Der Lichtschalter ist weg — die Ursache war der Pfadwechsel selbst.** Die Farbraum-Korrektur
   davor war richtig, hat aber nur den großen Sprung beseitigt; es blieb ein Rest, weil der Runner
   zwischen ZWEI Renderpfaden umschaltete: „direkt auf den Schirm" (Blur 0) und „durch den Puffer".
   Zwei Pfade sind nie pixelgleich — gemessen in der Bildmitte (wo Pet und Karte sitzen, dort blurrt
   der Pass gar nicht): direkt **66,97**, durch den Puffer **62,90**. 4 von 255 in EINEM Frame liest
   sich als Lichtschalter, genau wie beschrieben. **Jetzt läuft der Pass immer**, bei Stärke ~0 mit
   einer Ein-Tap-Abkürzung im Shader (Kosten praktisch null). Nachgemessen: Blur 0 und Blur 0,09
   liefern in der Mitte **denselben** Wert (62,90) — es gibt keinen Umschaltmoment mehr.
   Der verbleibende konstante Unterschied von ~6 % gegenüber dem alten Direktpfad kommt vom
   MSAA-Resolve (der Schirmpuffer linearisiert beim Auflösen, ein RGBA8-Target nicht) und ist als
   Konstante unsichtbar. **Regel: nie zwischen Renderpfaden umschalten, während das Bild läuft.**
- **Regler dazu** in „Boost & FX": Kartenecken-Streifen an/aus, „Streifen ab" (km/h-Schwelle),
  Eckstreifen-Breite.
- **Dateien:** `terrain-v6/card-contrails.js` (neu), `terrain-v6/speed-lines.js`,
  `terrain-v6/post-radial.js`, `terrain-v6/card-carrier.js` (`lean` exportiert),
  `terrain-v6/travel-poc.js`.
- **Captures:** `screenshots/01-v6-trails.png` (Reisetempo, Kurve), `screenshots/02-v6-trails.png`
  (Vollgas: dünne Streifen mit weißem Kern + Eckstreifen).
- **Offen:** die Eckstreifen sind bei Reisetempo dezent bis fast unsichtbar (so gewollt) — wenn
  Georg sie früher sehen will, ist es `kmhOn` bzw. die Breite, kein Code.

## 2026-07-25 · v6 · S2 nachgeschärft: Streifen aus dem Original, Rolle für Karte + Pet, Farbraum-Bug

Georgs Review der ersten S2-Fassung, drei Befunde — alle drei berechtigt, alle drei behoben.

1. **„Speedlines sehen unecht, klobig, eckig aus."** Ursache: wir hatten die Streifenform in die
   GEOMETRIE gelegt (Rechteck, harte Kante, Alpha pro Vertex). Im Original steckt sie im
   Fragment-Shader. Jetzt 1:1 portiert aus TinySkies `client/src/game/SpeedLines.ts` (2659a5cc):
   `taper = smoothstep(0,0.25,u)·smoothstep(1,0.75,u)`, `halfW = taper·0.35`,
   `shape = 1 − smoothstep(halfW·0.3, halfW, |v−0.5|)` → eine **Spindel mit weichem Rand**, ein
   Strich statt eines Bretts. Zweiter Unterschied, genauso wichtig: das Quad sitzt **mittig auf dem
   Rand-Radius** und ragt ±Länge/2, liegt also größtenteils außerhalb des Bildes — sichtbar ist nur
   die auslaufende Spitze. Deshalb legt sich nie ein Streifen über Karte oder Pet, und die
   Report-Werte (Länge 0,35–0,84, Breite ×5 im Boost) stimmen plötzlich alle.
   Unser Abweichen bleibt bewusst: **ein Draw-Call** (eine Geometrie, `aUv`/`aLife` als Attribute)
   statt 24 Meshes, Spawn nur in FREIE Slots, Pool 32.
2. **Barrel-Roll dreht jetzt das Fahrzeug, nicht das Pet.** Der Winkel entsteht weiter in
   `pet-kinetics.js`, angewandt wird er in `card-carrier.js` (`rig.setBarrelRoll`) — direkt nach
   `group.quaternion.copy(st.quaternion)` und damit **vor** Lean und Fuß-Clip-Ebene. Karte und Pet
   rollen gemeinsam um die Karten-Mitte, physikalisch plausibel (Fahrzeug rollt, Passagier fährt mit).
   Hätte man den Roll nach `sync()` aufgesetzt, würde die aus `lean` gebaute Clipping-Ebene während
   der Rolle in die alte Richtung zeigen und das Pet anschneiden.
3. **„Aufhellen/Abdunkeln wie ein Lichtschalter" war ein echter Bug, kein Effekt.** Doppelte
   sRGB-Kodierung: die Szene wurde in ein Target geschrieben, das three bereits kodiert, und unser
   Fullscreen-Shader kodierte per `<colorspace_fragment>` ein zweites Mal. **Gemessen** (Pixel-
   Mittelwert, 1848×1080): direkt **82,7** → durch den Pass **144,0**. Genau der Sprung in dem Frame,
   in dem der Pass anspringt. Fix: das Target ist jetzt exakt das, was der Schirm auch wäre
   (`UnsignedByteType` + `SRGBColorSpace`, MSAA 4), der Shader schreibt unverändert durch.
   **Nachgemessen: 92,88 direkt → 92,41 durch den Pass → 92,26 mit Blur 0,09** — Delta 0,5 von 255,
   also unsichtbar. Der Blur mittelt jetzt in sRGB statt linear; für einen Zoom-Blur ist das der
   übliche und optisch unauffällige Kompromiss.
- **Streifen-Look als Regler:** Default ist `light` — additiv in der **Panel-Farbe** der Story
  (Cremeweiß), nicht in reinem Weiß. Das ist der TinySkies-Read in KFB-Farbe. Die Bloom-Sorge aus
  Embed-Doc §15 gilt hier nicht: dieser Pass läuft NACH der Szene und kann kein Szenen-Objekt
  überstrahlen. `ink` (Story-Tinte, normales Blending) bleibt als Comic-Variante im Overlay.
- **Dateien:** `terrain-v6/speed-lines.js` (neu geschrieben), `terrain-v6/post-radial.js`,
  `terrain-v6/card-carrier.js`, `terrain-v6/pet-kinetics.js`, `terrain-v6/travel-poc.js`.
- **Captures:** `screenshots/01-v6-s2c.png` (Look „Licht"), `screenshots/02-v6-s2c.png` (Look „Tinte"),
  `screenshots/01-v6-s2b.png` (Karte + Pet mitten in der Rolle).
- **Nebenbei:** Overlay-Kopf sagte im v6-Build noch „KFB TRAVEL V5" — Zeile behoben und als
  `eyebrow`-Option herausgezogen, damit sie beim nächsten Fork nicht wieder lügt.

## 2026-07-25 · v6 · S2 erledigt: Speedlines, Radial-Blur, Barrel-Roll — der Boost ist ein Ereignis

- **v6 angelegt** als Fork von v5: `KFB Travel v6.dc.html` → `terrain-v6/` (15 Module). v5 ist FROZEN.
  Neuer Sprintplan `docs/SPRINT_travel-v6.md`; der v5-Plan behält die Grundrisse der offenen Slices.
- **Was:** Fünf Stimmen am selben Regie-Skalar plus einem Boost-Impuls (`boostPulse`, Einsatz 9/s,
  Auslauf 2,2/s): **Speedlines** (`speed-lines.js`, Pool 24 Quads, Story-Ink, NormalBlending,
  Deckel 0,35) · **Radial-Blur** (`post-radial.js`, Zoom-Blur, 10 Taps, Mitte scharf) ·
  **Barrel-Roll** (genau eine 360°-Drehung pro Einsatz, danach exakt 0) · **Kamera** (Dolly +0,6,
  Höhe +0,15, FOV bis 73,7°) · **Lenk-Autorität** `boostYawGain 1.28`.
- **Warum der Blur hierhin gehört:** Georgs WebGPU-Beispiel ist nicht portierbar, der Effekt aber ein
  trivialer Fullscreen-Pass — und ein radialer Blur an `heat` IST die Boost-Regie, kein zweites
  System. Bei Stärke 0 rendert die Szene direkt auf den Schirm: kein Puffer, volles MSAA, keine
  Kosten in Ruhe.
- **Render-Reihenfolge ist jetzt Kanon:** Szene → `post.render()` → `lines.render()` → `hud.render()`.
  Verifiziert am Bild: bei Blur 0,106 ist der Tacho-Würfel scharf.
- **Farbraum, damit es nicht kippt:** Rendertarget bleibt linear (HalfFloat, MSAA 4), der Blur mittelt
  linear, `<colorspace_fragment>` konvertiert erst am Schirm — wie three's OutputPass. Screenshot
  mit und ohne Pass zeigt keinen Helligkeitssprung.
- **Drei Report-Zahlen am Bild korrigiert** (Merksatz „Textur-Schrift ist keine DOM-Schrift" gilt
  analog für Bildraum-Maße): Streifenbreite 5× → 2,6× (5× wären 34 px = Brett), Länge 0,84 → 0,55
  plus `rInMin 0.40` (vorher legten sich Streifen über Pet und Karte), und die inneren Ecken tragen
  nur 8 % Deckkraft, damit der Streifen ausläuft statt abzubrechen.
- **Der Kurven-Drag aus dem Report existiert bei uns nicht** — Lenken kostet kein Tempo. Statt einen
  Drag einzubauen, nur um ihn im Boost abzuschalten: mehr Lenk-Autorität während des Boosts. Gleiche
  Absicht, keine erfundene Mechanik.
- **Gemessen** (924×540, HEROIC): Ruhe `heat 0.039` · 6 km/h · 0 Streifen · Blur 0 (Pass übersprungen)
  · FOV 54,5°. Vollgas `heat 0.986` · 75 km/h · 24 Streifen · Deckkraft 0,35 · Blur 0,106 · FOV 73,7°
  · Roll 6,21 rad nach 0,85 s → 0. Nach dem Loslassen alles zurück auf null (der Gleitflug braucht
  ~8 s, nicht die FX).
- **Neue Overlay-Sektion „Boost & FX"** zwischen Reise und Welt: Speedlines an/aus, Dichte, Deckkraft,
  Radial-Blur, Barrel-Roll, Lenken im Boost, Live-Werte. S3–S6 sind damit am Bild justierbar.
- **Offen:** Pool ist bei Vollgas mit 24 Streifen ausgeschöpft — wenn dichter gewünscht, Pool auf 40
  heben, nicht die Lebensdauer kürzen (sonst flackert es).
- **Dateien:** `terrain-v6/speed-lines.js` (neu), `terrain-v6/post-radial.js` (neu),
  `terrain-v6/travel-poc.js`, `terrain-v6/pet-kinetics.js`, `terrain-v6/flight-controller.js`,
  `KFB Travel v6.dc.html`, `docs/SPRINT_travel-v6.md`.
- **Captures:** `screenshots/01-v6-s2-boost.png` (Einsatz), `screenshots/02-v6-s2-boost.png` (Vollgas).

## 2026-07-25 · v5 · Blauer Screen behoben (Waisen-Stage) + Würfel wächst beim Anfassen

**Bug: leerer blauer Screen, den nur ein Reload heilte.** Ursache gefunden statt weggeklickt: der
DC-Runtime ersetzt bei einem Template-Re-Render den `#tv-stage`-Knoten. Der Canvas hing danach an
einem **Waisen-Stage** — `parentElement` zeigte weiter auf „tv-stage", `document.contains()` war
false, `__travelPOC` lief samt Frame-Schleife weiter und rendert in ein Nichts. Reload half nur, weil
der Boot dann zufällig nach dem letzten Re-Render lag.

- **Fix:** Re-Attach-Wache in `travel-poc.js`. Alle halbe Sekunde `document.contains(canvas)` prüfen;
  wenn nein, das aktuelle `#tv-stage` holen und Canvas, Badge, Overlay und Hinweiszeile dort
  wieder einhängen, danach `resize()` und Kamera-Snap. Alle Größen lesen jetzt `liveStage`, nicht
  mehr das beim Boot gefangene Element.
- **Verifiziert** durch Erzwingen des Fehlers: Stage-Knoten ersetzt → `canvasInDoc: false` → nach
  900 ms `true`, am neuen Knoten, Overlay mit, 924×540.

**Würfel: klein als Instrument, groß als Menü** (S12 Teil 1, mit Georg abgestimmt).
`restScale 0.67`, Feder `growStiff 12`, `menuHold 2.2 s`. Gemessen: 131 px → 196 px → 131 px.
Auslöser: Hover, Drag, `spinTo()`.

- **Folge, sofort mitbehoben:** bei 131 px ist die Tacho-Seite nur ~58 px breit, die Zahl wäre auf
  12 px gefallen. Der Tacho hat jetzt zwei Fassungen — kompakt im Ruhezustand (Zahl `0.28·S`,
  größere Nadel, vier Teilstriche, kein `km/h`, kein Modus-Text), vollständig ab `grow > 0.45`.
- Neue Debug-Getter: `hud.sizePx`, `hud.growth`.

**Strahlen-Frage beantwortet (S13 im Sprintplan).** Das WebGPU-Radial-Blur-Beispiel ist nicht
portierbar — Travel läuft WebGL2 — aber der Effekt ist ein trivialer Fullscreen-Pass und gehört in
S2 (Speedlines), nicht in einen eigenen Slice. Skydome-Würfel brauchen dagegen SelectiveBloom (kein
Fullscreen-Pass kann ein Einzelobjekt umstrahlen), Leuchtturm-Karten einen additiven Kegel
(„Fake-Volumetric"), nicht echtes Raymarching. Notiert: sobald ein Post-Pass läuft, muss
`hud.render()` **dahinter** kommen, sonst wird der Tacho mitgeweichzeichnet.

## 2026-07-25 · v5 · Session-Cut, Check-in, Übergabe an v6

- **v5 geschlossen** mit S0, S1 (`travelHeat`), S7 (HUD-Würfel), S8 (Settings-Overlay). Dateien:
  `KFB Travel v5.dc.html` + `terrain-v5/` (13 Module).
- **Export:** `export/travel-v5_2026-07-25/` mit `MANIFEST.md`.
- **Neue Slices aus Georgs Review aufgenommen** (alle → v6):
  **S10** Modus ohne Schalter (WoW-Logik: Doppel-Leertaste abheben, `X` sinken, Bodenkontakt → Walk) ·
  **S11** Rahmen (KayfaBizarro-Wortmarke links aus `themes/kfb-med.css`, Meta klein rechts,
  Modus-Anzeige weg) · **S12** Würfel v2 (ein Drittel kleiner, kein ALLCAPS, Special Elite,
  Abnutzungs-Decal, Grundfläche in der aufgehellten Pet-Base-Color).
- **Zwei Abhängigkeiten notiert:** S11 darf die Modus-Anzeige erst streichen, wenn S10 steht (sonst
  fehlt die Auskunft ohne Ersatz). Und S12 senkt die Label-Größe von 18 px auf 12 px — trägt erst mit
  Georgs Icon-PNGs oder mit einem Würfel, der im Menü-Zustand wächst.
- **Nächster Sprint v6:** S2 (Speedlines + Boost) zuerst, dann S10–S12.

## 2026-07-24 · v5 · S8 erledigt: Settings-Overlay + konsolidierte Steuerung

- **Was:** `terrain-v5/settings-overlay.js`. Fast flächendeckendes Papier-Panel, das seine Sektionen
  als Daten vom Runner bekommt; das Spiel läuft dahinter weiter. Acht Cluster nach Häufigkeit:
  Karten (Story-Modus) · Rhythmus (BPM, Beat-Kopplung) · Reise (Fly⇄Walk, Tempi, Kamera, POV,
  Tacho-Eichung, Live-Werte) · Welt (fünf Terrain-Regler, Rebake debounced) · Himmel (zehn Varianten,
  Welt-Mischung, Belichtung, Spirale) · Pet (alle Pets aus dem Vertrag, altes wird disposed) ·
  Steuerung (Legende beider Modi) · System (Seed, Auflösung, Reset).
- **HUD aufgeräumt:** die zwei Legenden-Blöcke sind weg, das Badge zeigt nur noch `FLY`/`WALK`, dazu
  eine Hinweiszeile, die nach 8 s ausblendet und ab der zweiten Sitzung gar nicht mehr erscheint.
- **Story-Modus ist jetzt live schaltbar** — neuer WorldContext, Terrain rebaked, Himmel und Würfel
  in der neuen Palette. Verifiziert mit FORBIDDEN: `storyIdx 5`, Nebel `#503550`, Würfel-Nadel in
  Wein. Capture: `screenshots/v5-forbidden.png`, Overlay: `screenshots/v5-settings.png`.
- **Pet-Wechsel** läuft über denselben Pfad wie der erste Mount (ein Pfad, kein Sonderfall);
  verifiziert mit `fox`.
- **Zwei Fallen:** (1) das Overlay liest beim Bauen alle Werte → `zoomTarget` war weiter unten
  deklariert und riss den Boot mit `ReferenceError: Cannot access 'zoomTarget' before initialization`
  ab; Kamera-Zustand steht jetzt vor dem Overlay. (2) Tasten müssen dem Formular gehören, solange es
  offen ist — sonst fliegt die Karte, während man den Seed tippt.
- **Nachgezogen:** Akzentfarbe läuft jetzt über eine Custom-Property am Root (`--kfb-accent`) statt
  inline eingebacken — vorher blieben Slider-Thumbs und Live-Werte nach einem Story-Wechsel orange in
  einem weinroten Panel. `setAccent()` zieht alles mit einem Zuweisen nach.
- **Dateien:** `settings-overlay.js` (neu), `travel-poc.js`, `flight-controller.js`,
  `walk-controller.js`, `travel-heat.js` (je `setParams`/`params`), `KFB Travel v5.dc.html`.

## 2026-07-24 · v5 · Würfel: Texturen auf der Geometrie statt Planes davor

- **Georgs Befund:** „als wären die Flächen einfach sichtbar davor platziert, dadurch gehen die
  abgerundeten Ecken verloren“. Genau so war es: sechs `PlaneGeometry` vor den Würfelseiten —
  aufgeklebte Schilder, deren eckige Ecken über die gerundete Silhouette ragten (gemessen 2–3 px).
- **Fix:** ein Mesh, sechs Materialien. `RoundedBoxGeometry` erbt von `BoxGeometry` und damit deren
  sechs Material-Gruppen und UVs — die Textur sitzt also direkt auf der gerundeten Fläche. Klick
  läuft jetzt über `intersection.face.materialIndex` statt über Plane-Meshes.
- **Preis, bewusst bezahlt:** die UV einer Seite schließt die Rundkante ein → Inhalt braucht 12 %
  Sicherheitszone (`hud.safeZone`). Steht als Vorgabe für die Procreate-PNGs im Sprintplan.
- **Gemessen nach dem Umbau:** Seite 107 px auf dem Schirm, Label 18,2 px, km/h 12,3 px; Worst Case
  (Spin + maximale Neigung) NDC 0,825 — vorher schnitt der Spin die Silhouette an (1,000).
- **Capture:** `screenshots/v5-hud-cube.png`.

## 2026-07-24 · v5 · Würfel rahmenlos + Tacho-Nadel, drei Walk-Bugs

**Würfel (Georgs Review):**
- Rahmen weg. Flächen sind durchgehend, Schrift und Icon sitzen direkt auf dem Papier (Fläche 0,955
  der Seite, Korpusfarbe = Flächenfarbe). Der schwarze Rahmen ist damit frei für seine echte
  Aufgabe: unsichtbare Clip-Maske für Embeds (S9).
- Oberfläche: `Textures/Paper003` (seamless, leichtestes Set) als `normalMap` + `roughnessMap` —
  der Würfel wirkt nicht mehr wie glattes Plastik. `edge3` wäre falsch: Rand-Textur, kachelt nicht.
- Tacho ist jetzt eine **Nadel-Anzeige** (Halbkreis, acht Teilstriche, letzte zwei als Redline,
  Zeiger auf `travelHeat`). Damit ist auch der Rest-Balken bei 0 km/h weg — die Nadel steht am
  linken Anschlag.

**Bugs:**
1. **Beim Wechsel in den Walk-Mode im Cube gelandet.** Ursache: `walk.reset` bekam EINE
   Höhenprobe aus der Mitte — hüpfende Nachbarsäulen und der Körperradius waren nicht drin. Jetzt
   `safeGroundAt()` (Mitte + 8 Ringproben) plus `terrain.maxLift()` und 0,25 Reserve; die Schwerkraft
   setzt das Pet dann sauber ab. Zusätzlich pro Frame eine **Rettung**: steckt das Pet trotzdem
   tiefer als die Umgebung, hebt `walk.lift()` es auf die Oberfläche.
2. **Pet zeitweise unsichtbar.** Zwei Ursachen, beide behoben: der Kamera-Aufzug
   (`groundHeight + 1`) konnte die Kamera über das Pet heben, sodass sie in den Himmel schaute —
   jetzt gibt es eine Obergrenze, und statt höher wird die Kamera **näher** herangezogen. Und der
   POV-Modus (Zoom bis 0) versteckt das Pet absichtlich, sagte es aber nicht: der Tacho zeigt jetzt
   `WALK·POV` bzw. `FLY·POV`. POV-Blick außerdem weniger steil nach oben.
3. **Roter Rest-Balken bei 0 km/h.** Erledigt mit der Nadel (siehe oben).

- **Dateien:** `terrain-v5/hud-cube.js`, `travel-poc.js`, `walk-controller.js` (`lift()`).
- **Capture:** `screenshots/v5-walk-cube.png`.

## 2026-07-24 · v5 · S7 erledigt: HUD-Würfel

- **Was:** `terrain-v5/hud-cube.js`. Terrain-Würfel unten rechts, zweiter Render-Pass im
  Scissor-Viewport. Ruhezustand = Tacho (geeichte km/h + Modus + Heat-Balken), angefasst = Menü mit
  sechs Funktionsseiten (Karten, Musik, Welt, Himmel, Pet; die Tacho-Seite ist der Reise-Knopf).
  Oberfläche ist die **geteilte Kanten-Textur** aus `voxel-terrain.js` → sichtbar aus derselben Welt.
- **Aus der Academy portiert:** RoundedBox mit Fallback, CanvasTexture pro Seite, Slerp-Targeting,
  Drag-Trägheit. Neu: Rückkehr in die Tacho-Position nach 2,5 s, aufrechte Beschriftung über
  `texture.rotation`, Neigung gegen Bank und `heat.rate`.
- **Zwei Fallen, die beim Bauen auffielen:** `stopPropagation()` reicht nicht, wenn zwei Listener am
  SELBEN Element hängen (AT_TARGET) — jetzt `stopImmediatePropagation()` plus `e.__hudClaimed`-Marke,
  die travel-poc prüft (verifiziert: Würfel-Drag lenkt nicht mehr). Und: frontal gerastet liest sich
  ein Würfel als Rechteck — jede Rast-Position trägt jetzt dieselbe leichte 3/4-Neigung.
- **HUD:** Tastenlegende nach unten links verschoben (Kollision) — sie verschwindet mit S8.
- **Dateien:** `terrain-v5/hud-cube.js` (neu), `travel-poc.js`, `voxel-terrain.js` (`edgeTex`
  exportiert), `KFB Travel v5.dc.html` (Legende links).
- **Nachjustiert nach Messung:** Beschriftung war mit `0.082·S` nur 7 px groß (die Fläche ist auf dem
  Schirm ~90 px breit) → Labels `0.15·S`, km/h und Modus `0.105·S`, `minSize` 168 → gemessen 16,6 px
  bzw. 12 px. Und bei hartem Bank ragte die Würfelecke aus dem Scissor-Viewport (NDC 1,03) →
  Neigungs-Clamps auf ±0,16 / ±0,12, Mini-Kamera auf `z = 3.25` → Worst Case jetzt NDC 0,77 / 0,81.
  **Merksatz:** Textur-Schrift ist keine DOM-Schrift — vorher ausrechnen, wie viele Bildschirm-Pixel
  eine Textur-Einheit hat.

## 2026-07-24 · v5 · S7 revidiert: three.js statt CSS-3D (Cube Academy als Vorlage)

- **Auslöser:** Georg hat die **KFB Cube Academy v1** hochgeladen (`uploads/KFB Cube Academy v1/`) —
  dort ist die Würfel-Mechanik fertig gebaut, und zwei neue Anforderungen kamen dazu: Design 1:1 wie
  die Terrain-Cubes (Borders + Kanten-Textur) und der Ugur-D6 für Quest/Story.
- **Entscheidung gedreht:** CSS-3D scheidet aus — die Terrain-Optik ist ein `ShaderMaterial` mit
  `uEdge`, kein CSS-Effekt, und der D6 ist ein GLB. Also **three.js-Overlay** (eigene Szene, zweiter
  `render()` mit `autoClear=false`, Raycast für Klicks).
- **Aus der Academy übernommen:** `RoundedBoxGeometry(D,D,D,6,D*0.07)` mit `BoxGeometry`-Fallback ·
  `CanvasTexture` pro Seite (`anisotropy = 8`) · `quaternion.slerp(target, 1−0.0022^dt)` mit
  `angleTo < 0.004` als Abbruch · Drag-Trägheit `0.045^dt`, danach Eigen-Tumbeln.
- **Der wichtigste Trick von dort:** Embeds laufen **nicht auf der Würfelfläche**, sondern in einem
  DOM-Overlay mit `<iframe>`; die Fläche trägt nur das gemalte Vorschaubild. Scharfe Schrift, echte
  iframes, keine Textur-Unschärfe. Wird als **S9 (Monitor-Würfel)** eigener Slice: YouTube,
  three.js-Demo, LLM-Chat, skalierbar.
- **Drei Register statt zwei:** Werkzeug (Terrain-Voxel + PNG-Decal) · Orakel (Ugur-D6, Würfelaugen) ·
  Monitor (Glas-Seite + Overlay).
- **Backlog ergänzt:** Graveyard-Slice + Kenney-Assets ins Terrain streuen — viel später, eigener
  Sprint; Playbook liegt in der Academy-Zip.

## 2026-07-24 · v5 · Karte schneidet nicht mehr in hüpfende Cubes

- **Was:** Die Flughöhe war an EINER Höhenprobe in der Fahrzeugmitte geklemmt — die Karte ist aber
  3.0 × 1.68 groß und bankt, und die Cubes hüpfen nach oben. Ergebnis: die Ecken schnitten in
  steigende Würfel. Jetzt tastet `cardClearance()` die ganze Grundfläche ab (Mitte + 4 Ecken),
  einmal an der aktuellen und einmal an der voraus liegenden Position (`1.2 + speed·0.22`), nimmt
  den schlechtesten Fall und rechnet Bob-Reserve (`terrain.maxLift()`) plus den Tiefgang der
  untersten Ecke (`sin(bank)·halfW + sin(pitch)·halfD`) drauf. Steigen schnell (14/s), Sinken
  langsam (2,2/s).
- **Warum keine Physik-Engine:** Wir brauchen keine Kollisionslösung, nur eine ehrliche Bodenhöhe.
  Zehn Noise-Proben pro Frame kosten nichts; eine Engine würde Broadphase, Körper und Solver für
  ein Problem einführen, das eine Höhenfunktion schon beantwortet.
- **Dateien:** `terrain-v5/travel-poc.js`, `terrain-v5/card-carrier.js` (`halfW`/`halfD` exportiert).
- **S7 präzisiert:** Tacho ist die **Startposition** des Würfels (Rückdrehung nach ~2,5 s Ruhe),
  Beschriftung kontert die Drehung (Smartphone-Logik), `spinTo(face)` von Anfang an vorsehen
  (später Story-Mode-Wurf und Quest-Fortschritt). Design-Empfehlung: **ein Objekt, zwei Register** —
  Terrain-Voxel = Werkzeug, Sky-D6 = Orakel, der Spin-Flip ist der Übergang.

## 2026-07-24 · v5 · S1 erledigt: Regie-Skalar `travelHeat`

- **Was:** `terrain-v5/travel-heat.js`. Eine geglättete 0..1-Zahl plus Ableitung plus geeichte
  km/h-Anzeige. Reisetempo belegt die unteren 17 % der Skala, darüber `t·(2−t)`; Boost hebt auf
  mindestens 0,72, Sprungphase im Walk +0,10.
- **Warum:** Ohne diese Zahl bekommt jeder FX-Slice eine eigene Speed-Formel. Kamera-Dolly,
  Kamerahöhe, Look-Ahead, FOV (Flug + Walk), Walk-Chase-Abstand und Terrain-Energie hängen jetzt
  daran — die alten `st.speed`-Formeln sind ersetzt, nicht ergänzt.
- **Tacho-Eichung:** `unitMeters = 0.5` (ein Cube = 3 units ≈ 1,5 m). Gehen ≈ 10 km/h, Sprint
  ≈ 17 km/h, Reiseflug ≈ 16 km/h, Vollgas ≈ 76 km/h. Der alte Ride-Tacho log, weil genau diese
  eine Zahl fehlte.
- **Dateien:** `terrain-v5/travel-heat.js` (neu), `terrain-v5/travel-poc.js`.
- **Neu im Plan:** S7 (HUD-Würfel als Instrument + Menü, CSS-3D) und S8 (Settings-Overlay,
  konsolidierte Steuerungs-Legende). Empfohlene Reihenfolge ist jetzt S1 → S7 → S8 → S2…, weil das
  Panel die Tuning-Oberfläche für die FX-Slices ist.

## 2026-07-24 · v5 · Fork angelegt, Sprintplan persistiert

- **Was:** `KFB Travel v5.dc.html` + `terrain-v5/` als Fork des v4-Session-Cuts. v4 ist FROZEN.
  Sprintplan `docs/SPRINT_travel-v5.md` mit sechs Slices (Regie-Skalar → Speedlines/Boost →
  Rim-Light → FX-Pool → Story-Presets → Modus-Tor), Arbeitsregeln für frische Chats, Backlog und
  einer Liste bewusst verworfener Ideen.
- **Warum:** Die TinySkies-Analyse soll additiv über mehrere Chats abgearbeitet werden, ohne dass
  Kontext verloren geht oder v4 kaputt geht.
- **Dateien:** `KFB Travel v5.dc.html`, `terrain-v5/*` (9 Module + `edge3.jpg`),
  `docs/SPRINT_travel-v5.md`, `docs/CHANGELOG_travel.md`.
- **Nebenbei gefixt:** HUD lag hinter dem Canvas (`#tv-hud` ohne `z-index`) — jetzt `z-index:4`.
- **Offen:** S1 (`travelHeat`) ist der nächste Schritt und Voraussetzung für S2–S4.

## 2026-07-24 · v4 · Analyse TinySkies / GlobeFly

- **Was:** 13 Module aus `dannylimanseta/tinyskies@2659a5cc` im Detail gelesen, Report als
  `KFB TinySkies Analyse.dc.html`: Ampel-Inventar, sieben Übernahme-Bausteine mit konkreten Werten,
  fünf bewusste Nicht-Übernahmen, Sechs-Schritt-Reihenfolge.
- **Befund, der eine Erwartung korrigiert:** Es gibt dort keinen Partikel-Wirbel am Boost. Der
  Boost ist Barrel-Roll + zurückfallende Kamera + FOV-Weitung + verbreiterte Speedlines, alles an
  *einer* normalisierten Speed-Zahl. Der echte Swirl-Shader sitzt im Teppich-Portal.
- **Achtung beim Klonen:** Default-Branch ist `cursor/globefly-multiplayer-globe-flight-game`,
  nicht `main` — naive Repo-Zugriffe laufen ins 404.

## 2026-07-24 · v4 · Session-Cut + Pfad-Hygiene

- **Was:** Teil-Export nach `session-export_v1` (17 Dateien, alles < 2 MB, `MANIFEST.md` dabei).
  Pet-Stack läuft kanonisch über jsdelivr (lokaler Spiegel nur Fallback), Kartenrücken über
  `raw…/media/kfb/`, Kanten-Textur RAW-first.
- **Offen:** `edge3.jpg` (2,5 KB) liegt noch nicht im Repo → gehört nach
  `media/3D_Assets/Textures/edge3.jpg`; bis dahin greift der lokale Fallback und die Datei reist im
  Export mit.
- **Stolperstein für später:** Beim RAW-first-Fallback müssen die Bilddaten im `onLoad` des
  Fallback-Loaders übernommen werden, nicht synchron im `onError` des ersten — sonst ist
  `t.image` noch `undefined` und die Konsole spammt „Texture marked for update but no image data".
- **Altlast, in v5 gefixt:** `#tv-hud` lag ohne `z-index` im gleichen Stacking-Kontext wie das
  `<canvas>` → das HUD (Titel, Tastenblock) war komplett unsichtbar, nur die Mode-Badge mit
  `z-index:5` kam durch. In v4 steht der Fehler noch (FROZEN, bewusst nicht angefasst).

## 2026-07-24 · v4 · Achsen, Auto-Hop, Cartoon-Kinetik

- **Was:** Drei Fehler und ein Feature.
  1. **Achsen entdreht:** `heading += turn` (war `−=`) und `right = cross(forward, up)` — A/D und
     Q/E waren im Walk-Mode seitenverkehrt.
  2. **Auto-Hop:** Körper-Radius 0,55 in der Kollision (das Pet lief vorher in den Cube hinein) und
     ein vorausschauender Absprung: gezündet, solange die Kante eine Steigzeit entfernt ist,
     Absprunggeschwindigkeit auf die nötige Höhe gerechnet (`v = √(2g·(rise+0.55))`), davor ~90 ms
     Windup. Kanten über 4,2 gelten als Wand → sliden statt springen.
  3. **Frame-Reihenfolge:** `pet.update(dt)` lief NACH unserer Kinetik — PetMotion hat den Lean
     jedes Frame weggedämpft. Jetzt Motor zuerst.
  4. **Cartoon-Grammatik für beide Modi:** Anticipation-Duck → Launch-Pop → Stretch beim Steigen →
     Apex-Hang → Fall-Stretch → Land-Squash ∝ Aufprall → Rebound-Overshoot → Ruhe. Squash jetzt
     volumenerhaltend (`Sxz = 1/√Sy`) statt Näherung. Dazu der GLB-Clip-Layer: idle/walk/run mit
     `timeScale` an der echten Bodengeschwindigkeit (keine rutschenden Füße), `static` in der Luft,
     `initParts()` für Ohren- und Schweif-Federn.
- **Dateien:** `terrain-v4/walk-controller.js` (neu), `pet-kinetics.js` (neu), `travel-poc.js`.
- **Kanon:** `cartoon-motion_v1.md`, `EMBED_CUBE_PET_FULL_v2.md` §5/§7f.

## Vorgeschichte (vor diesem Changelog)

Slice 1 Flug · Slice 3 Terrain/Welt (deterministischer v3-Seed, ein Story-Mode) · Slice 4
Walk-Controller + Fly⇄Walk-Switch. Details in `HOUSEKEEPING.md`, Abschnitt „KFB Travel v4".

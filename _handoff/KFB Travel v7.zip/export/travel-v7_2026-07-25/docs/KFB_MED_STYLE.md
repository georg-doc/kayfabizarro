# KFB / MED — Style-System

**Stand:** 2026-07-12 · **Quelle:** CLAUDE.md des KFB-3D-Table-Projekts (autoritativ) · **Datei:** `themes/kfb-med.css`

Verbindliche Design-Sprache für **KayfaBizarro (Freestyle)** und die **MED / Clinical Edition**. Referenz für das Table-UI und alle künftigen KFB-Oberflächen.

---

## 1. Provenienz — autoritativ

Die Werte stammen **1:1 aus der konsolidierten UI-Kit in `CLAUDE.md`** (dort „UI-Kit von kayfabizarro.pages.dev konsolidiert"). Das ist der verbindliche Stand.

> **Korrektur ggü. erster Fassung:** Eine frühere Ableitung ging von *dunkler Bühne + Skew-Buttons* aus. Das ist **ersetzt**. Die echte Kit ist: **helles Papier**, **harter Offset-Schatten ohne Blur**, **Radius 0**, **Irish-Grover-Buttons mit Rotate-Hover**, alles **leicht rotiert** (−1° bis 2°), nie steril gerade. (Der dunkle `#100e0b`-Hintergrund in den Table-DCs ist der 3D-Bühnengrund, **nicht** die 2D-UI-Kit.)

---

## 2. Tokens (CSS Custom Properties)

Alle in `:root` in `themes/kfb-med.css`.

- **Papier (hell):** `--kfb-paper #f3ead3`, `--kfb-paper-2 #ece1c0`, `--kfb-paper-3 #e3d5af` (Matte), `--kfb-card #f7f0da`
- **Tinte:** `--kfb-ink #1f1a14`, `--kfb-ink-2 #3a342a`, `--kfb-ink-mute #6f6450`, `--kfb-ink-faint #a89a78`
- **Kanten:** `--kfb-border #d8c79c`, `--kfb-border-hi #c2ad79`
- **Akzente:** `--kfb-accent #b8361f`, `--kfb-gold #8a6a16`, `--kfb-teal #2f7a72`, `--kfb-cream #f6efd9` (Text auf Akzent), `--kfb-mark rgba(233,193,74,.5)`
- **Verdicts:** push `#4f6029` · hold `#6e685a` · twist `#b8361f`; **Calls:** bingo `#4f6029` · bongo `#8a6f3e` · boggle `#5a6b76` · blödsinn `#b8361f`
- **Semantisch:** `--kfb-signal` folgt der Edition (§4)
- **Type:** `--kfb-font-display/ui/hand`
- **Form:** `--kfb-radius 0`, `--kfb-shadow 3px 3px 0`, `--kfb-shadow-lift 5px 5px 0`, `--kfb-tilt -0.8deg`, `--kfb-dur-fast 120ms`, `--kfb-dur 200ms`, `--kfb-ease`

## 3. Type-Rollen (nur 3 Fonts)

| Rolle | Font | Einsatz |
|---|---|---|
| Display | Irish Grover | Wortmarke, Buttons, Badges, Zahlen. Laut, **sparsam**. |
| UI / Body | Special Elite | Typewriter: Kicker, Tabs, Labels, kleine UI. |
| Handschrift | Shantell Sans | Karten-Text + lesbarer Fließtext / Überschriften. |

Fonts laden:
```html
<link href="https://fonts.googleapis.com/css2?family=Irish+Grover&family=Special+Elite&family=Shantell+Sans:wght@400;500;700&display=swap" rel="stylesheet">
```

## 4. Editionen umschalten

```html
<html data-edition="freestyle">   <!-- --kfb-signal = Rot #b8361f (default) -->
<html data-edition="med">         <!-- --kfb-signal = Teal #2f7a72 -->
```
Regel: **immer `--kfb-signal` benutzen**, nie `--kfb-accent` hart verdrahten — sonst bricht die MED-Edition. Echtes „BLÖDSINN"/twist nutzt bewusst das fixe Rot.

## 5. Komponenten-Primitive

Alle in `themes/kfb-med.css` mit Hover/Active/`prefers-reduced-motion`.

- **`.kfb-wordmark`** — „Kayfa" (Tinte) + „Bizarro" (Cream auf Akzent, harter Schatten).
- **`.kfb-kicker`** — Special-Elite-Mikrolabel (`--signal` für Akzentvariante).
- **`.kfb-btn`** — Irish Grover, Akzent-Grund, Cream-Text, 2px Ink-Border, harter Schatten, leicht gekippt. Hover = `translate(-1px,-1px) rotate(-.6deg)` + größerer Schatten. Varianten: `--signal`, `--paper`.
- **`.kfb-tab`** — Papier-Tab, aktiv = Signal-Unterkante (3px, hart). `aria-selected="true"` oder `.is-active`.
- **`.kfb-cut`** — Cut-out-Panel/Karte: Kartengrund, Ink-Border, harter Offset-Schatten, leichte Rotation (abwechselnd). `--interactive` (Hover-Lift), `--marked` (Signal-Kante links).
- **`.kfb-badge`** — laute Ruf-Marke. **`.kfb-chip`** — Special-Elite-Daten-Chip.

Beispiel:
```html
<link rel="stylesheet" href="/themes/kfb-med.css">
<div class="kfb-wordmark">Kayfa<b>Bizarro</b></div>
<button class="kfb-btn">DEAL</button>
<button class="kfb-btn kfb-btn--paper">ROLL</button>
```

## 6. Verwendung in DCs vs. klassischem CSS

- **Klassisches HTML/CSS & JS-Komponenten** (z.B. `kfb-table.*.js`): `themes/kfb-med.css` verlinken, Klassen nutzen.
- **Design Components (`.dc.html`)**: NICHT verlinken (DCs stylen inline & streamen). Token-**Werte** aus diesem File 1:1 inline übernehmen (siehe `Web3D Learnings (Diorama).dc.html` als Referenz-Implementierung). Dieses File bleibt die kanonische Zahlenquelle.

## 7. Grundsätze (die den Look tragen)

1. **Papier, keine App.** Helle warme Papierflächen, **Radius 0** (Papier ist eckig), Tuschekanten — nie Glas/Neon/Pillen.
2. **Harter Schatten, kein Blur.** `3px 3px 0` — Offset, keine weiche Unschärfe. Alles wirkt aufgeklebt/geschnitten.
3. **Leichte Rotation statt Skew.** Jedes Element minimal gekippt (−1° bis 2°), nie steril gerade. Hover kippt sichtbar mit.
4. **Type: 3 Fonts, klare Rollen.** Irish Grover laut & sparsam, Special Elite fürs Gerüst, Shantell für Lesbares.
5. **Signal sparsam.** Rot/Teal ist Betonung, nicht Fläche. Ein bis zwei Signal-Elemente pro Screen.

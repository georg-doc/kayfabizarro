# KFB Cartoon Motion Bible

**Status: KANONISCH · Living Document · v1 · Stand 2026-07-16**

Die eine Wahrheit für alle Pet-/Cartoon-Motion in KayfaBizarro. Benchmark und Referenz-Pool
für die Motion Library. Neue Claude-Design-Chats und externe LLMs starten hier.

Diese Datei ist der **Index + die verbindliche Kurzfassung**. Die Langquellen liegen in
`docs/motion_bible/` (bereinigte, kanonische Fassungen der Research-Exporte).

---

## 0 · Quellen & Rollen

| Datei | Rolle |
|---|---|
| `docs/motion_bible/01_PRINCIPLES_and_RESEARCH.md` | Prinzipien, MVP-Tiers, Layer-Architektur, Produktions-SOP, Augen-Regeln |
| `docs/motion_bible/02_LIBRARY_MATRIX.md` | Die 37-Motion-Matrix (Name, Zweck, Dauer, Loop, Layer, Augenverhalten, Impl-Notiz, Referenztyp) + `eye_policy`-Tags |
| `docs/motion_bible/03_WEBGL_IMPLEMENTATION.md` | Prinzipien → Three.js/WebGL-Mechanik, State-Machine, Bone-Masking, Performance, Uncanny-Valley |

Bei Konflikt gewinnt **diese Index-Datei** (sie gleicht die Quellen ab). Quellen nie
stillschweigend widersprechen — hier reconcilen und Changelog schreiben.

---

## 1 · Grundgesetze (verbindlich)

1. **Nie linear.** LERP/konstante Geschwindigkeit = tot/mechanisch. Alles über Ease-Kurven.
2. **Volumen bleibt.** Squash/Stretch immer volumenerhaltend (§Formeln).
3. **Kontrast-Timing.** Langsame Vorbereitung, schnelle Ausführung; Apex-Hang, schnelle Kontakte.
4. **Anticipation → Action → Follow-through → Recovery.** Recovery ist Teil der Motion, kein Anhängsel.
5. **Bogen, nicht Gerade.** Flugbahnen parabolisch, Rotationen via SLERP.
6. **Motion-Priorität:** Augen vor Kopf, Kopf vor Körper, Körper vor Root. Sekundärteile (Ohren) laggen.
7. **Snappy vor schön.** Interaktiver Input braucht Frame-1-Feedback; Anticipation komprimieren, nie > ~8 Frames Verzug.
8. **Feel it, don't see it.** Aus Extrem-Posen schnell zurück; Extrem nie halten (wirkt „stuck").
9. **Frame-rate-unabhängig.** Alles über delta-time; Physik im Fixed-Timestep-Akkumulator.

---

## 2 · Formeln (kanonische Kurzform)

Im WebGL-Doc waren diese im Export zeilenweise zerbrochen — hier die gültige Fassung:

- **Volumenerhalt (Squash/Stretch):** `Sx = Sz = 1 / sqrt(Sy)`
  (Y-Scale `Sy` frei wählen, transversale Achsen invers → Masse konstant). In der Engine:
  `sxz = 1/Math.sqrt(sy)`.
- **Smoothstep / Ease-in-out Blend:** `w(t) = 3t² − 2t³` (Blend-Gewicht Ziel), `1 − w(t)` (Quelle).
  Verhindert den „flat spot" linearer Crossfades.
- **Gaze-Clamp:** Augen ±30° horizontal, ±20° vertikal; darüber Kopf/Nacken mitdrehen.
- **Saccade:** kleine zufällige Quaternion-Offsets (~0.04 rad) alle 0.8–2.4 s, binokular synchron.
- **Ground-Pivot:** Scale relativ zum Bodenkontakt-Pivot, nicht zum Mesh-Zentrum (sonst schwebt das Pet).

---

## 3 · Layer-Architektur (Ziel-Struktur)

- **Layer 0 Locomotion** (Full Body): idle, walk, run, jump, fall, land, turn.
- **Layer 1 Action** (Upper-Body-Mask): wave, celebrate, hit_react.
- **Layer 2 Expression** (Face/Morph): blink, eye-dart, emote_yes/no.
- **Layer 3 Procedural** (Head/Eyes/Appendages): lookAt, saccades, ear/tail jiggle.

`eye_policy` pro Motion: `lead | lag | lock | float | blink | wide | narrow`.

---

## 4 · Engine-Status (was ist gebaut) — `infinite-journey.v2.js`, `<kfb-journey-v2>`

| Motion | Status | Ort im Code |
|---|---|---|
| `idle` (GLB-Idle + Atmen) | ✅ | `pet.play('idle')`, `pet.update` |
| `look` / gaze-follow + auflösen in Ruhe | ✅ | EyeRig v3, `rig.pointTo`, `_ptrIdle` |
| `turn_react` (Hop bei vertikaler Raum-Drehung) | ✅ Stufe 2b | `HOP_KF`, `_kickHop`, Hop-Overlay in `_tick` |
| `blink`, `saccade`, `look_at`-Ziel | ⏳ EyeRig kann es, noch nicht getriggert | — |
| `jump_into_panel` (Zugbrücke, Umdrehen, Kamera am Band) | ⏳ Stufe 3 | Referenz: `card-viewer.v3.js` (FOLD_DOWN, Gummileine) |
| freie Pet-Platzierung | ✅ (Drag auf Bodenebene, Raster-Snap) | `_dragPetTo`, `_hitPet` |

### Aktuelle `turn_react`-Hop-Tokens (Stand 2026-07-16)
- Motion-ID `turn_react` · Layer Base · eye_policy `lock`→`settle` · Dauer **1.10 s** · one-shot.
- Kurve `HOP_KF` = Bouncing-Ball mit Apex-Hang (Ease) + **zwei** abklingenden Bounces
  (Impact-Squash `Sy≈0.72`/`0.84`, Rebound-Stretch, ~34 % Rebound-Höhe), Volumen via `Sx=Sz=1/√Sy`.
- **Nur bei vertikaler Drehung** (H-Drehung bewegt den Boden nicht → kein Hop).
- Pet reitet die Bodenkachel live über die volle Hop-Dauer (`_placePet` in `_tick`, Bedingung
  `_settling || _wheeling || _drag || _hop`) — verhindert Clipping/Anker-Pop-Flackern.
- Offen/Bekannt: bei sehr schnellem Scrollen noch leicht ruckelig; Feintuning Timing/Ease steht aus.

---

## 5 · Diagnose (Symptom → Ursache)

- **„hart / harte Feder"** → Recovery zu kurz/symmetrisch oder als Mikro-Dip statt eigener
  abklingender Bounce-Phase. Fix: echter Rebound mit Airtime, Amplitude abnehmend.
- **„flackert / unsauber"** → zu viele Kontakte auf zu kurzer Dauer (Stroboskop) ODER Anker-Pop
  (Objekt folgt der bewegten Fläche nicht über die volle Motion-Dauer).
- **„kein Ease"** → dichte Keyframes machen smoothstep pro Segment fast linear; Apex-HANG (flache,
  eng gesetzte Keys) + weite Kontakt-Spacing setzen.
- **„floaty / leicht"** → Kontakt-Spacing zu eng, Apex-Hang zu kurz, zu wenig S&S-Kontrast.
- **„stuck / mushy"** → Extrem-Pose zu lange gehalten.
- **„tot / mechanisch"** → linear, keine Arcs, keine Secondary Action/Augen-Leben.
- **Pet unsichtbar** → degenerierte Bounding-Box hat `_petUnit`/`_petFootY` = NaN/Inf gebacken;
  Messung transform-unabhängig halten (Group vor Messung auf Identität), Guard gegen NaN.

---

## 6 · Nächste sinnvolle Schritte

1. Hop-Tokens in ein **Motion-Spec-JSON** ziehen (Name, Trigger, Dauer, Loop, Layer, eye_policy,
   Kurve), damit Engine + Editor + Rigging eine Quelle teilen (siehe 02-Matrix „Nächster Schritt").
2. Stufe 3 (`jump_into_panel`) aus `card-viewer.v3.js` (FOLD_DOWN + Gummileinen-Kamera) portieren.
3. Augen-Layer scharfschalten: `blink`, `saccade`, AFK-`sleep`/selling.

---

## 7 · Changelog

- **v1 (2026-07-16):** Bible etabliert. Drei Research-Exporte bereinigt und als kanonische Quellen
  nach `docs/motion_bible/` übernommen. Index mit Grundgesetzen, kanonischen Formeln (aus dem
  zerbrochenen WebGL-Export normalisiert), Layer-Architektur, Engine-Status-Mapping und Diagnose.
  Ersetzt die frühere `docs/CARTOON_MOTION_KB_v1.md` (jetzt Redirect-Stub).

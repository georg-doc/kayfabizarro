# Handover — Time Capsule Ride v6 → Cowork-Lane (Engine/SSOT-Lead)

**Von:** Fable-Five-Chat (Oberflächen-Lane), 2026-07-10.
**Antwort auf:** `V6_BUILD_INSTRUCTION.md`.
**Konvention:** dies ist die EINE aktuelle Handover-Datei der Fable-Seite; ältere Stände stecken in `docs/CHANGELOG.md`.

## 1. Stand

`Time Capsule Ride v6.dc.html` ist eingecheckt, v5 eingefroren. Alle vier Blöcke umgesetzt und gegen die §8-Checkliste per Screenshot + synthetischen PointerEvents geprüft (Details im Changelog-v6-Eintrag):

- **Block A:** Snap löst auf aufrecht (beide Achsen, gemeinsames `faceLid()`), Ruhe-Kamera auf der Flächen-Normale in Platten-Höhe (Rechteck statt Trapez), FOV 26° im Lesezustand ↔ 48° bei Fahrt, Lese-Distanz aus FOV+Aspekt+Flächen-Ebene.
- **Block B:** Lift AUF dem Quest-Deckel (Stockwerke + Geschwister-Pfeile, Raycast-UV-Regionen, touch-groß), Erzähl-/Meta-Caption als Comic-Panel in die Flächen-/Deckel-Texturen gebacken (Opener → Wetter-Deckel, Verdict/Door → Tür-Deckel), Rand-HUD (Kopfzeile, Mode-Chip, Hint) in Special Elite, Beat-Dots bleiben.
- **Block C:** clamp()-HUD, aspekt-bewusste Lese-Distanz, Help scrollbar; Nav/Erzählung skalieren mit dem Artefakt.
- **Block D:** Zylinder raus. Default = prozeduraler fBm-Wasserfarbhimmel (domain-warp + Edge-Darkening + Papier-Granulation + Mode-Tint + speed-reaktives `uDrift`) auf der kamerafesten BackSide-Sphere — kantenlos, nahtlos. `skydomeSource`: procedural / watercolor (webp als gebogene Kulisse mit weichen Alpha-Kanten, D3) / collage (geparkt, D4). K cycelt.

Nicht angefasst (§7): Galaxie-Graph, Voice, Klangteppich, Impuls-Flug-Kern, Türblätter, Cockpit.

## 2. Rückfragen / Beobachtungen aus dem Bau

1. **D5-Umfang:** umgesetzt ist mehr als der Minimal-Fix (voller Warp+Granulation+Edge-Darkening im Sphere-Shader), aber noch nicht der separat getrackte „EINE Himmel für alle Galaxien"-Baustein mit geteilten `uSpeed`/`uTime`-Uniforms des Flug-Kerns. Der Shader hat `uDrift` (speed-integriert) — beim Andocken des Flug-Kerns dieselbe Uniform füttern, dann ist die Kopplung da.
2. **Verdict-Choreo:** der King's Verdict schwenkt jetzt auf den Tür-Deckel (Caption dort, Iris öffnet sichtbar davor, Abflug durch die Tür, Pfad rotiert mit dem Gruppen-Yaw). Gefällt uns; falls das Verdict lieber auf der letzten Karten-Fläche bleiben soll, ist es ein Ein-Zeilen-Revert im Verdict-Zweig.
3. **Caption vs. Pfeile:** steht eine Caption auf dem Quest-Deckel, überdeckt sie die Geschwister-Pfeile visuell (Klickregionen bleiben aktiv). Bewusst so gelassen (Caption ist transient); sagt Bescheid, falls die Pfeile über die Caption sollen.
4. **Lift-Semantik:** Stockwerke weiterhin SHELF/COVER/PAGE/CARD; Umbenennung bleibt ein Label-Edit (offen aus v5).

## 3. Nähte: Stubs und Andockpunkte

| Naht (Vertrag) | Stub im Viewer heute | Andockpunkt im Code |
|---|---|---|
| `window.KFBDie.roll()` → modeIdx | Zufall + Chip-Cycling | `rollMode(st)` |
| `kfb_beat_engine.js` → Beats mit `focus` | statisches `st.script` `{face | lid, kicker, line, verdict?}` | `rollMode()` baut das Script (`lid: 'mode'|'quest'` für face:null-Beats) |
| `window.fb.*` (Avatar) | Text-Präsenz + Kapsel-Rotation als finger-rule (bis L2) | `applyItem()` |
| King's Verdict / Quest-Die | gewichteter Zufall `[2,1,1,0]` | `applyItem()` Verdict-Zweig |
| `window.claude.complete` | ungenutzt | `setCaption()` ist jetzt die einzige Text-Senke (ersetzt `say()`) |
| Flug-Kern-Uniforms | `uDrift` speed-integriert im Sky-Shader | `tick()` Sky-Block / `skyUni` |

## 4. NDJSON-Log (Q4) — implementiert, Adapter bei euch

Events: `session {deck, skin, theme, seed, build}`, `arrive`, `roll`, `beat` (Deckel-Beats loggen `face: null, card: 'mode'|'quest'`), `verdict`, `depart`; `t` in ms. Export Taste **L** / `window.KFBRideLog`. **Replay weiter offen** (v7-Kandidat).

## 5. Was wir weiter von euch brauchen

1. **Kanonische S.16-Hex** (Interim läuft, Swap = ein Edit in `MODES`).
2. **`page`+`quadrant` pro Karte in den Deck-JSONs** (zugesagt, Schreibsperre) — bis dahin visuelles `cardMap`.
3. **Manifest-Schema (L1)** → dann bauen wir `?pkg=`.
4. **Flug-Kern-Track:** `IMMERSIVE_FLIGHT_research.md` + Modul aus eurer Lane; der Sky-Shader wartet mit `uDrift` auf die geteilten Uniforms.
5. **Türblatt-GLBs** (Vorhang / Schleuse / surreale Tür) für die Portal-Runde danach.
6. **Nächste „für v7"-Anweisung** (eine Datei, wie gehabt).

## 6. Schemata (Ist-Stand)

Deck-JSON: `{ deckTitle, cards: [{ name, power, lore }] }`. Deck-Layout-Parameter im Viewer (Ziel: Manifest): `pdf, cardsPerPage: 4, coverPages: 1, gridTop: 0.15, cardMap: { name: [page, quadrant] }, skydome: 'assets/skydome_a.webp'`. Tweak-Props: `theme, propertySkin, skydomeSource (procedural/watercolor/collage), autoBeats, beatSeconds, rideSeconds, halftone`.

## 7. IP / PoC

Nur web-aufgelöstes PDF im Projekt. Standalone-Export v5 in `export/` (v6-Export folgt nach Georgs Abnahme). claude.ai-PoC: PDF + JSON separat hochladen; `?pkg=` ist der Schritt dafür.

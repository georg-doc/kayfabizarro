# Pet Motion Library v1 — Ist-Stand & API (2026-07-16)

Cartoony Squash-and-Stretch-Bewegung für die Cube-Pets, als **prozedurale Schicht ÜBER den Baked-GLB-Clips**. Theorie/Timing/Matrix stehen in `docs/CARTOON_MOTION_KNOWLEDGE.md` (SSOT); dieses Dokument ist der konkrete Ist-Stand plus API.

## Dateien
- `pet-motion.v1.js` — Runtime-Modul (`PetMotion`, `MOTION_DEFAULTS`, `PARAM_META`). Kein Build, reines ES-Modul, `window.PetMotion`-Fallback.
- `motion-LIBRARY.json` — Contract (`$schema: kfb.motion-library/1`), Apps lesen ihn per URL und geben `motions` an `new PetMotion(ch, {params})`.
- `KFB Pet Motion Editor v1.dc.html` — Authoring-Bench (Trigger, Live-Tuning, Glättung, Reise-Ablauf, IO).
- `docs/CARTOON_MOTION_KNOWLEDGE.md` — Knowledge Base v2 (Prinzipien, 36-Zeilen-Matrix, eye_policy, Layer, MVP-Tiers, SOP).

## Vertrag mit dem Host
`PetMotion.update(dt)` MUSS **nach** `ch.update(dt)** und **vor** `rig.update(dt)** laufen:
```
if (this.ch) this.ch.update(dt);      // Baked-Clip + Character-Feder
if (this.motion) this.motion.update(dt);  // schreibt ch.inner.scale + ch.group.pos, fuettert ch._squash.s
if (this.rig) this.rig.update(dt);        // Augen-Kompensation liest ch._squash.s
```
Erwartet vom Character (`pet-library.v6.js`): `ch.group` (Raum-Wurzel), `ch.inner` (Modell), `ch._squash` (Feder), `ch._baseS` (Basis-Skala), `ch.setHome()`/`ch._home`. `opts.rig` (EyeRig v4) ist optional und wird NUR über die öffentliche API getrieben (pointTo/setGazeFollow/applyEmote/blinkNow) — das Rig bleibt unangetastet.

## API
```
const m = new PetMotion(ch, { rig, params, squashStretch: 1, smoothTime: 0.07, front:{x,z}, back:{x,z} });
m.hop(o)                     // kleiner Hüpfer on demand (Promise)
m.powerJump(o)               // grosser Sprung: Anticipation + Bogen + Aufprall-Squash + Rebound
m.jumpTo(x, z, {hops})       // Locomotion: hüpfend zu einem Punkt
m.locomotion({toX,toZ,hops}) // = jumpTo zum front-Punkt per Default
m.turnTo(rad) / m.turn180()
m.celebrate() / m.react('positive'|'negative')
m.transitionOut() / m.transitionIn()
m.roomTransition()           // Reise-Standard: Boden→vorderer Mittelrand→raus→rein
m.loop('idle'|'loading', on) // Dauer-Loops
m.stopLoops() / m.reset()
m.setParams(obj) / m.setMaster(x) / m.setSmooth(t) / m.setEyeReact(bool)
m.update(dt)                 // pro Frame, siehe Vertrag
```
Alle Einzel-Motions sind Promises → verkettbar (`await m.jumpTo(...); await m.transitionOut();`).

## Motions v1 (Coverage)
idle-breathe · hop · powerJump (jump+land+rebound in einem) · locomotion/jumpTo · loading-loop (bounce) · transition (launch+air+arrive) · turn180 · celebrate · react ±.
Mapping auf die volle Matrix und Backlog (MVP 2/3) in der Knowledge Base, Abschnitt 7.

## Anti-Flacker (der Kern-Umbau)
1. **Ein Besitzer der Skala.** `update()` berechnet pro Frame genau ein `target` und ist der einzige Schreiber von `ch.inner.scale`.
2. **SmoothDamp-Ausgangs-Glättung** (`smoothTime`, default 0.07 s) — kritisch gedämpft, framerate-unabhängig. Kappt Keyframe-Stufen UND harte State-Wechsel. Regler in der Bench.
3. **Ruhige Augen** — nur Blink bei Landung. Kein Wide-Pop (baute Pupillen-Geometrie neu), kein Follow-Toggle.
Squash-Konvention (Volumen grob erhalten, deckungsgleich mit EyeRig-Kompensation): `sxz = 1 + (1 - sy) * 0.6`.

## Bench
FrizzleBob (bunny) auf einer Schneidematte, `mods:['emotes']`, **Körper flach in Base-Color** (`_paintBody` → originale gemalte GLB-Augen weg, nur die 3D-EyeRig-Augen tragen das Gesicht). Vorderer Mittelrand als Tusche-Linie + roter Ziel-Ring = Zugbrücke. Global-Panel: Squash-Master, Glättung, Blick-reagiert-Toggle, Matte/Ziel-Toggle, Reset. Der dynamische Import ist cache-gebustet (`?v=Date.now()`), sonst lud der Browser das Modul stale.

## Offene Punkte / Backlog
- MVP 2 als Nächstes bauen: spring_up, rubber_band_return, gumball_roll, float_hover, stomp, sleep (Knowledge Base Abschnitt 7).
- Contract-Metadaten pro Motion (layer, eye_policy, tags, blendIn/Out, fpsRange) ergänzen, sobald MVP-2-Motions stehen.
- „Herrchen an Leine folgt dem hüpfenden Pet" (zweites Objekt) gehört zur Diorama-Integration, nicht in die isolierte Motion.
- Flacker-Feinschliff ist live beim User zu beurteilen (zeitlich, nicht am Standbild).

## Dev-Falle
Viele Hot-Reloads auf dieselbe `<canvas>` hinterlassen Zombie-`animate()`-Loops/mehrere Renderer, die sich überzeichnen → der Pet verschwindet, obwohl der Scene-Graph gesund ist. Kein Code-Bug. Harter Full-Reload räumt es weg.

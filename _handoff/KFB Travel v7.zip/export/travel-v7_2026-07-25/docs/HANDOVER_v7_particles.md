# HANDOVER v7 — Partikel: KFB Particle Test + three.js-Port-Plan

**Sprint 6 (Partikel-Immersion) · Stand 2026-07-19 · Dateien: `particle-test/`, `rollercoaster-ride.v7.js`**

## 1. Warum dieser Test existiert
Georgs Benchmark: three.js `webgpu_tsl_vfx_linkedparticles` + `webgpu_tsl_compute_attractors_particles`
wirken „andere Liga" als unsere Ride-Partikel. Nach **Lesen des echten Beispiel-Codes** (nicht nur
Screenshots) ist die Ursache klar und NICHT die reine Partikelzahl:

| Hebel | linkedparticles | attractors | unser Ride (vorher) |
|---|---|---|---|
| Hintergrund | `0x14171a` (fast schwarz) | `0x000000` | heller Watercolor / helle Tracks |
| Tonemapping | ACESFilmic | (default) | ACES nur space/shader |
| Bloom | `bloom(col,0.75,0.1,0.5)`, **addiert** (`col.add(bloom)`) | **kein Bloom** | `bloom(col,0.8,0.2,0.85)` addiert ✓ |
| HDR-Futter | Farbe ×~11 per `pulse·modLife` → nur Kerne >1 bloomen | winzige additive Sprites, Dichte | Kerne nur schwach >1 |
| Count | 2^13 = 8 192 | 2^18 = 262 144 | ~1–2k CPU-Points |
| Sprite | harte `step`-Kreisscheibe, additiv | 1×1 Plane, additiv | Default-Point |
| Extra | Nachbar-**Links** (Konstellations-Netz) | 3 Attraktoren (Gravitation+Spin) | — |

**Kernlehre:** dunkler BG + ACES + Bloom, das NUR von echten HDR-Kernen (>1) gespeist wird, +
additive Überlagerung. „Liga" = Kontrast & Glow-Disziplin, nicht Brute-Force-Count. Mein erster
Versuch (globales HDR ×1.4 auf alle Partikel + Threshold 0.6) hat deshalb die ganze Szene überstrahlt
und die Karten unlesbar gemacht → zurückgerollt auf `bloom(col,0.8,0.2,0.85)`.

## 2. KFB Particle Test v1 (`particle-test/KFB Particle Test v1.html`)
Standalone WebGPU-Canvas (unpkg three@0.178.0 — **exakt die Version, die der Ride hier rendert**).
Selbst-emittierend (kein Maus-Spawn, kein Compute-Buffer) → läuft zuverlässig im Preview, anders als
die interaktiven Referenz-Demos. Technik = die **bewährte Ride-Methode**: CPU-geseedete Points +
`PointsNodeMaterial` additiv, Position per `mx_fractal_noise_vec3`-Drift über `time` (wie `windGrp
posOf()`), ACES, `PostProcessing` + `bloom` wie im Ride.

**Live-Tweak-Panel** (Uniforms, kein Rebuild außer Count):
Count · Size · HDR/Hot · Flow Speed · Bloom Threshold/Strength/Radius · Palette (GOLD/ABSURD/TRAGIC/
COSMIC) · Links-Toggle (UI-Stub, s. Backlog). Bloom-Slider schreiben direkt `bloomPass.threshold/
strength/radius .value`. FPS+Count-Readout unten links.

**Workflow:** Look hier tunen → Gewinner-Werte in `rollercoaster-ride.v7.js` portieren
(`applySkyMode` bloom-Call + `buildTrackFlows`/`updatePetTrail` size/HDR).

## 3. three.js-Port-Plan (recherchiert, noch NICHT umgesetzt)
Ziel: die beiden Referenz-Demos als echte Vergleichs-Tabs neben dem KFB-Test. Warum offen: beide sind
**interaktive GPU-Compute-Spawn-Demos** (Partikel entstehen live am Mauszeiger in `storage()`-Buffern
über `renderer.compute()`); mein 1:1-Port lädt fehlerfrei, aber die Partikel spawnen im Preview nicht
(nur BG rendert). Vermutete Ursache: Compute-Dispatch/Timing-Kompat im Sandbox-Preview.

**Plan, wenn wir es doch wollen:**
1. **Version pinnen** auf three@0.178.0 (Ride-Version) statt master; API-Lücken beachten, die beim
   Port auffielen: `TWO_PI` ist KEIN TSL-Export (selbst definieren `PI.mul(2)`); `THREE.Timer` +
   `.connect()`, `.setName()` auf Compute-Nodes, `RenderPipeline` sind versionsabhängig — für 0.178
   `PostProcessing` statt `RenderPipeline` nehmen.
2. **Compute-Spawn ersetzen** durch einen Auto-Emitter (kein Maus-Input): `spawnPosition` per
   `time`-Kurve statt Raycast → deterministisch, im Preview screenshot-bar.
3. **Compute-Sichtbarkeit debuggen**: `renderer.compute()`-Ergebnis über eine Mini-Storage-Probe
   verifizieren (ein Punkt, bekannte Position) bevor der volle Loop läuft.
4. **linkedparticles zuerst** (8k, leichter), attractors (262k) nur wenn Perf im Canvas trägt.
5. Erst wenn ein Einzel-Demo isoliert rendert → in einen **Tab-Shell-DC** (`KFB Particle Test.dc.html`)
   mit iframes packen (Tab 1 KFB-Test, Tab 2 linkedparticles, Tab 3 attractors).

Bestehender Teil-Port liegt unter `particle-test/linkedparticles.html` (lädt, rendert nur BG) — als
Ausgangspunkt für Schritt 2–3 behalten.

## 4. Bereits im Ride umgesetzt (Sprint 6, davor)
Track-Flows aufgeweitet (radMax 0.3/0.4, count 13/9, size [0.4,1.9], atten 1180, turb 0.22),
Rad-Funken größer (1.35/0.32/1050) + dichter (Emission 640, Buffer 1400), weiche runde Sprite-Maske.
Beat-FX = Partikel-Burst aus Pet-Weltzentrum. Bloom zurück auf lesbare `0.8/0.2/0.85`.

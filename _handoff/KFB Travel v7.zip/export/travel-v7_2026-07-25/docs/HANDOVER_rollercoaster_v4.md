# HANDOVER: Rollercoaster Ride v4 (eingefroren 2026-07-17)

Für Coworker/Lead. v4 ist MVP+: kompletter Loop Pet-Auswahl → Cover-Gate → Ride mit Takt,
Portal/Curtain, Partikel-Sprache, Musikbett, LLM-Erzähler. Chrome (WebGPU) ist die Referenz.

---

## ⚡ DIE METAPHER (groß, bitte nicht überlesen)

**Human = Pet-Avatar. Die Pets sind storytelling animals.**

Alle Karten sind FrizzleBobs Time-Capsule-Artefakte, die er wie akashic records im fraktalen
Almanach sammelt. Das Pet ist der Avatar des Spielers UND das Closure-Tier: es fährt vorne mit,
kayfabuliert, macht die Physik der Fahrt viszeral (Squash/Lean/Hang) und gibt dem Menschen die
Erzähl-Ebene. Deshalb: Karten/Cover werden NIE falsch herum oder gespiegelt angezeigt — sie sind
immer player-facing lesbar (Ausnahme: Geisterbahn-Modus, Backlog 40: nur Rückseiten, Reveal bei
Passage). Jede Design-Entscheidung, die das Pet vom Spieler trennt oder Karten unlesbar macht,
bricht die Metapher.

---

## Dateien (v4-Kern)

| Datei | Rolle |
|---|---|
| `Rollercoaster Ride v4.dc.html` | Entry (DC), lädt das Modul |
| `rollercoaster-ride.v4.js` | Ride: Track, Physik, Curtains/Portal, Partikel, Audio, HUD, Settings |
| `pet-select.v4.js` | Pet-Auswahl-Ring (Entry-State), exportiert `inkChip2D` |
| `frizzlebob-voice.v3.js` | TTS-Erzähler: Pools (Ebene 0/1), `fluff()`-Operator |
| `pet-library.v6.js` / `pet-eye-rig.v3.js` / `pet-motion.v1.js` | Pet-Stack (Character, Augen, Motion) |
| `data/deck_*.json` + `assets/deck_*.pdf` | Karten (Index + Art-Quelle) |
| GitHub RAW (`georg-doc/kayfabizarro`) | pet-LIBRARY.json, Texturen, **Van_Metronome.mp3** |

Frozen: `export/Rollercoaster Ride v4 - standalone.html` (self-contained; GitHub-Assets bleiben remote).

## Architektur in 60 Sekunden

1. **Boot:** `PetSelect` (Ring, 12 Pets aus Contract) → `onSelect(petId)` → `RideV2`.
2. **Held-State:** Cover-Card frontal (Insert-Coin), ENTER → `held=false`, Fahrt beginnt durch das Cover.
3. **Physik:** three.js-XR-Coaster-Track (Original-Kurve), `velocity`/`progress`, Gravity entlang
   Tangente, **Karten-Magnet** (Shō bremst auf Lesetempo, Ten schnappt durch, `grade` = Haltezeit).
4. **Curtains:** eine Klasse, zwei Modi. Curtain = Cloth-Sim nur im Ten-Fenster; Portal = alphaTest-
   Dissolve (oval, Noise), Cloth aus. Signierte Along-Track-Distanz steuert alles (kein Re-Flattern).
5. **Erzähler:** fraktaler Takt Ki(−19s Name)/Shō(Power|Beat)/Ten(Lore-Punch)/Ketsu(still) pro Karte;
   pro 4er-Seite EIN LLM-Call (am Ten der Vorkarte) → `card._beat`. Fallback: Pool + Fluffo-Lekt.
6. **Audio:** 4-Layer-Soundscape (Mood = spektrale Identität) + Musikbett (104 BPM, DRY, Auslauf→Luft→
   Neustart). Takt-Uhr am AudioContext (`audio.bpm=104`, `audio.beat0`). Slider: MUSIC, DRONE.
7. **Partikel-Sprache** (3 Ebenen, alle speed-gekoppelt): Rohr-Ströme (Turbulenz + Hot-Cores) →
   Funkenregen am Pet (Duo-Tone, Kurven-G) → Fahrtwind-Streaks (kameranah). Dazu 12 Speedline-Lanes
   (GPU-Dash auf Track-Konturen). Aquarell = Multiply/Pigment, Nacht = Additive/Bloom(Threshold 1).

## ⚠️ Gelernte Fallen (nicht wieder reintappen)

- **WebGPU: max 8 Vertex-Buffer** pro Pipeline. Extra-Attribute in vorhandene vec-Slots packen.
- **MultiplyBlending braucht `premultipliedAlpha`** unter WebGPU, sonst Validation-Spam.
- **NIE `scene.add(camera)`** — reparented die Kamera aus dem Ride-Rig; das Pet fährt ohne dich.
  (Genau dieser Bug ist als Explore-Mode-Fundstück im Backlog 48.)
- **Bloom-Threshold ≥ 1.0**, sonst überstrahlt Kartenpapier (~0.95) in den Nacht-Modi.
- **Points-Size:** `sizeNode` braucht ~800/dist statt 240 (Retina), sonst Subpixel-Staub.
- **PMREM/Env erst nach async Renderer-Init** (`renderer.init()` awaiten / erst rendern).
- Remote-Fetches (Contract, Decks, MP3) IMMER mit Retry+Backoff; Fallbacks nie hart einfärben.
- Firefox: kein WebGPU → aktuell praktisch leer. Fallback-Plan siehe BACKLOG.md (WebGL2-Pfad
  oder `three.webgpu.js`-Fallback-Renderer; Partikel-Dichte drosseln).

## Backlog / v5-Plan (Empfehlung: Reihenfolge)

1. **Die Hand** (`uploads/HANDOVER_v5_die_hand.md`) — Karten einsammeln statt nur passieren;
   untere Reihe Pad|Hand|Tacho; Overlay ohne Pause (Fahrt läuft weiter). DER v5-Kern: macht
   „Deck leer" prüfbar und die Hand zur Speicherdatei (Session-Bundle). Punkt 3+7 der Abnahme zuerst.
2. **Beat-Meter/Soundbar** (50) + **Tacho-Eichung** (49) — beide hängen an `audio.bpm/beat0`
   (steht schon); Nadel zittert am roten Rand, Pad spiegelt Kinetik (Stretch&Squash).
3. **Konsole/Kartenhand** (`BRIEF_konsole_kartenhand.md`) — Steuerkarten durchscheinend,
   Spielkarten nicht; gleiche Lasche/Staffelung wie die Hand.
4. **Explore-Mode** (48) — WASD/Booster, Pet fährt allein, Card-Klick = magnetischer Pull.
5. Kleineres: Outline-Hull Pet (45), 3D-Fluffy-Die + Roll-Anim (46), Pet-Ride-Slider (41),
   Geisterbahn (40), Voice-Zweitstimme („drums and bass only"-Regenerat, falls Track matscht).

## Abnahme-Checkliste v4 (aus den Briefs, alle grün beim Freeze)

Karte still beim Lesen ✓ · Name fällt vor Sichtkontakt ✓ · kein Doppel-Flattern hinter dem
Fahrer ✓ · Portal löst oval auf & baut rückwärts ✓ · G1/G3 fühlen sich verschieden an ✓ ·
Musik duckt unter der Stimme ✓ · Drone trägt die Pause ✓ · Cards lesbar in allen 4 Skies ✓.

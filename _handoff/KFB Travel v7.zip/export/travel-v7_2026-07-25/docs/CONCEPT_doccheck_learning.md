# Lernen im Flug — Konzept für den DocCheck-Fork

Stand 2026-07-25 · Autor: Georgs Vorgaben + meine Ergänzungen · **Living Document**
Gehört zu: `docs/KFB_CONTEXT.md` (Spielkanon), `docs/SPRINT_travel-v7.md` (Slices).
**Zweck:** Grundlage für einen frischen Chat im DocCheck-Workspace — Konzept, Architektur,
Backlog, offene Entscheidungen.

---

## 0 · Die These, auf die alles aufbaut

**KayfaBizarros Mechanik IST bereits ein Lernsystem. Wir müssen sie nicht umbauen, nur umbenennen.**

| KFB-Mechanik | Was sie lerntheoretisch ist |
|---|---|
| **Gutter / Closure** — die Lücke zwischen zwei Karten schließen | **Active Recall** plus Elaboration: nicht abfragen, sondern *verbinden* |
| **Show it · Spin it · Sell it** | **Feynman-Technik**, wörtlich: erklär es laut, in eigenen Worten, ohne Fachjargon-Rettungsring |
| **BLÖDSINN!** | **Peer-Korrektur ohne Scham** — der Fehler gehört der Karte, nicht der Person |
| **King Kayfabian** (rotierender Richter) | **Prüfer-Rolle, die wandert** — jeder ist mal Prüfling, mal Prüfer |
| **Story-Mode-Würfel** (Tragic … Forbidden) | **Kontextvariation** — dasselbe Wissen in wechselndem Rahmen abrufen = besserer Transfer |
| **Zwei Karten kollidieren, der Funke springt** | **Differenzialdiagnose.** Zwei Befunde in einem Patienten — was verbindet sie? |
| **Karten sind Beweisstücke, keine Powers** | Kein Punktesystem, kein Gamification-Lack — **Evidenz statt Score** |

Das ist der Grund, warum dieser Fork kein aufgesetztes Edutainment wird: die Regeln, die Georg für
ein Improv-Kartenspiel geschrieben hat, sind zufällig (oder eben nicht zufällig) genau die Regeln,
die Lernforschung für Retention empfiehlt. **Der medizinische Corpus ist das Deck. Der Rest steht.**

**North Star:** *play → learn → apply* als Kreislauf, getragen von Feynman.
Maximaler Recall, maximaler Spaß, visuell befriedigender Flow.

---

## 1 · Die drei Ebenen (und wo sie im Flug sitzen)

**PLAY — die Reise.** Fliegen, Karten sehen, anfliegen, durchfliegen. Aufgabe dieser Ebene:
*Überraschung und Sog.* Sie darf nichts abfragen. Sie ist der Grund, warum jemand die App öffnet,
wenn er müde ist.

**LEARN — die Karte.** Vorderseite = Frage/Bild/Quiz. **Rückseite = Antwort.** Der Durchflug ist der
Flip. Aufgabe: *Recall im Moment der Neugier*, nicht im Moment der Pflicht.

**APPLY — die Anwendung.** VirP-Fall, mündliche Prüfung, Flexikon-Deep-Dive, CME-LEK. Aufgabe:
*Transfer.* Hier verlässt der Nutzer den Flug und kommt mit einem Ergebnis zurück.

Der Kreislauf schließt sich, weil **Apply neue Defizite erzeugt** und Defizite die nächste Reise
bestimmen. Das ist die Schleife, die trägt — nicht Punkte.

### Meta-Motivation (Mario-Ebenen, meine Lesart)
Georg hat dazu ein eigenes Dokument — **bitte in den neuen Chat mitgeben.** Meine Arbeitsversion,
bis es vorliegt:
1. **Sekunde:** Bewegung fühlt sich gut an. → Flug, Boost, Barrel-Roll, Speedlines, Sound. **Steht.**
2. **Minute:** Ein sichtbares Ziel in Reichweite. → die nächste Karte, immer sichtbar, anfliegbar.
3. **Sitzung/Woche:** Etwas wächst, das mir gehört. → das Deck unten links, die Reise als Artefakt,
   der eigene Corpus.
Was bei Mario zusätzlich trägt und uns noch fehlt: **eine Überraschung pro Minute, die nichts kostet.**
(Ein Cube, der sich als Karte entpuppt. Ein Ton, der einmal pro Reise anders klingt.)

---

## 2 · Die Karte als Lernobjekt

**Anki-Kompatibilität ist Pflicht, nicht Kür** — Georgs Corpus liegt so vor, und Import/Export
entscheidet über Adoption.

```json
{
  "id": "med_her2_001",
  "front": { "text": "HER2-Status positiv — welche Konsequenz für die Erstlinie?",
             "art": "media/kfb/Deck_MED_...pdf#p4q2", "mc": ["A …", "B …", "C …", "D …"] },
  "back":  { "text": "…", "answer": 1, "why": "…", "source": "flexikon:HER2" },
  "meta":  { "bloom": 3, "tags": ["Onkologie", "Mamma-Ca"], "deck": "MED", "sr": { "ease": 2.1, "due": "2026-08-02" } }
}
```
- **Import:** Anki-`.apkg`/TSV, Markdown (`Frage :: Antwort`), CSV, und der KFB-Deck-Vertrag
  (2×2-PDF-Crop) — der Loader dafür steht bereits (`card-registry.js`).
- **Export:** dasselbe Format zurück, plus die Reise (`journey.json`, Slice S29).
- **Gemischte Decks sind der Normalfall**, nicht die Ausnahme: MED-Karten + KFB-Karten in einem Pool.
  Der Almanach sagt es selbst — der Funke springt zwischen zwei Stimmungen. Medizinisch: zwischen
  zwei Fachgebieten.

**Multiple Choice auf der Vorderseite, Ergebnis auf der Rückseite.** Anklicken im Flug (die Karte ist
schon camera-facing und klickbar, S22d bringt den Anflug). Kein Balken, kein „3/4 richtig" —
die Karte bekommt beim Durchflug einen **Stempel**: durchgeflogen · verstanden · BLÖDSINN.

---

## 3 · Meine vier stärksten Ergänzungen

**a) Spaced Repetition als GEOGRAFIE, nicht als Zahl.**
Karten, die du nicht konntest, hängen beim nächsten Mal **näher und tiefer** — leicht erreichbar,
fast im Weg. Gemeisterte Karten hängen **höher und weiter außen**. Die Welt IST der
Wiederholungsplan; man sieht ihn, statt ihn zu lesen. Kein „Due: 12 cards" — sondern: da vorne
hängen drei, die dich letztes Mal erwischt haben. Technisch trivial: `sr.ease` → `ring`/`yMin` in
`sky-cards.place()`. **Das ist der Slice, mit dem ich anfangen würde.**

**b) Bloom-Level als FLUGHÖHE.**
Remember/Understand = Tiefflug über dem Boden, dicht an den Cubes, viele Karten, schnelle Abfrage.
Analyze/Evaluate/Create = Reiseflughöhe, wenige Karten, weite Strecken, Zeit zum Erklären. Die Höhe
ist bereits ein Skalar im System (`agl`), der Wind und die Regie färbt. **Bloom kostet uns damit
keinen einzigen neuen Regler** — nur eine Zuordnung. Und der Nutzer *spürt* den Anspruch, statt ihn
angezeigt zu bekommen.

**c) Das Terrain ist die Wissenslandkarte.**
Die Voxel-Welt ist bereits in Regionen mit eigener Palette unterteilt. Region = Fachgebiet.
Höhe/Farbe = dein Stand. Ein dunkles, zerklüftetes Tal ist ein Defizit; eine helle Hochebene ist
gekonnt. Fliegen heißt dann: seine eigene Landkarte sehen. **Das ist die Defizit-Anzeige, die kein
Dashboard braucht** — und sie ist der Grund, warum jemand freiwillig ins dunkle Tal fliegt.

**d) Feynman-Karaoke ist der Kern, nicht ein Modus.**
Der KFB-Karaoke-Modus (S30) *ist* die Feynman-Technik: Karte anfliegen, laut erklären, ohne
Fachjargon, gegen eine Uhr oder ohne. Danach die Rückseite — und optional das Flexikon als
Gegencheck. Ich würde das nicht „Quiz-Alternative" nennen, sondern die **Hauptübung**, und
Multiple Choice als die schnelle Variante für müde Tage.

Dazu drei kleinere:
**e) Wrong ist BLÖDSINN!, nicht falsch.** Der Fehler gehört der Karte. Georgs eigene Regeln sagen es:
*„Wrong tonight, right tomorrow, teachable by breakfast."* Das ist die richtige Haltung für
Prüfungsangst — und sie ist markenkonform, nicht therapeutisch verkleidet.
**f) Die Zielflagge als Durchflug.** CME-Punkt, Kapitelabschluss, LEK bestanden: immer ein
*Durchflug*, nie ein Dialog mit „OK"-Button. Eine Geste, kein Formular.
**g) Ein Exkurs ist eine Abzweigung.** Wenn der Copilot merkt, dass etwas fehlt, hängt er eine Karte
seitlich in den Himmel — kein Popup. Der Nutzer entscheidet mit dem Steuer, ob er hinfliegt.

---

## 4 · Eingebettete DocCheck-Anwendungen

Die Würfelseiten sind die Systemgrenze: **der HUD-Würfel wird das Betriebssystem** (statt Tacho).
Sechs Seiten = sechs Einstiege. Das ist schon gebaut — er dreht, er ist anklickbar, er ist markenfähig.

| Seite | Inhalt | Technischer Weg |
|---|---|---|
| **Flexa** | KI-Avatarin: Onboarding-Clips, LLM-Chat, Tutorhinweise | Video-Element + Chat im Würfel-Overlay |
| **Reise** | Journey-Setting, Import/Export, Deck-Auswahl, Ziel | `journey.js` (S29) |
| **VirP** | Virtuelle Patientenfälle, Behandlungssimulation, LLM-Dialog | Embed der DC-App, Voice-First |
| **Prep** | Mündliche Prüfung: Prüfer-Archetyp würfeln, Bloom-Level wählen | Embed + Audio-Call |
| **Flexikon** | Definition, Recap, Deep Dive | Mediawiki-API → Karte oder Overlay |
| **CME** | Webinare/Videos mit LEK, Punkte, Nachweis | Video + Zeitlimit-Flugstrecke |

**Voice-First-Steuerung** ist bei VirP und Prep kein Gimmick, sondern der Punkt: ein Prüfungsgespräch
tippt man nicht. Ehrliche Einschränkung, die ins Sprint-Risiko gehört: Browser-Spracherkennung ist
je nach Plattform unterschiedlich gut, und eine echte Echtzeit-Sprachschleife über ein LLM ist ein
eigener Slice mit eigenen Kosten. **Erst Text mit Sprachausgabe (mit Ducking, siehe unten), dann
Vollduplex.**

**Ducking ist Pflicht.** Sobald der Narrator/Prüfer spricht, müssen Musik und Soundscape weichen.
Im Rollercoaster ist das noch nicht gut gelöst; die Griffe liegen in `travel-audio.js` bereit
(`master`, `musicGain`, `fxBus`). Ein Bus, eine Zeitkonstante, fertig — und **nicht** einfach die
Musik ausschalten: absenken auf ~25 %, 250 ms rein, 600 ms raus.

**CME-Realität, nicht UI-Frage:** Fortbildungspunkte hängen an formalen Anforderungen
(Lernerfolgskontrolle, Nachweisbarkeit, teils Zertifizierung durch die Kammer). Der Flug kann die
*Oberfläche* sein, aber die Nachweiskette muss auditierbar bleiben. **Früh mit den Fachleuten klären,
bevor die Zielflagge Punkte verspricht.**

---

## 5 · Marke, Skin, White Label

**Ein Skin ist ein Manifest, kein Fork.** Das ist die wichtigste Architekturentscheidung für das
Geschäftsmodell: sobald Pharma-Kunden eigene Reisen bekommen, darf niemand Code kopieren.

```json
{
  "id": "doccheck",
  "brand": { "primary": "#cc0033", "ink": "#000000", "paper": "#ffffff",
             "wordmark": "…/dc-wordmark.svg", "font": { "display": "…", "text": "…" } },
  "mascot": { "type": "sprite2d", "asset": "…/dc-doc.svg", "billboard": true, "shadow": "blob" },
  "cardBack": "…/dc-card-back.png",
  "decks": ["med_core", "onko_2026"],
  "narrator": { "persona": "flexa", "voice": "de-DE-…", "ducking": 0.25 },
  "world": { "palette": "clinical", "danceMode": "steady", "storyModes": ["Heroic", "Mystical"] },
  "goals": { "type": "cme", "points": 4, "timeLimit": 2700 }
}
```
Alles, was ein Kunde ändern darf, steht in dieser Datei. Alles andere ist Kern. **Prüfstein für jeden
neuen Slice: „Wäre das im Skin-Manifest oder im Kern?" — wenn die Antwort unklar ist, ist der Slice
noch nicht fertig gedacht.**

**DocCheck-Maskottchen als 2D-Hampelmann**, immer zum Nutzer gedreht: das ist billiger *und* besser
als 3D — die Marke bleibt exakt, und Billboarding haben wir schon (die Sky-Karten machen genau das).
Rote Karte `#cc0033` mit Wortmarke als Kartenrückseite: ein Texturtausch in `card-carrier.js`.

**Blocky Characters** (`GLB_block_chars`, `GLB_blocky_chars` im Repo) neben den 24 Pets: Auswahl,
Personalisierung, Level-Belohnung. Zu klären: ob die Kenney-Modelle einen gemeinsamen Texturatlas
teilen (dann ist Skinnen ein Bildtausch) oder pro Modell eigene Materialien haben (dann pro Figur
Arbeit). **Vor dem Slice einmal ein GLB inspizieren** — die Antwort entscheidet, ob „24 + N Figuren"
ein Nachmittag oder eine Woche ist.

**Zwei Tonlagen, ein Kern.** KFB ist laut, respektlos, BLÖDSINN. Eine Oberärztin, die CME-Punkte
sammelt, braucht dieselbe Mechanik in seriös: gedeckte Palette, kein Cartoon-Pet, sachliche Copy.
Beides aus demselben Manifest. Ohne diesen Schalter verliert das Produkt genau die Zielgruppe, die
zahlt.

---

## 6 · Backlog DocCheck-Fork (Vorschlag zur Priorisierung)

**Fundament (ohne das geht nichts):**
- **D1 · Skin-Manifest + DC-Skin.** `#cc0033`, Wortmarke, Kartenrückseite, 2D-Maskottchen-Billboard.
  Beweist die White-Label-Architektur am ersten echten Kunden (DocCheck selbst).
- **D2 · Karte mit Vorder- und Rückseite.** Flip beim Durchflug, Antwort auf der Rückseite.
  Ohne das ist es keine Lernkarte. *Der eigentliche Kern-Slice.*
- **D3 · Anki-/Markdown-Import.** Ein Deck aus Georgs Corpus im Flug, ohne Umweg.

**Lernschleife:**
- **D4 · Multiple Choice auf der Karte**, Ergebnis auf der Rückseite, Stempel statt Score.
- **D5 · SR als Geografie** (§3a) — Karten wandern nach Können näher/ferner.
- **D6 · Bloom als Flughöhe** (§3b).
- **D7 · Feynman-Karaoke** (KFB S30, medizinisch gerahmt) + Flexikon-Gegencheck.
- **D8 · Terrain als Wissenslandkarte** (§3c).

**Anwendung:**
- **D9 · Würfel als Betriebssystem** — sechs Seiten, sechs Einstiege, Flexa auf Seite 1.
- **D10 · Flexikon-Anflug** (Mediawiki-API → Karte).
- **D11 · CME-Flugstrecke mit Zeitlimit + Zielflagge.** Vorher: Compliance klären.
- **D12 · VirP-Embed**, Text + Sprachausgabe mit Ducking.
- **D13 · Prep-Embed**, Prüfer-Archetyp würfeln, Bloom wählen.
- **D14 · LLM-Lernguide/Builder** — Reise aus Ziel und Defiziten bauen, Exkurse als Abzweigung.
- **D15 · Videos/Podcasts als Weltobjekte** (Monitor-Cubes, KFB S9) statt als Player-Overlay.

**Später:**
- **D16 · Blocky-Character-Auswahl** + Skinning.
- **D17 · White-Label-Kundenreisen** (Manifest + eigene Decks + eigenes Ziel).

**Aus KFB übernehmen, sobald dort fertig:** S22d (Anflug), S29 (Reise als JSON), S30 (Karaoke),
S22b/c (Strahlen, Wind), S26 (Deck-UI), S28 (Narrator).

---

## 7 · Offene Entscheidungen (für den neuen Chat)

1. **Ein Projekt oder zwei?** Mein Rat: **zwei Projekte, ein Kern.** KFB bleibt der Spielplatz (laut,
   experimentell); DocCheck ist das Produkt. Gemeinsame Module wandern per Housekeeping-Sync — und
   zwar **immer in eine Richtung pro Slice**, sonst divergieren die Forks. Wer synct, schreibt in
   `github.md`, was er mitgenommen hat.
2. **Wo liegt der medizinische Corpus?** Eigenes Repo, eigenes Manifest? Lizenz gegenüber
   Pharma-Kunden?
3. **CME-Compliance:** Was muss nachweisbar sein, damit die Zielflagge Punkte geben darf?
4. **LLM:** Welcher Weg im DC-Workspace (Endpunkt, Kosten, Datenschutz bei Patientendialogen)?
5. **Mario-Doc:** bitte in den neuen Chat mitgeben — ich will die drei Ebenen 1:1 gegen unsere
   Schleife legen, nicht meine Arbeitsversion behalten.
6. **Bewegungsempfindlichkeit:** ein Lernwerkzeug muss auch ohne Flug funktionieren (Walk-Modus,
   Ruhe-Palette, weniger Kamerabewegung). Als Skin-Option, nicht als Nachgedanke.

---

## 8 · Was ich am Konzept für stark halte — und was riskant ist

**Stark:** Die Mechanik ist nicht geliehen, sie passt. Ein Kartenspiel, dessen Kern das Verbinden
zweier widersprüchlicher Karten ist, IST Differenzialdiagnose. Ein Spiel, dessen Ritual „erklär es
laut und steh dahinter" heißt, IST Feynman. Und ein Spiel, in dem niemand verliert, nimmt der
Prüfungsangst genau das, was Lernen blockiert. Das ist selten — die meisten Lern-Gamifications kleben
Punkte auf Karteikarten und hoffen.

**Riskant, in dieser Reihenfolge:**
1. **Zu viele Einstiege zu früh.** Sechs Würfelseiten mit sechs eingebetteten Apps sind sechs
   Projekte. Erst *eine* Schleife, die trägt (D2 → D4 → D7), dann Embeds.
2. **Der Flug kann der Sache im Weg stehen.** Wer für eine Prüfung lernt, will manchmal nur 40 Karten
   in 10 Minuten. Dafür braucht es einen sehr schnellen Modus, der dieselben Daten nutzt.
3. **Glaubwürdigkeit.** Cartoon plus CME-Punkte kann als unseriös gelesen werden. Die zwei Tonlagen
   aus §5 sind kein Nice-to-have.
4. **Content-Menge.** Die Welt ist unendlich, der Corpus nicht. Der Import muss so leicht sein, dass
   Nutzer eigene Decks mitbringen — sonst ist die Landschaft nach zwei Sitzungen leer.

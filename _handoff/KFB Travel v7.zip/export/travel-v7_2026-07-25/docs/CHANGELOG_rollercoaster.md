# Rollercoaster Ride — Changelog

Strang B des Infinite-Canvas-Projekts: der WebGPU/TSL-Coaster. Eigene Datei,
damit der Table-Changelog (`CHANGELOG.md`) sauber bleibt.

Versionierung: eingecheckte Versionen einfrieren, Weiterbau als neue Datei
(`rollercoaster-ride.vN.js` + `Rollercoaster Ride vN.dc.html`).

---

## v8 · 2026-07-19 · Partikel-Tuning „in Action" (Kopie von v7)

**Dateien:** `Rollercoaster Ride v8.dc.html` + `rollercoaster-ride.v8.js`. Import-Map identisch zu v7
(pet-select.v7, pet-library.v6, eye-rig.v3, motion.v1, voice.v3, rc-ink geteilt). **v7 eingefroren.**

Die im **KFB Particle Test v1** ertunte Config wurde versucht zu portieren — **Global-Bloom lässt
sich aber nicht in die Ride heben, ohne 3D-Geometrie mitzureissen** (Karte/Augen/Würfel brennen).
v8 daher **auf v7-Bloom-Niveau zurükstabilisiert** (kein Ausbrennen), COSMIC-Palette bleibt als Vorrat.
Details: `docs/HANDOVER_v8.md`, `docs/SPRINT_KICKOFF_selective-bloom.md`:

- **Bloom-Pipeline** bleibt v7-sicher `bloom(col,0.8,0.2,0.85)` (Versuche 2.1/0.5/0.42 → Karte aus; /1.0 → Augen+Würfel aus — beide verworfen).
- **Orbit-Stream-Palette** → **COSMIC** behalten (Bloom-unabhängig, aktuell vom Gold-Tint 0.45 überlagert).
- Hot-Cores zurück auf v7 (1.7/1.8).
- **Erkenntnis:** echter Partikel-Glow in-Ride braucht **Selective/Emissive-Bloom (MRT)** → Sprint 7.

---

## v5 · 2026-07-17 · gestartet (Kopie von v4)

**Dateien:** `Rollercoaster Ride v5.dc.html` + `rollercoaster-ride.v5.js` + `pet-select.v5.js`
(Import-Map zeigt auf v5; `frizzlebob-voice.v3.js` + Pet-Stack bleiben geteilt, werden bei
erster v5-Änderung kopiert). v4 bleibt eingefroren.

- **Bugfix Karten-Crop:** PDF-Zellen trugen links/rechts gedruckte Panel-Rahmen der Nachbar-
  zellen ins Karteninnere. Crop-Inset (3.5% h / 2.5% v) rasiert sie ab — die irregulare
  schwarze KFB-Tuschekante ist jetzt die EINZIGE Einfassung, immer sauber auf der Kante.
- **Fullscreen-Toggle** im Tacho-Pad (max): VIEW-Zeile mit ⛶ FULL / ⛷ EXIT rechts außen,
  Label folgt `fullscreenchange` (auch bei ESC).
- Ortslabel: V5.

Geplant (aus HANDOVER v4): Die Hand → Beat-Meter + Tacho-Eichung → Konsole → Explore-Mode.

---

## ❄️ v4 EINGEFROREN · 2026-07-17 · MVP+ (Takt, Portal, Partikel, Musikbett)

**Stand beim Freeze** — `rollercoaster-ride.v4.js` + `pet-select.v4.js` + `frizzlebob-voice.v3.js`
+ `Rollercoaster Ride v4.dc.html`. Ab hier nur noch Bugfixes; Weiterbau als v5-Kopie.

### Seit dem Ring dazugekommen (Sprint-Verlauf, chronologisch)

- **Cover-Gate & Deck-Selector:** Select → Cover-Card frontal (idealer Viewport), ENTER-Button +
  Deck-Dropdown floaten VOR der unteren Kante; „?"-Fluffy-Die (Shantell) = Random-Deck („I feel
  fluffy"), Mausrad = Deck-Cycle. Cover rendert im Held-State über Track/Pfosten (depthTest off).
- **Cockpit-Position:** Pet unten links (Screen-Projektion, Fluchtung mit Tacho-Pad), faced den
  Spieler, Pupillen folgen dem Cursor (pointerleave → Blick zum Spieler). Storytelling-Default.
- **Deck-Loading robust:** Retry mit Backoff (3×), Self-Healing über `assignCards`/`loadDecks`,
  gedeckelt (kein Endlos-Loop). Pet-Contract ebenso (3×) — kein Gelb-Fallback mehr bei Fetch-Fail.
- **Partikel-Ströme (North Star linked particles):** Turbulenz (mx_noise, pro Partikel), ~7.600
  Punkte an den Rohren (im Glas + Spirale), White-Hot-Cores (>1) als Bloom-Futter. Size-Fix
  240→800 (Retina-Subpixel). Links-Experiment (LineSegments) wieder raus — kreuzte in Kurven.
- **Cartoon-Speedlines statt Links:** 12 GPU-Dash-Lanes auf vorab gebauten Track-Konturen —
  a) 2 lange Leitplanken, b) 4 mittlere Richtungslinien, c) 6 kurze Schweife; Köpfe driften um
  den Fahrer, Puls/Fade speed-gekoppelt. Null CPU/Frame, kein Kreuzen (WebGPU-Limit: max 8
  Vertex-Buffer — gelernt, head steckt in aP2.z).
- **Funkenregen:** 900 Sparks vom Rad/Schienen-Kontakt, Gravitation, Duo-Tone-Flicker (Pet↔Mode),
  Kurven-G aus Tangenten-Drehrate → Zentrifugal-Auswurf zur Außenseite.
- **Fahrtwind:** 320 kamera-gebundene Nahbereich-Streaks (Ring um Blickachse), folgen der
  Kamera-Weltpose pro Frame. ⚠️ NIE `camera.add()` + `scene.add(camera)` — reparented die Kamera
  aus dem Ride-Rig („Pet fährt ohne mich"-Bug; als Feature notiert → Explore-Mode, Backlog 48).
- **Zwei Themes = zwei Blend-Modi:** Aquarell = MultiplyBlending (+premultipliedAlpha, WebGPU!)
  mit ink-Farben (Pigment); Nacht/Space/Shader = Additive + Bloom + ACES. Bloom-Threshold 1.0 —
  nur >1-Hot-Cores bloomen, Kartenpapier bleibt lesbar.
- **Pfosten als Kraftfeld:** Grazing-Angle-Shading (frontal dünn, streifend glüht) killt die
  Ecken-Quadrate (Fake-3D-Tell); Distanz-Fade ab 70 m; Streben laufen unten weich aus.
- **BRIEF Takt (Ten-Regel):** Karte STILL solange man liest; Flattern erst im Ten-Fenster
  (letzte ~5 s); Ketsu = Stille (signierte Along-Track-Distanz — kein Wieder-Reinflattern).
  Kayfabe fraktal: Ki = Name fällt ~19 s BEVOR man die Karte sieht, Shō = Power beim Lesen,
  Ten = Lore-Punch, Ketsu = still.
- **BRIEF Takt (Call pro Seite):** EIN `window.claude.complete`-Call pro 4er-Seite
  (Ki/Shō/Ten/Ketsu-Beats als JSON), getriggert am Ten der Vorkarte (~19 s Vorlauf). Beats auf
  `card._beat` (überlebt Reassign), sprechen auf der Eins (ersetzen die Shō-power-Zeile).
  Ohne window.claude: Pool + **Fluffo-Lekt** (Operator in `frizzlebob-voice.v3.js`: jede ~4.
  Zeile EIN tragendes Wort → fluff, Suffix-erhaltend; Namen & Kayfabe-Rufe nie).
- **BRIEF Portal (Transition Mode):** Settings-Toggle Curtain ↔ Portal (persistiert). Portal:
  Karte steht still, löst sich oval von innen auf (shared alphaMap: Radial-Gradient + Value-
  Noise, steigender alphaTest), rückwärts = gleicher Shader. Cloth-Sim in Portal-Mode aus.
- **Karten-Magnet = Takt-Metronom:** Shō zieht ab ~100 m auf Lesetempo, Ten (−6…+4 m) lässt
  durchschnappen; `grade` steuert die Haltezeit (G1 1.0 · G2 1.5 · G3 2.0). Track-Builder darf
  damit würfeln — die Karten kommen trotzdem auf der Eins.
- **KFB-Tuschekanten:** `inkFrame2D` (2-Pass-Wobble, immer schwarz) auf jeder Karte: Curtains,
  Cover, Library.
- **Musikbett (HANDOVER v5 vorgezogen):** Van_Metronome.mp3 (104 BPM, D dorian), DRY an master
  (nicht reverbIn), 0.26; kein Loop — Auslauf → ~5 s Drone (Luft) → Neustart. Takt-Uhr
  (`audio.bpm`/`beat0`) am AudioContext, nie am Track. Voice-Duck greift mit.
- **Sound-Kontrolle komplett:** Settings-Slider MUSIC (0–0.6, 0 = Quelle stoppt) + DRONE (0–2×,
  Multiplikator aufs speed-gekoppelte Bett), beide persistiert. Dazu SOUNDSCAPE/FRIZZLEBOB/VOICE.
- **Pet-Select-Feinschliff:** IBL aus dem Watercolor-Himmel (PMREM, async-Init), Tint nur wo die
  Library `color` vorgibt, Contact-Shadow an der Karte (kein Z-Fighting-Blinken), Karten-Aspect
  aus dem echten PNG, Klick-Fix (max-Abweichung statt Jitter-Summe — kein Doppelklick mehr).

### Offen beim Freeze (→ HANDOVER_rollercoaster_v4.md, Backlog)

40 Geisterbahn · 41 Pet-Ride-Slider · 45 Outline-Hull · 46 3D-Fluffy-Die + Roll-Anim ·
48 Explore-Mode · 49 Tacho-Eichung · 50 Beat-Meter · Die Hand (HANDOVER_v5_die_hand.md) ·
Konsole/Kartenhand · Voice/TTS-Zweitstimme.

---

## v4 · 2026-07-17 · Pet-Auswahl-Ring (B-v4.1) — der Einstieg

**v4 begonnen** (Kopie von v3). Neuer Entry-State VOR der Fahrt: kein Track, nur Himmel und ein
Karussell. Eigenes Modul `pet-select.v4.js`; `boot()` startet jetzt die Auswahl, `onSelect(petId)`
übergibt an den Ride (`RideV2.selectedPetId` → `loadPet` lädt genau dieses Pet, recolort mit
seiner Contract-Farbe statt hart Gelb).

- **Ring:** 12 spielbare Pets (die mit Stimme: bunny, fox, cat, panda, koala, tiger, deer, monkey,
  crab, lion, giraffe, polar) auf waagerechtem Kreis, **jedes nach außen gedreht** (das vordere
  schaut den Spieler an). Aus dem Contract geladen (`Character`, `pet-library.v6`), Farbe/Name/
  Archetyp aus dem Contract — nichts hardcoded. **Rund:** Character ruft nie `computeVertexNormals`
  (kein eckiger Hase). Auf dem Ring bewusst **ohne Eye-Rig** → Kenneys gebackene Augen sind hier
  korrekt und es bleibt leicht.
- **Scroll/Drag/Pfeiltasten** drehen den Ring, **Snap mit Overshoot** (`easeOutBack`, turn-Feel
  ~0.2): rastet nicht ein, schwingt über und kommt zurück. Alle Pets atmen (`PetMotion` idle-Loop).
- **Fokus:** KFB-Kartenrücken als **schwebendes Podest** (floatet + dreht sich langsam), **Spot**
  von oben, weiche Kontakt-Schatten-Blende. Kartenformat = KFB-Ratio (0.72).
- **Hover:** Raycast → **`reactPos`** auf dem getroffenen Pet — das *Pet* reagiert, keine
  UI-Umrandung/kein Glow.
- **Sprechblase:** KFB-Tuschelinie **1:1 aus `infinite-journey.v3`** (`brushLoop`/`inkRibbon2D`/
  `inkChip2D` kopiert, keine zweite erfunden), Name + Archetyp, erscheint **erst NACH** dem Snap.
- **Select:** `celebrate` (3 Hops) → Fade → Handoff in den Ride mit dem gewählten Pet.
- **Noch offen (B-v4.1 Rest):** Select → **Deck-Cover-Panel + ENTER → Curtain-Durchfahrt als
  erste, langsame Fahrt** (Onboarding, das wie ein Vorhang aussieht). Aktuell springt Select direkt
  in den Ride. Nächster Schritt.

---

## ❄️ v3 EINGEFROREN · 2026-07-17 · MVP erreicht

**v3 ist eingecheckt und eingefroren.** Fahrt + Kurven + Karten (keine Rückseite, gemischt,
progressives Streaming, echte PDF-Grafik) + Würfel/Tacho + Skydome (Watercolor/Space/Shader) +
Curtains + 4-Layer-Soundscape + Pet (Augen gefixt: converge + Follow-Gaze, gebackene Schalen
gestrippt) + **FrizzleBob-Voice POC (Ebenen 0+1)** stehen. Weiterbau ab hier NUR als `v4`
(`Rollercoaster Ride v4.dc.html` + `rollercoaster-ride.v4.js`), diese Dateien nicht mehr anfassen.
Roadmap: `docs/BACKLOG.md` §Strang B. Kickoff für den neuen Chat: `docs/V4_KICKOFF.md`.

---

## v3 · 2026-07-17 · FrizzleBob-Voice POC (Kayfabulate, Ebenen 0+1) — MVP-Abschluss

Letzter Baustein vor dem v3-Check-in. Browser-TTS, Englisch, kein LLM. Umsetzt
`KAYFABULATE_POC.md` eins zu eins. Neues Modul `frizzlebob-voice.v3.js`, im Ride
verdrahtet; eigener **FRIZZLEBOB**-Toggle in den Settings (getrennt vom SOUNDSCAPE,
damit die Stimme isoliert testbar ist). Standardmäßig aus.

- **Ebene 0 (Reflex, null Latenz):** Phrase-Pools hart im Code. Kurve (hohes `c` > 0.55) →
  Kurven-Pool, Drop (hohes `j` > 0.6) → Schreck-Pool, Mode-Wechsel (`rollDice`) → eine Zeile
  pro Story-Mode (TRAGIC…FORBIDDEN). Getriggert aus dem **Drive-Bus** (`this.drive`), mit
  Cooldowns wie die Sound-FX. **Stillstand ist still** (`drive.v < 0.03` → keine Reflexe).
- **Ebene 1 (Karte):** an der Vorhang-Kreuzung (`d < 6 m`) bellt FrizzleBob die `power` der
  Karte (Punch), ~2,4 s später die `lore` (Nachsatz) — beides direkt aus dem Deck-JSON, das
  jeder Vorhang schon trägt (`cur.card`). 5-s-Cooldown pro Vorhang.
- **TTS-Grenzen respektiert:** kein SSML/Markup im Text (macOS liest es sonst vor) — Pausen
  entstehen durch Zerlegen in mehrere `SpeechSynthesisUtterance`, verkettet über
  `onend`+`setTimeout`. Gedankenstriche → Komma. **Nie zweimal dieselbe Zeile hintereinander**
  (Picker mit Last-Index-Guard). `rate`/`pitch` pro Utterance variiert (Punch schneller+höher,
  Nachsatz langsamer+tiefer) plus Jitter, damit es nicht wie ein Vorleser klingt.
- **Degradiert weich:** `getVoices()` erst leer → `onvoiceschanged`; keine `en`-Stimme →
  `ready=false`, Ride läuft stumm weiter. Nie auf eine benannte Stimme gebaut (nimmt die erste
  `en-US`, sonst erste `en`). Verifiziert: Stimme *Albert / en-US*, Sprechen startet/bricht sauber,
  Picker ohne Doppler.
- **Priorität:** Reflexe/Nachsatz = 1, Drop + Karten-Punch = 2 (darf einen laufenden 1er
  abbrechen, aber nie einen gleich-/höher-priorisierten). Kein Stapeln.
- **Noch offen (v4+):** Ebene 2 (LLM-Closure), die sechs Narrator-Kadenzen (`data/narrator/`,
  B-v4.3), Session-NDJSON für passierte Karten. Der POC baut bewusst nur 0 + 1.
- **Nachschliff (nach Gegenhören + `SOUND VOICE TTS-perplexity.md`):** Der wahre Übeltäter war
  die *Stimme*, nicht die Parameter — automatisch landete man auf *Albert* (macOS-Jux-Stimme,
  dünn/roboterhaft). Jetzt **Stimm-Scoring statt „erste en"**: Netzwerk-/Enhanced-/Google-/
  Microsoft- und bekannt gute System-Stimmen (Samantha, Alex, Daniel…) zuerst, Novelty-Stimmen
  (Albert, Zarvox, Bahh, „Bad News"…) per Blocklist ganz nach hinten. Wählt jetzt **Samantha**.
  Plus **Stimm-Dropdown in den Settings** (Geräte-abhängig „beste Stimme" — User-Override, 41
  en-Stimmen). **Ducking:** die Drohne tritt beim Sprechen auf 0.3 zurück (löst „zu leise").
  Tempo weiter gesenkt (Punch 0.85, Nachsatz ~0.73) für Verständlichkeit bei Nicht-Muttersprachlern.
  `voiceschanged`-Nachfass-Timeout für Firefox/Safari.
- **Soundscape-Squeal behoben:** Reverb-Feedback war zu hoch (bis 0.76 mit kurzem Delay → Klingeln);
  jetzt ~0.28–0.5, dunklere Dämpfung (1100 statt 1800 Hz), weniger Wet.

---

## v3 · 2026-07-17 · Polish-Pass — Karten zum Fahrer, Tacho-Würfel, Skydome B

Nachtrag auf v3 (Karten-/HUD-Feedback aus `HANDOVER_cards_und_bremse.md`). Der
Freeze aus dem Check-in gilt weiter — der nächste NEUE Baustein (Pet-Auswahl, Voice)
wird trotzdem v4.

- **Pet-Augen: Kenneys gebackene Augen-Schalen werden gestrippt (`face.stripEyes`).** Die
  „Original-Augen unter den Eyeballs" waren **Geometrie** (2 Schalen im body-Mesh), keine Textur.
  Neuer `face`-Block in `pet-LIBRARY.json` v0.4.2 (Cowork 2026-07-16) liefert die Regel; unser
  Loader setzt sie jetzt um: `stripEyeShells()` weldet per Position, findet via Union-Find die
  Connected Components und entfernt das **symmetrische X-Paar an `zPlane 0.635` mit ≥`minTris`
  Dreiecken** — nur Index-Einträge fallen weg, die Original-Normalen bleiben (kein Re-Facetting).
  Zentrale Schalen (Nase/Mund) und Nasenlöcher fallen durch Symmetrie-/minTris-Filter raus.
- **Karten haben keine Rückseite (Meta-Narrativ).** Anders als im Kartenspiel sind die
  Vorhang-Karten jetzt **immer zum Fahrer gebillboardet** — durchgängig lesbar, auch beim
  Durchfahren. Der frühere Blend zu einer fixen fahrtrichtungs-orientierten „Gate"-Pose
  (mit gespiegelter Rückseite) ist raus; damit entfällt auch der UV-Mirror (Front zeigt
  immer zum Rider). Die Durchfahr-Perpendikularität bleibt, weil das Billboard am Pass-Moment
  ohnehin quer zur Fahrt steht.
- **Test-Modus: Decks A–C durchgemischt + progressives Vorladen.** `assignCards` baut einen
  einzigen gemischten Cross-Deck-Pool (deterministisch, keine direkten Deck-Wiederholungen)
  statt striktem Round-Robin. Echte PDF-Grafik wird nicht mehr in einem Batch beim Start
  geladen, sondern **während der Fahrt** — der jeweils nächstgelegene noch nicht geladene
  Vorhang wird gestreamt, **eins nach dem anderen** (`ensureCardArt`, `_artBusy`-Throttle),
  Seiten-Cache dedupt gleiche PDF-Seiten. Kein Start-Ruckler mehr.
- **Deck-Library + Reset (Settings-Modal).** Rechtsklick → Settings hat zwei neue Zeilen:
  **RESET RIDE** (zurück an den Streckenanfang, Free-Look genullt) und **DECK LIBRARY**.
  Die Library liest die `index.json`-Registry (`assets/kfb-index.json`) und listet alle
  4 Decks + 5 Regel-/Comic-Booklets. Klick rendert das **echte PDF inline** — pdf.js
  (CDN, lazy geladen) zieht die Seiten direkt aus dem KFB-GitHub (`baseUrl` + Dateiname),
  plus „↗ open in tab"-Link. Escape schließt Library/Settings.
- **Echte Karten-Grafik auf den Vorhängen.** Die typografischen Platzhalter werden im
  Hintergrund durch die **echten Kartenbilder aus den Deck-PDFs** ersetzt — Crop-Logik 1:1
  aus `kfb-table.v2.js` übernommen: `page = coverOffset+1+floor((n-1)/4)`, `quadrant = (n-1)%4`,
  exakte Hälften, Seiten-Cache. Aspect bleibt erhalten (contain-fit auf Tusche-Papier, kein
  Stretch), Grafik korrekt lesbar auf Anfahrt (eigener UV-Flip gegenüber dem Banner).
  pdf.js-Loader/`renderPdfPage` teilen sich Library & Vorhänge.

- **Karten stehen richtig herum (HANDOVER §3).** Die Vorhang-Ebene zeigt mit der Normale
  in Fahrtrichtung; der Fahrer nähert sich von hinten und las bisher die gespiegelte
  Rückseite. Fix: Textur beim Setzen **einmal horizontal gespiegelt** (`repeat.x=-1`),
  nicht pro Frame — auf Anfahrt lesbar, nach dem Durchfahren bewusst rückseitig
  (eigene Rückseite bleibt eine getrennte Entscheidung).
- **Tacho = 3D-Würfel (Cockpit-Metapher).** Der flache SVG-Bogen + die „STORY MODE"-Zeile
  sind weg. Stattdessen sitzt unten rechts ein echter D6 an der Kamera: die zur Kamera
  zeigende Fläche = die aktuelle Story-Mode-Augenzahl (1..6), getönt in der Mode-Glow-Farbe.
  Er **rattert stärker mit Speed** (der Tacho „dreht hoch", die Fläche bleibt lesbar) und
  **tumbelt auf die neue Fläche bei jedem Wurf**. Gegenlager = dunkle Scheibe, damit er
  gegen den hellen Aquarell-Himmel liest. Handgemalte Tusche-Pips auf Papier (KFB-DNA,
  kein Casino-Glanz). Restliche Telemetrie (SPEED/E-KIN/NEXT CARD/GOAL/ROUTE) bleibt schlank.
- **Skydome B als zweite Aquarell-Kuppel.** `skydome_b.webp` liegt in `assets/`. Das
  SKYDOME-Dropdown zyklt jetzt WATERCOLOR A → WATERCOLOR B → SPACE → SHADER; beide
  Aquarell-Varianten teilen eine Kuppel-Mesh, das Dropdown tauscht nur die Textur.

---

## v3 · 2026-07-17 · CHECK-IN (v3 eingefroren) ✅

**Stand:** Das v3+-Paket (Schritte 1–5 aus dem Perplexity-Bauplan) ist komplett und
verifiziert. `Rollercoaster Ride v3.dc.html` + `rollercoaster-ride.v3.js` gelten ab
jetzt als **eingefroren**. Weiterbau (v4+ = Pet-Auswahl, FrizzleBob-Voice, Narrator-Pack)
als neue Datei, siehe `docs/BACKLOG.md` + `docs/ONBOARDING_fresh_claude.md`.

Was in v3 steckt (ein Blick):

1. **Drive-Bus** (v, a, c, j, p, mood) — eine Quelle, alle Abnehmer (Pet, Sound, Himmel,
   Vorhang) hängen dran. `MOODS_UND_FAHRWERTE §2`.
2. **Sechs Würfel im Skydome** statt Planeten — der gewürfelte führt (nah+hell), fünf warten
   (fern+dim), feste Azimut-Sitze (subliminaler Anker). `DICE_IM_SKYDOME`.
3. **Vorhang-Durchfahrt** (Cloth-State-Machine schwebend→Anfahrt→Durchfahrt→settle) +
   echte Deck-Karten aus `index.json` (Cover = erste Durchfahrt). `BRIEF_curtain_durchfahrt`.
4. **4-Layer-Soundscape** (BED/MOTION/EVENT/SPACE) mit einer spektralen Identität je Mood +
   sechs HRTF-Würfel-Richtungsquellen. `KAYFABULATE_POC` (Audio-Teil).
5. **Shader-Dome** als optionaler dritter Sky-Mode (domain-warped fbm, non-repetitiv,
   phase = ∫ speed·dt → kein Loop). `MOODS_UND_FAHRWERTE` (Visuelle Bauweise).

Dazu in diesem Check-in:

- **Pet-Augen-Fix** (Feedback „Augen leicht off"): Die Geometrie war korrekt (Augäpfel
  sitzen in der Face, kein Float), aber `converge:0` machte die Augen wandäugig und der
  Idle-Blick zuckte alle ~2 s weg. Fix **von der Ride-Seite** (das geteilte
  `pet-eye-rig.v3.js` bleibt unangetastet): `converge=0.13` + Follow-Gaze aktiv, die Pupillen
  bekommen pro Frame einen sanften Rider-Bias (`pointTo`) → das Pet schaut dich ruhig an,
  statt zu driften (Prime Directive: settlet in Ruhe).
- **Narrator-Prompts geborgen**: alle 12 Stimmen aus `media/prompts/narrator/` liegen jetzt
  lokal unter `data/narrator/` (für v4-Voice-Sprint + Standalone). `data/narrator/README.md`.

**Bekannte Grenze:** WebGPU-only (Chrome/Edge). Firefox/Safari-Fallback ist P1 im Backlog.

---

## v3 · 2026-07-17 · Schritt 5 — Shader-Dome als dritter Sky-Mode

Dritter, optionaler Himmel neben WATERCOLOR und SPACE (Settings → SKYDOME
zyklt jetzt durch alle drei). Umgesetzt nach Perplexity §Visuelle Bauweise:
Inside-out-Sphere, per-Pixel Fragment-Shader (TSL), non-repetitiv.

- **Domain-warped fbm**: 4-Oktaven-MaterialX-Noise, dessen Sample-Punkt von
  einem eigenen Low-Freq-Noise-Vektor verschoben wird → faltende, gitterfreie
  Marmor-Formen statt sichtbarer Kacheln.
- **State evolves, not time loops** (Prime Directive): die `phase` wird pro Frame
  aus `dt·(0.03 + speed·0.55)` **integriert** — das Feld entwickelt sich weiter und
  kehrt nie in einen früheren Zustand zurück; kein Metronom.
- **Ein Mood = eine Sphäre** (`MOOD_SKY[0..5]`, Index = MODES): je drei Farben
  (Basisfeld → Glow → Hot-Accent) plus warp/contrast/flow. TRAGIC steel/folding,
  COMIC lime/playful, ABSURD color-breaks, HEROIC radiant beams, MYSTICAL
  lavender halos, FORBIDDEN red/black interference. Recolor live beim D6-Roll.
- **Velocity-Layer**: Speed hebt Helligkeit + schärft die fließenden Ribbon-Beams,
  Beschleunigung öffnet den Kontrast — gespeist aus demselben Drive-Bus wie Sound
  und Pet.

Damit ist das v3+-Paket (Schritte 1–5) komplett: Drive-Bus, sechs Würfel,
Vorhang-Durchfahrt + echte Deck-Daten, 4-Layer-Soundscape, Shader-Dome.

---

## v3 · 2026-07-17 · Schritt 4 — 4-Layer-Soundscape + Würfel-Panner

Der alte Sound (Drone + Gate-Shimmer) wird zum kanonischen 4-Schichten-Modell
aus dem Perplexity-Bauplan, gespeist aus demselben Drive-Bus (v,a,c,j) wie Pet,
Vorhang und Himmel — eine Quelle, drei+ Abnehmer (MOODS_UND_FAHRWERTE §2).

- **Ein Mood = eine spektrale Identität.** `AUDIO_MOODS[0..5]` (Index = MODES):
  Grundton, Partialset (harmonischer Charakter), Wellenform, Detune/Instabilität,
  Grundhelligkeit, Reverb-Wet, Puls, Air-Charakter. TRAGIC tief+chorisch+viel Hall,
  COMIC hell+rubbery, ABSURD instabil+Stutter-Puls, HEROIC brass-artig+breit,
  MYSTICAL modal+Riesenhall, FORBIDDEN dunkel+metallischer Resonator+Throb.
- **BED/Drone**: Mood-Partialset, tiefpassgefiltert; Tonhöhe reitet `v`, Cutoff
  öffnet auf `a`. FORBIDDEN bekommt einen klingenden Bandpass-Resonator.
- **MOTION**: Breitband-Air-Noise, Gain ∝ v², Bandpass öffnet mit Speed + Turn.
- **EVENT** (Interpunktion, kein Metronom): Mood-Puls (nur ABSURD/FORBIDDEN),
  plus Turn-Whoosh (stereo-gepannt in Kurvenrichtung, `c`-Spikes, Cooldown 650 ms)
  und Jerk-Thump (`j`-Spikes, 400 ms). Card-SFX bleibt.
- **SPACE**: geteilter Feedback-Delay-Reverb (Wet = Mood). Die **sechs Sky-Würfel
  sind Richtungsquellen** — je ein HRTF-Panner folgt pro Frame dem Welt-Sitz des
  Würfels; der gewürfelte führt (nah+laut, wächst mit v), die fünf warten (fern+
  leise). Listener wandert mit der Kabine → alles pannt in 3D.
- UI: „DRONE SOUND" → „SOUNDSCAPE".

**Nächster Schritt:** 5) Shader-Dome als optionaler dritter Sky-Mode.

---

## v3 · 2026-07-17 · v3+-Paket, Schritt 1 — Drive-Bus + kanonischer D6

Baut auf v2 (XR-Coaster-Strecke 1:1, Bunny vorne, Watercolor-Sphere, Karten
nach Bogenlänge, transparent-pulsierende Schienen). Kopie v2 → v3, v2 eingefroren.

**Umgesetzt (Schritt 1 von 5 des v3+-Pakets):**

- **Kanonische Mode-Farben.** Die alte 6-Farben-Glow-Liste im Code
  (`0x7db6ff …`) ist raus — ersetzt durch die **Print-v4-Legende S.16** aus
  `uploads/09_MODE_COLORS_canonical.md`: sechs Modi mit echtem `ink` + `panel`
  (TRAGIC/COMIC/ABSURD/HEROIC/MYSTICAL/FORBIDDEN). `ink`/`panel` bleiben true
  für UI/Panels; für die Neon-Schiene im dunklen Dome wird `ink` per
  `glowOf()` in HSL angehoben (Hue bleibt exakt, nur Sättigung/Helligkeit
  hoch) — der Mode ist als Farbe erkennbar, ohne die dunkle Tusche zu zeigen.
- **Ein Wurf, ein Mood, eine Fahrt** (MOODS_UND_FAHRWERTE §1). Der D6 rollt
  **einmal** und der Mood hält die ganze Fahrt. Das frühere Verhalten
  „jede Karten-Durchfahrt würfelt neu" ist entfernt — Gate löst nur noch das
  SFX aus. Re-Roll manuell über Settings → STORY MODE (Klick auf den
  Mode-Namen) oder programmatisch `app.rollDice()`. Feste, stabile Farbe ist
  die Voraussetzung für die festen Würfel-Plätze in Schritt 2.
- **Drive-Bus** (MOODS_UND_FAHRWERTE §2). `v, a, c, j, p, mode` werden
  **einmal pro Frame an einer Stelle** gerechnet und als `this.drive`
  bereitgestellt — statt dass sich jedes System sein eigenes `v` aus
  Kamera/Sprungkurve holt und im ersten Looping auseinanderläuft. Felder:
  `v` (Speed 0..1), `vRaw`, `a` (Accel −1..1), `c` (Krümmung aus headingChange),
  `j` (Jerk), `p` (Progress), `mode`/`ink`/`name`. Künftige Abnehmer
  (Vorhang, Himmel, Sound, Würfel) lesen nur noch aus dem Bus.
- **Dashboard** zeigt STORY MODE oben, in der Glow-Farbe des Modes.

**Bewusst NICHT geändert:** Strecke, Pet-Physik, Kamera, Streams, Audio-Drohne,
Watercolor-Sphere — alles wie v2. Nur Farb-Quelle + Mood-Regel + Bus.

---

## v3 · 2026-07-17 · Schritt 2 — sechs Würfel im Skydome statt Planeten

Umsetzung von `uploads/DICE_IM_SKYDOME.md`. Die 9 zufälligen Glow-Planeten aus
v2 (`buildPlanets`) sind entfernt und durch sechs echte D6 ersetzt.

- **Asset per URL, nicht kopiert.** `dice_ugur_lowpoly.glb` aus dem Repo
  (`media/3D_Assets/`), einmal geladen, sechsmal geklont. Zwei Primitives
  (white body / black eyes) — Body wird in der Mode-Farbe (`glowOf(ink)`)
  eingefärbt + `emissive`, Augen bleiben schwarz. `MeshStandardNodeMaterial`,
  KISS: emissive treibt den Glow, die HemisphereLight-Szene shadet den Rest.
- **Feste Plätze für immer** (`DICE_SEATS`). Jeder Mode hat einen festen
  Azimut/Elevation — Würfel i = Mode i, immer am selben Fleck. Das ist die
  Voraussetzung für das Schritt-4-Sound-Anchoring (Forbidden wohnt hinten
  rechts, für immer).
- **Der gewürfelte führt, fünf warten.** Der Leader (`this.mode`) lerpt nach
  vorn (Radius 250, Größe 48, emissive 1.15 + Puls) und **präsentiert sich zum
  Rider** (lookAt Kamera, settlet); die anderen fünf bleiben fern (Radius 440),
  dunkel (emissive 0.30) und driften. Reroll → neuer kommt vor, alter fällt
  zurück, alles per Lerp.
- **Rotation aus `v`, nicht aus der Uhr.** Wartende Würfel driften im Stand,
  spinnen bei Tempo; unharmonische Perioden (`periodF`) je Würfel, damit das
  Auge kein Muster sieht. Liest aus dem Drive-Bus (`this.drive.v`).
- App-Handle `stage.__rcApp` exponiert (Debug/Steuerung).

**Offen / bewusst so:** die Würfel poppen im SPACE-Dome; auf dem hellen
Watercolor waschen sie aus (emissive gegen helles Papier). Sie sind der
Mood-Anker des Doms — ob sie auch auf dem Watercolor erzwungen werden sollen,
ist eine Design-Frage an Georg. Value-Face-Mapping (welche Augenzahl zeigt zum
Rider) ist noch „präsentiert Gesicht zur Kamera", nicht die exakt gewürfelte
Zahl — Verfeinerung, wenn nötig.

---

## v3 · 2026-07-17 · Schritt 3 — Vorhang-Durchfahrt + echte Kartendaten

Umsetzung von `uploads/BRIEF_curtain_durchfahrt.md`. Die flachen Gate-Planes
sind durch echte Stoff-Vorhänge ersetzt, bespannt mit echten Deck-Karten.

- **Cloth-Physik als Block portiert** (`class Curtain`, aus `Curtain
  Reader.dc.html` / three.js `webgl_animation_cloth`): `buildPhysics`,
  `satisfyConstraints`, `simulate` 1:1. Läuft in „Sim-Units" (die Beispiel-
  Zahlen unverändert), Mesh wird per `scale` auf Weltgröße gebracht — so
  transplantieren Gravitation & Wind ohne Umrechnung. **Keine Feder-Falle**
  (der explizit gewarnte `infinite-journey.v5`-Fehler): oben aufgehängt
  (`pins` = obere Reihe), Schwerkraft runter, fertig.
- **Wind = deine Geschwindigkeit, keine Sinuskurve.** `updateCurtains` speist
  `speed01` als Windstärke in Fahrtrichtung (lokales +Z = Tangente). Anfahrt
  bläht auf, das Pet fährt durch (Ball-Kollision aus der Pet-Weltposition),
  danach pendelt der Vorhang aus. Nur die ~4 nächsten Vorhänge simulieren
  (Fenster |Δt|<0.07), der Rest bleibt eingefroren — Performance.
- **Echte Karten, kein Platzhalter.** Die drei Ausstellungs-Decks
  (`forget_utopia` / `ignore_dystopia` / `embrace_protopia`) liegen als lokale
  Kopien in `assets/decks/` (offline, robust), werden per `fetch` geladen.
  `cardFaceTexture` rendert `cardName`, `power`, `lore`, `grade` auf
  Büttenpapier mit Deck-Akzent und Grade-Badge. **Nur die `web`-Dateien** —
  die Druckversionen bleiben draußen (nicht verhandelbar).
- **Richtige Seite / richtiger Quadrant** aus `cardMapping` berechnet
  (`coverOffset=1`, 4 Zellen/Seite, TL·TR·BL·BR) und im Kartenkopf angezeigt
  („#12 · S.04 · TL").
- UV horizontal gespiegelt, damit die Karte von der Anfahrtseite (dem Rider)
  lesbar ist, nicht spiegelverkehrt.

**Offen / bewusst so:** echte Karten-**Artworks** (die PDF-Seiten-Quadranten)
sind nicht eingebaut — wir haben nur die Text-JSONs, nicht die gerenderten
Seiten. Die Vorhänge zeigen ein aus den Daten gestaltetes Kartengesicht, kein
Foto der Druckkarte. Vierter Deck (`sonic_slaughterhouse`) bewusst weggelassen
(nur die drei Ausstellungs-Decks liegen lokal).

**Nächste Schritte:** 4) Soundscape (4 Layer + Würfel-Richtungs-Panner). 5)
Shader-Dome als optionaler dritter Sky-Mode.

---

## v3 · 2026-07-17 · Schritt 3b — Vorhang-Lebenszyklus (State-Machine)

Georgs Feedback: manche Vorhänge waren statisch, manche flatterten, manche
dauergebläht — weil ferne Vorhänge im Warmup-Zustand eingefroren blieben.
Neu: ein durchgehender, distanz-/zeitgesteuerter Lebenszyklus pro Vorhang.

- **`cloth` 0..1 (smoothstep über Bogendistanz)** blendet jederzeit zwischen
  *flacher Karte* (Originalpose) und *Live-Cloth*. Sim läuft nur wenn cloth>0.02
  (~1–2 Vorhänge gleichzeitig). Beim Eintritt in die Live-Phase wird das Tuch
  auf die flache Pose zurückgesetzt → kein Sprung, es bläht natürlich auf.
- **Zustände:** FLOAT (flache Karte, schwebt/pulsiert per Mesh-Bob) → Anfahrt
  antizipiert den Wind (Stärke wächst mit cloth, speed-gekoppelt) → flatternde
  Durchfahrt (Pet stößt das Tuch auf, Ball-Kollision, non-repetitiv) →
  Einpendeln → zurück zu FLOAT. Kein eingefrorener Billow mehr.
- **Ausrichtung blendet mit:** fern dreht sich die Karte träge zum Spieler
  (optimal lesbar, `slerp` mit dt-Lag), bei cloth→1 zurück zur fixen Gate-
  Ausrichtung (Normale = Tangente) → Durchfahrt immer frontal am selben Punkt
  (unteres Drittel).
- **Material MeshStandard→MeshBasic:** kamerazugewandte flache Karten wurden
  von den Szenenlichtern von hinten beleuchtet und rendeten schwarz. Unlit
  (wie die alten Gates) → immer lesbar.
- Platzierung war schon überschneidungsfrei (Bogenabstand + 62-Welt-Einheiten-
  Reject in `buildCards`), bleibt Basis.

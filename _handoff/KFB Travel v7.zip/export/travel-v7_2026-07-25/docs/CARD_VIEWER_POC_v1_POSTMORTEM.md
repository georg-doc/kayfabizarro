# Card-Viewer POC v1 — POST-MORTEM & Version-Check-in (FAILED ATTEMPT)

**Status: FEHLGESCHLAGEN / eingefroren.** Diese Version wird NICHT weiterentwickelt.
**Datum:** 2026-07-15 · **Autor:** Fable (Design-Chat) · **Für:** Cowork-Lead (Opus) + nächster Design-Chat.

Diese Datei ist der ehrliche Nachruf auf v1 und die Übergabe der Lehren. Der saubere Neu-Plan steht in
`CARD_VIEWER_HANDOVER_coworker.md`. Bitte BEIDE lesen, bevor v2 startet.

---

## 1 · Was v1 erreicht hat (das Fundament ist gut)
Diese Teile funktionieren und sind **wiederverwendbar** (nicht wegwerfen):
- **PDF-Karten-Pipeline** (pdf.js, `page = coverOffset+1+floor((n-1)/4)`, `quadrant = (n-1)%4`) — lädt echte Deck-Karten live per GitHub-raw. ✅ robust.
- **Deck-Registry / Multi-Select / Karten-Pool-Ökonomie** (visited nie wieder · Cooldown ≥4 · cross-deck Round-Robin). ✅ logisch korrekt, verifiziert.
- **Mode-Wurf + kanonische Mode-Farben** (deep_specs/09), Skydome-Tönung, i18n DE/EN, Session-Export. ✅
- **Clay-Pet aus v3 Pet-Editor 1:1**: object-space-Triplanar-Cardboard-Shader (`onBeforeCompile`) + Studio-HDRI (`RoomEnvironment`) + Sphere-Eye-Rig aus `pet-LIBRARY.json`. ✅ sieht richtig aus (nach mehreren Anläufen).
- **Zoom/Pan im Rahmen** (Clipping-Planes am Fenster, cursor-zentriert, ziel-gelerpt, kein Ruckeln). ✅
- **2-Res-/LRU-Textur-Budget** (Live-Texturen nie evicten). ✅ (nach dem Schwarz-Panel-Bug gefixt).

## 2 · Was v1 NICHT erreicht hat (der Kern)
- **Kein sauberer, navigierbarer 3D-Raum / kein echtes „infinite canvas"-Gefühl.** Die Bewegung ist ein
  **geskripteter Kamera-Dolly**, keine echte Navigation. Kanten/Ecken lecken Skydome; das Raumgefühl trägt nicht.
- **Pet-Animation schlampig.** Ansatz (Boden-Hüpfer, durch die Wand, zurück in die Control-Ecke) stimmt, aber
  handgetunte kamera-lokale Keyframes ohne Bodenkontakt, ohne saubere Easing-/Clip-Struktur → wirkt „gebastelt".

## 3 · Die Fehler-Kette (Root-Cause-Analyse)

**RC-1 — Falsches räumliches Grundmodell, VIEL zu spät korrigiert.**
Ich habe „D6-Rundum aus 6 Karten … vor einem Skydome" als **horizontalen Ring aus 6 senkrechten Panels im Leerraum**
gebaut. Gemeint war eine **Kiste/Box** (D6 = Würfel = 6 Flächen = Raum**wände**, inkl. Decke & Boden), deren **Wände
selbst die Karten SIND**. Erst nach ~6 Runden + handgezeichneten Skizzen (Decken-/Boden-Karte) wurde das klar.
→ *Der teuerste Fehler.* Alles andere (Transition, Kamera, Pet) wurde auf einem falschen Raum gebaut und musste jedes Mal nachgezogen werden.

**RC-2 — Auf Symptome statt aufs Konzept iteriert.**
Ich habe die *Übergangs-Animation* viermal umgebaut (Fade → Karte kippt → Rampe → Vorwärts-Kontinuum) und die Kamera
mehrmals, OHNE zuerst das **Raum-Topologie- + Navigations-Modell schriftlich festzunageln**. Jede Runde hat den
letzten Screenshot-Kommentar geflickt statt die Ursache. Animation wurde gebaut, bevor der Raum feststand → garantierte Nacharbeit.

**RC-3 — Bewegung ohne Boden.**
Der Pet-Flug lief **kamera-lokal** (keine Welt-/Boden-Referenz), weil der Raum kein definiertes Boden-/Wand-Gerüst
hatte. Ergebnis: „fliegt im Raum" statt „hüpft am Boden". Erst die Box liefert die nötige Boden-Ebene — die kam zu spät.

**RC-4 — Verifikation prüfte End-Zustände, nicht Bewegung.**
Meine Screenshots landeten fast immer NACH der Transition (die lief schneller als die Capture-Kadenz). Ich habe die
*ruckelige Bewegung*, die der User sah, selbst nie gesehen — ich habe der Logik vertraut statt der beobachteten Animation.
→ Deshalb blieb „schlampig" runde um runde bestehen.

**RC-5 — Keine Klärungsfrage zur Geometrie.**
`00_START_HERE` sagte „starte ohne Rückfrage". Genau die Geometrie war aber der Punkt, der eine EINZIGE Frage gebraucht
hätte: *„Ring aus schwebenden Panels ODER geschlossene Box aus Karten-Wänden (mit Decken-/Boden-Karte)?"* — hätte die ganze Schleife verhindert.

## 4 · Wo das Briefing (Cowork) ungenau/unvollständig war — ehrliches Feedback
Das Briefing war inhaltlich stark, aber an der **Geometrie mehrdeutig**, und genau dort ist alles gekippt:
- **„D6-Rundum aus 6 Karten"** ist zweideutig: *Rundum* legt einen Ring nahe; *D6* meint einen **Würfel/Box** (6 Flächen).
  Der eigentliche Referenz-Code `comic-cube.v1.js` war eine **Box** (4 Wände + Boden + Deckel) — d.h. die richtige
  Geometrie lag längst vor, aber der Text-Brief hat sie nicht als verbindlich markiert.
- **„vor einem Skydome"** + **„KEIN gebauter Raum, keine Props"** hat aktiv **weg von der Box** gezogen. Der Knackpunkt,
  der fehlte: *„Der Raum ist NICHT extra gebaut — die Karten SIND die Wände; die Box entsteht aus den 6 Karten selbst."*
  Diese eine Zeile hätte RC-1 verhindert.
- **Decken-Karte & Boden-Karte** stehen NIRGENDS im Text-Brief — sie tauchten erst in handgezeichneten Screenshots auf.
  Die 2 von 6 Flächen (oben/unten) waren also gar nicht spezifiziert.
- **„infinite canvas"** war als Vision klar, aber ohne **Navigations-Modell** (Snap? Free-Look? Bewegung Zelle→Zelle als
  Graph im Weltraum?). „Unendlich durch Inhalt, nicht Geometrie" beschreibt die Ökonomie, nicht die *Raum-Traversal-Mechanik*.
- **Animations-Anforderung** kam nur iterativ/verbal („cartoony, stretch&squash, glaubwürdig durch Panel, auf dem Boden") —
  nie als Shot-Liste/State-Machine. Ohne festen Raum war sie auch nicht spezifizierbar.

**Fazit Feedback:** Das Briefing hätte **einen 1-seitigen Raum-/Navigations-Contract mit Skizze** gebraucht (Topologie,
Kamera-Modell, Türen, Decke/Boden, Zelle→Zelle-Regel) BEVOR ein Pixel gebaut wird. Und ich hätte auf dieser Lücke bestehen
müssen, statt „ohne Rückfrage" loszulaufen.

## 5 · Dateien (eingefroren, v1)
- `comic-viewer.v1.js` — Engine (Ring-Fehlmodell → spät auf Box umgebaut, aber Navigation/Animation nie sauber).
- `cube-pet.js` (Root) — Clay-Pet + Sphere-Eyes (✅ behalten für v2).
- `KFB Card Viewer.dc.html` — DC-Wrapper.
- `docs/CARD_VIEWER_POC_v1.md` — laufende v1-Doku.
- **Reuse ohne Änderung in v2:** PDF-Pipeline, Deck-Pool, Clay-Pet+Eyes, Zoom/Pan-Clipping, Mode-Farben, 06-Call, LRU.
- **Wegwerfen/neu:** Ring-Geometrie, Kamera-/Snap-Navigation, Transition, Pet-Traversal-Keyframes.

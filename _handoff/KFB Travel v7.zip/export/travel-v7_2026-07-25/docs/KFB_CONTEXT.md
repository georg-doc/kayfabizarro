# KFB · Kontext & Ideensammlung (Living Document)

Stand 2026-07-25. **Zweck:** das Spiel- und Meta-Narrativ an einer Stelle, damit die Travel-Slices
nicht als Techdemo auseinanderlaufen. Sprint- und Backlog-Führung bleibt in
`docs/SPRINT_travel-v7.md`; hier steht das WARUM.

---

## 1 · Was KayfaBizarro ist (Quelle: kayfabizarro.pages.dev)

**Cut & Play Comics.** Man druckt einen Comic, **zerschneidet** ihn entlang gepunkteter Linien und
hat ein Kartendeck. 1–6 Menschen bauen daraus **eine gemeinsame Geschichte, laut, Karte für Karte**.
Niemand gewinnt. „Kein Spiel, das man spielt. Ein Spiel, das man benutzt."

**Der theoretische Kern, und der ist für uns direkt nutzbar:** McClouds *Gutter* — die Lücke zwischen
zwei Panels, die der Leser im Kopf schließt (*Closure*). KFB macht aus dieser privaten Lücke eine
**gepunktete Linie**: die Closure wandert aus dem Kopf in die Hände und passiert laut, mit anderen.

**Das Verb ist Kayfabulation** (Kayfabe + Konfabulation): die geteilte Realität, die ein Tisch baut
und behalten darf. Kayfabe = die laut getroffene Übereinkunft, das Inszenierte als echt zu behandeln.

### Mechanik, die wir schon abbilden oder abbilden sollten

| KFB-Regel | Travel heute | Travel später |
|---|---|---|
| **Story-Mode-Würfel** (1 Tragic · 2 Comic · 3 Absurd · 4 Heroic · 5 Mystical · 6 Forbidden) | ✅ Sechs Modi = Palette, Himmel, Licht, Drone-Identität; HUD-Würfel wechselt sie | Modus färbt auch Wind, Turbulenz, Kartenverhalten |
| **Quest-Würfel** (1 Setup → 6 Finale, nur der King bewegt ihn) | — | Reisestrecke ALS Quest-Achse: Durchflüge schieben den Bogen von Setup zu Finale |
| **Card Ritual: Show it · Spin it · Sell it** | — | Der Dreischritt beim Durchflug: Karte groß zeigen (Show), Pet/Narrator dreht sie (Spin), Story-Beat (Sell) |
| **Die Bühne: drei Scene-Slots** | — | Die drei letzten durchflogenen Karten = aktuelle Bühne; sie färben Terrain und Himmel |
| **Actor** (die Karte, als die man spricht) | Das Pet | Pet übernimmt Actor-Karte als Persönlichkeit |
| **BLÖDSINN!** | — | Verwerfen/Neuwürfeln eines Story-Beats, mit Geste oder Taste |
| **Kayfabulation Loot** | — | Die Sammlung am Ende als teilbares Artefakt (Deck-Ansicht, Export) |

**Drei Decks, drei Wetterlagen:** *Hopium* (hell, Werbepalette, „die Zukunft ist schon fertig"),
*Doom* (dunkel, tuschelastig, „sie ist schon vorbei"), *Protopia in Pencil* (vorläufig, radierbar,
Karten sind **Anweisungen** statt Behauptungen). Gemischt wird es erst gut — der Funke springt
zwischen zwei Stimmungen. **Für uns heißt das:** die Kartensammlung darf gemischt sein, und der
Zusammenprall zweier Karten ist der eigentliche Story-Motor, nicht die einzelne Karte.

**Karten sind keine Powers, sie sind Beweisstücke.** Nichts auf einer Karte ist eine Regel.
Deshalb: keine Zahlenwerte, keine Trefferpunkte, kein Fortschrittsbalken in unserem UI.

---

## 2 · Die Vision für Travel (Georgs Vorgaben, 2026-07-25)

**Karten sammeln durch Durchfliegen.** Der Flug IST die Wegstrecke; durchflogene Karten werden zu
Story-Beats und zu einer Collection.

**Deck unten links im Anschnitt.** Wachsender Kartenstapel, angeschnitten am Bildrand, mit
Fächer-Ansicht und Detail-Overlay. Position und Anmutung ungefähr wie der Startscreen von
Rollercoaster v11 (Screenshot vorhanden).

**Story-Telling / Afterglow-Modus.** Das Pet steht auf dem Deck (letzte bzw. erste Karte offen
oben), stärker zum Spieler gedreht, mit **Eye-Tracking** auf Karten und Cursor.

**Kayfabulieren per LLM.** Aus der Collection wird nach KFB/MED-Regeln, Prompt und
Pet-Persönlichkeit eine Geschichte — Text und Stimme. Vorbild: die FrizzleBob-**Narrator**-Settings im
Rollercoaster (Toggle · Voice-Auswahl · Voice volume). Ohne LLM: Texte aus der Karten-JSON.

**Sky-Karten, wie sie sein sollen** (S22 ff.):
- **Zero-G-Float:** nicht nur auf/ab, sondern leichte Rotation um alle drei Achsen, möglichst nicht
  repetitiv wirkend. ✅ gebaut (inkommensurable Frequenzen)
- **Immer optimale Lesbarkeit:** die Karte richtet sich dynamisch, aber nicht sprunghaft zur Kamera
  aus — Ziel ist immer ein guter Lese- UND Durchflugwinkel. ✅ gebaut (gedämpfter Slerp)
- **KISS-Strahlen:** die Karten farbig/wabernd in den Himmel projiziert, **ohne** überstrahlt zu
  werden. → offen, S22b
- **Wind:** global (besonders für Curtain-Modus) plus lokale Effekte wie Orkan-Turbulenzen oder
  3D-Kollisions-Impact-Events in der Kartenregion, grob nach KISS. → offen, S22c

---

## 2b · Closure, Narrator, Reisen als Daten (Georgs Präzisierung 2026-07-25)

**Closure ist die Reise selbst.** Die Strecke zwischen zwei (widersprüchlichen) Karten IST die Lücke,
die geschlossen wird — nicht ein Textfeld nach dem Durchflug. Das ändert die Bauweise: der Story-Beat
gehört in den FLUG zwischen zwei Karten, nicht in ein Overlay danach.

**Onboarding: das Pet kayfabuliert.** Der Narrator-Ansatz aus Rollercoaster v11 (Toggle · Voice ·
Voice volume) wird übernommen, inklusive **dynamischem Dämpfen von Musik und Soundscape während der
Sprachausgabe** — dort noch nicht ideal gelöst, hier also von Anfang an als Ducking-Bus bauen
(`travel-audio` hat mit `master`, `musicGain` und `fxBus` schon die Griffe dafür).

**Reisen sind Daten.** Import/Export als JSON mit relativen Kartenpositionen, IDs, Reihenfolge und den
LLM-Story-Beats — zuerst für QA und Testing, dann zum **Nachspielen**: dieselbe Reise mit anderem
Narrator-Pet, anderen Story-Modi, Zusatz-Durchflügen, Fortsetzung über mehrere gemischte Decks.
→ Slice **S29**.

**Karaoke-Modus.** Der Spieler übernimmt die Closure selbst — wahlweise story-modus-konform mit allen
oder ohne KFB/MED-Regeln, allein oder mit Freunden am selben Screen. Kein Multiplayer.
Denkbild: *Guitar Hero als Improv-Kartenspiel.* → Slice **S30**.

**Karten immer erreichbar.** Es soll immer mindestens eine Karte sichtbar und anklickbar sein (auch
am Bildrand); **Doppelklick** fliegt sie an, mit Boost, Barrel-Roll und Speedlines. Im
Story-Telling-Modus müssen Transitionszeit und Animation regelbar sein. → Slice **S22d**.
✅ Teilweise gebaut: neue Karten erscheinen jetzt ±75° um die Flugrichtung, der Himmel voraus ist
also nicht mehr leer.

## 3 · Meine Ergänzungen (zur Diskussion, nicht gebaut)

**a) Der Gutter als Spielmechanik.** Das ist der stärkste ungenutzte Hebel. Zwischen zwei
durchflogenen Karten liegt eine Lücke — und die Regeln sagen: der Spieler schließt sie. Also: nach
dem zweiten Durchflug erscheint der **Gutter** kurz sichtbar zwischen den beiden Karten (der
Zwischenraum als schmaler heller Streifen im Himmel), und dort passiert der Story-Beat. Nicht die
Karte erzählt, der Raum zwischen zwei Karten erzählt. Das ist billig zu bauen und konzeptuell exakt.

**b) Nähe erzeugt Bedeutung (Warburgs „gute Nachbarschaft").** Welche zwei Karten *zufällig
nebeneinander* im Himmel hängen, ist bei uns bisher Zufall ohne Folge. Es könnte die Folge haben:
zwei nahe Karten färben gemeinsam die Region (Palette-Mischung), und wer beide kurz hintereinander
durchfliegt, bekommt einen anderen Beat als bei zwei weit entfernten. Kostet fast nichts.

**c) Der Story-Mode gehört auch den Karten.** Heute färbt der Modus Welt und Klang. Er könnte das
Verhalten der Karten färben: *Forbidden* lässt sie zittern und wegdrehen (schwer zu treffen),
*Heroic* stellt sie sauber in die Flugbahn, *Absurd* dreht sie im falschen Moment, *Mystical* lässt
sie langsam kreisen. Ein Datensatz pro Modus, kein neuer Code-Pfad.

**d) Die leere Karte.** Der Almanach nennt sie das vierte Deck: ein Stapel *blanker* Karten. Im Flug
wäre das eine Karte ohne Titel — durchfliegen heißt: der Spieler (oder das LLM mit seinem Input)
schreibt sie. Das ist der stärkste narrative Moment, den das Material hergibt, und technisch nur ein
Textfeld.

**e) BLÖDSINN! als Geste.** Ein Ruf/Taste, der den letzten Beat verwirft und neu würfelt. Wichtig
fürs Gefühl: die Autorität liegt beim Spieler, nicht beim System — genau wie am Tisch.

**f) Quest-Achse statt Punktestand.** Nie eine Punktzahl zeigen. Stattdessen den Quest-Würfel:
Setup → Spark → Pursuit → Trials → Ordeal → **Finale**. Jeder Durchflug schiebt ihn, jede verpasste
Karte hält ihn. Beim Finale löst die Reise auf (Rückkehr mit dem Elixier — Campbell, und die Regeln
sagen es ausdrücklich: „not just an ending: **the return**").

**g) Kein Fortschritts-UI in Zahlen.** Die Karten selbst sind die Anzeige. Das Deck unten links
wächst — das ist der ganze Zähler, den es braucht.

---

## 4 · Namen, die stimmen müssen

- **Uncle FrizzleBob** — der Hase, Zeremonienmeister, Erzähler. Nicht „Frizzle" allein.
- **King Kayfabian** — der rotierende Richter (eine Wertung pro Zug, dann wandert die Krone).
- **Kayfabulation** / **kayfabulieren** — das Verb für unsere LLM-Erzählung.
- **BLÖDSINN!** — immer in Großbuchstaben, immer mit Ausrufezeichen.
- **Story-Modi:** Tragic · Comic · Absurd · Heroic · Mystical · Forbidden (englisch, so wie im Spiel).
- **Stay fluffy.** — die Grußformel.
- Autor: **Georg von Westphalen**. Lizenz der Decks: CC BY-NC-SA 4.0.

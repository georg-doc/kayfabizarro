# Stufe 3 — Kickoff (frischer Chat)

**Status: BEREIT · Stand 2026-07-16 · Gate offen? NEIN — Stufe 1+2 Sign-off durch Georg erteilt (inkl. 2b).**

Diese Datei macht einen frischen Claude-Design-Chat turnkey für Stufe 3 („Die Reise").
Kopiere die Pflicht-Kontext-Liste in den neuen Chat.

---

## 0 · Pflicht-Kontext (in den neuen Chat laden)

1. `docs/HANDOVER_v3.md` (aktueller Projektstand) + `CLAUDE.md`
2. `docs/MASTER_infinite_comic.md` — **§3.3 Rotation, §3.4 Die Reise, §3.5 Nahraum/Holografie** (verbindlich)
3. `docs/LEAD_PLAN*` (Plan + Gates)
4. `infinite-journey.v2.js` (aktuelle Engine) + `KFB Infinite Journey v3.dc.html` (Wrapper, importiert `kfb-journey-v2` aus `./infinite-journey.v2.js`)
5. `docs/CARTOON_MOTION_BIBLE.md` (+ `docs/motion_bible/`) — Motion-SSOT
6. **NEU für Stufe 3:** `pet-motion.v1.js`, `motion-LIBRARY.json`, `docs/MOTION_LIBRARY_v1.md`
7. Referenz (nur lesen, NICHT portieren): `uploads/card-viewer.v3.js` — hat die Kette gelöst, aber in falscher Geometrie

---

## 1 · Architektur-Entscheidung (getroffen)

**Modell A** aus MASTER §3.4 „Die Reise: Kamerafahrt, keine Blende":
1. Gewähltes **Front-Panel klappt wie eine Zugbrücke** nach vorn/unten (Scharnier = Unterkante).
2. **Kamera fährt hindurch** in das nächste Rig, das dahinter **schon fertig steht** (vor Fahrtbeginn gebaut).
3. Hinter dir **klappt das Panel wieder hoch** = **Rückwand/Spur** (`BACK · SPUR`-Slot, in `infinite-journey.v2.js:~379` schon vorgesehen) des neuen Raums.
4. **180°-Drehung** führt durch dieselbe Karte zurück.

**Verboten (§3.4):** Crossfade, Blende, Schnitt, Weltgleiten, **Klappen statt Fahren.** → Modelle B/C (Karussell-Snap) sind damit raus.

**Präzisierung (§3.5):** Nur der unmittelbare Nahraum bleibt temporär konstant; alles Weitere re-arrangiert sich holografisch. **Keine persistente Karte.** Also **genau EIN nächstes Rig** vor der Fahrt bauen, altes nach Ankunft recyceln — **zwei Rigs leben, nie mehr.** `ROOM_PITCH`/Index aus card-viewer **NICHT** übernehmen (das ist die verbotene indizierte Kette).

**Rotation wählt, ENTER committet.** §3.3 Rotation (Rig dreht, Ruhe-Reset, `_roles` in `infinite-journey.v2.js:~264`) bleibt; ENTER löst die Reise aus.

---

## 2 · Pet-Bewegung: PetMotion nehmen, NICHT neu bauen

Die Pet-Kette existiert als Engine: `pet-motion.v1.js` (`class PetMotion`). Verkettbare Promises:
`hop · powerJump · jumpTo/locomotion · turnTo/turn180 · celebrate · react · transitionOut/In ·
roomTransition() (= Boden→vorderer Mittelrand→raus→rein) · loop('idle'|'loading')`.
Enthält den Anti-Flacker-Umbau (ein Skala-Besitzer + SmoothDamp `smoothTime` 0.07 s), den der alte
card-viewer-`_hop` NICHT hat.

**Contract (aus `docs/MOTION_LIBRARY_v1.md`):** `PetMotion.update(dt)` läuft **NACH** `ch.update(dt)`
und **VOR** `rig.update(dt)`. Erwartet am Character: `ch.group`, `ch.inner`, `ch._squash`, `ch._baseS`,
`ch.setHome()/ch._home`. `motion-LIBRARY.json` (`$schema: kfb.motion-library/1`) per URL laden →
Params an `new PetMotion(ch, {rig, params, front:{x,z}, back:{x,z}})`.

---

## 3 · Integrations-Gotchas (VOR dem Bauen lösen — sonst Bugs)

1. **Besitz-Konflikt Skala/Position.** `PetMotion` ist alleiniger Schreiber von `ch.inner.scale` +
   `ch.group.position`. Die aktuelle Stufe-2b-Kurve `HOP_KF` in `infinite-journey.v2.js` schreibt
   dieselben Werte direkt. → Beim Adoptieren **HOP_KF + Hop-Overlay in `_tick` entfernen** und
   `turn_react` auf `PetMotion.hop/powerJump` umstellen. Nicht beide gleichzeitig laufen lassen.
2. **Koordinaten-Basis.** `PetMotion` rechnet welt-achsenparallel (`position.set(x,y,z)`, `rotation.y`).
   Die Journey ankert das Pet an eine **rotierende Kachel mit Quaternion-Basis** (n/x/f, siehe
   `_placePet`). → **Adapter nötig:** PetMotion in lokalen Tile-Koordinaten laufen lassen und pro
   Frame über die Kachel-Basis in die Welt transformieren (analog `_placePet`s `lp.applyQuaternion(S.quat).add(S.pos)`).
3. **EyeRig-Version.** `PetMotion` erwartet **EyeRig v4** (API pointTo/setGazeFollow/applyEmote/blinkNow);
   die Engine läuft auf **v3**. Prüfen ob v3 die genutzte Teilmenge (`blinkNow`) hat, sonst v4 ziehen
   oder `eyeReact:false` starten.

---

## 4 · Empfohlener erster Slice (einzeln abnehmbar)

**Slice 1:** ENTER am Front-Panel → Bridge-Fold (Scharnier Unterkante, `easeOutBack`) + Pet
`jumpTo(front-Mittelrand)` via PetMotion, mit Gummileinen-Kamera (unterdämpfte Feder, Overshoot+Settle;
Referenz `card-viewer.v3.js` `_camStep`: `k=34−rubber·14`, Dämpfung < kritisch). Noch OHNE nächsten
Raum — nur Fold + Hop + Kamera-Trail, damit Geometrie/Adapter/Ownership sauber sitzen.
Danach Slice 2: nächstes Rig bauen + Durchtritt + Fold-up-behind. Slice 3: 180°-Rückweg + Recycling.

---

## 5 · Beim Hüpfen sichtbare Details (Georgs Wünsche)

- Beim Sprung **dreht sich das Pet**, man sieht es beim Raumwechsel **von hinten**.
- Pet kann frei platziert werden; beim Raumwechsel hüpft es von aktueller Position zur **Mitte der
  Unterkante** der Bottom-Card, über den Gutter, klappt dadurch das Hero-Panel (Tür-Kick/Kollision).
- Idle später: zufällige Idle-Varianten, Umherblicken, AFK-Selling.

---

## 6 · Known Issue (löst Stufe 3 auf, NICHT vorher hacken)

**Pet clippt bei VERTIKALER Rotation in die Karten** (positionsabhängig, stärker fern/vorne).
Ursache: `_placePet` ankert an `SLOT.S` (fester Boden-Slot). Bei vertikaler Drehung schwenkt die
Frontkarte nach unten und legt sich als neue Bodenkarte über den Slot, auf dem das welt-feste Pet
steht → Durchdringung. Bei horizontaler Drehung (Yaw an Ort) tritt es nicht auf.
Das ist inhärent an 2b's Boden-Stehen. **Auflösung = Stufe 3:** das Pet verlässt beim Raumwechsel
den Boden (Hop in die Zugbrücke) und steht nicht mehr im Schwenkpfad. Der Tile-Adapter (Gotcha #2)
baut das Anchoring ohnehin neu — daher hier nicht separat fixen.

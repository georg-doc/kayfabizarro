# SPRINT — KFB Travel v6 · Boost-Regie, Modus ohne Schalter, Rahmen

> **ABGESCHLOSSEN & FROZEN 2026-07-25 → Fortsetzung in `docs/SPRINT_travel-v7.md`.**
> Erledigt: S2 · S14 · Ink-Outline-Regler · Ruhezonen · S10 · S11 · S18 · S15.
> Snapshot: `export/travel-v6_2026-07-25/`. Diese Datei bleibt als Beleg stehen; Status ab jetzt
> nur noch im v7-Plan.

**Lebendes Dokument.** Status wird HIER gepflegt, nicht im Code. Jede Runde (auch in einem
frischen Chat) trägt ihr Ergebnis ein und schreibt eine Zeile in `docs/CHANGELOG_travel.md`.

- **Entry:** `KFB Travel v6.dc.html` → `terrain-v6/travel-poc.js` (15 Module)
- **Vorgänger:** `KFB Travel v5.dc.html` / `terrain-v5/` — **FROZEN**, nicht mehr anfassen
- **Grundrisse der offenen Slices** stehen weiter in `docs/SPRINT_travel-v5.md` (S3–S6, S9–S13
  wörtlich, mit den Zahlen aus dem Report) — hier nur Status und was sich geändert hat.
- **Grundlage:** `KFB TinySkies Analyse.dc.html` · **Pet-Kanon:** `EMBED_CUBE_PET_FULL_v2.md`
  · **Motion-Kanon:** `skills/cartoon-motion_v1.md`

---

## Was ein frischer Chat zuerst lesen muss

1. Diese Datei (Status + der eine Slice, der dran ist).
2. `docs/HANDOVER_travel-v6.md` — die sieben teuer gelernten Regeln stehen dort, alle gelten weiter.
3. `terrain-v6/travel-poc.js` (Runner, **Render-Reihenfolge**) und das Modul, das der Slice anfasst.

**Neue Regel Nr. 8 seit S2:** Die Render-Reihenfolge ist
`Szene → post-radial → speed-lines → hud.render()`.
Wer einen weiteren Fullscreen-Pass einführt, hängt ihn zwischen Szene und Speedlines — alles Scharfe
(Streifen, Würfel, künftige DOM-Overlays) kommt dahinter.

## Arbeitsweise, die sich in v6 bewährt hat (Georgs „Golden Sample", 2026-07-25)

Sechs Punkte. Sie klingen banal und waren in v6 jedes Mal der Unterschied zwischen „behoben" und
„weggeklickt":

1. **Messen statt schätzen — und zwar am laufenden Bild.** Jeder Befund in v6 wurde mit Zahlen
   belegt (`eval_js` gegen die Szene, Pixel-Mittelwerte, Differenzbilder). Der „Lichtschalter" war
   erst ein Gefühl, dann −22/255 im Kartenbereich, dann eine Ursache.
2. **Die Ursache eingrenzen, nicht die Symptome kurieren.** Ausblenden, halbieren, gegenprobieren:
   Pet aus → bleibt; Karte aus → Differenz 0. Erst danach wurde Code angefasst.
3. **Wenn zwei Fassungen scheitern, ist die Architektur die Frage, nicht der Parameter.** Zwei
   Farbraum-Runden am Rendertarget, dann die Einsicht: ein Randeffekt braucht kein Rendertarget.
   Die dritte Fassung war kürzer als die erste.
4. **Fremde Lösung lesen, bevor man eine eigene baut.** Speedlines und Kondensstreifen sind aus
   TinySkies portiert. Die eigene erste Fassung sah klobig aus, weil sie die Form in die Geometrie
   legte statt in den Shader — das stand dort seit Jahren richtig.
5. **Widersprüche zur Vorlage benennen, nicht stillschweigend umbauen.** Der „wegfallende
   Kurven-Drag" existiert bei uns nicht; statt einen Drag zu erfinden, nur um ihn abzuschalten,
   wurde die Absicht anders erfüllt — und das steht im Changelog.
6. **Snapshot vor dem großen Schritt, Fork erst wenn ein Zustand vorzeigbar ist.** Ein Fork pro
   Slice erzeugt fünf Ordner, in denen Fixes einzeln nachgezogen werden müssen.

Dazu die alte Regel, die weiter gilt: **ein Slice pro Runde, additiv**, und was schiefging kommt in
den Changelog — nicht nur, was klappte.

## Status

| # | Slice | Status | Datei(en) | Runde |
|---|---|---|---|---|
| S0 | v6 angelegt (Fork von v5) | **✅ erledigt** | `KFB Travel v6.dc.html`, `terrain-v6/*` | 2026-07-25 |
| S2 | Speedlines + Boost-Regie (+ Radial-Blur) | **✅ erledigt** | `speed-lines.js`, `post-radial.js` (neu), `pet-kinetics.js`, `flight-controller.js`, `travel-poc.js` | 2026-07-25 |
| S10 | Modus ohne Schalter (WoW-Logik) | **✅ erledigt** | `flight-controller.js`, `travel-poc.js` | 2026-07-25 |
| S11 | Rahmen: Wortmarke links, Meta rechts | **✅ erledigt** | `KFB Travel v6.dc.html`, `themes/kfb-med.css` | 2026-07-25 |
| S12 | Würfel v2: Teil 2 (ALLCAPS raus, Special Elite, Abnutzung, Pet-Farbe) | **offen** (Teil 1 steht) | `hud-cube.js`, `kfb-pets.js` (lesen) | — |
| S3 | Rim-Light auf Pet, Karte, Cubes | **offen** | `rim-light.js` (neu) | — |
| S4 | Staub- & Splitter-Pool | **offen** | `fx-pool.js` (neu) | — |
| S5 | Story-Presets konsolidieren | **offen** | `world-context.js`, `skydome-shader.js` | — |
| S6 | Portal-Swirl als Modus-Tor | **offen** | `mode-portal.js` (neu) | — |
| S9 | Monitor-Würfel: Embeds (YouTube / Demo / Chat) | **offen (später)** | `hud-cube.js`, DOM-Overlay | — |
| S14 | Pet-Beleuchtung: Fill-Light + Sky-Environment + Story-Tint | **✅ erledigt** | `pet-lighting.js` (neu), `travel-poc.js` | 2026-07-25 |
| S15 | Bodenschatten für Pet und Karte | **✅ erledigt** | `ground-shadow.js` (neu) | 2026-07-25 |
| S16 | Tag/Nacht-Wechsel | **offen (nach S5)** | `skydome-shader.js`, `world-context.js`, `travel-poc.js` | — |
| S17 | Regen & Wirbelstürme | **offen (später Sprint)** | eigene Module | — |
| S18 | Terrain-Modus „Flow": laufende Welle statt Einzelhüpfen | **✅ erledigt** | `voxel-terrain.js` | 2026-07-25 |
| S19 | Wasserfarb-Wellen: Farbflächen breiten sich von Tropfen aus | **offen** | `voxel-terrain.js`, Event-Bus | — |
| S13 | Beams / Leuchtturm-Karten / Selective Bloom | **offen (v6+)** | eigene Module | — |

Status-Vokabular: `offen` · `in Arbeit` · `✅ erledigt` · `geparkt (Grund)`.

---

## S2 · Speedlines + Boost-Regie — ✅ erledigt 2026-07-25

**Der Boost ist jetzt ein Ereignis mit fünf Stimmen**, alle an `travelHeat` plus einem
Boost-Impuls (`boostPulse`: Einsatz 9/s, Auslauf 2,2/s — die Welt weitet sich beim DRÜCKEN,
nicht erst, wenn das Tempo angekommen ist).

| Stimme | Wo | Kern |
|---|---|---|
| **Eckstreifen** | `card-contrails.js` (neu) | zwei Ribbons an den hinteren Kartenecken, ab 20 km/h, Kern weißt mit dem Tempo aus. Anker in der Weltmatrix von `rig.lean` → zeichnen Bank, Roll und Steigflug mit. Portiert aus TinySkies `Contrails.ts` |
| **Speedlines** | `speed-lines.js` (neu) | eigene Szene + `OrthographicCamera(−1,1,1,−1)`, Pool 24 Quads, Ring-Zeiger, zwei `Float32Array` pro Frame beschrieben — keine Allokation. Story-**Ink**-Farbe, `NormalBlending`, Deckel 0,35 |
| **Radial-Blur** | `post-radial.js` (neu) | Zoom-Blur als Fullscreen-Pass, 10 Taps, Zentrum = Fluchtpunkt, Bildmitte bleibt scharf (`inner 0.20`). Bei Stärke 0 rendert die Szene **direkt** auf den Schirm — kein Puffer, volles MSAA |
| **Barrel-Roll** | `pet-kinetics.js` | genau EINE 360°-Drehung pro Boost-Einsatz, eased, danach exakt 0. Läuft als Offset auf DERSELBEN Roll-Achse wie die Bank-Feder |
| **Kamera** | `travel-poc.js` | Dolly `+ pulse·0.6`, Höhe `+ pulse·0.15`, FOV `54 + h·13 + pulse·7` |
| **Lenken** | `flight-controller.js` | `boostYawGain 1.28` |

**Der „wegfallende Kurven-Drag" aus dem Report existiert bei uns nicht** — Lenken kostet in unserem
Flight-Controller kein Tempo, da war nichts zu entfernen. Statt einen Drag einzubauen, nur um ihn
abzuschalten: dieselbe Absicht („der Boost fühlt sich FREIER an, nicht nur schneller") über mehr
Lenk-Autorität während des Boosts.

**Gemessen (924 × 540, HEROIC, Vollgas aus dem Reiseflug):**

| Größe | Ruhe | Vollgas |
|---|---|---|
| `heat` / Tacho | 0,039 · 6 km/h | 0,986 · 75 km/h |
| Streifen im Bild | 0 | 24 (Pool voll), Deckkraft 0,35 = Deckel |
| Blur-Stärke | **0** (Pass übersprungen) | 0,106 |
| FOV | 54,5° | 73,7° (+19°) |
| Barrel-Roll | 0 | 6,21 rad ≈ 2π nach 0,85 s, danach exakt 0 |

Nach dem Loslassen ist in ~8 s alles zurück auf 0/0/0 (der Gleitflug braucht so lange, nicht die
FX) — Prime Directive gehalten: **in Ruhe ist der Effekt weg, nicht bloß leise.**

**Nachgeschärft nach Georgs Review (gleicher Tag) — drei Korrekturen, die den Slice erst tragen:**
1. **Streifenform gehört in den Shader, nicht in die Geometrie.** Erste Fassung: Rechteck mit
   harter Kante → „klobig, eckig". Jetzt 1:1 die Mathematik aus TinySkies `SpeedLines.ts`
   (Taper × weicher Querschnitt = Spindel) und das Quad sitzt MITTIG auf dem Rand-Radius, ragt
   ±Länge/2 nach außen — sichtbar ist nur die auslaufende Spitze. Damit stimmen die Report-Werte
   (Länge 0,35–0,84, Breite ×5) alle, und kein Streifen legt sich über das Fahrzeug.
   **Regel für die nächsten FX-Slices: Form in den Fragment-Shader, Bewegung in die Geometrie.**
2. **Der Barrel-Roll gehört der KARTE.** `rig.setBarrelRoll(angle)`, angewandt in `card-carrier.js`
   direkt nach `group.quaternion.copy(st.quaternion)` — vor Lean und Fuß-Clip-Ebene. Karte und Pet
   drehen gemeinsam um die Karten-Mitte. Nach `sync()` aufgesetzt würde die Clip-Ebene während der
   Rolle in die alte Richtung zeigen und das Pet anschneiden.
3. **Farbraum: doppelte sRGB-Kodierung** hat den Pass zu einem Lichtschalter gemacht (Pixel-Mittel
   82,7 → 144,0 in dem Frame, in dem er anspringt). Target ist jetzt `UnsignedByteType` +
   `SRGBColorSpace` (= der Schirm), der Shader schreibt durch: 92,88 → 92,41 → 92,26 mit Blur.
   **Merksatz für jeden künftigen Post-Pass: Target-Farbraum = Schirm-Farbraum, sonst kodiert man
   zweimal.**

**Runde 3 (Georgs zweites Review):** Streifen dünner (0,0035–0,0075) und im Boost **heller statt
dicker** — der Kern weißt aus, die Breite wächst nur noch ×1,35. Dazu die Eckstreifen (Zeile oben).
Und der Rest-Lichtschalter: der Post-Pass **läuft jetzt immer**, weil das Umschalten zwischen
Direkt- und Pufferpfad selbst der Sprung war (Bildmitte gemessen: 66,97 direkt vs. 62,90 durch den
Puffer — 4 von 255 in einem Frame). Bei Stärke ~0 nimmt der Shader eine Ein-Tap-Abkürzung.
**Regel: nie zwischen Renderpfaden umschalten, während das Bild läuft.**

**Streifen-Look ist ein Regler.** Default `light` (additiv, Panel-Farbe der Story — der
TinySkies-Read in KFB-Farbe), `ink` als Comic-Variante. Additiv ist hier unbedenklich: der Pass
läuft NACH der Szene und kann kein Szenen-Objekt überstrahlen.

**Regler im Overlay**, neue Sektion **„Boost & FX"** (zwischen Reise und Welt): Speedlines an/aus ·
Streifen-Dichte · Streifen-Deckkraft · Radial-Blur (0 = aus) · Barrel-Roll an/aus · Lenken im Boost ·
Live-Anzeige (Streifen im Bild, Blur-Stärke). Damit sind S3–S6 am Bild justierbar, nicht im Code.

**Test-Hooks:** `__travelPOC.lines` (`.liveCount`, `.opacity`, `.params`, `.setEnabled`) ·
`__travelPOC.post` (`.strength`, `.active`) · `__travelPOC.boostPulse` ·
`__travelPOC.petKin.barrelRoll` / `.rollOnce()`.

**Offen aus diesem Slice.** Bei Vollgas ist der Pool mit 24 Streifen ausgeschöpft (Spawn-Intervall
0,02 s × Lebensdauer 0,3–0,7 s will 15–35). Wenn Georg dichter will: Pool auf 40 heben, nicht die
Lebensdauer kürzen — sonst flackert es. Und: der Blur ist bewusst nur an `heat` gekoppelt, nicht an
der Kurve; ein Motion-Blur beim Lenken wäre ein eigener Pass (Velocity-Buffer) und ist es nicht wert.

---

## S14 · Pet-Beleuchtung — ✅ erledigt 2026-07-25

Gebaut wie im Grundriss unten beschrieben. Zwei Dinge, die beim Bauen aufkamen:
1. **Der Skydome hängt am Kamera-Follow.** Für den PMREM-Bake muss er auf den Ursprung, danach
   zurück an seinen Parent — sonst backt man eine Kugel, deren Mittelpunkt woanders liegt.
2. **Der Tint darf nur PBR-Materialien anfassen.** Augen und Kartenfläche sind `MeshBasic`; ein
   Multiplikations-Tint macht sie nur schmutzig. Gemessen: 28 von 31 Materialien gepatcht, die drei
   übrigen sind genau diese. Regler: Himmels-Licht, Fill-Licht, Story-Tint (Sektion „Pet").

## S10 + S11 — ✅ erledigt 2026-07-25

**S10.** Abheben = Leertaste zweimal (< 280 ms) am Boden, als verlängerter Sprung: die Karte setzt
auf der Höhe des Pets ein und in seiner Blickrichtung (`flight.reset(x, z, alt, heading)` ist dafür
erweitert), Steigziel +12. Landen = `X`/Pfeil-runter; der Wechsel feuert bei Bodenkontakt **plus**
kleiner Sinkrate **plus** Sinkwille, gehalten 0,22 s (`landSink`/`landHold` im Flight-Controller),
und nach jedem Wechsel sperrt eine Sperrzeit von 0,9 s das Zurückkippen. `F` bleibt, dazu der
Schalter „Modus folgt der Höhe". Gemessen: `X` → 0,7 s bis Walk; einzelner Sprung bleibt am Boden;
Doppel-Leertaste steigt (alt 14,4 → Ziel 16,3), springt nicht.

**S11.** Wortmarke oben links aus `themes/kfb-med.css` (`.kfb-wordmark`, Irish Grover), Meta klein
oben rechts in Special Elite, Modus-Badge gelöscht; der Tacho zeigt nur noch `POV`. Über bewegter
Welt trägt „Kayfa" einen harten Cream-Schatten als Kontrastkante — Offset, kein Blur.

## Georgs Fragen vom 2026-07-25 — Antworten und die Slices, die daraus wurden

**Welche Lichtquellen laufen heute?** Genau zwei: eine `DirectionalLight` (warm `#fff2e0`,
Intensität 2,6, Schattenkarte 2048², Ortho-Box ±40, folgt dem Fahrzeug) und eine
`HemisphereLight` (Himmel `#e6f0ff` / Boden `#6a6250`, 1,0). Tone-Mapping ACES-Filmic,
Belichtung 1,0. **Kein Fill-Licht, keine Environment-Map.** Deshalb wirkt das Pet auf der
Schattenseite flach: dort arbeitet nur die Hemisphere.

**S14 · Pet-Beleuchtung (klein, größter sichtbarer Ertrag).** Drei Bausteine, unabhängig schaltbar:
1. **Sky-Environment** — der Skydome einmal pro Story-Wechsel in eine PMREM-Map backen und als
   `scene.environment` setzen. Damit nimmt jedes PBR-Material die Himmelsfarbe auf; Farbe und
   Textur des Pets lesen sich sofort satter, ohne eine einzige neue Lampe.
2. **Fill-Light** gegen die Sonne (kalt, ~0,5) — die klassische Cartoon-Zweilicht-Situation.
3. **Story-Tint wie im Rollercoaster v11** — `onBeforeCompile` mischt die Story-`ink` in
   `diffuseColor` (`mix(base, base·tint, amount)`, Anteil ~0,15–0,25), also **ohne** die Base-Color
   zu ersetzen. Muss mit S3 (Rim-Light) zusammen gedacht werden: Rim = Kante, Tint = Fläche.

**S15 · Bodenschatten.** Heute wirft das Pet zwar Schatten (`castShadow` steht, Schattenkarte läuft),
aber **nichts empfängt sie**: die Terrain-Cubes sind ein eigenes `ShaderMaterial` ohne
Shadowmap-Chunks. Zwei Wege: (a) **Blob-Schatten** — eine weiche dunkle Ellipse, projiziert auf die
Höhe unter Karte und Pet, Größe und Deckkraft aus der Flughöhe; billig, cartoongerecht, robust
gegen hüpfende Cubes. (b) **Echte Schatten im Terrain-Shader** — mehr Arbeit, und die tanzenden
Cubes machen die Kante unruhig. Empfehlung: (a) bauen, (b) erst wenn der Tanz ruhen kann.

**S16 · Tag/Nacht.** Die Bausteine liegen: der Skydome hat schon `night`/`morning`/`day` und
`uWorldMix`. Fehlt: eine Tageszeit-Uhr, die Sonnenrichtung + Farbe, Nebelfarbe, Hemisphere und
Skydome-Mischung aus **einer** Zahl fährt — dieselbe Disziplin wie `travelHeat`. Gehört hinter S5
(Story-Presets), sonst gibt es zwei konkurrierende Farbquellen.

**S17 · Regen & Wirbelstürme.** Regen ist ein Pool-Effekt (Streifen-Sprites im Kameraraum, dazu
Tropfenringe am Boden) und passt technisch neben S4. „Mit Physik" heißt bei TinySkies ein
Kraftfeld, kein Solver: eine Windfunktion, die Karte und Partikel gleich beeinflusst. Späterer
Sprint, wie von Georg vorgesehen.

## S18 · Terrain-Modus „Flow" (Grundriss, Georgs Wunsch 2026-07-25)

**Was heute passiert:** jede Säule hat ihre EIGENE Phase (`seed`), alle hüpfen unabhängig. Das ist
ein Dancefloor — richtig für den Beat-Modus, aber kein Fluss.

**Was Flow ist:** dieselbe Bewegung, aber die Phase kommt aus dem ORT statt aus dem Zufall —
`phase = uTime·speed − dot(worldXZ, dir)·k`. Damit läuft eine Welle durch das Terrain. Zwei solche
Wellen mit verschiedenen Winkeln und Frequenzen überlagert ergeben ein Interferenzmuster, das sich
nie exakt wiederholt und trotzdem nicht zufällig aussieht — das ist der „befriedigende Loop", und
mit einem dritten, sehr langsamen Term wird er leicht hypnotisch. **Fünf Shader-Zeilen**, dieselbe
Amplituden- und Kanal-Logik wie jetzt: „Cube-Tanz koppeln an" bekommt einen dritten Eintrag
**Flow**, und der Beat kann optional die Wellenamplitude modulieren (Dancefloor UND Fluss).
Georgs three.js-Verweis (`webgl_instancing_dynamic`) beschreibt genau diesen Unterschied: dort ist
die Bewegung stetig und räumlich zusammenhängend, nicht 10 000 unabhängige Zappler.

**Reihenfolge:** klein und unabhängig — passt gut direkt nach S10/S11, und die Ruhezonen (schon
gebaut) greifen unverändert, weil sie die Amplitude dämpfen, nicht die Phase.

## S19 · Wasserfarb-Wellen (Grundriss)

**Idee:** ein Tropfen trifft das Terrain, eine Farbfläche breitet sich ringförmig aus und verblasst.
Auslöser: Beat-Tropfen, Story-/Zonen-Wechsel, Kartenpassage, später Regen (S17).

**Technik, die dazu passt:** ein Ring von ~8 Tropfen als Uniform-Array (`vec4`: x, z, t0, Stärke).
Im **Vertex**-Shader (nicht Fragment — unsere Cubes sind groß, pro Vertex reicht und kostet ein
Achtel) für jeden Tropfen `ring = smoothstep` um `dist − c·(t−t0)`, Ergebnis als zusätzlicher
Farb-Mix-Faktor an den Fragment-Shader. Die Farbe kommt aus der Story-Palette bzw. der Zone — dann
ist die Welle nicht Deko, sondern sagt, WO man ist. Zusätzlich kann derselbe Faktor die Hub-Amplitude
kurz anheben: eine Welle, die man sieht UND spürt.

**Voraussetzung:** ein winziger Event-Bus („drop(x, z, colour, strength)"), den Beat, Story und
später Regen bespielen. Ohne den bekommt jedes System seine eigene Verdrahtung — genau der Fehler,
den `travelHeat` in S1 vermieden hat.

## Warten auf Georg

- **PNG-Set für die Würfelseiten** (Procreate, transparent, quadratisch, 12 % Sicherheitszone) →
  `media/kfb/hud/`. Erst damit trägt der kleinere Würfel (S12).
- **`edge3.jpg` ins Repo** (`media/3D_Assets/Textures/`) → dann kann die lokale Kopie raus.
- **Bundle-Matrix** (greet/notice/celebrate/sleep an Travel-Events) mit dem Coworker abstimmen.
- **Urteil zu S2 am Bild:** Streifen dichter/dünner? Blur stärker? Beides sind Regler in „Boost & FX".

## Backlog und bewusst Verworfenes

Unverändert in `docs/SPRINT_travel-v5.md` (Abschnitte „Nicht in diesem Sprint" und „Bewusst
verworfen"). Nicht wieder vorschlagen: Quaternion-Kugelwelt, Partikel-Vortex am Booster,
Multiplayer/Upgrades/HP-Balken.

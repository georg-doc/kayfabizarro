> ## ⚠ META-NARRATIV (zuerst lesen!)
> **Human = Pet-Avatar:** Das Pet ist der Avatar des Spielers — storytelling animal, das FrizzleBobs
> Time-Capsule-Artefakte (die Cards, gesammelt wie Akashic Records im fraktalen Raum) stellvertretend
> erlebt und Closure/Storytelling liefert. Darum: Cards/Cover haben KEINE Rückseite, werden NIE
> falsch herum gezeigt, und alle UI-Metaphern sind **Karten & Würfel**.

# HANDOVER — Rollercoaster Ride (Strang B), Stand v3 · 2026-07-17

> Übergabe-Blatt für einen frischen Chat, der den **WebGPU/TSL-Coaster** weiterbaut.
> Verweis-Dokument, kein Briefing. Lies die verlinkten SSOTs, nicht diese Prosa.
> Für den **Comic-Cube-Strang** (Diorama-Box) gilt weiter `docs/HANDOVER_v3.md` — das
> ist eine ANDERE Linie, nicht verwechseln.

---

## 0 · Was das ist (ein Satz)

Ein immersiver Storytelling-Ride: der Spieler fährt als Cube-Pet auf einer three.js-
Achterbahn durch einen mood-gefärbten Himmel, vorbei an schwebenden KFB-Deck-Karten,
durch Vorhänge hindurch — Bild, Sound und Bewegung hängen an einem Drive-Bus.

## 1 · Die gültigen Dateien (SSOT)

- **`Rollercoaster Ride v3.dc.html`** — der Einstiegs-DC (Shell: helmet + importmap + stage-div).
- **`rollercoaster-ride.v3.js`** — die ganze Engine (Klasse `RideV2`, ~1450 Zeilen, eine Datei).
- **`docs/CHANGELOG_rollercoaster.md`** — was v1→v3 enthält und warum. Zuerst lesen.
- **`docs/BACKLOG.md`** — was als Nächstes, mit Plan + Fallback-Strategie pro Komponente.

Beide v3-Dateien sind **eingefroren**. Weiterbau = Kopie als v4 (`.js` + `.dc.html`),
Changelog-Eintrag, alte Version unangetastet lassen.

## 2 · Architektur in fünf Sätzen

1. **Ein Drive-Bus** (v = Geschwindigkeit, a = Beschleunigung, c = Kurve, j = Ruck, p = Progress,
   mood = D6) wird pro Frame aus der Fahrt berechnet; Pet, Sound, Himmel und Vorhang lesen
   NUR aus diesem Bus — eine Quelle, viele Abnehmer.
2. **Der Track ist rein parametrisch** (three.js `webgpu_xr_rollercoaster`-Kurve, 1:1
   übernommen): eine Formel `curve.getPointAt(t)`, keine gespeicherten Punkte. `RollerCoasterGeometry`
   (zwei Schienen + Stufen) + Lifters (Pfosten). Boden/Bäume/Wolken sind ausgeblendet.
3. **Sechs Story-Modes** (`MODES[]`, kanonische ink+panel-Hex aus KFB Rules Print v4) sind
   ein D6; ein Wurf färbt Schiene, Streams, Himmel, Sound und Erzähler einheitlich.
4. **Das Pet** kommt per Contract-URL (`pet-LIBRARY.json`) als `Character` (`pet-library.v6.js`)
   + `EyeRig` (`pet-eye-rig.v3.js`) — geteilte Module, NICHT hier neu bauen. Cartoon-Physik
   (Squash/Lean/Fling) rechnet die Ride-Engine lokal aus dem Drive-Bus.
5. **Alles Sichtbare ist datengetrieben**: `MODES`, `AUDIO_MOODS`, `MOOD_SKY`, `DICE_SEATS`
   liegen als Tabellen oben in `rollercoaster-ride.v3.js`, nichts ist verstreut hardcoded.

## 3 · Der Tech-Stack ist WebGPU (nicht WebGL)

Anders als der Comic-Cube-Strang (der bewusst WebGL2 fährt) nutzt der Coaster **WebGPU + TSL**:

- `importmap` → `three@0.178.0/build/three.webgpu.js` + `three.tsl.js` (unpkg CDN).
- `THREE.MeshStandardNodeMaterial`, `THREE.WebGPURenderer`, TSL-Node-Shader für die Streams
  (linked particles) und den Shader-Dome (domain-warped fbm).
- **Boot-Guard:** `if (!navigator.gpu)` → Klartext-Hinweis „needs WebGPU, open in Chrome/Edge".
- **Firefox/Safari:** siehe Backlog P1 — noch KEIN Fallback, nur der Guard. Das ist die
  wichtigste offene Baustelle für Breitentauglichkeit.

## 4 · Regeln, die Regressionen verhindern

1. **Prime Directive:** jede Bewegung settlet in Ruhe; kein Idle-Fidget, kein Metronom,
   Animation = Interpunktion. Gilt für Pet, Sound, Himmel und Stimme.
2. **State evolves, never loops:** zeitbasierte Felder (Streams, Shader-Dome) integrieren
   `phase += f(speed)·dt` — sie kehren nie in einen früheren Zustand zurück.
3. **Pet + Karten + Stimmen per Contract-URL**, nie hardcoden. Geteilte Rig-/Character-Module
   nicht forken — Fixes von der Ride-Seite (siehe Augen-Fix v3).
4. **`computeVertexNormals()` NUR wenn `facet===true`** — sonst wird der runde Pet eckig
   (dreimal passiert). Der Fix war: den Aufruf ganz weglassen (GLB-Normalen sind glatt).
5. **Verifikation prüft Bewegung, nicht Endzustände.** WebGPU-Canvas lässt sich per
   html-to-image schlecht zoomen — für Pet-Details lieber Scene-Graph-Werte per `eval_js`
   auslesen (Welt-BBox, Eye-Weltpositionen) als blind zu screenshoten.
6. Eingecheckte Versionen einfrieren, Weiterbau als neue Datei.

## 5 · Der Drive-Bus im Code (Orientierung)

In `RideV2.animate()` (~Zeile 970+): `this.progress` läuft über die Kurve, `this.velocity`
+ `this.accel01` + `_headingChange` (Kurve) + Jerk speisen `speed01`. Daraus:

- **Pet:** `petHolder` folgt der Kurve (Vorlauf +0.006), `qTrack`/`qFace`-Blend dreht es zur
  Fahrt bzw. zum Rider (AUTO: schaut zurück wenn langsam), Squash/Lean als Federn.
- **Kamera:** Chase im „train"-Rig, FOV öffnet mit Speed, freies Umsehen decayt zurück.
- **Sound:** `updateAudio()` — BED-Tonhöhe reitet v, MOTION-Gain ∝ v², EVENT-Whoosh auf
  c-/j-Spikes, sechs Würfel-Panner folgen den Welt-Sitzen.
- **Himmel/Streams:** Mood-Recolor beim Kartendurchgang (stiller D6-Roll), Shader-`phase`
  integriert aus speed.

## 6 · Assets (alle per GitHub-raw, `RAW`-Konstante oben)

- Pet-Contract: `media/3D_Assets/pet-LIBRARY.json` · GLBs: `.../animal-<id>.glb`
- Würfel: `media/3D_Assets/dice_ugur_lowpoly.glb`
- Deck-Registry: `media/kfb/index.json` (Karten, `coverOffset`)
- Narrator-Stimmen: `media/prompts/narrator/<datei>.md` (lokal gespiegelt in `data/narrator/`)
- Watercolor-Sky: `./assets/skydome_a.webp` (lokal)

## 7 · Was als Nächstes (v4+) — mit Georg klären, nicht eigenmächtig

Der nächste Sprint liegt als drei Briefs im Projekt (siehe `docs/BACKLOG.md` §v4-Sprint):
`uploads/BRIEF_pet_auswahl.md` (Auswahl-Ring vor der Fahrt), `uploads/KAYFABULATE_POC.md`
(FrizzleBob-Voice, Ebene 0+1), `uploads/NARRATOR_PACK_2_aus_der_NIE.md` (sechs Kadenzen).

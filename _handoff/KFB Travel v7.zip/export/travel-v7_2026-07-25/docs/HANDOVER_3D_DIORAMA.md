# Handover — Web-3D / Diorama-Techniken für den KFB Gameplay-Sim

**Von:** Fable-Design-Lane · **An:** Cowork-Lead (Engine/SSOT) · **Stand:** 2026-07-12
**Analyse-Quelle:** `andrewwoan/john-and-patricias-romantic-comfort-website` (Three.js WebGPU + GSAP + Howler)
**Begleit-Demo:** `Web3D Learnings (Diorama).dc.html` (interaktives Canvas, KFB/MED-Style)

Dieses Dokument destilliert, was wir aus einem ausgereiften Single-Scene-Diorama-Projekt für unseren KFB-Sim übernehmen sollten — mit konkreten Implementierungs-Vorschlägen, Andockpunkten und Best Practices.

---

## 0. TL;DR für den Lead

Das Referenzprojekt ist **keine Website**, sondern eine **Diorama-Engine als Klassen-Baukasten**. Genau unser Zielbild. Die sieben Übernahmen, priorisiert:

1. **Singleton-`Experience` + zentrale `update()`-Schleife** — Architektur-Skelett.
2. **Blender↔Code-Naming-Convention** als verbindliches Artist/Dev-Interface.
3. **Separates Hitbox-Modell** (unsichtbare Klick-Geometrie).
4. **Focus-Point-State-Machine** für Navigation (Übersicht ↔ Station, GSAP-Kamerafahrten + Back-Button).
5. **DOM-UI-Layer über Canvas** (keine 3D-UI) + **projizierte HTML-Marker** fürs Onboarding.
6. **Ein-Uniform-State** (Tageszeit/Wetter/Phase) treibt Stimmung global.
7. **Batch-Loading + DRACO/KTX2** für Performance/Mobile.

⚠️ **Risiko:** Referenz nutzt `three/webgpu` + TSL (Bleeding Edge, kein WebGL-Fallback im Code). Wenn KFB breite Browser-Kompatibilität braucht → WebGL-Pfad einplanen (Entscheidung nötig, siehe §8).

---

## 1. Architektur — das Grundgerüst

**Muster:** Ein **Singleton `Experience`** hält alle Subsysteme (Camera, Renderer, World, Raycaster, Resources, Time, Sizes). Jede Klasse holt sich `Experience.getInstance()` — kein Prop-Drilling, saubere Entkopplung. Eine zentrale `update()` ruft alle Subsystem-`update()`s pro Frame.

**Event-getriebenes Laden:** `Resources` (extends EventEmitter) feuert `progress` + `ready`. `World` baut die Szene **erst** bei `ready`. `Preloader` hört auf dieselben Events. Interaktion wird erst nach dem Preloader freigeschaltet (`raycaster.enabled = true`).

**Eigene `Time`-Klasse** als Tick-Emitter statt verstreuter `requestAnimationFrame` — wichtig für Spiellogik/Deltas im Sim.

> **Vorschlag KFB:** Dieses Skelett 1:1 übernehmen. `Experience` = unser Root; Subsysteme: `Board` (Diorama), `Cards`, `Dice`, `TurnState` (Spiellogik), `Camera`, `Raycaster`, `UI`. `TurnState` als EventEmitter (Draw→Roll→Play→Tell→Calls→Verdict) — die UI hört darauf, statt zu pollen.

## 2. Diorama

- **Ein einziges gebackenes Modell**, im Code traversiert; pro Mesh Material/Logik zugewiesen. Beleuchtung ist **gebacken** (Tag-/Nacht-Texturen), nicht real-time → billig, stabil, art-directed.
- **Texture-Atlas nach Sinngruppen:** `first-house`, `second-photos`, … `ninth-attachment`. Mesh-Präfix `obj.name.split("_")[0]` mappt aufs Atlas. **Kernlektion: Naming-Convention im 3D-Tool = die API zwischen Artist und Code.**
- **Stilisierung statt Realismus:** Inverted-Hull-Outlines mit zeitlich „boilendem" Jitter (wackelnde Tuschelinie), Gobos, Vignette, Kontrast-Post — Handmade-Look ohne teures Rendering. Deckt sich mit unserem Cel-Look (`look: "cel"` im Table).

> **Vorschlag KFB:** Board als ein gebackenes GLB. Atlas-Gruppen z.B. `board-`, `deck-`, `studio-`, `frizzlebob-`. Cel-Outline aus der Referenz ist der saubere Weg — **Achtung:** Vertex-Hull kann an Rundungen buggen (bekanntes Problem auch in unserem Table-Postmortem) → Phase-3-Weg = **Screen-Space-Outline**.

## 3. 3D-Model-Integration

- **DRACO-komprimierte GLB** (`GLTFLoader` + `DRACOLoader`, Decoder in `/draco/`). iOS zusätzlich **KTX2/Basis** (GPU-komprimierte Texturen) statt WebP; Device-Detection wählt Format.
- **Batch-Loading:** Assets in 4er-Gruppen, 150 ms Versatz → kein Main-Thread-Stall, flüssiger Progress-Balken.
- **Separates Hitbox-Modell (`Hitboxes.glb`):** unsichtbare Meshes nur für Klick-Erkennung, entkoppelt von der Render-Geometrie. **Interaktionszonen sind damit Design-kontrolliert.** Stark empfohlen.
- Materialien nach Load neu gesetzt (TSL Node-Materials), Original per `old.dispose()` freigegeben — Speicherhygiene.

> **Vorschlag KFB:** Hitbox-Modell für alle klickbaren Zonen (Karten-Slots, Würfel, Quest-Treppe, FB-Menü, PDF-Viewer an der Wand). Naming: `<Zone>_Raycaster_Hitbox`. Batch-Loader übernehmen; DRACO sowieso.

## 4. Navigation — Focus-Point-State-Machine

- **Keine freie Kamera.** Default ist eine subtile **Parallaxe**: Kamera folgt per `lerp` einer `basePosition` + Maus-Offset; Scroll = Dolly-Zoom mit Clamp-Bounds. OrbitControls nur für Debug (auskommentiert).
- **Focus-Points:** Jeder Hotspot = feste Ziel-Position+Rotation. Klick → GSAP fährt Kamera in ~2 s (`power2.inOut`), lockt Steuerung, zeigt **Back-Button**. Technisch eine **verschachtelte State-Machine** (`inFocus`, `_inHouseMode`, `_inMessagesMode`, `_inCharactersMode`; House→Messages).
- Mobile: eigenes Handling (Ein-Finger-Pan mit Clamp, Pinch-Zoom); Desktop: Maus-Parallaxe.
- **Wiedereinstieg sauber:** beim Verlassen eines Modus werden Listener entfernt, Zustände zurückgesetzt (`disableHouseDrag()` etc.), gespeicherte Positionen restauriert (`_savedHouseDragX`).

> **Vorschlag KFB:** Genau dieses Modell. „Übersicht" = Board-Totale; Stationen = Deck, Quest-Treppe, Studio-Wand (PDF), FrizzleBob. Ein `NavState`-Objekt mit `enter(target)`/`exit()`; jede Station registriert/deregistriert ihre eigenen Listener. **Best Practice:** Ziel-Positionen als benannte Konstanten oben in der Datei (wie `PHOTOS_POS`, `HOUSE_ROT`) — trivial zu tunen.

## 5. UI/UX — das Vorbildliche

- **DOM-UI über der Canvas, nicht in 3D:** Modals, Back-Button, Preloader, Hover-Labels = normales HTML, per GSAP animiert. Text scharf/zugänglich, Interaktion simpel.
- **3D→2D-projizierte Marker:** Welt-Koordinaten pro Frame auf Screen-Pixel projiziert (`vec.project(camera)`), HTML-Diamant-Labels positioniert. Hover über Info-Button blendet **alle Hotspots als Marker** ein → elegante Affordance/Onboarding-Lösung („was ist klickbar").
- **Progressive Discovery:** Hover-Label unten, cursor-folgender Tooltip (mit physik-artigem Drift + EMA-geglätteter Velocity beim Verlassen), einmaliger Drag-Hint der nach erster Nutzung verschwindet (`dragHintDismissed`).
- **Cursor als Zustandssignal:** `grab`/`grabbing`/`pointer`/`default` je Kontext.
- **Diegetische Interaktion:** Objekte *tun* etwas — Kreide direkt auf die Tafel (Raycast→UV→CanvasTexture bemalen), Haus per Drag, Karten via Morph-Targets umdrehen, Musik per Klick aufs Grammophon. Metapher trägt die Funktion.
- **Onboarding-Gate:** Preloader „Enter" / „Enter without sound" schaltet Audio erst nach User-Geste frei (Autoplay-Policy).

> **Vorschlag KFB:** DOM-UI-Layer im KFB/MED-Style (`themes/kfb-med.css`, siehe eigenes Doc). Projizierte Marker fürs Board-Onboarding. Diegetik haben wir teils schon (Kreide-Tafel im Table!) — konsequent ausbauen: Würfel wirklich werfen, Karten physisch ablegen, King's Verdict als Geste.

## 6. Konkrete Nächste Schritte (Vorschlag)

1. **Entscheidung WebGPU vs. WebGL** (§8) — blockt Renderer-Wahl.
2. **Naming-Convention-Spec** festschreiben (Atlas-Präfixe + `_Raycaster_Hitbox`-Suffix) — 1 Seite, dann kann Blender-Seite liefern.
3. **Skeleton bauen:** `Experience` + `Time`/`Sizes`/`Resources`(Batch)/`Camera`(Parallaxe+Focus)/`Raycaster`(Hitbox-Modell)/`NavState`. Lauffähig mit Platzhalter-Box.
4. **Focus-Navigation** an einer echten Station (Deck) verdrahten.
5. **Projizierte Marker + DOM-UI** im KFB/MED-Style andocken.

## 7. Best Practices / Tips & Tricks (destilliert)

- **Naming-Convention ist Vertrag, nicht Konvention.** Der ganze Material-/Interaktions-Code hängt an Mesh-Namen. Einmal sauber spezifizieren spart später Refactors.
- **Baken statt beleuchten** wo möglich — Stimmung als Textur + ein Uniform ist billiger und art-direktierbarer als Echtzeit-Licht.
- **Ein Zustandswert für globale Stimmung** (`uDayNight` 0→1, GSAP-getweent) statt N verstreuter Flags. Skaliert auf Wetter/Phase.
- **Kamera nie dem User ganz überlassen** — geführte Focus-Points > freie Orbit; verhindert „Verlaufen" und hält die Komposition.
- **Interaktionsgeometrie von Rendergeometrie trennen** (Hitbox-Modell).
- **Listener-Hygiene:** jeder Modus fügt seine Listener beim Betreten hinzu und entfernt sie beim Verlassen; Zustände explizit zurücksetzen. Sonst Ghost-Klicks.
- **Micro-Feedback zahlt sich aus:** Cursor-States, einmalige Hints (merken via Flag!), sanfte GSAP-Fades. Macht „billig" wie „poliert".
- **DOM für Text/UI, WebGL für Welt.** Nie Fließtext in 3D rendern.
- **Speicher freigeben** (`geometry/material.dispose()`) beim Material-Swap und Szenenabbau.
- **Batch + Delay beim Laden** hält den Progress-Balken flüssig statt ruckelnd.

## 8. Offene Entscheidung: WebGPU vs. WebGL

Referenz ist **WebGPU-only** (`three/webgpu`, TSL Node-Materials, `RenderPipeline`). Vorteile: moderne Shader-Pipeline, TSL sehr angenehm. Nachteil: WebGPU-Support variiert (v.a. ältere/mobile Browser), **kein Fallback im Referenzcode**.
- **Option A — WebGPU + WebGL-Fallback:** three.js kann `WebGPURenderer` mit automatischem WebGL-Backend; TSL läuft auf beiden. Realistischster Weg für breite Reichweite.
- **Option B — WebGL only:** maximale Kompatibilität, wir verzichten auf TSL-Komfort.
- **Empfehlung:** Option A, Renderer-Init mit Capability-Check. Bitte Lead-Entscheid — blockt das Skeleton.

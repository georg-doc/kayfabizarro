# Onboarding — Georg's Infinite Canvas (für einen frischen Claude-Design-Chat)

> Aktualisiert 2026-07-17 beim Rollercoaster-v3-Check-in. **Lies erst diesen Kopf,
> dann den Handover deines Strangs.** Der lange Abschnitt ab „ANHANG" ist der
> ältere Time-Capsule-Einstieg — Historie, kein Pflicht-Kontext mehr.

## 0. Das Wichtigste zuerst: es gibt DREI Stränge

Verwechslung der Stränge war historisch die teuerste Fehlerquelle. Kläre in Satz eins,
an welchem du baust, und lies NUR dessen Dateien:

| Strang | Was | Aktiv | Tech | Handover |
|---|---|---|---|---|
| **B · Rollercoaster** | immersiver Story-Ride (Achterbahn durch Mood-Himmel) | `Rollercoaster Ride v3.dc.html` + `rollercoaster-ride.v3.js` | **WebGPU/TSL** | `HANDOVER_rollercoaster_v3.md` |
| **A · Comic-Cube / Diorama** | Infinite-Comic-Box mit Pet-Cube | `KFB Diorama Box.dc.html` + `comic-cube.v2.js` | WebGL2 | `HANDOVER_v3.md` |
| **C · Table / Card-Viewer** | KFB-Spieltisch, Kartenzug | `KFB Table v2.dc.html` | WebGL2 | `HANDOVER_TABLE_v2*.md` |

**Achtung Tech-Unterschied:** Strang B fährt WebGPU/TSL (Chrome/Edge). A und C fahren
bewusst WebGL2. Nicht das Pattern des einen auf den anderen übertragen.

Datei-Status, geteilte Module und Aufräum-Kandidaten: `docs/HOUSEKEEPING.md`.

## 1. Wenn du am Rollercoaster (Strang B) baust

1. `docs/HANDOVER_rollercoaster_v3.md` — Architektur, Regeln, Drive-Bus, Asset-URLs.
2. `docs/CHANGELOG_rollercoaster.md` — was v1→v3 enthält (Drive-Bus, 6 Würfel, Vorhang,
   4-Layer-Sound, Shader-Dome, Augen-Fix).
3. `docs/BACKLOG.md` §Strang B — der v4-Sprint + Fallback-Plan pro Komponente.
4. Dann `rollercoaster-ride.v3.js` lesen — eine Datei, Klasse `RideV2`, Daten-Tabellen oben.

**v3 ist eingefroren.** Weiterbau = Kopie als `v4.js` + `v4.dc.html`, Changelog-Eintrag.

### Der v4-Sprint liegt bereit (drei Briefs + Notizen für den Coworker)

Georg hat den nächsten Sprint schon spezifiziert. Reihenfolge und Kern:

- **B-v4.1 Pet-Auswahl-Ring** — `uploads/BRIEF_pet_auswahl.md`.
  *Coworker-Note:* Der Screen kommt VOR die Fahrt (kein Track). Motion-Werte NICHT neu
  tunen — sie liegen in `pet-motion.v1.js` (turn/reactPos/idle/celebrate/transition), der
  overshoot 0.2 im `turn` ist das Game-Feel. Sprechblase = `kfb-ink.js` kopieren, keine
  zweite Tuschelinie erfinden. Pets sind rund, wenn `computeVertexNormals` NICHT läuft
  (facet===false) — der eckige Hase war dreimal genau dieser Aufruf. Select → Deck-Cover
  als erster (langsamer) Vorhang, den Cloth-Code aus v3 wiederverwenden.
- **B-v4.2 FrizzleBob-Voice POC** — `uploads/KAYFABULATE_POC.md`.
  *Coworker-Note:* Nur Ebene 0 (Phrase-Pool) + Ebene 1 (`power`/`lore` aus Deck-JSON),
  KEIN LLM. Kein SSML (wird auf macOS vorgelesen). Pausen = mehrere Utterances über
  `onend`+`setTimeout`. **Der Ride darf nie an der Stimme hängen** — keine `en`-Stimme →
  stumm weiter. Stille bei Stillstand ist gewollt.
- **B-v4.3 Sechs Narrator-Kadenzen** — `uploads/NARRATOR_PACK_2_aus_der_NIE.md`.
  *Coworker-Note:* Prompts liegen lokal in `data/narrator/` (Mapping: `README.md`). Der
  plattformfeste Hebel ist der Text-Rhythmus, nicht rate/pitch. Ma-Regel: vor dem Höhepunkt
  aufhören. Kadenz-Tabelle als Datenobjekt oben in der Engine anlegen (wie `AUDIO_MOODS`).

*Delegation:* B-v4.2/4.3 sind mechanisch mit klaren Contracts (delegierbar). B-v4.1 ist
Animations-Handwerk mit vielen Geschmacks-Entscheidungen → sorgfältiger Chat.

## 2. Regeln, die für ALLE Stränge gelten

- **Prime Directive:** jede Bewegung settlet in Ruhe. Kein Idle-Fidget, kein Metronom,
  Animation = Interpunktion. „Wonky, nicht Casino."
- **Layer Zero** für jeden Text, den die App spricht: keine Gedankenstriche, keine Emojis,
  kein Moral-Fazit, Rent-Rule (jeder Satz trägt Mechanismus/Kosten/Bild/Rhythmus), Power
  performen statt ansagen, „players/readers" statt „audience". `uploads/01_LAYER_ZERO_canon.md`.
- **Contracts, nicht Kopien:** Pet, Karten, Stimmen kommen per URL/Contract; geteilte Module
  (`pet-library.v6.js`, `pet-eye-rig.v3.js`, `pet-motion.v1.js`, `kfb-ink.js`) NICHT forken —
  Fixes von der Aufruf-Seite (siehe Augen-Fix: converge + Follow-Gaze in der Ride-Engine,
  Rig unangetastet).
- **Assets per GitHub-raw**, nichts Schweres ins Projekt (`RAW`-Konstante / `uploads/ASSET_URLS.md`).
- **Einchecken = einfrieren, Weiterbau als neue Datei** (vN+1), immer mit Changelog-Eintrag.
- **Verifizieren prüft Bewegung, nicht Endzustände.** Bei WebGPU lässt sich der Canvas per
  html-to-image schlecht heranzoomen — Detail-Checks lieber über Scene-Graph-Werte (`eval_js`).

---

## ANHANG — Historischer Time-Capsule-Einstieg (Strang-Vorläufer, Referenz)

> Der folgende Abschnitt beschreibt die ältere Time-Capsule-Ride-Linie (`Time Capsule
> Ride v5`…`v8`). Sie ist der Vorläufer des heutigen Rollercoaster-Strangs. Nur ziehen,
> wenn du an dieser alten Linie etwas nachvollziehen musst.

Du übernimmst die Weiterentwicklung des immersiven Almanac-Viewers in diesem Projekt. Dieses Dokument ist dein Einstieg. Lies es ganz, dann die Referenzen in der angegebenen Reihenfolge.

## 1. Lese-Reihenfolge

1. `uploads/START_HERE.md` — das Startpaket des ersten Baus (Warum + Was in Kurzform).
2. `uploads/00_EXPLORER_VIEWER_context_briefing.md` — Projekt, bestehende Bausteine, Nähte, Regeln, IP-Grenzen.
3. `uploads/01_TIME_CAPSULE_ride_build_brief.md` — das Konzept des ersten Baus im Detail. §1 (mentales Modell) und §8 (Scope) sind tragend.
4. `uploads/01_LAYER_ZERO_canon.md` — Stilboden für JEDEN Text, den FrizzleBob spricht. Nicht optional.
5. `docs/CHANGELOG.md` — was v1 und v2 enthalten und warum.
6. `uploads/ITERATION_2_polish_feedback.md` — das Feedback, das v2 umgesetzt hat.
7. `uploads/02_TRANSMEDIA_PLATFORM_vision.md` — Nordstern (L0–L5), NICHT der nächste Sprint.
8. Danach: den Code von `Time Capsule Ride v2.dc.html` lesen (eine Datei, Template + Logic-Klasse).

## 2. Projekt-Landkarte

- `Time Capsule Ride.dc.html` — v1, eingefroren. Nicht anfassen.
- `Time Capsule Ride v2.dc.html` / `v3` / `v4` — eingefroren (Standalone-Exporte in `export/`).
- `Time Capsule Ride v5.dc.html` — aktueller Stand (lesbare Collage + Aufzug-Navigation). Weiterentwicklung = Kopie als v6 anlegen, v5 einfrieren.
- `uploads/V5_BUILD_INSTRUCTION.md` — die aktuelle Anweisung, die v5 gebaut hat (die EINE gültige „für vN“-Datei; ältere nur Referenz).
- `assets/sonic_slaughterhouse.pdf` — das Deck-PDF (web-Auflösung, 15 Seiten, 745×416pt, KEIN Text-Layer, reine Bildseiten).
- `data/sonic_slaughterhouse.json` — Starter-Deck-JSON (12 Karten, name/power/lore). SSOT für alle Texte.
- `docs/` — Changelog, dieses Onboarding, Cowork-Handover.
- `Fractal Almanac.dc.html`, `Three Weathers.dc.html`, `Canvas.dc.html` — frühere/parallele Experimente derselben Linie (Chamber-Ansatz). Kontext, nicht Baustelle.
- `assets/deck_a|b|c.pdf`, `data/deck_a|b|c.json`, `ontology/`, `themes/` — Material des Chamber-Strangs (Utopia/Dystopia/Protopia-Trilogie).

## 3. Architektur in fünf Sätzen

1. Das Ganze ist ein **zustandsbehafteter PDF-Viewer**: Seite, Quadrant, Zoomstufe sind die States; Rotationen, Fahrt und Portale sind nur animierte Wechsel zwischen diesen States.
2. **PDF = das Bild, JSON + Skript = die Worte und das Spiel.** Keine Bild-Pipeline, das Deck-PDF wird per pdf.js on-demand gerendert und Quadranten geschnitten.
3. Die **Kapsel** (Quader 6.4×3.6×3.6) trägt den ganzen Turn: 4 Längsseiten = Actor + 3 Szenen, 2 Deckel = Story-Mode + Quest-Die. Drehung = Erzähltempo = finger-rule.
4. Die **Fahrt** ist eine unsichtbare Catmull-Rom-Spline; Übergang = eine durchgehende Timeline (Iris → Accel → Hyperraum → Decel → Docking mit Settle).
5. **Alles Sichtbare ist parametrisch**: Property-Skin (kayfabizarro/medkayfab/frizzlecrits) und Mode-Palette (6 Story-Modes) liegen als Datenobjekte oben in der Logic-Klasse, nichts ist hardcoded.

## 4. Die Logic-Klasse (Component) — Orientierung

Konstanten oben in der Klasse:
- `THEMES` — paper (Default, Marken-Primär) / dark. Gutter, Himmel-Basis, Panel, Fog, Partikel-Blending folgen dem Theme; HUD via CSS-Variablen (`data-theme`).
- `SKINS` — Property-Häute (Akzent/Frame, Dust-Töne, Himmel-Tint), orthogonal zum Theme. Skin-Wechsel = Tweak-Prop `propertySkin`.
- `MODES` — 6 Story-Modes mit `ink` + `panel` (**Interim-Palette Rules S.16** vom Cowork-Lead; kanonische Hex folgen). Himmel je Mode wird in `skyFor()` abgeleitet.
- `DECK` — Deck-Parameter: pdf, json, `cardsPerPage`, `coverPages`, `gridTop` (Karten-Grid beginnt bei 15 % Seitenhöhe unter dem Header), `cardMap` (Kartenname → [Seite, Quadrant 0=TL,1=TR,2=BL,3=BR]). **cardMap ist nötig, weil das PDF thematisch sortiert ist** (Phasen-Seiten) und keinen Text-Layer hat; visuell gemappt am 2026-07-10.
- `FACE_MAT = [4, 2, 5, 3]` — Beat b → Material-Index der BoxGeometry ([+x,−x,+y,−y,+z,−z]; +x = Mode-Deckel, −x = Quest-Deckel/Tür).
- `FACE_ROT = [0, 0, π, 0]` — Canvas-Rotation pro Beat-Fläche. **Visuell verifiziert, nicht ändern ohne Screenshot-Test.**
- `INTRO`, `CARD_LINES`, `OPENERS`, `VERDICTS` — die vorgeschriebenen Layer-Zero-Texte (12 Karten-Zeilen in Starter-JSON-Reihenfolge).

Phasen-Maschine (`this.phase`): `boot → approach → script ⇄ ready → iris → riding → dock → (arrive) …` plus `rolling` (Mode-Würfel) und Free-Fly (`this.freeFly`, orthogonal). Jede Station hat ein `script`-Array (Opener, 4 Beats, Verdict, ggf. Closing); `advance()` steppt, `applyItem()` dreht/spricht/highlightet (`st.lit`), `scheduleAuto()` taktet. Navigation: Zoom-Leiter `st.zoom` 0 Karte / 1 Seite / 2 Cover / 3 Shelf (`setZoom`, Aufzug-Panel `updateFloors`/`elevMove`, A/D-Geschwister via `manualTurn`), Klick-Zoom `faceFocus()` (kürzester Weg + Dolly `focusIn`), Deckel-Blick rollt aufrecht (Snap auf 2π). Meta lebt IMMER im Screen-Space (`setMeta`/`syncMeta`, Caption-Box + Ticker), nie auf der Fläche. Skydome: `setupSkydome()`/`canvasSkyTexture()` (Tweak `skydomeSource` + Taste K, Fallback bei fehlender webp = Collage), Drift folgt Kamera-Speed. NDJSON-Log (`logEv`, Taste L, `window.KFBRideLog`).

Zeichnen: jede der 6 Flächen ist ein Canvas + `THREE.CanvasTexture`. `drawFace` (Gutter + cover-fit Art bzw. Seiten-Zoom), `drawModeCap` (Pips), `drawQuestCap` (Zahl + Fortschritt, `aperture`-Parameter = Iris).

## 5. Arbeitsregeln

- **Prime Directive: schlank halten.** Der Vorgänger-Anlauf kippte in Komplexität und wurde unspielbar. Erst Gefühl beweisen, dann skalieren. Alles unter „Spätere Schichten" im Build-Brief NICHT nebenbei mitbauen.
- **Versionierung:** eingecheckte Versionen einfrieren; Weiterentwicklung als neue Datei (v3, v4 …); jede Version bekommt einen Changelog-Eintrag in `docs/CHANGELOG.md`.
- **Layer Zero** für jeden Text, den die App spricht: keine Gedankenstriche, keine Emojis, kein Moral-Fazit, Rent-Rule (jeder Satz trägt Mechanismus/Kosten/Bild/Rhythmus), Power performen statt ansagen, „players/readers" statt „audience".
- **Ein Korpus, nicht forken:** Änderungen an Karten-Texten, Grades, Personas oder der Engine gehen in die Cowork-Lane zurück (siehe `docs/HANDOVER_cowork_lead.md`), nicht als lokale Kopie hierher.
- **IP:** nie das Print-PDF einbetten oder öffentlich hosten, nur web-aufgelöste PDFs (das vorhandene ist web-Auflösung).
- **WebGL2, nicht WebGPU.** Drei billige Effekte reichen (Halftone, Sky-Shader, Partikel).

## 6. Verifizieren (spart dir Stunden)

- Face-Orientierung und Karten-Mapping IMMER per Screenshot prüfen: W-Taste per `window.dispatchEvent(new KeyboardEvent('keydown',{code:'KeyW'}))` auslösen, Space steppt Beats, dann Screenshots der 4 Beats vergleichen.
- Drag/Hover/Wheel lassen sich synthetisch testen: PointerEvents/WheelEvent auf das Element `[data-screen-label="world"]` dispatchen.
- Neue `THREE.Points`/`LineSegments`, deren Positionen erst zur Laufzeit gesetzt werden: `frustumCulled = false`, sonst unsichtbar (Bounding-Sphere-Falle, ist uns passiert).
- pdf.js: Worker-URL ist CDN (`GlobalWorkerOptions.workerSrc`); das Deck-PDF hat keinen Text-Layer, Namenssuche im PDF funktioniert also NICHT — Mapping bleibt visuell/manuell, bis Deck-JSONs `cardNumber` tragen.

## 7. Was als Nächstes ansteht (nicht eigenmächtig starten, mit Georg klären)

- Impuls-/Momentum-Flug-Kern: eigener code-starker Track laut V5 §5 (`IMMERSIVE_FLIGHT_research.md` liegt noch nicht im Projekt); wird später als Bewegungs-Kern eingesetzt.
- Türblatt-Stile im Deckel-Türrahmen (Vorhang paper / Schleuse dark / surreale Tür): braucht GLB-Assets.
- Kanonische S.16-Hex einpflegen (ersetzt Interim-Werte in `MODES`).
- NDJSON-Replay (Aufzeichnung läuft seit v3).
- L1: Paket-Manifest + `?pkg=`; echte Nähte (KFBDie, Beat-Engine, Avatar in L2); Fable-Pass über die FrizzleBob-Texte.


---

## Stand 2026-07-17: v4 EINGEFROREN — neuer Chat startet mit v5

Lies zuerst: `docs/HANDOVER_rollercoaster_v4.md` (Metapher „storytelling animals", gelernte
WebGPU-Fallen, v5-Plan) → `docs/CHANGELOG_rollercoaster.md` (Freeze-Block oben) →
`uploads/HANDOVER_v5_die_hand.md` (v5-Kern: die Hand) → `uploads/BRIEF_portal_und_takt-73f6ee21.md`
(Takt-System, schon umgesetzt, Kontext fürs Beat-Meter).

Arbeitsregeln unverändert: v4-Dateien NICHT mehr anfassen (Kopie als v5), KISS, jede Karte immer
player-facing lesbar, Tuschekanten immer schwarz-irregulär, Remote-Fetches mit Retry, Takt-Uhr am
AudioContext. Test-Referenz: Chrome mit WebGPU.

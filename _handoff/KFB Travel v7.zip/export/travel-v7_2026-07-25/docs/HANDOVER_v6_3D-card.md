# Handover v6 → Coworker: 3D-Paper-Card als Ersatz für die 2D-Surf-Karte

**Für:** Coworker (Fixing-Runde) · **Von:** Design-Chat · **Stand:** 2026-07-18
**Regel für diese Aufgabe (Georg):** an Pet/Karten-Position im aktuellen v6 **NICHTS** ändern,
bis der 3D-Karten-Weg sauber steht. Der jetzige Zustand ist der Known-Good-Anker (siehe
`docs/POSTMORTEM_v6_pet-board.md`).

---

## 0. Warum überhaupt 3D-Karte
Die aktuelle „Surf-Karte" unter dem Pet ist ein **2D-Quad** (`buildPetBoard`): eine gebogene
Plane mit der KFB-Kartenrücken-Textur, pro Frame gebogen/gerippelt und mit einer Basis-Rotation
flach zur Kamera gekippt (~30°/0.52 rad Deck-Winkel). Zwei ungelöste Schwächen:

1. **Füße stechen im tiefsten Idle-Frame durch das flache Quad** (kein Volumen, keine Kante, an
   der man kappen kann, ohne dass es zickt — der Clip-Ebenen-Versuch scheiterte, s. §3).
2. Das Quad ist eine Fläche → von der Seite/schräg wirkt es dünn und „aufgeklebt".

Eine **echte 3D-Karte mit Dicke** könnte beides lösen: die Füße stehen auf einer realen
Oberfläche mit Materialstärke, und die Kante gibt visuelle Verankerung.

---

## 1. Das Asset — BEREITS VERMESSEN (Korrektur)
`media/3D_Assets/KFB_PaperCard_01.glb` · **22.908 Bytes (~22 KB)** · im Repo.

**Der vorige Coworker hat das GLB schon vermessen** (HANDOVER_v6_kickoff): ein Mesh `UI_Paper`,
Material `Atlas`, **BBox 0.0051 × 0.0052 × 0.0031 → 1.02:1 (quadratisch, NICHT 1.79)**, und die
**UVs zeigen in einen Kenney-Atlas, nicht auf ein sauberes 0–1-Rechteck.** Das ändert den Plan:

- Backside-Textur lässt sich **nicht per einfachem `material.map =`** sauber auflegen — die vorhandenen
  UVs mappen auf eine Atlas-Kachel. Nötig: **UVs neu setzen** (Deckfläche auf 0–1 remappen) ODER die
  Geometrie ignorieren und ein **eigenes flaches Karten-Mesh** bauen (PlaneGeometry mit Dicke), das
  wir voll kontrollieren. Bei 1.02:1 vs. Ziel-1.79 ohnehin non-uniform scale nötig.
- **Empfehlung:** das GLB als Formreferenz nehmen, aber ein eigenes Karten-Mesh mit sauberer UV und
  KFB-AR 1.79 bauen — weniger Fummelei als UV-Reparatur eines Atlas-Meshes. Erst messen ob die 22-KB-
  Geometrie überhaupt Mehrwert (Dicke/Papierwelle) bringt; wenn nein, reicht ein Box/Plane.

---

## 2. Georgs Idee (zu prüfen, nicht blind umsetzen)
> „Dimensionen passen nicht — aber könnten wir die KFB-Backside auf Vorder- UND Rückseite legen
> und als Ersatz für die 2D-Karte nutzen? Und mit der Default-irregular-Ink-Outline?"

**Machbarkeits-Einschätzung: ja, plausibel, mittlerer Aufwand.** Zerlegt:

### 2a. Dimensionen anpassen
- Kanonische KFB-Karten-AR (nach dem Crop-Fix): **native Zellgröße ~745**, Cover/Panels 1280 →
  KFB-Kartenrücken-AR ≈ **1.79** (siehe `KFB_CARD_AR` im Crop-Postmortem).
- GLB-AR misst der Coworker (§1). Wenn sie abweicht: **non-uniform scale** auf die GLB-Gruppe
  (x/z so, dass die Deckfläche 1.79 trifft), Dicke (y) separat wählen. Alternativ die Textur-UVs
  anpassen — aber Scale ist KISS und reicht.

### 2b. Backside-Textur auf beide Seiten
- Die 2D-Karte nutzt heute `KayfaBizarro_Card_Backside` (CanvasTexture). Dieselbe Textur auf
  Front- UND Back-Material der GLB legen. Wenn die GLB ein Material für beide Faces hat: ein
  `material.map = tex`. Wenn getrennt: beide Slots gleich setzen. `side: THREE.FrontSide` pro Face
  (Box hat korrekte Normalen) — NICHT DoubleSide, sonst z-fighting an der Kante.

### 2c. Irregular Ink Outline
- Kanonische Quelle ist `kfb-ink.js` / `inkTail` (der `hb`-Fix von heute: `hb = min(W,H)·0.0069`).
- Auf einem 3D-Mesh gibt es zwei Wege:
  - **(A, KISS)** Ink bleibt 2D: die Outline als Teil der **Textur** rendern (wie heute die 2D-Karte:
    inkTail zeichnet die Kante ins Canvas, das dann als map dient). Für ein flaches Kartendeck völlig
    ausreichend und performant. **Empfehlung.**
  - **(B, teuer)** echte 3D-Outline (Backface-Hull oder Post-Edge). Nur nötig, wenn die Karte stark
    aus der Ebene rotiert. Für ein flach liegendes Surfbrett-Deck **nicht** nötig — nicht bauen.

### 2d. Ersetzt was?
- `buildPetBoard` austauschen: statt der gebogenen Plane die GLB-Gruppe als `this.petBoard.mesh`
  in `petHolder` hängen, an derselben Sohlen-Position (`bb.min.y − 0.006`).
- **Achtung Biege-Animation:** die 2D-Karte biegt sich pro Frame (`amp * (x/halfL)² …`) und rippelt.
  Ein GLB hat feste Geometrie → entweder (i) auf die Biegung verzichten (statische Karte, ok für den
  Start), oder (ii) einen leichten Bend per Vertex-Shader/Morph nachrüsten (später, nicht Runde 1).

---

## 3. Was wir HEUTE probiert und wieder verworfen haben (Beweise & Werte)
Damit der Coworker dieselben Sackgassen nicht zweimal läuft. Alles gemessen im echten Flow
(`_select()` → `releaseGate()`), nicht vermutet.

| Versuch | Wert/Beweis | Ergebnis |
|---|---|---|
| **Squash-Pivot** (`petScaler.position.y = soleY·(1−sq.s)`) | `_petSoleY` gemessen = **0** (Pet-Origin liegt schon auf den Füßen) | wirkungslos → raus |
| **Board an Bind-Pose-Sohle** (`buildPetBoard`) | Foot in grp-Space maß Board **0.076 zu hoch** → in petHolder-Space korrigiert (`invH·meshWorld`), Sitz `bb.min.y − 0.006` | KNOWN-GOOD, bleibt |
| **Laufendes Foot-Min** (Board pro Frame an tiefste animierte Sohle) | Foot local-y schwingt **−0.0747 … −0.0358** über den Idle-Clip; Bind-Pose trifft nur −0.03 | Board **wanderte** → Pet verlor Kartenbindung → raus |
| **Clip-Ebene an Board-Deckfläche** (`localClippingEnabled` + `material.clippingPlanes`, Ebene pro Frame aus `bN`/Board-Weltpos) | `clipConstant` sprang je nach Board-Tilt (−10 … +1e4) | Pet **willkürlich gekappt, verschwand teils ganz** → raus |
| **Launch-Ramp + großer Lean/Float** (leanDamp 0.45, maxTilt 0.22, bob 0.028) | „45°-Snap" war real Board-Deck (fixe 30°) + zu großer Lean, nicht ein Positions-Snap | zurück auf subtil (0.24 / 0.12 / 0.012) |

**Kern-Erkenntnis:** Der Fuß-Durchstich lässt sich mit dem **flachen Quad** nicht sauber lösen —
weder per Pivot noch per Clip auf der tanzenden Deckfläche. Genau **hier setzt die 3D-Karte an**:
eine echte Oberfläche mit Kante gibt einen stabilen, mit dem Board mitrotierenden Clip-Referenz
(oder braucht dank Dicke gar keinen Clip).

## 3a. Wenn doch geclippt werden muss (für die 3D-Karte)
Der heutige Clip scheiterte, weil die Ebene aus der **sich biegenden, tanzenden** Deckfläche kam.
Für die 3D-Karte: die Clip-Ebene an ein **flach-fixes, mit der Karte starr mitrotierendes
Hilfs-Mesh** koppeln (Karte hat feste Geometrie → ihre lokale +Y ist stabil). Ebene = Karten-lokale
Deckfläche, in Weltkoords über `card.matrixWorld` transformiert, EINMAL pro Frame, ohne Bend-Rausch.
Das ist der Unterschied, der es diesmal stabil macht.

---

## 4. Known-Good-Werte (Referenz, nicht ändern)
- HUD-Pet = Kind der **HUD-Kamera**, feste kamera-lokale Pose → Schirm-Jitter **0** (gemessen).
- `mixer.timeScale = 0.5` · Blink `dur 0.30`, Gap 4–9 s.
- Cockpit-Lean `leanDamp 0.24`, `maxTilt 0.12` · Float bob 0.012 / sway 0.008 @ 2.72 rad/s.
- Board-Sitz `feetY = bb.min.y`, `mesh.position.y = bb.min.y − 0.006`, `depthTest:true`.
- 4-Punkt-HUD-Studio (key/fill/rim/amb), Pet nie dunkel.

---

## 5. Empfohlene Reihenfolge fürs Fixing
1. GLB messen (§1) — AR, Node-Baum, Materialslots. **Erst messen, dann planen.**
2. GLB laden + auf KFB-AR 1.79 skalieren, Backside-Textur auf beide Faces (§2a/2b).
3. Ink als Textur-Kante (Weg A, §2c). Kein 3D-Edge-Hull.
4. `buildPetBoard` gegen die GLB-Gruppe tauschen, gleicher Sohlen-Sitz (§2d), erstmal OHNE Bend.
5. Fuß-Durchstich prüfen: reicht die Dicke? Wenn nein → starr-mitrotierender Clip (§3a).
6. **Eine Änderung, dann Screenshot im echten Flow.** Bei Regress zurückbauen, nicht stapeln.

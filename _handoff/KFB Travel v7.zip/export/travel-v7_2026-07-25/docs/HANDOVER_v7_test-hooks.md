# HANDOVER v7 — DEV/QA Test-Hooks (`window.__rideTest`)

**Sprint 5.1 · Stand 2026-07-18 · Datei: `rollercoaster-ride.v7.js`**

Deterministische Test-Hooks, damit sich **jeder Ride-Zustand reproduzierbar anspringen** lässt —
für Screenshots, Verifikation und Regressions-Checks. Konzept übernommen aus
`majidmanzarpour/threejs-game-skills` (Test-Hooks + Seeded-RNG), auf unser single-file-DC-Runtime
portiert (kein Build-Step, keine Fremd-Abhängigkeit).

## Warum
Bisher war jede Fahrt zufällig: `this.mode` (D6) und `this.rideSeed` (Kartenpool/-reihenfolge)
werden pro Ride neu gewürfelt. Beim Prüfen/Screenshotten hieß das „mal so, mal so". Die Hooks
pinnen Mode, Seed und Fortschritt fest → gleiche Eingabe, gleiches Bild.

## API
Die Ride-Instanz liegt auf `window.__rcRide2`; die Hooks auf `window.__rideTest` (erst nach
`start()` verfügbar). Alle Aufrufe sind synchron.

| Aufruf | Wirkung | Rückgabe |
|---|---|---|
| `__rideTest.seek(t)` | Fortschritt auf `t` (0..1, wrappt) pinnen, **Physik einfrieren**, Cover-Gate ausblenden. Kamera/Pet stehen an genau dieser Track-Stelle. | `progress` |
| `__rideTest.play()` | Einfrieren aufheben — Fahrt läuft normal weiter. | `true` |
| `__rideTest.setMode(n)` | Story-Mode `0..5` erzwingen (TRAGIC…FORBIDDEN). Färbt Dashboard, Button, Shader-Mood, Erzähler — via gemeinsame `_applyMode`, identisch zum D6-Roll. | `mode` |
| `__rideTest.setSeed(s)` | `rideSeed` setzen und Karten neu zuteilen (`assignCards`) → deterministischer Kartenpool/-reihenfolge. | `rideSeed` |
| `__rideTest.snapshot()` | Zustands- + Perf-Schnappschuss (s. u.). | Objekt |
| `__rideTest.dev(on)` | Perf-Readout (FPS/DRAWS/TRIS) zur Laufzeit an/aus (Arg weglassen = toggeln). Nötig, weil der Sandbox-/Preview-iframe kein `?dev` trägt. | `dev`-Bool |

### `snapshot()` liefert
```json
{
  "progress": 0.42131, "velocity": 0.00012, "speed01": 0.31,
  "mode": 3, "modeName": "ABSURD", "rideSeed": 738492011,
  "held": false, "frozen": true,
  "fps": 60, "draws": 128, "tris": 246011
}
```
`fps` = gleitender Mittelwert (in `animate` per EMA, dt auf 20 fps geklemmt). `draws`/`tris` aus
`renderer.info.render` (WebGPU: `drawCalls`, sonst `calls`) → **FX-Stacking-Regressionen messbar**
(Beat-Aura, Speedlines, Curtains). Das ist die Datenbasis für den geplanten DEV-Readout (Sprint 5.2).

## Rezept: reproduzierbarer Screenshot
```js
const R = window.__rideTest;
R.setSeed(12345);     // fixe Karten
R.setMode(3);         // fixer Mood (ABSURD)
R.seek(0.42);         // exakte Track-Stelle, eingefroren
// → Screenshot ziehen
R.snapshot();         // Zahlen fürs Protokoll
R.play();             // wieder freigeben
```

## Implementierungsnotizen (für Coworker)
- **Einfrieren** = `this._frozen`. In `animate` wird nur der Fortschritts-Vorschub übersprungen
  (`this.progress += …`); der Rest des Loops (Kamera, Pet, Aura, Audio) läuft weiter, damit der
  eingefrorene Zustand vollständig gerendert dasteht.
- `seek` setzt zusätzlich `held=false` + blendet das Cover-Gate aus, sonst verdeckt der gehaltene
  Vorhang die Sicht.
- **Mode** läuft ausschließlich über `_applyMode(n)`. Wer künftig Mode-Nebenwirkungen ergänzt
  (Licht, Sound, …), macht das DORT — dann greifen Roll und Test-Hook gleich.
- **Seed**: `rideSeed` speist `mulberry(this.rideSeed)` in `assignCards` (Sprint-1-Jukebox-Logik).
  `setSeed` teilt sofort neu zu; wirkt erst mit gebauten `curtains`.
- Kein Guard gegen Produktivnutzung nötig — die Hooks sind read/write und harmlos; der Ride läuft
  ohne sie unverändert. Für einen späteren `?dev`-Gate wäre nur der DEV-Readout (UI) relevant,
  nicht die Hooks.

## Sprint 5.2 — DEV-Perf-Readout (ergänzend)
Dieselben Zahlen wie in `snapshot()`, aber sichtbar im Dashboard: `?dev` an die URL (oder
`localStorage.setItem('rc2-dev','1')`) → drei grüne Zeilen **FPS · DRAWS · TRIS** erscheinen im
Tacho-Grid (beim Hover aufs Pad). Im Sandbox/Preview (kein `?dev` im iframe): `window.__rideTest.dev(true)`
zur Laufzeit. `this.dev` steuert das; ohne Flag sind die Zeilen aus dem Grid
entfernt (`[data-dev]` → `display:none`). Quelle: FPS-EMA + `renderer.info.render`. Zweck: beim
Stapeln von FX (Beat-Aura, Speedlines, Curtains) Regressionen sofort sehen.

## Nicht enthalten (bewusst)
- Kein Auto-Screenshot/Playwright (unser Runtime ist DC, nicht Vite/CLI) — die Hooks sind der
  Ersatz dafür: von außen aufrufbar, Zustand deterministisch.

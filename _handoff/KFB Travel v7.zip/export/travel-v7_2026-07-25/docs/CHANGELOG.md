# KFB Table — Changelog

## v2 · 2026-07-12 · Turn-Flow + Studio + Cel-Politur „check-in"

Eingefroren als `KFB Table v2.dc.html` + `kfb-table.v2.js` (Default-Look: **cel**). v1 bleibt als Referenz liegen.

### Neu in v2
- **Turn-State-Machine:** REST → ROLL → PLAY → TELL → CALLS → MOVE; Phasen-Strip + TURN-Zeile unten links konsolidiert (oben frei)
- **TELL:** spieler-getaktete Spotlight-Blase (klick die Karten in DEINER Reihenfolge), CALLS (KayfaBINGO/BOGGLE/BONGO/BLÖDSINN + → VERDICT), King-Rotation → REST
- **Studio-Wand:** Raum-Shell (Wand mit echtem Fensterloch, Boden, 2 Seitenwände), Skydome-Tapete (einmal gestreckt, keine Kacheln), Fenster mit Parallax-Außenwelt, Galerie (Georg-Foto, Wanted-Poster, FB-Story-Mode-Slideshow mit Cross-Fade, synct auf gerollten Mode), **2 klickbare PDF-Viewer** (Anti-Rules · Rule-Book, direkt vom GitHub-Repo, Close-up + Blättern)
- **GLB-Requisiten:** quaternius-Tisch (ersetzt Box), Scheren ×2 (grau-metallic, 2×), Tuschefass, FrizzleBob (gelb, schwarze Augen, steht links auf dem Tisch, Skeleton-Hull-Outline)
- **FrizzleBob-Menü** (Klick auf den Hasen): Auto-Play (phasen-passender Zug) · Explain Rules (Zoom aufs Regelwerk) · Select Decks (A/B/C, Stub)
- **Quest-Treppe:** prozedural, diagonal (~45°) zur Quest-Karte, quadratische Stufen mit Würfelaugen, EIN Silhouetten-Hull (keine Trennlinien)
- **Blasen-System v2:** Comic-Tail ist Teil des EINEN Ink-Pfads (keine Naht/Stufe), Tooltips mit 280-ms-Debounce + Auto-Hide + fester Welt-Anker, Eine-Blase-Regel (Karaoke-Blase unterdrückt Tooltips), Tail nur wenn Blase ÜBER dem Anker
- **Theme paper/dark** (◐) für alle Ink-Panels; Pad-Icons (◎ ☰ ◐) als dunkle Ink-Flächen mit irregulärer Outline; PDF-Pager im selben Stil
- **Flächen-API:** `setSurface('main'|'left'|'right'|'floor', url)` — Bild oder mp4/webm-Loop; 4 URL-Felder im ☰-Modal
- **Robustheit:** PDF-Render-Timeout (15 s) → Platzhalter + Hintergrund-Retry mit Textur-Swap; Boot hängt nie mehr an pdf.js
- **Hand:** Draw 3→4, open breit gestaffelt (keine Actor-Kollision), minified 0.75× über der Matte
- **Schatten-Modell:** EIN schattenwerfendes Key-Light (Ortho-Box über Tisch+Wand, 4096er Map), Fill/Wash schattenfrei, keine gemalten Pseudo-Schatten mehr
- **Fonts:** Shantell Sans (Fließtext/Blasen), Special Elite (Kicker), Irish Grover („KayfaBizarro"-Wortmarke auf der Matte)
- **Full Navigation** (Test-Modus) + ◎-Reset; „Zurück an den Tisch"-Button entfernt

### Post-Mortem: Cel-Outlines („unten dicker" ungelöst)
Ziel war eine Licht-Logik für Outlines (schattig/unten dick, lichtseitig dünn). Vier Anläufe:
1. **Skalierte Inverted-Hulls** — Blitzer am Boden; bei GLBs mit Node-Scales explodieren Offsets zu riesigen schwarzen Flächen (Fix: Welt-Skalierung pro Mesh messen).
2. **Gepaddete Geometrie-Hulls** (Box+pad) — Trennlinien zwischen gestapelten Boxen, Overshoot-Linien auf Deckflächen.
3. **Shader-Hull mit Boden-Verdickung** (tall-Faktor) — bodennahe Vertices stülpen seitlich-unten aus → schwarze Blobs unter Würfel/Objekten.
4. **Final (v2):** Normal-Offset-Shader-Hull, Licht-Gewichtung (0.6+0.9·shad), downCut dämpft nach unten gerichtete Normalen — stabil, aber „unten dicker" ist als Vertex-Offset NICHT sauber erreichbar: Strichbreite hängt an der Geometrie und kollidiert am Bodenkontakt.

**Empfehlung Phase 3:** Screen-Space-Outlines (Post-Processing, Tiefen-+Normal-Kanten à la OutlinePass/Sobel) mit variabler Strichbreite — dort ist „unten dicker" ein Screen-Space-Gradient, kein Geometrie-Problem. Skinned Meshes brauchen Hulls als SkinnedMesh + bind() (gelöst); Scheren/Tuschefass laufen bis dahin bewusst OHNE Outline.

### Bekannte Offene (→ BACKLOG.md)
Deck-Switch (GitHub-Multi-Deck), Voice-Guide, kanonische S.16-Hex, Kartenrückseite, Sound, FB-Augen-Glanzlicht (Textur), Outline-Feinpass.

## v1 · 2026-07-11 · Phase-1-Slice „check-in"

Eingefroren als `KFB Table v1.dc.html` + `kfb-table.v1.js`. Weiterentwicklung auf `KFB Table.dc.html` + `kfb-table.js`.

### Kern (Phase 1, Handover §9 bewiesen)
- **PDF→Textur-Pipeline** gegen echtes Deck B (pdf.js, coverOffset=1, 2×2-Crop, weißer Schnittrand, LRU-Cache; Platzhalter-Fallback offline)
- **Story-Beats-Layout:** ACTOR-Slot (PoV, vor dem Spieler) → SCENE 1–3 → QUEST (End-Panel) + Quest-Die-Rampe, die auf das Quest-Panel zuführt (Stufe 6 endet an der Karte)
- **3er-Hand** (secret, minified ↔ open, Auto-Minify + Nachziehen nach dem Ausspielen)
- **Rituale:** Draw · Show-it-Spin-it-Sell-it (mit Overwrite/Überkleben) · Story-Mode-Roll → Mood-Wash · King's Verdict (+2/+1/±0/−1)
- **Quest-Resolvement:** 6 = Finale (Karten-Hop + Gold-Konfetti + Treppen-Top glüht in Mode-Ink) · unter 1 = Karte zerfällt in Schnipsel, Würfel fällt vom Tisch, neuer Quest + Würfel-Drop
- **Karaoke-/Detail-Zoom** mit Cue-Sprechblase (Cue, kein Skript; Quest-Anker)
- **Narrator-Box** (5-Beat-Story, ‹ ›, Finger-Rule = goldenes Highlight + Lift)
- **Sprechblasen-System:** Ink-Outline-SVGs (exakte Ecken, wellige Kanten), Hover-Tooltips mit festem Anker + Pfeil
- **Zwei Looks** (Tweak `look`): `papier` (naturalistisch, echte Schatten) / `cel` (Toon-Bänder, Inverted-Hull-Outlines, Kontakt-Blobs statt Schatten)
- **Cartoon-Physics:** Quest-Würfel Stretch&Squash, Karten-Hop, Settle in Ruhe (kein Idle-Bob)
- **3D-Props** (ASSETS.md-Pipeline, Cel-Reskin): 2× Schere, Tusche-Fläschchen, FrizzleBob-Hase; skinned Meshes ohne Hull (Bind-Pose-Bug)
- **Navigation:** Orbit-Drag (Welt greifen), WASD/Pfeile = Pan, Q/E = Drehen, Space/Shift/Mitte+Drag = Pan, Rad/Pinch = Zoom, Touchpad-Scroll = Pan; alles geclampt (§4: eingeschränkte Freiheitsgrade)
- **Mode-Farben:** 6× ink/panel Interim aus Rules S.16 — kanonische Hex ausstehend

### Bekannte Offene
- §11.3 Kartenrückseite = generierter Platzhalter
- Mode-Farben interim (nicht kanonisch verifiziert)
- Hase ohne Outline (skinned); Ausrichtung geraten
- Nur Deck B; Instanz-Test mit 3 Decks aussteht
- Kein Sound

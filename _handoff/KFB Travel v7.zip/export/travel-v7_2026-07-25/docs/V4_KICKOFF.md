# v4-Kickoff — Rollercoaster Ride (Strang B)

> Zum Einfügen als erste Nachricht in den frischen v4-Design-Chat. Danach die
> hier genannten Dateien lesen lassen, dann bauen.

## Wo wir stehen

**v3 ist eingefroren und erreicht das MVP** (siehe `docs/CHANGELOG_rollercoaster.md`,
Kopf „❄️ v3 EINGEFROREN"). Ein WebGPU/TSL-Rollercoaster mit:
- Fahrt auf der three.js-`webgpu_xr_rollercoaster`-Kurve (1:1), Banking/Velocity-Loop.
- Karten als Cloth-Vorhänge über der Strecke: keine Rückseite (immer zum Fahrer gebillboardet),
  Decks A–C durchgemischt, echte PDF-Grafik streamt progressiv während der Fahrt.
- Sechs Story-Modes als D6 (ein Wurf pro Fahrt) — färben Rails/Streams/Dome aus der kanonischen
  Print-Palette (S.16). Sechs Würfel hängen als Anker im Himmel (`DICE_IM_SKYDOME`).
- Tacho-Würfel (Cockpit als physisches Objekt), Skydome in drei Modi (Watercolor/Space/Shader).
- 4-Layer-Soundscape (bed/motion/event/space), pro Mode eine spektrale Identität.
- FrizzleBob-Pet reitet voraus (Augen gefixt: converge + Follow-Gaze, gebackene Augen-Schalen
  gestrippt via `face.stripEyes`).
- **FrizzleBob-Voice POC (Ebenen 0+1, kein LLM):** `frizzlebob-voice.v3.js`, Browser-TTS,
  Stimm-Scoring + Dropdown + Ducking. Reflex-Pool (Kurve/Drop/Mode) + Karten-`power`/`lore`.

## Erst lesen (Reihenfolge)

1. `docs/CHANGELOG_rollercoaster.md` — Kopf + die letzten drei v3-Einträge.
2. `docs/BACKLOG.md` — **§Strang B**, das ist die Roadmap (v4-Sprints B-v4.1 … B-v4.7).
3. `docs/HANDOVER_rollercoaster_v3.md` — Architektur, Drive-Bus, Contracts, Asset-Pipeline.
4. Die Briefs im `uploads/` zu den Sprints, die drankommen (Pfade stehen im Backlog pro Sprint).

## Wie hier gearbeitet wird (wichtig)

- **Erst kopieren:** v3 → `Rollercoaster Ride v4.dc.html` + `rollercoaster-ride.v4.js`.
  v3 nicht mehr anfassen (eingefroren).
- **Ein Wert, fünf Reaktionen:** alles hängt am **Drive-Bus** (`this.drive` = {v,a,c,j,p,mode…}),
  einmal pro Frame berechnet. Neue Features lesen den Bus, setzen kein eigenes Flag.
- **Prime Directive:** keine Fidget-Animationen, jede Bewegung ist Ritual/Interpunktion; alles
  degradiert weich (Ride hängt NIE an Stimme/Sound/GLB-Fetch/LLM). Stillstand ist still.
- **Contracts/Assets kommen per URL** vom KFB-GitHub (`RAW`-Konstante), Motion-/Pet-/Mode-Werte
  aus den Libraries lesen, **nicht neu tunen oder hart codieren** (z. B. `cardAspect` aus dem PDF).
- **Nach jedem Baustein:** Changelog-Eintrag, dann Review. Standalone bei Bedarf neu bündeln.

## Empfohlene v4-Reihenfolge (Vorschlag, Georg entscheidet)

1. **B-v4.1 Pet-Auswahl-Ring** — der Einstieg (Karussell, kein Track). Schaltet den Flow frei
   (Pet wählen → Fahrt) und nutzt alles frisch Validierte (12 Pets, Eye-Rig, Narrator-Archetypen).
2. **B-v4.5 Konsole = Kartenhand + Hebel** — diegetisches Interface (3 Steuerkarten + Holz-Hebel).
   ⚠ Der Kontroll-Würfel ist zurückgezogen. Der Hebel setzt `a` (Bremse/Rückwärts, B-v4.4).
3. **B-v4.6 Mienenspiel + Abstands-Regler** — Emotes als Werte (wandern+zittern), auf der Pet-Karte.
4. **B-v4.7 Takt & Trommeln** — Lookahead-Scheduler, Dichte statt Tempo; danach Ebene 2 (LLM).

Nicht alles auf einmal. Ein Sprint, ein Review, dann der nächste.

## Offene Design-Entscheidungen für Georg

- Wie öffnen sich die Konsolen-Karten (aufklappen/hochschieben/vorziehen)? Hebel rechts-außen
  oder rechts-unten (Kollision mit Pet auf Regler-0)?
- Zählt eine rückwärts zweimal gelesene Karte als ein Ereignis oder zwei (Session-NDJSON)?
- Ghost-Note/Betonung auf Schlag 3 (Kishōtenketsu-Wendung) — trägt es am Ohr?

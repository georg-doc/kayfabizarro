# SPRINT — KFB Travel v7 · Klang, Sky-Karten, Flugziele

**Lebendes Dokument.** Status wird HIER gepflegt, nicht im Code. Jede Runde (auch in einem frischen
Chat) trägt ihr Ergebnis ein und schreibt eine Zeile in `docs/CHANGELOG_travel.md`.

- **Entry:** `KFB Travel v7.dc.html` → `terrain-v7/travel-poc.js` (18 Dateien)
- **Vorgänger:** `KFB Travel v6.dc.html` / `terrain-v6/` — **FROZEN**, nicht mehr anfassen
  (Snapshot: `export/travel-v6_2026-07-25/`, Beleg-Sprintplan: `docs/SPRINT_travel-v6.md`)
- **Quellen für v7:** `rollercoaster-v11/rollercoaster-ride.v11.js` (Audio, Curtain, Portal) ·
  `KFB TinySkies Analyse.dc.html` (Flug-Sounddesign, Regen) · `docs/SPRINT_travel-v5.md`
  (Grundrisse S3–S6, S9, S12)

---

## Was ein frischer Chat zuerst lesen muss

1. Diese Datei (Status + der eine Slice, der dran ist).
2. `docs/SPRINT_travel-v6.md`, Abschnitt „Arbeitsweise" (das Golden Sample) und die neun Regeln im
   `MANIFEST.md` des v6-Snapshots. Sie gelten alle weiter.
3. `terrain-v7/travel-poc.js` (Runner, Render-Reihenfolge) und das Modul, das der Slice anfasst.

**Render-Reihenfolge (Kanon):** Szene → `post.render()` → `lines.render()` → `hud.render()`.

**Drei Regeln, die beim Fork v6→v7 dazukamen:**
- **Ein Schatten auf einer nicht-durchgehenden Fläche gehört in den Shader der Fläche**, nicht auf ein
  Quad davor. Der Terrain-Shader projiziert Werfer selbst (`setCasters`); das Quad bleibt nur für die
  Karte (durchgehende Fläche).
- **Die Versionsnummer gehört dem Runner.** Das Overlay bekommt sie als `eyebrow` übergeben; ein
  Modul mit hartkodierter Version lügt beim nächsten Fork (passiert jetzt zweimal).
- **Kamera:** `escapeTerrain()` ist die letzte Instanz gegen „Kamera im Cube" — Höhenfeld aus vollen
  Säulen, also garantiert draußen, sobald sie über der Säulenoberkante ist. Wer neue Kamera-Modi baut,
  ruft sie als LETZTES auf, nach allen Deckeln und Korrekturen.

## Status

| # | Slice | Status | Datei(en) | Runde |
|---|---|---|---|---|
| S20 | **Audio I: Jukebox + Drone aus Rollercoaster v11** | **✅ erledigt** | `travel-audio.js` (neu), `jukebox.json`, `travel-poc.js` | 2026-07-25 |
| S21 | **Audio II: Flug-Sounddesign + Event-SFX** | **✅ erledigt** (Dateien folgen als Daten) | `travel-audio.js`, `sfx.json`, `pet-kinetics.js` | 2026-07-25 |
| S22 | **Sky-Karten: Portal + Curtain, als Flugziele** | offen (der große v7-Slice) | `sky-cards.js` (neu), `world-context.js` | — |
| S23 | **YouTube-Video als sphärischer Skydome** | offen (Georgs Wunsch) | `skydome-shader.js` oder eigenes Modul | — |
| S24 | **Musikvideo ↔ Dancefloor gekoppelt** (Beat, Stille, Flows) | offen (nach S23 + S20) | `travel-audio.js`, `voxel-terrain.js` | — |
| S25 | **UI-Sounddesign aus dem Kenney-Set** | offen (klein) | `travel-audio.js`, `settings-overlay.js`, `hud-cube.js` | — |
| S19 | Wasserfarb-Wellen (Tropfen-Ringe im Terrain) | offen | `voxel-terrain.js`, Event-Bus | — |
| S3 | Rim-Light auf Pet, Karte, Cubes | offen | `rim-light.js` (neu) | — |
| S4 | Staub- & Splitter-Pool | offen | `fx-pool.js` (neu) | — |
| S5 | Story-Presets konsolidieren | offen (Voraussetzung für S16) | `world-context.js`, `skydome-shader.js` | — |
| S12 | Würfel v2 Teil 2 (ALLCAPS raus, Abnutzung, Pet-Farbe) | **geparkt** (wartet auf Georgs PNGs) | `hud-cube.js` | — |
| S16 | Tag/Nacht-Wechsel | offen (nach S5) | `skydome-shader.js`, `world-context.js` | — |
| S6 | Portal-Swirl als Modus-Tor | offen | `mode-portal.js` (neu) | — |
| S9 | Monitor-Würfel: Embeds (YouTube / Demo / Chat) | offen | `hud-cube.js`, DOM-Overlay | — |
| S17 | Regen & Wirbelstürme | offen (später) | eigene Module | — |
| S13 | Beams / Leuchtturm-Karten / Selective Bloom | offen (später) | eigene Module | — |
| — | **Karten-getriebenes Terrain** (CardTriplet → Welt) | offen — **eigener Sprint** | `world-context.js`, Runner | — |

Status-Vokabular: `offen` · `in Arbeit` · `✅ erledigt` · `geparkt (Grund)`.

---

## S20 · Audio I: Jukebox + Drone (Grundriss)

**Alles liegt schon gebaut in `rollercoaster-v11/rollercoaster-ride.v11.js`** — übernehmen, nicht neu
erfinden. Die Teile:

| Was | Wo | Kern |
|---|---|---|
| **Mood-Matrix** | `AUDIO_MOODS` (Zeile ~79) | ein Datensatz je Story-Mode: `root`, `ratios`, `type`, `detune`, `bright`, `rev`, `pulse`, `air`. Ein Mood = eine spektrale Identität |
| **4-Ebenen-Soundscape** | `startAudio()` | bed/drone · motion (Wind an der Geschwindigkeit) · event (Turn/Jerk/Karte) · space (Reverb + die sechs Würfel als gerichtete Quellen) |
| **Jukebox** | `loadJukebox()`, `assets/jukebox.json` | RAW-first, lokaler Fallback, hartkodierter Default (Van Metronome, 104 BPM) — der Ride steht nie ohne Musik da |
| **Takt-Uhr** | `_beatFreq()` | 1 Takt = 4 Beats, `f = 2π/(60/bpm·4)`. **Die Uhr hängt am AudioContext, nie am Track** |
| **Ducking** | `voice.onActivity` | Drone tritt zurück, wenn das Pet spricht |

**Der eigentliche Gewinn für Travel:** unser Takt ist heute **synthetisch** (`synthPhase`, `bpm 104`
als Zahl im Runner). Mit S20 wird die Beat-Uhr echt — und der Dancefloor-Modus, die Cube-Hübe und das
Blinken hängen an der Musik, die man hört. Das ist genau die Kopplung, die Georg testen will.

**Grundriss.** Ein Modul `travel-audio.js` mit der Modul-Disziplin des Rests
(`update(dt, …)` · `reset()` · `dispose()`), das den 4-Ebenen-Graph aus v11 aufbaut und drei Ausgänge
liefert: `beat` (0..1, Impuls auf die Eins), `bpm`, `level` (Musik-Pegel für Blink-Kopplung).
Der Runner ersetzt seinen synthetischen Takt damit — **eine Quelle, kein zweites System.**
`travelHeat` speist die motion-Ebene (Wind ∝ Tempo, Cutoff ∝ Beschleunigung).

**Zu beachten (aus v11 teuer gelernt):** Audio braucht eine Nutzergeste zum Start (Autoplay-Policy) →
ein Ton-an-Schalter im Overlay, der beim ersten Klick `ctx.resume()` fährt. Und: Reverb-Send **post**
Fader, sonst hört man den Hall noch, wenn der Regler auf 0 steht.

**Akzeptanz.** Musik läuft, BPM steuert die Cube-Uhr messbar (Beat-Impuls im Bild sichtbar), Regler
für Musik/Drone/FX getrennt, Ton-aus ist wirklich still, kein Frame-Einbruch beim Start.

## S20 · Audio I — ✅ erledigt 2026-07-25

Gebaut wie im Grundriss unten. Drei Dinge, die dabei zählten:
1. **Ein Takt-Ausgang.** `audio.beat` ersetzt den synthetischen Takt, wenn Ton läuft; ohne Ton
   greift der Fallback. Kein zweites System.
2. **Der rohe Bass-Pegel ist kein Beat** — gemastert steht er dauerhaft bei ~0,68. Gekoppelt wird der
   Ausschlag über dem langsamen Mittel (Onset). Gemessen: `uBeat` pulst 0,28…0,61.
3. **Mood-Wechsel live**, ohne Graph-Rebuild (Wellenform, Partiale und Filter per
   `setTargetAtTime`) — ein Story-Wechsel darf nicht knacken.
4. **Zwei Audio-Regeln, teuer gelernt:** `ctx.resume()` gehört in `start()` UND in jede Nutzergeste
   (ein Context kommt suspendiert hoch und kann später wieder suspendieren). Und: **gaten auf „Uhr
   läuft", nie auf „Objekt existiert"** — sonst verwirft man den funktionierenden Fallback für die
   ganze Sitzung. Gilt für jedes künftige System mit Fallback, nicht nur für Audio.
5. **Testen über den echten Bedienweg.** Der Slice war über `audio.start()` grün und über den
   Overlay-Schalter tot. Wer nur die API testet, testet die Hälfte.

Gemessen: zehn Tracks aus dem RAW-Manifest, Van Metronome 104 BPM spielt, Pegel 0,68.
Regler in „Klang & Rhythmus": Ton an · Track · Musik · Drone · Fahrtwind · FX · Tempo (ohne Ton) ·
Beat-Kopplung · Live-Anzeige.

## S21 · Audio II: Flug-Sounddesign + Event-SFX (Grundriss)

Aufbauend auf S20: Fahrtwind an `heat`, Boost-Whoosh am Boost-Impuls, Landungs-Thud am `impact` des
Walk-Controllers, Sprung-Pop, Karten-Durchflug-SFX (kommt mit S22). Georg liefert Dateien über
GitHub (ElevenLabs-Prompts kommen von hier) — bis dahin bleibt alles synthetisch aus dem v11-Graph.
**Ein Event-Bus, nicht sechs Verdrahtungen:** dieselbe `drop()`-artige Schnittstelle, die S19 für
die Wasserfarb-Wellen braucht, trägt auch die SFX-Trigger.

## S21 · Audio II — ✅ erledigt 2026-07-25

Böen (langsamer Zufallsgang) + Rumpeln (zweite Rauschschicht, lauter nah am Boden) + Schritte am
Gehzyklus (`petKin.stepCount`, gemessen 5 Tritte in 1,8 s) + Roll-Swish über die Stereobreite.
**Kern des Slices ist die Registry:** `sfx(id)` nimmt eine echte Datei, wenn sie im Manifest steht
(`media/3D_Assets/Audio/sfx.json`, RAW-first, lokaler Fallback `terrain-v7/sfx.json`), sonst den
synthetischen Einsatz — nie Stille. Ids: `boost` `land` `jump` `step` `roll` `card`.
Form: `{ file | variants[], gain, rate, jitter }`. **Dateien einzuhängen ist damit Daten, nicht Code.**

## Zwei Messregeln, die diese Runde dazukamen

1. **Nur in der SICHTBAREN Ansicht messen.** In einem hidden Preview feuert `requestAnimationFrame`
   nicht; der Frame-Zähler steht still und sieht wie ein toter Render-Loop aus. `document.hidden`
   prüfen, bevor man eine Bildrate glaubt.
2. **Ein Auftrag, der nie zurückkommt, ist der Standardfehler in asynchronen Pipelines.** Wer ein
   `busy`-Flag oder einen `'pending'`-Zustand setzt, braucht beides: einen Watchdog, der freigibt,
   und einen Fehler-Rückweg zum Aufrufer. Ohne das schaltet ein einzelner hängender Job den Slice für
   die ganze Sitzung ab — lautlos.
3. **`renderer.info.render` zeigt nur den LETZTEN Pass.** Mit Post-Processing sind das die 6 Calls
   des Bildschirm-Quads, nicht die Welt. Wer Draw-Calls zählen will, misst vor dem Post-Pass.

## S23b · YouTube-Video als sphärischer Skydome (Grundriss, Georgs Wunsch 2026-07-25)

**Was gefragt ist:** URL-Eingabe → das Video füllt als gebogene Kuppel den Himmel und wandert mit der
Kamera, so wie der Skydome heute.

**Der Haken, den man vorher wissen muss:** ein YouTube-`<iframe>` ist **kein** WebGL-Textur-Quelle —
CORS und DRM verbieten `texImage2D` aus fremden Videoframes. Zwei ehrliche Wege:
1. **DOM-Kuppel (empfohlen für YouTube):** das iframe liegt HINTER dem Canvas, per CSS-3D leicht
   gewölbt (`perspective` + `rotateX`), und der Skydome-Shader wird für den Himmelsanteil
   transparent geschaltet. Kostet nichts, echte YouTube-Wiedergabe, aber keine echte Kugel und kein
   Zugriff auf Pixel (also keine Farbkopplung ans Terrain).
2. **Echte Videotextur (für eigene Dateien):** ein `<video>` mit gleicher Herkunft oder CORS-Freigabe
   → `THREE.VideoTexture` in den bestehenden Dome. Dann stimmt die Biegung, und die Pixel sind
   lesbar (Farbe → Palette, Helligkeit → Beat). Für YouTube-Inhalte heißt das: Datei ins Repo.
**Empfehlung:** beides bauen, aber die Videotextur ist der Weg, der S24 möglich macht.

## S24 · Musikvideo ↔ Dancefloor (Grundriss)

Ziel ist nicht ein Beat-Meter, sondern **Musikalität**: Beat, Stille, Auf- und Abbau. Die Bausteine
liegen: `travel-audio` hat Analyser, Onset (`pulse`) und Takt-Uhr; das Terrain hat getrennte Kanäle
für Tanz und Blinken plus den Flow-Modus. Was fehlt, ist eine **Dynamik-Auskunft**: gleitender
Kurzzeit- gegen Langzeitpegel → `build` (Aufbau), `drop` (Einsatz), `silence` (Pause). Daran hängen
dann Muster statt Zappeln: Stille → Flow, Aufbau → Amplitude steigt, Drop → Dancefloor + Blinken.
Läuft das Video als echte Textur (S23 Weg 2), kann seine Helligkeit denselben Kanal speisen — Bild
und Boden pulsen dann gemeinsam, nicht nur beide zur Musik.

## S25 · UI-Sounddesign aus dem Kenney-Set (Grundriss)

Georgs Set liegt schon im Repo: `media/3D_Assets/Audio/`. Die Registry aus S21 nimmt es ohne
Codeänderung; nötig sind nur Ids für die Oberfläche (`ui-open`, `ui-close`, `ui-tick`, `ui-toggle`,
`cube-spin`, `cube-snap`) und je ein Aufruf an den drei Stellen, die sie auslösen: Overlay,
Regler, HUD-Würfel. Klein, aber erst sinnvoll, wenn die Lautstärke-Staffel steht (UI leiser als Welt).

## S22 · Sky-Karten: Portal + Curtain, als Flugziele (der große v7-Slice)

**Was aus v11 kommt** (`rollercoaster-ride.v11.js`):
- **`class Curtain`** (Zeile ~414): der three.js-Cloth (`webgl_animation_cloth`) als Block portiert,
  läuft in „sim units" und wird über `mesh.scale` in die Welt skaliert — **die Gravitations- und
  Windkonstanten des Beispiels bleiben damit unverändert gültig**. `setWind(s)` bekommt den
  Fahrtwind, nicht einen Sinus. Billboard zur Kamera (Karten haben keine Rückseite).
- **Portal-Auflösung** (`portalAlphaTex()`, `setDissolve(k)`): eine geteilte AlphaMap (radial-ovaler
  Gradient + Value-Noise) plus **steigender `alphaTest`** — frisst die Mitte zuerst, irreguläre
  Kante aus dem Noise. Null CPU, rückwärts derselbe Shader.
- **Kartenformat als EINE Zahl** (`KFB_CARD_AR = 1.79`), gemessen statt geraten.

**Was in Travel neu dazukommt** (und der Grund, warum es ein eigener Slice ist): in v11 hängen die
Vorhänge an einer **Schiene** (`curve.getPointAt(t)`) — bei uns gibt es keine Schiene. Die Karten
müssen im Himmel **verteilt** werden (Anchor-Punkte kann `world-context.js` schon erzeugen, es
rendert sie nur niemand) und als **Ziel** taugen: Sichtbarkeit über Distanz, ein Auto-Pilot, der die
Karte anfliegt (Kurs- und Höhen-Regler auf den Flight-Controller, kein Teleport), Kollisionsfenster
beim Durchflug, Durchflug-Ereignis → Story-Wechsel + SFX + Portal-Auflösung.

**Reihenfolge im Slice:** (1) Karten im Himmel platzieren und billboarden · (2) Durchflug erkennen ·
(3) Cloth + Portal-Auflösung anschließen · (4) Auto-Pilot · (5) Ereignis verdrahten (Story, Audio).
Nach (2) ist es schon spielbar — dort einen Zwischenstand zeigen, nicht erst am Ende.

**Warnung aus v11:** Kollision und Animation waren dort „ganz gut, muss noch optimiert werden".
Der Cloth kostet CPU pro Vorhang (Verlet-Solver). Für Travel heißt das: **nur die nächste Karte
simuliert Cloth**, alle anderen bleiben flache Quads mit derselben Textur. Der Umschaltpunkt ist eine
Distanzschwelle, kein Rebuild.

## Warten auf Georg

- **PNG-Set für die Würfelseiten** → `media/kfb/hud/`. Erst damit trägt S12.
- **`edge3.jpg` ins Repo** (`media/3D_Assets/Textures/`).
- **Sound-Dateien** (ElevenLabs) für S21, plus die Entscheidung, welche Tracks in `jukebox.json`.
- **Ink-Outline-Stile Torn und Bend** (`kfb-ink.js`) → `PERIMETER`/`STROKE` in `card-carrier.js`.
- **Bundle-Matrix** (greet/notice/celebrate/sleep an Travel-Events) mit dem Coworker.

## Nicht wieder vorschlagen

Quaternion-Kugelwelt · Partikel-Vortex am Booster · Multiplayer/Upgrades/HP-Balken/Quests ·
WebGPU-Portierung (Travel läuft WebGL2, der Effekt-Gewinn ist kein Backend-Wechsel wert).

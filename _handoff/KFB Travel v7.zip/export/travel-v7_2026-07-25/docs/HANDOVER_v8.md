# HANDOVER v8 — Partikel-Tuning „in Action" (Test v1 → Ride)

**Stand:** 2026-07-19 · Session v8-Cut · Autor: Claude (für Coworker/Lead)
**Dateien neu:** `Rollercoaster Ride v8.dc.html` + `rollercoaster-ride.v8.js`
**Basis:** 1:1-Kopie von v7, dann fokussierter Partikel-Patch. v7 ist ab jetzt **FROZEN**.

---

## 1. Worum es geht (TL;DR)

Die im **KFB Particle Test v1** ertunte Lieblings-Config (COSMIC-Palette, HDR 6,
bloom 2.1/0.5/0.24) und die Erkenntnisse aus dem **KFB Particle Academy**-Exkurs
sind jetzt **in der laufenden Ride** verbaut — nicht mehr nur im Standalone-Sandbox.

Kern-Erkenntnis (unverändert seit v7-Postmortem, jetzt konsequent umgesetzt):
> Sichtbarkeit gewinnt man durch **Dichte + Additive-Blending + weiche Sprites +
> heiße Kerne (>1) die Bloom füttern** — NICHT durch rohe Punktgröße oder globales HDR-Überstrahlen.
> Dunkler BG + ACES-Tonemapping + Bloom nur aus echten HDR-Kernen = der „Liga"-Sprung.

---

## 2. Verlauf & aktueller Stand (WICHTIG)

**v8 ist auf v7-Bloom-Niveau zurückstabilisiert.** Der aggressive Test-v1-Bloom ließ sich global
NICHT in die Ride heben, ohne 3D-Geometrie mitzureissen — zwei dokumentierte Fehlversuche:

1. `bloom(col, 2.1, 0.5, 0.42)` → **Karte blutete komplett aus** (Threshold zu tief).
2. `bloom(col, 2.1, 0.5, 1.0)` → Karte gerettet, aber **Augen (glossy-googly Specular) + Würfel-
   flächen brennen weiter** — und die gewünschten Partikel-Effekte gehen im Kollateral unter.

**Erkenntnis (der eigentliche Kern):** Global-Bloom ist das falsche Werkzeug. Es greift ALLES >
Schwelle — Partikel-Kerne UND Pet-Specular UND belichtete Flächen UND Karten-Highlights. Die
Academy-Regel „Bloom nur aus Hot-Cores >1" gilt nur, wenn sonst nichts im Bild >1 ist; ein
belichtetes 3D-Pet mit Glanzaugen verletzt das per Definition. **Der echte Partikel-Glow in-Ride
braucht Selective/Emissive-Bloom (MRT)** — eigener Sprint, s. `docs/SPRINT_KICKOFF_selective-bloom.md`.

### Aktuell aktiv in v8 (nach Stabilisierung)
| Stelle | Wert | Status |
|---|---|---|
| Bloom-Pipeline (2×) | `bloom(col, 0.8, 0.2, 0.85)` | **v7-sicher** (kein Ausbrennen) |
| Orbit-Stream Hot-Core | `vec3(1.7,1.6,1.35)` | zurück auf v7 |
| Beat-Aura Funken | `vec3(1.8,1.7,1.4)` | zurück auf v7 |
| Orbit-Stream Palette | COSMIC `[0x8a5cff,0xb98cff,0xffc2a0,0xffa575]` | **behalten** (Bloom-unabhängig, Vorrat für Selective-Bloom-Sprint; wird aktuell vom Gold-uModeCol-Tint 0.45 überlagert) |

**Bewusst NICHT geändert:** Größen/Attenuation/Counts/Turbulenz/Flow-Kopplung, Physik, HUD, Sky, Pet-Rig, Contracts = identisch zu v7.

---

## 3. Wie prüfen (Clean-Run v8)

1. `Rollercoaster Ride v8.dc.html` öffnen → Pet-Select bootet, Pet wählen → Ride bootet.
2. Space/Shader-Mode: Bloom läuft v7-sicher — **nichts brennt aus** (Karte, Augen, Würfel lesbar/sauber).
3. Der große Partikel-Glow ist bewusst NOCH NICHT da → kommt mit dem Selective-Bloom-Sprint.
4. `?dev` → FPS/DRAWS/TRIS: keine neuen Draw-Calls ggüber v7.

---

## 4. Offen / Fine-Tuning-Kandidaten (nach diesem Cut)

- **Threshold mode-aware machen:** 1.0 schützt die Karte immer. In reinen Space-Modi (kein Karten-
  Lesen im Fokus) ließe sich testweise runter Richtung 0.6 für mehr Nebula-Milch — ABER nur wenn die
  Karte gerade nicht groß im Bild steht. Aktuell EIN globaler, sicherer Wert (KISS).
- **COSMIC auch auf Rad-Funken-Duo?** Aktuell nutzen Funken Pet-Farbe↔Mode-Farbe. Optional COSMIC-Tint.
- **Skydome Hypno-Spiral** (Georgs BACKLOG-Idee) bleibt eigener Sprint.

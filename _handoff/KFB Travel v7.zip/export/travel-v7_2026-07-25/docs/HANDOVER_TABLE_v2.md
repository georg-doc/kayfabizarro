# Handover — KFB Table v2 → frischer Design-Chat

**Stand 2026-07-12.** Ersetzt `HANDOVER_TABLE_v1.md` als Einstieg. Lies zuerst `uploads/START_HERE_table.md` (Prime Directive!), dann dies, dann `docs/BACKLOG.md`.

## Was existiert

`KFB Table v2.dc.html` + `kfb-table.v2.js` — eingecheckt, Default-Look **cel**. Ein `<kfb-table>`-Web-Component (three.js + pdf.js via CDN-ESM, kein Build). Details: `docs/CHANGELOG.md` (v2-Eintrag inkl. Outline-Post-Mortem).

**Der Slice spielt sich:** Draw (3→4) → Story-Mode-Roll (Mood-Wash) → Play (Show it · Spin it · Sell it in Scene 1–3) → Tell (Spotlight-Blase, spieler-getaktet) → Calls (BINGO/BOGGLE/BONGO/BLÖDSINN) → Verdict (+2/+1/±0/−1 auf der Quest-Treppe) → König rotiert. Quest-Finale: Gold-Ritual; unter 1: Schnipsel + Würfel fällt.

## Architektur-Landkarte (kfb-table.v2.js)

- **Texturen:** `_cardFaceTexture(n)` (pdf.js, COVER_OFFSET=1, 2×2-Quadranten-Crop, 15-s-Timeout → Platzhalter + `_retryTex`-Hintergrund-Swap) · prozedurale Canvas-Texturen (Matte mit Irish-Grover-Wortmarke, Holz, Rückseite=Platzhalter §11.3)
- **Look-System:** `_surfMat` (Toon ↔ Standard, `shadowSide` DoubleSide), `_applyLookSwap`, EIN Key-Light wirft Schatten (PCF, 4096, Ortho über Tisch+Wand)
- **Outlines:** `_shaderHull(mesh, base)` — Normal-Offset-BackSide-Hull, Licht-Gewichtung + downCut; SkinnedMesh-Support via `bind()`. Scheren/Tuschefass bewusst `hull: false`. **Lies das Post-Mortem im CHANGELOG, bevor du Outlines anfasst.**
- **Ink-Panels (DOM):** `inkPathD`/`_inkify(el, seed, tailX, fill, stroke)` — wellige Pfade, exakte Ecken, Tail im Pfad; Cache über `el._inkKey`; NIE skalieren, immer neu zeichnen (Höhenänderung → re-inkify!)
- **Blasen-Regeln:** Eine Blase zur Zeit; Tooltip 280-ms-Debounce, Auto-Hide 4,5 s, fester Welt-Anker, Tail nur wenn Blase über dem Anker
- **Turn-Flow:** `_setPhase` (REST→…→MOVE), `PHASE_HINTS`, Finger-Rule = goldenes Karten-Highlight (`_setBeat`) — **das gold-braune Outline der Actor-Karte ist der Beat-1-Highlight-State, kein Bug**
- **Wand:** `_buildWall` (Shell, Fenster-Parallax, Galerie, `_enterViewer` PDF-Close-up mit Pager), `setSurface(name, url)` für 4 Flächen (Bild/mp4/webm; YouTube braucht CSS3D → Backlog)
- **FB-Menü:** `_fbMenu` / `_autoPlay`; „Select Decks" ist Stub → Backlog P1.1

## Guardrails (unverändert, aus v1 gelernt)

1. **Social Agency:** jede Animation ist Ritual, nie Fidget. Kein Idle-Bobbing.
2. **Blase = Cue, kein Skript.**
3. **Visuell verifizieren (Screenshot) vor „fertig".** Achtung: das Agent-Preview-iframe kann pdf.js-Worker drosseln (Boot zeigt dann Platzhalter — beim User lädt es; `eval_js_user_view` zum Gegencheck).
4. Ink-Panels nie stretchen — bei Größenänderung `_inkify` erneut aufrufen.
5. GLB-Hulls: Welt-Skalierung pro Mesh (`getWorldScale`), sonst schwarze Riesenflächen.

## Nächste Schritte

`docs/BACKLOG.md` — P1: Deck-Switch (GitHub-Multi-Deck), State-Loop-Feinschliff, kanonische S.16-Hex. Danach Outline-Phase-3 (Screen-Space) und FrizzleBob-Ausbau (Voice).

// ============================================================================
// card-carrier.js — KFB Travel v4 · CardRig (the Pet's flying card)
// ----------------------------------------------------------------------------
// Canonical VISUAL embodiment of the vehicle (003_CardRig): the Pet rides ON a
// light 3D card — a subdivided thin plate (PlaneGeometry ~10×14 segments) with
// the card-back texture + ONE ink outline. NOT flat 2D (feet would poke).
//
// Ink outline = KFB Ink Outline Style v1 canon (SSOT: KFB_INK_OUTLINE_STYLE_v1 +
// kfb-ink.js). Style `inked` (default): inkPerimeter (segments ~34px, corners
// FIXED, ±jit on intermediate points) + drawInkOutline uniform (baseW modulated
// by a SMOOTHED low-freq wobble over a 2nd seed). Deterministic (mulberry, one
// seed/card), size-honest (drawn at real px), colour #1f1a14. Drawn on a 2D
// canvas → renderer-independent → used directly as a WebGL texture.
//
// STIL-HOOK (2026-07-25): die Outline wird über `createCardSurface` gemalt und ist
// zur Laufzeit nachstellbar (`rig.setInk({ width, wobble, jitter })`) — das Bild wird
// EINMAL geholt und danach nur noch neu übermalt, ein Regler löst also keinen
// Netzverkehr aus. Die zwei Funktionen `PERIMETER[style]` und `STROKE[style]` sind der
// Platz für Georgs weitere Stile (`torn` = zackig, `bend` = flaggenartig): ein
// Tabelleneintrag, kein Umbau. Bis die Kanon-Dateien vorliegen ist nur `inked` belegt.
//
// Ownership (003): presentation only — seat, visual lean, hover, waver, squash.
// Never moves the vehicle: copies its world transform, adds visual offsets.
//
//   const rig = createCardCarrier({ THREE, assetBase });
//   rig.group → scene;  rig.seat → pet.object3D
//   rig.sync(vehicleState, dt, petChar)   // once per frame, AFTER pet.update
//   rig.kick(a)                            // squash impulse (+ stretch / − duck)
// ============================================================================

const INK = '#1f1a14';

function mulberry(a) { return function () { a |= 0; a = (a + 0x6D2B79F5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }

// inkPerimeter — walk the 4 rect edges, ~34px segments, jitter intermediate points, corners fixed.
function inkPerimeter(x0, y0, x1, y1, seed, jit) {
  const rnd = mulberry(seed), pts = [];
  const corners = [[x0, y0], [x1, y0], [x1, y1], [x0, y1]];
  for (let c = 0; c < 4; c++) {
    const a = corners[c], b = corners[(c + 1) % 4];
    const len = Math.hypot(b[0] - a[0], b[1] - a[1]);
    const n = Math.max(3, Math.round(len / 34));
    for (let i = 0; i < n; i++) {
      const u = i / n, corner = i === 0;   // corners fixed → closed, no gap
      pts.push([a[0] + (b[0] - a[0]) * u + (corner ? 0 : (rnd() - 0.5) * 2 * jit),
                a[1] + (b[1] - a[1]) * u + (corner ? 0 : (rnd() - 0.5) * 2 * jit)]);
    }
  }
  return pts;
}
function pathOf(g, pts) { g.beginPath(); g.moveTo(pts[0][0], pts[0][1]); for (let i = 1; i < pts.length; i++) g.lineTo(pts[i][0], pts[i][1]); g.closePath(); }
// drawInkOutline inked: uniform baseW modulated by a smoothed low-freq wobble (2nd seed).
function drawInkOutline(g, pts, seed, baseW, wob) {
  const rnd = mulberry((seed ^ 0x9e37) >>> 0), N = pts.length, raw = [];
  for (let i = 0; i < N; i++) raw.push(rnd());
  const sm = (i) => (raw[(i - 1 + N) % N] + 2 * raw[i] + raw[(i + 1) % N]) * 0.25;
  g.lineJoin = 'round'; g.lineCap = 'round'; g.strokeStyle = INK;
  for (let i = 0; i < N; i++) {
    const a = pts[i], b = pts[(i + 1) % N];
    g.lineWidth = baseW * (1 + wob * (sm(i) - 0.5) * 2);
    g.beginPath(); g.moveTo(a[0], a[1]); g.lineTo(b[0], b[1]); g.stroke();
  }
}

// lively spring with slight overshoot: x eased toward target, velocity damped.
function spring(cur, target, stiff, damp, dt) {
  cur.v += (target - cur.x) * stiff * dt;
  cur.v *= Math.pow(damp, dt * 60);
  cur.x += cur.v * dt;
}

// Stil-Tabellen: EIN Eintrag pro Ink-Outline-Stil. `inked` ist der Kanon aus v1;
// `torn` und `bend` warten auf die Kanon-Dateien (dann hier eintragen, sonst nichts).
const PERIMETER = { inked: inkPerimeter };
const STROKE = { inked: drawInkOutline };

// createCardSurface — malt Papier + Kartenbild + Ink-Outline in EIN Canvas und hält das
// geladene Bild fest, damit `setInk()` nur neu übermalt (kein zweiter Netzabruf).
function createCardSurface(THREE, url, seed, opts) {
  const W = 800, H = 447, m = 14;
  const P = Object.assign({ style: 'inked', width: 6, wobble: 0.5, jitter: 4 }, opts || {});
  const c = document.createElement('canvas'); c.width = W; c.height = H;
  const g = c.getContext('2d');
  let bmp = null;
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace; tex.anisotropy = 8;

  function repaint() {
    const per = PERIMETER[P.style] || inkPerimeter, stroke = STROKE[P.style] || drawInkOutline;
    const pts = per(m, m, W - m, H - m, seed, P.jitter);
    g.clearRect(0, 0, W, H);
    g.fillStyle = '#efe6d0'; pathOf(g, pts); g.fill();      // Papier (blitzt nie transparent)
    if (bmp) { g.save(); pathOf(g, pts); g.clip(); g.drawImage(bmp, 0, 0, W, H); g.restore(); }
    if (P.width > 0.05) stroke(g, pts, seed, P.width, P.wobble);
    tex.needsUpdate = true;
  }
  repaint();
  fetch(url).then((r) => r.blob()).then(createImageBitmap).then((b) => { bmp = b; repaint(); }).catch(() => {});

  return {
    texture: tex, params: P,
    setInk(next) { Object.assign(P, next || {}); repaint(); },
  };
}

export function createCardCarrier(opts = {}) {
  const THREE = opts.THREE;
  // Pfad-Hygiene (session-export §6): Assets laufen über die kanonische RAW-URL.
  const assetBase = opts.assetBase || 'https://raw.githubusercontent.com/georg-doc/kayfabizarro/main/media/kfb/';
  const CW = opts.width || 3.0, CD = CW * 447 / 800;
  const SEGX = 10, SEGZ = 14;

  const group = new THREE.Group();   // vehicle-driven world transform
  const lean = new THREE.Group();    // CardRig visual lean (springs)
  group.add(lean);

  const topGeo = new THREE.PlaneGeometry(CW, CD, SEGX, SEGZ);
  topGeo.rotateX(-Math.PI / 2);
  const basePos = topGeo.attributes.position.array.slice();
  const topMat = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.9, metalness: 0, side: THREE.DoubleSide, emissive: 0x000000 });
  const top = new THREE.Mesh(topGeo, topMat);
  top.castShadow = true; top.receiveShadow = false;   // no self-shadow (that acne was the boost "black flashes")
  lean.add(top);

  // --- SOLID SLAB: thin card with real thickness. Top = lit card face; bottom = SAME card back
  // (unlit MeshBasic so it never renders black from below); skirt = thin dark rim. Bottom + skirt
  // are rebuilt from the top rim EVERY frame → one bending object, no gap, edges curl freely. ---
  const TH = 0.055;                                  // ~1/3 of the old thickness (was a card-stack)
  const nx = SEGX + 1;
  const perim = [];
  for (let ix = 0; ix < SEGX; ix++) perim.push(0 * nx + ix);            // front row
  for (let iy = 0; iy < SEGZ; iy++) perim.push(iy * nx + SEGX);          // right col
  for (let ix = SEGX; ix > 0; ix--) perim.push(SEGZ * nx + ix);          // back row
  for (let iy = SEGZ; iy > 0; iy--) perim.push(iy * nx + 0);            // left col
  const M = perim.length;
  // bottom face: clone of the top grid, unlit card texture, always visible (never black)
  const botGeo = topGeo.clone();
  const botMat = new THREE.MeshBasicMaterial({ color: 0xffffff, side: THREE.DoubleSide });
  const bottom = new THREE.Mesh(botGeo, botMat); bottom.castShadow = false; bottom.receiveShadow = false; lean.add(bottom);
  // skirt: thin dark rim, 2*M verts (top ring + bottom ring), M quads
  const darkMat = new THREE.MeshStandardMaterial({ color: 0x2a2018, roughness: 0.95, metalness: 0, side: THREE.DoubleSide });
  const skirtPos = new Float32Array(2 * M * 3);
  const skirtGeo = new THREE.BufferGeometry();
  skirtGeo.setAttribute('position', new THREE.BufferAttribute(skirtPos, 3));
  { const idx = []; for (let i = 0; i < M; i++) { const a = 2 * i, b = 2 * ((i + 1) % M); idx.push(a, a + 1, b + 1, a, b + 1, b); } skirtGeo.setIndex(idx); }
  const skirt = new THREE.Mesh(skirtGeo, darkMat); skirt.castShadow = true; skirt.receiveShadow = false; lean.add(skirt);

  function rebuildSlab() {
    const a = topGeo.attributes.position.array;
    const bp = botGeo.attributes.position.array;
    for (let i = 0; i < a.length; i += 3) { bp[i] = a[i]; bp[i + 1] = a[i + 1] - TH; bp[i + 2] = a[i + 2]; }   // bottom hugs top, offset down
    botGeo.attributes.position.needsUpdate = true;
    for (let i = 0; i < M; i++) {
      const t = perim[i] * 3, x = a[t], y = a[t + 1], z = a[t + 2];
      skirtPos[6 * i] = x; skirtPos[6 * i + 1] = y; skirtPos[6 * i + 2] = z;                 // top ring
      skirtPos[6 * i + 3] = x; skirtPos[6 * i + 4] = y - TH; skirtPos[6 * i + 5] = z;         // bottom ring
    }
    skirtGeo.attributes.position.needsUpdate = true; skirtGeo.computeVertexNormals();
  }

  const seat = new THREE.Group();
  seat.position.set(0, 0.055, CD * 0.12);   // on TOP of the card surface → feet rest, don't poke
  lean.add(seat);

  // real clipping plane at the card surface: anything the pet dips BELOW the top (e.g. squash on
  // landing after a jump) is clipped instead of poking through the underside. Updated each frame
  // from the card's world transform (renderer.localClippingEnabled must be on).
  const clipPlane = new THREE.Plane(new THREE.Vector3(0, 1, 0), 0);
  let clipEnabled = true;
  const _up = new THREE.Vector3(), _qw = new THREE.Quaternion(), _pt = new THREE.Vector3();
  const _qRoll = new THREE.Quaternion(), _zAxisR = new THREE.Vector3(0, 0, 1);
  let barrelRoll = 0;
  function applyClip(obj) {
    obj.traverse((n) => {
      if (!n.isMesh || !n.material) return;
      const mats = Array.isArray(n.material) ? n.material : [n.material];
      for (const m of mats) { m.clippingPlanes = [clipPlane]; m.clipShadows = true; m.needsUpdate = true; }
    });
  }

  const surface = createCardSurface(THREE, assetBase + 'KayfaBizarro_Card_Backside_01_lowrez.png', 4242,
    { width: 6, wobble: 0.5, jitter: 4 });   // baseW 6 = ~25 % dünner als die Durchflug-Karten
  topMat.map = surface.texture; topMat.needsUpdate = true;
  botMat.map = surface.texture; botMat.needsUpdate = true;

  // kinetic springs (flying-carpet feel)
  const roll = { x: 0, v: 0 }, pitch = { x: 0, v: 0 }, yawWhip = { x: 0, v: 0 };
  const cup = { x: 0, v: 0 }, tail = { x: 0, v: 0 };   // edge-curl springs (cup into turns, tail lift on boost)
  const flSq = { x: 1, v: 0 };
  let bob = 0, prevBoost = false, prevClimbSig = 0, wavePhase = 0;
  const halfW = CW / 2, halfD = CD / 2;

  function sync(st, dt, petChar) {
    // 1) vehicle owns world transform
    group.position.copy(st.position);
    group.quaternion.copy(st.quaternion);
    // S2 · Barrel-Roll: die GANZE Karte rollt um ihre Flugachse (lokales Z). Das Pet sitzt
    // darauf und wird mitgeführt — es dreht also um die Karten-Mitte, nicht um sich selbst.
    // Muss HIER stehen, vor Lean und Clip-Ebene: die Fuß-Clipping-Ebene wird unten aus der
    // Weltdrehung von `lean` gebaut; ein später aufgesetzter Roll würde das Pet anschneiden.
    if (barrelRoll) group.quaternion.multiply(_qRoll.setFromAxisAngle(_zAxisR, barrelRoll));
    // 2) kinetic lean — springs overshoot slightly, so the carpet whips into turns & rears on boost
    const boostKick = st.boosting ? 0.16 : 0;
    spring(roll, Math.max(-0.7, Math.min(0.7, st.bank * 1.15)), 90, 0.80, dt);
    spring(pitch, Math.max(-0.5, Math.min(0.5, st.pitchTilt * 0.9 + boostKick)), 80, 0.82, dt);
    spring(yawWhip, Math.max(-0.35, Math.min(0.35, -st.bank * 0.5)), 70, 0.84, dt);   // tail swings out of the turn
    lean.rotation.set(pitch.x, yawWhip.x, roll.x);

    // impulse kicks (boost edge, climb/dive edge) → squash + a pitch pop
    if (st.boosting && !prevBoost) { flSq.v -= 0.30 * 14; pitch.v += 1.6; }
    if (!st.boosting && prevBoost) { flSq.v += 0.14 * 14; }
    prevBoost = st.boosting;
    const climbSig = st.climbIn > 0.10 ? 1 : st.climbIn < -0.10 ? -1 : 0;
    if (climbSig !== prevClimbSig) { flSq.v += (climbSig > 0 ? 0.18 : -0.16) * 14; }
    prevClimbSig = climbSig;

    // 3) hover bob
    bob += dt;
    lean.position.y = Math.sin(bob * 2.4) * 0.03;

    // edge-curl targets: cup = both side edges lift in a turn (taco); tail = trailing edge rears on boost/climb
    spring(cup, Math.min(0.5, Math.abs(st.bank) * 1.3 + (st.boosting ? 0.14 : 0)), 70, 0.82, dt);
    spring(tail, Math.max(-0.4, Math.min(0.5, (st.boosting ? 0.42 : 0) + st.climbIn * 3.0 - st.pitchTilt * 0.4)), 60, 0.84, dt);

    // 4) carpet-waver + edge-curl. Ripple flows backward faster with speed; curl bends the RIM, and the
    // slab (skirt+bottom) is rebuilt from that rim so the edges physically bend as one solid card.
    wavePhase += dt * (2.6 + st.speed * 0.07);
    const arr = topGeo.attributes.position.array;
    const amp = 0.06 + st.speed * 0.0016;                 // livelier than before, still lit cleanly
    for (let i = 0; i < arr.length; i += 3) {
      const x = basePos[i], z = basePos[i + 2];
      const u = x / halfW, w = z / halfD;                 // -1..1 across / along
      const wave = Math.sin(wavePhase + z * 3.4 + x * 1.6) * amp * (0.35 + Math.abs(w));
      const cupCurl = cup.x * u * u * 0.9;                 // side edges up (into the turn)
      const tailCurl = tail.x * (w > 0 ? w * w : w * w * -0.5) * 0.8;   // back rears up, front dips a little
      const bank = roll.x * x * 0.16;                      // slab tips with the roll spring
      arr[i + 1] = basePos[i + 1] + wave + cupCurl + tailCurl + bank;
    }
    topGeo.attributes.position.needsUpdate = true;
    topGeo.computeVertexNormals();
    rebuildSlab();

    // update feet clip plane from the card's world surface (with a small tolerance below the top)
    if (clipEnabled) {
      lean.updateWorldMatrix(true, false);
      _up.set(0, 1, 0).applyQuaternion(lean.getWorldQuaternion(_qw)).normalize();
      seat.getWorldPosition(_pt).addScaledVector(_up, -0.05);
      clipPlane.setFromNormalAndCoplanarPoint(_up, _pt);
    } else {
      clipPlane.set(_up.set(0, 1, 0), 1e6);   // disabled: everything on the positive side → no clipping
    }

    // 5) card squash spring settles (kept for rig.kick card impulses; the PET squash is now owned by pet-kinetics.js)
    flSq.v += (1 - flSq.x) * 90 * dt - flSq.v * 12 * dt; flSq.x += flSq.v * dt;
  }

  return {
    name: 'card-carrier', group, seat, lean, sync, clipPlane, applyClip, halfW, halfD,
    // Ink-Outline zur Laufzeit: { width, wobble, jitter, style }
    setInk(next) { surface.setInk(next); },
    get ink() { return surface.params; },
    setBarrelRoll(a) { barrelRoll = a || 0; },
    get barrelRollAngle() { return barrelRoll; },
    setClipEnabled(on) {
      clipEnabled = !!on;
      // release immediately — sync() does not run in walk mode, so a stale card plane
      // left over from flight would clip the grounded pet away entirely.
      if (!on) clipPlane.set(_up.set(0, 1, 0), 1e6);
    },
    setVisible(on) { group.visible = !!on; },
    kick(a) { flSq.v += a * 14; },
    dispose() { topGeo.dispose(); topMat.dispose(); skirtGeo.dispose(); botGeo.dispose(); botMat.dispose(); darkMat.dispose(); },
  };
}

// ============================================================================
// flight-controller.js — KFB Travel v4 · Motion Controller (Flight)
// ----------------------------------------------------------------------------
// Extracted from PetFlight v2 (petflight.v2.js) and ADAPTED from the sphere
// world to a FLAT world (up = +Y, constant). The Dragonriding control feel is
// preserved 1:1: drag-hold = turn/climb RATE, W/S thrust, A/D yaw, ↑/↓ altitude,
// Space boost, idle glides out. WebGL three 0.160.
//
// Contract (004/005 Motion Controller): owns movement ONLY — no camera, no pet,
// no rendering. Consumes normalized input + ground height; publishes vehicle
// state (position/orientation/velocity/flags) that CardRig + camera read.
//
//   const fc = createFlightController({ THREE });
//   fc.update(dt, input, groundY);   // input = { yawIn, climbIn, thrust, boost }
//   fc.state → { position, quaternion, forward, right, up, speed, alt, bank,
//                pitchTilt, boosting, climbIn, grounded, flying }
// ============================================================================

export function createFlightController(opts = {}) {
  const THREE = opts.THREE;
  const P = Object.assign({
    SPD_MIN: 2, SPD_MAX: 42, CRUISE: 9,
    ALT_MIN: 2.2, ALT_MAX: 160,
    yawRate: 1.9, climbRate: 16, accel: 14, decel: 16,
    // S2 · „der Boost fühlt sich FREIER an, nicht nur schneller“. Im Report ist das
    // ein wegfallender Kurven-Drag — den gibt es bei uns nicht (Lenken kostet hier
    // kein Tempo). Also die andere Hälfte derselben Absicht: mehr Lenk-Autorität,
    // solange der Boost läuft. 1 = aus.
    boostYawGain: 1.28,
    // S10 · Landung: ab wann gilt Bodenkontakt als „gelandet". Nicht Berührung ALLEIN — sonst
    // kippt ein Streifschuss über einen Cube-Gipfel mitten im Flug in den Laufmodus. Es braucht
    // Bodenkontakt UND kleine Sinkrate UND (fast immer) den Willen zu sinken, gehalten über
    // `landHold` Sekunden. Hysterese also hier, nicht im Runner.
    landSink: 7, landHold: 0.22,
  }, opts.params || {});

  const up = new THREE.Vector3(0, 1, 0);
  const forward = new THREE.Vector3(0, 0, -1);   // heading, kept horizontal
  const right = new THREE.Vector3(1, 0, 0);
  const pos = new THREE.Vector3(0, P.CRUISE, 0);
  let alt = P.CRUISE, targetAlt = P.CRUISE;
  let speed = P.CRUISE, targetSpeed = P.CRUISE;
  let bank = 0, pitchTilt = 0, boosting = false, climbIn = 0, grounded = false;
  let prevAlt = alt, sinkRate = 0, touchT = 0, landed = false;

  const quaternion = new THREE.Quaternion();
  const _m = new THREE.Matrix4(), _q = new THREE.Quaternion();
  const _negF = new THREE.Vector3(), _zAxis = new THREE.Vector3(0, 0, 1), _xAxis = new THREE.Vector3(1, 0, 0);

  function update(dt, input, groundY) {
    input = input || {}; groundY = groundY || 0;
    climbIn = input.climbIn || 0;
    boosting = !!input.boost;
    const yawIn = (input.yawIn || 0) * (boosting ? P.boostYawGain : 1);
    // --- steering: rotate forward around up, keep horizontal ---
    forward.applyAxisAngle(up, yawIn);
    forward.y = 0; forward.normalize();
    right.crossVectors(forward, up).normalize();
    // bank follows turn rate (visual, but published for CardRig/pet lean)
    bank += ((-yawIn / Math.max(dt, 1e-3) * 0.06) - bank) * Math.min(1, dt * 5);
    bank = Math.max(-0.6, Math.min(0.6, bank));

    // --- altitude ---
    targetAlt = Math.max(P.ALT_MIN, Math.min(P.ALT_MAX, targetAlt + climbIn));
    alt += (targetAlt - alt) * Math.min(1, dt * 2.2);
    const minAlt = groundY + P.ALT_MIN;
    if (alt < minAlt) { alt = minAlt; targetAlt = Math.max(targetAlt, minAlt); }
    grounded = alt <= minAlt + 0.02;

    // --- S10: Sinkrate + Landungs-Erkennung (mit Hysterese) ---
    const dAlt = (alt - prevAlt) / Math.max(dt, 1e-3); prevAlt = alt;
    sinkRate += (-dAlt - sinkRate) * Math.min(1, dt * 8);     // positiv = sinken
    const wantsDown = climbIn < -0.001;
    if (grounded && sinkRate < P.landSink && (wantsDown || sinkRate > 0.5)) touchT += dt;
    else touchT = 0;
    landed = touchT >= P.landHold;

    // --- speed ---
    if (input.thrust > 0) targetSpeed = Math.min(P.SPD_MAX, targetSpeed + P.accel * dt);
    if (input.thrust < 0) targetSpeed = Math.max(P.SPD_MIN, targetSpeed - P.decel * dt);
    if (input.idle) targetSpeed += (P.CRUISE * 0.4 - targetSpeed) * Math.min(1, dt * 0.7);
    const desired = boosting ? P.SPD_MAX : targetSpeed;
    speed += (desired - speed) * Math.min(1, dt * (boosting ? 4 : 2));

    // --- travel (flat): advance along forward, y = alt ---
    pos.addScaledVector(forward, speed * dt);
    pos.y = alt;

    // --- orientation: -Z = forward, +Y = up, + bank + pitch ---
    _negF.copy(forward).negate();
    _m.makeBasis(right, up, _negF);
    quaternion.setFromRotationMatrix(_m);
    quaternion.multiply(_q.setFromAxisAngle(_zAxis, bank));
    const pitchTarget = Math.max(-0.42, Math.min(0.42, (targetAlt - alt) * 0.06 + climbIn * 2.4));
    pitchTilt += (pitchTarget - pitchTilt) * Math.min(1, dt * 5);
    quaternion.multiply(_q.setFromAxisAngle(_xAxis, -pitchTilt));
  }

  return {
    name: 'flight-controller', update,
    get state() {
      return {
        position: pos, quaternion, forward, right, up,
        speed, alt, bank, pitchTilt, boosting, climbIn, grounded, flying: !grounded,
        sinkRate, landed, targetAlt,
      };
    },
    setCruise() { alt = targetAlt = P.CRUISE; speed = targetSpeed = P.CRUISE; },
    // S10: Abheben braucht beides — auf der aktuellen Höhe EINSETZEN (kein Sprung nach oben)
    // und ein Steigziel darüber. `climbTo` ist genau dafür, `setTargetAlt` für das Overlay.
    setTargetAlt(v) { targetAlt = Math.max(P.ALT_MIN, Math.min(P.ALT_MAX, v)); },
    climbTo(v) { targetAlt = Math.max(alt, Math.min(P.ALT_MAX, v)); touchT = 0; landed = false; },
    setParams(p) { Object.assign(P, p || {}); },
    get params() { return P; },
    // alt/heading optional: von der Landung kommend setzt der Runner beides, damit die Karte
    // dort weiterfliegt, wo das Pet stand — und in die Richtung, in die es sah.
    reset(x, z, atAlt, heading) {
      const h = heading != null ? heading : Math.PI;
      pos.set(x || 0, 0, z || 0);
      forward.set(Math.sin(h), 0, Math.cos(h)).normalize();
      right.crossVectors(forward, up).normalize();
      alt = targetAlt = prevAlt = (atAlt != null ? Math.max(P.ALT_MIN, atAlt) : P.CRUISE);
      pos.y = alt;
      speed = targetSpeed = P.CRUISE;
      bank = pitchTilt = 0; sinkRate = 0; touchT = 0; landed = false;
    },
  };
}

// ============================================================================
// travel-poc.js — KFB Travel v7 · Runner (Flug + Boden)
// ----------------------------------------------------------------------------
// Fork von terrain-v6/travel-poc.js (Freeze 2026-07-25). v6 bleibt unangetastet.
// Sprintplan für diese Version: docs/SPRINT_travel-v7.md — Status dort pflegen,
// nicht hier. Changelog: docs/CHANGELOG_travel.md.
// ----------------------------------------------------------------------------
// RENDER-REIHENFOLGE (seit S2 unverhandelbar):
//   Szene → post-radial (Fullscreen-Blur) → speed-lines → hud.render()
// Sobald die Szene in einen Puffer geht, muss alles Scharfe DAHINTER kommen.
// ----------------------------------------------------------------------------
// ----------------------------------------------------------------------------
// Brief §7.1 — smallest bootable slice: flat WebGL ground + card + default pet
// (bunny) + flight controller. Flies. WebGL three 0.160. Later slices swap the
// flat ground for terrain-v3, add the ground/walk controller, 24-pet select,
// mode switch, and richer card kinetics.
//
// Runtime layers (001): Input → Vehicle(flight) → Camera → Pet → CardRig → Render.
// ============================================================================

import * as THREE from 'three';
import { createFlightController } from './flight-controller.js';
import { createCardCarrier } from './card-carrier.js';
import { createPetKinetics } from './pet-kinetics.js';
import { createVoxelTerrain } from './voxel-terrain.js';
import { createSkydome } from './skydome-shader.js';
import { makeWorldContext, MODES } from './world-context.js';
import { createWalkController } from './walk-controller.js';
import { createTravelHeat } from './travel-heat.js';
import { createHudCube } from './hud-cube.js';
import { createSettingsOverlay } from './settings-overlay.js';
import { createSpeedLines } from './speed-lines.js';
import { createRadialPost } from './post-radial.js';
import { createCardContrails } from './card-contrails.js';
import { createPetLighting } from './pet-lighting.js';
import { createBlobShadow } from './ground-shadow.js';
import { createTravelAudio } from './travel-audio.js';
import { createSkyCards } from './sky-cards.js';
import { createCardRegistry } from './card-registry.js';

const ASSET = (p) => new URL(p, import.meta.url).href;
// Pfad-Hygiene: der Pet-Stack kommt kanonisch über jsdelivr (Module brauchen application/javascript);
// der lokale Spiegel ist nur Fallback, nie Quelle.
const PETS_CANON = 'https://cdn.jsdelivr.net/gh/georg-doc/kayfabizarro@main/media/3D_Assets/kfb-pets.js';
async function petsModule() {
  try { return await import(/* @vite-ignore */ PETS_CANON); }
  catch (e) { console.warn('[travel-poc] kanonischer Pet-Stack nicht ladbar → lokaler Spiegel', e); return await import('./kfb-pets.js'); }
}

(function boot() {
  const stage = document.getElementById('tv-stage');
  if (!stage) { requestAnimationFrame(boot); return; }
  const probe = document.createElement('canvas');
  if (!(probe.getContext('webgl2') || probe.getContext('webgl'))) {
    stage.innerHTML = '<div style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center;color:#cdd4e6;font-family:monospace;">This needs a WebGL browser.</div>';
    return;
  }
  start(stage).catch((e) => console.error('[travel-poc] start failed', (e && (e.stack || e.message)) || e));
})();

async function start(stage) {
  const renderer = new THREE.WebGLRenderer({ antialias: true });
  renderer.setSize(stage.clientWidth, stage.clientHeight);
  renderer.setPixelRatio(Math.min(devicePixelRatio || 1, 2));
  renderer.shadowMap.enabled = true; renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  renderer.localClippingEnabled = true;   // for the card-carrier feet clip plane
  renderer.toneMapping = THREE.ACESFilmicToneMapping; renderer.toneMappingExposure = 1.0;
  renderer.domElement.style.cssText = 'position:absolute;inset:0;width:100%;height:100%;display:block;';
  stage.appendChild(renderer.domElement);

  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(58, stage.clientWidth / stage.clientHeight, 0.3, 5000);

  // --- WORLD (slice 3): deterministic v3 world from a fixed seed + one story mode.
  // Card-driven terrain (CardTriplet → setWorldContext) is a later slice; the hook is already here.
  const WORLD_SEED = 'kfb-travel-v4-slice3';
  const STORY = 'heroic';
  let worldSeed = WORLD_SEED, story = STORY;
  let wc = makeWorldContext({ storyMode: STORY, seeds: [WORLD_SEED] });
  let pal = wc.palette;
  const fogCol = new THREE.Color(pal[0][0] * 0.6 + 0.02, pal[0][1] * 0.6 + 0.03, pal[0][2] * 0.6 + 0.05);
  scene.background = fogCol.clone();
  scene.fog = new THREE.Fog(fogCol.getHex(), 90, 520);

  // --- lights: warm sun (shadow) + cool hemi so the pet reads from all sides ---
  const sun = new THREE.DirectionalLight(0xfff2e0, 2.6); sun.position.set(30, 60, 20); sun.castShadow = true;
  sun.shadow.mapSize.set(2048, 2048); sun.shadow.camera.near = 1; sun.shadow.camera.far = 200;
  sun.shadow.camera.left = -40; sun.shadow.camera.right = 40; sun.shadow.camera.top = 40; sun.shadow.camera.bottom = -40; sun.shadow.bias = -0.0006; sun.shadow.normalBias = 0.6;
  scene.add(sun, sun.target);
  scene.add(new THREE.HemisphereLight(0xe6f0ff, 0x6a6250, 1.0));

  // --- skydome (v3), coupled to the same story mode/palette ---
  const sky = createSkydome({ THREE, mode: wc.storyModeIndex, variant: 'S', worldMix: 0.4 });
  sky.setPalette(pal);
  scene.add(sky.group);

  // --- voxel terrain (v3), replacing the flat ground. groundHeightAt drives the flight clamp. ---
  const terrain = createVoxelTerrain({ THREE });
  terrain.setWorldContext(wc);
  terrain.setPalette(pal);
  terrain.build(scene);
  const groundHeightAt = (x, z) => terrain.groundHeightAt(x, z);

  // WoW-style camera collision: march from the look-target outward and stop before the camera
  // would enter terrain, so the pet is never hidden behind a cube wall.
  const _probe = new THREE.Vector3();
  function pullIn(from, dir, dist, margin) {
    const N = 14, m = margin != null ? margin : 1.0 + terrain.maxLift(true) * 0.5;
    for (let i = 1; i <= N; i++) {
      const t = (i / N) * dist;
      _probe.copy(from).addScaledVector(dir, t);
      if (_probe.y < groundHeightAt(_probe.x, _probe.z) + m) return Math.max(1.4, t - dist / N);
    }
    return dist;
  }
  // Letzte Instanz gegen „Kamera steckt im Cube": unsere Welt ist ein Höhenfeld aus VOLLEN
  // Säulen — wer über der Säulenoberkante ist, ist garantiert draußen. Also notfalls Richtung
  // Blickziel kriechen, bis das gilt. Lieber sehr nah dran als in einer Wand (Georgs Screen 1:
  // an Eck-Positionen zog die Auto-Zentrierung die Kamera in die Nachbarsäule).
  function escapeTerrain(pos, look, margin, steps) {
    const m = margin != null ? margin : 0.75, N = steps || 6;
    for (let i = 0; i < N; i++) {
      const gh = groundHeightAt(pos.x, pos.z) + m;
      if (pos.y >= gh) return i;
      pos.x += (look.x - pos.x) * 0.3;
      pos.z += (look.z - pos.z) * 0.3;
      if (pos.y < gh) pos.y = gh;
    }
    return N;
  }

  // --- vehicle + rig ---
  const flight = createFlightController({ THREE });
  flight.reset(0, 0);
  const rig = createCardCarrier({ THREE });   // assetBase: kanonische RAW-URL (card-carrier default)
  scene.add(rig.group);
  const petKin = createPetKinetics({ THREE });
  const walk = createWalkController({ THREE });
  const heat = createTravelHeat({});   // S1: der eine Regie-Skalar
  let mode = 'fly';   // 'fly' | 'walk'

  // --- S7: HUD-Würfel unten rechts — Ruhezustand Tacho, angefasst Menü.
  // Oberfläche und Farben kommen aus derselben Welt (Kanten-Textur + Story-Palette).
  let storyMode = MODES.find((m) => m.key === STORY) || MODES[3];
  let settings = null;   // wird nach dem Pet-Mount gebaut; Handler greifen lazy darauf zu
  const hud = createHudCube({
    THREE, dom: renderer.domElement,
    ink: storyMode.ink, panel: storyMode.panel,
    onSelect: (id) => settings.toggle(id),
  });
  hud.preWarm(renderer);   // Shader vorwärmen (Academy-Muster): kein Ruckler im ersten Frame

  // --- S2: Boost-Regie ------------------------------------------------------
  // Zwei Pässe, ein Regler-Satz. Beide hängen an `heat` (+ Boost-Impuls), beide sind
  // in Ruhe komplett aus. `fxBlur` steht HIER, weil das Overlay es beim Bauen liest
  // (später deklariert = TDZ-Boot-Abbruch, S8-Falle 1).
  let fxBlur = 1;
  const lines = createSpeedLines({ THREE, ink: storyMode.ink });
  lines.setInk(storyMode.ink, storyMode.panel);
  // Kondensstreifen an den hinteren Kartenecken: ab 20 km/h die einzige Tempo-Auskunft,
  // und sie zeichnen Bank, Barrel-Roll und Steigflug als Kurve in die Luft (TinySkies-Muster).
  const trails = createCardContrails({ THREE });
  trails.setAnchors(rig.halfW, rig.halfD);
  trails.setTint(storyMode.panel);
  scene.add(trails.group);

  // --- S14: Pet-Beleuchtung (Sky-Environment + Fill + Story-Tint) --------------
  const lighting = createPetLighting({ THREE, renderer, scene });
  lighting.setTint(storyMode.ink, 0.18);
  lighting.register(rig.group);
  lighting.bakeEnvironment(sky.group);

  // --- S15 · Schatten. Zwei verschiedene Probleme, zwei verschiedene Lösungen:
  // (1) auf dem TERRAIN projiziert der Terrain-Shader selbst (`terrain.setCasters`). Ein
  //     Schatten-Quad kann auf einem Voxel-Boden nicht funktionieren: es liegt auf EINER Höhe,
  //     schwebt also an Kanten über dem Abgrund, steckt in Wänden und flackert, sobald die
  //     Probenhöhe zwischen Nachbarsäulen springt (Georgs Befund).
  // (2) auf der KARTE bleibt es ein Quad im Karten-Rig — dort IST die Fläche durchgehend,
  //     und der Schatten soll mit Bank und Wellung mitgehen.
  let shadowGain = 1;
  const petShadow = createBlobShadow({ THREE, color: 0x1f1a14, params: { core: 0.3 } });
  rig.lean.add(petShadow.mesh);
  const post = createRadialPost({ THREE, renderer });
  lines.preWarm(renderer);

  // ---------------------------------------------------------------- WELT NEU BAUEN
  // Story-Mode und Seed ändern denselben Weg: neuer WorldContext → Terrain rebaked,
  // Himmel und HUD-Würfel bekommen dieselbe Palette. (Vorgriff auf S5.)
  function applyWorld(rebuildCtx) {
    if (rebuildCtx) {
      wc = makeWorldContext({ storyMode: story, seeds: [worldSeed] });
      pal = wc.palette;
    }
    terrain.setWorldContext(wc);
    terrain.setPalette(pal);
    sky.setMode(wc.storyModeIndex);
    sky.setPalette(pal);
    storyMode = MODES.find((m) => m.key === story) || storyMode;
    hud.setPalette({ ink: storyMode.ink, panel: storyMode.panel });
    lines.setInk(storyMode.ink, storyMode.panel);   // Speedlines tragen die Story-Tinte, nie Weiß
    trails.setTint(storyMode.panel);
    lighting.setTint(storyMode.ink);
    lighting.bakeEnvironment(sky.group);   // neuer Himmel → neues Umgebungslicht
    audio.setMood(wc.storyModeIndex);      // ein Mood = eine spektrale Identität
    fogCol.setRGB(pal[0][0] * 0.6 + 0.02, pal[0][1] * 0.6 + 0.03, pal[0][2] * 0.6 + 0.05);
    scene.background = fogCol.clone();
    if (scene.fog) scene.fog.color.copy(fogCol);
    if (settings) settings.setAccent('#' + new THREE.Color(storyMode.ink).getHexString());
  }

  // ---------------------------------------------------------------- CARD FLOOR
  // Das Fahrzeug ist keine Kugel, sondern eine 3.0 × 1.68 große Karte, die BANKT — und die
  // Cubes hüpfen nach oben. Eine einzige Höhenprobe in der Mitte lässt genau das passieren,
  // was Georg sieht: die Ecken schneiden in einen steigenden Würfel. Statt einer Physik-Engine
  // tastet diese Funktion die ganze Grundfläche ab (Mitte + 4 Ecken), einmal an der aktuellen
  // und einmal an der VORAUS liegenden Position, nimmt den schlechtesten Fall und rechnet die
  // Bob-Reserve (`terrain.maxLift()`) plus den Tiefgang der untersten Ecke drauf.
  // Steigen schnell, Sinken langsam — dieselbe Disziplin wie beim Kamera-Pull-in.
  let cardFloor = 0;
  // Höchste Oberfläche im Umkreis eines Körperradius — EINE Mittenprobe reicht nicht: das
  // Pet steckt sonst in der Nachbarsäule (Georgs Screen 1 beim Wechsel in den Walk-Mode).
  function safeGroundAt(x, z, r) {
    const rad = r != null ? r : 0.7;
    let top = groundHeightAt(x, z);
    for (let i = 0; i < 8; i++) {
      const a = (i / 8) * Math.PI * 2;
      const t = groundHeightAt(x + Math.cos(a) * rad, z + Math.sin(a) * rad);
      if (t > top) top = t;
    }
    return top;
  }
  function cardClearance(st, dt) {
    const hw = rig.halfW + 0.25, hd = rig.halfD + 0.25;   // + Haut-Marge
    const fx = st.forward.x, fz = st.forward.z;
    const rx = -fz, rz = fx;                              // right = forward × up (horizontal)
    const ahead = 1.2 + st.speed * 0.22;                  // dorthin, wo wir gleich sind
    let top = -1e9;
    for (let s = 0; s <= 1; s++) {
      const ox = st.position.x + fx * ahead * s, oz = st.position.z + fz * ahead * s;
      for (let i = 0; i < 5; i++) {
        const sx = i === 0 ? 0 : (i <= 2 ? 1 : -1);
        const sz = i === 0 ? 0 : (i === 1 || i === 3 ? 1 : -1);
        const t = groundHeightAt(ox + rx * hw * sx + fx * hd * sz, oz + rz * hw * sx + fz * hd * sz);
        if (t > top) top = t;
      }
    }
    const tilt = Math.abs(Math.sin(st.bank)) * hw + Math.abs(Math.sin(st.pitchTilt || 0)) * hd;
    // Bob-Reserve nur dort, wo die Cubes wirklich tanzen: in der Ruhezone braucht die Karte
    // keine Höhe für Hübe, die nicht stattfinden — dafür immer ein fester Sicherheitsabstand.
    const lift = terrain.maxLift(true) * (1 - terrain.calmAt(st.position.x, st.position.z));
    const want = top + lift + tilt + 0.3;
    cardFloor += (want - cardFloor) * Math.min(1, dt * (want > cardFloor ? 14 : 2.2));
    return cardFloor;
  }

  // S11 · Die Modus-Anzeige ist WEG — kein Badge mehr. Sie darf fallen, weil S10 die Auskunft
  // durch Mechanik ersetzt: man sieht an der Höhe, in welchem Modus man ist. Was bleibt, ist der
  // Rahmen im DC (Wortmarke links, Meta rechts) und der Tacho im Würfel.
  // EINE Hinweiszeile statt zweier Legenden-Blöcke: blendet nach 8 s aus und in späteren
  // Sitzungen gar nicht mehr auf. Die vollständige Steuerung steht im Overlay (S8).
  const hint = document.createElement('div');
  hint.style.cssText = "position:absolute;left:50%;transform:translateX(-50%);bottom:20px;text-align:center;"
    + "font-family:'Special Elite',monospace;font-size:12px;color:#fff;opacity:.9;"
    + 'text-shadow:0 2px 6px rgba(0,0,0,.7);transition:opacity 1.4s ease;pointer-events:none;';
  hint.textContent = 'W/S Schub · A/D lenken · Leertaste zweimal = abheben · X sinken und landen · Tab = Einstellungen';
  (document.getElementById('tv-hud') || stage).appendChild(hint);
  try {
    if (localStorage.getItem('kfb-travel-v7-hint') === 'seen') hint.style.display = 'none';
    else setTimeout(() => { hint.style.opacity = '0'; try { localStorage.setItem('kfb-travel-v7-hint', 'seen'); } catch (e) {} }, 8000);
  } catch (e) { setTimeout(() => { hint.style.opacity = '0'; }, 8000); }
  // S10 · MODUS OHNE SCHALTER. Der Modus ist eine Folge der Höhe, kein Zustand, den man umlegt:
  // Leertaste zweimal am Boden = abheben (ein verlängerter Sprung, kein neuer Zustand) · X oder
  // Pfeil-runter = sinken · Bodenkontakt mit kleiner Sinkrate = zurück in Walk. `F` bleibt als
  // direkter Umschalter — wer mit Timing-Fenstern nicht zurechtkommt, braucht einen Weg ohne.
  let autoMode = true, modeLockT = 0, lastSpaceAt = 0;
  function switchMode(to, opt) {
    if (to === mode) return;
    if (to === 'walk') {
      const p = flight.state.position; const gy = safeGroundAt(p.x, p.z) + terrain.maxLift(true) + 0.25;
      walk.reset(p.x, p.z, gy, Math.atan2(flight.state.forward.x, flight.state.forward.z));
      walkLookY = gy + walk.eyeUp;
      rig.setVisible(false); rig.setClipEnabled(false);
      petKin.enterWalk();
      if (pet) {
        scene.add(pet.object3D); pet.object3D.scale.setScalar(1.25);
        // no procedural loop in walk mode: those tweens move group.position, which
        // IS the walker's world position here — the clip layer carries the cycle.
        if (pet.motion) { pet.motion.stopLoops(); }
      }
    } else {
      const wp = walk.state.position;
      // Vom Boden kommend setzt die Karte DORT ein, wo das Pet stand, und in seiner Blickrichtung.
      // Sonst hüpft das Fahrzeug beim Abheben auf Reisehöhe — das war der Sprung in v5.
      const startAlt = opt && opt.alt != null ? opt.alt : null;
      flight.reset(wp.x, wp.z, startAlt, opt && opt.heading != null ? opt.heading : walk.state.heading);
      if (opt && opt.climb) flight.climbTo((startAlt != null ? startAlt : flight.state.alt) + opt.climb);
      cardFloor = terrain.groundHeightAt(wp.x, wp.z) + terrain.maxLift(true);   // kein Kriechstart
      rig.setVisible(true); rig.setClipEnabled(true);
      trails.reset();   // sonst spannt ein altes Band quer über die Karte
      petKin.leaveWalk(pet);
      if (pet) { rig.seat.add(pet.object3D); pet.object3D.visible = true; pet.object3D.scale.setScalar(1.15); pet.object3D.position.set(0, 0, 0); }
    }
    mode = to;
    heat.setMode(to);   // Skala behalten, kein Sprung beim Wechsel
    camSnap = true;
    modeLockT = 0.9;    // kurz keine automatische Rueckkehr — sonst pendelt es am Boden
  }

  // Abheben = der Sprung, der nicht landet. Kein neuer Zustand in der Sprung-Grammatik:
  // walk.jump() ist beim ersten Tastendruck schon gelaufen, der zweite verlängert ihn.
  function takeOff() {
    if (mode !== 'walk') return;
    const ws = walk.state;
    if (!ws.onGround && ws.vy < -0.5) return;   // im Fallen nicht abheben (sonst Rettungs-Flug)
    switchMode('fly', { alt: ws.position.y + 0.8, heading: ws.heading, climb: 12 });
  }

  // --- pet (canonical stack, default bunny) ---
  let pet = null, petLib = null, petId = 'bunny', petBusy = false;
  // Pet-Wechsel läuft über DIESELBE Funktion wie der erste Mount (ein Pfad, kein Sonderfall).
  // Vertrag §12.6: altes Pet disposen, sonst stapeln sich Augen-Rigs.
  async function mountPet(id) {
    if (petBusy) return;
    petBusy = true;
    try {
      const { loadPets, makePet } = await petsModule();
      if (!petLib) petLib = await loadPets();
      const p = await makePet(petLib, id, { THREE, motion: 'idle' });
      p.object3D.rotation.y = Math.PI;   // face travel direction (-Z)
      p.object3D.traverse((n) => { if (n.isMesh) { n.castShadow = true; } });
      if (pet) { try { pet.object3D.removeFromParent(); pet.dispose && pet.dispose(); } catch (e2) {} }
      pet = p; petId = id; window.__pet = p;
      if (p.motion && p.motion.initParts) p.motion.initParts();
      lighting.register(p.object3D);   // S14: Tint-Uniforms + envMapIntensity auf das neue Pet
      if (mode === 'walk') {
        petKin.enterWalk();
        scene.add(p.object3D); p.object3D.scale.setScalar(1.25);
        if (p.motion) p.motion.stopLoops();
      } else {
        p.object3D.scale.setScalar(1.15); p.object3D.position.set(0, 0, 0);
        rig.seat.add(p.object3D);
        rig.applyClip(p.object3D);   // clip feet at the card surface
      }
    } catch (e) { console.warn('[travel-poc] pet mount failed', e); }
    petBusy = false;
  }
  mountPet('bunny');

  // ---------------------------------------------------------------- S8: EINSTELLUNGEN
  // Cluster nach Häufigkeit. Es stehen nur Regler drin, die ECHT etwas tun — lieber eine
  // Sektion mit drei ehrlichen Reglern als sechs, die Zukunft versprechen.
  let bpm = 104, beatGain = 1;                       // Rhythmus-Fallback ohne Ton
  // S20 · Klang. Der Takt kommt ab jetzt aus dem Track, den man hört; ohne Ton fällt der Runner
  // auf seinen synthetischen Takt zurück. EIN Ausgang, kein zweites System (Regel aus S1).
  const audio = createTravelAudio({ storyIndex: wc.storyModeIndex });
  let soundOn = false;   // erst eine Nutzergeste darf den AudioContext bauen (Autoplay-Policy)
  const armAudio = () => { if (!soundOn) return; if (!audio.ready) audio.start(); else audio.resume(); };

  // S22 · Sky-Karten als Flugziele. Durchflug → Portal-Auflösung + Einsatz + Zähler.
  // S23 · Die Blätter tragen echte Karten: Titel/Lore aus der Deck-JSON sofort, das Artwork als
  // 2×2-Quadrant aus dem Deck-PDF gedrosselt nach (Kanon aus v11, cardMapping im Repo-Manifest).
  const cardReg = createCardRegistry();
  const skyCards = createSkyCards({ THREE, count: 7, registry: cardReg });
  scene.add(skyCards.group);
  let artT = 0, artOn = true;
  // Deck-JSON erst nach vier Sekunden holen — die ersten Sekunden gehören dem Terrain-Aufbau.
  setTimeout(() => {
    cardReg.pool().then((list) => {
      if (list && list.length) {
        skyCards.setDeck(list, true);
        console.info('[travel] Kartenpool:', list.length, 'Karten aus', cardReg.decks.length, 'Decks');
      }
    }).catch(() => { /* Textkarten bleiben stehen — nie ein leeres Blatt */ });
  }, 4000);
  skyCards.onPass = (data, n) => {
    audio.sfx('card');
    hud.flash && hud.flash();
    lastPass = { title: data.title, deck: data.deck, n };
  };
  let lastPass = null;
  // Tanz und Blinken sind ZWEI Kanäle (Georgs Befund: bei Tanz aus blinkten die Cubes weiter).
  // 'off' · 'beat' (an der Musik) · 'speed' (am Reisetempo) · 'both'
  let danceMode = 'both', blinkMode = 'both', blinkGain = 1;
  // Ruhezone am Boden (Georgs Befund: idealerweise hüpft nur der Boden, nicht die Kamera).
  // Je näher die Karte dem Boden kommt, desto ruhiger tanzen die Cubes unter ihr — dieselbe
  // Mechanik, die im Walk-Modus schon den Läufer schützt, nur mit weichem Übergang.
  let groundCalm = 0.9, calmAmt = 0;
  const CALM_LO = 3.5, CALM_HI = 15;   // voll ruhig unter 3,5 units über Grund, ab 15 voller Tanz
  let skyWorldMix = 0.4, skyExposure = 1, skySpiral = false;
  let quality = Math.min(devicePixelRatio || 1, 2);
  // Kamera-Zustand steht HIER, nicht in der Input-Schicht: das Overlay liest ihn beim Bauen
  // (die Regler zeigen ihren Wert sofort) — später deklariert wäre es ein TDZ-Fehler.
  let camDist = 9, zoomTarget = 9, camYaw = 0, camYawTarget = 0, lastZoomAt = 0, lastLookAt = 0;
  let rebakeT = 0;
  const scheduleRebake = () => { clearTimeout(rebakeT); rebakeT = setTimeout(() => applyWorld(false), 130); };
  const wp = () => (wc.params || {});
  const tp = (k, d) => (wp()[k] != null ? wp()[k] : d);
  const setTp = (k, v) => { if (wc.params) { wc.params[k] = v; scheduleRebake(); } };

  settings = createSettingsOverlay({
    mount: stage,
    eyebrow: 'KFB Travel v7',   // der Runner kennt seine Version, das Overlay nicht

    accent: '#' + new THREE.Color(storyMode.ink).getHexString(),
    onOpen: () => { hud.setEnabled(false); keys.clear(); },
    onClose: () => hud.setEnabled(true),
    sections: [
      { id: 'cards', title: 'Karten', hint: 'Der Story-Modus färbt Welt, Himmel und Würfel. Die Ink-Outline gilt vorerst für die Pet-Karte — Sky-Karten bekommen eigene Regler, sobald sie eigene Stile tragen (Torn, Bend).',
        controls: [
          { kind: 'select', label: 'Story-Modus', options: MODES.map((m) => ({ v: m.key, l: m.n + ' · ' + m.name })),
            get: () => story, set: (v) => { story = v; applyWorld(true); } },
          { kind: 'info', label: 'Palette', get: () => storyMode.name + '  ·  Ink #' + new THREE.Color(storyMode.ink).getHexString() },
          { kind: 'slider', label: 'Ink-Outline der Pet-Karte', min: 0, max: 18, step: 0.5, get: () => rig.ink.width,
            set: (v) => rig.setInk({ width: v }), fmt: (v) => (v === 0 ? 'aus' : v.toFixed(1) + ' px') },
          { kind: 'slider', label: 'Strich-Unruhe', min: 0, max: 1, step: 0.05, get: () => rig.ink.wobble,
            set: (v) => rig.setInk({ wobble: v }), fmt: (v) => Math.round(v * 100) + ' %' },
          { kind: 'slider', label: 'Kanten-Zittern', min: 0, max: 14, step: 0.5, get: () => rig.ink.jitter,
            set: (v) => rig.setInk({ jitter: v }), fmt: (v) => v.toFixed(1) + ' px' },
        ] },

      { id: 'cards', title: 'Sky-Karten', hint: 'Karten schweben in Zero-G im Himmel und richten sich gedämpft zur Kamera — immer ein guter Lese- und Durchflugwinkel. Durchflug löst sie als Portal auf.',
        controls: [
          { kind: 'toggle', label: 'Karten sichtbar', get: () => skyCards.params.visible, set: (on) => skyCards.setVisible(on) },
          { kind: 'slider', label: 'Kartengröße', min: 5, max: 24, step: 0.5, get: () => skyCards.params.width,
            set: (v) => { skyCards.setParams({ width: v }); }, fmt: (v) => v.toFixed(1) + ' m' },
          { kind: 'slider', label: 'Abstand (Ring)', min: 60, max: 320, step: 5, get: () => skyCards.params.ring, set: (v) => skyCards.setParams({ ring: v }) },
          { kind: 'slider', label: 'Höhenband oben', min: 30, max: 140, step: 2, get: () => skyCards.params.yMax, set: (v) => skyCards.setParams({ yMax: v }) },
          { kind: 'slider', label: 'Zero-G-Drift', min: 0, max: 8, step: 0.2, get: () => skyCards.params.driftAmp, set: (v) => skyCards.setParams({ driftAmp: v }) },
          { kind: 'slider', label: 'Eigen-Neigung', min: 0, max: 0.7, step: 0.02, get: () => skyCards.params.tiltAmp, set: (v) => skyCards.setParams({ tiltAmp: v }) },
          { kind: 'slider', label: 'Ausrichtung folgt (träge → flink)', min: 0.2, max: 4, step: 0.1, get: () => skyCards.params.faceDamp, set: (v) => skyCards.setParams({ faceDamp: v }) },
          { kind: 'slider', label: 'Trefferfenster', min: 0.5, max: 1.6, step: 0.05, get: () => skyCards.params.passRadius, set: (v) => skyCards.setParams({ passRadius: v }) },
          { kind: 'info', label: 'Gesammelt', get: () => skyCards.collected + ' Karten' + (lastPass ? '  ·  zuletzt: ' + lastPass.title : '') },
          { kind: 'toggle', label: 'Echtes Artwork laden', get: () => artOn, set: (on) => { artOn = on; if (!on) cardReg.clearQueue(); } },
          { kind: 'info', label: 'Artwork', get: () => (cardReg.decks.length ? cardReg.decks.length + ' Decks  ·  ' + (cardReg.pending ? cardReg.pending + ' in Arbeit' : 'geladen') : 'Textkarten (Registry nicht erreichbar)') },
        ] },
      { id: 'music', title: 'Klang & Rhythmus', hint: 'Der Takt treibt Cube-Tanz und Blinken. Ton startet erst mit einem Klick — Browser lassen Audio nicht von allein an.',
        controls: [
          { kind: 'toggle', label: 'Ton an', get: () => soundOn, set: (on) => {
            soundOn = on;
            if (on) { audio.start(); audio.setEnabled(true); } else audio.setEnabled(false);
          } },
          { kind: 'select', label: 'Track',
            options: () => (audio.tracks.length ? audio.tracks.map((t) => ({ v: t.file, l: t.title + (t.bpm ? '  ·  ' + t.bpm + ' BPM' : '') })) : [{ v: '', l: 'lädt …' }]),
            get: () => audio.track || '', set: (v) => audio.setTrack(v) },
          { kind: 'slider', label: 'Musik', min: 0, max: 0.6, step: 0.02, get: () => audio.params.music,
            set: (v) => audio.setMusicVol(v), fmt: (v) => (v <= 0 ? 'aus' : Math.round(v * 100 / 0.6) + ' %') },
          { kind: 'slider', label: 'Drone', min: 0, max: 2, step: 0.05, get: () => audio.params.drone, set: (v) => audio.setDroneVol(v) },
          { kind: 'slider', label: 'Fahrtwind', min: 0, max: 2, step: 0.05, get: () => audio.params.wind, set: (v) => audio.setWindVol(v) },
          { kind: 'slider', label: 'Rumpeln (Bodennähe)', min: 0, max: 2, step: 0.05, get: () => audio.params.rumble, set: (v) => audio.setRumbleVol(v) },
          { kind: 'slider', label: 'Böen', min: 0, max: 2, step: 0.05, get: () => audio.params.gust, set: (v) => audio.setGustVol(v) },
          { kind: 'slider', label: 'Sample-Trim', min: 0, max: 2, step: 0.05, get: () => audio.params.sfx, set: (v) => audio.setSfxVol(v) },
          { kind: 'slider', label: 'Effekte (FX)', min: 0, max: 2, step: 0.05, get: () => audio.params.fx, set: (v) => audio.setFxVol(v) },
          { kind: 'slider', label: 'Tempo (ohne Ton)', min: 60, max: 170, step: 1, get: () => bpm,
            set: (v) => { bpm = v; audio.setBpm(v); }, fmt: (v) => Math.round(v) + ' BPM' },
          { kind: 'slider', label: 'Beat-Kopplung', min: 0, max: 2, step: 0.05, get: () => beatGain, set: (v) => { beatGain = v; } },
          { kind: 'info', label: 'Takt', get: () => (audio.running
            ? Math.round(audio.bpm) + ' BPM aus dem Track  ·  Puls ' + Math.round(audio.pulse * 100) + ' %'
            : (audio.ready ? 'Ton aus (' + audio.state + ') — synthetisch ' + Math.round(bpm) + ' BPM'
                           : 'synthetisch (' + Math.round(bpm) + ' BPM)')) },
          { kind: 'select', label: 'Cube-Tanz koppeln an', options: [
            { v: 'both', l: 'Musik + Tempo' }, { v: 'beat', l: 'nur Musik (Dancefloor)' },
            { v: 'speed', l: 'nur Reisetempo' }, { v: 'steady', l: 'gleichmäßig (Flow ohne Musik)' },
            { v: 'off', l: 'aus — Cubes stehen still' },
          ], get: () => danceMode, set: (v) => { danceMode = v; } },
          { kind: 'select', label: 'Cube-Blinken koppeln an', options: [
            { v: 'both', l: 'Musik + Tempo' }, { v: 'beat', l: 'nur Musik (Dancefloor)' },
            { v: 'speed', l: 'nur Reisetempo' }, { v: 'steady', l: 'gleichmäßig' },
            { v: 'off', l: 'aus — kein Leuchten' },
          ], get: () => blinkMode, set: (v) => { blinkMode = v; } },
          { kind: 'slider', label: 'Blink-Stärke', min: 0, max: 2.5, step: 0.05, get: () => blinkGain, set: (v) => { blinkGain = v; } },
          { kind: 'slider', label: 'Flow statt Dancefloor', min: 0, max: 1, step: 0.05, get: () => terrain.flow,
            set: (v) => terrain.setFlow(v),
            fmt: (v) => (v <= 0 ? 'Dancefloor' : v >= 1 ? 'Flow' : Math.round(v * 100) + ' % Flow') },
        ] },

      { id: 'travel', title: 'Reise',
        controls: [
          { kind: 'toggle', label: 'Boden-Modus (F)', get: () => mode === 'walk', set: (on) => switchMode(on ? 'walk' : 'fly') },
          { kind: 'toggle', label: 'Modus folgt der Höhe', get: () => autoMode, set: (on) => { autoMode = on; } },
          { kind: 'slider', label: 'Höchsttempo Flug', min: 18, max: 90, step: 1, get: () => flight.params.SPD_MAX,
            set: (v) => flight.setParams({ SPD_MAX: v }), fmt: (v) => Math.round(v) + ' u/s' },
          { kind: 'slider', label: 'Lauftempo', min: 2, max: 12, step: 0.2, get: () => walk.params.speed,
            set: (v) => walk.setParams({ speed: v }), fmt: (v) => v.toFixed(1) + ' u/s' },
          { kind: 'slider', label: 'Kamera-Abstand', min: 0, max: 17, step: 0.5,
            get: () => (mode === 'walk' ? walk.state.cam.dist : zoomTarget),
            set: (v) => { if (mode === 'walk') walk.zoom(v - walk.state.cam.dist); else zoomTarget = v; } },
          { kind: 'toggle', label: 'POV (Blick des Pets)',
            get: () => (mode === 'walk' ? walk.state.cam.dist <= 1.6 : zoomTarget <= 1.6),
            set: (on) => { if (mode === 'walk') walk.zoom((on ? 0 : 9) - walk.state.cam.dist); else zoomTarget = on ? 0 : 9; } },
          { kind: 'slider', label: 'Tacho-Eichung', min: 0.2, max: 1.5, step: 0.05, get: () => heat.params.unitMeters,
            set: (v) => heat.setParams({ unitMeters: v }), fmt: (v) => '1 Unit = ' + v.toFixed(2) + ' m' },
          { kind: 'info', label: 'Aktuell', get: () => Math.round(heat.kmh) + ' km/h  ·  heat ' + heat.value.toFixed(2) },
        ] },

      { id: 'fx', title: 'Boost & FX', hint: 'Alles hier hängt am Regie-Skalar travelHeat — in Ruhe ist es aus, nicht bloss leise. Der Blur ist ein Fullscreen-Pass; bei 0 rendert die Szene direkt (kein Puffer, volles MSAA).',
        controls: [
          { kind: 'toggle', label: 'Speedlines', get: () => lines.enabled, set: (on) => lines.setEnabled(on) },
          { kind: 'toggle', label: 'Kartenecken-Streifen', get: () => trails.active, set: (on) => trails.setActive(on) },
          { kind: 'slider', label: 'Streifen ab', min: 5, max: 60, step: 1, get: () => trails.params.kmhOn,
            set: (v) => trails.setParams({ kmhOn: v }), fmt: (v) => Math.round(v) + ' km/h' },
          { kind: 'slider', label: 'Eckstreifen-Breite', min: 0.02, max: 0.14, step: 0.005, get: () => trails.params.width,
            set: (v) => trails.setParams({ width: v }), fmt: (v) => v.toFixed(3) },
          { kind: 'select', label: 'Streifen-Look', options: [{ v: 'light', l: 'Licht (additiv, Panel-Farbe)' }, { v: 'ink', l: 'Tinte (Story-Farbe)' }],
            get: () => lines.look, set: (v) => lines.setLook(v) },
          { kind: 'slider', label: 'Streifen-Dichte', min: 0.2, max: 2.5, step: 0.1, get: () => lines.params.density,
            set: (v) => lines.setParams({ density: v }), fmt: (v) => v.toFixed(1) + '×' },
          { kind: 'slider', label: 'Streifen-Deckkraft', min: 0, max: 0.6, step: 0.02, get: () => lines.params.opacity,
            set: (v) => lines.setParams({ opacity: v }) },
          { kind: 'slider', label: 'Radial-Blur', min: 0, max: 2, step: 0.05, get: () => fxBlur,
            set: (v) => { fxBlur = v; }, fmt: (v) => (v === 0 ? 'aus' : v.toFixed(2) + '×') },
          { kind: 'toggle', label: 'Barrel-Roll beim Boost', get: () => petKin.barrelRoll.on, set: (on) => petKin.setBarrelRoll(on) },
          { kind: 'slider', label: 'Lenken im Boost', min: 1, max: 1.8, step: 0.02, get: () => flight.params.boostYawGain,
            set: (v) => flight.setParams({ boostYawGain: v }), fmt: (v) => v.toFixed(2) + '×' },
          { kind: 'info', label: 'Live', get: () => 'Streifen ' + lines.liveCount + '  ·  Blur ' + post.strength.toFixed(3) },
        ] },

      { id: 'world', title: 'Welt', hint: 'Alles hier baut das Terrain neu — die Änderung greift kurz nach dem Loslassen.',
        controls: [
          { kind: 'slider', label: 'Rauheit', min: 0, max: 1, step: 0.02, get: () => tp('terrainRoughness', 0.6), set: (v) => setTp('terrainRoughness', v) },
          { kind: 'slider', label: 'Höhenskala', min: 4, max: 40, step: 0.5, get: () => tp('heightScale', 16), set: (v) => setTp('heightScale', v) },
          { kind: 'slider', label: 'Wasserlinie', min: -12, max: 12, step: 0.5, get: () => tp('waterLevel', 0), set: (v) => setTp('waterLevel', v) },
          { kind: 'slider', label: 'Farbversatz', min: 0, max: 1, step: 0.02, get: () => tp('colorShift', 0.5), set: (v) => setTp('colorShift', v) },
          { kind: 'slider', label: 'Cube-Tanz', min: 0, max: 1, step: 0.02, get: () => tp('motionAmplitude', 0.35), set: (v) => setTp('motionAmplitude', v) },
          { kind: 'slider', label: 'Ruhezone am Boden', min: 0, max: 1, step: 0.05, get: () => groundCalm,
            set: (v) => { groundCalm = v; }, fmt: (v) => (v === 0 ? 'aus' : Math.round(v * 100) + ' %') },
          { kind: 'info', label: 'Zone unter der Karte', get: () => (mode === 'walk' ? 'Walk: Läufer-Zone' : Math.round(calmAmt * 100) + ' % ruhig') },
          { kind: 'slider', label: 'Bodenschatten', min: 0, max: 1.6, step: 0.05, get: () => shadowGain,
            set: (v) => { shadowGain = v; terrain.setCasterGain(v); }, fmt: (v) => (v === 0 ? 'aus' : Math.round(v * 100) + ' %') },
        ] },

      { id: 'sky', title: 'Himmel',
        controls: [
          { kind: 'select', label: 'Variante', options: [
            { v: 'S', l: 'Sphäre (Default)' }, { v: 'A', l: 'Waber-Noise' }, { v: 'space', l: 'Space' },
            { v: 'watercolor', l: 'Aquarell' }, { v: 'watercolor2', l: 'Aquarell II' }, { v: 'starfield', l: 'Sternenfeld' },
            { v: 'night', l: 'Nacht' }, { v: 'morning', l: 'Morgen' }, { v: 'day', l: 'Tag' }, { v: 'alien', l: 'Alien' },
          ], get: () => sky.getVariant(), set: (v) => { sky.setVariant(v); lighting.bakeEnvironment(sky.group); } },
          { kind: 'slider', label: 'Welt-Mischung', min: 0, max: 1, step: 0.02, get: () => skyWorldMix, set: (v) => { skyWorldMix = v; sky.setWorldMix(v); } },
          { kind: 'slider', label: 'Belichtung', min: 0.4, max: 1.8, step: 0.05, get: () => skyExposure, set: (v) => { skyExposure = v; sky.setExposure(v); } },
          { kind: 'toggle', label: 'Hypno-Spirale', get: () => skySpiral, set: (on) => { skySpiral = on; sky.setSpiral(on); } },
        ] },

      { id: 'pet', title: 'Pet', hint: 'Alle Pets aus dem kanonischen Vertrag. Der Wechsel räumt das alte Pet ab (ein Augenpaar).',
        controls: [
          { kind: 'select', label: 'Cube-Pet',
            options: () => ((petLib && petLib.pets) || []).map((p) => ({ v: p.id, l: p.name || p.id })),
            get: () => petId, set: (v) => mountPet(v) },
          { kind: 'info', label: 'Geladen', get: () => (pet ? (pet.name || petId) : '…') },
          { kind: 'slider', label: 'Himmels-Licht', min: 0, max: 2, step: 0.05, get: () => lighting.params.env,
            set: (v) => lighting.setEnv(v), fmt: (v) => (v === 0 ? 'aus' : v.toFixed(2) + '×') },
          { kind: 'slider', label: 'Fill-Licht (Gegenlicht)', min: 0, max: 1.5, step: 0.05, get: () => lighting.params.fill,
            set: (v) => lighting.setFill(v) },
          { kind: 'slider', label: 'Story-Tint', min: 0, max: 0.5, step: 0.01, get: () => lighting.tintAmount,
            set: (v) => lighting.setTint(null, v), fmt: (v) => (v === 0 ? 'aus' : Math.round(v * 100) + ' %') },
        ] },

      { id: 'controls', title: 'Steuerung', wide: true, hint: 'Beide Travel-Modi in einer Tabelle — dafür ist die Legende aus dem Bild verschwunden.',
        controls: [{ kind: 'keys', rows: [
          ['Leertaste ×2', 'Boden: ABHEBEN (verlängerter Sprung)'], ['X / ↓', 'sinken — am Boden wird gelandet'],
          ['W / S', 'Flug: Schub · langsamer'], ['W / S', 'Boden: laufen · rückwärts'],
          ['A / D', 'lenken (Flug) · drehen (Boden)'], ['Q / E', 'Boden: seitwärts'],
          ['↑ / ↓', 'Flug: steigen · sinken'], ['Shift', 'Boden: rennen'],
          ['Leertaste', 'Flug: Boost'], ['Leertaste', 'Boden: Sprung'],
          ['J', 'Flug: Pet hüpft'], ['F', 'Fly ⇄ Walk (direkt)'],
          ['Tab', 'Einstellungen'], ['Esc', 'Einstellungen schließen'],
          ['Ziehen', 'lenken (Flug) · umsehen (Boden)'], ['Rad / Pinch', 'Zoom bis POV'],
          ['Würfel unten rechts', 'drehen → Seite klicken → Sektion'],
        ] }] },

      { id: 'system', title: 'System', wide: true, hint: 'Selten gebraucht, deshalb unten.',
        controls: [
          { kind: 'text', label: 'Welt-Seed', get: () => worldSeed, set: (v) => { worldSeed = v || WORLD_SEED; applyWorld(true); } },
          { kind: 'button', label: 'Seed neu würfeln', onClick: () => { worldSeed = 'kfb-' + Math.random().toString(36).slice(2, 9); applyWorld(true); } },
          { kind: 'slider', label: 'Auflösung', min: 0.6, max: 2, step: 0.1, get: () => quality, set: (v) => {
            quality = v; renderer.setPixelRatio(v); resize();
          }, fmt: (v) => v.toFixed(1) + '×' },
          { kind: 'button', label: 'Alles zurücksetzen', onClick: () => {
            story = STORY; worldSeed = WORLD_SEED; applyWorld(true);
            flight.setParams({ SPD_MAX: 42 }); walk.setParams({ speed: 5.4 });
            heat.setParams({ unitMeters: 0.5 }); heat.reset(mode);
            fxBlur = 1; lines.setEnabled(true); lines.setParams({ density: 1, opacity: 0.32, look: 'light' });
            trails.setActive(true); trails.setParams({ kmhOn: 20, width: 0.055 });
            petKin.setBarrelRoll(true); flight.setParams({ boostYawGain: 1.28 });
            bpm = 104; beatGain = 1; zoomTarget = 9;
            danceMode = 'both'; blinkMode = 'both'; blinkGain = 1; groundCalm = 0.9;
            terrain.setFlow(0); shadowGain = 1;
            lighting.setEnv(1); lighting.setFill(0.55); lighting.setTint(storyMode.ink, 0.18);
            rig.setInk({ width: 6, wobble: 0.5, jitter: 4 });
            sky.setVariant('S'); sky.setWorldMix(0.4); sky.setExposure(1); sky.setSpiral(false);
            skyWorldMix = 0.4; skyExposure = 1; skySpiral = false;
            if (mode === 'walk') switchMode('fly');
          } },
        ] },
    ],
  });

  // ---------------------------------------------------------------- INPUT layer
  const keys = new Set();
  addEventListener('keydown', (e) => {
    if (settings.isOpen()) return;            // Overlay offen: Tasten gehören dem Formular
    armAudio();
    keys.add(e.code);
    if (['ArrowUp', 'ArrowDown', 'Space'].includes(e.code)) e.preventDefault();
    if (e.code === 'KeyF' && !e.repeat) switchMode(mode === 'fly' ? 'walk' : 'fly');
    if (e.code === 'KeyJ' && !e.repeat && mode === 'fly') petKin.jump();
    if (e.code === 'Space' && !e.repeat) {
      // Kontext entscheidet, nicht ein Sonderfall: am Boden Sprung, doppelt = abheben.
      // In der Luft bleibt die Leertaste der Boost — die Doppel-Erkennung läuft dort ins Leere.
      const t = performance.now(), dbl = t - lastSpaceAt < 280;
      lastSpaceAt = t;
      if (mode === 'walk') { if (dbl && autoMode) takeOff(); else walk.jump(); }
    }
    if (e.code === 'Tab' && !e.repeat) { e.preventDefault(); settings.toggle('travel'); }
  });
  addEventListener('keyup', (e) => keys.delete(e.code));
  let steer = false, grabX = 0, grabY = 0, sx = 0, sy = 0, lastInputAt = performance.now(), lastPX = 0, lastPY = 0;
  const ptrs = new Map(); let pinch0 = 0, zoom0 = 0;
  const el = renderer.domElement;
  el.addEventListener('pointerdown', (e) => {
    if (e.__hudClaimed) return;   // S7: der HUD-Würfel hat diesen Zeiger
    armAudio();
    ptrs.set(e.pointerId, { x: e.clientX, y: e.clientY }); lastInputAt = performance.now(); lastPX = e.clientX; lastPY = e.clientY;
    try { el.setPointerCapture(e.pointerId); } catch (e2) {}
    if (ptrs.size === 1) { steer = true; grabX = e.clientX; grabY = e.clientY; sx = 0; sy = 0; }
    if (ptrs.size === 2) { const p = [...ptrs.values()]; pinch0 = Math.hypot(p[0].x - p[1].x, p[0].y - p[1].y); zoom0 = zoomTarget; }
  });
  el.addEventListener('pointermove', (e) => {
    if (e.__hudClaimed) return;
    if (!ptrs.has(e.pointerId)) return;
    const dxi = e.clientX - lastPX, dyi = e.clientY - lastPY; lastPX = e.clientX; lastPY = e.clientY;
    ptrs.set(e.pointerId, { x: e.clientX, y: e.clientY }); lastInputAt = performance.now();
    if (ptrs.size >= 2) { const p = [...ptrs.values()], d = Math.hypot(p[0].x - p[1].x, p[0].y - p[1].y); if (pinch0 > 0) { zoomTarget = Math.max(0, Math.min(17, zoom0 * (pinch0 / Math.max(d, 1)))); lastZoomAt = performance.now(); } }
    else if (mode === 'walk') { walk.orbit(dxi, dyi); lastLookAt = performance.now(); }
    else { sx = e.clientX - grabX; sy = e.clientY - grabY; }
  });
  const endPtr = (e) => { ptrs.delete(e.pointerId); if (ptrs.size < 2) pinch0 = 0; if (ptrs.size === 1) { const p = [...ptrs.values()][0]; grabX = p.x; grabY = p.y; sx = 0; sy = 0; steer = true; } if (ptrs.size === 0) { steer = false; sx = 0; sy = 0; } };
  el.addEventListener('pointerup', endPtr); el.addEventListener('pointercancel', endPtr);
  el.addEventListener('contextmenu', (e) => e.preventDefault());
  el.addEventListener('wheel', (e) => { e.preventDefault(); if (mode === 'walk') { walk.zoom(Math.sign(e.deltaY) * 1.1); return; } if (Math.abs(e.deltaX) > Math.abs(e.deltaY) * 1.2) { camYawTarget += e.deltaX * 0.004; lastLookAt = performance.now(); } else { zoomTarget = Math.max(0, Math.min(17, zoomTarget + Math.sign(e.deltaY) * 0.9)); lastZoomAt = performance.now(); } }, { passive: false });
  addEventListener('resize', () => { resize(); });

  // --- RE-ATTACH-WACHE ---------------------------------------------------------
  // Der DC-Runtime kann `#tv-stage` bei einem Template-Re-Render durch einen NEUEN
  // Knoten ersetzen. Unsere Knoten hängen dann an einem Waisen-Stage: `parentElement`
  // stimmt noch, `document.contains()` ist false — Ergebnis war ein leerer blauer Screen,
  // den nur ein Reload heilte (Boot-Reihenfolge-Glück). Statt Glück: jede halbe Sekunde
  // prüfen und alles Eigene ins aktuelle Stage hängen.
  const owned = () => [renderer.domElement, settings.root].filter(Boolean);
  let liveStage = stage, attachT = 0;
  function resize() {
    const w = liveStage.clientWidth || 1, h2 = liveStage.clientHeight || 1;
    renderer.setSize(w, h2);
    camera.aspect = w / h2; camera.updateProjectionMatrix();
    post.setSize(w, h2, renderer.getPixelRatio());
    lines.setAspect(w / h2);
  }
  function keepAttached(dt) {
    attachT += dt;
    if (attachT < 0.5) return;
    attachT = 0;
    if (document.contains(renderer.domElement)) return;
    const s = document.getElementById('tv-stage');
    if (!s) return;
    liveStage = s;
    for (const n of owned()) s.appendChild(n);
    const hudBox = document.getElementById('tv-hud');
    if (hint && !document.contains(hint)) (hudBox || s).appendChild(hint);
    resize();
    camSnap = true;
  }

  function readInput(dt) {
    let yawIn = 0, climbIn = 0, thrust = 0;
    if (steer) {
      const dz = 12;
      const nx = Math.sign(sx) * Math.min(1, Math.max(0, (Math.abs(sx) - dz) / 170));
      const ny = Math.sign(sy) * Math.min(1, Math.max(0, (Math.abs(sy) - dz) / 150));
      yawIn += -nx * 1.9 * dt; climbIn += -ny * 16 * dt;
      if (nx || ny) lastInputAt = performance.now();
    }
    if (keys.has('KeyA')) yawIn += 1.4 * dt;
    if (keys.has('KeyD')) yawIn -= 1.4 * dt;
    if (keys.has('ArrowUp')) climbIn += 16 * dt;
    if (keys.has('ArrowDown')) climbIn -= 16 * dt;
    if (keys.has('KeyX')) climbIn -= 16 * dt;   // S10: sinken und landen, ohne Pfeiltasten
    if (keys.has('KeyW')) thrust = 1;
    if (keys.has('KeyS')) thrust = -1;
    if (keys.has('KeyW') || keys.has('KeyS') || keys.has('KeyA') || keys.has('KeyD')) lastInputAt = performance.now();    const idle = performance.now() - lastInputAt > 1600;
    return { yawIn, climbIn, thrust, boost: keys.has('Space'), idle };
  }

  // ---------------------------------------------------------------- LOOP
  const _back = new THREE.Vector3(), _camPos = new THREE.Vector3(), _look = new THREE.Vector3(), _dir = new THREE.Vector3(), _sunOff = new THREE.Vector3(30, 60, 20);
  let last = performance.now(), synthPhase = 0, synthBeat = 0, lastChunkX = 1e9, lastChunkZ = 1e9, walkBobT = 0, camSnap = false, camPullW = 9, camPullF = 9, walkLookY = 0, boostPulse = 0, wasGrounded = true, lastStep = 0, rollWasActive = false, aglNow = 30;
  window.__travelPOC = { renderer, scene, camera, flight, walk, rig, petKin, terrain, sky, heat, hud, lines, post, trails, lighting, petShadow, audio, skyCards, cardReg, get lastPass() { return lastPass; }, get wc() { return wc; }, get settings() { return settings; }, get story() { return story; }, get mode() { return mode; }, setMode: (m) => switchMode(m), get pet() { return pet; }, get boostPulse() { return boostPulse; } };
  resize();   // Rendertarget + Speedline-Aspekt einmal auf die echte Stage-Größe setzen
  renderer.setAnimationLoop(() => {
    try {
      const now = performance.now(); const dt = Math.min(0.05, (now - last) / 1000); last = now;
      keepAttached(dt);
      let activePos, activeSpeed = 0, activeBank = 0, activePov = false;

      if (mode === 'fly') {
        // 1) input → 2) vehicle (ground height at the current pet/vehicle world x,z)
        const input = readInput(dt);
        const st0 = flight.state;
        // Ruhezone unter der Karte, bevor die Physik rechnet: näher am Boden = ruhigere Cubes.
        const gTop = safeGroundAt(st0.position.x, st0.position.z, 1.4);
        const agl = st0.position.y - gTop;
        const wantCalm = groundCalm * (1 - Math.max(0, Math.min(1, (agl - CALM_LO) / (CALM_HI - CALM_LO))));
        calmAmt += (wantCalm - calmAmt) * Math.min(1, dt * 3);
        aglNow = agl;   // S21: Bodennähe färbt den Fahrtwind (Rumpeln + dunklerer Bandpass)
        terrain.setCalm(st0.position.x, st0.position.z, 22, calmAmt);
        flight.update(dt, input, cardClearance(st0, dt));
        const st = flight.state; activePos = st.position; activeSpeed = st.speed;
        // S10: Landung. Der Flight-Controller entscheidet (Bodenkontakt + kleine Sinkrate +
        // Sinkwille, gehalten), der Runner führt nur aus — und erst nach der Sperrzeit.
        modeLockT = Math.max(0, modeLockT - dt);
        if (autoMode && modeLockT <= 0 && st.landed) { switchMode('walk'); return; }
        heat.update(dt, { mode: 'fly', speed: st.speed, boosting: st.boosting });
        // S2: der Boost-Impuls — schneller Einsatz (9/s), langsames Auslaufen (2,2/s).
        // Er addiert auf die heat-Kopplung: die Welt weitet sich beim Drücken, nicht erst,
        // wenn das Tempo angekommen ist.
        const bp = st.boosting ? 1 : 0;
        if (bp && boostPulse < 0.2) audio.sfx('boost');   // Einsatz, nicht Dauerton
        boostPulse += (bp - boostPulse) * Math.min(1, dt * (bp ? 9 : 2.2));
        const h = heat.value;
        activeBank = st.bank;
        // 3) follow cam behind forward — zoom sets pet distance; full zoom-in = POV
        camDist += (zoomTarget - camDist) * Math.min(1, dt * 4);
        camYaw += (camYawTarget - camYaw) * Math.min(1, dt * 5);
        if (now - lastLookAt > 1400) camYawTarget += (0 - camYawTarget) * Math.min(1, dt * 1.8);
        const povF = zoomTarget <= 1.6;
        if (povF) {
          if (pet) pet.object3D.visible = false;
          _camPos.copy(st.position).addScaledVector(st.up, 1.15);
          camera.position.lerp(_camPos, Math.min(1, dt * 8));
          _look.copy(camera.position).addScaledVector(st.forward, 6).addScaledVector(st.up, 0.2);
          camera.lookAt(_look);
        } else {
          if (pet) pet.object3D.visible = true;
          _back.copy(st.forward).negate(); if (camYaw) _back.applyAxisAngle(st.up, camYaw);          // S1: Kamera hängt an travelHeat, nicht mehr an der Rohgeschwindigkeit —
          // die Welt weitet sich beim Boost (Dolly zurück + höher + FOV), Report §03.
          const camH = 2.6 + h * 1.4 + camDist * 0.18 + boostPulse * 0.15;
          _look.copy(st.position).addScaledVector(st.forward, 2 + h * 3.4).addScaledVector(st.up, 0.8);
          _dir.copy(_back).addScaledVector(st.up, camH / Math.max(camDist, 0.001)).normalize();
          const dRaw = pullIn(st.position, _dir, Math.hypot(camDist + h * 1.6 + boostPulse * 0.6, camH));
          // fast pull-in, slow push-out — stops the camera bouncing on broken ground
          if (camSnap) camPullF = dRaw;
          else camPullF += (dRaw - camPullF) * Math.min(1, dt * (dRaw < camPullF ? 20 : 2.5));
          _camPos.copy(st.position).addScaledVector(_dir, camPullF);
          escapeTerrain(_camPos, _look, 0.9, 4);
          camera.position.lerp(_camPos, Math.min(1, dt * 3.5));
          camera.lookAt(_look);
        }
        if (camSnap) { camera.position.copy(_camPos); camSnap = false; }
        const fovT = povF ? 66 : 54 + h * 13 + boostPulse * 7;
        activePov = povF;
        camera.fov += (fovT - camera.fov) * Math.min(1, dt * 6); camera.updateProjectionMatrix();
        // 4) pet on the card → 5) CardRig transform+clip, then pet-kinetics reacts
        if (pet && pet.update) pet.update(dt);
        if (pet) petKin.update(pet, st, dt);
        // Der Barrel-Roll-Winkel entsteht in der Pet-Kinetik, gehört aber der KARTE:
        // rig.sync rollt Karte + Sitz gemeinsam, also dreht das Pet um die Karten-Mitte.
        rig.setBarrelRoll(petKin.barrelRoll.angle);
        // Die Rolle wird hörbar: ein Swish, der über die Stereobreite wandert (S21)
        const rollNow = petKin.barrelRoll.active;
        if (rollNow && !rollWasActive) audio.sfx('roll', 0.9);
        rollWasActive = rollNow;
        rig.sync(st, dt, pet && pet.character);
        // Streifen NACH rig.sync: die Anker sitzen in der Weltmatrix von rig.lean, also
        // tragen sie Bank, Kippung, Kantencurl und Barrel-Roll ohne eigene Kinematik.
        trails.setActive(true);
        trails.update(dt, rig.lean, camera, { kmh: heat.kmh });
        // S15 · Schatten: der Terrain-Shader projiziert den Werfer entlang des Lichtstrahls auf
        // die Fläche, die wirklich da ist — kein Quad, also kein Schweben an Kanten und kein
        // Flackern bei tanzenden Cubes. Werfer im Flug = die Karte.
        terrain.setCasterGain(shadowGain);
        terrain.setCasters({ x: st.position.x, y: st.position.y, z: st.position.z, r: 1.9 }, null);
        if (pet) {
          const po = pet.object3D.position, ph = Math.max(0, po.y);
          const ps = 0.62 * (1 + ph * 0.55);
          petShadow.place(rig.seat.position.x + po.x, 0.085, rig.seat.position.z + po.z,
            ps, ps * 0.92, 0, shadowGain * 0.5 * Math.max(0, 1 - ph * 0.6));
        } else petShadow.hide();
      } else {
        // WALK: same control scheme as flight — W/S move, A/D turn, Q/E strafe, Shift sprint
        const iy = (keys.has('KeyW') ? 1 : 0) - (keys.has('KeyS') ? 1 : 0);
        const ix = (keys.has('KeyE') ? 1 : 0) - (keys.has('KeyQ') ? 1 : 0);
        walk.setInput(ix, iy);
        const turn = (keys.has('KeyA') ? 1 : 0) - (keys.has('KeyD') ? 1 : 0);
        walk.update(dt, { turn, sprint: keys.has('ShiftLeft') || keys.has('ShiftRight') }, groundHeightAt);
        const ws = walk.state; activePos = ws.position; activeSpeed = ws.moving ? 6 : 0;
        aglNow = Math.max(0, ws.position.y - groundHeightAt(ws.position.x, ws.position.z));
        // Rettung: steckt das Pet trotz allem in einer Säule (hüpfender Cube, harter Modus-Wechsel),
        // heben wir es auf die höchste Oberfläche im Körperumkreis — nie stumm darin stehen lassen.
        const safeY = safeGroundAt(ws.position.x, ws.position.z, 0.62);
        if (ws.position.y < safeY - 0.06) walk.lift(safeY);
        heat.update(dt, { mode: 'walk', speed: ws.speed, sprinting: ws.sprinting, airborne: !ws.onGround });
        boostPulse += (0 - boostPulse) * Math.min(1, dt * 2.2);   // kein Boost am Boden
        if (trails.active) trails.setActive(false);                // keine Karte, keine Streifen
        // Am Boden wirft das PET — Körpermitte als Werfer, damit der Schatten am Fuß ansetzt
        // und nicht als runder Fleck daneben liegt.
        terrain.setCasterGain(shadowGain);
        terrain.setCasters({ x: ws.position.x, y: ws.position.y + 0.85, z: ws.position.z, r: 0.95 }, null);
        petShadow.hide();
        const h = heat.value;
        activeBank = ws.turnRate * 0.22;
        // cubes hold still around the walker so they can't swallow or punch through the pet
        terrain.setCalm(ws.position.x, ws.position.z, 26, 1);
        // third-person orbit cam — zoom all the way in for POV
        const c = ws.cam;
        const pov = c.dist <= 1.6;
        activePov = pov;
        if (pov) {
          if (pet) pet.object3D.visible = false;
          const hy = ws.position.y + walk.eyeUp * 1.15;
          camera.position.set(ws.position.x, hy, ws.position.z);
          _look.set(ws.position.x + Math.sin(ws.facing) * 4, hy + (0.32 - c.pitch) * 3.2, ws.position.z + Math.cos(ws.facing) * 4);
          camera.lookAt(_look);
          camera.fov += (66 - camera.fov) * Math.min(1, dt * 6); camera.updateProjectionMatrix();
        } else {
          if (pet) pet.object3D.visible = true;
          // follow cam BEHIND the walker's heading (same feel as flight); drag adds a temporary
          // look-around offset that recentres, and the look target's Y is smoothed so cube
          // steps don't jolt the camera.
          if (now - lastLookAt > 1400) walk.recenterView(dt);
          const yaw = ws.heading + c.yawOff;
          const tgtY = ws.position.y + walk.eyeUp;
          walkLookY += (tgtY - walkLookY) * Math.min(1, dt * 5);
          _look.set(ws.position.x, walkLookY, ws.position.z);
          _dir.set(-Math.sin(yaw) * Math.cos(c.pitch), Math.sin(c.pitch), -Math.cos(yaw) * Math.cos(c.pitch)).normalize();
          const dRaw = pullIn(_look, _dir, c.dist + h * 0.9, 1.2);
          if (camSnap) { camPullW = dRaw; walkLookY = tgtY; }
          else camPullW += (dRaw - camPullW) * Math.min(1, dt * (dRaw < camPullW ? 20 : 2.5));
          _camPos.copy(_look).addScaledVector(_dir, camPullW);
          const cg = groundHeightAt(_camPos.x, _camPos.z) + 1.0;
          if (_camPos.y < cg) _camPos.y = cg;
          // … aber der Aufzug darf die Kamera nicht über das Pet hinaus heben (sonst schaut sie
          // in den Himmel und das Pet fällt aus dem Bild). Statt höher: näher heranziehen.
          const yCap = walkLookY + Math.max(2.4, c.dist * 0.8);
          if (_camPos.y > yCap) {
            _camPos.y = yCap;
            _camPos.x += (_look.x - _camPos.x) * 0.35;
            _camPos.z += (_look.z - _camPos.z) * 0.35;
          }
          // … und ganz zuletzt die Garantie: nie in einer Säule stehen. Der Deckel oben kann die
          // Kamera horizontal in die Nachbarsäule geschoben haben — genau der Fehler im Screenshot.
          escapeTerrain(_camPos, _look, 0.8, 6);
          camera.position.lerp(_camPos, Math.min(1, dt * 6));
          camera.lookAt(_look);
          camera.fov += (56 + h * 6 - camera.fov) * Math.min(1, dt * 6); camera.updateProjectionMatrix();
        }
        if (camSnap) { camera.position.copy(_camPos); camSnap = false; }
        // pet walks on the ground: walk cycle, lean, jump/land squash, facing
        // ORDER IS CANON: motor first (mixer/face/rig), our kinetics last so the
        // lean + world position win over PetMotion's rotation.z damping.
        if (pet) {
          if (pet.update) pet.update(dt);
          petKin.updateWalk(pet, ws, dt);
        }
        // S21 · Schritte, Sprung, Landung als Hörereignisse. Die Schrittzählung kommt aus der
        // Pet-Kinetik (dort läuft der Gehzyklus) — sonst sitzen die Tritte auf einem zweiten Takt.
        if (!ws.onGround && wasGrounded) audio.sfx('jump', 0.9);
        if (ws.onGround && !wasGrounded) audio.sfx('land', Math.min(1.4, 0.5 + (ws.impact || 0) * 0.05));
        wasGrounded = ws.onGround;
        if (petKin.stepCount !== lastStep) {
          lastStep = petKin.stepCount;
          if (ws.onGround) audio.sfx('step', ws.sprinting ? 1.1 : 0.8);
        }
      }

      // shared: terrain streaming (only on chunk crossing) + colour/beat + sky + sun
      const cx = Math.round(activePos.x / terrain.CHUNK), cz = Math.round(activePos.z / terrain.CHUNK);
      if (cx !== lastChunkX || cz !== lastChunkZ) { terrain.recenter(activePos.x, activePos.z); lastChunkX = cx; lastChunkZ = cz; }
      synthPhase += dt * (bpm / 60);
      if (synthPhase >= 1) { synthPhase -= 1; synthBeat = 1; }
      synthBeat *= Math.exp(-dt * 5.5);
      // S20: EIN Takt-Ausgang. Läuft Ton, kommt die Eins aus dem Track (plus dessen Bassband);
      // ohne Ton bleibt der synthetische Takt — kein zweites System, nur eine andere Quelle.
      audio.update(dt, { heat: heat.value, rate: heat.rate, mode, agl: aglNow, camera });
      // S22: Karten wandern mit der Welt mit und weichen nach vorn, wenn man sie hinter sich lässt
      skyCards.setCenter(activePos.x, activePos.z);
      skyCards.setForward(mode === 'fly' ? flight.state.forward.x : Math.sin(walk.state.facing || 0),
                          mode === 'fly' ? flight.state.forward.z : Math.cos(walk.state.facing || 0));
      skyCards.update(dt, camera, activePos);
      // Artwork gepaced: ein PDF-Render alle 2,5 s, nur wenn das Bild flott läuft (dt < 40 ms) und
      // die Welt steht. Ein Seitenrender kostet Hunderte Millisekunden auf demselben Thread —
      // ungepaced kostet er die Bildrate.
      if (artOn && (artT += dt) > 2.5 && dt < 0.04) { artT = 0; skyCards.pumpArt(activePos, 520); }
      skyCards.recycle(activePos);
      // Gate ist „Uhr läuft", nicht „Graph gebaut": sonst ist der synthetische Takt ab dem ersten
      // Ton-Einschalten dauerhaft weg, auch wenn der Context suspendiert oder stumm ist.
      const rawBeat = (audio.running ? Math.max(audio.beat, audio.pulse) : synthBeat) * beatGain;
      const rawEnergy = 0.28 + heat.value * 0.4;
      const chanB = (m) => (m === 'beat' || m === 'both' ? rawBeat : 0);
      // 'steady' ist die Stellung für den reinen Flow: eine KONSTANTE Amplitude, die weder am
      // Takt noch am Reisetempo hängt — das Boden-Animationsmuster für sich, wie in der
      // three.js-Demo. Ohne diese Stellung war Flow ohne Musik nicht einstellbar (Georgs Notiz).
      const chanE = (m) => (m === 'steady' ? 0.55 : (m === 'speed' || m === 'both' ? rawEnergy : 0));
      const drive = {
        beat: chanB(danceMode), energy: chanE(danceMode),
        glowBeat: chanB(blinkMode), glowEnergy: chanE(blinkMode), glowGain: blinkGain,
      };
      terrain.update(dt, drive);
      sky.follow(camera);
      sky.update(dt, { beat: rawBeat, energy: rawEnergy });   // der Himmel hört weiter den ganzen Takt
      sun.position.copy(activePos).add(_sunOff); sun.target.position.copy(activePos);
      lighting.follow(activePos);

      // S2 · REIHENFOLGE: Szene → Radial-Blur → Speedlines → Würfel.
      // Der Blur ist quadratisch an `heat` gekoppelt (Reisetempo bleibt scharf) plus
      // einem Anteil aus dem Boost-Impuls; bei 0 rendert `post` direkt auf den Schirm.
      const hi = Math.max(0, (heat.value - 0.30) / 0.70);
      post.setStrength(fxBlur * (hi * hi * 0.075 + boostPulse * 0.035), dt);
      post.render(scene, camera);
      lines.update(dt, { heat: heat.value, rate: heat.rate, pulse: boostPulse });
      lines.render(renderer);
      // S7: HUD-Würfel als LETZTER Pass in einem Scissor-Viewport — nie verdeckt, nie geblurrt
      hud.update(dt, { kmh: heat.kmh, heat: heat.value, rate: heat.rate, bank: activeBank,
                       mode: activePov ? 'POV' : '' });
      hud.render(renderer);
    } catch (e) { if (!window.__loopErr) { window.__loopErr = true; console.error('[travel-poc] frame error', e); } }
  });
}

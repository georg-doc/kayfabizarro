<!-- Kopie der Projekt-CLAUDE.md, damit sie im Bundle mitreist. Im Ziel-Workspace als CLAUDE.md ablegen. -->

# Projekt-Kontext (immer lesen)

## Was hier gebaut wird
**KayfaBizarro (KFB)** von Georg von Westphalen — Cut & Play Comics: Comic drucken, in Karten
zerschneiden, gemeinsam laut eine Geschichte bauen. 1–6 Menschen, niemand gewinnt.
Regeln: kayfabizarro.pages.dev (#kfb Freestyle, #med MedKayfab). Lizenz der Decks CC BY-NC-SA 4.0.

Die 3D-Sachen hier sind **Meta-Narrativ zum Spiel**, keine Techdemos:
- `KFB Travel v7.dc.html` + `terrain-v7/` — aktueller Stand, Reise über eine Voxel-Welt auf einer
  fliegenden Karte, Sky-Karten als Flugziele.
- `rollercoaster-v11/` — Vorgänger, **eingefroren**. Quelle für portierbare Systeme (Audio, Portal,
  Curtain, Pet, Decks).

## Kontextdokumente (vor Konzeptarbeit lesen)
- `docs/KFB_CONTEXT.md` — Spiel- und Meta-Narrativ, Vision für Travel, Ideensammlung. **Living Doc.**
- `docs/SPRINT_travel-v7.md` — Slices, Status, Grundrisse.
- `docs/CHANGELOG_travel.md` — was wann warum, mit gemessenen Zahlen.
- `docs/SFX_elevenlabs_prompts.md` — Prompt-Sammlung für Sound-Einsätze.

## Namen, die stimmen müssen
**Uncle FrizzleBob** (der Hase) · **King Kayfabian** (rotierender Richter) · **Kayfabulation** /
kayfabulieren · **BLÖDSINN!** (immer so geschrieben) · Story-Modi englisch: Tragic · Comic · Absurd ·
Heroic · Mystical · Forbidden · Grußformel **Stay fluffy.**
**Karten sind keine Powers, sie sind Beweisstücke** — also nie Zahlenwerte, Trefferpunkte oder
Punktestände im UI.

## Arbeitsweise, die sich hier bewährt hat
- **Ein Slice pro Runde**, klein genug, dass am Ende ein vorzeigbarer Stand steht.
- **Messen statt behaupten:** jede Änderung mit einer Zahl belegen (Uniform, Zähler, Pegel) und die
  Zahl in den Changelog schreiben.
- **Über den echten Bedienweg testen**, nicht über die API — ein Slice kann über `start()` grün und
  über den Schalter tot sein (S20).
- **Auf „läuft" gaten, nie auf „existiert"** — sonst verwirft man den funktionierenden Fallback.
- **Versionsnummern gehören dem Runner**, nicht einem Modul — ein Modul, das seine eigene Version
  kennt, lügt beim nächsten Fork.
- Antworten auf Deutsch, Code-Kommentare auf Deutsch, Fachbegriffe englisch.

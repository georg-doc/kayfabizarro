repo: georg-doc/kayfabizarro
branch: main
path: media/

## Wozu

Dieses Projekt **rendert** aus dem Repo, es forkt es nicht: Travel lädt zur Laufzeit
Deck-PDFs, Karten-JSON, Musik und (bald) SFX per RAW-URL. Nichts davon liegt hier als Kopie —
mit Absicht, damit ein neues Deck im Repo sofort im Flug auftaucht. Lokal liegen nur
**Fallback-Manifeste**, die nicht veralten dürfen.

## Was gelesen wird

| Repo-Pfad | wofür | Modul |
|---|---|---|
| `media/kfb/index.json` | Deck-Registry (`kfb-deck-registry/v2`), `cardMapping` 2×2, `baseUrl` | `terrain-v7/card-registry.js` |
| `media/kfb/Deck_*.pdf` | Karten-Artwork, ein 2×2-Quadrant pro Karte | `card-registry.js` |
| `media/kfb/Deck_*.pdf.json` | Karten-Daten (`cardNumber`, `cardName`, `power`, `lore`) | `card-registry.js` |
| `media/3D_Assets/Sounds/jukebox.json` + Tracks | Musikbett, BPM für die Takt-Uhr | `terrain-v7/travel-audio.js` |
| `media/3D_Assets/Audio/sfx.json` | Einsatz-Ebene (Sample erst, Synthese dann) | `travel-audio.js` |
| `media/3D_Assets/build/pet-library.v6.js`, `pet-eye-rig.v5.js`, `pet-motion.v2.js` | Pet-Stack (per CDN-Import) | `terrain-v7/kfb-pets.js` |
| `media/kfb/*` (Karten-Rückseite, Wortmarke) | Kartenblatt der Flug-Karte | `terrain-v7/card-carrier.js` |

**Lokale Fallbacks** (RAW-first, dann diese, dann hartkodierter Default):
`terrain-v7/kfb-index.json` · `terrain-v7/jukebox.json` · `terrain-v7/sfx.json`

## Screen map

| Screen / Datei | gebaut aus |
|---|---|
| `KFB Travel v7.dc.html` (Entry) | `terrain-v7/*` (18 Module), Theme `themes/kfb-med.css` |
| Sky-Karten | `media/kfb/index.json`, `Deck_*.pdf`, `Deck_*.pdf.json` |
| Klang & Rhythmus | `media/3D_Assets/Sounds/jukebox.json`, `media/3D_Assets/Audio/sfx.json` |
| Pet (Uncle FrizzleBob & Co.) | `media/3D_Assets/build/pet-*.js` (CDN, gepinnte Versionen) |
| Flug-Karte / Kartenblatt | `media/kfb/` (Rückseite, Wortmarke) |

## Was im Repo fehlt, damit Slices grün werden

- `media/3D_Assets/Audio/sfx.json` — Manifest für die Einsatz-Ebene. Form und Prompts stehen in
  `docs/SFX_elevenlabs_prompts.md`. Solange es fehlt, spielt Travel die synthetischen Einsätze
  (kein Fehler, nur weniger Charakter).
- Die ElevenLabs-Dateien selbst nach `media/3D_Assets/Audio/`.

## Last sync

date: 2026-07-25T04:45:00+02:00
commit: — (nicht ermittelt; es wurde nur per RAW-URL gelesen, nicht geklont)

### Updated in this project
- Sky-Karten tragen echtes Deck-Artwork (2×2-Crop aus den Deck-PDFs, Daten aus der Karten-JSON).
- Jukebox liest das Repo-Manifest: zehn Tracks, BPM treibt die Takt-Uhr.
- Einsatz-Ebene ist auf `media/3D_Assets/Audio/sfx.json` vorbereitet (Sample erst, Synthese dann).
- Pet-Stack per gepinntem CDN-Import (`pet-library.v6`, `pet-eye-rig.v5`, `pet-motion.v2`).

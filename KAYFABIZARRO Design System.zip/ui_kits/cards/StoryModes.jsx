// ui_kits/cards/StoryModes.jsx
// The six story modes, one per d6 face.

function StoryModes() {
  const modes = [
    { pip: '⚀', name: 'Tragic',    body: 'Loss is real. Comedy gets you ejected.', cls: 'mode--tragic' },
    { pip: '⚁', name: 'Comedic',   body: 'Bigger. Sillier. The bit must escalate.', cls: 'mode--comedic' },
    { pip: '⚂', name: 'Noir',      body: 'Everyone is lying about something. Yes, you.', cls: 'mode--noir' },
    { pip: '⚃', name: 'Erotic',    body: 'Tension, restraint, eye contact. No fluids.', cls: 'mode--erotic' },
    { pip: '⚄', name: 'Mythic',    body: 'Speak in oracles. The room becomes a temple.', cls: 'mode--mythic' },
    { pip: '⚅', name: 'Forbidden', body: 'The taboo. The X-Card is your friend.', cls: 'mode--forbidden' },
  ];
  return (
    <div className="modes">
      {modes.map(m => (
        <div className={`mode ${m.cls}`} key={m.name}>
          <div className="mode__pip">{m.pip}</div>
          <div className="mode__name">{m.name}</div>
          <p className="mode__body">{m.body}</p>
        </div>
      ))}
    </div>
  );
}

window.StoryModes = StoryModes;

// ui_kits/cards/PlayingCard.jsx
// A single 2.5×3.5-ratio playing card for KayfaBizarro / MedKayfab.

function PlayingCard({
  variant = 'character',     // 'character' | 'scene' | 'shift'
  suit = 'CHARACTER',        // top-left label
  ref_ = '01/52',            // top-right ref
  artwork,                   // { src, tag } | { gradient, tag }  | null (uses placeholder)
  artClass = '',             // 'kfb-card__art--clinical' | '--shift' | '--ghost'
  name,
  italic,
  alias,
  quote,
  lore,
  power,                     // { name, body }
  rotate = 0,
  stampTR,                   // src
  stampBL,                   // src
}) {
  const cls = `kfb-card kfb-card--${variant}`;
  return (
    <article className={cls} style={{ transform: `rotate(${rotate}deg)` }}>
      <div className="kfb-card__suit">
        <span>{suit}</span><b>{ref_}</b>
      </div>
      <div className={`kfb-card__art ${artClass}`}>
        {artwork && artwork.src && <img src={artwork.src} alt=""/>}
        {artwork && artwork.tag && <div className="kfb-card__art-tag">{artwork.tag}</div>}
      </div>
      <h3 className="kfb-card__name">
        {name} {italic && <em>{italic}</em>}
      </h3>
      {alias && <div className="kfb-card__alias">{alias}</div>}
      {quote && <p className="kfb-card__quote">{quote}</p>}
      {lore && <div className="kfb-card__lore"><b>LORE</b> — {lore}</div>}
      {power && (
        <div className="kfb-card__power">
          <b>{power.name}</b>{power.body}
        </div>
      )}
      {stampTR && <img className="kfb-card__stamp kfb-card__stamp--tr" src={stampTR} alt=""/>}
      {stampBL && <img className="kfb-card__stamp kfb-card__stamp--bl" src={stampBL} alt=""/>}
    </article>
  );
}

function CardBack({ rotate = 0, label = 'Kayfa', italic = 'Bizarro', sub = 'Stay Fluffy · Kayfa-bingo!' }) {
  return (
    <article className="kfb-card kfb-card--back" style={{ transform: `rotate(${rotate}deg)` }}>
      <div className="back-inner">
        <img className="back-rabbit" src="../../assets/frizzlebob-rabbit.svg" alt=""/>
        <div className="back-mark">{label} <em>{italic}</em></div>
        <div className="back-sub">{sub}</div>
      </div>
    </article>
  );
}

window.PlayingCard = PlayingCard;
window.CardBack = CardBack;

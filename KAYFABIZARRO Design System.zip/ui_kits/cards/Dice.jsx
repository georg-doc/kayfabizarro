// ui_kits/cards/Dice.jsx
// Story-Mode die (white, d6 with story-mode pips) and Quest die (red, +/-).

function Die({ face = 1, kind = 'mode', rotate = 0, caption }) {
  const src = `../../assets/dice/d6-${face}.svg`;
  return (
    <div className={`die die--${kind}`} style={{ transform: `rotate(${rotate}deg)` }}>
      <img src={src} alt={`d6 face ${face}`}/>
      {caption && <div className="die__caption">{caption}</div>}
    </div>
  );
}

function DiceSet({ items }) {
  return (
    <div className="diceset">
      {items.map((d, i) => <Die key={i} {...d} />)}
    </div>
  );
}

window.Die = Die;
window.DiceSet = DiceSet;

// ui_kits/cards/QuestLadder.jsx
// 1–6 quest-state bar.

function QuestLadder() {
  const steps = [
    { n: 1, lbl: 'Spark' },
    { n: 2, lbl: 'Stir' },
    { n: 3, lbl: 'Stake' },
    { n: 4, lbl: 'Spiral' },
    { n: 5, lbl: 'Storm' },
    { n: 6, lbl: 'Finale' },
  ];
  return (
    <div className="ladder">
      <div className="section__num">QUEST DIE — STATE LADDER</div>
      <div className="ladder__bar">
        {steps.map(s => (
          <div className="ladder__step" key={s.n}>
            <div className="ladder__num">{s.n}</div>
            <div className="ladder__lbl">{s.lbl}</div>
          </div>
        ))}
      </div>
      <div className="ladder__legend">
        <div><b>+2</b> escalate hard</div>
        <div><b>+1</b> push the stakes</div>
        <div><b>0</b> hold the moment</div>
        <div><b>−1</b> deflate · never &lt; 1</div>
      </div>
    </div>
  );
}

window.QuestLadder = QuestLadder;

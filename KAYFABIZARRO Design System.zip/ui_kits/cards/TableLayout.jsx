// ui_kits/cards/TableLayout.jsx
// A bird's-eye annotated mock of a played table.

function TableLayout() {
  return (
    <div className="table">
      <div className="zone zone--deck">
        <div className="zone__cap">Deck</div>
        <div className="table__deck-stack">
          <div className="mini-card mini-card--back"></div>
          <div className="mini-card mini-card--back"></div>
          <div className="mini-card mini-card--back"></div>
        </div>
        <div className="zone__sub">draw 1, hold 4</div>
      </div>

      <div className="zone zone--stage">
        <div className="zone__cap">Stage · the played card</div>
        <div className="table__stage-card">
          <div style={{height: 60, border: '1.5px solid #1a1a1a', background: 'linear-gradient(135deg, #ecc04a, #c2412c)'}}></div>
          <div style={{fontFamily: 'var(--font-display)', fontSize: 14, marginTop: 4}}>FrizzleBob</div>
          <div style={{fontFamily: 'var(--font-mono)', fontSize: 8, color: '#3a352d'}}>EGO TRIP — flip the Quest</div>
        </div>
        <div className="zone__sub">scene OR character — pick a frame</div>
      </div>

      <div className="zone zone--modedie">
        <div className="zone__cap">Mode Die</div>
        <img className="table__die" src="../../assets/dice/d6-4.svg" alt=""/>
        <div className="zone__sub">erotic, today</div>
      </div>

      <div className="zone zone--hand">
        <div className="zone__cap">Hand · 4 cards</div>
        <div className="table__hand">
          <div className="mini-card"></div>
          <div className="mini-card"></div>
          <div className="mini-card"></div>
          <div className="mini-card"></div>
        </div>
        <div className="zone__sub">don't fan it like a tourist</div>
      </div>

      <div className="zone zone--questdie">
        <div className="zone__cap">Quest Die</div>
        <img className="table__die" src="../../assets/dice/d6-3.svg" alt=""/>
        <div className="zone__sub">at 6: finale next turn</div>
      </div>

      <div className="zone zone--xcard">
        <div className="zone__cap">X-Card</div>
        <div className="xcard-mini"><span>×</span></div>
        <div className="zone__sub">always reachable</div>
      </div>

      <div className="zone zone--notes">
        <div className="zone__cap">Marginalia</div>
        <div className="scribble">
          "the dropped sandwich was always Doris's"<br/>
          <span style={{color:'var(--stamp-red)'}}>+ FrizzleBob owes a song</span>
        </div>
      </div>
    </div>
  );
}

window.TableLayout = TableLayout;

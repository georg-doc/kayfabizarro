// ui_kits/cards/IntroRitual.jsx
// The "Name it · Claim it · Power it" 30-second ticket.

function IntroRitual() {
  const beats = [
    { pip: '01', lbl: '10 sec', phr: 'Name it',  bar: 'Say the card aloud, in character.' },
    { pip: '02', lbl: '10 sec', phr: 'Claim it', bar: 'Stake your relationship to it.' },
    { pip: '03', lbl: '10 sec', phr: 'Power it', bar: 'Promise the table what it will do.' },
  ];
  return (
    <div style={{ display: 'grid', gap: 12 }}>
      {beats.map(b => (
        <div className="ticket" key={b.pip} style={{ transform: `rotate(${b.pip === '02' ? 0.6 : -0.5}deg)` }}>
          <div className="ticket__pip">{b.pip}</div>
          <div>
            <div className="ticket__lbl">{b.lbl} · the intro ritual</div>
            <div className="ticket__phr">{b.phr}</div>
            <div className="ticket__bar">{b.bar}</div>
          </div>
        </div>
      ))}
    </div>
  );
}

window.IntroRitual = IntroRitual;

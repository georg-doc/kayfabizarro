# UI Kit · The Hub

Recreates the kayfabizarro web hub — the static home page at https://georg-doc.github.io/kayfabizarro/ — using the design-system tokens.

The hub is the public-facing landing surface that ties KayfaBizarro Freestyle and MedKayfab together. It's a single long page with anchor navigation, FrizzleBob's voice up top, and rule-book sections below. Built in HTML + a small amount of vanilla JS for the section reveal.

## Files
- `index.html` — full landing page, scrolls through hero · two-game cards · rule-book teaser · footer
- `Hero.jsx` — top hero, wordmark + manifesto pull-quote
- `GameCard.jsx` — one of the two big "choose your reality" cards
- `RuleSection.jsx` — bordered + taped rule-book section, used through the page
- `MicroNav.jsx` — sticky-top mini navigation
- `Footer.jsx` — CC license + Gumroad + Substack links

## Notes
The hub on the live site uses long-form text and `#anchor` jumps. We replicate the **vibe and structure**, not every paragraph — see the live URL for the canonical text. Replace the placeholder rabbit illustration with your real Procreate art when available.

// ui_kits/hub/MicroNav.jsx
function MicroNav() {
  const items = [
    { href: '#kfb',   label: 'KayfaBizarro' },
    { href: '#med',   label: 'MedKayfab' },
    { href: '#cards', label: 'Cards' },
    { href: '#dl',    label: 'Download' },
  ];
  return (
    <nav className="micronav">
      <span className="micronav__brand">KKKK · v18.4</span>
      <ul>
        {items.map(i => (
          <li key={i.href}><a href={i.href}>{i.label}</a></li>
        ))}
      </ul>
      <a className="btn btn--small" href="#print">Print / PDF</a>
    </nav>
  );
}
window.MicroNav = MicroNav;

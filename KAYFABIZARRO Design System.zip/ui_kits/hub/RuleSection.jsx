// ui_kits/hub/RuleSection.jsx
function RuleSection({ id, num, eyebrow, title, children, tilt = -1 }) {
  return (
    <section id={id} className="rule" style={{ transform: `rotate(${tilt}deg)` }}>
      <div className="rule__num">{num}</div>
      <div className="rule__eyebrow">{eyebrow}</div>
      <h3 className="rule__title">{title}</h3>
      <div className="rule__body">{children}</div>
      <img className="rule__tape" src="../../assets/marginalia/tape.svg" alt=""/>
    </section>
  );
}
window.RuleSection = RuleSection;

// ui_kits/hub/Footer.jsx
function Footer() {
  return (
    <footer className="footer">
      <div className="footer__col">
        <div className="footer__h">Kayfa<em>Bizarro</em> Freestyle v18.4</div>
        <div className="footer__p">Georg von Westphalen<br/>CC BY-NC-SA 4.0 · Pay What You Want · Do Not Resell</div>
      </div>
      <div className="footer__col">
        <div className="footer__h">Get the decks</div>
        <a href="#">All Decks — Gumroad</a><br/>
        <a href="#">Protopia (KayfaBizarro)</a><br/>
        <a href="#">Cardiology (MedKayfab)</a>
      </div>
      <div className="footer__col">
        <div className="footer__h">Follow</div>
        <a href="#">CancelThisComic Blog</a><br/>
        <a href="#">Substack</a>
      </div>
      <img className="footer__stamp" src="../../assets/stamps/pwyw.svg" alt="PWYW"/>
      <span className="margin-text footer__sig">— stay fluffy.</span>
    </footer>
  );
}
window.Footer = Footer;

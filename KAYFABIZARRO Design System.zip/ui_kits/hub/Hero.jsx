// ui_kits/hub/Hero.jsx
function Hero() {
  return (
    <section className="hero">
      <div className="hero__seal">
        <img src="../../assets/logos/seal-kkkk.svg" alt="KKKK seal"/>
      </div>
      <div className="hero__top">Uncle FrizzleBob's Komik Kard Kult</div>
      <h1 className="hero__mark">
        Kayfa<em>Bizarro</em>
        <span className="hero__sub">— The Game —</span>
      </h1>
      <div className="hero__tag">
        The Social Story-Wrestling Card Game by Georg v. Westphalen<br/>
        <span className="hero__tag-mono">Free Cut &amp; Play Comics · CC BY-NC-SA 4.0</span>
      </div>
      <div className="hero__manifesto">
        <p>
          You sit down. You draw a card. You announce who you are — <em>loud, in character,
          no apologies.</em> Somebody else draws a card and contradicts everything you just said.
          This is not a problem. <strong>This is the game.</strong>
        </p>
        <p>
          Cards are not rules. They are <strong>invitations</strong>. Reality is not fixed —
          it is negotiated, one sentence at a time, until the story lands or the die hits 6.
          Put on your mask. Let's wrestle.
        </p>
        <div className="hero__attr">— Uncle FrizzleBob <span>(Professional Reality-Wrestler &amp; Epistemiologic Outlaw)</span></div>
      </div>
      <div className="hero__cta">
        <a className="btn">PLAY THE GAME</a>
        <a className="btn btn--ghost">Read the rules →</a>
      </div>
      <img className="hero__rabbit" src="../../assets/frizzlebob-rabbit.svg" alt="FrizzleBob"/>
      <img className="hero__stamp" src="../../assets/stamps/stay-fluffy.svg" alt="Stay fluffy"/>
      <span className="margin-text hero__m1">KayfaBINGO!</span>
      <span className="margin-text hero__m2">Stay fluffy!</span>
      <img className="hero__doodle hero__doodle--1" src="../../assets/marginalia/pigeon.svg" alt=""/>
      <img className="hero__doodle hero__doodle--2" src="../../assets/marginalia/blob.svg" alt=""/>
    </section>
  );
}
window.Hero = Hero;

// ui_kits/hub/GameCard.jsx
function GameCard({ kicker, title, italic, body, cta, accent, stamp, doodle, rotate }) {
  const style = { transform: `rotate(${rotate}deg)` };
  return (
    <article className="gamecard" style={style}>
      <div className="gamecard__kicker">{kicker}</div>
      <h2 className="gamecard__title">
        {title} <em style={{ color: accent }}>{italic}</em>
      </h2>
      <p className="gamecard__body">{body}</p>
      <div className="gamecard__meta">1–6 players · 20–60 min · CC BY-NC-SA</div>
      <a className="btn">{cta}</a>
      {stamp && <img className="gamecard__stamp" src={stamp} alt=""/>}
      {doodle && <img className="gamecard__doodle" src={doodle} alt=""/>}
    </article>
  );
}
window.GameCard = GameCard;

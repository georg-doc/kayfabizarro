# KayfaBizarro Design System — Agent Skill

When asked to design anything for **KayfaBizarro**, **MedKayfab**, or **Uncle FrizzleBob's Krazy Kayfabizarro Komik Kard Kult Klub** (the same brand, different surface), follow this skill.

## What this brand is

A hand-drawn, cut-and-play, zine-style story-wrestling card-game system by Georg von Westphalen.
Underground-comix + punk-zine + watercolor-Procreate + wrestling-kayfabe. **Anti-corporate by design.** If it looks slick or shipped-from-Figma, it's wrong.

## First step — always

**Read `README.md`** before doing anything else. It contains the full content + visual + voice rules.
Then load `colors_and_type.css` (the token source) and skim `preview/` to see the design system in action.

## Files & where to find things

| You need… | Look in |
|---|---|
| Color tokens, type ramp, spacing/shadow vars | `colors_and_type.css` |
| Brand fonts (Fonteys PRO, CC ClobberinTime, Baby Eliot, PiS Coalfield) | `fonts/` |
| Mascot, paper grain, divider | `assets/` (root) |
| Dice glyphs (d6 faces) | `assets/dice/` |
| Stamps (BINGO!, BLÖDSINN!, HUMBUG!, PWYW, STAY FLUFFY!) | `assets/stamps/` |
| Marginalia doodles (gator, pigeon, tape, manicule, blob, coffee ring) | `assets/marginalia/` |
| Logos / wordmarks / seals | `assets/logos/` |
| Design-system preview cards (one concept per file) | `preview/` |
| Web-hub patterns (Hero, GameCard, RuleSection, Footer) | `ui_kits/hub/` |
| Card-game kit (cards, dice, story modes, quest ladder, table layout, X-card) | `ui_kits/cards/` |
| Slide templates (1920×1080: cover, divider, list, two-col, feature, card-stage, closing) | `ui_kits/slides/` |

## When asked to make…

- **A web page or marketing surface** → start from `ui_kits/hub/` patterns. Use `MicroNav`, `Hero`, `GameCard`, `RuleSection`, `Footer` as building blocks.
- **A printable card / playmat / rules sheet** → start from `ui_kits/cards/`. The `PlayingCard` component covers Character, Scene, and Shift variants.
- **A deck (presentation, pitch, manifesto)** → copy `ui_kits/slides/index.html` and edit. Each `<section>` inside `<deck-stage>` is one slide.
- **A new game component (timer, scoreboard, etc.)** → match the visual vocabulary in `ui_kits/cards/cards.css` (paper-bone fill, ink-black border, paper-drop-shadow, ±1.5° rotation).

## Voice — the non-negotiables

- **Second person, intimate, conspiratorial.** "You sit down. You draw a card."
- **Imperatives over explanations.** "Don't explain it — perform it."
- **Manifesto cadence.** Short sentences. *Italics for emphasis.* Em-dashes — like that.
- **No corporate softening.** Never "user." It's "you," "the table," "the storyteller."
- **No emoji.** Doodles or nothing.
- **Brand stylization:** `Kayfa*Bizarro*` (italic middle), all-caps for **CALLS** (BINGO!, BLÖDSINN!, EGO TRIP).
- **German loanwords** stay German with the umlaut: *Blödsinn!*

## Visuals — the non-negotiables

- **Damage everything.** Rotate ±1.5°. Paper-grain overlay (`assets/paper-grain.svg`) on every full surface. Stamp something. Tape something.
- **Paper grounds, ink lines, watercolor washes.** Use `var(--paper-cream)` / `var(--paper-bone)` for backgrounds, `var(--ink-black)` (NOT `#000`) for line work, the `--wash-*` variables ONLY at 55–80% alpha.
- **Type:** display = `var(--font-display)` (CC ClobberinTime) — use `--font-display-rough` (Krackle) or `--font-display-crunch` (Crunchy) for stamped headlines. Body = `var(--font-serif)` (Fonteys PRO). Captions = `var(--font-hand)` (Baby Eliot). Rules tables = `var(--font-mono)` (PiS Coalfield).
- **Marginalia is mandatory.** Every page reserves 12–18% edge real-estate for tiny doodles, stamps, micro-text. Empty corners are a bug.
- **Aspect ratio for game cards: 2.5 × 3.5** (225×315 px screen). Internal layout, top-to-bottom: **Image · Quote · Lore · Power**. Always.
- **No glassmorphism, no neumorphism, no gradients-as-style, no blur, no backdrop-filter.** A gradient may exist *only* as a watercolor wash.
- **Drop shadows are paper shadows** — hard, warm-toned, slightly offset (`var(--sh-paper)`/`--sh-paper-lg`/`--sh-paper-xl`). Never `filter: blur`.
- **No humans in illustration.** Always anthropomorphic animals — rabbits, foxes, pigeons, possums, alligators.

## Patterns to copy directly

- **Stamp-style button:** rectangular, ink-bordered, slightly rotated, hover-wobbles. See `.btn` in `ui_kits/hub/hub.css`.
- **Numbered rule card:** see `RuleSection` in `ui_kits/hub/`.
- **Card with image / quote / lore / power:** see `PlayingCard` in `ui_kits/cards/PlayingCard.jsx`.
- **Six-mode legend block:** see `StoryModes` in `ui_kits/cards/StoryModes.jsx`.
- **1→6 quest ladder with hero's-journey color arc:** see `preview/components-quest-ladder.html` (cream → ochre → bruise → ink-black).

## Hard "no"s

- ❌ No emoji
- ❌ No icon fonts (Lucide, Heroicons, Material)
- ❌ No `#000` (use `var(--ink-black)` = `#1f1a14`)
- ❌ No clean opacity-fade hover transitions — use a wobble or stamp-down
- ❌ No "user" in copy
- ❌ No square plumb borders — always slight rotation
- ❌ No grey-and-fade disabled states — cross out with hand-drawn X
- ❌ Never call the system "modern," "minimal," or "clean"

## Stay fluffy.

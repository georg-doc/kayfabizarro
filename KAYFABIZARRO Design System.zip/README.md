# KAYFABIZARRO Design System

> *"This is not a game you play. It's a game you use." — Uncle FrizzleBob*

A design system for **Uncle FrizzleBob's Krazy Kayfabizarro Komik Kard Kult Klub** — a series of hand-drawn, cut-and-play, zine-style story-wrestling card games by Georg von Westphalen.

The brand lives at the intersection of:

- **Underground comix / MAD magazine satire** (Aragonés margins, dark humor, weird animals)
- **Punk zine + Xerox culture** (Banksy street, Gilliam cut-out collage, found-document chaos)
- **Bill Watterson-style inking** (wildly varied line weight, kinetic energy — vocabulary only, never the cast)
- **Procreate-drawn analog warmth** (custom brushes, watercolor washes bleeding past ink, aged paper)
- **Wrestling kayfabe + epistemic sabotage** (the fiction is real, reality is negotiated)

The system is **anti-corporate by design**. If something looks slick, polished or shipped-from-Figma, it's wrong. Damage it. Stamp it. Tape it. Let pencil show through the ink.

---

## Products covered

1. **KayfaBizarro Freestyle** — the original social story-wrestling card game (1–6 players · 20–60 min).
2. **MedKayfab** — the clinical edition for medical active-recall learning (solo or 1–6).
3. **The Hub** — the static web home at `georg-doc.github.io/kayfabizarro` that ties them together.

All three share Uncle FrizzleBob (the yellow rogue rabbit) as host, the same Anti-Rule Book vibe, the same dice + card mechanics — but address different tables.

---

## Sources we explored

- **Live web hub:** https://georg-doc.github.io/kayfabizarro/ — text + structure of both rule sets, voice of FrizzleBob, content scaffold.
- **Distribution:** https://georgvw.gumroad.com/ — free Cut & Play comic decks (Protopia, MedKayfab Cardiology, etc).
- **Blog / longform:** https://cancelthiscomic.substack.com/t/kayfabizarro
- **License:** CC BY-NC-SA 4.0 · Pay What You Want · Do Not Resell.
- **NotebookLM persona prompt** for the "Uncle FrizzleBob" art voice (provided directly by the creator).

We did **not** have direct access to the original Procreate files, custom brushes, or the printed card art — so the system encodes the *language* of those artifacts (paper texture, ink, watercolor, marginalia rules) rather than reproducing them. Real card art should be dropped into `assets/` to replace placeholders.

---

## Index

```
README.md                  — this file (start here)
SKILL.md                   — Agent Skills entry point
colors_and_type.css        — CSS variables: palette, type ramp, semantic tokens
fonts/                     — real brand fonts (Fonteys PRO, CC ClobberinTime, Baby Eliot, PiS Coalfield)
assets/                    — logos, paper textures, marginalia, stamps, dice, mascot
preview/                   — Design-System-tab cards (one concept per file)
ui_kits/
  hub/                     — KayfaBizarro web hub (Hero, GameCard, RuleSection, Footer)
  cards/                   — Cut-&-Play card-game kit (cards, dice, modes, ladder, table)
  slides/                  — 1920×1080 zine-deck templates (cover, divider, list, feature, closing)
```

See **CONTENT FUNDAMENTALS** and **VISUAL FOUNDATIONS** below for the rules of the road.

---

## CONTENT FUNDAMENTALS

The voice is **Uncle FrizzleBob**: a yellow cartoon rogue rabbit who claims to be a "Professional Reality-Wrestler & Epistemiologic Outlaw." Everything copy-related funnels through this character.

### Voice rules

- **Second person, intimate, conspiratorial.** "You sit down. You draw a card. You announce who you are." The reader is *at the table*, not being marketed to.
- **Imperatives over explanations.** "Don't explain it — perform it." "Put on your mask." "Stay fluffy." "Cut the cards."
- **Manifesto cadence.** Short sentences. *Italicized italics for emphasis.* Em-dashes — like that. Periods doing the work commas usually would.
- **Wrestling + theatre + therapy + philosophy** — mixed without apology. "Kayfabe," "ritual," "ordeal," "tabula rasa," "Akt I/II," "Ego Trip."
- **Footnote-style asides** in pull-quotes attributed to FrizzleBob, often undermining the rule that precedes them.
- **No corporate softening.** The word "user" never appears. It's "you," "the table," "the storyteller."

### Casing & punctuation conventions

- **Brand stylization:** `Kayfa*Bizarro*` (italic middle), `KayfaBizarro` plain, all-caps for **CALLS** (BINGO!, BLÖDSINN!, BOGGLE?, BONGO!, EGO TRIP, WARP ZONE).
- **Bold for terms**, *italics for emphasis*, `monospace` for actual rules / quick-reference tables.
- **Section labels** lowercase or sentence case ("Your Turn," "What is this?"), never SHOUTING-CAPS except for exclamations.
- **German loanwords** stay German: *Blödsinn!* with the umlaut, always.
- **Numbered steps** stay flush — `01 Draw  · 02 Roll · 03 Play · 04 Tell · 05 Move`.
- **No period at the end of taglines.** Taglines breathe.

### Vocabulary whitelist (in marginalia / micro-text)

`KayfaBIZARRO!` `BLÖDSINN!` `HUMBUG!` `Stay fluffy!` `KayfaBINGO!` `KayfaBONGO!` `KayfaBOGGLE!` `What the FLUFF?!`

These should appear infested across margins, gutters, sticker-style, in different hand-letterings. Add contextual jokes inline.

### Emoji policy

**No emoji.** Ever. Use:
- Hand-drawn doodle marks (✷ ✺ ✱ as ink alternatives, sparingly)
- Dice unicode `⚀ ⚁ ⚂ ⚃ ⚄ ⚅` for rules tables
- Pointing-finger marginalia (☞) and asterisk-styled footnote markers (`*`, `†`)
- Em-dashes — used liberally
- Real card-suit glyphs (♠ ♥ ♦ ♣) for reference tables

Emoji are too clean, too vendor-themed, too 2014-tech. Doodles or nothing.

### Tone examples (from source)

> "Cards are not rules. They are **invitations**. Reality is not fixed — it is negotiated, one sentence at a time, until the story lands or the die hits 6. Put on your mask. Let's wrestle."

> "Don't explain it. Perform it."

> "If you're not embarrassed, you're not playing hard enough."

> "The Mode is a frame, not a cage."

> "A messy ending that was earned beats a neat ending that was imported."

> "Stay fluffy."

When in doubt: write something a Banksy character would mutter to a wrestler at 2am about Kant.

---

## VISUAL FOUNDATIONS

### Aesthetic mandate

**Analog. Slightly unfinished. Tactile. Calm, not chaotic.** Think: a beloved zine that lived in a backpack for a year. Pencil under ink, ink bleeding into watercolor, watercolor bleeding past the panel border, panel border drawn with a wobbly hand on top of a Xerox of last week's draft.

If it looks designed-in-a-tool, **damage it**: rotate ±1.5°, drop a paper-grain overlay on top, scribble over a corner, ink-stamp a red call-out, tear an edge.

### Color system

The palette is a **harmonic retro-comic** set — desaturated, warm, slightly faded by sun. Not vivid. Watercolor-bleeding-into-newsprint, not Pantone.

**Paper grounds**
- `--paper-cream`: `#f3ead3` — primary aged-paper background
- `--paper-bone`: `#ece1c0` — slightly more weathered, for sub-panels
- `--paper-stain`: `#dfcd9e` — coffee-ring tone, accents

**Inks (line work, type)**
- `--ink-black`: `#1f1a14` — never pure `#000`. Slightly warm, slightly soft.
- `--ink-charcoal`: `#3a342a` — secondary line / body text
- `--ink-pencil`: `#7d736480` — pencil-underdrawing tone, used at 50% opacity

**Wash colors (watercolor accents — use as bleeding fills, never as flat brand colors)**
- `--wash-rabbit-yellow`: `#e9c14a` — Uncle FrizzleBob's coat. Warm mustard, not lemon.
- `--wash-blood-red`: `#c2412c` — BLÖDSINN! stamps, danger calls, finale
- `--wash-mystic-violet`: `#6b4e7d` — Mystical mode, bizarro
- `--wash-tragic-blue`: `#3e6a83` — Tragic mode, melancholy washes
- `--wash-comic-green`: `#7a8d4a` — Comic mode, mossy/sour
- `--wash-heroic-orange`: `#d97c3a` — Heroic mode, sunset
- `--wash-forbidden-magenta`: `#a64670` — Forbidden mode, line-crossing
- `--wash-clinical-teal`: `#4f8a85` — MedKayfab-only accent, clinical-but-not-sterile

**Stamp / sticker reds & yellows**
- `--stamp-red`: `#b8361f`
- `--stamp-yellow`: `#f0c948`

All washes are used **transparent** (≈55–80% alpha) over paper, never flat. Two washes overlapping should *blend*, not stack solid.

### Typography

The system uses **four roles**, each from a different "voice":

1. **Display** — `CC ClobberinTime` — comic-stamp headline family, in 4 textures:
   `Smooth` (default), `Krackle` (xerox-noise), `Crunchy` (heavy ink), `Open` (outline).
   Use Krackle/Crunchy for the most "stamped on paper" feel; Smooth as default.

2. **Hand** — `Baby Eliot` — natural pen-hand for captions, marginalia, asides.

3. **Mono / typewriter** — `PiS Coalfield` — beat-up xerox/typewriter texture for rules tables, reference, FAQ.

4. **Serif / manifesto** — `Fonteys PRO` — full weight range (400/500/700/800/900 + italics). Long-read body, FrizzleBob's quotes, manifesto paragraphs.

Type pairings should feel **collaged**: two voices on one page is normal; three is the signature look.

See `colors_and_type.css` for the full ramp + semantic tokens.

### Spacing & layout

- **Grid:** intentionally loose. Use a 4 / 8 / 12 / 24 / 48 / 72 / 120 px scale, but break it on purpose for hand-collage feel.
- **Rotation:** every "stamped" or "taped" element has `rotate(-2deg)` to `rotate(+3deg)`. Never plumb-square.
- **Panels:** drawn borders, never `border: 1px solid`. Use `border-image` with a hand-inked SVG, or layered box-shadow + clip-path for torn edges.
- **Margins are sacred.** Every page reserves 12–18% of edge real-estate for **marginalia** (tiny doodles, micro-text, scattered creatures). The center holds the "rule"; the edges chew on it.
- **No glassmorphism. No neumorphism. No gradients-as-style.** A gradient may exist only as a *watercolor wash*, never as a UI primitive.

### Backgrounds

- Default: `--paper-cream` with a layered **paper-grain** PNG (provided in `assets/paper-grain.svg`) at low opacity.
- Section breaks: paper switches to `--paper-bone` or a pasted "torn-paper" strip overlay.
- Imagery: full-bleed watercolor washes are okay for hero panels — but always with a torn or feathered edge (`mask-image`).

### Borders, shadows, corners

- **Borders:** drawn ink, varying thickness. Implemented via `border-style: solid` + slight `box-shadow` jitter, or as inline SVG paths drawn with `stroke-dasharray` mimicry. **Never 1px crisp.**
- **Corner radius:** `0` (taped corner), or `--r-wobble: 6px 14px 4px 18px / 12px 6px 18px 8px` for that "drawn-by-hand-quickly" asymmetric rounding.
- **Shadows:** never CSS drop-shadow blur as a UI affordance. Only as **paper drop-shadow**: a hard, slightly-offset shadow (`2px 3px 0 rgba(31,26,20,0.3)`) under cards/cards-on-table, always warm-toned, never grey.
- **Inner shadow:** acceptable as **edge wear** — a faint vignette around the edges of a panel suggesting age.

### Animation

The whole system breathes. Nothing snaps; everything wobbles.

- **Hover states:** slight rotate (±0.5°), tiny scale (1.01), or a swap to a hand-redrawn variant (use 2–3 frames of the same element, switch on hover for "wiggle"). Never a clean opacity fade.
- **Press states:** "stamp down" — translate 1–2px down + slight darken via overlay. The element should feel pressed into paper.
- **Transitions:** `cubic-bezier(0.34, 1.4, 0.64, 1)` (overshoot bounce) for entrances. ~200–280ms. Exits faster (~120ms) ease-out.
- **Card wiggle:** when a card lands on the Stage, a 2-keyframe wobble (rotate -3deg → +2deg → 0deg, 320ms).
- **Dice roll:** rapid face-swap at 60ms intervals for ~600ms, then rest on final face with a wobble.
- **Marginalia:** slow, slow drift — sub-pixel translation over 6–10 seconds, looped, easing inOut. Should feel like the page itself is alive but tired.

### Hover & interaction states

- **Default link:** ink-charcoal, underline drawn as a hand-wobble SVG (not text-decoration).
- **Hover link:** flips to `--wash-blood-red`, underline gets thicker (one frame redraw), no smooth transition.
- **Buttons** are stamps, not pills. Rectangular, ink-bordered, rotated, hover-wobbles, press-stamps.
- **Disabled:** crossed out with a hand-drawn X overlay. Never grey-and-fade.

### Cards (the literal cards in the game, AND UI cards)

- Aspect ratio: **2.5 × 3.5** (poker-card / tarot-card proportions) for game cards.
- Border: ink-drawn frame, ~6–10px thick, slightly imperfect.
- Internal layout: **Image — Quote — Lore — Power**, in that order, top to bottom. Always.
- Drop shadow: hard, warm, offset down-right `4px 5px 0 rgba(31,26,20,0.25)`.
- Back of card: bold logo block with marginalia infestation.
- UI cards (panels in the hub): same vocabulary — ink border, paper inside, slight rotation, paper drop-shadow.

### Transparency, blur, "modern" effects

- **Blur:** never. The only blur allowed is a watercolor edge (already baked into the wash texture).
- **Transparency:** only on watercolor washes (55–80% alpha) and pencil underdrawing (40–50%).
- **No backdrop-filter.** No `mix-blend-mode: multiply` *unless* you're literally simulating ink on paper (then yes, `multiply` is the right tool — for ink-line SVG over paper texture).

### Imagery & illustration vibe

- **Always animals.** No humans. Anthropomorphic rogues (rabbits, foxes, pigeons, possums, alligators).
- **Visible pencil under ink.** All illustrations should reveal construction.
- **Watercolor bleeds past ink.** Always.
- **No 3D, no photoreal, no DOF.**
- **Aged-paper substrate** under everything.
- **Color vibe:** warm-leaning, faded, summer-afternoon. Never cool / neon / digital.

### Marginalia rules (mandatory on every surface)

Every page or screen MUST have marginalia. Empty corners are a bug.

- **Density:** 4–8 marginalia elements per typical view (more on dense pages).
- **Scale:** 12–28px, much smaller than the main content.
- **Placement:** gutters, between blocks, in the negative space between paragraphs, on top of borders.
- **Content options:** tiny rabbits playing dice, surreal blobs, a stamp, a torn coupon, a question-mark blob, a coffee ring, a piece of tape, scribbled marginalia text.
- **Rotation:** every marginalia element is rotated.
- **Use the whitelist micro-text** (`KayfaBINGO!`, `BLÖDSINN!`, `Stay fluffy!`, etc.) — handwritten, in red ink-stamp, or scratched across the corner.

### Layout rules at a glance

- Generous outer margins (≥ 60px on a 1280-wide deck slide).
- Center column does the work; edges hold the noise.
- One serif voice + one hand voice + (optional) one typewriter voice on a single composition. Avoid four.
- Headlines breathe (≥1.5em line-height for hand-letter, ≥1.3em for serif body).
- It's okay to leave generous empty paper. Calm is part of the brand.

---

## ICONOGRAPHY

KayfaBIZARRO does not have a corporate icon set. Iconography is **hand-drawn marginalia** + **a small library of game-specific glyphs**.

### Approach

- **Game glyphs** (dice faces, story-mode symbols, social-call stamps, the Quest Die ladder) are drawn-in-ink SVGs in `assets/glyphs/`. Treat them as **illustrations, not icons**. They have variable line weight, rotation, and warmth.
- **UI icons** (e.g. a "next" arrow, a download icon, a print icon on the hub) are also drawn — use the same hand-letter SVGs. **Do not** use Lucide / Heroicons / Material — they are too clean and would break the spell.
- **Suit / dice unicode** (`⚀ ⚁ ⚂ ⚃ ⚄ ⚅`, `♠ ♥ ♦ ♣`) is acceptable in `Special Elite` mono context — it reads as typewriter-stamped, which fits.
- **Marginalia stamps** (red-ink "KayfaBINGO!", "BLÖDSINN!", "PWYW", coffee ring, etc.) are PNG/SVG assets in `assets/stamps/` to be sprinkled freely.
- **NO emoji.** Documented above; restated here.
- **NO icon font.** Vendor icon fonts are bland and Adidas-shop.

### What's in `assets/`

- `frizzlebob-rabbit.svg` — the mascot, simplified inline placeholder (replace with the real Procreate art when available)
- `paper-grain.svg` — tileable paper-grain noise overlay
- `dice/` — six D6 face glyphs, hand-drawn
- `stamps/` — `bingo.svg`, `blodsinn.svg`, `humbug.svg`, `stay-fluffy.svg`, `pwyw.svg`
- `marginalia/` — small drifting creatures and doodles
- `logos/` — primary mark, wordmark, sub-logos for KayfaBizarro & MedKayfab

### Substitution flag

Where the brand calls for **bespoke Procreate-drawn art** that we don't have access to, we ship simplified inline-SVG placeholders. Replace them with the real assets when available — the system is designed to swap one for one (same filenames in `assets/`).

---

## CAVEATS & ASKS (please read)

This system was built from the live web hub + the creator's NotebookLM persona prompt — we did **not** have direct access to:

- The Procreate brushes / source illustration files.
- The actual printed card art.
- The custom hand-lettered fonts (if any).
- The Gumroad PDFs / printable PDFs.

So three things are **substitutions** that I'd love your feedback on:

1. **Fonts** — Real brand fonts (Fonteys PRO, CC ClobberinTime in 4 textures, Baby Eliot, PiS Coalfield) are now wired in. Google Fonts substitutions removed.
2. **Illustrations** — every rabbit, fox, dice and stamp shipped in this system is a placeholder I generated as inline SVG so the layouts breathe correctly. **Drop your real art into `assets/`** with the same filenames and the whole system inherits it.
3. **The exact palette** — I've encoded the *language* of your watercolor palette (warm, faded, harmonic). If you've established specific hex values from the cards, please share them and I'll lock them in.

This is **v0.1**. Once you've reviewed, comment on what feels right and what feels too-clean — I'll iterate hard on whichever surfaces need more grit.
